# Pixel art craft: rules a machine can check, what to draw, animation, rendering, AI cleanup (2026-10-24)

Why: the owner wants the pixel module to help an agent **draw** strong pixel art in code (string-grid sprites), **check** it
automatically, and **brief** Gemini. Our pixel games: Candle Crypt (16 px string-array sprites), Swarm Smash. Today the platform
has `technique: pixel` in `gp art` (cut to a grid by the most common colour per cell, snapped to `art.palette`),
`drawPixelSprite`, `gp assets upscale` (Scale2x/xBR/xBRZ) and a 5×7 pixel font ([art.md §5](../guides/art.md#5-generated-art-gp-art)).
Game-level art notes of the roguelites are in [pixel-roguelites §1.2, §2](pixel-roguelites-2026-10.md#2-what-the-breakouts-share).

Conventions. "Opaque pixel" = alpha 255; "boundary pixel" = an opaque pixel with a transparent 4-neighbour; "cluster" = an
8-connected group of same-coloured pixels. **(ours)** marks a threshold or algorithm we propose, not one from a source;
**(unverified)** marks a claim I found only second-hand. Sources that are tool vendors are marked (vendor).

## 0. The short version

- Pixel art reads by **clusters, values and edges**, not detail; almost every classic mistake (orphans, doubles, uneven steps,
  banding, pillow shading, outer AA, mixed pixel sizes) is a grid pattern a program can find.
- Few colours per sprite (NES 3 + transparent; Shovel Knight 4–5 + transparent) in **hue-shifted ramps** (≤ 20° a step,
  saturation peaking mid-ramp). One game = one palette, one light, one outline rule, **one pixel size**.
- Render into a low-res buffer, scale by a **whole number**, never rotate or fractionally scale sprites; smooth the camera by
  rendering one extra pixel and shifting the upscaled image by the fractional part.
- Image models paint off-grid "pixel-looking" pictures; the fix is pipeline, not prompt: detect the grid, dominant colour per
  cell, snap to the palette, then the same lint.

## 1. Fundamentals as checkable rules

Each rule: what · why · how to detect on the grid · the usual fix.

**1.1 Limited palette, few colours per sprite.**
What: a game palette of roughly 16–64 colours, a sprite using a handful of ramps. NES sprites had "4 colors (or 3 colors +
transparency)"; Shovel Knight relaxed this to **4–5 colours per sprite plus transparency** and kept the 54-colour NES palette
plus 4 added colours ([Yacht Club, Breaking the NES](https://www.yachtclubgames.com/blog/breaking-the-nes/)). The PixelJoint
community tutorial sets no hard limit but recommends small palettes "for cohesion and control"; a high count "can signal dirty
tools" ([PixelJoint tutorial, cure 2010](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)).
Why: shared colours tie a set together; every extra near-duplicate is noise.
Detect: count distinct opaque RGBA values; flag any colour not in the game palette; flag near-duplicates (two colours with
OKLab ΔE < 0.03 **(ours)**). Guidance **(ours)**: ≤ 8 colours for a 16 px sprite, ≤ 12 for 32 px, ≤ 16 for 64 px, outline included.
Fix: merge near-duplicates to the nearest palette entry; re-shade with fewer, more distinct steps.

**1.2 Hue-shifted ramps.**
What: a ramp is "a specific range of colors … arranged according to brightness"; shift hue along it. Slynyrd's Mondo palette uses
**9 swatches per ramp, +20° hue between swatches ("about as high as I go")**, brightness rising left to right with smaller steps
near 100 %, saturation peaking at the middle swatch and never reaching 0 or 100; "the biggest mistake is combining high
saturation and brightness" ([Slynyrd Pixelblog 1](https://www.slynyrd.com/blog/2018/1/10/pixelblog-1-color-palettes);
[GameDev.net reprint](https://www.gamedev.net/articles/visual-arts/color-palettes-r4964/)). The usual direction: shadows toward
blue/purple, highlights toward yellow/orange ([Stardew modding wiki](https://stardewmodding.wiki.gg/wiki/How_to_make_pixel_art);
[Tiny Warrior Games](https://tinywarriorgames.com/2018/12/)). A "straight ramp" (one hue) "lacks interest and is harder to
harmonize" (Slynyrd). For one sprite a material usually needs 3–5 steps of such a ramp (Shovel Knight's 4–5 colours per sprite).
Why: darkening without changing hue looks "flat and muddy" ([Wayline](https://www.wayline.io/learn/color-palettes/2));
hue shift adds contrast and harmony between ramps.
Detect **(ours)**: group the sprite's colours into ramps (by palette definition, or cluster by hue then sort by OKLab L). Per ramp:
L strictly increasing; adjacent ΔL ≥ 0.06 (else the steps don't read at 1×); hue moves monotonically, darker end toward ≈ 260°
(blue-violet), lighter toward ≈ 60–90° (yellow), total shift 10–60°; chroma maximum not at either end; flag any colour with
L > 0.85 and chroma > 0.15 ("eye-burning"). Flag a ramp with < 5° total hue change as straight.
Fix: generate the ramp from one base colour (§7 tool 2) instead of hand-picking.

**1.3 Value contrast and a readable silhouette.**
What: the sprite must read as its subject as a solid shape, at 1×, before any shading. Block the shape "in a single color" first
([sprite-ai guide](https://www.sprite-ai.art/guides/how-to-create-16x16-pixel-art) (vendor)); test "the outline, facing
direction, and main action" at thumbnail scale ([Bugnet](https://bugnet.io/blog/how-to-make-pixel-art-that-reads-clearly));
Pixel Logic gives readability a chapter ([Gumroad listing](https://michafrar.gumroad.com/l/pixel-logic)). Lospec: "any two touching
colors should be distinguishable" at 1× ([Lospec outlines 2](https://lospec.com/articles/pixel-art-outlines-part-2-using-color)).
Characters get the strongest value contrast and saturation; distant scenery a narrower value range
([Bugnet](https://bugnet.io/blog/how-to-make-pixel-art-that-reads-clearly)).
Detect **(ours)**: (a) silhouette: alpha mask at 1×; compare masks of all sprites of one role (enemies) pairwise after aligning
by bounding box — IoU > 0.85 means two things share a silhouette. (b) value: render in grayscale (OKLab L); the sprite's mean L
must differ from the play background's mean L by ≥ 0.25, and touching regions of different colours by ΔL ≥ 0.06 or a hue
difference ≥ 30°. (c) facing: the mask's horizontal centre of mass must lean toward the facing side for a side-view walker
(weak signal; report only).
Fix: change the shape (pose, a weapon, a hat) before changing colours; then widen the value gap.

**1.4 Outlines.**
What: a 1-px outline separates object from background; it is "the thinnest a single-color completely-connected line can be";
segments connect only diagonally; a common approach is **outline only the outside**; skip inner lines where parts already
contrast; omit the outline where the object touches another (feet on ground) or it looks like it floats
([Lospec outlines](https://lospec.com/articles/pixel-art-outlines)). Black is versatile but "overpowering or retro"; coloured
outlines use a darker shade of the outlined part; "an outline should always increase contrast, and never decrease it"; it should be
darker than both object and background. **Selective outline (selout)**: darker outline where the sprite is in shadow, lighter where
lit, so contrast stays even all the way round; inner lines one step darker than the fill
([Lospec outlines 2](https://lospec.com/articles/pixel-art-outlines-part-2-using-color)). Selout is "not just making the corners
dark" ([Pixel Parmesan](https://pixelparmesan.com/anti-aliasing-fundamentals-for-pixel-artists)); PixelJoint warns a light selout
only works on a known (e.g. dark) background ([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)).
Detect **(ours)**: boundary pixels → share that are in the darkest step of their ramp or the outline colour (≥ 0.9 = "outlined");
outline continuity: boundary ring is one 8-connected loop per shape; thickness: an outline pixel whose removal keeps the ring
8-connected and that has an outline neighbour on two orthogonal sides is a double (1.5); selout check: on the lit side boundary
L may be higher than on the shadow side, but every boundary pixel must stay darker than the adjacent interior pixel. Across a set:
all sprites follow the same mode (none / black / coloured / selout).
Fix: generate the outline from the mask (§7 tool 3) rather than drawing it; for selout take the darkest-but-one step of the
adjacent fill's ramp on the lit side.

**1.5 Lines, jaggies and doubles.**
What: a diagonal is a staircase; it reads smooth when step lengths are consistent ("even 2, 2, 2 steps"); **jaggies** are
"uneven step lengths"; **doubles** are "two stacked pixels that thicken a 1px line"; **orphans** are lone pixels
([Wayline lesson](https://www.wayline.io/learn/pixel-art/1)). Only horizontal, vertical and 45° lines are free of jaggies
([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)). Straight diagonals use "identical line segments"
(1:1, 2:1, 3:1 …); curves order lengths smoothly, longest at the extremes ("5, 2, 2, 1, 1 rather than 5, 2, 1, 2, 1")
([Lospec outlines](https://lospec.com/articles/pixel-art-outlines)). Aseprite's "pixel perfect" stroke mode exists to avoid
doubles ([braceletbook summary](https://www.braceletbook.com/tutorials/120_making-better-outlines-for-alpha-patterns/)).
Detect **(ours)**: trace each 1-px line (outline ring, or same-colour thin cluster) as a chain; split into monotone runs (direction
changes sign → new segment); per segment list run lengths along the major axis. Straight segment: all lengths equal, or a strict
alternation of two adjacent values (1,2,1,2 for in-between angles). Curve: lengths non-increasing then non-decreasing (no
"5,2,1,2,1"). Flag a length that breaks the pattern by ≥ 2 or a lone 1 between longer runs. **L-corner/double**: pixel p of a line
with line-neighbours at two orthogonal sides (N and E) that are themselves diagonal neighbours → p is redundant; allowed only at
a deliberate sharp corner (≤ 1 per 8 boundary pixels, ours).
Fix: delete the L-corner pixel (what Aseprite's pixel-perfect does while drawing); re-space runs to the nearest regular pattern.

**1.6 Banding.**
What: "neighboring pixels line up, so the grid immediately becomes more evident"; variants: hugging, fat pixels, skip-one, 45°
([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)); "lines of the same length placed parallel to each other"
([Pixel Parmesan](https://pixelparmesan.com/anti-aliasing-fundamentals-for-pixel-artists)). A 2025 TU Delft thesis that
semi-automates fixing it: "Pixel Fixer" ([data + summary](https://data.4tu.nl/datasets/11446578-c1f3-474c-9cc4-6978a79b675b));
its definition: two adjacent pixel runs of different colours whose endpoints align along a shared axis
([TU Delft repository](https://repository.tudelft.nl/file/File_65d43acd-9779-4eab-999b-9bcd4f0a96a9) — full text not
reachable, the definition is from the search snippet: unverified).
Detect **(ours)**: for every horizontal and vertical run of length ≥ 2 in colour A, look at the parallel run in the next row/column;
if it is a different colour B (not transparent) and both runs start *and* end at the same coordinate (± 0), count a band; also
diagonal bands (each run shifted by exactly one). Report bands where 3+ parallel runs stack (a staircase of colours tracking one
another).
Fix: offset one ramp's edge by a pixel, vary run lengths, or merge a step.

**1.7 Pillow shading.**
What: shading that "surrounds a central area with darker bands", following the outline instead of a light
([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)); "a pronounced form of banding, characterized by concentric
strips that perfectly follow the object's outline" (TU Delft thesis snippet, unverified).
Detect **(ours)**: for each interior pixel compute its distance to the boundary (chamfer) and its signed position along the light
axis (§1.8). Pillow shading = luminance correlates with boundary distance (Spearman ρ > 0.7) while the correlation with the light
axis is weak (|ρ| < 0.3). Also the outermost interior ring being the darkest step all the way round.
Fix: choose a light direction and re-shade: lit side lighter, the side away from the light darker, the shadow shape following
the form, not the edge.

**1.8 Light from one direction.**
What: watch "the direction light is coming from"; PixelJoint's examples use top-left
([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)). Dead Cells built a lighting system so shadows need not
be hand-drawn on every frame ([Game Developer](https://www.gamedeveloper.com/production/art-design-deep-dive-using-a-3d-pipeline-for-2d-animation-in-i-dead-cells-i-)).
Detect **(ours)**: per sprite, the luminance-weighted centroid of interior pixels minus the geometric centroid gives a light vector;
its angle must be within ± 45° of the game's declared light (e.g. upper-left), and all sprites of a set within ± 45° of each other.
Fix: mirror the shading, not the sprite (a flipped sprite flips its light — keep separate left/right shading or a symmetric light
from above).

**1.9 Orphan pixels and noise; clusters.**
What: a cluster is "groups of pixels of the same color that together produce a solid color field"; isolated pixels "usually read
as noise" and are for "very specific and purposeful reasons" — speculars, essential details
([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)). A PixelJoint critique (eishiya): "use clusters smaller than
4px in area very sparingly" ([PixelJoint](https://pixeljoint.com/pixelart/90047.htm)). Texture = "a few
simple clusters" repeated in varied distribution ([Slynyrd Pixelblog 2](https://slynyrd.com/blog/2018/2/15/pixelblog-2-texture)).
In animation "a single misplaced pixel can create an eyesore" ([Slynyrd Pixelblog 8](https://slynyrd.com/blog/2018/8/19/pixelblog-8-intro-to-animation)).
Detect: **orphan** = an opaque pixel whose 8 neighbours all differ from it in colour (transparent counts as different). Allowed
orphans **(ours)**: the lightest step of a ramp (a specular), or an eye/feature listed in the sprite's `keep` map. **Noise ratio**
(ours) = pixels in clusters of size ≤ 2 ÷ opaque pixels; flag > 10 % on sprites, > 20 % on textures.
Fix: delete the orphan (take the majority neighbour colour) or attach it to a cluster.

**1.10 Hand anti-aliasing.**
What: intermediate-colour pixels at step corners; the AA value reflects how much of the cell the ideal line would cover; "the longer
the segment, the longer the AA"; reuse palette colours, avoid plain averages; **don't AA the outer edge of a game sprite** (the
background is unknown) — keep AA inside; skip AA on small sprites, where it "can read as noise"; too much AA blurs, can create
banding ([Pixel Parmesan](https://pixelparmesan.com/anti-aliasing-fundamentals-for-pixel-artists)). "Only as much AA as is
necessary" ([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)).
Detect: any boundary pixel with 0 < alpha < 255 (outer AA by transparency); boundary pixels whose colour is lighter than both
the outline colour and the adjacent fill (AA toward a presumed light background) **(ours)**. On sprites ≤ 24 px: AA pixels
(colour between two neighbouring clusters, cluster size 1) > 5 % of boundary length → flag **(ours)**.
Fix: binarize alpha (≥ 128 → opaque); recolour outer AA pixels to the outline or fill.

**1.11 Dithering.**
What: alternating two colours so the eye mixes a third; the 50/50 checkerboard is the common pattern; it should "taper the ends
and edges" of a field; too much becomes a texture; lower contrast between the two colours calls for less; random dithering is
discouraged ([PixelJoint](https://pixeljoint.com/forum/forum_posts.asp?TID=11299)). Pixel Logic describes dithering as gradients
"primarily for backgrounds" ([80.lv on Pixel Logic](https://80.lv/articles/pixel-logic-a-pixel-art-tutorial-book/)). Dither only
where two shades meet, with solid shade between ([GameDev.net thread](https://www.gamedev.net/topic/629704-dithering-help-in-for-my-pixel-art)).
Detect **(ours)**: 2×2 windows that are perfect checkerboards of two colours; flag on a sprite ≤ 32 px when they cover > 10 % of
its opaque area, and anywhere when the two colours are > 2 ramp steps apart (reads as noise, not as a mid-tone).
Fix: replace with a solid mid-step of the ramp, or limit the dither to a 1–2 px transition band.

**1.12 Mixels and one pixel density.**
What: mixels = noticeably inconsistent pixel sizes in one image or scene; they make assets look "from different sources"; a common
rule (attributed to Pixel Logic): never mix resolutions ([Flowlab forum](https://community.flowlab.io/t/mini-rant-stop-using-mixels/38287)).
Godot notes that with sub-pixel scaling "there is no longer a 1:1 correspondence between sprite pixels and screen pixels"
([Godot docs](https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html)).
Detect **(ours)**: inside an asset, mark every pixel that belongs to an aligned 2×2 same-colour block; a region > 25 % of the
asset made only of such blocks while the rest has 1-px detail = mixed density. For an image of unknown scale use the grid detector
of §5 — its detected scale must be 1 after cleanup. At runtime: every draw's scale = the game's integer scale, no rotation (a dev
assertion in the renderer, §4).
Fix: redraw at one size; never upscale a 16 px sprite by 2 to sit next to 32 px art (use xBRZ-style upscale + redraw, as
[art.md §5](../guides/art.md#5-generated-art-gp-art) says).

## 2. What to draw

**2.1 Virtual resolutions and integer scales.** Most pixel games use viewports "between 256×224 and 640×480"; 640×360 integer-scales
to 720p, 1080p, 1440p and 2160p with no bars ([Godot docs](https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html)).
The arithmetic (ours): 320×180 → ×4 = 1280×720, ×6 = 1080p, ×8 = 1440p, ×12 = 4K. 384×216 → ×5 = 1080p, ×10 = 4K, not 1440p.
480×270 → ×4 = 1080p, ×8 = 4K, not 720p/1440p. 640×360 → ×2, ×3, ×4, ×6. Shovel Knight: 400×240, each game pixel 4.5×4.5 at
1080p — a non-integer scale they accepted on TV ([Yacht Club](https://www.yachtclubgames.com/blog/breaking-the-nes/)).
Hyper Light Drifter: "our game is 480p … very intentionally so" ([GamingBolt](https://gamingbolt.com/our-game-is-480p-yeah-its-low-resolution-and-very-intentionally-so/amp));
480×270 is a forum figure (unverified). Celeste: 320×180 (a Steam user claim, unverified).
**For a browser game fix the scale first, then the size (ours):** `scale = max(1, floor(deviceH / targetH))` with `targetH` in
180–270 for action games; then `virtualW = ceil(deviceW / scale)`, `virtualH = ceil(deviceH / scale)` — Godot's `expand` idea
(width grows with the screen). Example: phone landscape 2400×1080 device px → scale 6 → 400×180; phone portrait 1080×2400 →
target width 180–270: scale 4 → 270×600; desktop iframe ≈ 1600×900 device px → scale 5 → 320×180. Work in device pixels (CSS ×
`devicePixelRatio`, capped as `fitCanvas` does): MDN warns that a non-integer `devicePixelRatio` makes "certain pixels … drawn
larger than others" ([MDN](https://developer.mozilla.org/en-US/docs/Games/Techniques/Crisp_pixel_art_look)).

**2.2 Sprite sizes.** Shovel Knight tiles are 16×16 (Yacht Club). Stardew: most sprites 16×16, NPC overworld 16×32, portraits
64×64 ([Stardew forum](https://forums.stardewvalley.net/threads/sprite-sizes-character-sheets-pixel-art.5597/latest), community).
Celeste: "most of the sprites were somewhere around 16x16" (unverified recollection). Dead Cells characters are "only 50 pixels"
tall ([Game Developer](https://www.gamedeveloper.com/production/art-design-deep-dive-using-a-3d-pipeline-for-2d-animation-in-i-dead-cells-i-)).
Rule of thumb **(ours)**: hero height ≈ 1/8–1/12 of the view height in an action game (16–24 px at 180 tall, 24–32 px at 270),
≈ 1/5 in a close-camera puzzle or board game; enemies differ from each other by silhouette first, size second; bullets 3–6 px
with a 1-px dark rim. On a phone at scale 6 a 16 px hero is 96 device px ≈ 32 CSS px ≈ 6 mm (est.) — readable, but a face at 16 px
is 2–4 pixels. The owner asked for "very strong pixel art with big sprites" for Candle Crypt (art.md §5): 32 px heroes at
a 270-tall view, or 24 px at 180, are the step up.

**2.3 Proportions, faces, exaggeration.** Slynyrd's 6-head model gives "stockier, doll-like figures" that keep key details small;
shrinking further means dropping facial features ([Slynyrd Pixelblog 49](https://www.slynyrd.com/blog/2024/3/25/pixelblog-49-realistic-human-anatomy)).
A survey of game sprites: chibi heads 60–67 % of height use 1×2 eyes and no mouth; RPG heads 38–54 % move to 2×2 eyes from
16×32 ([Blake Crosley](https://blakecrosley.com/blog/pixel-art-characters-on-iphone), second-hand). For 16–32 px heroes:
2–3 heads tall, eyes 1×2 or 2×2 with a 1-px highlight, a single prop that makes the silhouette (weapon, hat, candle flame).
Exaggerate what the play needs: the facing (nose/weapon side), the danger (teeth, a glow), the state (Celeste's hair colour shows
the dash: `NormalHairColor` #AC3232, `UsedHairColor` #44B7FF, a white flash for 0.12 s — [Celeste Player.cs](https://raw.githubusercontent.com/NoelFB/Celeste/master/Source/Player/Player.cs)).

**2.4 A set that looks like one game.** One palette (Shovel Knight kept the NES palette and added only 4 colours), one light
direction, one outline mode, one pixel density, a consistent idle complexity ("idles should be consistent within a project",
[Slynyrd Pixelblog 8](https://slynyrd.com/blog/2018/8/19/pixelblog-8-intro-to-animation)). Mismatched density makes a game look
assembled from packs ([Flowlab forum](https://community.flowlab.io/t/mini-rant-stop-using-mixels/38287)).

**2.5 Background vs foreground.** Reserve the strongest value contrast and saturation for characters; far layers low contrast,
desaturated, lighter (atmospheric fade) ([Bugnet](https://bugnet.io/blog/how-to-make-pixel-art-that-reads-clearly); a
parallax guide, [Sorceress wiki](https://sorceress.games/wiki/sorceress/parallax) (vendor)). Shovel Knight averages 5–6
background layers; bosses fight on black (Yacht Club). An analysis of AdamCYounis's pieces: "dark foregrounds, light horizon,
mid-grey mountains" in 4–5 layers ([ArtStation study](https://ckelsallpixels.artstation.com/projects/yJ3Qn3), second-hand).
Check **(ours)**: background layers' mean chroma < foreground sprites' mean chroma; the play layer's L histogram must not overlap
the hero's L range by more than 50 %.

**2.6 Tiles.** 16×16 is the classic size (Shovel Knight). Seams: spread visual weight evenly so no area dominates; let clusters
wrap past the edge; repeated key shapes must not touch each other ([Slynyrd Pixelblog 28](https://slynyrd.com/blog/2020/5/21/pixelblog-28-side-view-tiles);
"hide the patterns within consistent non-distracting textures", [Pixelblog 20](https://slynyrd.com/blog/2019/8/27/pixelblog-20-top-down-tiles)).
Autotiles: edge-only (Wang) and corner sets need 16 tiles; the **blob** set needs **47** (8 neighbours, a diagonal counts only
when both adjacent edges are filled: 256 → 47), 16 with rotation and mirroring
([Boris the Brave](https://www.boristhebrave.com/2021/11/14/classification-of-tilesets/)); an Aseprite extension builds all 47
from 6 template tiles ([AutoBlob](https://community.aseprite.org/t/extension-autoblob-generate-the-full-47-tile-blob-autotile-set-from-6-template-tiles/28606)).
Variation tiles break runs but too many duplicates "create the very repetition" ([OpenGameArt template](https://opengameart.org/content/seamless-tileset-template)).
Checks **(ours)**: seam = tile the tile 2×2 and run the lint (orphans, banding) across the joins; repetition = render 8×8 tiles,
downscale ×4, autocorrelation peak at the tile period above 0.9 → visible grid; add a variant or a landmark cluster.

**2.7 UI and type.** A fixed pixel font at a whole scale (we have a 5×7 font, `@gp/art/type/pixel`); 9-slice panels at the
game's density (Saint11 has a "UI 9-Slice" tutorial, [Saint11](https://saint11.art/blog/pixel-art-tutorials/); `nineSlice` exists
in `@gp/art/sprite`). Rule **(ours)**: HUD drawn into the same low-res buffer or at an integer multiple of it, never mixed with smooth
vector text in the play view.

**2.8 Effects.** Shovel Knight uses **flashing instead of alpha transparency** (invincibility) and palette cycling for damage and
explosions (Yacht Club). A hit flash is the sprite drawn as a white silhouette for a few frames (Celeste's hair: white 0.12 s);
smears are in-betweens "held for only one or two frames" ([Prolific Studio](https://prolificstudio.co/blog/smear-frames/));
particles are whole pixels or tiny clusters in palette colours, not soft sprites **(ours, following 1.10)**.

## 3. Animation

**Frame counts.** Run: Mega Man's run is 3 drawings in a 4-slot loop (the pass frame twice); Slynyrd builds 8-frame cycles and cuts
to 6 ("work well in most cases") or 4; key poses are contact, pass and high point, the recoil frame is the first to cut; idles
are mostly "bouncy breathing", and 8-frame idles are "unreasonable for small teams"; many JRPGs reuse a 2-frame walk as idle
([Slynyrd Pixelblog 8](https://slynyrd.com/blog/2018/8/19/pixelblog-8-intro-to-animation)). A 12-frame run can be cut to 8 or 6
"for most pixel art games" ([Slynyrd Pixelmotion](https://www.patreon.com/posts/20778494)). Celeste's run is 4 frames and
Shovel Knight's walk 6 (vendor guides, [sprite-ai](https://www.sprite-ai.art/blog/pixel-art-animation), unverified). Common
targets: idle 2–4, run 6–8, attack 4–6 or 6–12 split into anticipation, strike, recovery (vendor tables, same).

**Timing.** Slynyrd's 8-frame run is 80 ms per pose; cut to 4 frames, 160 ms per pose, to keep the energy; "smooth movement
doesn't necessarily equal good animation"; too many in-betweens look "sluggish" (Pixelblog 8). Aseprite's default frame is 100 ms.
Dead Cells keys attacks pose to pose and adds interpolation frames only before or after keyframes — "Never in-between" — letting
VFX carry the motion ([Game Developer](https://www.gamedeveloper.com/production/art-design-deep-dive-using-a-3d-pipeline-for-2d-animation-in-i-dead-cells-i-)).
Recipe for an attack **(ours, from the above)**: anticipation 2 frames held long (120–200 ms total), a smear/contact frame 1
(40–60 ms), the contact pose held (80–120 ms) while the hit lands, recovery 2–3 frames (≈ 200 ms). Per-frame durations, not a
single fps.

**Squash and stretch at pixel scale.** Celeste scales the sprite on jump to (0.6, 1.4) and on landing up to (1.6, 0.4), easing back
([Celeste Player.cs](https://raw.githubusercontent.com/NoelFB/Celeste/master/Source/Player/Player.cs)) — it works because the
scaled sprite is drawn into the 320×180 buffer with nearest-neighbour, so the result stays on the game grid (no mixels). In our
renderer: squash in the low-res buffer, never on the upscaled screen.

**Sub-pixel animation.** "Changing the colors of pixels, instead of outright moving pixels", for motion smaller than a pixel
(Metal Slug) ([Substack](https://someanimatorwannabe.substack.com/p/animator-techniques-sub-pixel-animation)); smear colours across
in-betweens, better on large sprites and low-detail areas ([Tiny Warrior Games](https://tinywarriorgames.com/2019/01/04/game-development-pixel-art-sub-pixel-animation/)).
Pixel Logic has a chapter on it (Gumroad listing). For 16–24 px sprites a bob of one whole pixel is usually enough **(ours)**.

**Secondary motion and hit-stop.** Hair, capes, flames lag one frame behind the body (Celeste's hair is a separate chain, see the
code). Hit-stop: Celeste freezes the game **0.05 s** at a dash start, **0.1 s** on an explosion launch
([Player.cs](https://raw.githubusercontent.com/NoelFB/Celeste/master/Source/Player/Player.cs)); 50–100 ms on a heavy hit is the
common advice ([uhiyama-lab](https://uhiyama-lab.com/en/notes/unity/unity-game-feel-hit-feedback/)).

**What reads in a web game (ours).** At 6–8 fps of drawn animation on a 60 fps game, motion reads if the key poses are strong; flicker
is the enemy — lint every pair of consecutive frames for pixels that toggle on/off in isolation (an orphan in the difference image)
and for a bounding box that jumps by > 1 px without intent. Dead Cells admits "flickering pixels" are the cost of rendering 3D small
(Game Developer).

## 4. Rendering in code

1. **Low-res buffer, integer upscale.** Draw the whole frame into an offscreen canvas of the virtual size; draw it to the screen
   canvas scaled by an integer with `ctx.imageSmoothingEnabled = false` and CSS `image-rendering: pixelated`
   ([MDN](https://developer.mozilla.org/en-US/docs/Games/Techniques/Crisp_pixel_art_look); MDN: draw "at integer multiples of
   canvas pixels", else a 128 px image drawn into 100 px gives 0.78-px pixels and blur). Unity's Pixel Perfect Camera "Upscale
   Render Texture" does the same ([Unity docs](https://docs.unity3d.com/Packages/com.unity.2d.pixel-perfect@5.0/manual/index.html));
   Godot: stretch mode `viewport`, scale mode `integer` ([Godot docs](https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html)).
   Our perf note agrees: one filtered full-screen upscale costs as much as the rest ([art.md §3](../guides/art.md#3-performance)).
2. **Snap everything to the game grid.** Positions are floats in game logic, `Math.round` (or floor) at draw time into the buffer.
   Unity's "Pixel Snapping … prevents subpixel movement" (Unity docs).
3. **Smooth camera trick.** Snapped cameras jitter ([Godot forum](https://forum.godotengine.org/t/how-to-set-up-smooth-sub-pixel-camera-movement-for-pixel-art-games/38765)).
   yal.cc's fix: make the buffer **one pixel larger** than the view (W+1 × H+1), place the camera at `floor(x), floor(y)`, then draw
   the buffer to the screen shifted by the fractional part: `draw_surface(view_surf, -frac(x), -frac(y))` in game pixels
   ([yal.cc](https://yal.cc/gamemaker-smooth-pixel-perfect-camera/)). In canvas: `screen.drawImage(buf, -Math.round(fx*S), -Math.round(fy*S), (W+1)*S, (H+1)*S)`
   with S the integer scale — the world scrolls in device-pixel steps while sprites stay on the grid. uPixelator does the same in
   3D ([Unity Asset Store](https://marketplace.unity.com/packages/tools/camera/upixelator-pixelize-3d-scenes-243562)). The HUD is drawn
   after, unshifted. Parallax layers get the same treatment each with their own fractional offset (ours).
4. **Rotation: avoid at runtime.** Nearest-neighbour rotation scrambles pixels; Godot recommends `canvas_items` (no 1:1 pixels) if
   sprites must rotate — i.e. give up pixel purity (Godot docs). Options: (a) design so nothing rotates (8-direction sprites,
   symmetric bullets); (b) **pre-rotate** frames at build time (8 or 16 angles) with RotSprite and draw the nearest; (c) rotate
   inside the low-res buffer with nearest-neighbour, accepting some noise for fast spinning things.
   **RotSprite** (Xenowhirl): 1) upscale ×8 with a modified Scale2x that treats *similar* (not only identical) colours as equal;
   2) optionally search a small grid of rotation offsets for the one with the least colour difference / fewest boundary samples;
   3) rotate with nearest-neighbour while shrinking back ×1/8 in the same pass; 4) optionally restore lost single-pixel details
   (source pixel differs while the destination has three identical neighbours). No new colours are introduced. **Fast RotSprite**
   (Pixel Studio): one ×3 upscale, rotate with rounded coordinates, ×1/3 down ([Wikipedia](https://en.wikipedia.org/wiki/Pixel-art_scaling_algorithms);
   [RotSpriteSharp](https://www.nuget.org/packages/RotSpriteSharp.SystemDrawingExtensions)). Aseprite ships RotSprite as a rotation
   option ([Aseprite docs](https://aseprite.org/docs/rotate/)).
5. **Scaling sprites: whole numbers only.** A boss at 2× next to 1× enemies is a mixel (§1.12); draw a bigger sprite instead.
   Squash/stretch is the exception, and only inside the buffer (§3).
6. **Aspect ratios.** Either keep one aspect with bars (Godot `keep`, Unity "Crop Frame"; the bars "cannot be drawn into") or let the
   view grow along one axis (Godot `expand`, Unity "Stretch Fill") — Godot docs, Unity docs. Shovel Knight widened the NES 256-px
   width to 16:9 keeping the 240-px height (Yacht Club). For portals (desktop + phone, both orientations) the expand rule of §2.1 is
   the one that never letterboxes; the level must tolerate a wider or taller view (camera bounds, UI anchored to corners).

## 5. AI-generated pixel art

**Why general models fail.** They "paint pixels that look like pixel art but aren't snapped to a consistent grid", with uneven pixel
sizes, colour bleed and extra shades ([SpriteCook](https://www.spritecook.ai/blog/nanobanana-pixel-art-for-games) (vendor));
"uneven pixel sizes, inconsistent outlines, blur, and noise" ([Runware on Retro Diffusion](https://runware.ai/blog/retro-diffusion-creating-authentic-pixel-art-with-ai-at-scale) (vendor));
the dedicated Retro Diffusion models were trained at ≤ 256×256 native resolution for that reason
([Scenario help](https://help.scenario.com/en/articles/retro-diffusion-models-the-essentials/)). No independent benchmark found.

| Defect | Detect | Fix |
|---|---|---|
| Fake pixels: one "pixel" is a k×k block, k unknown and drifting | unfake.js: take the 3×3 image tiles with most variance, Sobel X/Y, sum edge strength per column/row, find peaks, histogram the peak-to-peak distances — the most common distance is the scale; then try each offset 0..k−1 and keep the one whose grid lines best hit the peaks, per axis ([unfake.js write-up](https://dev.to/jenissimo/how-to-tame-your-ai-pixel-art-3pk5)) | resample one value per cell |
| Inconsistent grid (cells of 15, 16, 17 px) | edge-profile peaks not evenly spaced (std of peak gaps > 10 % of k, ours) | snap per row/column to the detected peaks instead of a fixed k (Pixel Snapper "grid resolution can drift", [Pixel Snapper](https://github.com/Hugo-Dz/spritefusion-pixel-snapper)) |
| Blended cell colours | per cell, top colour vs runner-up | unfake: take the top colour if it beats the runner-up by > 5 %, else the mean; we take the mode (art.md) — keep the mode, fall back to the mean only for flat cells (ours) |
| Too many colours / near-duplicates | distinct colours after resampling > budget (§1.1) | quantize (unfake uses Wu via `image-q`, then a second pass after downscaling; Pixel Snapper defaults to 16 colours or a given palette) — we snap to `art.palette` |
| Speckle, orphans | §1.9 | majority filter on orphans only (not on speculars) |
| Blurry/soft edge, semi-alpha halo | §1.10 | binarize alpha, recolour boundary to outline colour |
| Broken or missing outline | §1.4 continuity/coverage | regenerate the outline from the mask (§7 tool 3) |
| Mismatched density across a set | detected k differs per asset relative to its target size; §1.12 | ask for the same "subject fills an N-pixel grid" in every prompt; resample all to the same grid; reject outliers |
| Different light / palette per asset | §1.8 light vector; palette coverage | send the style board and one finished sprite as reference images (Gemini takes up to 14 references, [Gemini docs](https://ai.google.dev/gemini-api/docs/image-generation)) |

**Prompt wording.** Google: "describe the scene, don't just list keywords"; be hyper-specific; state the purpose; iterate in
conversation; use **semantic negatives** — describe what you want ("an empty, deserted street") rather than "no cars"; the
sticker template names style, subject, palette, line and shading style and ends "The background must be white"
([Google Developers Blog](https://developers.googleblog.com/en/how-to-prompt-gemini-2-5-flash-image-generation-for-the-best-results/)).
Transparency is not documented there — ask for a flat single-colour background and cut it out (we do). SpriteCook's working prompt:
"pixel art infantry soldier, side view, 2d game sprite, clean pixel edges, limited color palette, transparent background"; say
"side view" or "front view" explicitly (the default drifts to 3/4); an era phrase ("16-bit style") sets the look; "32x32" "sometimes
work[s] and sometimes get[s] ignored"; don't expect grid perfection from the prompt — fix it in post; generate at the highest
resolution so the detector finds the grid ([SpriteCook](https://www.spritecook.ai/blog/nanobanana-pixel-art-for-games) (vendor)).
**What to say (ours, from the above):** a sentence per asset: the view; the role ("a 2D game sprite of …"); "drawn as N×N pixel art,
every pixel a large square of equal size, the subject filling the grid"; "a palette of K flat colours: …hex…" (the game's ramps);
"shaded with hue-shifted steps: shadows toward violet, highlights toward warm yellow; light from the upper left"; "a 1-pixel dark
outline around the outside only"; "a big readable silhouette, simple shapes, large eyes"; "on a flat pure white background".
**What to avoid:** "realistic", "detailed", "intricate", "4K/8K", "smooth shading", "gradient", "soft light", "glow", "depth of field",
"3D render" — each pulls toward painterly blends (our `REALISM_WORDS` already warns on part of this list); asking for a sprite
sheet of many poses in one image (cells drift, density varies — ours, unverified) — one pose per request with the first sprite as
reference, as `gp art` frames already do.

## 6. What breakout pixel games do

**Celeste (2018).** About 320×180 (unverified), most sprites near 16×16 (unverified). The technique that sells it: **state shown
in a few pixels and motion feel** — hair colour as the dash meter (red → blue → pink, white flash 0.12 s), squash to (0.6, 1.4) on
jump and (1.6, 0.4) on landing inside the low-res buffer, 50 ms freezes on dash
([Player.cs](https://raw.githubusercontent.com/NoelFB/Celeste/master/Source/Player/Player.cs)). Pixel art by Pedro Medeiros and Amora
Bettany ([HandWiki](https://handwiki.org/wiki/Software:Celeste_(video_game))).

**Dead Cells (2018).** Characters ≈ 50 px tall. A simple 3D model + skeleton (3ds Max, FBX) rendered by an in-house tool "at very
small size with no anti-aliasing", each frame exported as PNG **with its normal map**, lit by a toon shader; pose-to-pose keys,
interpolation only before or after keys; retakes in minutes; the cost is flickering pixels
([Game Developer](https://www.gamedeveloper.com/production/art-design-deep-dive-using-a-3d-pipeline-for-2d-animation-in-i-dead-cells-i-);
[Habr](https://habr.com/post/416589)). Lesson: a pipeline that renders *to* pixels at the final size, with no AA, then lights it.

**Shovel Knight (2014).** 400×240 virtual, 16×16 tiles, the NES palette + 4 colours, 4–5 colours per sprite, 5–6 parallax layers,
flashing instead of alpha, palette cycling for variants and damage, bosses on black — "a rose-tinted view of an 8-bit game"
([Yacht Club](https://www.yachtclubgames.com/blog/breaking-the-nes/)). Lesson: a strict palette with a few deliberate exceptions.

**Hyper Light Drifter (2016).** "Our game is 480p … very intentionally so" ([GamingBolt](https://gamingbolt.com/our-game-is-480p-yeah-its-low-resolution-and-very-intentionally-so/amp)).
It bends the rules: "broad swaths of soft gradient" and soft pastel colour against hard-edged pixels, regions with their own
palettes ([AV Club](https://avclub.com/hyper-light-drifter-blended-past-and-present-to-become-1798255620)). Lesson: a soft light
layer over a strict pixel layer — kept as separate layers, not baked into the sprites.

**Sea of Stars (2023).** Pitched with "fully dynamic lighting of sprites including normal mapping", shadow receiving and casting,
and pixel-perfect rendering, tied to a day/night cycle (Kickstarter feature list via [NicheGamer](https://nichegamer.com/2020/03/19/the-messenger-prequel-rpg-sea-of-stars-enters-kickstarter-launches-2020-for-pc/);
shipped details unverified). Lesson: classic sprites + modern light.

**Eastward (2021).** "Retro-pixel + 3D lighting", aiming at "a feeling close to Japanese animation from 90s"
([Siliconera](https://www.siliconera.com/?p=522687)); how the lighting is done is not documented (unverified). Lesson: dense,
lived-in tiles and props; light as mood.

**Stardew Valley (2016).** 16×16 tiles and items, 16×32 villagers, 64×64 portraits (community, [Stardew forum](https://forums.stardewvalley.net/threads/sprite-sizes-character-sheets-pixel-art.5597/latest)).
Hi-res mod textures "stick out unless you overhaul all vanilla assets" (same) — mixels in practice. Lesson: tiny sprites, big
portraits for emotion.

**Vampire Survivors (2021).** Sprites from an Oryx Design Lab asset pack, with some Castlevania-copied item sprites later replaced
([developer on Steam](https://steamcommunity.com/app/1794680/discussions/0/3201496371570662124)). Lesson: a coherent bought set
plus effects and numbers carried a breakout; also: check a pack's provenance.

## 7. Recommendations for the platform

Ordered by value for our games (an agent drawing string-grid sprites in code, Gemini for bigger ones, portal play on phones).

1. **`pixelSprite(rows, key)` + `lintPixel(sprite, opts)`** in `@gp/art/pixel`: compile string rows (`'..oo..'`) with a key of
   ramp names (`o: 'skin.2'`) into a canvas; validate equal row lengths, every char in the key, every colour in the game palette;
   then lint with the checks of §1 — orphans (8 neighbours all differ, speculars and `keep` pixels exempt), noise ratio, colour
   budget, near-duplicates, outer semi-alpha, outline coverage/continuity, L-corners, uneven line runs, banding (aligned parallel
   runs), pillow shading (luminance ~ boundary distance but not ~ light axis), light vector vs the declared light, checkerboard
   dither share. Output: issues with coordinates and a fix line, like `gp validate`. `gp art` runs it on every pixel asset.
2. **`ramp(base, { steps, hueShift, light })`** and a palette lint: build ramps in OKLCH (L rising, hue toward ≈ 60–90° up and
   ≈ 260° down, ≤ 20° per step, chroma peak mid-ramp, chroma capped at high L), and flag straight ramps, ΔL < 0.06 between steps,
   eye-burning colours — an extension of `checkPalette` in `@gp/art/palette`.
3. **Fixers, not only checks**: `outline(mask, { mode: 'none'|'black'|'colour'|'selout', inside: false })` generates an outside
   1-px outline from the alpha mask (lit-side selout = second-darkest step of the adjacent fill's ramp); `cleanPixel()` removes
   orphans by majority, deletes L-corners, binarizes alpha, snaps to the palette. Agents draw the fill; the tool draws the line.
4. **Set coherence report** (`gp art --check` / `gp qa`): every pixel asset — one palette, detected pixel scale 1, the same outline
   mode, light vectors within ± 45°, hero/enemy size ratios, pairwise silhouette IoU < 0.85 for enemies; plus a contact sheet
   `qa/pixel-sheet.png` showing each sprite at 1× and play scale, in one colour (silhouette) and in grayscale on the game's
   background — the eyes for the reviewer.
5. **`createPixelView({ targetH })`**: the low-res buffer renderer — integer scale from device pixels, `expand` sizing (§2.1),
   smoothing off, `image-rendering: pixelated`, the W+1 × H+1 smooth-camera offset, HUD after the shift; in dev, warn on any
   sprite draw at a non-integer scale or with rotation (the runtime mixel check).
6. **Grid detection in `gp art` (`technique: pixel`)**: detect the model's pixel scale and offset from Sobel edge-profile peaks
   (the unfake.js method) instead of assuming `size`; per-row/column snapping when the grid drifts; reject an image whose grid is
   not found or whose detected subject size is far from the asked grid; then palette snap, `cleanPixel`, `lintPixel`; failures
   become a `--only` remake list.
7. **A better `PIXEL_STYLE` + per-asset prompt**: sentence form; the view named; "N×N pixel art, every pixel a large square of
   equal size"; the palette's ramps as hex with the light rule; "1-pixel dark outline around the outside only"; flat white
   background; send the style board and the hero sprite as references for every asset; extend `REALISM_WORDS` with "detailed",
   "intricate", "gradient", "soft light", "depth of field", "3D render" for pixel games.
8. **Animation helpers + lint**: per-frame durations (`frames: [{ i, ms }]`) instead of one fps; `squash()` that scales inside the
   buffer; `hitFlash` (white silhouette, ≈ 0.1 s — `silhouette()` exists) and `hitStop(ms)` (≈ 50 ms); a frame-pair lint for
   flicker (isolated pixels in the frame difference) and bounding-box jitter.
9. **Tile tools**: a seam lint (2×2 self-tiling run through `lintPixel`), a repetition score (autocorrelation at the tile period),
   and a 47-blob autotile builder from 5–6 template tiles with its bitmask table (8 neighbours, diagonals only when both edges set).
10. **`rotsprite(img, angle)` at build time** (×8 similarity-Scale2x, rotate + shrink nearest, single-pixel restore) to pre-bake 8 or
    16 rotated frames for weapons, projectiles and props, so nothing rotates at runtime.

## 8. What I couldn't verify

- Unread: Derek Yu's tutorial ([derekyu.com](https://derekyu.com/makegames/pixelart.html), no text returned; topics via
  [80.lv](https://80.lv/articles/pixel-art-basics-tutorial)); Saint11's tutorials (GIFs, titles only); Pixel Logic (chapter list);
  MortMort, AdamCYounis (a fan study only), Brandon James Greer; the TU Delft "Pixel Fixer" full text (HTTP 503).
- Community or plan-only claims: Celeste 320×180, Hyper Light Drifter 480×270, Sea of Stars' lighting, Eastward's lighting, the
  Celeste/Shovel Knight frame counts (vendor blog). Enter the Gungeon, Blasphemous, Noita: no reliable source on their pixel
  technique, so not profiled.
- Every **(ours)** threshold is a starting value to calibrate on Candle Crypt and Swarm Smash sprites before it blocks anything.
