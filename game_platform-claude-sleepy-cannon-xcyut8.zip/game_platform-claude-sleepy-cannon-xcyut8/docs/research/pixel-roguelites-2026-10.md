# Pixel roguelites that broke out: what they share, what fits the platform, and what to make next (2026-10-23)

> The owner, 2026-10-23: «изучи все популярные пиксельные игры на рынке которые стрельнули. А именно пиксельные рогалики.
> Это у нас получается и это пока вектор». Our pixel roguelites do best: **Candle Crypt** (QmaCyber/game9) is in its second
> Basic Launch at **desktop 11/15, «Ready for Full Launch»** (playtime 13m33s → 5, D1 18.18 % → 5, conversion 42.22 % → 1;
> `publisher/results.yaml`, the owner's score screen of 2026-10-22). Swarm Smash (game20) and Kinetic Noir (game23, a story
> 2D action-roguelite slasher) are in the same vector.
>
> **Method.** Web search and the pages it could open (Wikipedia, press releases, CrazyGames game pages, the Raijin Steam
> tracker), 2026-10-23. Each number has its source inline. **Raijin, SteamPulse and Gamalytic numbers are third-party
> estimates** from review counts, not sales; developer announcements are marked as such. CrazyGames' "likes" are the
> votes on a game's page on the day we read it — cumulative, so an old game has more; they rank popularity only roughly.
> Poki has no roguelike category any more; Yandex Games' pages didn't open from here (see §6).
>
> **Not repeated here:** the survivors crowd on CrazyGames (≈ 20–25 "X Survivors", [crazygames-requirements-2026-09.md §13](crazygames-requirements-2026-09.md#13-what-crazygames-says-it-wants-now-and-saturated-genres),
> [market-depth-2026-09.md §1.2](market-depth-2026-09.md#12-crazygames-genre-by-genre-live-titles-found-verdict)); depth
> techniques and run lengths of VS/Brotato/20MTD ([market-depth §2](market-depth-2026-09.md#2-depth-that-keeps-players-10-minutes));
> Survivor.io vs Archero retention (same, §1.5); juice numbers ([game-design-2026-10.md §1.2](game-design-2026-10.md#12-game-feel-and-juice-concrete-numbers));
> what our roguelites built themselves ([our-games-survey-2026-10.md](our-games-survey-2026-10.md)).

## 0. The short version

1. **The genre is huge and crowded at once.** Roguelike/roguelite releases on Steam went from 432 (2021) to 1,926 (2025);
   the genre grossed ≈ $400 M on Steam in 2025 and ≈ $500 M in H1 2026, concentrated in a few hits (Alinea Analytics,
   via [Recognizing Patterns, 2026-07-19](https://recognizingpatterns.substack.com/p/the-roguelite-cull-hasnt-happened)).
   "Vampire Survivors-style clones" are the most oversupplied sub-genre there; deckbuilders and management-adjacent
   roguelites break through more often (same source, directional, no rates).
2. **Every breakout has a one-sentence hook that is a familiar thing turned around:** *you are the bullet hell* (Vampire
   Survivors), *poker whose jokers break the rules* (Balatro), *Breakout that levels up* (Ball x Pit), *chess where you're
   the king with a shotgun* (Shotgun King), *pachinko as combat* (Peglin), *the window is the arena* (Windowkill), *you build
   the loop, the hero walks it* (Loop Hero). A theme alone never was the hook.
3. **One input, deep build.** The breakouts move with one stick or one button (VS: move only; Archero: stop to shoot;
   Balatro: pick cards), and put all the depth in the build: 1-of-3 picks every 20–60 s, items that combine into a third
   thing (VS evolutions, Ball x Pit fusions, Balatro joker chains).
4. **Short units inside a 15–30-min run.** VS runs 15/20/30 min, Halls of Torment 30, Brotato 20 waves of 20–90 s with a
   shop after each, Archero rooms "probably under a minute", Ball x Pit stages "rarely longer than fifteen minutes". The
   unit ends in a choice; the run ends in a meta purchase.
5. **Cheap, and spread by streamers.** $2.99–$5.49 for VS, 20 Minutes Till Dawn, Brotato, Halls of Torment, Megabonk,
   Windowkill; each was lifted by one stream or video (SplatterCatGaming → VS, Asmongold → Halls, Northernlion and Dan
   Gheesling → Balatro, HandOfBlood → Brotato). On a portal the game is free: **the cover and the first 30 seconds play the
   streamer's role.**
6. **Pixel art is cheap and readable, not the reason.** VS was built on £1,100 of bought assets; Dead Cells renders 3D
   models to pixels; Halls of Torment pre-renders a 1990s Diablo look; Brotato isn't pixel art at all, Megabonk and CloverPit
   are low-poly 3D. What they share is **one coherent low-fi style that stays legible with 300 things on screen.**
7. **On the web, the pixel roguelites with the most votes on CrazyGames are ports of proven games:** Endless Waves Survival
   (≈ 60K likes, a 2022 mobile/Steam game), Dwarves: Glory, Death and Loot (23K), the Binding of Isaac demo (20K),
   10 Minutes Till Dawn (13K), War Lands (11K), Tavern Rumble (11K). New HTML5 survivors of 2025–2026 sit at 0.6–1.6K. The
   tag's "most popular" list now leads with **card roguelites** (Tavern Rumble, Poker Quest, Cardlike), not survivors.
   Poki's catalogue shows almost none (one: Survivor Z).
8. **Candle Crypt has the breakouts' long game and lacks their first minute.** Its desktop playtime and D1 score 5 and 5
   with a long run, a deep meta and a daily on the title; its conversion scores 1 because the first 30 s show "one
   skirmish at 8 s, then empty corridors" (the blind first look), a HUD of tabletop numbers nobody has explained yet, and
   two-handed controls. The breakouts hand the player a fight in the first second and a choice by 0:20–0:30.
9. **What to make next:** a new *verb* inside the pixel-roguelite frame, never a new theme on the survivors or twin-stick
   loop: a bomb-chain crawler, a boomerang that must be caught, a gunless bullet-catcher, a chess-move dungeon deckbuilder,
   a dig-then-defend night, a snake of heroes (§5). `gp forecast --idea` can't tell them apart (EV ≈ €15–22 each): the
   choice is made by originality and the first-minute design the model doesn't see.

## 1. The games

### 1.1 Facts and numbers

Steam unless said. "est." = a third-party estimate. Dates are of the source.

| Game (year) | Price | Players / sales (source) | How it spread (source) |
|---|---|---|---|
| **Vampire Survivors** (EA Dec 2021, 1.0 Oct 2022) | $2.99 at the breakout ([Prima Games](https://primagames.com/news/vampire-survivors-sleeper-hit-steam-linux)); $4.99 list ([Raijin](https://raijin.gg/app/1794680/Vampire_Survivors)) | > 1 M copies in 2–3 months ([GameBusiness.jp interview with poncle](https://www.gamebusiness.jp/article/2022/10/21/20972.html)); **27 M+ players** (poncle, June 2026, [press release](https://app.pressengine.net/newsdesk/bastion/stories/poncle-reveals-new-vampire-survivors-content-expansion-pack-survivaton-lineup-and-japan-studio)); > 70K concurrent Feb 2022 ([Wikipedia](https://en.wikipedia.org/wiki/Vampire_Survivors)); mobile: 1 M downloads in its first week ([80.lv](https://80.lv/articles/mobile-version-of-vampire-survivors-surpassed-1-million-downloads/)); est. 6.5 M Steam copies (Raijin) | a SplatterCatGaming video of 6 Jan 2022 started it ([Mein-MMO](https://mein-mmo.de/en/indie-game-for-e2-39-conquers-steam-99-positive-reviews,773936)); Twitch around Feb 2022 ([Dread Central](https://www.dreadcentral.com/editorials/486243/vampire-survivor-oh-man-this-is-doing-numbers/)); BAFTA Best Game 2023 (Wikipedia) |
| **Vampire Crawlers** (Apr 2026) | $10 ([Destructoid](https://www.destructoid.com/vampire-crawlers-million-copies-week-hit-every-genre-possible/)) | 1 M in a week — copies or players, outlets differ ([Shacknews](https://www.shacknews.com/article/148938/vampire-crawlers-one-million-one-week)) | the VS name; a turn-based deckbuilder spin-off, Game Pass |
| **Dead Cells** (EA 2017, 1.0 2018) | — | 10 M by June 2023 ([Gematsu](https://www.gematsu.com/2023/06/dead-cells-sales-top-10-million-further-updates-planned-through-2025)); 34 free updates, 4 DLC (same) | long-tail updates, console and mobile ports (iOS 2019, Android 2020: [Wikipedia](https://en.wikipedia.org/wiki/Dead_Cells)) |
| **Enter the Gungeon** (2016) | — | 200K first week, 1 M July 2017 ([MCV](https://www.mcvuk.com/enter-the-gungeon-hits-1m-copies/)), > 3 M by 2020 ([Wikipedia](https://en.wikipedia.org/wiki/Enter_the_Gungeon)) | Devolver; > 1 M on Switch alone ([GoNintendo](https://www.gonintendo.com/stories/329958-enter-the-gungeon-hits-1-million-sold-on-switch-ultimate-edition)) |
| **The Binding of Isaac** (2011) / Rebirth (2014) | — | original 2 M by 2013 ([Game Informer](https://www.gameinformer.com/b/news/archive/2013/04/21/the-binding-of-isaac-breaks-two-million-units-sold.aspx)); with Rebirth > 5 M by July 2015 ([Wikipedia](https://en.wikipedia.org/wiki/The_Binding_of_Isaac:_Rebirth)); est. 10 M Rebirth on Steam ([Raijin](https://raijin.gg/app/250900/The_Binding_of_Isaac_Rebirth)) | Northernlion's let's plays (McMillen told him the 2 M, same source); a Flash demo still on CrazyGames (20K likes, below) |
| **Risk of Rain 2** (EA 2019) | — | 1 M in its first month; Risk of Rain 1 took almost five years to reach that on Steam ([PCGamesN](https://www.pcgamesn.com/risk-of-rain-2/one-million-sales)) | 3D co-op (contrast); est. 12 M (Raijin) |
| **Brotato** (EA 2022, 1.0 2023) | $4.99 ([Raijin](https://raijin.gg/app/1942280/Brotato)) | > 1 M in EA (Sept 2022), **> 10 M by 2025** all platforms ([Wikipedia](https://en.wikipedia.org/wiki/Brotato)) | German streamers, HandOfBlood ([Mein-MMO](https://mein-mmo.de/brotato-neuer-hype-handofblood/)); Game Pass 1 M downloads ([LevelUp](https://www.levelup.com/noticias/776431/Este-juego-la-rompio-en-Xbox-Game-Pass-devs-celebran-mas-de-1-millon-de-descargas)); one-man studio, Godot (Wikipedia) |
| **Balatro** (Feb 2024) | — | $1 M gross in 8 h, 1 M in a month, **5 M by Jan 2025**, about half after the Sept 2024 mobile ports ([Wikipedia](https://en.wikipedia.org/wiki/Balatro); [MobileSyrup](https://mobilesyrup.com/2025/01/21/balatro-5-million-copies-sold-update/)) | 48 wishlists in May 2023; Northernlion's stream of 19 July 2023 lifted followers ≈ 400 %, Dan Gheesling's made wishlists spike; 114,977 wishlists at the end of Jan 2024 ([Push to Talk](https://www.pushtotalk.gg/p/the-word-of-mouth-magic-behind-balatro)); Game of the Year at the GDCA, three awards at The Game Awards 2024 (Wikipedia) |
| **Halls of Torment** (EA May 2023) | €5 ([Mein-MMO](https://mein-mmo.de/asmongold-twitch-steam-hit-aus-stuttgart-halls-of-torment/)) | 70K first week of EA ([GamingOnLinux](https://www.gamingonlinux.com/2023/06/halls-of-torment-hits-over-70k-sales-in-the-first-week/page=1/)); 1 M on Steam, Oct 2024 ([Wikipedia](https://en.wikipedia.org/wiki/Halls_of_Torment)) | Asmongold found it on stream (Mein-MMO); a free demo two months before EA (Wikipedia) |
| **20 Minutes Till Dawn** (EA 2022) | $2.99, no discount | 110K in 36 h, 220K in 4 days ([How To Market A Game](https://howtomarketagame.com/2022/06/14/20-minutes-till-dawn/)); est. 749K ([Raijin](https://raijin.gg/app/1966900/20_Minutes_Till_Dawn)) | its free browser demo, **10 Minutes Till Dawn, is on CrazyGames: 13K likes, 9.6, desktop only** ([CrazyGames](https://www.crazygames.com/game/10-minutes-till-dawn)) |
| **Spelunky** (2008) / Spelunky 2 (2020) | — | original > 1 M ([Simon Parkin's podcast notes](https://music.amazon.com/podcasts/d49b4865-7dfc-4f65-81a1-f7a0fb08c98f/episodes/2e35184f-8746-4499-a78a-c5ef6730fde2/my-perfect-console-with-simon-parkin-derek-yu-gamemaker-spelunky-ufo-50)); Spelunky 2 est. 455K on Steam ([Raijin](https://raijin.gg/app/418530/Spelunky_2)) | speedrun and daily-challenge culture (estimate: not sourced here) |
| **Noita** (2019/2020) | — | est. 2.6 M ([SteamPulse](https://steampulse.org/game/881100)) – 3.2 M ([Steam Revenue Calculator](https://www.steampageanalyzer.com/tools/revenue-calculator/881100)); no official number | every pixel simulated: a clip machine |
| **Moonlighter** (2018) | — | 1 M copies and 3.5 M players by mid-2020 ([PocketGamer.biz](https://www.pocketgamer.biz/moonlighter-one-million-copies/)) | shopkeeper by day, dungeon by night |
| **Loop Hero** (2021) | — | 500K first week ([Gematsu](https://www.gematsu.com/2021/03/loop-hero-sales-top-500000)); 1 M on Steam in < 1 year ([TechRaptor](https://techraptor.net/gaming/news/loop-hero-sales-hits-1-million-copies-on-steam)) | Devolver; a hook you explain in one line |
| **Death Must Die** (2023/2024) | — | est. 563K, 90 % of 21.6K reviews ([Raijin](https://raijin.gg/app/2334730/Death_Must_Die)) | a Diablo-like survivors with gods' blessings |
| **Soul Knight** (2017, mobile) | free, IAP | > 100 M Android installs (AppBrain, an estimate: [AppBrain](https://www.appbrain.com/dev/ChillyRoom/)) | the mobile twin-stick reference; TouchArcade 4/5, "made for" Gungeon fans ([TouchArcade](https://toucharcade.com/2017/03/10/soul-knight-review/)) |
| **Archero** (2019, mobile, contrast) | free, IAP | ≈ 96 M downloads, ≈ $263 M net IAP by Jan 2025 (AppMagic, [Game World Observer](https://gameworldobserver.com/2025/01/20/archero-2-revenue-8-million-in-11-days-vs-original-game)) | UA on one-thumb video ads (estimate) |
| **Survivor.io** (2022, mobile, contrast) | free, IAP | $75 M from 37 M downloads in 2 months ([Mobilegamer.biz](https://mobilegamer.biz/two-months-in-survivor-io-passes-75m-from-37m-downloads/)); ≈ $5 M a month three years on ([Global Games Forum](https://www.globalgamesforum.com/news/how-survivor.io-continues-to-pull-in-5-million-a-month-three-years-later)) | TikTok ([Mobilegamer.biz](https://mobilegamer.biz/tiktok-drives-habbys-survivor-io-past-15m-iap-revenue-12m-downloads/)) |
| **Hades** (2020, not pixel, contrast) | — | 1 M by Sept 2020, 700K of it in EA ([GameSpot](https://gamespot.com/articles/hades-has-sold-1-million-copies-nearly-one-third-sold-in-last-few-days/1100-6482388/)) | story that reacts to every death |
| **Slay the Spire 2** (EA Mar 2026, not pixel, contrast) | $24.99 | 6.5 M by mid-May 2026, peak 574,638 concurrent (Alinea via [Recognizing Patterns](https://recognizingpatterns.substack.com/p/the-roguelite-cull-hasnt-happened)) | the sequel's audience; 39 % first-timers (same) |
| **Rogue Legacy** (2013) | — | recouped its cost in an hour, 100K first week ([MCV, GDC 2014](https://www.mcvuk.com/development-news/rogue-legacy-profitable-after-one-hour-on-sale/)); Rogue Legacy 2 est. 329K ([Raijin](https://raijin.gg/app/1253920/Rogue_Legacy_2)) | heirs with traits: every death is a new character |
| **Children of Morta** (2019) | — | > 1 M ([TechRaptor](https://techraptor.net/content/children-of-morta-sales-great-success-recouping-development-costs)) | a family story across runs |
| **Wizard of Legend** (2018) | — | 200K in a week, 500K by July 2018 ([God is a Geek](https://www.godisageek.com/2018/07/wizard-legend-crosses-500k-copies-sold-platforms/)) | spell-combo dashing |
| **Cult of the Lamb** (2022, contrast) | — | 1 M first week ([Gematsu](https://www.gematsu.com/2022/08/cult-of-the-lamb-sales-top-one-million)); > 4.5 M later ([KitGuru](https://www.kitguru.net/tech-news/mustafa-mahmoud/cult-of-the-lamb-surpasses-4-5-million-copies-sold/)) | base management + roguelite, a cute-dark look |
| **Dome Keeper** (2022) | $17.99 PC, $9.99 mobile ([Pocket Gamer](https://www.pocketgamer.com/dome-keeper/official-launch/)) | 1 M players (2024, [GamingOnLinux](https://www.gamingonlinux.com/2024/09/dome-keeper-hits-1-million-players-multiplayer-and-modding-support-to-come/comment_id=269839)); est. 499K copies ([Raijin](https://raijin.gg/app/1637320/Dome_Keeper)) | dig between waves |
| **Peglin** (2021) | — | 400K in its first EA year ([Wikipedia](https://en.wikipedia.org/wiki/Peglin)); est. 382K ([Raijin](https://raijin.gg/app/1296610/Peglin)) | pachinko as combat |
| **Luck be a Landlord** (2021) | — | est. 275K ([Raijin](https://raijin.gg/app/1404850/Luck_be_a_Landlord)) | Northernlion's stream of it inspired Balatro ([Wikipedia](https://en.wikipedia.org/wiki/Balatro)) |
| **Backpack Hero** (2023) | $19.99 | Kickstarter $223,893 of $20,000 ([Wikipedia](https://en.wikipedia.org/wiki/Backpack_Hero)); est. 170K ([Raijin](https://raijin.gg/app/1970580/Backpack_Hero)); Backpack Battles (another game) 650K in its first month ([GameDiscoverCo](https://newsletter.gamediscover.co/p/how-backpack-battles-sold-650k-copies)) | the inventory is the game |
| **Shotgun King** (2022) | $9.99 | est. 145K, 91 % ([Raijin](https://raijin.gg/app/1972440/Shotgun_King_The_Final_Checkmate)); OpenCritic 77 ([OpenCritic](https://opencritic.com/game/14838/shotgun-king-the-final-checkmate)) | chess turned into a shooter |
| **Nova Drift** (2024 1.0) | $17.99 | est. 348K, 96 % of 14.7K ([Raijin](https://raijin.gg/app/858210/Nova_Drift)) | Asteroids with mods |
| **HoloCure** (2022) | free (fan game) | 50K downloads on its first day on itch.io ([Wikipedia](https://en.wikipedia.org/wiki/HoloCure_%E2%80%93_Save_the_Fans!)); 99 % of ≈ 32K Steam reviews ([PCGamesN](https://www.pcgamesn.com/holocure/update-new-characters)) | VTuber fandom |
| **Windowkill** (2024) | $4.99 | est. 156K, 96 % of 3.8K ([Raijin](https://raijin.gg/app/2726450/Windowkill)) | the desktop window itself shrinks and must be shot open |
| **Ball x Pit** (Oct 2025) | $14.99 ([Raijin](https://raijin.gg/app/2062430/BALL_x_PIT)) | 100K in 24 h, 300K in 5 days, 1 M Dec 2025, **2 M Aug 2026** ([Game Developer, Devolver](https://www.gamedeveloper.com/press-release/devolver-digital-s-ball-x-pit-s-final-free-update-the-naturalist-update-arrives-today-as-the-ball-hit-crosses-2-million-copies-sold)) | Devolver; "Hard-to-impossible to stop" ([Gamereactor](https://www.gamereactor.eu/?p=117913)) |
| **Megabonk** (Sept 2025, 3D) | $5.49 | 1 M in two weeks, peak 117,336 ([Game World Observer](https://gameworldobserver.com/2025/10/03/megabonk-is-a-new-indie-hit-on-steam-the-games-sales-have-surpassed-one-million-copies); [Notebookcheck](https://www.notebookcheck.net/Megabonk-beats-Hades-2-s-all-time-record-as-it-morphs-into-Steam-s-new-indie-sensation.1136297.0.html)) | solo dev; viral streamer buzz (same) |
| **CloverPit** (Sept 2025, 3D) | — | 500K in 8 days ([Game Developer](https://gamedeveloper.com/business/cloverpit-has-sold-500-000-units-in-eight-days)), 1 M by Nov 2025 ([Instant Gaming](https://news.instant-gaming.com/en/articles/16032-cloverpit-a-slot-machine-style-roguelite-has-surpassed-one-million-sales)) | a slot machine as the whole game |
| **Mewgenics** (Feb 2026, not pixel) | — | 1 M in a week, costs back in 3 h ([Game Informer](https://gameinformer.com/2026/02/17/mewgenics-hits-1-million-copies-sold); [Game World Observer](https://gameworldobserver.com/2026/02/11/mewgenics-recouped-its-development-costs-three-hours-after-release)) | Edmund McMillen's name; 400K wishlists before launch (same) |

### 1.2 Design: loop, run, meta, art, and what a web or phone version needs

Run lengths marked "est." are our estimates from play knowledge, not a source.

| Game | Core loop | Run · session | Meta between runs | Art and juice | Web / phone needs |
|---|---|---|---|---|---|
| Vampire Survivors | move only; weapons fire on their own; gems → a level-up pick of 3–4; chests of 1/3/5 items; most weapons evolve (maxed + a passive + a chest) ([Wikipedia](https://en.wikipedia.org/wiki/Vampire_Survivors)) | 15, 20 or 30 min by stage (same) | gold buys characters and power-ups; secret unlocks by deeds (same) | bought Castlevania-like pixel sprites (£1,100 of assets, same); the chest opening is a slot-machine reveal — Galante worked years on mobile slot machines ([Multiplayer.it](https://multiplayer.it/notizie/vampire-survivors-ha-salvato-il-suo-autore-dal-lavorare-ai-giochi-dazzardo-per-sistemi-mobile.html); [Mechanics of Magic](https://mechanicsofmagic.com/?p=31948)) | it **started in Phaser, a web engine** (Unity from 1.6); mobile free with optional ads, fast-tracked against clones (Wikipedia) |
| Brotato | auto-fire (manual aim optional); materials → a shop after every wave ([Wikipedia](https://en.wikipedia.org/wiki/Brotato)) | 20 waves: 20 s, +5 s a wave to 60 s, wave 20 is 90 s with 1–2 bosses ([Brotato wiki](https://brotato.wiki.spellsandguns.com/Waves)) ≈ 17.5 min of fighting + shops (est. 20–25 min) | characters unlocked by playing | **not pixel**: flat cartoon; screen full of numbers | free + premium on mobile from Mar 2023 (Wikipedia) |
| Halls of Torment | survivors in a Diablo frame; boss scrolls, a chest offers armour or jewellery; a well stores an item to buy for good | **30 min**, then a Lord boss; 6 stages, 11 characters ([Wikipedia](https://en.wikipedia.org/wiki/Halls_of_Torment)) | the well's items, characters | pre-rendered grainy 1990s isometric sprites, orb health (same) | mobile port Oct 2024 (Erabit) |
| 20 Minutes Till Dawn | aim and shoot by hand (mouse); level-up picks | 20 min (10 in the web demo) | characters, guns, runes | dark field, tiny bright sprites, a flashlight cone | the browser demo runs on CrazyGames, desktop only |
| Enter the Gungeon | twin-stick; the dodge roll is invulnerable; flip tables; Blanks clear bullets | 5 floors of ≈ 20 rooms, a boss each ([Wikipedia](https://en.wikipedia.org/wiki/Enter_the_Gungeon)); est. 30–60 min | the Breach hub: boss currency unlocks items into the pool, NPCs (same) | dense pixel bullet patterns, gun jokes | twin-stick needs two thumbs |
| Dead Cells | 2D melee platformer; procedural levels from hand-made pieces | est. 30–60 min | Cells spent only at a section's end (die before and lose them), blueprints carried out, runes open routes ([Wikipedia](https://en.wikipedia.org/wiki/Dead_Cells)) | 3D models rendered to pixel frames by a batch tool ([Game Developer via WN Hub](https://wnhub.io/news/art/item-13775); [80.lv](https://80.lv/articles/interview-with-the-developers-of-dead-cells)) | mobile 2019–2020; Netflix version |
| Binding of Isaac | twin-stick tears, bombs; a room at a time | est. 30–45 min | unlocks by deeds (items, characters) | gross-cute; hundreds of items whose effects stack visibly | the Flash demo plays on CrazyGames through Ruffle |
| Balatro | play poker hands; jokers add chips or mult; ante = 3 blinds; win at ante 8, endless to 39 ([Wikipedia](https://en.wikipedia.org/wiki/Balatro)) | est. 30–60 min | decks, stakes (difficulty tiers) | pixel + "retro VCR-style visuals"; scoring counted up chip by chip | LÖVE; mobile ports grossed $1 M in the first week (same); PEGI 18 → 12 after appeal: casino looks are a rating risk (same) |
| Archero | stand still to auto-fire, move to dodge — never both ([Game Developer](https://www.gamedeveloper.com/design/finding-the-fun-archero-part-1---gameplay)) | rooms "probably under a minute"; groups of 11 rooms: 4 fights, an angel, 4 fights, a boss (same) | gear, talents (IAP) | 3D-ish cartoon | one thumb, portrait; the phone benchmark |
| Soul Knight | twin-stick room clearing on mobile | rooms of 5–8 per level, a boss every few levels ([Techlife review](https://www.pressreader.com/australia/techlife-australia/20171225/285937452739701)) | coins kept after death buy buffs and unlocks ([TouchArcade](https://toucharcade.com/2017/03/10/soul-knight-review/)) | 16-bit pixel, guns galore | free with IAP; a lobby before the run |
| Ball x Pit | aim and fire balls that bounce off brick-enemies; balls fuse and evolve | stages "rarely longer than fifteen minutes" ([Nintendo World Report](https://www.nintendoworldreport.com/review/72918)) | a base you build between runs that yields permanent resources (same, [Mobalytics](https://mobalytics.gg/gamebase/reviews/ball-x-pit-review)) | "charm of the 16-bit era" (same) | aim + fire fits a thumb; Switch and mobile-friendly (est.) |
| Loop Hero | place tiles around a loop; the hero walks and fights on his own | est. 20–40 min a loop expedition | camp buildings from resources | 4-colour CGA-like pixel | mostly a mouse game |
| Shotgun King | each turn: move the king *or* shoot, then move to reload ([KeenGamer](https://www.keengamer.com/articles/reviews/pc-reviews/shotgun-king-the-final-checkmate-review/)) | est. 15–30 min | cards (curses and blessings for both sides) | 1-bit-ish pixel | turn-based: a perfect phone game |
| Peglin / Luck be a Landlord / CloverPit | pachinko, a slot machine, a slot machine — the toy *is* the combat | est. 20–40 min | relics, characters | pixel (Peglin), 3D (CloverPit) | casino looks: PEGI risk (Balatro's story) |
| Windowkill | twin-stick; the game window shrinks; shoot its edges to push it out | est. 15–30 min | upgrades | minimal | **needs the desktop window: impossible inside a portal iframe** |
| Dome Keeper | dig for resources on a timer, then defend the dome ([search snippets](https://www.gamingonlinux.com/2022/10/dome-keeper-is-a-nice-twist-on-base-tower-defense/)) | est. 30–60 min | keepers, domes, gadgets | soft pixel, strong silhouettes | mobile $9.99 |
| Megabonk | 3D survivors (VS in 3D) | est. 15–20 min | unlocks by challenges | low-poly | Steam PC |
| Moonlighter, Cult of the Lamb, Children of Morta, Rogue Legacy | a second loop outside the run: a shop, a cult, a family, an heir | est. 20–40 min | the second loop *is* the meta | detailed pixel (Moonlighter, Morta), cartoon (Lamb) | heavier content; not a first-minute game |

## 2. What the breakouts share

**The hook.** A known toy or genre plus one rule that turns it around, said in one sentence and **seen in the first
seconds**: VS (you only move — the bullet hell is yours), Balatro (poker, but jokers rewrite the score), Ball x Pit (Breakout
with level-ups and fusions), Shotgun King (chess from the king's side, with a shotgun), Peglin (pachinko), Windowkill (the
window), Loop Hero (you build the loop, not the hero). Theme is decoration in every case — Brotato is "VS with potatoes"
but its real difference is the wave-and-shop rhythm.

**The first minute.** No text and no menu between the store's Play and the first enemy in the shooters: Brotato's first
wave lasts **20 s** and ends in the shop ([Brotato wiki](https://brotato.wiki.spellsandguns.com/Waves)); Archero's rooms
are under a minute and end in a skill pick ([Game Developer](https://www.gamedeveloper.com/design/finding-the-fun-archero-part-1---gameplay));
VS gives the first level-up pick within the first minute (est., from play). **A fight in the first seconds, the first
choice by 0:20–0:30, the first "wow" (an evolution, a fusion, a big hand) within the first run.** The exceptions are
premium Steam games whose players have paid and will wait (Soul Knight's lobby, Dead Cells' prison) — not a model for a
portal, where the click is free and so is leaving.

**Run length.** 15–30 minutes, made of units of 20–90 s that end in a decision (a level-up, a shop, a room, a hand):
VS 15/20/30, Halls 30, Brotato ≈ 20, 20MTD 20 (10 on the web), Ball x Pit ≤ 15 per stage. A long run is fine *because*
it is chopped into short units — a portal's natural breaks (`money.session.breaks`) sit at the larger units: a boss, a
stage, the run's end.

**Meta.** Horizontal first: new characters, weapons and items that *play differently*, unlocked by deeds (VS's secret
unlocks, Isaac's items, Gungeon's Breach putting items into the pool) — then a little vertical (+stats). The 2025–2026 hits
add **a place that grows**: Ball x Pit's base, Cult of the Lamb's cult, Loop Hero's camp. Difficulty tiers after the
first win stretch the content (Balatro's stakes; see [market-depth §2](market-depth-2026-09.md#2-depth-that-keeps-players-10-minutes)
for the 33.5 % / 0.8 % numbers).

**Build-craft.** Every breakout has **a moment where two things become a third**: VS evolutions, Ball x Pit fusions,
Balatro jokers that multiply each other, Isaac's stacking tears. It is the clip players share and the reason for "one more
run". A list of +10 % upgrades never is.

**Juice.** Numbers everywhere, sounds on every hit (pitched, throttled), screens that fill with effects as the build grows
(the late-run chaos *is* the reward), slot-like reveals (VS's chest; Galante's slot-machine background: [Multiplayer.it](https://multiplayer.it/notizie/vampire-survivors-ha-salvato-il-suo-autore-dal-lavorare-ai-giochi-dazzardo-per-sistemi-mobile.html)),
scores counted up beat by beat (Balatro). Nuclear Throne's pistol: the camera kicks back a few pixels, a fixed shake that
decays fast ([infovore.org on "The Art of Screenshake"](https://infovore.org/?p=5275)).

**Art.** Low resolution, one style, strong silhouettes on a dark ground, bright projectiles: VS (bought Castlevania-like
sprites), Gungeon, Isaac, Halls (pre-rendered grain), Dead Cells (3D → pixel), Balatro (pixel + a VCR filter). Cheap to make
many of, readable when 300 things are on screen, and nostalgic for 25–40-year-olds. **Not required:** Brotato (flat
cartoon), Megabonk and CloverPit (low-poly 3D) broke out without it. What is required is coherence: the same pixel size
everywhere, one palette, light used for focus.

**Sound.** Music with a drive (VS's Castlevania pastiche), and hit sounds that stay pleasant at 50 a second — pitch
variation, a throttle, a limiter (our `createSfx` has all three).

**Price and spread.** $2.99–$5.49 for most action breakouts; streamers picked them because the screen reads at a glance
(a swarm, a number going up) and every run tells a different story. On CrazyGames the game is free and the "stream" is the
**cover, the 15-second preview and the first 30 seconds of play** — the same job, done by us.

**Mobile.** The phone versions earned big where they were free with opt-in ads or IAP: VS mobile free with optional ads
(Wikipedia), Brotato free + premium, Soul Knight free with IAP (100 M+ installs, est.), Archero and Survivor.io (IAP, one
thumb). That is CrazyGames' rewarded model: the player chooses the ad.

## 3. What fits the platform

**The frame.** A CrazyGames game is one `index.html` under 400 KB gzipped and 3 s to Play on a slow phone (`gp build`),
≈ 70 % of plays on phones, 13+, rewarded and midgame ads only at breaks, and Basic Launch scores playtime, D1 and
conversion against the category's peers ([game-design.md](../guides/game-design.md#the-three-basic-launch-metrics-design-for-them)).
Pixel art is the best fit for that budget: a 32 px sprite sheet of a whole bestiary is a few dozen KB (Candle Crypt's
uploads were 57–200 KB gzipped: [feedback-and-metrics §2.3](feedback-and-metrics-2026-10.md#23-what-each-launched-game-did-in-its-first-minute-and-after-the-part-the-metrics-see)).
The genre's own must-haves (`gp explain genre.roguelite`): meta that plays differently, a peak every few minutes, a revive,
a run seed and a daily, run choices.

**Each pattern, the block that serves it, and the gap:**

| Pattern (§2) | Blocks we have (`gp catalog blocks --genre roguelite`) | Gap → block request |
|---|---|---|
| One input; auto-fire or auto-aim on the phone | `MoveInput` (visible stick), `TwinStick` (touch: move stick + auto-aim), `aimAssist` | — |
| A fight in the first second, a first visit straight into play | `host.firstVisit`, `hints` (one at a time), `coachHand`, `gp qa`'s first-minute section | **first-choice timing in QA:** measure the time to the first fight and the first pick of 1 of 3 (via `RunChoices`) on a new save; warn after 30 s (rule) |
| A pick of 1 of 3 every 20–60 s, a reroll for an ad | `RunChoices` (weights, stacks, recent-draw memory, rerolls), `rewardedOffer` | — |
| A shop between waves (Brotato), prices that inflate, lock, sell back | `UpgradeShop` is a level shop for idle/launch games | **RunShop** (in-run shop: tiered offers by wave, escalating reroll, locks, sell-back, slots full) — already asked by Frankengun's survey (G/sim.ts:2792-2960) |
| Two things become a third (evolutions, fusions) | `collection` + `mountAlbum` can show a codex | **Recipes** (A maxed + B held → C offered; hidden until found, then shown in the codex; the balance model counts the first fusion's minute) — every breakout has it, every one of our roguelites wrote its own synergy table |
| Waves that escalate in a sawtooth with a peak every 3–5 min | `BossPatterns` (phases, telegraphs), `callouts`, `edgeArrow` | **WaveDirector** (spawn tables over time, a budget per second, the sawtooth, a breather after a boss, the first 30 s safe on a new save; feeds `balanceModel`) — no spawner exists in `@gp/core` |
| 300 enemies on a phone in Canvas 2D | `steer` (separation, slots), `Fx` pools, `DamageNumbers` (merged), `QualityLadder` (WebGL only) | **Horde kit** (a spatial hash for neighbours and hits, pooled entities, off-screen culling, a 2D quality ladder) — `steer`'s separation has no broad phase |
| Bosses, peaks, `happytime()` | `BossPatterns`, `callouts`, `HitArcs`, `edgeArrow` | — |
| Juice: numbers, shake, flash, count-up, slot-like reveal | `Fx`, `Camera` (shake, kick), `DamageNumbers`, `ScoreSequencer` (beats, count-up, land), `LootTable` (odds on screen, pity) | a **reveal** helper (a chest's items one by one, quickening, the best last) is small: `ScoreSequencer` + `LootTable` cover it in game code |
| Meta that plays differently; difficulty tiers after a win | `Roster`, `Tiers`, `PactTree` (heat/pacts), `achievements` (unlock by deed), `collection` (bestiary) | — |
| A place that grows between runs (Ball x Pit's base, Lamb's cult) | `Sites` / `mountSitesMap` are idle-only (`W_GENRE_BLOCK`) | **Camp**: buildings bought with run resources that add to the pool or the run (a Tiers + UpgradeShop pair today, in game code) — ask once a second game needs it |
| Daily run, seed, weekly rule, season | `newRunSeed`, `seedField`, `dailyRunSeed`, `dailyTable` (share card), `weeklyEvent`, `seasonPass` | — |
| A revive once a session, ×2 on the results | `rewardedOffer`, `mountResults` (the next run is the big button) | — |
| Pixel art: one grid, one palette, light | `gp art` with `technique: pixel`, `upscale`, `redraw`; `useFont(PIXEL)`; `@gp/art/light`; QA's magnified-image probe | **PixelView**: a low virtual resolution (e.g. 320×180 or 480×270) drawn at an integer scale with a letterbox fitted per screen, a pixel-snapped camera and sub-pixel motion, a palette lock (every sprite checked against the game's ramps) — each pixel game sizes its canvas by hand |
| Sound at 50 hits a second; music that builds | `createSfx` (pitch variation, throttle, limiter), `createSceneMusic` (layers by intensity) | — |
| Phone performance ("lags on the phone": the owner on Candle Crypt) | `gp qa` at 4× CPU, `gp build`'s load budget | the Horde kit above |

**CrazyGames' 13+ rules that bite this genre:** a chest is never sold and never a rewarded spin (`E_PAID_RANDOM`; odds shown:
`W_LOOT_ODDS`); no casino look (Balatro's PEGI 18 before the appeal — slot machines and poker chips are out); gore stays
pixel-small; a revive at most once a session; ads only at breaks (a boss, the run's end), never on the play screen.

**The block requests, in the AGENTS.md §5 format:**

```
Block request: mechanic (WaveDirector)
Game: any action roguelite (Candle Crypt, Swarm Smash, Frankengun, Kinetic Noir), brief: waves that escalate in a sawtooth
Needed: spawn tables over run time with a budget per second, a peak every N minutes, a breather after a boss, a safe first
  30 s on a new save; deterministic with host.rng; exports its curve to balanceModel()
Settings: waves: [{ at: 0, budget: 2, pool: [bat, skeleton] }, { at: 180, boss: lich }], breather: 8, firstRunSafe: 30
Why the existing blocks don't fit: BossPatterns is one boss's attacks; RunChoices is the player's pick; nothing spawns
```

```
Block request: mechanic (Recipes)
Game: any roguelite with a build, brief: two things become a third
Needed: rules "A at max + B held → C offered" checked at each pick; hidden until found, then in the codex; a first-fusion
  minute the balance model reports
Settings: recipes: [{ needs: [{ id: whip, level: 8 }, { id: hollow-heart }], gives: bloody-tear }]
Why the existing blocks don't fit: RunChoices offers cards by weight but knows no combinations; collection lists, doesn't combine
```

```
Block request: mechanic (RunShop)
Game: Frankengun (G/sim.ts:2792-2960), Swarm Smash, the ideas below, brief: a shop between waves
Needed: offers by tier inflating with the wave, an escalating reroll, locks kept across rerolls, sell-back at 50–75 %, slots full
Settings: runShop: { slots: 4, reroll: { base: 1, step: 1 }, sell: 0.6, tiers: [{ wave: 1, weights: [80, 20, 0] }] }
Why the existing blocks don't fit: UpgradeShop is a permanent level shop (idle/launch); RunChoices has no prices
```

```
Block request: rule (PixelView) + scene (Horde kit)
Game: Candle Crypt, Swarm Smash, Kinetic Noir, brief: crisp pixel art and 300 enemies on a phone
Needed: a virtual low resolution at an integer scale per screen with a letterbox, a pixel-snapped camera, a palette lock check;
  a spatial hash for neighbours and hits, pooled entities, culling, a Canvas 2D quality ladder
Settings: pixel: { width: 480, height: 270, palette: "games/<id>/palette.yaml" }, horde: { cell: 32, max: 400 }
Why the existing blocks don't fit: bake.ts sizes to device pixels, not a game grid; steer has no broad phase; QualityLadder is WebGL
```

## 4. Lessons from Candle Crypt's numbers

**The numbers (2026-10-20 – 21, 66 plays, category Action — `publisher/results.yaml`):** desktop 11/15 — playtime 13m33s → 5,
D1 18.18 % → 5, conversion 42.22 % → 1 (2 at 53.95 %); mobile 6/15 — 7m30s → 3, D1 0.00 % → 1, conversion 28.89 % → 2.
**66 plays is a tiny sample**: one returning player moves D1 by several points (estimate), so read the scores as a
direction until 500 plays. The first Basic Launch (1.0–1.4, 10-10) had the same shape: desktop playtime 4, D1 2,
conversion 1.

**Why playtime and D1 are high — what it shares with the breakouts:**
- **Long runs with few exits:** a 16-min session with 2 breaks (`money.session` in its game.yaml) — the run, not the menu,
  holds the player, as in VS and Halls (15–30 min).
- **Content that keeps arriving:** 6 candles, 46 weapons and shields, 25 monsters with mutations, 8 minibosses, 5 bosses,
  20 kinds of rooms (its listing), a route map with a choice of theme every block — the "new thing every 1–3 min" rule.
- **A second chance inside the run:** d20 death saves at 0 wax (its twist) keep a run alive past the moment others end.
- **A meta with a named next goal and a daily:** gems toward the next candle on the title, deeds that unlock weapons and
  spells, a journal and bestiary, the run seed and a daily (1.6.1) on the title row (1.8.0) — Gungeon's Breach and VS's
  deed unlocks, plus a daily the breakouts didn't need on Steam.

**Why conversion is low — what the breakouts do differently in minute 1:**
- **Dead time in the first 30 s.** The blind first look (`game9/games/candle-crypt/qa/first-look.md`, "keep playing" 3/5):
  "the 30 s show little fighting: one skirmish at 8 s, then empty corridors and an empty room labelled "Wave 1 – 3 left"".
  Brotato's first wave ends at 0:20 in a shop; Archero's first room ends in under a minute with a pick; VS never stops
  spawning. **Conversion counts players who stay a minute: 30 s of walking is where they go.**
- **The hook unexplained.** The dice and the armour roll are the difference (`concept.twist: armor-roll within 60`), but the
  first look asks "what is the dice panel… what decides the result? What omens do… what the gold counter buys". The HUD
  opens with `AC 13 · 12% MISS · D6 · INF · SHIFT DIVINE SMITE` — tabletop vocabulary before the first explained roll.
  Balatro shows *one* number moving at a time; VS's HUD is a bar and a timer.
- **Two hands on desktop.** WASD + mouse aim + 15-odd keys in `listing.controls`; VS, Archero and Brotato (auto-fire by default)
  need one. A desktop player who doesn't know WASD leaves; auto-aim (J) exists but isn't the default on desktop.
- **A gate before play.** The title's Play is the click CrazyGames allows; the breakouts on the web (10 Minutes Till Dawn's
  page) open on the field. `host.firstVisit` can boot a new save straight into the first room.
- **Mobile.** The owner's remarks — «Сделай управление с телефона получше. Там оно устаревшее» (2026-10-03, `gp lessons`)
  and "lags on the phone" ([feedback-and-metrics §2.2](feedback-and-metrics-2026-10.md#22-what-the-people-who-judged-them-said-summarized-verbatim-texts-are-in-publisherrecs-and-the-sheet)) — and D1 0 % / conversion 28.89 %
  on mobile: phone controls and frame rate first, then the same first-30-s fix.

**What to change (for Candle Crypt's next update, and the rule for every game in the vector):**
1. The first room spawns its first wave at 0:02, next to the candle; no corridor before the first fight on a new save.
2. The first pick of 1 of 3 (a feat) by 0:30 on a new save — level 2 cheap on the first run.
3. The HUD shows wax and the weapon at first; AC, miss %, the dice tray and omens appear when they first matter, with the
   twist's one line ("Shots roll against your armor") on the first roll — QA's twist check already times it.
4. Auto-aim on by default for the first run on desktop too (mouse aim takes over on the first click), so one hand plays.
5. `host.firstVisit` → straight into the run; the title after the first death.
6. Mobile: the stick drawn at the first frame, the 4× CPU frame rate in `gp qa` green on the busiest room.

`gp lessons` → `first-minute` now carries this (the 2026-10-22 score screen and the first-look remark as sources, and "no
dead time before the first fight and the first pick" in its look and fix).

## 5. Next-game ideas in this vector

**The rule from §2 and from our own record:** keep the pixel-roguelite frame that works for us (long runs, deep meta,
a daily, bosses, pixel art with light), and change **the verb** — never a theme on the survivors loop (Petri Panic's
rejection) or on the twin-stick room clearer (`taken.ts`: `twin-stick-roguelike`, Candle Crypt is ours). Each idea below
was searched on CrazyGames for its genre *and* its verb on 2026-10-23 (search snippets are not the catalogue: search again
before building). Not overlapping our next games: Kinetic Noir is a slasher, Swarm Smash a shmup with a ship backpack.

| # | Idea | One-line hook | Why it could break out | Closest on CrazyGames (and off it) |
|---|---|---|---|---|
| 1 | **Bomb-chain crawler** | "Your bombs set off each other: one blast that chains through the floor pays ten times." | a familiar toy (Bomberman) turned roguelite; the chain is the clip (Balatro's count-up in explosions); a grid reads at 360 px; the first blast at 0:02 | Bomber Friends (CG, a Bomberman without roguelite: [CrazyGames](https://www.crazygames.com/dk/game/bomber-friends)); off: Bombslinger (2018, [review](https://useapotion.com/2018/04/bombslinger-review)), Bomberlite (itch) |
| 2 | **Catch-back boomerang** | "Your only weapon comes back — be where it lands." | one verb with risk in it (unarmed while it flies), a catch is a beat of rhythm; mods that bend the path (split, fire trail, wider curve) are visible build-craft | Boomerang Chang (CG, a platformer, auto-return: [CrazyGames](https://www.crazygames.com/game/boomerang-chang)); off: Boomerbang, Caterang (itch) |
| 3 | **Gunless bullet-catcher** | "You have no gun: catch their shots and throw them back." | VS's reversal applied to bullet hell; the boss's own pattern is the only way to hurt it (`BossPatterns` exists); readable chaos for the cover | none found on CG; off: Bullet Yeeters (itch), DEFLECT (Steam, upcoming), Void Requiem (PICO-8) |
| 4 | **Chess-move dungeon deckbuilder** | "Every card is a chess move — a knight hop, a rook dash — and landing takes the monster." | card roguelites lead CG's roguelike tag (Tavern Rumble 11K, Cardlike 7.2K likes); turn-based = phones; enemies show intent (`Automa`); 2026's hits are deckbuilders (Slay the Spire 2, Vampire Crawlers) | Chessformer (CG puzzle, 4.8K votes), Tavern Rumble, Cardlike (CG); off: Shotgun King, Just Chessing Around |
| 5 | **Dig, then hold the shaft** | "Sixty seconds to dig, then the night: what you carried up is what you shoot." | a timer that makes greed a choice (Dome Keeper's 1 M players); digging is satisfying on touch; every wave is a natural break | none found on CG as a roguelite (mining idles only — our own Craft Pickaxe was rejected for quality); off: Dome Keeper |
| 6 | **Snake of heroes** | "Your tail is your party: the order you grow them decides who protects whom." | steering only (a swipe), auto-fighting heroes, adjacency sets = build-craft; snake.io traffic on CG | Snake Attack Shooter (CG, not a roguelite); off: **SNKRX** (the reference: snake of heroes, 2021), HeroTail: Survivors, Slitho — the riskiest card for originality |

**Dropped after the search:** a lighthouse beam defence (The Last Lighthouse and Beacon Under Siege are live on CG:
[CrazyGames](https://www.crazygames.com/game/beacon-under-siege)); slot-machine or poker roguelites (PEGI and E_PAID_RANDOM
risk; CloverPit and Cardlike hold the space); pinball/pachinko (the ball/brick pair is taken: ABLOCKALYPSE, Bounce Heroes);
a shrinking-window arena (Windowkill needs the OS window; inside an iframe it is a shrinking arena, and Candle Crypt's
light already shrinks); a time-moves-when-you-move shooter (the Time Shooter series on CG, by its title — not verified here).

### 5.1 The forecasts

`gp forecast --idea --channel crazygames … --mb 0.4 --load 1.5` (2026-10-23, the model calibrated on 32 review verdicts and
9 Basic Launches). Numbers as printed:

| # | Idea | Command (after `--channel crazygames`) | P(approval) | P(Full Launch) | Months 1–3 if launched (pess / median / opt) | **Expected** |
|---|---|---|---|---|---|---|
| 1 | Bomb-chain crawler | `--genre roguelite --session 16 --breaks 8 --rewarded revive,x2,reroll --return daily --meta 180 --pitch "A pixel bomb crawler: every floor is a grid of crates and monsters, your bombs set off each other, and a chain of blasts multiplies the loot; …"` | 32–39 % | 2–19 % | €4.0 / €625 / €17,087 | **€22** |
| 2 | Catch-back boomerang | `--genre roguelite --session 16 --breaks 6 --rewarded revive,x2,reroll --return daily --meta 180 --pitch "Your only weapon is a boomerang: throw it, then stand where it comes back — …"` | 32–39 % | 2–19 % | €3.7 / €527 / €17,087 | **€19** |
| 3 | Gunless bullet-catcher | `--genre roguelite --session 15 --breaks 5 --rewarded revive,x2,trial --return daily --meta 150 --pitch "You have no gun: hold to catch the enemy's shots in a ring around you and release to throw them back; …"` | 32–39 % | 2–19 % | €1.7 / €426 / €15,139 | **€15** |
| 4 | Chess-move deckbuilder | `--genre deckbuilder --session 15 --breaks 8 --rewarded revive,undo,reroll --return daily --meta 150 --pitch "Every card is a chess move: …"` | 32–39 % | 1–16 % | €4.0 / €568 / €16,019 | €17 |
| 5 | Dig, then hold | `--genre roguelite --session 16 --breaks 6 --rewarded revive,x2,boost --return daily --meta 180 --pitch "Dig for sixty seconds, then hold the shaft: …"` | 32–39 % | 2–19 % | €3.7 / €527 / €17,087 | €19 |
| 6 | Snake of heroes | `--genre roguelite --session 16 --breaks 6 --rewarded revive,x2,reroll --return daily --meta 180 --pitch "Your tail is your party: …"` | 32–39 % | 2–19 % | €3.7 / €527 / €17,087 | €19 |
| — | (contrast) a plain pixel survivors-like | `--genre survivors … --pitch "A pixel survivors-like: hordes of monsters, weapons that auto-attack, a level-up card every 30 seconds."` | **32–35 %** (the pitch matched the taken `survivors` concept) | 2–19 % | €3.7 / €527 / €17,087 | €18 |

**What the forecast says, and what it can't:**
- **It barely separates these ideas** (€15–22): they share the genre's benchmarks, a 15–16-min session and a daily, so the
  model's only differences are the natural breaks (8 > 6 > 5) and the offers. Its single lever for each is uniqueness 85+
  (+€0.4–0.6). Take the ranking from §2–§4, not from the euros.
- **Its P(Full Launch) is pulled toward 0 %** by nine stopped Basic Launches; Candle Crypt's desktop 11/15 is still
  `pending` in results.yaml. When it is recorded as a Full Launch, every roguelite forecast moves up: record it the day
  the portal answers.
- **What it doesn't see** is what decides the vector: conversion in the first minute (a fight at 0:02, a pick by 0:30), the
  cover's click rate, and whether the verb reads as new to a reviewer who knows Soul Knight and Vampire Survivors.

**The top 3, in order, and why:**
1. **Bomb-chain crawler** — the clearest "familiar toy + one rule" hook of the six, no roguelite version found on CG, the most
   natural breaks (a floor every 1.5–2 min), and the best first minute of any idea here (a bomb at 0:02, a chain by 0:10, a
   mod pick at the first stairs). Built on `Board` (a grid), `RunChoices` (mods), `BossPatterns` (a boss every 4 floors),
   `dailyRunSeed`, `Fx`/`Camera`/`ScoreSequencer` (the chain count-up), `@gp/art/light` (blasts light the floor). Needs
   WaveDirector or its own spawner, and Recipes for mod fusions (cross + pierce → a laser line).
2. **Catch-back boomerang** — the most original verb (nothing on CG), one thumb on the phone (tap to throw toward, the
   boomerang returns on its own path; catching is walking into it), risk in every throw. Built on `MoveInput`, `RunChoices`,
   `RunShop` (request) between waves, `BossPatterns`, `Roster` (throwers whose boomerangs fly differently).
3. **Gunless bullet-catcher** — the strongest *reversal* hook (VS's trick for bullet hell) and the platform already has the
   bullet machine (`BossPatterns`: fan, ring, spiral, aimed, wave). Risk: bullet hell is hard for web players — a rookie
   factor on the first run (`first-minute` lesson) and generous catch windows; fewest breaks, so a stage of 3 waves + a boss.

The chess-move deckbuilder (#4) is the best *market* fit (card roguelites lead the CG tag; 2026's top sellers are
deckbuilders) and the best phone fit, but our deckbuilder-like Velvet Domino Rogue was rejected for quality, and it is the farthest from what has worked for us (Candle Crypt's action) — make it after one action idea lands.

## 6. What I couldn't verify

- **Yandex Games:** the category pages didn't open (a header overflow from the proxy); no Yandex ranking of roguelites here.
- **Poki:** `poki.com/en/roguelike` serves the home page (150 games, no roguelite); the site search found only Survivor Z.
  Poki's catalogue may hide them behind tags we couldn't reach.
- **CrazyGames rankings:** likes are cumulative votes, not plays; the tag's "most popular" FAQ is the site's own order on
  the day. Candle Crypt's own page isn't public during Basic Launch.
- **Sales:** Raijin's estimates disagree with developer numbers (Raijin: VS peak 15,386; Wikipedia: > 70K in Feb 2022;
  Halls: 826K vs the developer's 1 M; CloverPit: 645K vs 1 M). We quote the developer where there is one.
- **Run lengths** marked "est." are ours; first-minute timings of VS are from play knowledge, not measured here.
- **Soul Knight's 100 M installs** is AppBrain's figure, not ChillyRoom's.
- The CrazyGames searches for each idea's verb are search snippets, not the catalogue: search again (`site:crazygames.com
  <verb> <theme>`) and add what you find to `packages/spec/src/taken.ts` before building.
