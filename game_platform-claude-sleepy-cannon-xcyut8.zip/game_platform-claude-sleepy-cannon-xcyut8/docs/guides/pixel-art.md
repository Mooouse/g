# Pixel art: what to draw, how to draw it, how the platform checks it

A pixel game is judged as pixel art. Players and portal reviewers spot an unfinished one in a second: mixed pixel sizes,
muddy colours, a silhouette that doesn't read, noise. This page lists the rules pixel artists work by, the numbers
from the games that broke out, and the platform's tools. The tools are `@gp/art/pixel` to draw sprites in code, `gp pixel`
to check them, and `gp art` with `technique: pixel` to have an image model paint them. The sources, about 100 links, are in
[pixel-art-craft-2026-10.md](../research/pixel-art-craft-2026-10.md). The genre, and why pixel roguelites are our vector, is in
[pixel-roguelites-2026-10.md](../research/pixel-roguelites-2026-10.md).

**The four rules that make a set look like one game.** One palette. One light. One outline rule. **One pixel size.**
Most of what follows comes from these four. Mixed pixel sizes (mixels) are the clearest sign of a game assembled from packs.

## 1. What to draw

**The view: a design resolution, scaled by a whole number.** Draw the frame into a low-resolution buffer, then scale it
up by a whole number with smoothing off. Common sizes:

| Size | Whole-number scales |
|---|---|
| 320×180 | ×4 = 720p, ×6 = 1080p, ×8 = 1440p |
| 384×216 | ×5 = 1080p |
| 480×270 | ×4 = 1080p |
| 640×360 | ×2, ×3, ×4, ×6 |

On a portal, pick the scale from the device pixels first. Then let the buffer grow with the screen's aspect, so there are
no black bars. `pixelViewport` and `PixelView` do this (§ 4).

**Sprite sizes.**

- Action games: the hero is about 1/8–1/12 of the view's height. That is 16–24 px at 180 tall, 24–32 px at 270.
- A close-camera puzzle or board game: about 1/5 of the view's height.
- References: Shovel Knight's tiles are 16×16, Stardew's sprites 16×16 (people 16×32, portraits 64×64), Dead Cells' characters about 50 px tall.
- Bigger sprites read far better on a phone. The owner asked Candle Crypt for "very strong pixel art with big sprites": 32 px heroes at a 270-tall view, or 24 px at 180.

**Proportions and faces.** For 16–32 px heroes:

- Draw them 2–3 heads tall.
- Make the eyes 1×2 or 2×2 pixels, with a 1-pixel highlight.
- Give each one prop that makes the silhouette: a weapon, a hat, a candle flame.
- Exaggerate what play needs: which way it faces, the danger (teeth, a glow) and its state. Celeste's hair turns from red to blue when the dash is spent, with a white flash for 0.12 s.
- Enemies differ from each other by silhouette first, size second.
- Bullets are 3–6 px with a 1-px dark rim.

**Background against foreground.**

- Keep the strongest contrast and saturation for the characters.
- Far layers have less contrast, less saturation and more light (atmospheric fade). Shovel Knight averages 5–6 parallax layers.
- The play layer must not share the hero's values.

**Tiles.**

- 16×16 is the classic size.
- Let clusters run off one edge and in at the other, so a laid tile shows no seam.
- A framed block (flagstones, bricks, crates) shows its grid on purpose.
- Ground, grass, sand and water must not show a grid: add a variant or two and a landmark cluster.
- An autotile blob set has 47 tiles (16 with rotation and mirroring).

**Effects.**

- A hit flash is the sprite as a white silhouette for a few frames (`pixelFlat`).
- Flashing replaces half transparency (Shovel Knight's invincibility).
- Particles are whole pixels or small clusters in palette colours, never soft sprites.
- A smear frame is held 1–2 frames.

**UI and type.** A pixel font at a whole scale (`@gp/art/type/pixel`) and 9-slice panels at the game's density
(`nineSlice`). The HUD goes into the same buffer or at a whole multiple of it. Never smooth vector text in the play view.

## 2. How to draw it

| Rule | Why | `gp pixel` |
|---|---|---|
| **Few colours per sprite.** NES sprites had 3 plus transparency; Shovel Knight 4–5 plus transparency, from the NES palette plus 4 colours of its own | Fewer colours read cleaner and tie the set together | P_COLORS, P_NEAR_COLORS |
| **Hue-shifted ramps.** 3–5 steps per material: the shadows turn cool (toward blue-violet), the lights warm (toward yellow), the saturation peaks mid-ramp, ≤ 20° of hue a step | A ramp that only darkens toward black looks dead and muddy | — (`pixelRamp` makes them) |
| **Values carry the form.** Look at the sprite in grey: the shape must still read | Colour is read after value | P_FLAT; the sheet's value column |
| **The silhouette reads in one colour** | At play size the player sees the outline first | the sheet's silhouette column; P_CONTRAST against the background |
| **One light** (upper left is the usual), the shadow following the form | Shading that darkens every edge and lightens the middle (pillow shading) looks flat and amateur | P_PILLOW, P_SET_LIGHT |
| **Outlines: 1 px, outside only.** Black, coloured, or selective (selout: darker on the shadow side, lighter on the lit side); no line where the object touches something | The outline must raise contrast; a line with random gaps looks like a mistake | P_OUTLINE_BROKEN, P_NO_OUTLINE, P_THICK_OUTLINE |
| **Pixel-perfect lines.** Each step joins the next at a corner, never through an L of three pixels; the steps keep a regular length (1-1, 2-1, 2-2 …) | Doubled corners make a line thick and jagged | P_DOUBLES, P_JAGGIES |
| **Clusters, not noise.** Areas of one colour at least 2 px wide; single pixels only for the few details that need them (an eye, a glint) | Lone pixels of a close shade read as dirt | P_NOISE, P_CLUSTERS |
| **No banding.** Two ramp colours running side by side in parallel staircases outline the shape twice | The eye sees stripes, not volume | (look) |
| **Anti-aliasing by hand, inside the sprite only.** Never into transparency: the background is unknown | A soft edge becomes a halo on every background | P_SOFT_EDGE |
| **Dithering only on large soft areas** (sky, fog, a big glow), in 2–3 levels (a 50 % checker) | On a small sprite it is noise | — (`pixelDither`) |
| **One pixel size** for every sprite, tile, effect and the HUD | Mixels | P_UPSCALED, P_SET_DENSITY |

## 3. Animation

- **Frames.**
  - Idle: 2–4 frames of breathing.
  - Run: 6–8 frames (Slynyrd's 8-frame cycle is 80 ms a pose; cut to 4, 160 ms a pose).
  - Attack: anticipation 2 frames held long (120–200 ms), a smear or contact frame (40–60 ms), the contact pose held (80–120 ms) while the hit lands, recovery 2–3 frames (≈ 200 ms).
  - Give each frame its own duration, not one fps for all. Strong key poses matter more than smoothness: too many in-betweens look sluggish.
- **Squash and stretch.** Celeste scales the sprite to (0.6, 1.4) on a jump and up to (1.6, 0.4) on a landing. It stays on the grid because the squash happens inside the low-resolution buffer: squash there, never on the upscaled screen.
- **Hit-stop.** Celeste freezes 0.05 s at a dash and 0.1 s on an explosion; 50–100 ms on a heavy hit.
- **Secondary motion.** Hair, capes and flames lag a frame behind the body. For 16–24 px sprites a bob of one whole pixel is enough.
- **No flicker.** Pixels move in clusters from frame to frame. A lone pixel that blinks on and off reads as noise (P_FLICKER). The feet stay on one line (P_FRAME_JUMP).

## 4. In code: `@gp/art/pixel`

A sprite is rows of letters with a key. This is the way Candle Crypt and Swarm Smash draw theirs.

**No image key? Draw the pixels themselves, on the grid — not an SVG.** A vector drawing scaled down to 16–48 px is
decided by the rasteriser, not by you. Its 1.3-px lines come out 1 or 2 px wide unevenly. An eye falls between two
pixels and blurs or vanishes. Every curve picks up doubled corners and stray pixels. Its edges come out half-transparent.
`gp pixel` flags all of these (P_SOFT_EDGE, P_DOUBLES, P_JAGGIES, P_NOISE). Pixel art is placed pixel by pixel:
1. Write each sprite as rows, in a few colours from `pixelRamp`.
2. Shade with `pixelShade` or by hand, and outline with `pixelOutline`.
3. Check with `gp pixel` and fix what it marks.
`gp art --provider svg` is for the painted, cartoon technique.

```ts
import { pixelArt, pixelRamp, pixelShade, pixelOutline, pixelCanvas, rotSprite, pixelRotations, PixelView } from '@gp/art/pixel';
import { drawPixelSprite } from '@gp/art/assets';

const flame = pixelRamp('#ffa033', 4);                    // hue-shifted: violet shadow → warm yellow light
const wick = pixelArt(['..f..', '.fff.', '.fwf.', '.www.', '.www.'], { f: flame[2], w: '#ecd3a0' });
const hero = pixelOutline(pixelShade(wick), { selout: true });   // volume from one light, a selective outline
const img = pixelCanvas(hero);                            // once, at load
const swords = pixelRotations(swordArt, 16);              // RotSprite at 16 angles, once — never rotate per frame
```

| Function | What it does |
|---|---|
| `pixelArt(rows, key)` · `pixelRows(art)` | rows of letters ↔ a sprite (`pixelRows` writes a cleaned or generated sprite back as code) |
| `pixelRamp(base, steps)` | a hue-shifted ramp (cool shadows, warm lights, saturation peaking mid-ramp) |
| `pixelShade(art, { light })` | each flat colour becomes its ramp, lit from one side (not pillow shading): draw the shapes flat, then shade, then fix by hand |
| `pixelOutline(art, { selout, corners, color })` | a 1-px outline outside the shape, plain or selective |
| `pixelDither(art, a, b, t)` | ordered (Bayer) dithering in 2–3 levels |
| `pixelCleanup(art)` · `pixelThinOutline(art)` | noise out and near-twin colours merged · a 2-px outline (a 2× scale) thinned to 1 px |
| `rotSprite(art, angle)` · `pixelRotations(art, n)` | rotation that keeps the pixels: 8× up with Scale2x, turned, back down by the most common pixel — no new colour, no blur |
| `pixelScale2x` · `pixelDownscale(art, k)` · `pixelTrim` · `pixelMirror` · `pixelStamp` | scaling and composing on the grid |
| `pixelFlat(art, '#fff')` · `pixelValues(art)` | the hit flash and the silhouette test · the value test in grey |
| `pixelCanvas(art, scale)` · `pixelToRgba` · `pixelFromRgba` | to a canvas or RGBA and back (with a palette, snapped to it) |
| `depixelize(rgba, { palette })` · `detectPixelPitch(rgba)` | a model's picture of big blocks (pseudo-pixels) back to real pixels |
| `lintPixelArt` · `lintPixelImage` · `lintPixelSet` · `lintPixelFrames` | the checks of § 6 |

**The view.** `PixelView` keeps the low-resolution buffer: the design resolution grown to the device's aspect, a
whole-number scale and smoothing off. `begin(camX, camY)` snaps the camera to whole art pixels, so nothing shimmers or
lands between pixels. `present()` puts the camera's fraction back as a shift of whole device pixels. That is the smooth
camera of pixel games, with no mixels: render one pixel more each way, then shift the upscaled image. The HUD goes on
its own layer, `hud()`, which doesn't shift.

```ts
const view = new PixelView([384, 216]);
view.resize(canvas.width, canvas.height);          // device px, on every resize
const g = view.begin(cam.x, cam.y);                // world coordinates in art px
drawPixelSprite(g, img, hero.x, hero.y, 1);
drawPixelText(view.hud(), `${coins}`, 4, 4, '#fff3d6');
view.present(ctx);
```

Positions stay floats in the game's logic. They are rounded when drawn into the buffer: `drawPixelSprite` does it.

## 5. Generated pixel art: `gp art` with `technique: pixel`

An image model paints pixel art as big blocks of its own pitch, slightly off-grid, with extra shades and blur. A
1024 px picture of 21.3 px blocks is a 48 px sprite. Cutting that picture into cells of the asked size cuts across the
blocks, and pixels come out doubled or lost.

So `gp art` reads the model's own grid instead (`depixelize`):

- It finds the block pitch from where the colour changes along each axis.
- It reads each block from its middle, snaps it to `art.palette` and cleans out noise.
- It keeps the sprite at the model's grid when that is within a quarter of the asked `size`; otherwise it shrinks the sprite by a whole factor.
- When no grid is found, it cuts cells as before.

On a test picture of 21.33 px blocks, the old cut gave 32×32 with doubled pixels. The new one gives the 21×21 sprite
back, 97 %+ of it pixel for pixel. The frames of an animation still use the cell cut, so their scale stays the same.

**The prompt.** Say what you want in sentences, not "no X" (Google's guidance for its image models). `PIXEL_STYLE` says it
for every request: one grid of equal square pixels, a small palette, 3–4 hue-shifted steps per material from one light at
the upper left, a 1-pixel outline outside, big silhouettes, clusters, dithering only on large soft areas. Per asset:

- Name the view ("side view", "front view": the default drifts to three-quarters).
- Name the role ("a 2D game sprite of …").
- One pose per request, with the first sprite as the reference (`frames` does it).
- Expect "32×32" to be ignored: the grid is fixed afterwards.

Blend words ("smooth shading", "gradient", "soft light", "3D render") are warned about (`W_ART_PIXEL_BLEND`): snapped to
the palette, a blend becomes bands and noise. Check every generated sprite with `gp pixel` and remake the ones it flags
(`gp art --only <id>`).

## 6. The checks: `gp pixel`

`gp pixel <id>` checks every sprite the game declares:

- the PNGs in `assets/` of a game with `art.technique: pixel`;
- game.yaml `pixel.sprites`: modules of string-grid sprites (`{ frames, pal }`, `{ rows, key }` or `PixelArt` exports), PNGs or folders.

Files can also be given on the command line: `gp pixel <id> sprites.ts assets-src/tiles`. The command writes two files:

- **`qa/pixel.md`**: every finding with its fix, then the set as one game and each animation (a module's `frames`; PNGs named `<id>.png`, `<id>-1.png` … as gp art writes them).
- **`qa/pixel-sheet.png`**: each sprite at 1× and 4× with the findings marked in red, its silhouette and its values in grey. These are the two tests artists make.

`--fix` writes cleaned copies to `qa/pixel-fixed/` (noise out, near-twin colours merged, a 2-px outline thinned) to compare
before you take them. `--check` exits 1 on a warning. `pixel.background` in game.yaml (or `--background`) gives the colour the
sprites stand on, for the contrast check. A pixel game's `gp review` brief carries the findings.

| Code | What it finds |
|---|---|
| P_COLORS · P_NEAR_COLORS | more than 16 colours in a sprite up to 64 px (32 above); pairs a player can't tell apart (OKLab distance < 0.025) |
| P_NOISE · P_CLUSTERS | lone pixels of a close shade inside an area; > 20 % of the fill touching no pixel of its colour (from 24 px) |
| P_OUTLINE_BROKEN · P_NO_OUTLINE · P_THICK_OUTLINE | an outline on 40–72 % of the edge; none; a 2-px one (what a 2× scale leaves) |
| P_DOUBLES · P_JAGGIES | L-steps on a 1-px line; one-pixel bumps on a smooth stretch of the silhouette (both from 24 px: at 16 px every pixel is a decision) |
| P_FLAT · P_PILLOW · P_CONTRAST | the colours span < 30 % of lightness; lighter toward the middle with no light direction; the edge as light as the background |
| P_UPSCALED · P_SOFT_EDGE · P_NOT_PIXELS | every pixel a k×k block (mixels); half-transparent pixels; > 255 colours (a painted picture) |
| P_SEAM · P_TILE_GRID | a tile whose edges don't meet when laid; a framed block (right for flagstones, wrong for grass) |
| P_SET_LIGHT · P_SET_DENSITY · P_SET_OUTLINE | sprites lit from another side than the set; at another pixel size; with and without outlines mixed |
| P_FLICKER · P_FRAME_JUMP | pixels blinking alone between frames; a body jumping > 2.5 px between frames |

**Measured on Candle Crypt (2026-10-24): its 307 sprites (sprites.ts) and their 32 px upscales (sprites32.ts).** These are the platform's thresholds tuned on a hand-made set
that took 3rd place at a contest. The 16 px originals come out almost clean. What it flags is real:

- a 32 px upscale left with 2-px outlines everywhere — the reason the docs say a scaler doesn't make strong pixel art (§ 5 of art.md);
- a door left at 2× (mixels);
- near-twin silver and bone shades;
- 6 sprites lit from another side than the rest.

The thresholds marked "ours" in the research are starting values. Tell the platform when one is wrong on your game.
