# Publishing on Playgama (one upload, 20+ platforms)

Playgama takes an HTML5 game once and distributes it, non-exclusively, to its own portal and partner platforms: YouTube
Playables, MSN, Yandex Games, Facebook, Discord, Telegram, Xiaomi, Huawei, Samsung, GameSnacks, Y8, Lagged and more —
you choose the platforms in the cabinet. Revenue share (2026): 70 % of net up to $1,000, 80 % above, 90 % above $3,000.
CrazyGames does not require exclusivity, so a CrazyGames game can go to Playgama as it is.

## Build

```bash
gp build <game> --target playgama        # in a game repository: scripts/gp.sh build --target playgama
```

The same game, with Playgama Bridge instead of the CrazyGames SDK, in `games/<id>/upload-playgama/`:
`<id>-playgama.zip` (index.html + `playgama-bridge-config.json`) — the file to upload. Only portal games (`channel: crazygames`).

What the platform does for you through Bridge (`PlaygamaPortal` in packages/core/src/portal.ts):

| Game (host) | Bridge |
|---|---|
| loading done (first screen ready) | `platform.sendMessage('game_ready')` — dismisses the platform's loader |
| `host.gameplay(true/false)` | `gameplay_started` / `gameplay_stopped` |
| `host.adBreak()` | `advertisement.showInterstitial()` (Bridge's own cooldown, 60 s by default, applies too) |
| `host.rewarded()` | `showRewarded()` — the reward only on `rewarded` then `closed`; `rewardedAvailable` is false on platforms without rewarded ads |
| the portal's mute | `audio_state_changed` → `host.portalMuted`, the host's sound off |
| the platform pauses the game | `pause_state_changed` → the host's `hidden` pause (your pause screen) |
| the player's language | `platform.language` → the game's language when it has it |
| saves (`host.load`/`host.save`, the language choice) | Bridge Storage (cloud saves where the platform has them): all keys loaded in one `storage.get` at start, every save written through with `storage.set` — the checklist forbids localStorage. A game that writes localStorage itself must use `host.save` instead |

The Bridge script loads from `https://bridge.playgama.com/v2/stable/playgama-bridge.js`, so only the current platform's
adapter is downloaded. Outside a platform Bridge runs in its mock mode: the game plays, ads return their defaults.

Interstitials: Playgama's certification fails a build whose interstitial never fires in a short session, so a
Playgama build shows one at every natural break from the first, at most one a minute (`PLAYGAMA_AD_POLICY` in
packages/cli/src/vite-plugin.ts; the CrazyGames build keeps its channel's limits).

Before the owner certifies a build in Playgama's QA Tool, run `gp playgama-check <game>`: the Playgama build with a
recording fake Bridge, the demo bot playing — the Bridge first, storage in one call, game_ready, gameplay events, an
interstitial at a break within 90 s, a rewarded ad closed early giving nothing, pause and audio events, a platform pause held as long as Bridge keeps it, an ad the Bridge defers after `loading`
freeing the game, the platform's language taken at the first start (below), no
localStorage, no external hosts, and what the QA Tool's recorder films. Its report is games/<id>/qa/playgama-check.md.
It reads game_ready and the sign-in button once the game's `start()` has finished (`host.isLoaded`, ≤ 30 s), not when
`host.qa()` is registered: a start() that awaits its pictures after `host.qa()` is fine.

**What the QA Tool sees.** Its recorder films and screenshots the page's *first `<canvas>*` (Bridge:
`document.querySelector('canvas')`), not the page — the DOM in `#ui` (menus, the result screen, an ad button and its
"no reward" message) isn't in it. Candle Crypt 1.5 gave nothing for an ad closed early, and still failed "Reward was
granted despite the ad being closed before completion": the QA Tool saw the dungeon before the ad and the same dungeon
after. So the Playgama portal installs a mirror on the QA Tool's first recorder message (`@gp/core` recorder.ts): a canvas
first in the document that copies the game's canvases each frame and paints the DOM over them (boxes, borders, text,
images; no z-index, gradients beyond the first colour, shadows or pseudo-elements). Nothing changes for players: no
recorder message, no mirror. `gp playgama-check` saves what it films in `qa/playgama-recorder.png` — look at it: what
isn't there, the QA Tool doesn't see (an inline `<svg>` or a CSS-only shape, for example).

**Sign-in (the QA Tool's Authorization step).** Playgama has player accounts; its QA Tool warns "No sign-in option
found" when a game offers none, and "Login button visible for an authorized user" when it keeps offering it after the
player signed in — the certification passes, but the game can't be published until both are clear (2026-10-10). The
platform does it: on a Playgama build, where `bridge.player.isAuthorizationSupported`, the host puts a small "Sign in"
(10 languages) in the bottom-left corner of the menus, hidden while a run plays and gone once signed in; signing in
reloads the game so its saves come from the account. It never lies on the game's own DOM controls: when it would, it
moves to the next free corner (bottom right, top left, top right), and with none free it hides on that screen
(2026-10-10: it covered Rivet Clash's "Build & fight" at 360×800). Buttons drawn on a canvas it can't see — such a game
places its own. A game that wants it elsewhere places its own —
`signInButton({ host, className })` from `@gp/core` (data-gp="sign-in"), and the corner one stays away. Launching never
requires it (the checklist's item 20). `host.account` says `{ supported, authorized, name }`, `host.signIn()` starts it.
`gp playgama-check` checks it: offered on the menu, on none of the game's controls at 360×800 and 1280×720, gone after
signing in.

## Upload

developer.playgama.com → create the game → upload the zip, the covers (`gp covers`: the form's three slots take exactly `cover-1920x1080.png`,
`cover-1080x1920.png` and `cover-800x800.png` — all three are required) and the description (listing.md from
`gp submission`) → Playgama tests it (≈ 24 h) → choose the platforms. Playgama also has an MCP server for the cabinet
(`https://developer.playgama.com/api/mcp`): the owner connects it to an agent session to upload builds and covers by API.
Never put the owner's login in a game repository or a script.

## Not yet

- No `gp qa` against a fake Bridge (the CrazyGames build is what `gp qa` plays; the adapter has unit tests and was
  checked in a browser against a fake Bridge: game_ready, gameplay events, language, pause).
- Bridge's IAP, leaderboards, banners: not wired. Analytics: the Bridge has no custom-event API; its telemetry reads the
  `gameplay_started` / `gameplay_stopped` the host sends. The host's own first-minute funnel stays on its event bus, and a
  paid sandbox test before CrazyGames is the owner's decision ([first-minute.md → the funnel](first-minute.md#2-the-funnel-funnel-events)).
- `playgama-bridge-config.json` is empty (Bridge's defaults); its config editor adds placements and per-platform settings.

## Ads that never end and stale pauses (2026-10-22)
The Bridge can defer or skip an interstitial after `loading` (its minimum delay between ads, an ad blocker, no fill)
and then send neither `closed` nor `failed`; and `pause_state_changed: true` can stay on while the page is plainly
visible. Candle Crypt froze at the end of a floor until a reload. The Playgama adapter (`PlaygamaPortal` in
`packages/core/src/portal.ts`) now gives an ad 5 s to start, 10 s from `loading` to `opened` and 45 s in all. (It also let a
platform pause go after 3 s; that failed Playgama's QA Tool — "Platform pause signal ignored", 2026-10-24 — and was removed:
a Bridge pause now holds until Bridge lifts it.) `gp playgama-check` checks both. Every
Playgama build made before this platform commit can freeze the same way: rebuild its zip (`gp build --target playgama`).

## The cross-promo interstitial and the stutter after ads (2026-10-23)
Playgama's sandbox shows two interstitials: a timed one that closes itself (≈ 15 s) and a full-screen cross-promo for
another game that stays until the player taps its Close. The adapter waits for an ad Bridge still reports as `opened`
(`interstitialState` / `rewardedState`), however long: the game
must not run behind an ad. Each interstitial also brings Playgama's header bidding (50+ user-sync frames) and the game
stutters after it — the first one for ≈ 25 s at ≈ 8 fps in a headless measurement, later ones ≈ 1 s. So Playgama builds
space interstitials 180 s apart: `PLAYGAMA_AD_POLICY.minIntervalSec` and `minimumDelayBetweenInterstitial` in
playgama-bridge-config.json (Bridge's default is 60 s). The stutter itself is Playgama's ad stack: the owner reports it.

## A platform pause is an ad's, not the player leaving (2026-10-23)
Bridge sends `pause_state_changed: true` with every interstitial and rewarded ad it shows, and `false` when it closes.
The host used to turn it into the pause reason `'hidden'` (the tab hidden), and games answer `'hidden'` with their pause
menu: after every ad the game stood on its menu until the player tapped Resume — a "freeze" at each ad. Now a platform
pause is the reason `'ad'` (held apart from our own ad's hold, so neither clears the other): the game keeps still under
the ad and goes on by itself after it. Only `document.hidden` is `'hidden'`. `gp playgama-check` checks it.

## A system overlay and the platform's language (2026-10-24)
Playgama's QA Tool opens a system overlay and checks the game stands still the whole time: a Bridge pause holds until
`pause_state_changed: false` — never released by a timer (a game's own loop must not wake itself under it either). The QA
Tool also sets the platform's language: Bridge's SDK loads after the host is made, so when it comes and the player hasn't
picked a language in this game, the host switches to `bridge.platform.language` (not saved: only the player's own pick is).
List in Playgama's form only the languages the game has.

## The game is held only once an ad is on screen (2026-10-24)
A tester on the Candle Crypt sandbox: «Choose a feat» dead and silent for 5–7 s, «ROOM CLEARED» frozen for 2–3 s, with
no ad shown. The host held the game (paused, muted, its UI inert) from the ad's request, and Bridge loads for seconds and
often finds no fill (`loading` → `failed` in ≈ 4 s). Now the Playgama provider is `startsOnOpen`: the AdManager holds the
game from Bridge's `opened`; a load that ends in no fill never touched the player. A game's own wrapper must not hold its
loop around `host.adBreak()` either (the host pauses it when the ad opens). playgama-bridge-config.json preloads an
interstitial on start (`preloadOnStart`/`placementFallback: level_completed`), so a filled ad opens in ≈ 0.5 s.
`gp playgama-check`: an interstitial that loads 4 s and finds no fill must leave the game not paused and nothing inert.

## A rewarded ad's pause that Bridge never lifts (2026-10-25)

The live sandbox froze Candle Crypt 1.8.9 for good after a rewarded "Relight". The Playgama chat recorded the Bridge
events twice:

```
rewarded: loading → opened + pause_state_changed true → rewarded → closed
```

No `pause_state_changed false` ever came; the interstitial does send it. Since 2026-10-24 a Bridge pause holds until Bridge
lifts it, for the QA Tool's system overlay, so the game stood still behind its HUD. The adapter now remembers a pause that
began while one of our ads was up and ends it with the ad: when the ad is closed, fails or times out. Bridge's own late
false is not a second resume. A pause with no ad of ours, the overlay, still holds until Bridge lifts it.

`gp playgama-check` plays the sandbox's flow: pause on open, no false after close. The game must go on after the ad. On
Candle Crypt the check fails on the old adapter ("still paused (ad)") and passes on the new one.
