# Hardening the ТЗ: `gp brief`

The owner (Жаслан, 2026-10-23): «На платформе мне нужен функционал дописывания ТЗ. Условно есть ТЗ. Задай вопрос о
критике ТЗ. Ответь на него. Так до тех пор пока все вопросы и споры не будут закрыты. Это должен быть базовый функционал».

A ТЗ (the owner's brief, a GDD) is cheapest to fix before any code exists. Every game we built from a brief met its
problems later: at CrazyGames' review ("the overall quality", "quite close to existing titles") or at Basic Launch (a
3–6 minute session, no reason to come back). `gp brief` is the step that hardens the ТЗ first. A **critic** agent, one
who did not write the ТЗ and will not build the game, asks pointed questions. The game's **maker** answers each one.
The critic closes or disputes each answer, and the loop goes on until no question or dispute is open.

It follows the same pattern as `gp review` and `gp design`: a brief for an agent, the file it writes, and `--check`.
Here the loop has two agents, and `gp brief` tells you whose turn it is.

## When

The brief is **phase 0** of the design lifecycle ([gdlc.md](gdlc.md)). `gp stage` reads the record, and `gp submission` refuses to complete while a game that has a `docs/gdd.md` still has the loop open.

At **step 1** of AGENTS.md, as soon as the owner gives a ТЗ, and before anything is built on it. In a game's own
repository the ТЗ lives in `docs/gdd.md` (the game chats save it there). `gp init` can make the repository, but the
mechanic waits for the review. Run it again when the owner sends a new version of the ТЗ.

## The loop

```
gp brief docs/gdd.md          → round 1: qa/brief-critic.md          → the critic writes questions into docs/gdd-review.md
gp brief docs/gdd.md          → qa/brief-answer.md                    → the maker answers, edits docs/gdd.md in place
gp brief docs/gdd.md          → round 2: qa/brief-critic.md          → the critic closes or disputes each answer, asks more or not
…                                                                     (5 rounds at most: --cap)
gp brief docs/gdd.md          → done: qa/brief-owner.md              → the owner's questions, in Russian: send them to him
gp brief docs/gdd.md --check  → ✓
```

In a game's repository: `scripts/gp.sh brief docs/gdd.md` (or `scripts/gp.sh brief`, which finds `docs/gdd.md`). From
the platform: `npm run gp -- brief <path>`, where the path is the ТЗ file or a game.

Each run reads the record and works out the turn:

| Turn | When | The brief |
|---|---|---|
| the critic, round 1 | no record yet | `qa/brief-critic.md`: the task, the categories, the format, and the platform's facts |
| the maker | an item is `open` or `disputed`, an owner item lacks its options, or a ТЗ line doesn't hold | `qa/brief-answer.md`: the items with their history, the three kinds of answer, what to fix first |
| the critic, round N+1 | every item is answered, and the critic hasn't ruled on the answers or hasn't said «no further questions» | the answers to rule on, the owner items to check, what is settled |
| done | nothing is open, disputed or unruled, and the critic's latest round said «no further questions»; or the critic has had its last round (the cap) | `qa/brief-owner.md`: the owner's questions in Russian |

The critic's own problems (a question without a ground, say) go back to it first, in its round. A round is one critic
turn and one maker turn. The record's header keeps the round and the cap (`Round: 2 of 5`), and `gp brief` sets the
round when it starts a critic turn.

**At the cap**, `gp brief` hands any dispute the critic raised in its last round to the owner. It sets the item's heading
to `owner`, adds an `Escalated (r5): …` turn that states both sides, and writes a log line. The maker then adds the
options, a recommendation and the question in Russian. Answers the critic never ruled on stay `answered`.

**The critic ends the loop** by writing `- rN critic: no further questions` under `## Log`, or `вопросов больше нет`.
Writing that line in the same round as new questions counts as a problem.

## What the critic asks

Each question is filed under one category. Round 1 looks at every category, and a category with nothing to ask is fine:

| Category | What it asks |
|---|---|
| `scope` | what to cut for a first version: the vertical slice vs. the full game — counted (screens, kinds, levels, scenes) |
| `contradiction` | two rules, numbers or promises that clash: a story-heavy opening and a 1-click first minute |
| `feasibility` | can the platform build it: one `index.html`, the size budget, phones and touch, the engines and blocks, the known gaps |
| `portal` | CrazyGames' rules and what it rejected our games for: 13+, the first visit in gameplay, ten languages, music, drawn icons |
| `money` | the session, the natural breaks, the rewarded offers, the reason to come back tomorrow, a meta past the first session |
| `originality` | what the player does that the closest games don't, and the reference names, which never reach the title, texts, art or listing |
| `ambiguity` | numbers missing, terms never defined, lists ending in "etc." |
| `first-30s` | clicks to control, words before the first action, the first reward, no loss in 12 s |
| `first-10min` | where a new player first stops and what pulls them on (W_SESSION_SHORT) |

**Every question is grounded.** A `Ground:` line under it names the platform fact the question rests on, and `--check`
refuses a ground that names none. The critic's brief lists these facts:

- the channel's rules and its size and load budget (400 KB gzipped ≈ 3 s on CrazyGames);
- the first-minute and session rules;
- what CrazyGames said about our games, and the Basic Launch scores (`publisher/results.yaml`);
- the forecast model's rows (`MONEY_TABLE`);
- the genre's must-haves and the blocks that fit it (`packages/spec/src/genres.ts`; the genre comes from game.yaml
  `money.genre`, `--genre`, or the ТЗ's own words, Russian or English);
- the engines, physics and AGENTS.md's known gaps;
- the names the ТЗ borrows: protected names and brands, a hit's signature words, taken concepts, and the games it points
  at ("в духе X", "like X", a "Референсы:" list);
- every lesson in `gp lessons`.

At most 12 new questions a round. Only questions that would change the build or the review count, never nits about
wording.

## What the maker answers

Each answer takes one of three kinds:

- **`keep`**: the ТЗ stands as written. The reason says where the ТЗ already covers it, or why the risk is accepted.
- **`change`**: edit the ТЗ first, in place and in its own language. Then quote the new text exactly:
  `ТЗ: §6 — "Первая версия: 3 этажа, 1 босс"`. For a cut, write `ТЗ: §6 — removed "полная озвучка диалогов"`.
- **`owner`**: a product decision that only the owner can make (what the game is, its audience, cutting a feature he
  named, the title or brand, money, a date). It needs `Options:` with 2–3 choices, `Recommend:` and `Владельцу:` (the
  question as you would send it), all in Russian. The owner said «Не спрашивай — делай» (2026-10-03), so you decide
  everything else.

A decision the build needs (a number, a cut, a rule) is a **change**, not a keep, because the build reads the ТЗ and not
the record.

**The ТЗ is edited in place**, not copied to a `gdd.final.md`. Git keeps the owner's text and the record says what
changed and why. Every later step reads `docs/gdd.md`, and a second "final" file would drift from the one people read.
`--check` verifies each item's last `ТЗ:` line in two ways:

- the quote must be in the ТЗ now (for a removal, it must be gone);
- the quote must be new since the critic's copy of that round, `qa/brief/gdd-r<N>.md` (for a removal, the text must
  have been there).

If a later item rewrote the text, mark the earlier line `(superseded by Q7)`.

**When the owner answers**, add `Owner (2026-10-24): <his words>` under the item and set its heading to `closed`. If his
answer needs a change, edit the ТЗ and add a `ТЗ:` line.

## The record: `docs/gdd-review.md`

The record is one file next to the ТЗ, named `<name>-review.md`. Commit it. Every item has an id, a category, the
question, the answers, a state, and the change to the ТЗ when there was one:

```markdown
# Glass District — ТЗ review

ТЗ: docs/gdd.md · Round: 2 of 5

## Q1 · scope · closed
Q (r1): §6 puts 12 floors, 40 implants and 8 bosses into the first version, and §8 says the slice is "the first floor". Which is it?
Ground: lesson `feel-over-features`; W_SCOPE at more than 15 screens
A (r1, change): The first submission is three floors with one boss, 6 enemy kinds and 12 implants; the rest goes to the updates.
ТЗ: §6 — "Первая версия: 3 этажа, 12 имплантов, 1 босс (на 3-м этаже), 6 видов врагов, одна концовка"
Close (r2): §6 now names the first version; three floors and one boss fit the scope rule.

## Q5 · money · owner
Q (r1): §7 says no daily rewards and the only offer is a revive. What brings a player back tomorrow?
Ground: `cg.full.returnNone`; lesson `daily-visible`
A (r1, owner): The owner wrote "no daily rewards" by name: his call.
Options: 1) без ежедневного; 2) ежедневный контракт: этаж дня с таблицей; 3) недельное событие
Recommend: 2) — причина вернуться завтра (D1), сюжет не ломается
Владельцу: Можно добавить ежедневный контракт — один этаж дня с таблицей результатов? Рекомендую: да.

## Log

- r1 critic: 9 new questions
- r1 maker: 7 change, 2 owner
- r2 critic: 1 new question, 6 closed, 1 disputed — further questions
```

- **States:** `open` (asked), `answered` (keep or change), `disputed`, `closed` (by the critic, or by the owner's word),
  `owner`. The heading's state must match the item's history. `--check` names the right state when it doesn't.
- **Turns:** `Q (rN)`, `Dispute (rN)` and `Close (rN)` are the critic's. `A (rN, keep|change|owner)` is the maker's.
  `Owner (date)` is the owner's word, and `Escalated (rN)` is written by gp brief. Each turn can carry lines under it:
  `Ground:` after a question; `ТЗ:` after a change; `Options:`, `Recommend:` and `Владельцу:` after an owner answer. A
  line that is not an entry belongs to the entry before it.
- **Labels:** labels in bold or in Russian work too (`Вопрос`, `Ответ`, `Спор`). HTML comments are skipped.

## `--check`

`gp brief <ТЗ> --check` exits 1 in any of these cases:

- the record is missing or malformed;
- an item is `open` or `disputed`;
- the loop isn't done: answers are still unruled, or the critic hasn't said «no further questions»;
- the ТЗ doesn't say what an answer says it now says.

It lists the owner's questions to put to him. `--json` prints the parsed record and the turn. `--critic` or `--answer`
writes that brief whatever the turn.

The briefs go to the game's `qa/` (`gp qa` keeps them), else to `qa/` beside the ТЗ, or to `--out <dir>`. Code:
`packages/cli/src/brief.ts`; tests: `packages/cli/test/brief.test.ts`.
