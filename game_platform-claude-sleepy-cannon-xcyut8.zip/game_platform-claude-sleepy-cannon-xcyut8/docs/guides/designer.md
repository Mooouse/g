# The game designer: `gp design`

`gp review` judges a version: pass or fail, `quality.md` with `[blocking]` and `[nice]`. `gp review --first-look` asks a
stranger what the first 30 s say. Neither invents. Our games keep stopping at CrazyGames' Basic Launch a point or two
short of Full Launch (9 of 15 on a device class: Garage Evolution 2026-10-20 desktop 8/15, mobile 6/15; Hang the Moon
5/15 and 6/15 — `publisher/results.yaml`). The owner had good results giving Gemini a gameplay video and asking it, as a
game designer, for improvements. `gp design` makes that a step of the platform: a designer agent — one who did not make
the game — plays it and proposes **what to add or change so the next version scores more** on the three metrics
(average playtime, D1 retention, the 1-minute conversion; desktop and phone), ranked by expected effect and effort, each
built from the platform's blocks where a block exists.

## When to run it

In the design lifecycle ([gdlc.md](gdlc.md)) a `gp design` round is the review of **phase 4, content and meta**: before the first release candidate too, once the slice's gate is met. It is also the next step of **phase 6, live**, on the weakest metric of the score screen. `gp stage <id>` says when a round is due, for example when design.md is older than the scores.

- **Before a new version**: an update, or a game resubmitted "as a new game including significant improvements" — three
  of four resubmissions after a stop were rejected for looking like the build before ([publishing-crazygames.md](publishing-crazygames.md)).
- **After a Basic Launch stop**, with the score screen recorded in `publisher/results.yaml` (the brief reads it: the
  weakest metric per device is where a point is cheapest).
- **After an owner's playtest**: put the remarks in `gp lessons` (packages/cli/src/lessons.ts) first, then run it.

For an update or a resubmission it comes **before the quality review** (AGENTS.md step 9): design, build what the Top 3
say, then `gp qa`, then `gp review`. Not in the last pass before a first submission: that pass is feel only, no new systems.

## What it makes

```
npm run gp -- design <id>                 # a game in its own repository: scripts/gp.sh design
npm run gp -- design <id> --serve         # …and keep a frozen build up for the designer to play on (its URL in the brief)
```

| File | What |
|---|---|
| `games/<id>/qa/design-brief.md` | the designer's whole task (gp qa keeps it) |
| `games/<id>/qa/design-sheet.png` | a contact sheet of a new player's run: the dev build on a virtual clock, a fresh save, `?seed=1`, 1280×720, the demo bot (`host.qa({ demo })`; without one, an idle run), a frame every 10 s for `--minutes` (default 3, at most 15). At each stop it goes on as `gp qa`'s session section does — a results card that auto-continues (mountResults `autoContinueSec`) is let run and listed as **no stop**; otherwise the big button that continues, never Menu, never a rewarded offer, up to 3 taps — and the brief lists each stop. With `host.qa({ state })` every frame is labelled with the game's screen, stage and goal |
| `games/<id>/qa/design/` | the frames (`frame-<m>m<ss>.jpg`); with `--gemini` also `gameplay-design.mp4` and its contact sheet |
| `games/<id>/qa/design-gemini.md` | `--gemini`: Gemini's answer, in the same format, with a format check under it |
| `games/<id>/design.md` | written by the designer agent (commit it); `gp design <id> --check` parses it |

The brief holds what the platform already knows, so the designer starts from facts: the concept, the money design; the
genre, its must-haves (✓ / ✗ as the code shows them) and **every block that fits the genre, used or not yet** (`gp
catalog blocks --genre <g>`); where a new player's session stops (`qa/session.json`) and the first minute
(`qa/first-minute.json`) — run a full `gp qa` first; the balance report and the forecast's levers; the game's own
Basic Launch scores and every score screen on record — **each labelled with the build it measured** (`basicLaunch.scores.version`
in `publisher/results.yaml`; without it inferred from `publisher/updates.yaml` and marked so) against the version in the
checkout, so a 1.5.0 brief doesn't read 1.0–1.3's numbers as its own; the CHANGELOG's last versions; and, per section of
`design.md`, the question to answer while playing, the blocks for it and the lessons people told our games off for. The
game's records are found by its id, its folder's id, its title or its `repo:` (a record under another id is still its own;
a repository reused for a new game is not the new game's history).

A must-have the game builds in its **own code**, where the search sees no block (Idle Garage Evolution's ×1/×10/MAX shop
read as "✗ a level shop"): declare it in game.yaml, `money.covers: { shop: "the garage list with ×1 / ×10 / MAX
(src/garage/shop.ts)" }` — the id is the must-have's (`gp explain genre.<g>`), the text says where it is. The brief then
shows "✓ own code" with the where, and I_GENRE_EXPECTS stops hinting about it (an id that is no must-have of the genre:
W_MONEY_COVERS). The designer checks in play that it is there.

## The build to play: frozen

The designer plays on a **frozen** build — no file watcher, no HMR, as `gp qa` serves it: `npm run gp -- dev <id>
--frozen` (in the background; `gp dev <id> --stop` stops it), or `gp design <id> --serve`, which writes the brief and
keeps such a server up, its URL in the brief. The plain `gp dev` reloads the page when a file changes, and to a player bot
that is the game jumping to the title — it happened twice in the first design session. `?qa-demo=0` keeps the game's demo
bot off whatever calls it; `window.__gp.host.qaState()` says where the game is (`host.qa({ state })`: the screen, the stage,
the goal, what to touch now) when the game has the hook — the brief says whether it does, and shows a Playwright snippet
that uses it.

The designer then plays **15+ minutes as a new player** (desktop 1280×720 first, then 360×800 touch only), some as an
experienced one (same save, every screen and feature), and looks up **the genre's hits on CrazyGames** (a web search
`site:crazygames.com <genre>`): what they do in the first minute, the session and the return that this game doesn't.

## design.md

```markdown
# Garage Evolution — design proposals

Designer: … · Date: … · Played: gp dev, 18 min at 1280×720, 6 min at 360×800, 5 min with progress

## Top 3

1. [high] The results card starts the next run after 3 s, with the next car to unlock and its progress — playtime: at 1:10 the first results screen offers only Play again → `mountResults({ autoContinueSec: 3 })`, goalFromSnapshot · effort S
2. …
3. …

## First minute
## Session
## Coming back
## Phones
## Juice and feel
## Content and variety

- [high|mid|low] <change> — <why: the metric and what you saw> → <how: the platform's block or the game's code> · effort S|M|L
- [none] — <why nothing is needed here>

## The genre's hits

- <a top game of the genre>: <what it does that ours doesn't> → <what we take, in our own shape>

## Not now

free text: what you would not do yet (a new system, a mode, a screen) and why
```

`--check` refuses: generic advice ("improve the graphics", "add more content"), a why that names no metric
(conversion / first minute, playtime / session, D1 / coming back), a how that names neither a block nor the game's code (a
file or a `src/…` path, `game.yaml`, the balance data, a function `dailyCar()`, a `Class.method`, an `identifier` in
backticks), a missing effort, a Top 3 that isn't three, a missing section, fewer than two hits, no `[high]` at all, the
template left in. Each problem names its part and quotes it — `how: "make them bigger" names no block and no code`,
`why: …`, `effort: …` — on the line that part is on (a proposal over several lines says where it starts). It sums up a
good file as "Top 3 + N proposals in the sections (k high)": the sections' count is apart from the Top 3. `[high]` means you expect a point on a metric on a device class; the Top 3 are
the best effect **for their effort**. Deepen before you widen: a new system is a screen a reviewer opens unfinished.

## A second opinion from Gemini (`--gemini`)

With `GEMINI_API_KEY` (or `GOOGLE_API_KEY`) in the environment — the same key as `gp art` — `gp design <id> --gemini`
records a gameplay cut with `gp video`'s recorder (1280×720, `--max` seconds, default 90, going on through the stops, no
sound, a lighter encode than a preview: ≈ 8 MB for Forge Night), sends it to Gemini's video understanding (inline up to
14 MB, else the Files API) with the same rules and format as the agent's brief and the game's facts in short, and saves
the answer to `qa/design-gemini.md`. `--model` picks the model (or `GP_DESIGN_MODEL`); the default is a Flash model,
which a new key on the free tier can use (Pro needs billing). **Before the video** it asks the model a one-word question —
cheap — and follows the answer: a 404 that names a replacement ("no longer available to new users, use …") goes to that
model, one that names none to the newest Flash the key lists; a 429 with no quota ("free tier", limit 0) goes to Flash and
says plainly that Pro has no quota on this key; no model at all — the command says why and records no video. A server
error (a 502 "upstream request failed") is retried once, and an inline video that still fails goes again through the
Files API. `qa/design-gemini.md` says which model answered and why. Without ffmpeg it sends the run's frames instead. The key goes only into the request's `x-goog-api-key` header: never into a
URL, an argument, a file or a message. Without a key the command says how to set one and makes everything else; in a
cloud environment whose network adds the header (a network secret), run with `GEMINI_VIA_NETWORK=1`.

The designer agent reads Gemini's answer after playing, takes what it has seen in play, and says where it disagrees:
the video shows a bot, not a person, and Gemini can't feel the controls.
