# Routing the work to the right model

The owner's ТЗ (2026-10-27, `publisher/tasks/2026-10-27-tz-routing-pixellab.md`) has one aim: make a game without
running into the weekly Claude limit. Opus gets the hard tasks only, Haiku gets the mechanical ones, Sonnet does the
rest, and the graphics leave Claude entirely: sprites come from PixelLab.

## The classes

| Class | What it looks like | Who | Model |
|---|---|---|---|
| Mechanical | renames, formatting, tests after an example, boilerplate, mass edits, filling strings, records | subagent **mechanic** | Haiku |
| Routine | a feature from a clear spec, UI, an ordinary bug, a one-module refactor | the main session | Sonnet |
| Hard | a system's architecture, a bug after a failed try, performance, a change across more than 3 modules | subagent **architect** | Opus |
| Pixel art | sprites, directions, animations, tiles, icons | subagent **pixel-artist** | Sonnet + PixelLab |
| Promo art | covers, capsules, banners, collages from the game's sprites | subagent **promo-artist** | Sonnet |

**The rules:**
- **Hand over everything a subagent needs.** It doesn't see the conversation: the main session gives it the goal, the
  file paths, the limits and what counts as done.
- **Unsure between routine and hard?** Sonnet tries first. The task goes to the architect after a failed try.
- **The architect** returns a plan, the key code and the routine steps left. Sonnet or the mechanic finishes those.
- **The mechanic** stops and reports when a step needs a decision.
- **Claude never draws or redraws sprites.** The rework of sprites was where the limit went (Candle Crypt: portraits,
  animations, the 32 px redraw, the weapons — five rounds).
- **The target:** about 30 % Opus, 50 % Sonnet and 20 % Haiku of the tokens. To check it, look at `/usage` every 1–2
  days for the first two weeks. Anthropic doesn't publish how much of the limit each model's tokens take; Opus has a
  window of its own. If more than 70 % of the week's limit is gone before mid-week, Sonnet tries the hard tasks first.

## Where the agents are

- **A game repository:** `.claude/agents/` — architect, mechanic, pixel-artist and promo-artist. They come from the
  platform's `templates/game-repo/.claude/agents/`: `gp init` puts them in a new repository, and `gp agents` installs or
  updates them in an existing one (`--check`: exit 1 when one is missing or old). Commit them with the game.
- **The platform:** its own `.claude/agents/` — architect and mechanic, with the platform's checks.
- **The main session's model** is the session's setting: `/model sonnet` in Claude Code. A game chat the platform opens
  is created with its model (`create_session` `model`).

## What counts against the limits (checked 2026-10-27)

All of it is the subscription's limit:
- **Cloud sessions:** a session "counts toward your plan's usage limits" (code.claude.com/docs/en/claude-code-on-the-web).
- **Routines and scheduled tasks:** they "draw down subscription usage the same way interactive sessions do"
  (code.claude.com/docs/en/routines).
- **Subagents:** they "count toward the same usage limits as your main conversation"
  (code.claude.com/docs/en/sub-agents).
- **The Agent SDK and `claude -p`:** they still use the plan's limits; the June change was paused
  (support.claude.com/articles/15036540).
- **The Max plan's API credit** (Max 5x: $100 a month) is only for calls with an API key from the linked Console
  organization (support.claude.com/en/articles/17154008).

## The quotas of the external generators: `gp quota`

The limits live in the platform's `publisher/quota.yaml`:
- PixelLab Apprentice: 2,000 a month, a reserve of 50, from its reset day;
- FLUX: off.

A change of plan is a change of that file, made by the owner. Every generation is recorded in the repository that
spent it: a game's `art/quota-log.json`, committed with the game. So a fresh container still knows the month's spend.

- `gp quota check pixellab` exits 0 while more than the reserve is left, 1 otherwise. The pixel-artist runs it before
  every generation and stops on 1.
- `gp quota record pixellab <n>` comes after every generation, failed tries included.
- `gp quota status` shows every service.

Where the service tells its own balance, the lower of the two counts.

Claude's own limit isn't counted here: look at `/usage` in Claude Code every 1–2 days.
