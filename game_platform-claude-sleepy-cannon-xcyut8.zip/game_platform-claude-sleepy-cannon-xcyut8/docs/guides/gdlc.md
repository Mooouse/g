# The Game Design Lifecycle (GDLC): `gp stage`

The owner (Жаслан, 2026-10-23): «Давай пусть платформа работает в парадигме геймдизайн на каждом этапе. Это как SSDLC но
для игр.»

SSDLC doesn't trust a team to remember security at the end. Every phase has a security question, an artifact, a check,
a review and a gate, and a phase doesn't close until its gate is met. The platform already had the design checks:
`gp brief`, `gp forecast`, `gp uniqueness`, the blind first look, `gp qa`'s first minute and session, `gp balance`,
`gp design`, `gp review` and the Basic Launch records. Until now, running one was something an agent had to remember.
The GDLC puts them in order as seven phases with gates. **`gp stage <id>`** says which phase a game is in, which gates
hold (with evidence), and what to do next.

Our own record is why. `publisher/results.yaml` holds 32 records of CrazyGames' answers, and none is a Full Launch:

- **2** rejections for a concept "quite close to existing titles" (Petri Panic, Kite Royale). The concept was fixed too
  late.
- **19** rejections for "the overall quality". Swarm Smash went out with 0 `[blocking]` findings and was still rejected
  (D80, `docs/research/qa-calibration-2026-10.md`). A checklist at the end doesn't stand in for judging the game earlier.
- **9** Basic Launch stops. 5 of the 8 recorded score screens have a 1/5 conversion on at least one device class:
  Hang the Moon, Dread Throne, Starsilk, Candle Crypt and Potion Logic. A low conversion means the first minute was lost.
- A patch that misses the window: Garage Evolution's 1.4.0 went live on 2026-10-19 at 18:49, after its Basic Launch
  window closed. The scores measured 1.0.0–1.3.6, and the stop came one point short (8/15 on desktop).

Each problem belonged to a phase that had already passed. A gate is there to catch it in that phase.

## The phases

| # | Phase | The design question | Artifacts | Automated checks | Review by an agent who didn't make it | Gate (exit) |
|---|---|---|---|---|---|---|
| 0 | **Brief** | Is the ТЗ buildable, consistent and the game's own, before anything is built on it? | `docs/gdd.md` (edited in place), `docs/gdd-review.md`, `qa/brief-owner.md` | `gp brief --check` | the critic: did not write the ТЗ and won't build the game ([brief.md](brief.md)) | the loop is closed: nothing open or disputed, and the critic wrote «no further questions». **No ТЗ: n/a** |
| 1 | **Concept** | In one sentence, what does the player do that the 3 closest portal games don't? Where does it earn? | game.yaml `concept` and `money`; `docs/concept.md` (the searches, the runner-up); `qa/forecast.md`; `qa/uniqueness.md` | `gp validate` (E_CONCEPT, E_MONEY*), `gp forecast --idea` for the idea and the runner-up, `gp forecast`, `gp uniqueness` | the ТЗ critic's `originality` and `money` questions; without a ТЗ, `gp brief docs/concept.md` (advised) | validate has 0 errors; the hook, the difference and 3 closest games are written; the genre and the money design are set; `docs/concept.md` has no TODO; `forecast.md` exists; uniqueness ≥ 70 |
| 2 | **Vertical slice: the first 30 s** | Does the core verb feel good in the first 30 s? Does a stranger see the goal and the twist? | the playable slice (with `host.qa({ demo })`), `qa/first-look.md`, `qa/uniqueness.json`, `qa/feel.json` | `gp qa`: the twist check (`host.twist` within `concept.twist.within`, and its words readable), the feel section | **the blind first look** (`gp review --first-look`): an agent who knows nothing about the game sees six frames | **first look "keep playing" ≥ 4/5 and the goal told**; the twist fires in play; no failed feel check |
| 3 | **First session** | Does a new player get into play at once and stay 10 minutes? Is the progression paced? | `qa/first-minute.json`, `qa/session.json`, `qa/balance.md` | `gp qa`: the first-minute section, the session section (W_SESSION_SHORT), the balance section (`balance()`, `balanceModel()`) | the numbers decide here; the reviewer's `## Session` checks them again in phase 5 | every first-minute check is green; the first natural stop comes after 10 min of play (CrazyGames); the balance report is green |
| 4 | **Content and meta** | Is there something new every minute or two? Is there a reason to come back tomorrow? | `design.md`; game.yaml `money.returns`, `money.covers` | `gp design --check`, I_GENRE_EXPECTS (the genre's must-haves), `gp qa` feel: variety over time | **the designer** (`gp design`): plays 15+ min and proposes what moves playtime, D1 and conversion ([designer.md](designer.md)) | `design.md` ✓ and its Top 3 built; a reason to return; the genre's must-haves met or covered; nothing-new gaps within the feel section's limit |
| 5 | **Release candidate** | Would the portal's reviewer pass it? Does the owner have everything the form asks for? | `quality.md`, `qa/report.md` (a full run), `store/`, `submission/` and its zip | the full `gp qa` green on the current code, `gp review --check`, `gp submission` | **the quality reviewer** (`gp review`) against CrazyGames' requirements, our verdicts and `gp lessons` | `gp review --check` ✓; the full QA is green and newer than the code; the submission zip is newer than the code |
| 6 | **Live** | What did the players do? Which metric is weakest? What does the next version change for it? | `publisher/results.yaml` (the verdict, the score screen), `publisher/updates.yaml`, a new `design.md`, `patch-notes.md` | `gp design` (reads the scores and names the weakest metric per device), `gp forecast --results` | the designer's next round, on the weakest metric | the portal's answer is recorded; after Basic Launch, the score screen is recorded and a design round comes after it; a patch is uploaded **inside the window** (7–21 days), or the game reached Full Launch |

All of these commands existed before the GDLC. The only new piece is `gp stage`, which reads their output. Phase 6 had
no check of its own before: the gate now reads the patch dates in `publisher/updates.yaml` against the Basic Launch
window, and compares design.md's date with the score screen's.

## Why each gate exists

- **0 Brief.** A ТЗ is cheapest to fix before any code exists. Every game we built from a brief met its problems later:
  at the review ("the overall quality", "quite close to existing titles") or at Basic Launch (a 3–6 min session, no
  reason to return). The critic grounds each question in a platform fact ([brief.md](brief.md), D85).
- **1 Concept.** Two rejections came from the concept alone. Petri Panic arrived next to ≈ 20 X Survivors and Cell
  Survivor; Kite Royale was also "quite close". A search, the runner-up and the money forecast take an hour. A rejected
  concept costs the whole game. `gp submission` already refuses a uniqueness score under 70.
- **2 Slice.** Conversion is the score our games lose most often (5 of 8 screens have a 1/5). Candle Crypt is the
  measured case. Its blind first look said "keep playing **3/5**: one skirmish at 8 s, then empty corridors"
  (`docs/research/pixel-roguelites-2026-10.md` §4). Its Basic Launch conversion scored **1/5** on both device classes,
  while its playtime and D1 scored 5. Content and polish on top of a first 30 s that a stranger leaves are wasted,
  because conversion counts the players who stay one minute. The threshold is **4**: a 3 was Candle Crypt. The gate also
  asks for the twist in play, because a twist that exists only on paper doesn't make the game its own.
- **3 First session.** Every Basic Launch we had stopped on average playtime (3–6 min). Candle Crypt's 9m31s scored 4/5
  on desktop. `gp qa`'s session section finds the first natural stop of a new player, and the gate wants it past
  10 minutes ([first-minute.md](first-minute.md#11-the-session-from-the-first-minute-to-the-tenth)).
- **4 Content and meta.** "No variety" is the jury's most frequent remark (`gp lessons`). D1 scored 1–3 of 5 on all 8
  recorded score screens. The designer round used to come only after a stop (an update or a resubmission). Now it runs
  before the release candidate, because the cheapest version to change is the one not yet submitted.
- **5 Release candidate.** Nineteen quality rejections. The reviewer's brief is calibrated (D80: the review sheet next
  to approved and rejected shots), and `gp submission` refuses a `[blocking]` finding.
- **6 Live.** Nine stops, none of them a Full Launch. Garage Evolution's scores never saw its 1.4.0. Three of four
  resubmissions after a stop were rejected for looking like the build before ([designer.md](designer.md)). The gate
  asks for the score screen, a design round on the weakest metric, and a patch inside the window.

## `gp stage`

```
npm run gp -- stage <id>                 # a game in its own repository: scripts/gp.sh stage
npm run gp -- stage <id> --check slice   # exit 1 while phase 2's gate isn't met (0–6 or the id)
npm run gp -- stage <id> --json
```

It reruns nothing. It reads `qa/qa-results.json`, `qa/session.json`, `qa/uniqueness.json`, `qa/first-look.md`,
`qa/forecast.md`, `qa/uniqueness.md`, `quality.md`, `design.md`, `docs/gdd-review.md` with `docs/gdd.md`,
`docs/concept.md`, the submission zip, `store/`, and `publisher/results.yaml` and `updates.yaml`. It runs `gp validate`,
which is cheap. It writes `qa/stage.md`: a table of the phases and every check, with its evidence (the file and its
date, or the result) and what to do when the check isn't met.

- **A check** is `✓` met, `✗` not met (the evidence says no), `·` not yet (no evidence: a game in an older phase, an
  older game without the newer files), or `–` n/a (no ТЗ; not a portal game). Advice is shown but doesn't count toward
  the gate.
- **The phase the game is in** is the first one whose gate isn't met. "Not yet" and "not met" both hold the game there.
- **Built past a gate.** A phase is *reached* only by its own files: `design.md` for phase 4; `quality.md`, the store or
  a zip for 5; a portal record for 6. From phase 4 on, any open gate behind the work is flagged. Phases 1–3 overlap
  while the slice is built (`gp qa` measures 2 and 3 from the first playable build), so they aren't flagged against
  each other.
- **Fresh evidence.** For the release gate, the QA run and the zip must be newer than the game's code (its files except
  Markdown and outputs). A first look older than the code is noted but not refused: a new blind agent is needed once the
  first 30 s change, not after every edit.

## What is enforced, and where

Light, not a wall. One command refuses; the others warn.

| Where | What | How |
|---|---|---|
| `gp submission` | **phase 0**: the ТЗ review loop is closed, when the game has a `docs/gdd.md` | refuses (the `Design gates (gp stage)` line) |
| `gp submission` | **phase 2** on CrazyGames: the blind first look "keep playing" ≥ 4/5 with the goal told | refuses a new submission (and `--full`); **an update to a live game only warns**, because a patch inside the Basic Launch window must not wait for a new blind agent |
| `gp submission` | phases 1, 3 and 4 | listed as "not enforced, still open", never refused (the uniqueness, forecast and quality gates already refuse their own parts) |
| `gp design`, `gp review`, `gp build --target crazygames` | built past the slice without a passed first look | a warning: `⚠ GDLC: … built past the vertical slice (phase 2) without its gate` |
| `gp qa` | the phase the game is in, after the run | one line, `GDLC: phase N … — next: …`, and `qa/stage.md` written |

The gates above phase 2 stay reported, not refused. The session's 10 minutes, the balance report and the design round
are judgements a game can fail honestly and still be worth submitting. The owner decides that, with `qa/stage.md` in
front of him. Phase 0 and phase 2 are refused because skipping them has cost us the most: an unreviewed ТЗ, and a first
minute a stranger leaves.

**When the first look is under 4:** change the first 30 s (`gp lessons` → first-minute: a fight or a score in the first
seconds, the goal on screen, a choice by 0:30), then ask a **new** blind agent: `gp review <id> --first-look`. An agent
that has seen the earlier frames is no longer blind.

## In the loop

AGENTS.md §1 names the phase and the gate of every step. Run `gp stage <id>` at the start of a session, before moving on
to the next step, and before handing over. The report's `Next:` is the next action. Code:
`packages/cli/src/stage.ts`; tests: `packages/cli/test/stage.test.ts`; decision D86.
