# CLAUDE.md

Making a game: follow @AGENTS.md exactly.

Working on the platform itself (packages/): read docs/guides/add-a-block.md and docs/platform-architecture.md;
run `npm run check` before every commit, and after any change to runtime, blocks or kits a full `gp qa` of the code-game
examples — the kind of game we ship: `npm run gp -- qa docs/examples/code/game.yaml` and `npm run gp -- qa docs/examples/art/game.yaml`.
(The kids kit is covered by `npm run check`; Balloon Pop is not a reference for our games — the owner, 2026-10-02.)

Route the work to the right model (docs/guides/routing.md; the owner's ТЗ, 2026-10-27). The main session does the
routine itself and hands the rest to the subagents in `.claude/agents/`:
- **mechanic** (Haiku): renames, mass edits, records, tests after an example;
- **architect** (Opus): a cross-package design, a bug that survived one try, performance.
A subagent sees none of the conversation: give it the goal, the files, the limits and what counts as done.
