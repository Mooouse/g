// The live world's rules in the validator and the money model: paid randomness (E_PAID_RANDOM), a rewarded spin
// (W_REWARDED_RANDOM), odds not shown (W_LOOT_ODDS), the `restock` rewarded kind, and hybrids (money.hybrid) that let a
// second layer's blocks in (W_GENRE_BLOCK).

import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { ERRORS, GENRE_BLOCKS, MONEY_TABLE, REWARDED_KINDS, blocksFor, defaultPer, forecast, gameGenre, genreChecks, ideaDesign, lootChecks, rewardedKindOf, validateText } from '../src/index.ts';

const CODE = readFileSync(new URL('../../../docs/examples/code/game.yaml', import.meta.url), 'utf8');
const withMoney = (extra: string) =>
  extra.startsWith('  rewarded:') ? CODE.replace(/^  rewarded:\n(    - .*\n)+/m, extra) : CODE.replace(/^money:\n/m, `money:\n${extra}`);
const issues = (text: string) => validateText(text, { mode: 'dev' }).issues;
const codes = (text: string) => issues(text).map((i) => i.code);

describe('paid randomness and fair rolls (money.loot)', () => {
  it('the example game has a money section to add to', () => {
    expect(CODE).toMatch(/^money:\n/m);
    expect(issues(CODE).filter((i) => i.severity === 'error')).toEqual([]);
  });
  it('E_PAID_RANDOM: a roll for real money, or for a currency sold for it, is refused', () => {
    for (const cost of ['purchase', 'bought']) {
      const e = issues(withMoney(`  loot:\n    - { id: gem-egg, cost: ${cost}, odds: "the egg card shows each tier" }\n`)).find((i) => i.code === 'E_PAID_RANDOM')!;
      expect(e, cost).toMatchObject({ severity: 'error', path: ['money', 'loot'] });
      expect(e.message).toContain('PEGI 16');
    }
    expect(codes(withMoney('  loot:\n    - { id: meadow-egg, cost: earned, odds: "the egg card shows each tier" }\n'))).not.toContain('E_PAID_RANDOM');
    expect(codes(withMoney('  loot:\n    - { id: daily-egg, cost: free, odds: "the egg card shows each tier" }\n'))).not.toContain('E_PAID_RANDOM');
    expect(codes(withMoney('  loot:\n    - { id: x-egg, cost: robux }\n'))).toContain('E_ENUM');
  });
  it('W_REWARDED_RANDOM: a roll for an ad, or a rewarded offer that promises a spin or a random prize', () => {
    expect(codes(withMoney('  loot:\n    - { id: ad-egg, cost: ad, odds: "the egg card shows each tier" }\n'))).toContain('W_REWARDED_RANDOM');
    const spin = withMoney('  rewarded:\n    - { placement: lucky, kind: other, gives: "spin the lucky wheel" }\n');
    expect(issues(spin).find((i) => i.code === 'W_REWARDED_RANDOM')).toMatchObject({ severity: 'warning', path: ['money', 'rewarded'] });
    expect(codes(withMoney('  rewarded:\n    - { placement: box, kind: other, gives: "a mystery box" }\n'))).toContain('W_REWARDED_RANDOM');
    expect(codes(withMoney('  rewarded:\n    - { placement: lucky-egg, kind: boost, gives: "your next egg is rare or better" }\n'))).not.toContain('W_REWARDED_RANDOM');
    expect(codes(withMoney('  rewarded:\n    - { placement: reroll, kind: reroll, gives: "three new upgrade cards to pick from" }\n'))).not.toContain('W_REWARDED_RANDOM');
  });
  it('W_LOOT_ODDS: a declared roll that does not say where its odds are; a code that never reads them', () => {
    expect(codes(withMoney('  loot:\n    - { id: meadow-egg, cost: earned }\n'))).toContain('W_LOOT_ODDS');
    expect(codes(withMoney('  loot:\n    - { id: meadow-egg, cost: earned }\n    - { id: meadow-egg, cost: earned }\n'))).toContain('E_MONEY');
    const imported = ['LootTable'];
    expect(lootChecks({ imported, source: 'const r = eggs.roll("meadow");' }).map((i) => i.code)).toEqual(['W_LOOT_ODDS']);
    expect(lootChecks({ imported, source: 'panel.text = eggs.oddsText("meadow"); eggs.roll("meadow");' })).toEqual([]);
    expect(lootChecks({ imported, source: 'for (const o of eggs.odds("m")) row(o);' })).toEqual([]);
    expect(lootChecks({ imported, source: '// eggs.odds("m") later\neggs.roll("m")' })).toHaveLength(1);
    expect(lootChecks({ imported: [], source: '' })).toEqual([]);
  });
  it('every new code is in the catalog with a why and a fix', () => {
    for (const c of ['E_PAID_RANDOM', 'W_REWARDED_RANDOM', 'W_LOOT_ODDS', 'W_MONEY_HYBRID']) expect(ERRORS[c]?.fix, c).toBeTruthy();
  });
});

describe('the restock rewarded kind', () => {
  it('is a kind with its own take rate, read from a placement id, offered per run', () => {
    expect(REWARDED_KINDS).toContain('restock');
    expect(MONEY_TABLE['rewarded.take.restock'].mid).toBeGreaterThan(0);
    for (const p of ['restock', 'restock-now', 'new-stock', 'refresh-shop']) expect(rewardedKindOf(p), p).toBe('restock');
    expect(rewardedKindOf('refresh')).toBe('reroll');
    expect(defaultPer('restock')).toBe('run');
    expect(codes(withMoney('  rewarded:\n    - { placement: restock, kind: restock, gives: "a fresh stock in the crystal stall now" }\n')).filter((c) => c.startsWith('E_'))).toEqual([]);
  });
  it('adds to the forecast like any offer', () => {
    const base = ideaDesign({ channel: 'crazygames', genre: 'idle', sessionMin: 15, breaks: 6, rewarded: ['x2'] }).design;
    const more = ideaDesign({ channel: 'crazygames', genre: 'idle', sessionMin: 15, breaks: 6, rewarded: ['x2', 'restock'] }).design;
    expect(more.rewarded.map((r) => r.kind)).toEqual(['x2', 'restock']);
    expect(forecast(more).expected.mid).toBeGreaterThan(forecast(base).expected.mid);
  });
});

describe('hybrids: money.hybrid lets a declared layer\'s blocks in', () => {
  const action = { genre: 'action' as const, sub: null, from: 'money.genre action', named: false, source: '' };
  it('an idle layer on an action game: offlineEarnings and Prestige fit, the fix says how to declare it', () => {
    const w = genreChecks({ ...action, imported: ['offlineEarnings', 'Prestige'] });
    expect(w.map((i) => i.code)).toEqual(['W_GENRE_BLOCK', 'W_GENRE_BLOCK']);
    expect(w[0].fix).toContain('money.hybrid: [idle]');
    expect(genreChecks({ ...action, hybrid: ['idle'], imported: ['offlineEarnings', 'Prestige', 'Sites'] })).toEqual([]);
    expect(genreChecks({ ...action, hybrid: ['puzzle'], imported: ['offlineEarnings'] })).toHaveLength(1);
  });
  it('gameGenre reads it (sub-genres too); the benchmarks stay the main genre\'s', () => {
    expect(gameGenre({ kit: 'code', audience: 'general', money: { genre: 'platformer', hybrid: ['tycoon'] } })).toMatchObject({ genre: 'action', sub: 'platformer', hybrid: ['idle'] });
    expect(gameGenre({ kit: 'code', audience: 'general', money: { genre: 'idle', hybrid: ['idle', 'bogus'] } }).hybrid).toEqual([]);
  });
  it('in game.yaml: a known genre that is not the game\'s own', () => {
    const yaml = (h: string) => CODE.replace(/^(money:\n(?:  .*\n)*?)(  genre: .*\n)/m, `$1$2  hybrid: [${h}]\n`);
    expect(yaml('idle')).toContain('hybrid: [idle]');
    expect(codes(yaml('idle')).filter((c) => c.startsWith('E_') || c === 'W_MONEY_HYBRID')).toEqual([]);
    expect(codes(yaml('rhythm'))).toContain('E_MONEY');
    expect(codes(yaml('kids'))).toContain('E_MONEY');
    const own = /^  genre: (\S+)/m.exec(CODE)![1];
    expect(codes(yaml(own))).toContain('W_MONEY_HYBRID');
  });
});

describe('the live-world blocks in the genre registry', () => {
  it('are registered for the genres they serve, for every genre (none is genre-only)', () => {
    for (const n of ['worldClock', 'restockShop', 'mountRestockTimer', 'LootTable', 'variants', 'dailyTable', 'shareCode', 'rivals']) {
      expect(GENRE_BLOCKS[n], n).toBeTruthy();
      expect(GENRE_BLOCKS[n].only, n).toBeUndefined();
    }
    expect(blocksFor('idle').map((b) => b.name)).toEqual(expect.arrayContaining(['worldClock', 'restockShop', 'LootTable', 'variants']));
    expect(blocksFor('idle', 'merge').map((b) => b.name)).toEqual(expect.arrayContaining(['LootTable', 'variants']));
    expect(blocksFor('puzzle').map((b) => b.name)).toContain('dailyTable');
    expect(blocksFor('action', 'roguelite').map((b) => b.name)).toEqual(expect.arrayContaining(['dailyTable', 'shareCode', 'rivals', 'LootTable']));
    expect(blocksFor('idle', 'tycoon').map((b) => b.name)).toEqual(expect.arrayContaining(['rivals', 'shareCode', 'restockShop']));
  });
});
