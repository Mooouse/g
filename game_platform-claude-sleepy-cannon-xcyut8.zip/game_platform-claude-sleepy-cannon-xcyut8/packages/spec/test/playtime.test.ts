// The Basic Launch playtime score from our own score screens (publisher/results.yaml): the fit, the score of a session,
// what a score needs, and the lens that makes playtime the first lever when it is the weakest metric

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { parse } from 'yaml';
import { ideaDesign, minutesFor, PLAYTIME_LEVER, playtimeLens, playtimeLever, playtimeScale, playtimeScore, type RecordedResult } from '../src/index.ts';

const results = (parse(readFileSync(join(import.meta.dirname, '../../../publisher/results.yaml'), 'utf8')) as { results: RecordedResult[] }).results;
const rec = (game: string, device: 'desktop' | 'mobile', value: number, score: number, next?: number): RecordedResult =>
  ({ game, channel: 'crazygames', review: { verdict: 'approved' }, basicLaunch: { verdict: 'stopped', scores: { [device]: { playtime: { value, score, ...(next ? { next } : {}) } } } } }) as RecordedResult;

describe('the playtime scale', () => {
  it('reproduces every recorded score (the fit goes through its own points)', () => {
    for (const dev of ['desktop', 'mobile'] as const) {
      const s = playtimeScale(results, dev)!;
      expect(s.points.length, dev).toBeGreaterThanOrEqual(3);
      for (const p of s.points) expect(playtimeScore(s, p.value), `${dev} ${p.game} ${p.value}`).toBe(p.score);
      for (const p of s.points) if (p.next) expect(playtimeScore(s, p.next), `${p.game} next`).toBe(p.score + 1);
    }
  });
  it('desktop: our 3–5-minute sessions score 1, Candle Crypt\'s 9m31s a 4, 12m13s a 5; more minutes never score less', () => {
    const s = playtimeScale(results, 'desktop')!;
    expect(playtimeScore(s, 3.3)).toBe(1);
    expect(playtimeScore(s, 4.83)).toBe(1);
    expect(playtimeScore(s, 9.52)).toBe(4);
    expect(playtimeScore(s, 12.22)).toBe(5);
    let last = 0;
    for (let m = 0; m <= 30; m += 0.25) {
      const x = playtimeScore(s, m);
      expect(x).toBeGreaterThanOrEqual(last);
      last = x;
    }
    expect(minutesFor(s, 3)).toBeGreaterThan(4.83);
    expect(minutesFor(s, 3)).toBeLessThan(9.52);
    expect(minutesFor(s, 5)).toBeCloseTo(12.2, 1);
  });
  it('fits a tiny made-up record set the same way: the middle of each band, "next" as a band\'s start', () => {
    const s = playtimeScale([rec('a', 'desktop', 4, 1), rec('b', 'desktop', 10, 4, 12)], 'desktop')!;
    expect(s.anchors).toEqual([{ min: 4, score: 1.5 }, { min: 10, score: 4.5 }, { min: 12, score: 5 }]);
    expect(playtimeScore(s, 7)).toBe(3);
    expect(playtimeScale([rec('a', 'desktop', 4, 1)], 'desktop')).toBeNull();
  });
});

describe('the playtime lens and lever', () => {
  it('a 4-minute design: 1/5 on desktop, the weakest metric, and its lever comes first', () => {
    const { design } = ideaDesign({ channel: 'crazygames', genre: 'puzzle', sessionMin: 4, breaks: 5 });
    const lens = playtimeLens(results, [{ name: 'design', minutes: 4, from: '--session' }])!;
    expect(lens.devices.find((d) => d.device === 'desktop')!.scores[0]).toBe(1);
    expect(lens.weakest).toBe(true);
    const lv = playtimeLever(design, lens);
    expect(lv.name).toBe(PLAYTIME_LEVER);
    expect(lv.change).toContain('desktop 1/5');
  });
  it('the QA estimate is read before the design: a 12-minute design that QA measures at 4 is still weak; one QA measures at 12 is not', () => {
    const design = { name: 'design' as const, minutes: 12, from: 'money.session.minutes' };
    const weak = playtimeLens(results, [design, { name: 'qa', minutes: 4, from: 'qa/session.json', firstStopMin: 1, firstStopWhy: 'no-pull' }])!;
    expect(weak.basis.name).toBe('qa');
    expect(weak.weakest).toBe(true);
    expect(weak.devices[0]!.scores).toEqual([4, 1]);
    const strong = playtimeLens(results, [design, { name: 'qa', minutes: 12, from: 'qa/session.json' }])!;
    expect(strong.weakest).toBe(false);
  });
});
