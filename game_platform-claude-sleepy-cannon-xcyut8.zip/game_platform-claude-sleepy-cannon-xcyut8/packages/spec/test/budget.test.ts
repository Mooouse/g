// The size and load budget: the load model against the engine lab's measurements, the channel's budget and the one a
// game raises on purpose (and may not raise past the hard limit), and the load time in the money forecast.

import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { CHANNELS, MONEY_TABLE, SLOW_PHONE, budgetFor, chapterArrivals, embeddedDataBytes, estimateLoad, forecast, ideaDesign, levers, loadFactor, overBudget, splitUpload, validateText, type IdeaInput } from '../src/index.ts';

const root = new URL('../../../', import.meta.url);
const CODE = readFileSync(new URL('docs/examples/code/game.yaml', root), 'utf8');
const validate = (text: string) => validateText(text, { mode: 'dev', publisher: {} });

// The engine lab (QmaCyber/game12, results/<variant>.json): upload bytes raw / gzipped / base64 data, and the median of
// 5 cold loads to a tappable Play on Lighthouse's slow-4G profile with 4× CPU throttling
const LAB = [
  { v: 'canvas', raw: 42704, gzip: 15877, data: 0, ms: 433 },
  { v: 'three', raw: 609436, gzip: 155123, data: 0, ms: 1592 },
  { v: 'pixi', raw: 605708, gzip: 177827, data: 0, ms: 1919 },
  { v: 'phaser', raw: 1420524, gzip: 370451, data: 0, ms: 3347 },
  { v: 'rapier', raw: 3448791, gzip: 1297567, data: 3205956, ms: 7883 },
];

describe('the load model', () => {
  it('is within 15% of the engine lab\'s measurements (an engine that boots slowly, Kaplay, is slower than its bytes)', () => {
    for (const l of LAB) {
      const e = estimateLoad(l).totalMs;
      expect(Math.abs(e - l.ms) / l.ms, `${l.v}: ${Math.round(e)} ms vs ${l.ms} ms measured`).toBeLessThan(0.15);
    }
    // Ordered as measured: a bigger upload never loads faster
    const t = LAB.map((l) => estimateLoad(l).totalMs);
    expect([...t].sort((a, b) => a - b)).toEqual(t);
  });
  it('counts long base64 runs as data, cheaper than code', () => {
    const blob = 'A'.repeat(10_000);
    expect(embeddedDataBytes(`<script>const w = "data:application/wasm;base64,${blob}"; const x = "short";</script>`)).toBe(10_000);
    expect(embeddedDataBytes('<script>const x = "abc"</script>')).toBe(0);
    const asCode = estimateLoad({ raw: 1e6, gzip: 3e5, data: 0 }).cpuMs;
    expect(estimateLoad({ raw: 1e6, gzip: 3e5, data: 9e5 }).cpuMs).toBeLessThan(asCode);
  });
});

describe('the budget', () => {
  it("is the channel's: CrazyGames 400 KB gzipped, 3 s, 20 MB hard; none off the web portals", () => {
    expect(CHANNELS.crazygames.webLimits).toMatchObject({ maxFiles: 1500, maxInitialMB: 20, budgetGzipKB: 400, warnLoadSec: 3 });
    expect(budgetFor('crazygames')).toEqual({ gzipKB: 400, warnLoadSec: 3, hardMB: 20, from: 'channel' });
    expect(budgetFor('android-families')).toBeNull();
  });
  it('warns above it; a game raises it on purpose (and the load warning with it)', () => {
    const b = budgetFor('crazygames')!;
    const small = { raw: 42704, gzip: 15877, data: 0 };
    expect(overBudget(small, estimateLoad(small), b)).toEqual([]);
    const big = LAB[4];
    const over = overBudget(big, estimateLoad(big), b);
    expect(over).toHaveLength(2);
    expect(over[0]).toContain('> the 400 KB budget');
    expect(over[1]).toMatch(/s to a tappable Play on a slow phone > 3 s/);
    const raised = budgetFor('crazygames', { gzipKB: 1500 })!;
    expect(raised).toMatchObject({ gzipKB: 1500, hardMB: 20, from: 'game.yaml budget.gzipKB' });
    expect(raised.warnLoadSec).toBeGreaterThan(8);
    expect(overBudget(big, estimateLoad(big), raised)).toEqual([]);
  });
  it('game.yaml budget: valid on a web portal up to the hard limit; E_BUDGET elsewhere or above it', () => {
    const withBudget = (b: string, text = CODE) => validate(text.replace(/^channel: .*$/m, (l) => `${l}\nbudget: ${b}`));
    const ok = withBudget('{ gzipKB: 1500 }');
    expect(ok.issues.filter((i) => i.severity === 'error')).toEqual([]);
    expect(ok.game!.budget).toMatchObject({ gzipKB: 1500 });
    expect(validate(CODE).game!.budget).toMatchObject({ gzipKB: 400, from: 'channel' });
    // Above 20 MB: the schema's maximum
    expect(withBudget('{ gzipKB: 30000 }').issues.map((i) => i.code)).toContain('E_RANGE');
    expect(withBudget('{ gzipKB: 1500, mb: 3 }').issues.map((i) => i.code)).toContain('E_UNKNOWN_FIELD');
    // A channel without a web upload has no budget
    const web = withBudget('{ gzipKB: 1500 }', CODE.replace(/^channel: crazygames$/m, 'channel: web'));
    expect(web.issues.find((i) => i.code === 'E_BUDGET')?.message).toContain('no web upload budget');
  });
});

describe('the load time in the forecast', () => {
  const idea = (i: Partial<IdeaInput>) => ideaDesign({ channel: 'crazygames', genre: 'action', sessionMin: 12, breaks: 4, rewarded: ['revive'], ...i }).design;
  it('lowers P(Full Launch) above 3 s, in full from 10 s (a judgement row)', () => {
    expect(MONEY_TABLE['cg.full.slowLoad'].confidence).toBe('judgement');
    expect(loadFactor(null, 3, 10, 0.75)).toBe(1);
    expect(loadFactor(2, 3, 10, 0.75)).toBe(1);
    expect(loadFactor(6.5, 3, 10, 0.75)).toBeCloseTo(0.875);
    expect(loadFactor(20, 3, 10, 0.75)).toBe(0.75);
  });
  it('the engine lab again: a 42 KB upload (0.4 s) and a 3.4 MB one (7.9 s) no longer forecast the same', () => {
    const small = forecast(idea({ uploadMB: 0.04, loadSec: 0.4 }));
    const big = forecast(idea({ uploadMB: 3.4, loadSec: 7.9 }));
    expect(big.pFullLaunch.mid).toBeLessThan(small.pFullLaunch.mid);
    expect(big.expected.mid).toBeLessThan(small.expected.mid);
    expect(big.used).toContain('cg.full.slowLoad');
    // Unknown load: no factor, as before
    expect(forecast(idea({ uploadMB: 0.04 })).pFullLaunch.mid).toBeCloseTo(small.pFullLaunch.mid, 10);
    // The lever says so
    expect(levers(idea({ loadSec: 7.9 }), undefined, 20).map((l) => l.name)).toContain('A load under 3 s on a slow phone');
    expect(levers(idea({ loadSec: 0.4 }), undefined, 20).map((l) => l.name)).not.toContain('A load under 3 s on a slow phone');
  });
});

describe('asset chapters: what Play waits for', () => {
  const block = (path: string, chapter: number, b64: string) => `<script type="application/octet-stream" data-gp-asset="${path}" data-gp-chapter="${chapter}" data-type="image/webp" data-n="${b64.length}">${b64}</script>`;
  const head = '<!doctype html><html><head><style>body{}</style></head><body><canvas id="game"></canvas>\n<script type="module" async>start()</script>\n';
  const page = head + [block('chapters/1/a.webp', 1, 'QUJD'), block('chapters/1/b.webp', 1, 'REVG'), block('chapters/2/c.webp', 2, 'R0hJSktM')].join('\n') + '\n</body>\n</html>';
  it('splits the page into the first load and each later chapter, in order', () => {
    const p = splitUpload(page);
    expect(p.first).toContain('start()');
    expect(p.first).not.toContain('data-gp-asset');
    expect(p.first.endsWith('\n</body>\n</html>')).toBe(true);
    expect(p.chapters.map((c) => [c.chapter, c.files])).toEqual([[1, 2], [2, 1]]);
    expect(p.chapters[1]!.text).toContain('R0hJSktM');
    // Every byte is somewhere
    expect(p.first.length + p.chapters.reduce((a, c) => a + c.text.length, 0)).toBeLessThanOrEqual(page.length);
  });
  it('a page without chapters is all first load', () => {
    expect(splitUpload(head)).toEqual({ first: head, chapters: [] });
  });
  it('the chapters arrive one after the other after the first load, on the slow phone', () => {
    const a = chapterArrivals(100_000, [{ chapter: 1, files: 2, rawBytes: 300_000, gzipBytes: 200_000 }, { chapter: 2, files: 1, rawBytes: 10, gzipBytes: 100_000 }]);
    const at = (bytes: number) => Math.round(SLOW_PHONE.rttMs + (bytes * 8) / (SLOW_PHONE.downMbps * 1000));
    expect(a.map((c) => c.inMs)).toEqual([at(300_000), at(400_000)]);
  });
  it('the budget counts the first load: "before Play" in its warning', () => {
    const first = { raw: 600_000, gzip: 500 * 1024, data: 0 };
    expect(overBudget(first, estimateLoad(first), budgetFor('crazygames'), true)[0]).toMatch(/^500 KB gzipped before Play > the 400 KB budget/);
  });
});
