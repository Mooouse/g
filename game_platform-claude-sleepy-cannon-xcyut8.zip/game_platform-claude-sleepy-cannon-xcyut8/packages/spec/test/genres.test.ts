// The genre registry: one entry per money genre, every block it names real (or one being added), the idle-only blocks,
// sub-genres onto money genres, and the two checks (I_GENRE_EXPECTS, W_GENRE_BLOCK).

import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import {
  GENERAL_BLOCKS,
  GENRE_BLOCKS,
  GENRE_INFO,
  GENRES,
  MONEY_TABLE,
  SUBGENRE_INFO,
  SUBGENRES,
  blocksFor,
  explain,
  expectationsFor,
  gameGenre,
  genreChecks,
  ideaDesign,
  importedBlocks,
  moneyGenre,
  validateText,
} from '../src/index.ts';

const PACKAGES = fileURLToPath(new URL('../../', import.meta.url));
/** Blocks other agents are adding right now (idle: offline earnings, prestige, sites; the daily): named before they land */
const BEING_ADDED = new Set<string>();

function sources(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? sources(join(dir, e.name)) : /\.ts$/.test(e.name) ? [join(dir, e.name)] : []));
}

describe('the genre registry', () => {
  it('has one entry per money genre, linked to its money rows', () => {
    expect(Object.keys(GENRE_INFO).sort()).toEqual([...GENRES].sort());
    for (const g of Object.values(GENRE_INFO)) {
      for (const row of Object.values(g.money)) expect(MONEY_TABLE, `${g.id}: ${row}`).toHaveProperty(row);
      expect(g.name && g.players, g.id).toBeTruthy();
    }
  });
  it('sub-genres are the money sub-genres, each onto its money genre, never a second list', () => {
    expect(Object.keys(SUBGENRE_INFO).sort()).toEqual(Object.keys(SUBGENRES).sort());
    for (const s of Object.values(SUBGENRE_INFO)) {
      expect(s.genre).toBe(SUBGENRES[s.id]);
      expect(GENRES as readonly string[]).not.toContain(s.id);
    }
    expect(moneyGenre('roguelite')).toBe('action');
    expect(moneyGenre('tycoon')).toBe('idle');
    expect(moneyGenre('idle')).toBe('idle');
    expect(moneyGenre('bogus')).toBeNull();
  });
  it('every block it names is in GENRE_BLOCKS and exported by its package (or being added)', () => {
    const named = [
      ...GENERAL_BLOCKS,
      ...Object.values(GENRE_INFO).flatMap((g) => [...g.blocks, ...g.expects.flatMap((e) => e.blocks)]),
      ...Object.values(SUBGENRE_INFO).flatMap((s) => [...s.blocks, ...s.expects.flatMap((e) => e.blocks)]),
    ];
    for (const n of named) expect(GENRE_BLOCKS, n).toHaveProperty(n);
    const pkgDir: Record<string, string> = { '@gp/core': 'core/src', '@gp/art': 'art/src', '@gp/physics': 'physics/src' };
    const exported = new Map<string, string>();
    for (const [pkg, dir] of Object.entries(pkgDir)) exported.set(pkg, sources(join(PACKAGES, dir)).map((f) => readFileSync(f, 'utf8')).join('\n'));
    for (const b of Object.values(GENRE_BLOCKS)) {
      const src = exported.get(b.from.split('/').slice(0, 2).join('/'))!;
      const found = new RegExp(`export\\s+(?:abstract\\s+)?(?:function|class|const|let)\\s+${b.name}\\b`).test(src);
      if (!BEING_ADDED.has(b.name)) expect(found, `${b.name} is not exported from ${b.from}`).toBe(true);
    }
  });
  it('offline earnings, prestige and the sites map are idle only, and not offered to other genres', () => {
    for (const n of ['offlineEarnings', 'Prestige', 'Sites', 'mountSitesMap']) expect(GENRE_BLOCKS[n].only).toEqual(['idle']);
    expect(blocksFor('idle').map((b) => b.name)).toContain('offlineEarnings');
    for (const g of GENRES.filter((x) => x !== 'idle')) expect(blocksFor(g).map((b) => b.name), g).not.toContain('Prestige');
    expect(blocksFor('idle', 'tycoon')[0].name).toBe('Sites');
  });
  it('goals, the coach hand, inspect plates, the album, the rewards hub and the one-card queue fit every genre and warn nowhere', () => {
    const names = ['dailyQuests', 'achievements', 'mountGoals', 'goalBanners', 'coachHand', 'inspect', 'collection', 'mountAlbum', 'playtimeGifts', 'luckyWheel', 'dailyOffers', 'timedBoost', 'mountRewardsHub', 'cards'];
    for (const n of names) {
      expect(GENRE_BLOCKS[n].only, n).toBeUndefined();
      expect(GENERAL_BLOCKS, n).toContain(n);
      for (const g of GENRES.filter((x) => x !== 'kids' && x !== 'other')) expect(blocksFor(g).map((b) => b.name), `${g}: ${n}`).toContain(n);
    }
    const g = { genre: 'puzzle' as const, sub: null, from: 'money.genre puzzle', named: true, source: '' };
    expect(genreChecks({ ...g, imported: names }).filter((i) => i.code === 'W_GENRE_BLOCK')).toEqual([]);
  });

  it('the shooter blocks (aim, look, steering, bosses, the announcer, threat cues, quality) fit action, shooting and survivors', () => {
    const shooter = ['TwinStick', 'LookInput', 'aimAssist', 'steer', 'BossPatterns', 'callouts', 'HitArcs', 'DamageNumbers', 'edgeArrow', 'QualityLadder'];
    for (const n of shooter) {
      expect(GENRE_BLOCKS[n].only, n).toBeUndefined();
      for (const g of ['action', 'shooting'] as const) expect(blocksFor(g).map((b) => b.name), `${g}: ${n}`).toContain(n);
    }
    for (const n of ['steer', 'TwinStick', 'BossPatterns', 'DamageNumbers']) expect(blocksFor('action', 'survivors').map((b) => b.name), n).toContain(n);
    // A boss machine is the action genre's peak: a game importing it has the must-have
    const issues = genreChecks({ genre: 'shooting', sub: null, from: 'money.genre shooting', named: true, imported: ['BossPatterns', 'Roster'], source: '' });
    expect(issues.filter((i) => i.code === 'I_GENRE_EXPECTS')).toEqual([]);
  });
  it('the season pass and the weekly event fit action, roguelites and idle games, and warn nowhere', () => {
    for (const n of ['seasonPass', 'mountSeasonTrack', 'weeklyEvent']) {
      expect(GENRE_BLOCKS[n].only, n).toBeUndefined();
      for (const [g, sub] of [['action', null], ['action', 'roguelite'], ['idle', null]] as const) expect(blocksFor(g, sub).map((b) => b.name), `${g}/${sub}: ${n}`).toContain(n);
    }
    const g = { genre: 'puzzle' as const, sub: null, from: 'money.genre puzzle', named: true, source: '' };
    expect(genreChecks({ ...g, imported: ['seasonPass', 'weeklyEvent'] }).filter((i) => i.code === 'W_GENRE_BLOCK')).toEqual([]);
  });
  it('the table blocks (Zones, Board, Dice, Automa) fit puzzles, strategy, roguelites and deckbuilders, and warn nowhere', () => {
    const fits: [Parameters<typeof blocksFor>[0], Parameters<typeof blocksFor>[1], string[]][] = [
      ['puzzle', null, ['Board', 'Dice']],
      ['strategy', null, ['Zones', 'Board', 'Dice', 'Automa']],
      ['action', 'roguelite', ['Zones', 'Board', 'Dice']],
      ['strategy', 'deckbuilder', ['Zones', 'Automa']],
    ];
    for (const [g, sub, names] of fits) for (const n of names) expect(blocksFor(g, sub).map((b) => b.name), `${g}/${sub}: ${n}`).toContain(n);
    for (const n of ['Zones', 'Board', 'Dice', 'Automa']) expect(GENRE_BLOCKS[n].only, n).toBeUndefined();
    expect(blocksFor('strategy', 'deckbuilder')[0].name).toBe('Zones');
    expect(moneyGenre('deckbuilder')).toBe('strategy');
    expect(gameGenre({ kit: 'code', audience: 'general', tags: ['Deckbuilder'] })).toMatchObject({ genre: 'strategy', sub: 'deckbuilder' });
    // a deckbuilder without a deck or an intent hears about both
    const hint = genreChecks({ genre: 'strategy', sub: 'deckbuilder', from: 'money.genre deckbuilder', named: true, imported: ['RunChoices', 'PactTree', 'levelOpen'], source: 'const stages = 3;' });
    expect(hint.map((i) => i.code)).toEqual(['I_GENRE_EXPECTS']);
    expect(hint[0].message).toContain('[Zones]');
    expect(hint[0].message).toContain('[Automa]');
    expect(genreChecks({ genre: 'strategy', sub: 'deckbuilder', from: 'money.genre deckbuilder', named: true, imported: ['Zones', 'Automa', 'RunChoices', 'PactTree', 'levelOpen', 'newRunSeed'], source: 'const preview = 1;' })).toEqual([]);
  });
});

describe('what the code shows', () => {
  it('reads the names imported from @gp/*, not types, aliases or the game\'s own files', () => {
    const src = [
      "import { UpgradeShop, mountUpgradeShop as shop, type ShopRow } from '@gp/core';",
      "import type { RunSeed } from '@gp/core/seed';",
      "import { Camera } from '@gp/art/camera';",
      "import { offlineEarnings } from './offline.ts';",
      "// import { Prestige } from '@gp/core';",
    ].join('\n');
    expect(importedBlocks(src).sort()).toEqual(['Camera', 'UpgradeShop', 'mountUpgradeShop']);
  });
  it('W_GENRE_BLOCK: an idle block in an action game', () => {
    const g = { genre: 'action' as const, sub: null, from: 'money.genre action', named: true, source: '' };
    const w = genreChecks({ ...g, imported: ['offlineEarnings', 'Roster'] }).filter((i) => i.code === 'W_GENRE_BLOCK');
    expect(w).toHaveLength(1);
    expect(w[0].message).toContain('offlineEarnings');
    expect(w[0].fix).toContain('money.genre: idle');
    expect(genreChecks({ ...g, genre: 'idle', imported: ['offlineEarnings'] }).filter((i) => i.code === 'W_GENRE_BLOCK')).toEqual([]);
  });
  it("I_GENRE_EXPECTS: the genre's must-haves the code doesn't have — met by a block, the game's own code or the money design", () => {
    const idle = { genre: 'idle' as const, sub: null, from: 'money.genre idle', named: true };
    const bare = genreChecks({ ...idle, imported: ['UpgradeShop'], source: 'const coins = 0;' });
    expect(bare.map((i) => i.code)).toEqual(['I_GENRE_EXPECTS']);
    expect(bare[0].severity).toBe('info');
    expect(bare[0].message).toContain('offline earnings');
    expect(bare[0].message).toContain('prestige');
    expect(bare[0].message).toContain('after the first session');
    expect(bare[0].message).not.toContain('a level shop');
    // its own offline earnings and prestige count; a commented one doesn't
    expect(genreChecks({ ...idle, imported: ['UpgradeShop'], source: 'function offlineGain() {}\nconst prestige = 1;' })).toEqual([]);
    expect(genreChecks({ ...idle, imported: ['UpgradeShop', 'offlineEarnings'], source: '// prestige later' })[0].message).toContain('prestige');
    // a puzzle's hint is a rewarded offer
    const puzzle = { genre: 'puzzle' as const, sub: null, from: 'money.genre puzzle', named: true, imported: ['levelOpen', 'recordStars', 'UndoHistory'], source: '' };
    expect(genreChecks({ ...puzzle, money: { rewarded: [{ placement: 'hint', kind: 'hint', gives: 'one good move' }] } })).toEqual([]);
    expect(genreChecks(puzzle)[0].message).toContain('a hint when stuck');
    // a roguelite adds the seed and run choices to action's
    const rogue = genreChecks({ genre: 'action', sub: 'roguelite', from: 'money.genre roguelite', named: true, imported: ['Roster'], source: 'boss(); revive();' });
    expect(rogue[0].message).toContain('run seed');
    expect(rogue[0].message).toContain('RunChoices');
    // a genre the game never named (the kit's guess) asks for nothing
    expect(genreChecks({ genre: 'hypercasual', sub: null, from: 'kit', named: false, imported: [], source: '' })).toEqual([]);
  });
  it('the genre: money.genre (a sub-genre too), else listing.tags; the sub-genre from a tag', () => {
    expect(gameGenre({ kit: 'code', audience: 'general', money: { genre: 'roguelite' } })).toMatchObject({ genre: 'action', sub: 'roguelite', named: true });
    expect(gameGenre({ kit: 'code', audience: 'general', money: { genre: 'action' }, tags: ['Roguelike'] })).toMatchObject({ genre: 'action', sub: 'roguelite' });
    expect(gameGenre({ kit: 'code', audience: 'general', tags: ['Tower Defense'] })).toMatchObject({ genre: 'strategy', sub: 'tower-defense', named: true });
    expect(gameGenre({ kit: 'code', audience: 'general' })).toMatchObject({ genre: 'other', named: false });
  });
});

describe('money.genre and the CLI take a sub-genre', () => {
  const CODE = readFileSync(new URL('../../../docs/examples/code/game.yaml', import.meta.url), 'utf8');
  it('money.genre: roguelite is valid and benchmarked as action; an unknown genre is E_MONEY', () => {
    const ok = validateText(CODE.replace('genre: hypercasual', 'genre: roguelite'), { mode: 'dev' });
    expect(ok.issues.filter((i) => i.severity === 'error')).toEqual([]);
    const bad = validateText(CODE.replace('genre: hypercasual', 'genre: rogue'), { mode: 'dev' });
    expect(bad.issues.find((i) => i.code === 'E_MONEY')?.fix).toContain('roguelite (action)');
    expect(ideaDesign({ channel: 'crazygames', genre: 'tycoon' }).design.genre).toBe('idle');
    expect(ideaDesign({ channel: 'crazygames', genre: 'nope' }).issues[0]).toContain('roguelite');
  });
  it('deckbuilder: a strategy sub-genre with its own must-haves (draft, the deck, a preview before the commit, a seed), no stages; its own title hooks (Velvet Domino Rogue)', () => {
    expect(moneyGenre('deckbuilder')).toBe('strategy');
    expect(SUBGENRE_INFO.deckbuilder.genre).toBe('strategy');
    const must = expectationsFor('strategy', 'deckbuilder').map((e) => e.id);
    expect(must).toEqual(expect.arrayContaining(['draft', 'deck', 'preview', 'seed', 'pacts']));
    expect(must).not.toContain('stages');
    expect(expectationsFor('strategy').map((e) => e.id)).toContain('stages');
    expect(gameGenre({ kit: 'code', audience: 'general', money: { genre: 'strategy' }, tags: ['Deckbuilder'] })).toMatchObject({ genre: 'strategy', sub: 'deckbuilder' });
    // W_TITLE_HOOK offers a deckbuilder the card words, not "defense" and "tower"
    const deck = CODE.replace('genre: hypercasual', 'genre: deckbuilder');
    const hook = validateText(deck.replace(/^title: .*$/m, 'title: "Dominorum"'), { mode: 'dev' }).issues.find((i) => i.code === 'W_TITLE_HOOK')!;
    expect(hook.message).toMatch(/a deckbuilder player/);
    expect(hook.fix).toMatch(/deckbuilder hook \((deck|card|deckbuilder), /);
    expect(hook.fix).not.toMatch(/\(defense/);
    expect(validateText(deck.replace(/^title: .*$/m, 'title: "Domino Deck"'), { mode: 'dev' }).issues.find((i) => i.code === 'W_TITLE_HOOK')).toBeUndefined();
  });
  it('gp explain: genre.<id>, a bare sub-genre, the list; a bare "kids" stays the kit', () => {
    const idle = explain('genre.idle')!;
    expect(idle).toContain('offlineEarnings');
    expect(idle).toContain('[idle only]');
    expect(idle).toContain('Sub-genres');
    expect(explain('roguelite')).toContain('sub-genre of action');
    expect(explain('genre.action')).toContain('Not for action (W_GENRE_BLOCK): offlineEarnings');
    expect(explain('genres')).toContain('tower-defense');
    expect(explain('kids')).toMatch(/^kit: kids/);
    expect(explain('W_GENRE_BLOCK')).toContain('idle');
    expect(explain('I_GENRE_EXPECTS')).toContain('must-have');
  });
});
