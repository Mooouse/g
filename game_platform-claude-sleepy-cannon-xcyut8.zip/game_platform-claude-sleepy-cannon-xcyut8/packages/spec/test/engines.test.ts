// game.yaml `engine` (kit: code): the engines with an adapter, the versions each adapter supports, Kaplay refused with
// the engine lab's reasons. The CLI's half (the game's package.json and node_modules agree) is in packages/cli/test.

import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import type { CodeConfig } from '@gp/kit-code/meta';
import { ENGINES, PHYSICS, engineSupports, validateText } from '../src/index.ts';

const CODE = readFileSync(new URL('../../../docs/examples/code/game.yaml', import.meta.url), 'utf8');
const withEngine = (line: string) => CODE.replace('\nkit: code\n', `\nkit: code\n${line}\n`);
const check = (line: string) => validateText(withEngine(line), { mode: 'dev' });
const issue = (line: string, code: string) => check(line).issues.find((i) => i.code === code);

describe('engine', () => {
  it('canvas needs no version; pixi, phaser and three resolve with their package', () => {
    expect((check('engine: { name: canvas }').game!.kit as CodeConfig).engine).toEqual({ name: 'canvas', version: null, package: null });
    for (const [name, version, pkg] of [['pixi', '8.21.0', 'pixi.js'], ['phaser', '4.2.1', 'phaser'], ['three', '0.186.1', 'three']]) {
      const r = check(`engine: { name: ${name}, version: ${version} }`);
      expect(r.ok, JSON.stringify(r.issues)).toBe(true);
      expect((r.game!.kit as CodeConfig).engine).toEqual({ name, version, package: pkg });
    }
    // Without an engine section: as before
    expect((validateText(CODE, { mode: 'dev' }).game!.kit as CodeConfig).engine).toBeNull();
  });

  it('kaplay (and anything else) is refused, with the reason', () => {
    const k = issue('engine: { name: kaplay, version: 3001.0.19 }', 'E_ENGINE_UNSUPPORTED')!;
    expect(k.severity).toBe('error');
    expect(k.message).toContain('AudioContext');
    expect(k.fix).toContain('canvas, pixi, phaser, three');
    expect(issue('engine: { name: babylon }', 'E_ENGINE_UNSUPPORTED')).toBeTruthy();
    expect(issue('engine: { name: rapier }', 'E_ENGINE_UNSUPPORTED')!.message).toContain('physics');
  });

  it("a version outside the adapter's range, or none, is an error; canvas with a version a warning", () => {
    expect(issue('engine: { name: pixi, version: 7.4.2 }', 'E_ENGINE_VERSION')!.message).toContain('pixi.js 8.x');
    expect(issue('engine: { name: phaser, version: 3.90.0 }', 'E_ENGINE_VERSION')).toBeTruthy();
    expect(issue('engine: { name: three, version: 0.150.0 }', 'E_ENGINE_VERSION')).toBeTruthy();
    expect(issue('engine: { name: three, version: 0.200.0 }', 'E_ENGINE_VERSION')).toBeTruthy();
    expect(issue('engine: { name: pixi }', 'E_ENGINE_VERSION')!.fix).toContain('8.21.0');
    // A range is not a pin
    expect(check('engine: { name: pixi, version: "^8.21.0" }').ok).toBe(false);
    expect(issue('engine: { name: canvas, version: 1.0.0 }', 'W_ENGINE_VERSION')!.severity).toBe('warning');
  });

  it('three: a hint that it needs WebGL2', () => {
    expect(issue('engine: { name: three, version: 0.186.1 }', 'I_ENGINE_WEBGL2')!.severity).toBe('info');
    expect(issue('engine: { name: pixi, version: 8.21.0 }', 'I_ENGINE_WEBGL2')).toBeUndefined();
  });

  it('the supported ranges include the versions the lab measured and gp init pins', () => {
    for (const e of Object.values(ENGINES)) if (e.tested) expect(engineSupports(e, e.tested), e.id).toBe(true);
    expect(engineSupports(ENGINES.pixi, '8.0.0')).toBe(true);
    expect(engineSupports(ENGINES.pixi, '9.0.0')).toBe(false);
    expect(engineSupports(ENGINES.three, '0.163.0')).toBe(true);
  });

  it('only for kit: code', () => {
    const BALLOON = readFileSync(new URL('../../../docs/examples/kids/game.yaml', import.meta.url), 'utf8');
    expect(validateText(`${BALLOON}\nengine: { name: canvas }\n`, { mode: 'dev' }).issues.map((i) => i.code)).toContain('E_UNKNOWN_FIELD');
  });
  it('the browser tests run each adapter and the physics block on the very version gp init pins (packages/core/test-browser/engines-real)', () => {
    const pkg = JSON.parse(readFileSync(new URL('../../core/test-browser/engines-real/package.json', import.meta.url), 'utf8')) as { dependencies: Record<string, string> };
    const pinned = [...Object.values(ENGINES).filter((e) => e.package).map((e) => [e.package, e.tested]), ...Object.values(PHYSICS).map((p) => [p.package, p.tested])];
    expect(Object.entries(pkg.dependencies).sort()).toEqual(pinned.sort());
  });
});

describe('engine.physics', () => {
  const budget = (yaml: string, kb: number) => yaml.replace('\nkit: code\n', `\nkit: code\nbudget: { gzipKB: ${kb} }\n`);
  it('rapier2d and rapier2d-deterministic resolve with their -compat package, beside any engine', () => {
    for (const [name, pkg] of [['rapier2d', '@dimforge/rapier2d-compat'], ['rapier2d-deterministic', '@dimforge/rapier2d-deterministic-compat']]) {
      const r = validateText(budget(withEngine(`engine: { name: canvas, physics: { name: ${name}, version: 0.21.0 } }`), 1500), { mode: 'dev' });
      expect(r.ok, JSON.stringify(r.issues)).toBe(true);
      expect(r.issues.map((i) => i.code)).not.toContain('W_PHYSICS_BUDGET');
      const kit = r.game!.kit as CodeConfig;
      expect(kit.physics).toEqual({ name, version: '0.21.0', package: pkg });
      expect(kit.engine).toEqual({ name: 'canvas', version: null, package: null });
    }
    expect((check('engine: { name: pixi, version: 8.21.0, physics: { name: rapier2d, version: 0.21.0 } }').game!.kit as CodeConfig).physics?.package).toBe('@dimforge/rapier2d-compat');
    // None declared: null
    expect((check('engine: { name: canvas }').game!.kit as CodeConfig).physics).toBeNull();
  });

  it('another library is refused; the version is required and must be in the block’s range (0.21.x)', () => {
    expect(issue('engine: { name: canvas, physics: { name: matter } }', 'E_PHYSICS_UNSUPPORTED')!.fix).toContain('rapier2d');
    expect(issue('engine: { name: canvas, physics: { name: rapier2d } }', 'E_PHYSICS_VERSION')!.fix).toContain('0.21.0');
    expect(issue('engine: { name: canvas, physics: { name: rapier2d, version: 0.20.0 } }', 'E_PHYSICS_VERSION')!.message).toContain('0.21.x');
    expect(issue('engine: { name: canvas, physics: { name: rapier2d, version: 0.22.0 } }', 'E_PHYSICS_VERSION')).toBeTruthy();
    expect(check('engine: { name: canvas, physics: { name: rapier2d, version: "^0.21.0" } }').ok).toBe(false);
    expect(check('engine: { name: canvas, physics: { name: rapier2d, version: 0.21.0, gravity: 9 } }').issues.map((i) => i.code)).toContain('E_UNKNOWN_FIELD');
    expect(engineSupports(PHYSICS.rapier2d, '0.21.3')).toBe(true);
    for (const p of Object.values(PHYSICS)) expect(engineSupports(p, p.tested), p.id).toBe(true);
  });

  it("over a portal's size budget: a warning that says how to raise it on purpose", () => {
    const w = issue('engine: { name: canvas, physics: { name: rapier2d, version: 0.21.0 } }', 'W_PHYSICS_BUDGET')!;
    expect(w.severity).toBe('warning');
    expect(w.message).toContain('400 KB');
    expect(w.fix).toContain('budget: { gzipKB: 1500 }');
    const low = validateText(budget(withEngine('engine: { name: canvas, physics: { name: rapier2d, version: 0.21.0 } }'), 800), { mode: 'dev' });
    expect(low.issues.find((i) => i.code === 'W_PHYSICS_BUDGET')!.message).toContain('game.yaml budget.gzipKB');
  });

  it('naming Rapier as the engine points to engine.physics', () => {
    for (const name of ['rapier', 'rapier2d']) expect(issue(`engine: { name: ${name} }`, 'E_ENGINE_UNSUPPORTED')!.message).toContain('physics: { name: rapier2d');
  });
});
