// The money model: ranges are ordered, it moves the right way with the design, it never counts more ads than the
// channel's policy lets through, children never get rewarded ads; the money section's checks; the calibration rule.

import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import {
  CHANNELS,
  MIN_PER_PLAY,
  MONEY_TABLE,
  PER_PLAY_SCALE,
  blend,
  calibrate,
  checkResults,
  BASIC_LAUNCH,
  deviceTotal,
  scoresLine,
  forecast,
  ideaDesign,
  levers,
  loadYaml,
  midgameAds,
  moneyDesign,
  resubmissionOf,
  resubmissions,
  revenuePerDay,
  rewardedKindOf,
  validateText,
  type Forecast,
  type IdeaInput,
  type Range,
  type RecordedResult,
} from '../src/index.ts';

const root = new URL('../../../', import.meta.url);
const read = (p: string) => readFileSync(new URL(p, root), 'utf8');
const idea = (i: Partial<IdeaInput>) => forecast(ideaDesign({ channel: 'crazygames', genre: 'action', ...i }).design);
const ordered = (r: Range) => r.low <= r.mid + 1e-9 && r.mid <= r.high + 1e-9;

function expectOrdered(f: Forecast) {
  for (const r of [f.pApproval, f.pFullLaunch, f.expected, f.unit.midgame, f.unit.rewarded, f.unit.eur, f.volume.range, f.revenueFromDay]) expect(ordered(r), JSON.stringify(r)).toBe(true);
  expect(f.total.pessimistic).toBeLessThanOrEqual(f.total.median);
  expect(f.total.median).toBeLessThanOrEqual(f.total.optimistic);
  for (const m of [0, 1, 2]) {
    expect(f.months.pessimistic[m]).toBeLessThanOrEqual(f.months.median[m] + 1e-9);
    expect(f.months.median[m]).toBeLessThanOrEqual(f.months.optimistic[m] + 1e-9);
  }
  for (const p of [f.pApproval, f.pFullLaunch]) expect(p.low >= 0 && p.high <= 1).toBe(true);
}

describe('the money table', () => {
  it('every row is a range in order, with a source, a confidence and a date', () => {
    for (const [id, r] of Object.entries(MONEY_TABLE)) {
      expect(r.low <= r.mid && r.mid <= r.high, id).toBe(true);
      expect(r.source.length, id).toBeGreaterThan(3);
      expect(['high', 'medium', 'low', 'very low', 'judgement'], id).toContain(r.confidence);
      expect(r.checked, id).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    }
  });
  it('carries the research numbers (docs/research/revenue-2026-09.md §7)', () => {
    expect(MONEY_TABLE['cg.share']).toMatchObject({ low: 0.45, mid: 0.5, high: 0.6, confidence: 'medium' });
    expect(MONEY_TABLE['cg.rewarded.ecpm']).toMatchObject({ low: 3, mid: 8, high: 15 });
    expect(MONEY_TABLE['cg.review.pass']).toMatchObject({ low: 0.1, mid: 0.4, high: 0.7, confidence: 'very low' });
    expect(MONEY_TABLE['gp.iap.buyRate']).toMatchObject({ low: 0.0005, mid: 0.003, high: 0.015 });
  });
});

describe('the model', () => {
  it('ranges are ordered: low ≤ mid ≤ high, pessimistic ≤ median ≤ optimistic', () => {
    for (const genre of ['puzzle', 'idle', 'action', 'hypercasual', 'strategy'])
      for (const breaks of [0, 2, 6, 12])
        for (const rewarded of [[], ['revive'], ['revive', 'x2', 'hint']]) expectOrdered(idea({ genre, breaks, rewarded, sessionMin: 14 }));
    expectOrdered(forecast(ideaDesign({ channel: 'android-families' }).design));
  });
  it('the median grows with the session, the breaks, the offers and the uniqueness — never falls', () => {
    const med = (i: Partial<IdeaInput>) => idea(i).total.median;
    let prev = -1;
    for (const sessionMin of [4, 8, 12, 16, 20]) {
      const v = med({ sessionMin, breaks: 6, rewarded: ['revive', 'x2'] });
      expect(v).toBeGreaterThanOrEqual(prev);
      prev = v;
    }
    prev = -1;
    for (const breaks of [0, 1, 2, 3, 4, 6, 9, 14]) {
      const v = med({ sessionMin: 15, breaks, rewarded: ['x2'] });
      expect(v).toBeGreaterThanOrEqual(prev);
      prev = v;
    }
    expect(med({ breaks: 5, rewarded: ['revive', 'x2'] })).toBeGreaterThan(med({ breaks: 5, rewarded: ['revive'] }));
    expect(med({ breaks: 5, rewarded: ['revive'] })).toBeGreaterThan(med({ breaks: 5, rewarded: [] }));
    prev = -1;
    for (const unique of [20, 55, 75, 90]) {
      const p = idea({ unique }).pApproval.mid;
      expect(p).toBeGreaterThanOrEqual(prev);
      prev = p;
    }
    // A daily reason to return and a long meta raise the odds of Full Launch; a short session lowers them
    expect(idea({ returns: 'daily' }).pFullLaunch.mid).toBeGreaterThan(idea({ returns: 'none' }).pFullLaunch.mid);
    expect(idea({ metaMin: 90 }).pFullLaunch.mid).toBeGreaterThan(idea({ metaMin: 3 }).pFullLaunch.mid);
    expect(idea({ sessionMin: 20 }).pFullLaunch.mid).toBeGreaterThan(idea({ sessionMin: 5 }).pFullLaunch.mid);
    expect(idea({ uploadMB: 30 }).pFullLaunch.mid).toBeLessThan(idea({ uploadMB: 5 }).pFullLaunch.mid);
  });
  it('revenue grows with an input\'s price (eCPM) and with the plays', () => {
    const base = idea({ breaks: 6, rewarded: ['revive', 'x2'] }).total.median;
    for (const id of ['cg.rewarded.ecpm', 'cg.midgame.ecpmMobile', 'cg.plays.steady', 'cg.share']) {
      const r = MONEY_TABLE[id];
      const was = r.mid;
      r.mid = was * 1.5;
      try {
        expect(idea({ breaks: 6, rewarded: ['revive', 'x2'] }).total.median, id).toBeGreaterThan(base);
      } finally {
        r.mid = was;
      }
    }
  });
  it('midgame ads are bounded by the channel\'s ad policy: none in the first 3 min, the first at the 3rd break or 5 min, then one per 3 min', () => {
    const cg = CHANNELS.crazygames.adPolicy!;
    // 1,000 breaks in 10 minutes: the first ad at 3 min (round 3 long past), then every 3 min → 3
    expect(midgameAds(cg, 10, 1000)).toBe(3);
    // Two breaks in a 30-min session (at 10 and 20 min): both past 5 min → 2; with the round rule alone, none
    expect(midgameAds(cg, 30, 2)).toBe(2);
    expect(midgameAds({ ...cg, firstAdAfterSec: undefined }, 30, 2)).toBe(0);
    // Runs of 4.33 min (13 min, 2 breaks): the first break (260 s) is before 5 min, the second (520 s) carries one
    expect(midgameAds(cg, 13, 2)).toBe(1);
    // Levels of 1.5 min: round 3 (270 s) comes before 5 min and gets the first ad
    expect(midgameAds(cg, 6, 3)).toBe(1);
    // A session of 0 min or a negative/NaN break count: 0, and no endless loop
    expect(midgameAds(cg, 0, 3)).toBe(0);
    expect(midgameAds(cg, 12, Number.NaN)).toBe(0);
    expect(midgameAds(cg, 12, 0)).toBe(0);
    for (const min of [5, 10, 20, 40]) expect(midgameAds(cg, min, 200)).toBeLessThanOrEqual(Math.floor((min * 60 - cg.noAdsAfterLaunchSec) / cg.minIntervalSec) + 1);
    // And per play no more than games achieve per player-hour
    const f = idea({ genre: 'puzzle', sessionMin: 21, breaks: 200 });
    expect(f.unit.midgame.mid).toBeLessThanOrEqual((MONEY_TABLE['cg.midgame.perHour'].mid * 21) / 60 + 1e-9);
    // Families: not in the first 60 s, not before round 2, then once per 2 rounds and 90 s
    const fam = CHANNELS['android-families'].adPolicy!;
    expect(midgameAds(fam, 5, 1000)).toBeLessThanOrEqual(Math.floor((300 - 60) / 90) + 1);
  });
  it('children never get rewarded ads, whatever the design says', () => {
    const { design } = ideaDesign({ channel: 'android-families', rewarded: ['revive', 'x2', 'hint'] });
    const f = forecast(design);
    expect(f.unit.rewarded).toEqual({ low: 0, mid: 0, high: 0 });
    expect(f.notes.join(' ')).toMatch(/no ads a child can choose/);
    // A child audience on any channel: still none
    const kidsWeb = forecast({ ...ideaDesign({ channel: 'crazygames', genre: 'action', rewarded: ['revive'] }).design, audience: 'ages-6-8' });
    expect(kidsWeb.unit.rewarded.high).toBe(0);
  });
  it('Google Play Families: interstitials and "Remove ads"; the purchase adds revenue', () => {
    const withIap = forecast(ideaDesign({ channel: 'android-families' }).design);
    const without = forecast(ideaDesign({ channel: 'android-families', removeAds: false }).design);
    expect(withIap.earns).toBe(true);
    expect(withIap.total.median).toBeGreaterThan(without.total.median);
    expect(withIap.stages.map((s) => s.name)).toEqual(['Google Play review', 'Organic installs']);
  });
  it('channels without ads earn nothing, and say why', () => {
    const web = forecast(ideaDesign({ channel: 'web', genre: 'puzzle' }).design);
    expect(web.earns).toBe(false);
    expect(web.why).toMatch(/no ad provider/);
    expect(web.expected.high).toBe(0);
    const android = forecast(ideaDesign({ channel: 'android', genre: 'puzzle' }).design);
    expect(android.why).toMatch(/consent/);
    // The lever: go where the ads are
    expect(levers(ideaDesign({ channel: 'web', genre: 'puzzle' }).design)[0].name).toMatch(/CrazyGames/);
  });
  it('CrazyGames: no revenue before Full Launch (review + Basic Launch + the second review)', () => {
    const f = idea({ breaks: 6, rewarded: ['revive'] });
    expect(f.revenueFromDay.low).toBe(1 + 7 + 2);
    expect(f.revenueFromDay.high).toBe(3 + 21 + 10);
    expect(f.months.pessimistic[0]).toBe(0);
    expect(f.expected.mid).toBeCloseTo(f.pApproval.mid * f.pFullLaunch.mid * f.total.median, 6);
  });
  it('levers: at most three, the biggest first, each adds expected value', () => {
    const lv = levers(ideaDesign({ channel: 'crazygames', genre: 'action', breaks: 1, rewarded: [] }).design);
    expect(lv.length).toBeGreaterThan(0);
    expect(lv.length).toBeLessThanOrEqual(3);
    for (let i = 1; i < lv.length; i++) expect(lv[i - 1].delta).toBeGreaterThanOrEqual(lv[i].delta);
    for (const l of lv) expect(l.delta).toBeGreaterThan(0);
  });
  it('idea mode: a pitch that reads like a taken concept lowers the review odds (Petri Panic)', () => {
    const pp = ideaDesign({ channel: 'crazygames', genre: 'action', pitch: 'A cell fights off germs in a survivors-like with auto-attack and level-up cards', title: 'Petri Panic' }).design;
    const own = ideaDesign({ channel: 'crazygames', genre: 'puzzle', pitch: 'Tap a face to mark each townsperson honest or a liar until the statements agree' }).design;
    // Three taken concepts (−15 each on the portal) take at most 25, as gp uniqueness does: 80 − 25 = 55
    expect(pp.uniqueness!.score).toBe(55);
    expect(own.uniqueness!.score).toBe(80);
    expect(forecast(pp).pApproval.mid).toBeLessThanOrEqual(forecast(own).pApproval.mid / 2 + 1e-9);
  });
  it('the design from a game: the money section first, then the code and the balance report', () => {
    const facts = { channel: 'crazygames', audience: 'general', kit: 'code', tags: ['Puzzle'], adsOn: true, rewardedOn: true, billing: false };
    const derived = moneyDesign(null, { ...facts, code: { rewarded: ['rise-again', 'double'], adBreak: true }, balanceMetaMin: 45 });
    expect(derived.genre).toBe('puzzle');
    expect(derived.rewarded.map((r) => [r.kind, r.per])).toEqual([['revive', 'session'], ['x2', 'run']]);
    expect(derived.metaMin).toBe(45);
    expect(derived.returns).toBe('meta');
    // No host.adBreak() in the code: no natural break
    expect(moneyDesign(null, { ...facts, code: { rewarded: [], adBreak: false } }).breaks).toBe(0);
    const written = moneyDesign({ genre: 'idle', session: { minutes: 20, breaks: 5 }, rewarded: [{ placement: 'offline', kind: 'boost', gives: 'welcome back ×2' }], returns: { kind: 'daily' } }, facts);
    expect(written).toMatchObject({ genre: 'idle', sessionMin: 20, breaks: 5, returns: 'daily' });
    expect(written.from.breaks).toBe('money.session.breaks');
    // balance.difficulty.winningRunMin declared: a session is a winning run, the breaks scaled to it
    const run = moneyDesign({ genre: 'action', session: { minutes: 15, breaks: 6 }, returns: { kind: 'meta' } }, { ...facts, winningRun: { minutes: 33, from: "balance(): the skilled bot's winning run, 33 min" } });
    expect(run).toMatchObject({ sessionMin: 33, breaks: 13 });
    expect(run.from.session).toMatch(/winning run, 33 min — balance.difficulty.winningRunMin is declared, so a session is a winning run \(in place of money.session.minutes 15\)/);
    expect(run.from.breaks).toBe("money.session.breaks 6 in 15 min, scaled to the winning run's 33 min");
  });
});

describe('the money section in game.yaml', () => {
  const CODE = read('docs/examples/code/game.yaml');
  const BALLOON = read('docs/examples/kids/game.yaml');
  const TEMPLATE = read('templates/game-repo/games/__ID__/game.yaml').replace(/__ID__/g, 'lantern-walk').replace(/__TITLE__/g, 'Lantern Walk');
  const codes = (text: string) => validateText(text, { mode: 'dev' }).issues.map((i) => i.code);
  const withMoney = (money: string) => CODE.replace(/money:\n(  .*\n)+/, money.endsWith('\n') ? money : `${money}\n`);
  it('the example has one and the template has it as TODO (E_MONEY, like E_CONCEPT)', () => {
    expect(codes(CODE)).not.toContain('E_MONEY');
    expect(codes(TEMPLATE)).toContain('E_MONEY');
  });
  it('a portal code game without it: a warning, never an error (old games keep validating)', () => {
    const none = CODE.replace(/money:\n(  .*\n)+/, '');
    const issues = validateText(none, { mode: 'dev' }).issues;
    expect(issues.find((i) => i.code === 'W_MONEY_MISSING')?.severity).toBe('warning');
    expect(issues.some((i) => i.severity === 'error')).toBe(false);
    // The YAML kits and Google Play games are not asked
    expect(validateText(read('docs/examples/casual.game.yaml'), { mode: 'dev' }).issues).toEqual([]);
    expect(codes(BALLOON)).not.toContain('W_MONEY_MISSING');
  });
  it('TODO, an unknown genre and a placement listed twice are errors', () => {
    expect(codes(withMoney('money:\n  genre: TODO pick one\n'))).toContain('E_MONEY');
    expect(codes(withMoney('money:\n  genre: rhythm\n'))).toContain('E_MONEY');
    expect(codes(withMoney('money:\n  rewarded:\n    - { placement: revive, kind: revive, gives: "one more life" }\n    - { placement: revive, kind: x2, gives: "double the coins" }\n'))).toContain('E_MONEY');
    expect(codes(withMoney('money:\n  rewarded:\n    - { placement: revive, kind: free-coins, gives: "coins" }\n'))).toContain('E_ENUM');
  });
  it('no break and no offer on a paying channel: the one error — unless ads are off', () => {
    const none = withMoney('money:\n  session: { minutes: 12, breaks: 0 }\n  rewarded: []\n');
    expect(codes(none)).toContain('E_MONEY_NONE');
    expect(codes(none + 'monetization:\n  ads: { enabled: false }\n')).not.toContain('E_MONEY_NONE');
    // Offers only: a warning that no midgame ad can be shown
    expect(codes(withMoney('money:\n  session: { minutes: 12, breaks: 0 }\n  rewarded:\n    - { placement: revive, kind: revive, gives: "one more life" }\n'))).toContain('W_MONEY_BREAKS');
  });
  it('warnings for what the gates read: long stretches without a break, short sessions, a short meta, no reason to return', () => {
    expect(codes(withMoney('money:\n  session: { minutes: 60, breaks: 1 }\n'))).toContain('W_MONEY_BREAK_GAP');
    expect(codes(withMoney('money:\n  session: { minutes: 7, breaks: 3 }\n'))).toContain('W_MONEY_SESSION');
    expect(codes(withMoney('money:\n  session: { minutes: 15, breaks: 5 }\n  meta: { minutes: 8 }\n'))).toContain('W_MONEY_META');
    // CrazyGames: no return is an error (E_MONEY_RETURN) — kind none or no `returns` at all; another channel is not asked
    const none = validateText(withMoney('money:\n  returns: { kind: none }\n'), { mode: 'dev' }).issues;
    expect(none.find((i) => i.code === 'E_MONEY_RETURN')).toMatchObject({ severity: 'error', path: ['money', 'returns'] });
    expect(none.map((i) => i.code)).not.toContain('W_MONEY_RETURN');
    expect(codes(withMoney('money:\n  genre: puzzle\n'))).toContain('E_MONEY_RETURN');
    expect(codes(withMoney('money:\n  returns: { kind: daily, what: "a new seeded run every day" }\n'))).not.toContain('E_MONEY_RETURN');
    expect(codes(withMoney('money:\n  returns: { kind: none }\n').replace('channel: crazygames', 'channel: web'))).not.toContain('E_MONEY_RETURN');
    const good = codes(withMoney('money:\n  genre: puzzle\n  session: { minutes: 18, breaks: 7, breaksAt: "level end → Next level" }\n  rewarded:\n    - { placement: hint, kind: hint, gives: "shows one good move" }\n  meta: { minutes: 120 }\n  returns: { kind: daily, what: "a new night every day" }\n'));
    expect(good.filter((c) => c.includes('MONEY'))).toEqual([]);
  });
  it('rewarded offers where there are none: children never, channels without rewarded ads, rewarded switched off', () => {
    const kids = BALLOON + 'money:\n  rewarded:\n    - { placement: more, kind: x2, gives: "more stickers" }\n';
    expect(codes(kids)).toContain('E_REWARDED_UNSUPPORTED');
    const web = withMoney('money:\n  rewarded:\n    - { placement: revive, kind: revive, gives: "one more life" }\n').replace('channel: crazygames', 'channel: web');
    expect(codes(web + 'monetization:\n  ads: { enabled: false }\n')).toContain('E_REWARDED_UNSUPPORTED');
    const off = withMoney('money:\n  rewarded:\n    - { placement: revive, kind: revive, gives: "one more life" }\n') + 'monetization:\n  ads: { rewarded: false }\n';
    expect(codes(off)).toContain('W_MONEY_REWARDED_OFF');
  });
  it('kids: a price for "Remove ads" needs the purchase', () => {
    expect(codes(BALLOON + 'money:\n  removeAdsPrice: 2.99\n')).not.toContain('W_MONEY_IAP');
    expect(codes(BALLOON.replace('removeAds: { product: remove_ads }', 'removeAds: false') + 'money:\n  removeAdsPrice: 2.99\n')).toContain('W_MONEY_IAP');
  });
});

describe('calibration from recorded results', () => {
  const rejected = (game: string): RecordedResult => ({ game, channel: 'crazygames', genre: 'action', review: { verdict: 'rejected' } });
  it('publisher/results.yaml is valid and holds Petri Panic\'s rejection', () => {
    const data = loadYaml(read('publisher/results.yaml')).data as { results: RecordedResult[] };
    expect(checkResults(data)).toEqual([]);
    expect(data.results.find((r) => r.game === 'petri-panic')).toMatchObject({ channel: 'crazygames', review: { verdict: 'rejected' } });
    const rep = calibrate(data.results, 'crazygames');
    const pp = rep.comparisons.find((c) => c.game === 'petri-panic')!;
    // The retro-forecast from its concept (a taken genre + theme: uniqueness 55) gave it a low chance, half an own
    // concept's: the model leans the verdict's way (D65: ≈ 24%)
    expect(Number(pp.predicted.match(/(\d+)%/)![1])).toBeLessThan(30);
    // The owner's dashboard (2026-10-01) added six verdicts: from 3 reviews the approval range is pulled toward the
    // recorded rate, and every recorded verdict gets its Brier term
    expect(rep.brier!).toBeLessThan(0.25);
    expect(rep.comparisons.filter((c) => c.what === 'review').length).toBe(data.results.filter((r) => r.review && r.review.verdict !== 'pending').length);
    expect(rep.calibration.approval).toBeDefined();
  });
  it('the Basic Launch score screen: per device class, raw values and scores 1–5; the total must add up; Candle Crypt\'s 2026-10-10 screen', () => {
    const data = loadYaml(read('publisher/results.yaml')).data as { results: RecordedResult[] };
    const candle = data.results.find((r) => r.game === 'candle-crypt')!;
    expect(candle.basicLaunch!.scores!.desktop).toMatchObject({ playtime: { value: 9.52, score: 4 }, d1: { value: 0.0296, score: 2 }, conversion: { value: 0.5125, score: 1 }, total: 7 });
    expect(deviceTotal(candle.basicLaunch!.scores!.desktop)).toBe(7);
    expect(deviceTotal(candle.basicLaunch!.scores!.mobile)).toBe(9);
    expect(scoresLine(candle.basicLaunch!.scores)).toBe('Desktop 7/15 (playtime 4 · D1 2 · conversion 1), Mobile 9/15 ✓ (playtime 5 · D1 3 · conversion 1)');
    expect(deviceTotal({ playtime: { score: 3 } })).toBeNull();
    const rec = (desktop: unknown, extra: object = {}) => ({ results: [{ game: 'x-game', channel: 'crazygames', ...extra, basicLaunch: { scores: { date: '2026-10-10', desktop } } }] });
    expect(checkResults(rec({ playtime: { value: 6.5, score: 3 }, d1: { score: 2 }, conversion: { score: 2 }, total: 7 }, { category: 'Puzzle' }))).toEqual([]);
    expect(checkResults(rec({ playtime: { score: 3 }, d1: { score: 2 }, conversion: { score: 2 }, total: 9 })).map((i) => i.code)).toEqual(['E_RESULTS_SCORES']);
    expect(checkResults(rec({ playtime: { score: 6 } })).map((i) => i.code)).toContain('E_RANGE');
    expect(checkResults(rec({ conversion: { value: 51 } })).map((i) => i.code)).toContain('E_RANGE');
    expect(BASIC_LAUNCH).toMatchObject({ fullLaunchAt: 9, of: 15 });
  });
  it('the schema catches a wrong verdict, a share over 1 and an unknown field', () => {
    expect(checkResults({ results: [{ game: 'x-game', channel: 'crazygames', review: { verdict: 'maybe' } }] }).map((i) => i.code)).toContain('E_ENUM');
    expect(checkResults({ results: [{ game: 'x-game', channel: 'crazygames', basicLaunch: { d1: 12 } }] }).map((i) => i.code)).toContain('E_RANGE');
    expect(checkResults({ results: [{ game: 'x-game', channel: 'crazygames', revenue: 3 }] }).map((i) => i.code)).toContain('E_UNKNOWN_FIELD');
  });
  it('blend: each end moves toward what was observed by n / (n + 3)', () => {
    expect(blend({ low: 0, mid: 0.5, high: 1 }, { low: 0.2, mid: 0.2, high: 0.2 }, 3)).toEqual({ low: 0.1, mid: 0.35, high: 0.6 });
  });
  it('from 3 verdicts of a kind the odds narrow toward them; fewer change nothing', () => {
    const d = ideaDesign({ channel: 'crazygames', genre: 'puzzle', unique: 80 }).design;
    const base = forecast(d).pApproval;
    const two = calibrate([rejected('a-game'), rejected('b-game')], 'crazygames');
    expect(forecast(d, two.calibration).pApproval).toEqual(base);
    const three = calibrate([rejected('a-game'), rejected('b-game'), rejected('c-game')], 'crazygames');
    const after = forecast(d, three.calibration).pApproval;
    expect(after.mid).toBeLessThan(base.mid);
    expect(after.high).toBeLessThan(base.high);
    expect(ordered(after)).toBe(true);
    // Other channels' results don't count
    expect(calibrate([rejected('a-game'), rejected('b-game'), rejected('c-game')], 'android-families').calibration.approval).toBeUndefined();
  });
  it('a resubmission after a Basic Launch stop or a rejection: P(approval) capped by the recorded resubmissions (4 of 5 after a stop rejected)', () => {
    const data = loadYaml(read('publisher/results.yaml')).data as { results: RecordedResult[] };
    // The history: five games sent again after their Basic Launch stopped, one approved
    const again = resubmissions(data.results, 'crazygames').filter((x) => x.kind === 'after-stop' && x.verdict !== 'pending');
    expect(again.map((x) => `${x.game}:${x.verdict}`).sort()).toEqual(['candle-crypt:rejected', 'garage-evolution:rejected', 'hang-the-moon:approved', 'spin-brawl:rejected', 'starsilk:rejected']);
    // A game's next submission from its latest record: a stopped one, a rejected one, an approved one still in Basic Launch
    expect(resubmissionOf(data.results, 'starsilk', 'crazygames')?.kind).toBe('after-rejection');
    expect(resubmissionOf(data.results, 'dread-throne', 'crazygames')?.kind).toBe('after-stop');
    expect(resubmissionOf(data.results, 'hang-the-moon', 'crazygames')?.kind).toBe('after-stop'); // its second Basic Launch stopped too (2026-10-19)
    expect(resubmissionOf(data.results, 'a-new-game', 'crazygames')).toBeNull();
    const cal = calibrate(data.results, 'crazygames');
    expect(cal.calibration.resubmission?.['after-stop']).toBeDefined();
    expect(cal.calibration.notes.join('\n')).toMatch(/after a Basic Launch stop: 1 of 5 approved/);
    const d = ideaDesign({ channel: 'crazygames', genre: 'puzzle', unique: 90 }).design;
    const fresh = forecast(d, cal.calibration);
    const stopped = forecast({ ...d, resubmission: 'after-stop' }, cal.calibration);
    const rejected = forecast({ ...d, resubmission: 'after-rejection' }, cal.calibration);
    expect(stopped.pApproval.mid).toBeLessThanOrEqual(0.25 + 1e-9);
    expect(stopped.pApproval.mid).toBeLessThan(fresh.pApproval.mid);
    expect(rejected.pApproval.mid).toBeLessThanOrEqual(MONEY_TABLE['cg.resubmit.afterReject'].mid);
    expect(ordered(stopped.pApproval) && ordered(rejected.pApproval)).toBe(true);
    expect(stopped.notes.join('\n')).toMatch(/resubmission after a Basic Launch stop/);
    expect(stopped.used).toContain('cg.resubmit.afterStop');
    expect(stopped.expected.mid).toBeLessThan(fresh.expected.mid);
  });
  it('recorded plays and revenue pull the volumes and the per-play revenue; predictions are compared', () => {
    const r = (game: string, plays: number, rev: number): RecordedResult => ({ game, channel: 'crazygames', genre: 'idle', fullLaunch: { playsPerDay: plays, revenuePerDayEUR: rev }, predicted: { revenuePerDay: [0.5, 5, 50] } });
    const rep = calibrate([r('a-game', 400, 2), r('b-game', 600, 3), r('c-game', 800, 4)], 'crazygames');
    const d = ideaDesign({ channel: 'crazygames', genre: 'idle', breaks: 4, rewarded: ['revive'] }).design;
    expect(forecast(d, rep.calibration).volume.range.mid).toBeLessThan(forecast(d).volume.range.mid);
    expect(rep.calibration.perPlayScale).toBeDefined();
    expect(rep.comparisons.filter((c) => c.what === 'revenue/day')).toHaveLength(3);
    expect(rep.comparisons[0].actual).toMatch(/inside the range/);
  });
});

describe('review findings (each a regression test)', () => {
  it('calibration: a game the model says earns ~nothing is left out of the per-play scale; the scale stays within ×0.1–×10', () => {
    const r = (game: string, plays: number, rev: number, design: Partial<RecordedResult> = {}): RecordedResult => ({ game, channel: 'crazygames', genre: 'idle', fullLaunch: { playsPerDay: plays, revenuePerDayEUR: rev }, ...design });
    // No breaks, no rewarded offers: the retro-forecast's per-play revenue is 0 — dividing by it scaled everything ×2,500,000
    const none = { breaks: 0, rewarded: [] as string[] };
    const zero = calibrate([r('a-game', 500, 2, none), r('b-game', 500, 3, none), r('c-game', 500, 4, none)], 'crazygames');
    expect(zero.calibration.perPlayScale).toBeUndefined();
    expect(zero.calibration.notes.join(' ')).toMatch(/left out of the per-play scale/);
    // A real design earning 1,000× what the model says: clamped to ×10
    const rich = calibrate([r('a-game', 100, 1000, { sessionMin: 15, breaks: 5 }), r('b-game', 100, 2000, { sessionMin: 15, breaks: 5 }), r('c-game', 100, 3000, { sessionMin: 15, breaks: 5 })], 'crazygames');
    const k = rich.calibration.perPlayScale!;
    expect(k.high).toBeLessThanOrEqual(PER_PLAY_SCALE.max);
    expect(k.low).toBeGreaterThanOrEqual(PER_PLAY_SCALE.min);
    expect(MIN_PER_PLAY).toBeCloseTo(0.1 / 1000, 12);
    // The design fields are in the schema; a fractional break count is not
    expect(checkResults({ results: [{ game: 'x-game', channel: 'crazygames', sessionMin: 14, breaks: 4, rewarded: ['revive', 'x2'], review: { verdict: 'pending' } }] })).toEqual([]);
    expect(checkResults({ results: [{ game: 'x-game', channel: 'crazygames', breaks: 1.5 }] }).length).toBeGreaterThan(0);
  });
  it('idea mode refuses numbers that mean nothing (a 0-min session hung the model) and the loops are guarded', () => {
    expect(ideaDesign({ channel: 'crazygames', genre: 'puzzle', sessionMin: 0, breaks: 3 }).issues.join(' ')).toMatch(/--session 0/);
    expect(ideaDesign({ channel: 'crazygames', genre: 'puzzle', breaks: 1.5 }).issues.join(' ')).toMatch(/--breaks 1.5/);
    expect(ideaDesign({ channel: 'crazygames', genre: 'puzzle', breaks: -1 }).issues.join(' ')).toMatch(/--breaks -1/);
    expect(ideaDesign({ channel: 'crazygames', genre: 'puzzle', unique: 120 }).issues.join(' ')).toMatch(/--unique 120/);
    expect(ideaDesign({ channel: 'crazygames', genre: 'puzzle', sessionMin: 12, breaks: 3 }).issues).toEqual([]);
    // The model itself, handed such a design, returns instead of looping
    const d = ideaDesign({ channel: 'crazygames', genre: 'puzzle', breaks: 3 }).design;
    expect(forecast({ ...d, sessionMin: 0 }).unit.midgame.mid).toBe(0);
  });
  it('idea mode: an audience the validator refuses on the channel, or an unknown one, is an error', () => {
    expect(ideaDesign({ channel: 'crazygames', audience: 'ages-2-5', genre: 'puzzle' }).issues.join(' ')).toMatch(/ages-2-5/);
    expect(ideaDesign({ channel: 'crazygames', audience: 'adults', genre: 'puzzle' }).issues.join(' ')).toMatch(/unknown audience "adults"/);
    expect(ideaDesign({ channel: 'android-families', audience: 'general' }).issues.join(' ')).toMatch(/child-directed/);
    expect(ideaDesign({ channel: 'android', audience: 'ages-6-8', genre: 'puzzle' }).issues.join(' ')).toMatch(/android-families/);
    expect(ideaDesign({ channel: 'crazygames', audience: 'general', genre: 'puzzle' }).issues).toEqual([]);
    expect(ideaDesign({ channel: 'android-families', audience: 'ages-6-8' }).issues).toEqual([]);
  });
  it('midgame and rewarded together: at most 20 per player-hour (midgame gets what rewarded leaves)', () => {
    const cap = MONEY_TABLE['cg.ads.maxPerHour'];
    const rwCap = MONEY_TABLE['cg.rewarded.maxPerHour'];
    // Rewarded offers at every one of 200 breaks: rewarded hits its 12 an hour, so the player's minutes are rw × 60 / 12
    const f = idea({ genre: 'puzzle', breaks: 200, rewarded: ['x2', 'hint', 'reroll', 'undo', 'boost'] });
    for (const k of ['low', 'mid', 'high'] as const) {
      const minutes = (f.unit.rewarded[k] * 60) / rwCap[k];
      expect(f.unit.midgame[k] + f.unit.rewarded[k]).toBeLessThanOrEqual((cap[k] * minutes) / 60 + 1e-9);
    }
    // Before the combined cap the optimistic end had 20 midgame + 12 rewarded an hour
    expect(f.unit.midgame.high).toBeLessThan((MONEY_TABLE['cg.midgame.perHour'].high * (f.unit.rewarded.high * 60) / rwCap.high) / 60);
  });
  it('revenue per day to record: month 2 ÷ 30 per scenario, on every channel (Google Play: active days and "Remove ads" in)', () => {
    for (const d of [ideaDesign({ channel: 'android-families' }).design, ideaDesign({ channel: 'crazygames', genre: 'idle', breaks: 4, rewarded: ['revive'] }).design]) {
      const f = forecast(d);
      expect(revenuePerDay(f)).toEqual({ low: f.months.pessimistic[1] / 30, mid: f.months.median[1] / 30, high: f.months.optimistic[1] / 30 });
    }
  });
  it('rewardedKindOf: whole words, the boost\'s welcome / offline first', () => {
    const cases: [string, string][] = [
      ['welcome-back', 'boost'],
      ['offline-back', 'boost'],
      ['offline_bonus', 'boost'],
      ['retry', 'continue'],
      ['surprise-box', 'other'],
      ['rise-again', 'revive'],
      ['revive', 'revive'],
      ['double', 'x2'],
      ['double-coins', 'x2'],
      ['hints', 'hint'],
      ['try-hero', 'trial'],
      ['undo', 'undo'],
      ['step-back', 'undo'],
      ['reroll-cards', 'reroll'],
      ['head-start', 'boost'],
      ['trophy', 'other'],
      ['wheel-spin', 'spin'],
      ['extra-spin', 'spin'],
      ['market-gems', 'currency'],
      ['free-coins', 'currency'],
      ['free-currency', 'currency'],
    ];
    for (const [p, kind] of cases) expect(rewardedKindOf(p), p).toBe(kind);
  });
});

it('CrazyGames: the steady month on Full Launch is plays a day × revenue a play × 30, and only for the portal', () => {
  const f = idea({ breaks: 4, rewarded: ['revive', 'x2'] });
  expect(f.perMonth).toBeDefined();
  expect(ordered(f.perMonth!)).toBe(true);
  expect(f.perMonth!.mid).toBeCloseTo(f.volume.range.mid * f.unit.eur.mid * 30, 6);
  expect(f.perMonth!.mid).toBeGreaterThan(0);
  const gp = forecast(ideaDesign({ channel: 'android-families', genre: 'action' }).design);
  expect(gp.perMonth).toBeUndefined();
});
