// How much story a game needs, as data: the depths, which kind of game supports which (docs/guides/story.md §1, the
// one place the table lives), and the checks of a story against its depth. Pure: the CLI loads the game's story file
// and hands its exports here (`gp validate`, `gp story`); resolve.ts checks the game.yaml `story` section.
// The evidence: docs/research/story-2026-09.md §1.6 and §3.5.

import { dueScene, formatStoryPath, loadStory, parseLine, STORY_LIMITS, storyState, validateStory, type Line, type StoryDef, type StoryLimits } from '@gp/core/story';
import type { Issue } from './errors.ts';
import type { AudienceProfile } from './profiles.ts';

export const STORY_DEPTHS = ['none', 'premise', 'barks', 'chapters', 'branching'] as const;
export type StoryDepth = (typeof STORY_DEPTHS)[number];
export const STORY_GENRES = ['action', 'idle', 'puzzle', 'choices'] as const;
export type StoryGenre = (typeof STORY_GENRES)[number];

export interface DepthInfo {
  title: string;
  what: string;
  /** Words to write (docs/guides/story.md §2) */
  words: readonly [number, number];
  /** What the game has to have for this depth */
  needs: string;
}

/** Each depth includes the ones before it (a chapters game has a premise, and usually barks too) */
export const DEPTH_INFO: Record<StoryDepth, DepthInfo> = {
  none: { title: 'No story', what: 'the game is its play', words: [0, 0], needs: 'nothing' },
  premise: { title: 'Premise', what: 'one line and one picture: who, what, why ("the pigs stole the eggs")', words: [1, 30], needs: '`story.premise` in game.yaml' },
  barks: { title: 'Barks', what: 'a character reacts to events in a bubble (≤ 60 characters), never blocking play: 50–200 barks', words: [300, 1500], needs: 'bark lists in the story file (`BARKS: { event: [lines] }`), a `Bag` per event and a cooldown in the game' },
  chapters: { title: 'Chapters as rewards', what: '6–12 short scenes unlocked by progress, played between runs, always skippable', words: [500, 2000], needs: 'a `StoryDef` in the story file, `mountDialogue`, the story state in the save' },
  branching: { title: 'Light branching', what: 'chapters where flags from choices change later lines; 2–3 endings', words: [650, 3200], needs: 'the chapters, plus flags (`do: { set }`), `if` on later lines and `ending`' },
};

/** Barks and chapters: the counts behind "too thin / too heavy" */
export const DEPTH_COUNTS = { premiseWords: 30, barkChars: 60, barksThin: 30, barksMax: 200, chaptersMin: 6, chaptersMax: 12, endingsMin: 2, endingsMax: 3, firstActionWords: 20 } as const;

/**
 * How a kind of game takes each depth: `default` (the recommendation), `yes` (fine), `max` (the most it supports, with
 * the note's limits), `weak` (allowed, but the game gains from more: an info hint when it has no story), `no` (outside
 * what it supports: a warning).
 */
export type FitCell = 'default' | 'yes' | 'max' | 'weak' | 'no';

export interface StoryFit {
  id: string;
  title: string;
  depths: Record<StoryDepth, FitCell>;
  /** What a cell means for this kind of game */
  notes: Partial<Record<StoryDepth, string>>;
  /** Chapters only when the game has meta progression (upgrades, unlocks between runs) */
  chaptersNeedMeta?: boolean;
  /** Every story line must be voiced (from depth barks up) */
  voiced?: boolean;
  /** Stricter limits for validateStory than the web 13+ STORY_LIMITS */
  limits?: Partial<StoryLimits>;
  /** Barks: at most this many words (kids 6–8 read slowly) */
  barkWords?: number;
}

/** The table of docs/guides/story.md §1. Web 13+ rows by genre, children's rows by audience */
export const STORY_FITS: readonly StoryFit[] = [
  {
    id: 'web-action',
    title: 'Web 13+, action/arcade (casual kit, survivors-like, roguelike, tower defense)',
    depths: { none: 'yes', premise: 'default', barks: 'default', chapters: 'max', branching: 'no' },
    notes: { chapters: '≤ 6 short chapters, between runs, only with meta progression', branching: 'players come for the action' },
    chaptersNeedMeta: true,
  },
  {
    id: 'web-idle',
    title: 'Web 13+, idle/clicker/merge (kit: code) with ≥ 20 min of meta progression',
    depths: { none: 'weak', premise: 'yes', barks: 'yes', chapters: 'default', branching: 'max' },
    notes: { none: 'idle games fit story best: waiting leaves natural pauses for 3–6 short chapters', branching: 'cosmetic only: flags colour later lines, 2–3 endings' },
  },
  {
    id: 'web-puzzle',
    title: 'Web 13+, puzzle levels',
    depths: { none: 'yes', premise: 'default', barks: 'yes', chapters: 'max', branching: 'no' },
    notes: { chapters: 'only with a long meta: a map, unlocks between levels', branching: 'the puzzle is the content' },
    chaptersNeedMeta: true,
  },
  {
    id: 'web-choices',
    title: 'A game where choosing is the play (Reigns-like)',
    depths: { none: 'yes', premise: 'default', barks: 'yes', chapters: 'yes', branching: 'no' },
    notes: { branching: 'a card deck of choices is a mechanic, not a story: file a mechanic block request (AGENTS.md §5)' },
  },
  {
    id: 'kids-2-5',
    title: 'Kids 2–5 (they do not read)',
    depths: { none: 'yes', premise: 'default', barks: 'max', chapters: 'no', branching: 'no' },
    notes: { premise: 'wordless: a picture and a voiced guide character', barks: 'voiced reactions only, no text needed', chapters: 'ages 2–5 do not read', branching: 'no choices in words' },
    voiced: true,
    limits: { lineWarn: 50, lineMax: 60, sceneWarn: 20, sceneMax: 30, firstScene: 20, choices: 2, choiceChars: 20 },
    barkWords: 8,
  },
  {
    id: 'kids-6-8',
    title: 'Kids 6–8 (early readers)',
    depths: { none: 'yes', premise: 'yes', barks: 'default', chapters: 'max', branching: 'no' },
    notes: { barks: 'every line voiced', chapters: 'picture chapters of ≤ 3 voiced lines, ≤ 10 words a line' },
    voiced: true,
    limits: { lineWarn: 60, lineMax: 70, sceneWarn: 30, sceneMax: 40, firstScene: 30, choices: 2, choiceChars: 30 },
    barkWords: 10,
  },
  {
    id: 'kids-9-12',
    title: 'Kids 9–12',
    depths: { none: 'yes', premise: 'yes', barks: 'default', chapters: 'max', branching: 'no' },
    notes: { chapters: 'short chapters with ≤ 2 choices' },
    limits: { lineWarn: 80, lineMax: 90, sceneWarn: 80, sceneMax: 120, firstScene: 40, choices: 2, choiceChars: 40 },
  },
];

export const depthOrder = (d: StoryDepth): number => STORY_DEPTHS.indexOf(d);

export interface StoryFitInput {
  audience: string;
  kit: string;
  mechanic?: string;
  /** listing.tags */
  tags?: readonly string[];
  /** Title and concept text: a genre word there counts too */
  text?: string;
  /** story.genre, when the game says it */
  genre?: StoryGenre;
}

const IDLE = /\b(idle|clicker|incremental|merge|tycoon|management|cozy|farming)\b/i;
const PUZZLE = /\b(puzzle|puzzles|logic|match-?3|sokoban|physics puzzle|brain)\b/i;
const CHOICES = /\b(reigns|card choices|swipe choices|interactive fiction|visual novel|choose your own)\b/i;
const ACTION = /\b(action|arcade|shooter|roguelike|roguelite|survivors?|tower defen[cs]e|platformer|runner|fighting|racing|io)\b/i;
const GENRES = [['choices', CHOICES], ['idle', IDLE], ['puzzle', PUZZLE], ['action', ACTION]] as const;

/** The kind of game, for the table: story.genre, else the kit, else the first listing tag that names a genre, else the concept */
export function storyGenre(input: StoryFitInput): { genre: StoryGenre; from: string } {
  if (input.genre) return { genre: input.genre, from: 'story.genre' };
  if (input.kit === 'casual') return { genre: 'action', from: `kit casual (${input.mechanic ?? 'tap-score'}: an arcade round)` };
  for (const tag of input.tags ?? []) for (const [genre, re] of GENRES) if (re.test(tag)) return { genre, from: `listing.tags "${tag}"` };
  for (const [genre, re] of GENRES.slice(0, 3)) {
    const m = (input.text ?? '').match(re);
    if (m) return { genre, from: `the concept ("${m[0]}")` };
  }
  return { genre: 'action', from: input.tags?.length ? `listing.tags (${input.tags.join(', ')}): no genre tag, so action` : 'the default: no listing.tags (set story.genre if it is idle or puzzle)' };
}

/** The row of the table for this game, what it recommends, and why */
export function storyFit(input: StoryFitInput): { fit: StoryFit; recommended: StoryDepth[]; genre: StoryGenre | null; why: string } {
  const kidsRow = { 'ages-2-5': 'kids-2-5', 'ages-6-8': 'kids-6-8', 'ages-9-12': 'kids-9-12' }[input.audience];
  const g = kidsRow ? null : storyGenre(input);
  const fit = STORY_FITS.find((f) => f.id === (kidsRow ?? `web-${g!.genre}`))!;
  const recommended = STORY_DEPTHS.filter((d) => fit.depths[d] === 'default');
  const why = kidsRow ? `audience ${input.audience}` : `audience ${input.audience}, genre ${g!.genre} from ${g!.from}`;
  return { fit, recommended, genre: g?.genre ?? null, why };
}

/** The depths this kind of game supports, lightest first (meta: false drops chapters where they need meta) */
export function allowedDepths(fit: StoryFit, meta?: boolean): StoryDepth[] {
  return STORY_DEPTHS.filter((d) => fit.depths[d] !== 'no' && !(meta === false && fit.chaptersNeedMeta && depthOrder(d) >= depthOrder('chapters')));
}

/** One line per depth, for `gp explain story.depth` and `gp story` */
export function fitTable(): string[] {
  const mark: Record<FitCell, string> = { default: 'DEFAULT', yes: 'yes', max: 'at most', weak: 'fine, but gains from more', no: 'no' };
  return STORY_FITS.map((f) => `  ${f.title}: ${STORY_DEPTHS.map((d) => `${d} ${mark[f.depths[d]]}${f.notes[d] ? ` (${f.notes[d]})` : ''}`).join(' · ')}`);
}

// --- game.yaml `story` (resolve.ts) ------------------------------------------------------------------------------

export interface StoryInput {
  depth: StoryDepth;
  premise?: string;
  file?: string;
  voiced?: boolean;
  genre?: StoryGenre;
}

type Report = (code: string, path: (string | number)[], message: string, fix: string) => void;

/** Chapters in a kind of game that takes them only as a reward for meta progression, and the game has none */
export function metaWarning(fit: StoryFit, depth: StoryDepth, meta: boolean | undefined, why = ''): { message: string; fix: string } | null {
  if (meta !== false || !fit.chaptersNeedMeta || depthOrder(depth) < depthOrder('chapters') || fit.depths[depth] === 'no') return null;
  return {
    message: `depth ${depth} in a game with no meta progression${why ? ` (${why})` : ''}; ${fit.title}: chapters ${fit.notes.chapters}`,
    fix: 'Tell it in barks and a premise (depth barks), or add meta progression (upgrades, unlocks between runs) the chapters can be a reward in.',
  };
}
const words = (s: string): number => s.split(/\s+/).filter(Boolean).length;
const isTodo = (s: string | undefined) => !!s && /\bTODO\b/.test(s);

/**
 * The `story` section against the kind of game. No section and a game where no story is fine: nothing at all.
 * `meta`: whether the game has meta progression (false for the YAML kits; the CLI knows it for code games).
 */
export function checkStorySection(story: StoryInput | undefined, input: StoryFitInput, audience: AudienceProfile, report: { err: Report; warn: Report; info: Report }, meta?: boolean): void {
  const { fit, recommended } = storyFit({ ...input, genre: story?.genre ?? input.genre });
  if (!story) {
    if (fit.depths.none === 'weak')
      report.info('I_STORY_DEPTH', ['story'], `${fit.title}: ${fit.notes.none ?? 'a story pays off here'}. The game has no story`, `Run \`gp story\` to see the recommended depth (${recommended.join(' or ')}) and form a starting file; or write \`story: { depth: none }\` to say it is a decision. Per-item flavour text (a line under each car, upgrade or card) is not a story: it counts as \`story: { depth: none }\` too.`);
    return;
  }
  const d = story.depth;
  const cell = fit.depths[d];
  const allowed = allowedDepths(fit, meta);
  const noMeta = metaWarning(fit, d, meta);
  if (cell === 'no')
    report.warn('W_STORY_DEPTH', ['story', 'depth'], `depth ${d} is outside what this kind of game supports (${fit.title}${fit.notes[d] ? `: ${fit.notes[d]}` : ''})`, `Use ${allowed.slice(-1)[0]} at most (recommended: ${recommended.join(' or ')}); \`gp story\` explains why.`);
  else if (noMeta) report.warn('W_STORY_DEPTH', ['story', 'depth'], noMeta.message, noMeta.fix);
  else if (input.kit !== 'code' && depthOrder(d) >= depthOrder('barks'))
    report.warn('W_STORY_DEPTH', ['story', 'depth'], `kit ${input.kit} has no bark or dialogue block yet: depth ${d} can't be shown`, 'Keep depth premise (title screen, covers, store text), or file a block request (AGENTS.md §5) — or use kit: code for 13+.');

  if (d === 'none') return;
  if (d === 'premise' && !story.premise?.trim())
    report.err('E_STORY_SECTION', ['story', 'premise'], 'depth premise needs `story.premise`: the one line the story is', 'Write `premise: "<who> <wants what> <because>"` in one line of ≤ 30 words.');
  if (story.premise) {
    if (isTodo(story.premise)) report.warn('W_STORY_TODO', ['story', 'premise'], 'story.premise is still TODO', 'Write the one line: who, what, why.');
    else if (words(story.premise) > DEPTH_COUNTS.premiseWords)
      report.warn('W_STORY_HEAVY', ['story', 'premise'], `the premise is ${words(story.premise)} words; a premise is one line of ≤ ${DEPTH_COUNTS.premiseWords}`, 'Cut it to who, what and why; tell the rest in the game.');
  }
  if (depthOrder(d) >= depthOrder('chapters') && !story.file)
    report.err('E_STORY_SECTION', ['story', 'file'], `depth ${d} needs \`story.file\`: the story as data, so it can be checked`, 'Run `gp story --write` to form story.ts, then set `file: story.ts`.');
  if (fit.voiced && depthOrder(d) >= depthOrder('barks') && story.voiced !== true)
    report.err('E_STORY_VOICE', ['story', 'voiced'], `audience ${audience.id}: every story line must be voiced (${audience.id === 'ages-2-5' ? 'they do not read' : 'they read slowly'})`, 'Speak every line (TTS or audio) and set `voiced: true`; or keep the story wordless (depth premise).');
}

// --- The story file (the CLI loads it and passes its exports) ------------------------------------------------------

/** What a story file holds, read from its exports (any format; a StoryDef is checked in full) */
export interface StoryContent {
  /** The StoryDef export (`STORY` by convention), when there is one */
  def: StoryDef | null;
  defName: string | null;
  /** Bark lists: string arrays, or maps of event → string array ("KING_BARKS.wave") */
  barks: { name: string; lines: string[] }[];
  /** Other text in the game's own format ("INTRO", "CHAPTERS[2]") */
  own: { name: string; texts: string[] }[];
  /** Character names (the StoryDef cast, or a CAST / SPEAKERS / CHARACTERS export) */
  cast: string[];
  /** Main chapters (StoryDef `chapters`, or the length of a CHAPTERS array in the game's own format) */
  chapters: number;
  /** Scenes that play at a break, not counting first-action ones (StoryDef) */
  scenes: number;
  endings: string[];
  /** Story vars set by a choice and read by a condition: choices with consequences */
  consequences: string[];
  words: { scenes: number; barks: number; own: number; total: number };
}

const META_KEYS = new Set(['id', 'who', 'mood', 'color', 'colour', 'voice', 'when', 'if', 'at', 'goto', 'label', 'cue', 'ending', 'set', 'clear', 'fire', 'give', 'add', 'speaker', 'portrait', 'key', 'kind', 'type', 'icon', 'sprite', 'sound', 'emoji', 'moods']);
const looksLikeId = (s: string) => /^[#\w./-]+$/.test(s) && s.length <= 24;
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const isStrings = (v: unknown): v is string[] => Array.isArray(v) && v.length > 0 && v.every((x) => typeof x === 'string');
export const isStoryDef = (v: unknown): v is StoryDef => isObj(v) && isObj(v.scenes) && isObj(v.cast);

function texts(v: unknown, out: string[] = [], depth = 0): string[] {
  if (depth > 12) return out;
  if (typeof v === 'string') {
    if (!looksLikeId(v)) out.push(v);
  } else if (Array.isArray(v)) for (const x of v) texts(x, out, depth + 1);
  else if (isObj(v)) for (const [k, x] of Object.entries(v)) if (!META_KEYS.has(k)) texts(x, out, depth + 1);
  return out;
}

/** Every text of a StoryDef scene: lines and choices, with their replies */
function defTexts(lines: readonly Line[] | undefined, out: string[] = []): string[] {
  for (const raw of lines ?? []) {
    const l = parseLine(raw);
    if (l.text) out.push(l.text);
    for (const c of l.choose ?? []) {
      if (c.text) out.push(c.text);
      defTexts(c.then, out);
    }
  }
  return out;
}

function defWalk(lines: readonly Line[] | undefined, f: (l: ReturnType<typeof parseLine>, choice?: NonNullable<ReturnType<typeof parseLine>['choose']>[number]) => void): void {
  for (const raw of lines ?? []) {
    const l = parseLine(raw);
    f(l);
    for (const c of l.choose ?? []) {
      f(l, c);
      defWalk(c.then, f);
    }
  }
}

const countWords = (xs: readonly string[]) => xs.reduce((n, s) => n + words(s), 0);
const list = (x: string | readonly string[] | undefined): readonly string[] => (x === undefined ? [] : typeof x === 'string' ? [x] : x);

/** Sort a story file's exports into a StoryDef, bark lists, a cast and the rest */
export function readStoryExports(exports: Record<string, unknown>): StoryContent {
  const c: StoryContent = { def: null, defName: null, barks: [], own: [], cast: [], chapters: 0, scenes: 0, endings: [], consequences: [], words: { scenes: 0, barks: 0, own: 0, total: 0 } };
  const entries = Object.entries(exports).filter(([k, v]) => k !== '__esModule' && typeof v !== 'function');
  const defEntry = entries.find(([k, v]) => k === 'STORY' && isStoryDef(v)) ?? entries.find(([, v]) => isStoryDef(v));
  for (const [name, v] of entries) {
    if (defEntry && name === defEntry[0]) continue;
    if (defEntry && name === 'default' && v === defEntry[1]) continue;
    if (isStrings(v)) c.barks.push({ name, lines: v });
    else if (isObj(v) && Object.keys(v).length && Object.values(v).every(isStrings)) for (const [k, lines] of Object.entries(v)) c.barks.push({ name: `${name}.${k}`, lines: lines as string[] });
    else if (/^(CAST|SPEAKERS|CHARACTERS)$/i.test(name) && isObj(v)) c.cast.push(...Object.values(v).map((x) => (isObj(x) && typeof x.name === 'string' ? x.name : '')).filter(Boolean));
    else {
      if (/CHAPTERS$/i.test(name) && Array.isArray(v)) c.chapters = Math.max(c.chapters, v.length);
      const t = texts(v);
      if (t.length) c.own.push({ name, texts: t });
    }
  }
  if (defEntry) {
    const def = defEntry[1] as StoryDef;
    c.def = def;
    c.defName = defEntry[0];
    c.cast.push(...Object.values(def.cast ?? {}).map((m) => m?.name).filter((n): n is string => typeof n === 'string'));
    c.chapters = (def.chapters ?? []).length;
    const set = new Set<string>();
    const conds: string[] = [];
    for (const s of Object.values(def.scenes ?? {})) {
      if (s.at !== 'first-action') c.scenes++;
      if (s.when) conds.push(s.when);
      c.words.scenes += countWords(defTexts(s.lines));
      defWalk(s.lines, (l, choice) => {
        if (choice) {
          for (const f of [...list(choice.do?.set), ...list(choice.do?.clear), ...Object.keys(choice.do?.add ?? {})]) set.add(f);
          if (choice.if) conds.push(choice.if);
        } else {
          if (l.if) conds.push(l.if);
          if (l.ending && !c.endings.includes(l.ending)) c.endings.push(l.ending);
        }
      });
    }
    const read = new Set(conds.flatMap((x) => x.match(/[A-Za-z_][\w-]*/g) ?? []));
    // chose(scene.choice) reads a choice directly
    const chose = conds.flatMap((x) => [...x.matchAll(/chose\(\s*[\w-]+\.([\w-]+)\s*\)/g)].map((m) => m[1]));
    c.consequences = [...new Set([...[...set].filter((f) => read.has(f)), ...chose])];
  }
  c.words.barks = countWords(c.barks.flatMap((b) => b.lines));
  c.words.own = countWords(c.own.flatMap((o) => o.texts));
  c.words.total = c.words.scenes + c.words.barks + c.words.own;
  return c;
}

/** The depth a story file's content amounts to */
export function contentDepth(c: StoryContent): StoryDepth {
  if (c.def && c.endings.length >= DEPTH_COUNTS.endingsMin && c.consequences.length) return 'branching';
  if (c.chapters > 0 || c.scenes > 0 || c.words.own > 150) return 'chapters';
  if (c.barks.length) return 'barks';
  return c.words.total ? 'premise' : 'none';
}

export interface StoryCheckContext {
  depth: StoryDepth;
  audience: AudienceProfile;
  fit: StoryFit;
  /** The story file as shown in messages */
  file: string;
}

/** Words that point to the shop or ads (a story line never does that for children, and never during play for 13+) */
const SHOP = /\b(shop|store|buy|buying|purchases?|in-app|premium|ads?|advert\w*|rewarded|watch an? ad)\b/i;
const INTRO = /^(INTRO|PROLOGUE|OPENING|PRELUDE)/i;
const fmt = (n: number) => n.toLocaleString('en-US');
const readMin = (w: number) => `≈ ${Math.max(1, Math.round(w / 238))} min of reading`;
const quote = (xs: readonly string[], n = 3) => xs.slice(0, n).map((x) => `"${x.length > 50 ? `${x.slice(0, 47)}…` : x}"`).join(', ') + (xs.length > n ? ` and ${xs.length - n} more` : '');

/** Describe what the content holds, for "depth X but …" */
export function describeContent(c: StoryContent): string {
  const parts: string[] = [];
  if (c.chapters) parts.push(`${c.chapters} chapter${c.chapters === 1 ? '' : 's'}`);
  else if (c.scenes) parts.push(`${c.scenes} scene${c.scenes === 1 ? '' : 's'}`);
  if (c.endings.length) parts.push(`${c.endings.length} ending${c.endings.length === 1 ? '' : 's'}`);
  const bl = c.barks.reduce((n, b) => n + b.lines.length, 0);
  if (bl) parts.push(`${bl} barks`);
  parts.push(`${fmt(c.words.total)} words`);
  return parts.join(', ');
}

/**
 * The story file against its depth and audience: validateStory (with the audience's limits), play before story,
 * barks that fit a bubble, no line pointing to the shop or ads, and whether it is too thin or too heavy for the depth.
 * Issues have path ['story', 'file'] and say where in the file.
 */
export function checkStoryContent(c: StoryContent, ctx: StoryCheckContext): Issue[] {
  const issues: Issue[] = [];
  const at = (where?: string) => (where ? `${ctx.file} ${where}` : ctx.file);
  const push = (code: string, severity: Issue['severity'], message: string, fix: string) => issues.push({ code, severity, path: ['story', 'file'], message, fix });
  const { depth, audience, fit } = ctx;
  const child = audience.child;

  // A StoryDef: the engine's own checker, with the audience's limits
  if (c.def) {
    const found = validateStory(c.def, fit.limits ?? {});
    for (const i of found) push(i.code, i.severity, `${at(formatStoryPath(i.path))}: ${i.message}`, i.fix);
    if (!found.some((i) => i.severity === 'error')) {
      // Play before story: on a fresh save, before the player has done anything, no scene is due at the first run's start
      try {
        const story = loadStory(c.def);
        const fresh = Object.fromEntries((c.def.vars?.game ?? []).map((g) => [g, 0]));
        const due = dueScene(story, storyState(story), 'run-start', fresh);
        if (due)
          push('E_STORY_BEFORE_PLAY', 'error', `${at(`scenes.${due}`)}: plays at the first run's start on a fresh save, before the player has done anything${(c.def.chapters ?? [])[0] === due && !c.def.scenes[due].at ? ' (a chapter without `at` plays at run-start)' : ''}`, 'Play first, story after: set `at: run-end` (the first reward), or a `when` that is false on a fresh save. Before the first action only a `first-action` scene of ≤ 20 words.');
      } catch {
        // validateStory reported why it can't load
      }
    }
  } else if (depthOrder(depth) >= depthOrder('chapters'))
    push('W_STORY_FORMAT', 'warning', `${at()} exports no StoryDef (an object with \`cast\` and \`scenes\`): its ${fmt(c.words.own)} words of chapters were counted, but scene length, Skip, pacing and choices can't be checked`, 'Move the chapters into `export const STORY: StoryDef` (docs/guides/story.md §4): the engine plays it and gp validate checks it.');

  // A scene in the game's own format before the first action (heuristic: its name)
  for (const o of c.own)
    if (INTRO.test(o.name) && countWords(o.texts) > DEPTH_COUNTS.firstActionWords)
      push('W_STORY_BEFORE_PLAY', 'warning', `${at(o.name)} has ${countWords(o.texts)} words (${readMin(countWords(o.texts))}): if it plays before the first action, players leave before they play`, 'Before the first action at most one line of ≤ 20 words; the tutorial goes into barks during play, the rest into the first chapter after the first run.');

  // Barks: a bubble, short, and (for 6–8) few words
  const longBarks = c.barks.flatMap((b) => b.lines.filter((l) => [...l].length > DEPTH_COUNTS.barkChars || (fit.barkWords !== undefined && words(l) > fit.barkWords)));
  if (longBarks.length)
    push('W_STORY_BARK_LONG', 'warning', `${at()}: ${longBarks.length} bark${longBarks.length === 1 ? '' : 's'} over ${DEPTH_COUNTS.barkChars} characters${fit.barkWords ? ` or ${fit.barkWords} words` : ''}: ${quote(longBarks)}`, 'A bark is read at a glance in a bubble, during play: cut it, or make it a line of a chapter.');

  // No line pointing to the shop or ads: children never; 13+ never during play (barks, the first-action scene)
  const playLines = [...c.barks.flatMap((b) => b.lines), ...(c.def ? Object.values(c.def.scenes).filter((s) => s.at === 'first-action').flatMap((s) => defTexts(s.lines)) : [])];
  const allLines = [...playLines, ...(c.def ? Object.values(c.def.scenes).flatMap((s) => defTexts(s.lines)) : []), ...c.own.flatMap((o) => o.texts)];
  const shopLines = [...new Set((child ? allLines : playLines).filter((l) => SHOP.test(l)))];
  const shopEffects = child && c.def ? [...(c.def.events ?? []), ...(c.def.rewards ?? [])].filter((n) => SHOP.test(n.replace(/[-_]/g, ' '))) : [];
  if (shopLines.length || shopEffects.length) {
    if (child)
      push('E_STORY_SHOP', 'error', `${at()}: audience ${audience.id}, and a story line or effect points to the shop, purchases or ads: ${quote([...shopLines, ...shopEffects])}`, 'Take it out: characters in a children\'s game never lead to a purchase or an ad (Families policy).');
    else
      push('W_STORY_SHOP', 'warning', `${at()}: a line shown during play points to the shop or ads: ${quote(shopLines)}`, 'No story line pushes the shop or an ad during play; "the shop has new stock" belongs on the results screen. If the line is spoken inside the game\'s own shop (a merchant), say so in REPORT.md.');
  }

  // TODO left from `gp story`
  const todo = [...allLines, ...c.cast].filter((l) => /\bTODO\b/.test(l));
  if (todo.length) push('W_STORY_TODO', 'warning', `${at()}: ${todo.length} line${todo.length === 1 ? ' is' : 's are'} still TODO`, 'Write them: the characters, the lines, the chapter titles (gp story formed a skeleton).');

  // Too thin or too heavy for the depth
  const found = contentDepth(c);
  const barkCount = c.barks.reduce((n, b) => n + b.lines.length, 0);
  const d = depthOrder(depth);
  if (depthOrder(found) > d && !(depth === 'chapters' && found === 'branching'))
    push('W_STORY_HEAVY', 'warning', `depth ${depth}, but ${at()} holds ${describeContent(c)} (${readMin(c.words.total)}): that is depth ${found}`, `Set \`depth: ${found}\` if the game needs it (\`gp story\` says what this kind of game supports), or cut it to depth ${depth}: ${DEPTH_INFO[depth].what}.`);
  if (depth === 'chapters' && found === 'branching')
    push('I_STORY_DEPTH', 'info', `${at()}: choices change later lines (${c.consequences.join(', ')}) and there are ${c.endings.length} endings: that is depth branching`, 'Set `depth: branching` so the endings and consequences are checked.');
  if (depth === 'barks') {
    if (!barkCount) push('W_STORY_THIN', 'warning', `depth barks, but ${at()} exports no bark lists`, 'Export `BARKS: { <event>: [lines] }` (string arrays, ≤ 60 characters each) from the story file.');
    else if (barkCount < DEPTH_COUNTS.barksThin) push('W_STORY_THIN', 'warning', `depth barks, but only ${barkCount} barks: players hear every one within minutes`, `Write 50–200 barks over the game's events; at least ${DEPTH_COUNTS.barksThin}, a few per event.`);
    else if (barkCount > DEPTH_COUNTS.barksMax || c.words.barks > DEPTH_INFO.barks.words[1]) push('W_STORY_HEAVY', 'warning', `depth barks, ${barkCount} barks and ${fmt(c.words.barks)} words: more than players will hear`, 'Keep the best 50–200: more lines are more to translate, not more fun.');
  }
  if (d >= depthOrder('chapters')) {
    if (c.chapters < DEPTH_COUNTS.chaptersMin) push('W_STORY_THIN', 'warning', `depth ${depth}, but only ${c.chapters} chapter${c.chapters === 1 ? '' : 's'} (${DEPTH_COUNTS.chaptersMin}–${DEPTH_COUNTS.chaptersMax} short scenes unlocked by progress)`, c.chapters ? `Write at least ${DEPTH_COUNTS.chaptersMin} short chapters, or set \`depth: barks\` and tell it in barks and a premise.` : 'List the main chapters in `chapters: [...]` (scenes played in order between runs), or use a lighter depth.');
    else if (c.chapters > DEPTH_COUNTS.chaptersMax) push('W_STORY_HEAVY', 'warning', `depth ${depth}, ${c.chapters} chapters (${DEPTH_COUNTS.chaptersMin}–${DEPTH_COUNTS.chaptersMax})`, 'Merge or cut chapters: the finale should come within an hour of play.');
    const max = DEPTH_INFO[depth].words[1];
    const w = c.words.scenes + c.words.own;
    if (w > max) push('W_STORY_HEAVY', 'warning', `depth ${depth}, ${fmt(w)} words of scenes (${readMin(w)}; up to ${fmt(max)} pays off)`, 'Players who read less stay longer (story.md §1): cut every scene to ≤ 8 lines and ≤ 120 words.');
  }
  if (depth === 'branching') {
    if (!c.consequences.length) push('W_STORY_THIN', 'warning', `depth branching, but no choice changes a later line`, 'Set a flag in a choice (`do: { set: kind }`) and read it later (`if: kind`): a consequence at a fraction of the cost of a branch.');
    if (c.endings.length < DEPTH_COUNTS.endingsMin) push('W_STORY_THIN', 'warning', `depth branching, but ${c.endings.length} ending${c.endings.length === 1 ? '' : 's'} (${DEPTH_COUNTS.endingsMin}–${DEPTH_COUNTS.endingsMax})`, 'Mark the last lines of each ending with `ending: <id>`, chosen by the flags the player set.');
    else if (c.endings.length > DEPTH_COUNTS.endingsMax) push('W_STORY_HEAVY', 'warning', `depth branching, ${c.endings.length} endings (${DEPTH_COUNTS.endingsMin}–${DEPTH_COUNTS.endingsMax})`, 'A player sees one ending: every extra one doubles the writing and the QA for a path few see.');
  }
  return issues;
}

/** The STORY_LIMITS a fit uses (for messages and gp story) */
export const limitsFor = (fit: StoryFit): StoryLimits => ({ ...STORY_LIMITS, ...fit.limits });
