// Explanations for people and agents: `gp explain <topic>` and the generated reference docs.
// A topic is an error code, a profile, a catalog id or a game.yaml field path.

import type { JsonSchema } from '@gp/core/schema';
import { CATALOG, type CatalogKind } from './catalog.ts';
import { ERRORS } from './errors.ts';
import { explainGenre, genreRows } from './genres.ts';
import { AUDIENCES, CHANNELS } from './profiles.ts';
import { GAME_SCHEMA, gameSchema } from './schema.ts';
import { fitTable } from './story-depth.ts';

function typeText(s: JsonSchema): string {
  if (s.const !== undefined) return `\`${s.const}\``;
  if (s.enum) return s.enum.map((v) => `\`${v}\``).join(' \\| ');
  if (s.oneOf) return s.oneOf.map(typeText).join(' or ');
  if (s.type === 'array') return `list of ${s.items ? typeText(s.items) : 'values'}`;
  if (s.type === 'object') return 'section';
  const ref = s['x-gp-ref'] ? ` (${s['x-gp-ref']} id)` : '';
  return (s.type ?? 'value') + ref;
}

function limits(s: JsonSchema): string {
  const out: string[] = [];
  if (s.minimum !== undefined) out.push(`≥ ${s.minimum}`);
  if (s.exclusiveMinimum !== undefined) out.push(`> ${s.exclusiveMinimum}`);
  if (s.maximum !== undefined) out.push(`≤ ${s.maximum}`);
  if (s.minItems !== undefined) out.push(`≥ ${s.minItems} items`);
  if (s.maxItems !== undefined) out.push(`≤ ${s.maxItems} items`);
  if (s.maxLength !== undefined) out.push(`≤ ${s.maxLength} chars`);
  if (s.pattern) out.push(`format \`${s.pattern}\``);
  if (s.minLength !== undefined && s.minLength > 1) out.push(`≥ ${s.minLength} chars`);
  const it = s.items;
  if (it) {
    const inner = limits(it);
    if (inner && it.type !== 'object') out.push(`each item: ${inner}`);
  }
  return out.join(', ');
}

/** Every kit × mechanic combination the catalog allows */
export function schemaVariants(): { kit: string; mechanic: string; schema: JsonSchema }[] {
  const out: { kit: string; mechanic: string; schema: JsonSchema }[] = [];
  for (const [kit, meta] of Object.entries(CATALOG.kit)) {
    const mechanics = (meta as { mechanics: readonly string[] }).mechanics;
    // A kit without a round (kit: code) is one variant of its own
    if (!mechanics.length) out.push({ kit, mechanic: '', schema: gameSchema(kit, '') });
    for (const mechanic of mechanics) out.push({ kit, mechanic, schema: gameSchema(kit, mechanic) });
  }
  return out;
}

/** Schema node at a dotted path ("round.trajectory.time", "modes.card"), in any kit/mechanic variant */
export function schemaAt(path: string): JsonSchema | null {
  for (const v of [GAME_SCHEMA, ...schemaVariants().map((x) => x.schema)]) {
    const found = schemaAtIn(v, path);
    if (found) return found;
  }
  return null;
}

function schemaAtIn(root: JsonSchema, path: string): JsonSchema | null {
  let s: JsonSchema | undefined = root;
  for (const part of path.split('.').filter(Boolean)) {
    while (s && (s.type === 'array' || s.items) && s.items) s = s.items;
    if (s?.oneOf) s = s.oneOf.find((o) => o.properties?.[part]) ?? s;
    s = s?.properties?.[part];
    if (!s) return null;
  }
  return s ?? null;
}

/** Flat list of all fields of a schema: path, type, required, default, description — for the reference */
export function allFields(schema: JsonSchema = GAME_SCHEMA): { path: string; type: string; required: boolean; def: string; limits: string; description: string }[] {
  const out: ReturnType<typeof allFields> = [];
  const walk = (s: JsonSchema, path: string, required: boolean) => {
    if (path) out.push({ path, type: typeText(s), required, def: s.default === undefined ? '' : JSON.stringify(s.default), limits: limits(s), description: s.description ?? '' });
    let obj: JsonSchema | undefined = s;
    while (obj?.items) obj = obj.items;
    const variants = obj?.oneOf ?? (obj ? [obj] : []);
    for (const v of variants) {
      if (!v.properties) continue;
      const suffix = s.type === 'array' ? '[]' : '';
      for (const [k, child] of Object.entries(v.properties)) walk(child, path ? `${path}${suffix}.${k}` : k, (v.required ?? []).includes(k));
    }
  };
  walk(schema, '', true);
  return out;
}

function describeField(path: string, s: JsonSchema): string {
  const lines = [`${path} — ${typeText(s)}`];
  if (s.description) lines.push('', s.description);
  lines.push('');
  const l = limits(s);
  if (l) lines.push(`Limits: ${l}`);
  if (s.default !== undefined) lines.push(`Default: ${JSON.stringify(s.default)}`);
  if (s.examples) lines.push(`Example: ${JSON.stringify(s.examples[0])}`);
  const ref = s['x-gp-ref'];
  if (ref) lines.push(`Available: ${Object.keys(CATALOG[ref === 'kit' ? 'kit' : (ref as CatalogKind)]).join(', ')}`);
  let obj: JsonSchema | undefined = s;
  while (obj?.items) obj = obj.items;
  if (obj?.properties) {
    lines.push('', 'Fields:');
    for (const [k, c] of Object.entries(obj.properties)) lines.push(`  ${k}${(obj.required ?? []).includes(k) ? ' (required)' : ''} — ${typeText(c)}${c.default !== undefined ? `, default ${JSON.stringify(c.default)}` : ''}${c.description ? `. ${c.description}` : ''}`);
  }
  if (path === 'audience') lines.push('', ...Object.values(AUDIENCES).map((a) => `  ${a.id} — ${a.title}`), '', 'More: gp explain <audience id>');
  if (path === 'story' || path === 'story.depth') lines.push('', 'Which depth fits which game (docs/guides/story.md §1; `gp story` picks the row for a game):', ...fitTable());
  if (path === 'money.genre') lines.push('', 'What each genre\'s players expect and which blocks fit: gp explain genres · gp explain genre.<id> · gp catalog genres');
  if (path === 'channel') lines.push('', ...Object.values(CHANNELS).map((c) => `  ${c.id} — ${c.title}`), '', 'More: gp explain <channel id>');
  return lines.join('\n');
}

export function explain(topic: string): string | null {
  // genre.<id> first (a bare "kids" is the kit); "genre" / "genres" lists them
  if (/^genres?\./.test(topic)) return explainGenre(topic);
  if (topic === 'genre' || topic === 'genres')
    return ['Genres (money.genre takes each id; a sub-genre is benchmarked as its genre):', '', ...genreRows().map((r) => `  ${r.id.padEnd(14)} ${r.name.trim().padEnd(28)} must-haves: ${r.expects || '—'}`), '', 'More: gp explain genre.<id> · gp catalog genres · gp catalog blocks --genre <id> · docs/guides/genres.md'].join('\n');
  const e = ERRORS[topic.toUpperCase()];
  if (e) return [`${topic.toUpperCase()} — ${e.title}`, '', `Why: ${e.why}`, `Fix: ${e.fix}`, ...(e.example ? ['', 'Example:', e.example] : [])].join('\n');
  const a = AUDIENCES[topic];
  if (a) return [`audience: ${a.id} — ${a.title}`, '', a.description, '', `Touch targets ≥ ${a.minTouchPx} px, tap targets radius ≥ ${a.minTargetRadiusPx} px, child-directed: ${a.child ? 'yes' : 'no'}`, '', 'Rules:', ...a.rules.map((r) => `  - ${r}`)].join('\n');
  const c = CHANNELS[topic];
  if (c) {
    const p = c.adPolicy;
    return [
      `channel: ${c.id} — ${c.title}`,
      '',
      c.description,
      '',
      `Platform: ${c.platform} · ads: ${c.ads ?? 'none'}${c.adsNeedConsent ? ' (needs consent flow — not available yet)' : ''} · purchases: ${c.billing ? 'yes' : 'no'} · privacy policy: ${c.privacyPolicyRequired ? 'required' : 'optional'}`,
      ...(p ? [`Ad limits (floors): no ads in the first ${p.noAdsAfterLaunchSec} s, first after round ${p.firstAdAfterRound}${p.firstAdAfterSec !== undefined ? ` or after ${p.firstAdAfterSec} s of the session, whichever comes first` : ''}, then at most once per ${p.everyRounds} rounds and ${p.minIntervalSec} s`] : []),
      '',
      'Rules:',
      ...c.rules.map((r) => `  - ${r}`),
    ].join('\n');
  }
  for (const kind of Object.keys(CATALOG) as CatalogKind[]) {
    const entry = (CATALOG[kind] as Record<string, Record<string, unknown>>)[topic];
    if (!entry) continue;
    const lines = [`${kind}: ${topic}`, '', String(entry.description)];
    if (Array.isArray(entry.items)) {
      const items = entry.items as Record<string, string>[];
      lines.push('', `Items (${items.length}): ${items.map((i) => i.emoji ?? i.label ?? i.word).join(' ')}`);
      const d = entry.defaults as Record<string, unknown>;
      lines.push(`Defaults for a mode: show: ${d.show}, pop: ${d.pop}${d.popColored ? ', popColored: true' : ''}`);
    }
    if (Array.isArray(entry.stickers)) lines.push('', `Stickers (${entry.stickers.length}): ${(entry.stickers as string[]).join(' ')}`);
    if (Array.isArray(entry.palette)) lines.push('', `Palette (index: color): ${(entry.palette as string[]).map((c, i) => `${i}: ${c}`).join(', ')}`);
    if (entry.schema) lines.push('', describeField(kind === 'mechanic' ? 'round' : kind, entry.schema as JsonSchema));
    if (entry.sections) lines.push('', `Adds game.yaml sections: ${Object.keys(entry.sections as object).join(', ')} (gp explain <section>)`);
    if (entry.example) lines.push('', 'Example:', String(entry.example));
    return lines.join('\n');
  }
  const s = schemaAt(topic);
  if (s) return describeField(topic, s);
  return explainGenre(topic);
}
