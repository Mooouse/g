// Resolve a structurally valid game.yaml into a ResolvedGame: fill defaults, expand content packs,
// apply the audience and channel profiles — and check the semantic rules on the way.
// Parts: platform fields → round (by mechanic) → kit sections (by kit) → monetization.

import { PROTECTED_NAMES } from './vocabulary.ts';
import type { AdPolicy } from '@gp/core/ads-policy';
import { BASE_LANGUAGE, canonicalCode, languageInfo, TOP_LANGUAGES } from '@gp/core/i18n';
import {
  CONTENT_PACKS,
  NUMBER_WORDS_EN,
  STICKER_PACKS,
  TAP_COLLECT_DEFAULTS,
  TAP_SCORE_DEFAULTS,
  THEME_METAS,
  type ContentItem,
  type ContentPack,
  type PopField,
  type ShowField,
  type TapCollectConfig,
  type TapScoreConfig,
  type TargetKind,
} from '@gp/blocks/meta';
import { CASUAL_STRINGS_EN, type CasualConfig } from '@gp/kit-casual/meta';
import type { CodeConfig } from '@gp/kit-code/meta';
import { KIDS_PRAISE_EN, KIDS_STRINGS_EN, type CardPreviewItem, type KidsConfig, type KidsMode } from '@gp/kit-kids/meta';
import { CATALOG } from './catalog.ts';
import type { Issue } from './errors.ts';
import { ADMOB_TEST_IDS, AUDIENCES, CHANNELS, type AudienceProfile, type ChannelProfile } from './profiles.ts';
import { budgetFor } from './budget.ts';
import { ENGINES, PHYSICS, UNSUPPORTED_ENGINES, engineSupports } from './engines.ts';
import { checkMoney, genreOf, moneyGenre, SUBGENRES, type Genre, type SubGenre } from './money.ts';
import { hooksFor, scoreTitle } from './naming.ts';
import { resolveSound } from './sound.ts';
import { checkStorySection, storyGenre } from './story-depth.ts';
import { conceptText, takenConceptsFor } from './taken.ts';
import type { GameSpecInput, ModeInput, Publisher, ResolvedGame, RoundInput } from './types.ts';

export interface ResolveOptions {
  mode: 'dev' | 'release';
  publisher?: Publisher;
}

type Path = (string | number)[];

const APP_ID_RE = /^ca-app-pub-(\d{16})~\d{10}$/;
const UNIT_ID_RE = /^ca-app-pub-(\d{16})\/\d{10}$/;
const isTodo = (v: unknown) => typeof v === 'string' && /TODO/i.test(v);

/** Pack for an inline list: kind and defaults guessed from what the items have */
function inlinePack(items: ContentItem[]): ContentPack {
  const all = (k: keyof ContentItem) => items.every((i) => i[k] !== undefined);
  const colorBound = all('color');
  const show: ShowField = colorBound ? 'none' : all('label') ? 'label' : all('emoji') ? 'emoji' : 'none';
  const pop: PopField = colorBound ? 'word' : all('label') ? 'label' : all('emoji') ? 'emoji' : all('word') ? 'word' : 'none';
  return { id: '(inline)', description: '', kind: colorBound ? 'color-bound' : 'list', defaults: { show, pop, popColored: colorBound }, items };
}

const FIELD_OF: Record<string, keyof ContentItem | null> = { none: null, label: 'label', emoji: 'emoji', word: 'word' };

interface Ctx {
  spec: GameSpecInput;
  opts: ResolveOptions;
  audience: AudienceProfile;
  channel: ChannelProfile;
  palette: readonly string[];
  cardColors: readonly string[];
  locale: string;
  err(code: string, path: Path, message: string, fix: string): void;
  warn(code: string, path: Path, message: string, fix: string): void;
  info(code: string, path: Path, message: string, fix: string): void;
}

// --- Round ------------------------------------------------------------------------------------

type Field = { spawnEvery: readonly [number, number]; prefill: number; maxOnScreen: number; trajectory: { time: readonly [number, number] }; target: { min: number; max: number } };

/** Checks shared by every mechanic that has a field of moving targets */
function checkField(c: Ctx, round: Field): void {
  if (round.spawnEvery[0] > round.spawnEvery[1]) c.err('E_RANGE_ORDER', ['round', 'spawnEvery'], `round.spawnEvery [${round.spawnEvery}] — min is larger than max`, `Write [${round.spawnEvery[1]}, ${round.spawnEvery[0]}].`);
  if (round.trajectory.time[0] > round.trajectory.time[1])
    c.err('E_RANGE_ORDER', ['round', 'trajectory', 'time'], `round.trajectory.time [${round.trajectory.time}] — min is larger than max`, `Write [${round.trajectory.time[1]}, ${round.trajectory.time[0]}].`);
  if (round.target.min > round.target.max) c.err('E_RANGE_ORDER', ['round', 'target'], `round.target.min ${round.target.min} is larger than max ${round.target.max}`, 'Make min ≤ max.');
  if (round.target.min < c.audience.minTargetRadiusPx)
    c.err('E_TARGET_TOO_SMALL', ['round', 'target', 'min'], `round.target.min = ${round.target.min} px, audience ${c.audience.id} needs at least ${c.audience.minTargetRadiusPx} px`, `Set round.target.min: ${c.audience.minTargetRadiusPx} (or remove it).`);
  if (round.prefill > round.maxOnScreen) c.err('E_PREFILL', ['round', 'prefill'], `round.prefill ${round.prefill} > round.maxOnScreen ${round.maxOnScreen}`, `Set prefill ≤ ${round.maxOnScreen}.`);
}

function resolveTapCollect(c: Ctx, r: Extract<RoundInput, { mechanic: 'tap-collect' }>): TapCollectConfig {
  const d = TAP_COLLECT_DEFAULTS;
  const round: TapCollectConfig = {
    mechanic: 'tap-collect',
    goal: r.goal ?? d.goal,
    maxOnScreen: r.maxOnScreen ?? d.maxOnScreen,
    spawnEvery: (r.spawnEvery ?? d.spawnEvery) as [number, number],
    prefill: r.prefill ?? d.prefill,
    trajectory: { ...d.trajectory, ...r.trajectory, type: 'rise' },
    target: { ...d.target, ...r.target },
    celebrateSec: r.celebrateSec ?? d.celebrateSec,
  };
  checkField(c, round);
  return round;
}

function resolveTapScore(c: Ctx, r: Extract<RoundInput, { mechanic: 'tap-score' }>): TapScoreConfig {
  const d = TAP_SCORE_DEFAULTS;
  const targets: TargetKind[] = (r.targets ?? d.targets).map((t) => {
    const def = d.targets.find((x) => x.kind === t.kind)!;
    const penalty = t.kind === 'spiky' ? { time: t.penalty?.time ?? def.penalty!.time, combo: t.penalty?.combo ?? def.penalty!.combo } : null;
    return { kind: t.kind, weight: t.weight, score: t.score ?? def.score, speed: t.speed ?? def.speed, penalty };
  });
  const round: TapScoreConfig = {
    mechanic: 'tap-score',
    goal: { time: r.goal?.time ?? d.goal.time },
    maxOnScreen: r.maxOnScreen ?? d.maxOnScreen,
    spawnEvery: (r.spawnEvery ?? d.spawnEvery) as [number, number],
    prefill: r.prefill ?? d.prefill,
    countdown: r.countdown ?? d.countdown,
    trajectory: { ...d.trajectory, ...r.trajectory, type: 'rise' },
    ramp: { ...d.ramp, ...r.ramp },
    target: { ...d.target, ...r.target },
    targets,
    combo: { ...d.combo, ...r.combo },
    celebrateSec: r.celebrateSec ?? d.celebrateSec,
    idleHintSec: r.idleHintSec ?? d.idleHintSec,
  };
  checkField(c, round);
  (r.targets ?? []).forEach((t, i) => {
    if (t.kind !== 'spiky' && t.penalty) c.err('E_TARGET_KIND', ['round', 'targets', i, 'penalty'], `round.targets[${i}]: only spiky targets have a penalty`, 'Remove `penalty`, or use `kind: spiky`.');
  });
  if (!targets.some((t) => t.kind !== 'spiky')) c.err('E_TARGET_KIND', ['round', 'targets'], 'round.targets has only spiky targets — nothing to score', 'Add `{ kind: normal, weight: 90, score: 10 }`.');
  const steps = round.combo.steps;
  if (steps.some((s, i) => i > 0 && s <= steps[i - 1])) c.err('E_RANGE_ORDER', ['round', 'combo', 'steps'], `round.combo.steps [${steps}] must grow`, 'Write them in increasing order, e.g. [5, 10, 20, 35].');
  if (c.audience.child) c.err('E_NO_FAIL', ['round', 'mechanic'], `tap-score has a clock and penalties; audience ${c.audience.id} is child-directed (no losing, no timers)`, 'Use `mechanic: tap-collect` for children, or `audience: general`.');
  return round;
}

// --- Kits -------------------------------------------------------------------------------------

function resolveKids(c: Ctx): KidsConfig {
  const { spec, audience, palette, locale } = c;
  const lang = locale.slice(0, 2);
  if (spec.parentGate === false && audience.child)
    c.err('E_PARENT_GATE_REQUIRED', ['parentGate'], `audience ${audience.id} is child-directed: settings, purchases and links must be behind the parent gate`, 'Remove `parentGate: false`.');
  const seen = new Set<string>();
  const modes: KidsMode[] = [];
  (spec.modes ?? []).forEach((m: ModeInput, i) => {
    const at: Path = ['modes', i];
    if (seen.has(m.id)) c.err('E_MODE_DUPLICATE', [...at, 'id'], `mode id "${m.id}" is used twice`, 'Give every mode its own id.');
    seen.add(m.id);
    if (!!m.content === !!m.items) {
      c.err('E_MODE_CONTENT', at, `mode "${m.id}" needs either \`content\` (a pack) or \`items\` (inline list)${m.content && m.items ? ', not both' : ''}`, 'Add `content: <pack id>` (see `gp catalog content`) or `items: [...]`.');
      return;
    }
    const lower = (it: ContentItem): ContentItem => (it.color ? { ...it, color: it.color.toLowerCase() } : it);
    const pack = m.content ? CONTENT_PACKS[m.content] : inlinePack(m.items!.map(lower));
    if (!pack) return; // unknown pack: already reported by the schema check
    if (pack.lang && pack.lang !== lang) c.warn('W_CONTENT_LANG', [...at, 'content'], `pack ${pack.id} is in "${pack.lang}", the game locale is ${locale}`, 'Use a pack in the game language.');
    const show = m.show ?? pack.defaults.show;
    const pop = m.pop ?? pack.defaults.pop;
    for (const [what, field] of [['show', show], ['pop', pop]] as const) {
      const f = FIELD_OF[field];
      if (!f) continue;
      const missing = pack.items.findIndex((it) => !it[f]);
      if (missing >= 0) c.err('E_ITEM_FIELD', [...at, m.items ? 'items' : 'content'], `mode "${m.id}": ${what}: ${field}, but item ${missing} has no "${f}"`, `Add "${f}" to every item, or change ${what}.`);
    }
    const colorBound = pack.kind === 'color-bound';
    if (colorBound) {
      const named = new Set(pack.items.map((it) => it.color?.toLowerCase()));
      const unnamed = palette.filter((col) => !named.has(col));
      if (unnamed.length)
        c.err('E_COLOR_NOT_NAMED', [...at, m.items ? 'items' : 'content'], `mode "${m.id}" names target colors, but theme ${spec.theme} colors ${unnamed.join(', ')} have no name in it`, 'Add items with those colors, or use another theme/pack.');
    }
    const say = m.say ?? true;
    if (!say && audience.id === 'ages-2-5')
      c.err('E_VOICE_REQUIRED', [...at, 'say'], `mode "${m.id}": say: false, but audience ages-2-5 does not read — the voice is how the game talks to them`, 'Remove `say: false`.');
    if (say && pack.items.some((it) => !it.word))
      c.warn('W_SILENT_ITEMS', [...at, m.items ? 'items' : 'content'], `mode "${m.id}": some items have no "word", so nothing is spoken for them`, 'Add `word` to every item, or set `say: false` (not allowed for ages-2-5).');
    // Card preview
    const colorAt = (col: number | string | undefined, k: number, pi: number): string => {
      if (typeof col === 'string') return col.toLowerCase();
      const idx = col ?? (i * 3 + k * 2) % palette.length;
      if (idx >= palette.length) {
        c.err('E_PALETTE_INDEX', [...at, 'card', 'preview', pi, 'color'], `palette index ${idx}, but theme ${spec.theme} has ${palette.length} colors (0–${palette.length - 1})`, `Use 0–${palette.length - 1} or a #rrggbb color.`);
        return palette[0];
      }
      return palette[idx];
    };
    let preview: CardPreviewItem[];
    if (m.card?.preview) preview = m.card.preview.map((p, k) => ({ color: colorAt(p.color, k, k), label: p.label, emoji: p.emoji }));
    else if (colorBound) preview = [0, 2, 4].map((k) => ({ color: palette[k % palette.length] }));
    else
      preview = pack.items.slice(0, 3).map((it, k) => ({
        color: colorAt(undefined, k, k),
        label: show === 'label' ? it.label : undefined,
        emoji: show === 'emoji' ? it.emoji : undefined,
      }));
    modes.push({
      id: m.id,
      show,
      pop,
      popColored: m.popColored ?? pack.defaults.popColored ?? false,
      say,
      colorBound,
      items: pack.items.map((it) => lower({ ...it })),
      card: { fill: m.card?.fill?.toLowerCase() ?? c.cardColors[i % c.cardColors.length], preview },
    });
  });
  const st = spec.rewards?.stickers ?? 'stickers-24';
  const stickers = typeof st === 'string' ? [...(STICKER_PACKS[st]?.stickers ?? [])] : st;
  return {
    kit: 'kids',
    modes,
    menu: { backgroundTargets: spec.menu?.backgroundTargets ?? 4 },
    rewards: { stickers, praise: spec.rewards?.praise ?? KIDS_PRAISE_EN },
    parentGate: spec.parentGate ?? true,
    strings: { ...KIDS_STRINGS_EN, ...(spec.strings as Partial<typeof KIDS_STRINGS_EN>) },
    numberWords: [...NUMBER_WORDS_EN],
    privacyPolicyUrl: spec.privacyPolicyUrl ?? null,
  };
}

function resolveCasual(c: Ctx): CasualConfig {
  const { spec, audience } = c;
  if (audience.child)
    c.err('E_KIT_AUDIENCE', ['kit'], `kit casual has no parent gate and a score race; audience ${audience.id} is child-directed`, 'Use `kit: kids` for children, or `audience: general`.');
  return {
    kit: 'casual',
    title: { subtitle: spec.titleScreen?.subtitle ?? null, backgroundTargets: spec.titleScreen?.backgroundTargets ?? 5 },
    result: { stats: spec.result?.stats ?? ['pops', 'combo', 'accuracy'] },
    strings: { ...CASUAL_STRINGS_EN, ...(spec.strings as Partial<typeof CASUAL_STRINGS_EN>) },
  };
}

function resolveCode(c: Ctx): CodeConfig {
  const { spec, audience, channel } = c;
  // Child-directed games need the kids kit's parent gate, voice and no-fail rules, which own code could skip
  if (audience.child)
    c.err('E_KIT_AUDIENCE', ['kit'], `kit code has no parent gate or child-safety rules built in; audience ${audience.id} is child-directed`, 'Use `kit: kids` for children, or `audience: general`.');
  if (channel.platform !== 'web')
    c.err('E_KIT_CHANNEL', ['channel'], `kit code builds for web channels only for now (not ${channel.id})`, 'Use `channel: crazygames` or `channel: web`.');
  return { kit: 'code', entry: spec.entry ?? 'main.ts', background: (spec.background ?? '#000000').toLowerCase(), engine: resolveEngine(c), physics: resolvePhysics(c), anchor: resolveAnchor(c), difficulty: resolveDifficulty(c) };
}

/** game.yaml `balance.difficulty`: the skill ladder's targets (the schema checks the numbers; here the range's order) */
function resolveDifficulty(c: Ctx): CodeConfig['difficulty'] {
  const d = c.spec.balance?.difficulty;
  if (!d) return null;
  const r = d.winningRunMin;
  if (r && r[0] > r[1]) c.err('E_RANGE_ORDER', ['balance', 'difficulty', 'winningRunMin'], `balance.difficulty.winningRunMin [${r}] — the shortest is longer than the longest`, `Write [${r[1]}, ${r[0]}].`);
  const out: NonNullable<CodeConfig['difficulty']> = {};
  for (const k of ['naive', 'average', 'skilled'] as const) {
    const s = d[k];
    if (s) out[k] = { winRate: s.winRate, ...(s.tolerance !== undefined ? { tolerance: s.tolerance } : {}) };
  }
  if (r) out.winningRunMin = [Math.min(r[0], r[1]), Math.max(r[0], r[1])];
  return out;
}

/**
 * game.yaml `balance.anchor`: declared, the balance model's newer checks (the first session, the difficulty's shape, the
 * session's end) fail like the others; a portal game without it gets a warning, and those checks only warn
 */
function resolveAnchor(c: Ctx): CodeConfig['anchor'] {
  const a = c.spec.balance?.anchor;
  const todo = !!a && [a.name, a.unit, a.says].some((x) => /^\s*TODO\b/i.test(x ?? ''));
  if (a && !todo) return { name: a.name.trim(), unit: a.unit.trim(), says: a.says.trim(), shape: a.shape === 'run' ? 'run' : 'campaign' };
  if (c.channel.portal)
    c.warn(
      'W_BALANCE_ANCHOR',
      ['balance', 'anchor'],
      `channel ${c.channel.id}: game.yaml ${todo ? 'balance.anchor is still TODO' : 'declares no balance.anchor'} — the balance model's first-session checks (first reward, early gaps, big rewards, hard streaks, the session-end hook) only warn`,
      'Add `balance: { anchor: { name, unit, says } }` — the one number your genre converts everything into (docs/guides/upgrades.md → Start from time, then the anchor); build balanceModel() in it. A roguelite whose stages are a run\'s waves or floors adds `shape: run`.',
    );
  return null;
}

/**
 * game.yaml `engine.physics`: a library the physics block runs, its exact version within the block's range (the CLI
 * checks package.json), and a reminder of what it weighs where the channel has a size budget
 */
function resolvePhysics(c: Ctx): CodeConfig['physics'] {
  const e = c.spec.engine?.physics;
  if (!e) return null;
  const name = e.name.trim().toLowerCase();
  const info = PHYSICS[name];
  if (!info) {
    c.err('E_PHYSICS_UNSUPPORTED', ['engine', 'physics', 'name'], `"${e.name}" is not a physics library the physics block (@gp/physics) runs`, `Set engine.physics.name to one of ${Object.keys(PHYSICS).join(', ')} (docs/guides/code-games.md#physics).`);
    return null;
  }
  if (!e.version) {
    c.err('E_PHYSICS_VERSION', ['engine', 'physics', 'version'], `engine.physics ${name} needs its version: the exact ${info.package} version pinned in the game's package.json`, `Set engine.physics.version: "${info.tested}" (and "${info.package}": "${info.tested}" in games/<id>/package.json), or run gp init --physics.`);
    return null;
  }
  if (!engineSupports(info, e.version)) {
    c.err('E_PHYSICS_VERSION', ['engine', 'physics', 'version'], `${info.package} ${e.version} is outside what the physics block supports: ${info.range}`, `Pin the tested version, ${info.tested}, in games/<id>/package.json and engine.physics.version.`);
    return null;
  }
  const lim = c.channel.webLimits;
  const budget = c.spec.budget?.gzipKB ?? lim?.budgetGzipKB;
  if (lim && budget !== undefined && budget < info.gzipKB + 100)
    c.warn('W_PHYSICS_BUDGET', ['engine', 'physics'], `${info.package} adds ≈ ${info.gzipKB.toLocaleString('en-US')} KB gzipped to the upload; the size budget is ${budget.toLocaleString('en-US')} KB (${c.spec.budget ? 'game.yaml budget.gzipKB' : `channel ${c.channel.id}`}), so gp build warns`, `Physics is worth it only where it is the mechanic; then raise the budget on purpose: \`budget: { gzipKB: ${Math.ceil((info.gzipKB + 200) / 100) * 100} }\` (gp forecast counts the longer load).`);
  return { name, version: e.version, package: info.package };
}

/** game.yaml `engine`: a supported engine, its exact version within the adapter's range (the CLI checks package.json) */
function resolveEngine(c: Ctx): CodeConfig['engine'] {
  const e = c.spec.engine;
  if (!e) return null;
  const name = e.name.trim().toLowerCase();
  const info = ENGINES[name];
  if (!info) {
    const why = UNSUPPORTED_ENGINES[name] ?? `"${e.name}" is not one of the engines the platform has an adapter for.`;
    c.err('E_ENGINE_UNSUPPORTED', ['engine', 'name'], why, `Set engine.name to one of ${Object.keys(ENGINES).join(', ')} (docs/guides/code-games.md#engines).`);
    return null;
  }
  if (!info.package) {
    if (e.version) c.warn('W_ENGINE_VERSION', ['engine', 'version'], `engine ${name} is the browser's own: it has no version`, 'Remove engine.version.');
    return { name, version: null, package: null };
  }
  if (!e.version) {
    c.err('E_ENGINE_VERSION', ['engine', 'version'], `engine ${name} needs its version: the exact ${info.package} version pinned in the game's package.json`, `Set engine.version: "${info.tested}" (and "${info.package}": "${info.tested}" in games/<id>/package.json), or run gp init --engine ${name}.`);
    return null;
  }
  if (!engineSupports(info, e.version)) {
    c.err('E_ENGINE_VERSION', ['engine', 'version'], `${info.package} ${e.version} is outside what the ${name} adapter supports: ${info.range}`, `Pin a supported version (the tested one: ${info.tested}) in games/<id>/package.json and engine.version.`);
    return null;
  }
  if (info.needs === 'webgl2')
    c.info('I_ENGINE_WEBGL2', ['engine', 'name'], `${name} needs WebGL2: browsers and GPUs without it (old phones, blocklisted drivers) get the "can't run" screen`, 'Fine for a game where 3D is the point; for flat 2D, Canvas 2D or Pixi play everywhere.');
  return { name, version: e.version, package: info.package };
}

// --- Originality ---------------------------------------------------------------------------------

/** Titles that are a single common game word: CrazyGames — "Super Chess" is unique and clear, "Chess" is not */
const GENERIC_TITLES = new Set(
  'chess checkers draughts snake solitaire sudoku mahjong minesweeper pong breakout arkanoid tetris 2048 bingo poker blackjack uno pool billiards darts golf bowling soccer football basketball tennis racing race runner puzzle jigsaw memory match3 match-3 blocks bubbles bubble shooter tanks tank archery fishing parkour zombies clicker idle io survival merge sort'
    .split(' '),
);
type Report = (code: string, path: Path, message: string, fix: string) => void;

/** Someone else's name: every channel. A common word as the whole title: only where the channel reviews originality */
export function checkTitle(title: string, err: Report, portal = true): void {
  const t = title.trim().toLowerCase();
  const words = t.replace(/[!?.:]+$/, '').split(/\s+/);
  if (portal && words.length === 1 && GENERIC_TITLES.has(words[0]))
    err('E_TITLE_GENERIC', ['title'], `"${title}" is a common identifier, not a name (CrazyGames: "Super Chess" is unique, "Chess" is not)`, 'Name the game for what is special about it, in two or more words.');
  const hit = PROTECTED_NAMES.find((n) => new RegExp(`(^|[^a-z])${n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|[^a-z])`).test(t));
  if (hit) err('E_TITLE_GENERIC', ['title'], `"${title}" uses "${hit}", a name someone else owns`, 'Give the game its own name; never use another game\'s or brand\'s name.');
}

/** Words that describe the looks, not the play: a difference made only of these is a reskin */
const LOOKS = /\b(theme|themed|setting|art|artstyle|graphics|visuals?|style|skin|skins|look|looks|colou?rs?|characters?|story|name|music|sounds?|cute|pixel|3d|neon)\b/gi;
const PLAY = /\b(rule|rules|mechanic|mechanics|control|controls|input|goal|goals|objective|combo|combine|instead|only|can|must|when|each|every|turn|move|moves|aim|drag|tap|hold|swipe|draw|build|merge|swap|rotate|split|grow|shrink|push|pull|bounce|fuse|stack|time|reverse|rewind|gravity|physics)\b/gi;

export function checkConcept(concept: GameSpecInput['concept'], channelId: string, err: Report, warn: Report, title = '', kit = '', id = ''): void {
  if (!concept) {
    err('E_CONCEPT', ['concept'], `channel ${channelId} reviews originality: game.yaml has no \`concept\``, 'Add `concept: { pitch, closest: [3+ games it could be mistaken for], different }` before building — `gp explain concept`.');
    return;
  }
  const todo = [concept.pitch, concept.different, concept.progression, ...(concept.closest ?? [])].some((x) => /^\s*TODO\b/i.test(x ?? ''));
  if (todo) {
    err('E_CONCEPT', ['concept'], 'concept is still TODO: search the portal and write it before building', 'Fill in pitch, closest, different and progression (docs/concept.md has the search table) — `gp explain concept`.');
    return;
  }
  const closest = (concept.closest ?? []).map((x) => x.trim()).filter(Boolean);
  if (closest.length < 3)
    err('E_CONCEPT', ['concept', 'closest'], `concept.closest names ${closest.length} game(s); name at least 3 on the portal it could be mistaken for`, 'Search the portal for the genre and its tags; list the closest titles honestly — the reviewer will.');
  const diff = concept.different ?? '';
  const looks = (diff.match(LOOKS) ?? []).length;
  const play = (diff.match(PLAY) ?? []).length;
  if (/^\s*(nothing|none|no difference|the same)\b/i.test(diff))
    warn('W_CONCEPT_THEME', ['concept', 'different'], 'concept.different says there is no difference yet', 'Find the rule, input or goal that is new before building (docs/guides/uniqueness.md → twist levers).');
  else if (looks > 0 && play === 0)
    warn('W_CONCEPT_THEME', ['concept', 'different'], 'concept.different talks about looks (theme, art, characters) and not about play', 'Name the rule, input or goal that is new; a theme swap is what portals reject.');
  if (!concept.twist && kit === 'code')
    warn('W_TWIST_MISSING', ['concept', 'twist'], 'concept.twist is missing: the platform can\'t check that the twist is in the game', 'Add `twist: { event: "<name>", within: 30 }` and call `host.twist("<name>")` in the game when it happens (docs/guides/uniqueness.md).');
  else if (kit === 'code' && concept.twist && !concept.twist.explained?.trim())
    warn(
      'W_TWIST_UNEXPLAINED',
      ['concept', 'twist', 'explained'],
      'concept.twist.explained is missing: gp qa can see the twist happen, but not that a new player is told what it is',
      'Add `explained: "<the words on screen that explain it>"` to concept.twist and show them before or when host.twist() fires, long enough to read (docs/guides/uniqueness.md#the-explanation).',
    );
  const taken = takenConceptsFor(conceptText(title, concept.pitch, diff), title, id).slice(0, 2);
  if (taken.length)
    warn(
      'W_CONCEPT_TAKEN',
      ['concept'],
      `the concept reads like ${taken.map((t) => `${t.what} — live: ${t.titles.join(', ')}`).join('; and ')} (searched ${taken[0].checked})`,
      'List them in concept.closest and make concept.different say what the player does that they don\'t; if it\'s the same core action, change it.',
    );
}

// --- Languages (docs/guides/i18n.md) ------------------------------------------------------------

/**
 * game.yaml `languages`: each once, English among them (CrazyGames requires it; every missing text falls back to it), and
 * on a portal all ten languages its audience speaks most. The texts themselves (strings/<code>.yaml) are the CLI's to check
 */
function resolveLanguages(spec: GameSpecInput, channel: ChannelProfile, err: Report, warn: Report): string[] {
  const asked = (spec.languages ?? [BASE_LANGUAGE]).map(canonicalCode);
  const twice = asked.filter((l, i) => asked.indexOf(l) !== i);
  if (twice.length) err('E_I18N_LANGS', ['languages'], `languages lists ${[...new Set(twice)].join(', ')} twice`, 'List each language once.');
  const languages = [...new Set(asked)];
  if (!languages.includes(BASE_LANGUAGE))
    err('E_I18N_ENGLISH', ['languages'], `languages has no English (${languages.join(', ')})`, 'Put `en` first: CrazyGames requires English, and every text a language misses falls back to it.');
  if (channel.portal) {
    const missing = TOP_LANGUAGES.filter((l) => !languages.includes(l));
    if (missing.length)
      warn(
        'W_I18N_LANGS',
        ['languages'],
        `channel ${channel.id}: the game is in ${languages.length} language${languages.length === 1 ? '' : 's'} (${languages.join(', ')}); its players also speak ${missing.map((l) => languageInfo(l)?.english ?? l).join(', ')}`,
        spec.kit === 'code'
          ? `Add them: \`languages: [${TOP_LANGUAGES.join(', ')}]\`, then \`gp translate\` lists every text to translate into strings/<code>.yaml (docs/guides/i18n.md).`
          : `Add \`languages: [${TOP_LANGUAGES.join(', ')}]\`: the kit's texts are translated by the platform; your own (titleScreen.subtitle, strings) go into strings/<code>.yaml (docs/guides/i18n.md).`,
      );
  }
  return languages;
}

// --- The whole game -----------------------------------------------------------------------------

export function resolveGame(spec: GameSpecInput, opts: ResolveOptions): { game: ResolvedGame | null; issues: Issue[] } {
  const issues: Issue[] = [];
  const err = (code: string, path: Path, message: string, fix: string) => issues.push({ code, severity: 'error', path, message, fix });
  const warn = (code: string, path: Path, message: string, fix: string) => issues.push({ code, severity: 'warning', path, message, fix });
  const info = (code: string, path: Path, message: string, fix: string) => issues.push({ code, severity: 'info', path, message, fix });

  const audience = AUDIENCES[spec.audience];
  const channel = CHANNELS[spec.channel];
  // kit: code has no theme (the game draws itself): the palette checks of the other kits don't apply
  const themeMeta = THEME_METAS[(spec.theme ?? 'sky-balloons') as keyof typeof THEME_METAS];
  const locale = spec.locale ?? 'en-US';
  const c: Ctx = {
    spec,
    opts,
    audience,
    channel,
    palette: themeMeta.palette.map((col) => col.toLowerCase()),
    cardColors: themeMeta.cardColors,
    locale,
    err,
    warn,
    info,
  };

  // --- Platform fields
  if (channel.portal === 'crazygames' && spec.title.length > 35)
    err('E_TITLE_LONG', ['title'], `title is ${spec.title.length} characters; the CrazyGames form allows 35 (and it must match the title in the game)`, 'Shorten the title to 35 characters.');
  else if (spec.title.length > 30) {
    if (channel.platform === 'android') err('E_TITLE_LONG', ['title'], `title is ${spec.title.length} characters; Google Play allows 30`, 'Shorten the title to 30 characters.');
    else warn('W_TITLE_LONG', ['title'], `title is ${spec.title.length} characters; store titles are usually limited to 30`, 'Shorten the title to 30 characters.');
  }
  checkTitle(spec.title, err, !!channel.conceptReview);
  if (channel.conceptReview) checkConcept(spec.concept, channel.id, err, warn, spec.title, spec.kit, spec.id);
  if (channel.conceptReview) {
    const mg = spec.money?.genre;
    const genre: Genre = moneyGenre(mg) ?? genreOf(spec.kit, spec.audience, spec.listing?.tags ?? []).genre;
    // A sub-genre (money.genre: deckbuilder) gets its own hooks offered, not its money genre's (Velvet Domino Rogue)
    const sub = mg && mg in SUBGENRES ? (mg as SubGenre) : null;
    const ts = scoreTitle(spec.title, genre, sub);
    const name = sub ?? genre;
    if (genre !== 'kids' && !ts.hooks.some((x) => x.fits))
      warn('W_TITLE_HOOK', ['title'], `"${spec.title}" has no word a ${name} player recognises (score ${ts.score}/100): ${ts.issues.join('; ')}`, `Pair a word of the game's own with a ${name} hook (${hooksFor(genre, sub).slice(0, 6).map((k) => k.word).join(', ')}) — \`gp name\` scores titles and suggests some; a game already on the portal can keep its name with a subtitle ("Dread Throne: Tower Defense").`);
  }
  const todoText = (x?: string) => !x || /^\s*TODO\b/i.test(x);
  if (channel.portal && (todoText(spec.listing?.description) || todoText(spec.listing?.controls)))
    warn('W_LISTING', ['listing'], `channel ${channel.id}: the listing texts (description, controls) are ${spec.listing ? 'still TODO' : 'missing'} — \`gp submission\` needs them`, 'Write `listing: { description, controls }` before you hand the game over.');
  const languages = resolveLanguages(spec, channel, err, warn);
  if (channel.platform === 'android' && !spec.appId) err('E_APP_ID_REQUIRED', ['appId'], `channel ${channel.id} is an Android channel: appId is required`, 'Add `appId: <reverse domain>.<game>` (gp new fills it in from publisher.yaml).');
  if (channel.childOnly && !audience.child)
    err('E_CHANNEL_AUDIENCE', ['channel'], `channel ${channel.id} is for child-directed games, but audience is ${audience.id}`, 'Use `channel: android` for a general audience.');
  if (audience.child && channel.platform === 'android' && !channel.childOnly)
    err('E_CHANNEL_AUDIENCE', ['channel'], `audience ${audience.id} is child-directed; on Google Play it must use the android-families channel`, 'Set `channel: android-families`.');
  if (channel.audiences && !channel.audiences.includes(audience.id))
    err('E_CHANNEL_AUDIENCE', ['audience'], `channel ${channel.id} accepts audiences ${channel.audiences.join(', ')}, not ${audience.id}`, `Set audience: ${channel.audiences[0]}, or pick another channel.`);
  const privacy = spec.privacyPolicyUrl ?? null;
  if (channel.privacyPolicyRequired && (!privacy || !privacy.startsWith('https://')))
    err('E_PRIVACY_POLICY', ['privacyPolicyUrl'], privacy ? `privacyPolicyUrl must be https: ${privacy}` : `channel ${channel.id} requires privacyPolicyUrl`, 'Set `privacyPolicyUrl: https://<your site>/<game>/privacy-policy.html`.');
  if (opts.mode === 'release' && isTodo(privacy)) err('E_RELEASE_TODO', ['privacyPolicyUrl'], 'privacyPolicyUrl is still a TODO', 'Publish the policy page and put its URL here.');

  // --- Kit and mechanic must fit together (also reported before the schema check, see index.ts)
  let round: ResolvedGame['round'] = null;
  let kit: ResolvedGame['kit'];
  if (spec.kit === 'code') {
    kit = resolveCode(c);
  } else {
    const r = spec.round!;
    const kitMeta = CATALOG.kit[spec.kit as keyof typeof CATALOG.kit] as { mechanics: readonly string[] };
    if (!kitMeta.mechanics.includes(r.mechanic))
      err('E_MECHANIC_KIT', ['round', 'mechanic'], `kit ${spec.kit} works with mechanic ${kitMeta.mechanics.join(', ')}, not ${r.mechanic}`, `Set round.mechanic: ${kitMeta.mechanics[0]}, or pick the kit that fits the mechanic.`);

    // --- Round, kit
    round = r.mechanic === 'tap-score' ? resolveTapScore(c, r) : resolveTapCollect(c, r);
    kit = spec.kit === 'casual' ? resolveCasual(c) : resolveKids(c);
    if (spec.kit === 'kids' && !(spec.modes ?? []).length) err('E_REQUIRED', ['modes'], 'kit kids needs `modes` (at least one menu card)', 'Add `modes: [{ id: numbers, content: numbers-1-10-en }]`.');
  }

  // --- Story: only what the game declares, and a hint where a story clearly pays off (docs/guides/story.md)
  // The YAML kits have no meta progression; a code game's is known from its files (the CLI checks that part)
  const storyInput = { audience: audience.id, kit: spec.kit, mechanic: spec.round?.mechanic, tags: spec.listing?.tags, text: `${spec.title} ${spec.concept?.pitch ?? ''}`, genre: spec.story?.genre };
  checkStorySection(spec.story, storyInput, audience, { err, warn, info }, spec.kit === 'code' ? undefined : false);

  // --- Monetization
  const mon = spec.monetization ?? {};
  const adsIn = mon.ads ?? {};
  const adsAllowed = channel.ads !== null && !channel.adsNeedConsent;
  const adsEnabled = adsIn.enabled ?? adsAllowed;
  if (adsEnabled && !adsAllowed)
    err('E_ADS_UNSUPPORTED', ['monetization', 'ads', 'enabled'], channel.ads === null ? `channel ${channel.id} has no ad provider yet` : `ads on channel ${channel.id} need a consent flow (UMP) that the platform does not have yet`, 'Set monetization.ads.enabled: false.');
  if (adsIn.rewarded === true && !(adsEnabled && adsAllowed && channel.rewardedAds))
    err('E_REWARDED_UNSUPPORTED', ['monetization', 'ads', 'rewarded'], `channel ${channel.id} has no rewarded ads${adsEnabled ? '' : ' (ads are off)'}`, 'Remove monetization.ads.rewarded.');
  const rewarded = channel.rewardedAds && adsIn.rewarded !== false;
  let ads: ResolvedGame['ads'] = null;
  let admobAppId: string | null = null;
  if (adsEnabled && adsAllowed && channel.adPolicy) {
    const floor = channel.adPolicy;
    const policy: AdPolicy = { ...floor, ...adsIn.limits };
    // Every limit is a floor: a game may raise it, never lower it. firstAdAfterSec is an OR next to firstAdAfterRound, so a
    // lower (earlier) value loosens it; a channel without it has no time path (Infinity): no game may add one
    for (const k of ['noAdsAfterLaunchSec', 'firstAdAfterRound', 'firstAdAfterSec', 'everyRounds', 'minIntervalSec'] as const) {
      const min = floor[k] ?? Infinity;
      const v = policy[k] ?? Infinity;
      if (!(v >= min))
        err(
          'E_ADS_LIMITS',
          ['monetization', 'ads', 'limits', k],
          `monetization.ads.limits.${k} = ${v} is looser than channel ${channel.id} allows (${Number.isFinite(min) ? `≥ ${min}` : k === 'firstAdAfterSec' ? 'it has no time path: the first ad waits for the round' : `≥ ${min}`})`,
          Number.isFinite(min) ? `Set it to ${min} or more, or remove it.` : 'Remove it.',
        );
    }
    if (channel.ads === 'admob' && channel.admob) {
      const pubId = opts.publisher?.admob?.publisherId?.replace(/^pub-/, '');
      const checkId = (key: 'appId' | 'interstitial', re: RegExp) => {
        const v = adsIn[key] ?? 'auto';
        const path: Path = ['monetization', 'ads', key];
        if (v === 'auto') {
          if (opts.mode === 'release') err('E_RELEASE_IDS', path, `monetization.ads.${key} is "auto" — never filled in`, 'Run `gp admob provision` or paste the ID from AdMob.');
          return null;
        }
        const m = re.exec(v);
        if (!m) {
          err('E_ADMOB_ID', path, `monetization.ads.${key}: "${v}" is not an AdMob ${key === 'appId' ? 'App ID (ca-app-pub-…~…)' : 'ad unit ID (ca-app-pub-…/…)'}`, 'Copy the ID from AdMob, or use `auto`.');
          return null;
        }
        if (v.startsWith(ADMOB_TEST_IDS.publisherPrefix)) {
          if (opts.mode === 'release') err('E_RELEASE_IDS', path, `monetization.ads.${key} is Google's test ID`, 'Use your own AdMob ID (dev builds use test IDs automatically).');
        } else if (pubId && m[1] !== pubId) err('E_ADMOB_PUBLISHER', path, `monetization.ads.${key} belongs to publisher pub-${m[1]}, publisher.yaml says pub-${pubId}`, 'Use an ID from your own AdMob account.');
        return v;
      };
      const appId = checkId('appId', APP_ID_RE);
      const unit = checkId('interstitial', UNIT_ID_RE);
      const release = opts.mode === 'release';
      ads = { policy, admob: { ...channel.admob, interstitialId: release && unit ? unit : ADMOB_TEST_IDS.interstitial, isTesting: !release }, rewarded };
      admobAppId = release && appId ? appId : ADMOB_TEST_IDS.appId;
    } else {
      if (adsIn.appId || adsIn.interstitial) warn('W_ADMOB_IGNORED', ['monetization', 'ads'], `channel ${channel.id} shows the portal's ads; AdMob IDs are ignored`, 'Remove appId/interstitial from monetization.ads.');
      ads = { policy, admob: null, rewarded };
    }
  }
  let billing: ResolvedGame['billing'] = null;
  const ra = mon.removeAds;
  if (ra === undefined) billing = adsEnabled && adsAllowed && channel.billing ? { product: 'remove_ads' } : null;
  else if (ra !== false) {
    if (!channel.billing) err('E_BILLING_UNSUPPORTED', ['monetization', 'removeAds'], `channel ${channel.id} has no in-app purchases`, 'Set monetization.removeAds: false.');
    else if (!adsEnabled) err('E_BILLING_UNSUPPORTED', ['monetization', 'removeAds'], '"Remove ads" without ads makes no sense', 'Set monetization.removeAds: false, or enable ads.');
    else billing = { product: ra === true ? 'remove_ads' : (ra.product ?? 'remove_ads') };
  }

  // --- Money: the design against the channel (docs/guides/game-design.md → Design for money)
  checkMoney(spec.money, { channel: channel.id, audience: audience.id, kit: spec.kit, adsOn: adsEnabled && adsAllowed, rewardedOn: rewarded, billing: billing !== null }, err, warn);

  // --- Sound: music on a portal (the code's side is musicIssues, called by the CLI with the game's files)
  const sound = resolveSound(spec, channel.id, err, warn);

  // --- The upload's size budget: raised on purpose, never above the channel's hard limit
  if (spec.budget) {
    const lim = channel.webLimits;
    if (!lim) err('E_BUDGET', ['budget'], `channel ${channel.id} has no web upload budget (only web portals: ${Object.values(CHANNELS).filter((c) => c.webLimits).map((c) => c.id).join(', ')})`, 'Remove `budget`.');
    else if (spec.budget.gzipKB > lim.maxInitialMB * 1024)
      err('E_BUDGET', ['budget', 'gzipKB'], `budget.gzipKB ${spec.budget.gzipKB} is above channel ${channel.id}'s hard limit of ${lim.maxInitialMB} MB`, `Set budget.gzipKB to ${lim.maxInitialMB * 1024} or less — better, make the upload smaller (docs/guides/code-games.md#the-size-and-load-budget).`);
  }

  if (opts.mode === 'release') {
    const dev = opts.publisher?.developer ?? {};
    for (const k of ['name', 'email', 'website'] as const)
      if (!dev[k] || isTodo(dev[k])) err('E_RELEASE_TODO', ['(publisher.yaml)', 'developer', k], `publisher.yaml developer.${k} is not filled in`, `Fill in developer.${k} in publisher/publisher.yaml.`);
  }

  if (issues.some((i) => i.severity === 'error')) return { game: null, issues };
  const game: ResolvedGame = {
    spec: 0,
    id: spec.id,
    title: spec.title,
    listing: {
      description: spec.listing?.description?.trim() ?? null,
      controls: spec.listing?.controls?.trim() ?? null,
      orientation: spec.listing?.orientation ?? 'both',
      tags: spec.listing?.tags ?? [],
    },
    concept: spec.concept ?? null,
    story: spec.story
      ? { depth: spec.story.depth, premise: spec.story.premise?.trim() ?? null, file: spec.story.file ?? null, voiced: spec.story.voiced ?? false, genre: audience.child ? null : storyGenre(storyInput).genre }
      : null,
    money: spec.money ?? null,
    sound,
    budget: budgetFor(channel.id, spec.budget),
    appId: spec.appId ?? `web.${spec.id.replace(/-/g, '')}`,
    version: { name: spec.version?.name ?? '1.0.0', code: spec.version?.code ?? 1 },
    locale,
    languages,
    glossary: [...new Set((spec.glossary ?? []).map((g) => g.trim()).filter(Boolean))],
    audience,
    channel: { id: channel.id, platform: channel.platform },
    theme: spec.theme ?? null,
    saveKey: spec.saveKey ?? `${spec.id}.save.v1`,
    minTouchPx: audience.minTouchPx,
    round,
    ads,
    billing,
    kit,
    portal: channel.portal ?? null,
    android: { admobAppId },
    build: { mode: opts.mode },
  };
  return { game, issues };
}
