// The size and load budget of a web upload: how long a slow phone takes to a tappable Play, and the channel's budget.
// `gp build --target <portal>` measures the upload (raw, gzipped, by npm package) and estimates the load with this
// model; `gp forecast` reads the numbers (upload/size.json) into P(Full Launch). Pure data and code, like money.ts.
//
// Why a model and not a browser measurement: `gp build` must stay fast and deterministic (no Chromium, no timing noise
// from a shared CPU), and the load of a one-file upload is mostly its bytes. The model is fitted to the engine lab's
// measurements (QmaCyber/game12, docs/engine-lab.md: six uploads of 42 KB–3.4 MB, Chromium, Lighthouse's slow-4G
// profile 1.6 Mbps / 150 ms RTT and 4× CPU throttling, the median of 5 cold loads, served gzipped):
//   time to a tappable Play ≈ RTT + gzipped bytes ÷ 1.6 Mbps            (download: within 10 ms of all six)
//                          + 160 ms + 0.88 ms per KB of JS/CSS/HTML     (parse, compile, boot at 4× CPU)
//                          + 0.32 ms per KB of embedded base64 data     (a .wasm or an image inlined into the page)
// Measured → modelled: canvas 0.43 → 0.42 s, three 1.59 → 1.59 s, pixi 1.92 → 1.70 s, phaser 3.35 → 3.34 s,
// rapier 7.88 → 7.86 s; kaplay 1.88 → 0.92 s (its own start-up work isn't in its bytes: an engine that boots slowly is
// slower than the model says). Not in it: the portal SDK's own load, a real phone's GPU, the portal CDN.

import { CHANNELS } from './profiles.ts';

/** The slow phone of the estimate: Lighthouse's mobile profile, as the engine lab measured it */
export const SLOW_PHONE = { downMbps: 1.6384, rttMs: 150, cpu: 4 } as const;

/** The model's constants (fitted to the engine lab, see above) */
export const LOAD_MODEL = {
  bootMs: 160,
  codeMsPerKB: 0.88,
  dataMsPerKB: 0.32,
  /** A base64 run at least this long is embedded data (a .wasm, an image, a sound), not code */
  dataRunChars: 4096,
} as const;

export interface UploadBytes {
  /** The upload as served, before compression */
  raw: number;
  gzip: number;
  /** Base64 data embedded in the page (inlined .wasm, images, sounds): cheaper to parse than code */
  data: number;
}

export interface LoadEstimate {
  downloadMs: number;
  cpuMs: number;
  /** To a tappable Play on the slow phone */
  totalMs: number;
}

/** The estimated time to a tappable Play on the slow phone (SLOW_PHONE), from the upload's bytes */
export function estimateLoad(b: UploadBytes): LoadEstimate {
  const downloadMs = SLOW_PHONE.rttMs + (b.gzip * 8) / (SLOW_PHONE.downMbps * 1000);
  const code = Math.max(0, b.raw - b.data) / 1024;
  const cpuMs = LOAD_MODEL.bootMs + code * LOAD_MODEL.codeMsPerKB + (b.data / 1024) * LOAD_MODEL.dataMsPerKB;
  return { downloadMs, cpuMs, totalMs: downloadMs + cpuMs };
}

/**
 * A later chapter's image in the one-file upload (game.yaml art.assets[].chapter ≥ 1; packages/cli/src/chapters.ts writes
 * them): a data block after the game's script, which is `async` and placed before them — the game starts as soon as the
 * script has arrived, while the blocks still stream in, and @gp/art/assets reads them after Play. The HTML parser keeps
 * a block's base64 as text (a script type the browser doesn't run), so it costs no script parse or compile.
 */
export const CHAPTER_BLOCK = /<script type="application\/octet-stream" data-gp-asset="[^"]*" data-gp-chapter="(\d+)"[^>]*>[A-Za-z0-9+/=]*<\/script>/g;

export interface UploadParts {
  /** What a tappable Play waits for: the page and the game's script (with chapter 0 inside it), and the closing tags */
  first: string;
  /** Each later chapter's data blocks, in the order they arrive */
  chapters: { chapter: number; files: number; text: string }[];
}

/** The upload split into what Play waits for and the later chapters (none: all of it is the first load) */
export function splitUpload(html: string): UploadParts {
  const by = new Map<number, { files: number; parts: string[] }>();
  let start = -1;
  let end = 0;
  for (const m of html.matchAll(CHAPTER_BLOCK)) {
    if (start < 0) start = m.index;
    end = m.index + m[0].length;
    const c = Number(m[1]);
    const e = by.get(c) ?? { files: 0, parts: [] };
    e.files++;
    e.parts.push(m[0]);
    by.set(c, e);
  }
  if (start < 0) return { first: html, chapters: [] };
  return {
    first: html.slice(0, start) + html.slice(end),
    chapters: [...by.entries()].sort((a, b) => a[0] - b[0]).map(([chapter, e]) => ({ chapter, files: e.files, text: e.parts.join('') })),
  };
}

/** A later chapter in the size report */
export interface ChapterSize {
  chapter: number;
  /** Images (frames count) */
  files: number;
  rawBytes: number;
  gzipBytes: number;
  /** When its last byte is in on the slow phone, ms after opening (the page arrives in order: the first load, then 1, 2 …) */
  inMs: number;
}

/** The later chapters' download, one after the other after the first load, on the slow phone */
export function chapterArrivals(firstGzip: number, chapters: readonly Omit<ChapterSize, 'inMs'>[]): ChapterSize[] {
  let bytes = firstGzip;
  return chapters.map((c) => {
    bytes += c.gzipBytes;
    return { ...c, inMs: Math.round(SLOW_PHONE.rttMs + (bytes * 8) / (SLOW_PHONE.downMbps * 1000)) };
  });
}

/** Base64 runs long enough to be data, not code (in the one-file upload: an inlined .wasm, image or sound) */
export function embeddedDataBytes(html: string): number {
  let n = 0;
  for (const m of html.matchAll(new RegExp(`[A-Za-z0-9+/]{${LOAD_MODEL.dataRunChars},}={0,2}`, 'g'))) n += m[0].length;
  return n;
}

export interface Budget {
  /** Warn above this many KB gzipped (the channel's, or game.yaml budget.gzipKB) */
  gzipKB: number;
  /** Warn above this many seconds to a tappable Play on the slow phone */
  warnLoadSec: number;
  /** Fail above this many MB raw: the channel's hard limit, never raised */
  hardMB: number;
  /** Where gzipKB came from */
  from: 'channel' | 'game.yaml budget.gzipKB';
}

/**
 * The budget a game's upload is held to: the channel's (profiles.ts webLimits), or a bigger one the game asks for on
 * purpose (game.yaml `budget: { gzipKB }`, a physics or 3D game). A raised size raises the load warning with it, to the
 * time a budget-sized upload takes (its gzip ×3 raw, the engines' ratio). Null: the channel has no web budget.
 */
export function budgetFor(channelId: string, gameBudget?: { gzipKB?: number } | null): Budget | null {
  const lim = CHANNELS[channelId]?.webLimits;
  if (!lim) return null;
  const own = gameBudget?.gzipKB;
  if (typeof own !== 'number') return { gzipKB: lim.budgetGzipKB, warnLoadSec: lim.warnLoadSec, hardMB: lim.maxInitialMB, from: 'channel' };
  const atBudget = estimateLoad({ raw: own * 1024 * 3, gzip: own * 1024, data: 0 }).totalMs / 1000;
  return { gzipKB: own, warnLoadSec: Math.max(lim.warnLoadSec, Math.ceil(atBudget * 10) / 10), hardMB: lim.maxInitialMB, from: 'game.yaml budget.gzipKB' };
}

export interface PackageShare {
  /** An npm package name, "game" (the game's own files), "platform" (@gp/*), or "other" (Vite's helpers, unmapped) */
  name: string;
  /** Bytes of the minified JS from it */
  bytes: number;
  /** Its share of the upload's raw bytes */
  share: number;
}

/** What `gp build --target <portal>` writes to upload/size.json, and `gp forecast` and `gp submission` read */
export interface SizeReport {
  file: 'index.html';
  /** The whole file (the hard limit's) */
  rawBytes: number;
  gzipBytes: number;
  /** Base64 data embedded in the page */
  dataBytes: number;
  /**
   * What a tappable Play waits for — the budget and the load estimate count this: the whole file, or with asset chapters
   * (game.yaml art.assets[].chapter) everything but the later chapters' data blocks
   */
  first?: UploadBytes;
  /** The later chapters, loaded after Play (empty: none) */
  chapters?: ChapterSize[];
  /** By npm package, from the build's sourcemap (largest first) */
  packages: PackageShare[];
  load: { slowPhone: typeof SLOW_PHONE; downloadMs: number; cpuMs: number; tappableMs: number; method: string };
  budget: Budget | null;
  /** Warnings: over the budget (a build above the hard limit writes no upload at all) */
  over: string[];
}

/** The budget's warnings for an upload (`b`: what Play waits for — the first load when the game has asset chapters) */
export function overBudget(b: UploadBytes, load: LoadEstimate, budget: Budget | null, chapters = false): string[] {
  if (!budget) return [];
  const out: string[] = [];
  const kb = b.gzip / 1024;
  if (kb > budget.gzipKB)
    out.push(`${Math.round(kb).toLocaleString('en-US')} KB gzipped${chapters ? ' before Play' : ''} > the ${budget.gzipKB.toLocaleString('en-US')} KB budget (${budget.from === 'channel' ? 'the channel\'s' : 'game.yaml budget.gzipKB'})`);
  if (load.totalMs / 1000 > budget.warnLoadSec) out.push(`≈ ${(load.totalMs / 1000).toFixed(1)} s to a tappable Play on a slow phone > ${budget.warnLoadSec} s`);
  return out;
}
