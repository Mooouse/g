// game.yaml as written (input) and the resolved game the player runs (everything explicit).

import type { AdMobConfig, AdPolicy } from '@gp/core/ads-policy';
import type { ContentItem, PopField, ShowField, TapCollectConfig, TapScoreConfig, RiseConfig, TargetKind } from '@gp/blocks/meta';
import type { CasualConfig, CasualStrings, ResultStat } from '@gp/kit-casual/meta';
import type { CodeConfig } from '@gp/kit-code/meta';
import type { KidsConfig, KidsStrings } from '@gp/kit-kids/meta';
import type { AudienceProfile } from './profiles.ts';
import type { Budget } from './budget.ts';
import type { MoneyInput } from './money.ts';
import type { StoryDepth, StoryGenre, StoryInput } from './story-depth.ts';

export interface ModeInput {
  id: string;
  content?: string;
  items?: ContentItem[];
  show?: ShowField;
  pop?: PopField;
  popColored?: boolean;
  say?: boolean;
  card?: { fill?: string; preview?: { color?: number | string; label?: string; emoji?: string }[] };
}

export interface ConceptInput {
  /** One sentence: what the player does and why it's fun */
  pitch: string;
  /** Games already on the channel this one could be mistaken for (the portal's own search, genre and tag pages) */
  closest: string[];
  /** What the player does here that none of them has: the core action, rule or goal — not the theme, art or name */
  different: string;
  /** The moment the twist happens in play: the game calls host.twist(event) then; QA checks a new player meets it early */
  twist?: {
    event: string;
    within?: number;
    /** The words on screen that explain the twist: gp qa checks they are readable (≥ 2 s + 50 ms/char) before or when it fires */
    explained?: string;
  };
  /** What the currency or the run buys, in the shape that fits the genre (docs/guides/upgrades.md → pick a shape) */
  progression?: string;
}

export interface GameSpecInput {
  spec: 0;
  id: string;
  title: string;
  /** Required on Android channels */
  appId?: string;
  version?: { name?: string; code?: number };
  locale?: string;
  /** The languages the game ships in (docs/guides/i18n.md): English first; a portal game takes all ten top ones */
  languages?: string[];
  /** Names that stay as they are in every language (characters, places, the game's own words) */
  glossary?: string[];
  audience: string;
  channel: string;
  kit: 'kids' | 'casual' | 'code';
  /** Not for kit: code (the game draws itself) */
  theme?: string;
  saveKey?: string;
  privacyPolicyUrl?: string;
  /** What makes this game its own (portals reject "too close to existing titles"); required where the channel reviews originality */
  concept?: ConceptInput;
  /** The store / portal listing texts (`gp submission` puts them into listing.md with the form answers) */
  listing?: { description?: string; controls?: string; orientation?: 'both' | 'landscape' | 'portrait'; tags?: string[] };
  /** How much story, and where it is (optional: `gp story` says what the game needs) */
  story?: StoryInput;
  /** The money design: session, natural breaks, rewarded offers, meta, reason to return (`gp forecast`) */
  money?: MoneyInput;
  /** The game's sound where the code doesn't show it: what music plays, or `music: false` with `why` */
  sound?: { music?: string | false; why?: string };
  /** The upload's size budget, raised on purpose (web portals: `gp build --target <portal>`) */
  budget?: { gzipKB: number };
  /** Not for kit: code (the game has its own mechanics) */
  round?: RoundInput;
  monetization?: {
    ads?: { enabled?: boolean; rewarded?: boolean; appId?: string; interstitial?: string; limits?: Partial<AdPolicy> };
    removeAds?: boolean | { product?: string };
  };
  // kit: kids
  modes?: ModeInput[];
  menu?: { backgroundTargets?: number };
  rewards?: { stickers?: string | string[]; praise?: string[] };
  parentGate?: boolean;
  // kit: casual
  titleScreen?: TitleScreenInput;
  result?: { stats?: ResultStat[] };
  // kit: code
  entry?: string;
  background?: string;
  /** kit: code — the engine it draws with (its adapter: @gp/core/engines/<name>) */
  engine?: { name: string; version?: string; physics?: { name: string; version?: string } };
  /** kit: code — the balance as designed: the anchor the model is built in */
  balance?: {
    anchor?: { name: string; unit: string; says: string; shape?: 'campaign' | 'run' };
    /** The skill ladder's targets: the win rate per bot skill from a fresh save, and how long a winning run lasts */
    difficulty?: {
      naive?: { winRate: number; tolerance?: number };
      average?: { winRate: number; tolerance?: number };
      skilled?: { winRate: number; tolerance?: number };
      winningRunMin?: [number, number];
    };
  };
  // both kits (each validates its own keys)
  strings?: Partial<KidsStrings> & Partial<CasualStrings>;
}

export type RoundInput =
  | (Partial<Omit<TapCollectConfig, 'trajectory' | 'target'>> & {
      mechanic: 'tap-collect';
      trajectory?: Partial<RiseConfig>;
      target?: Partial<TapCollectConfig['target']>;
    })
  | (Partial<Omit<TapScoreConfig, 'trajectory' | 'target' | 'targets' | 'ramp' | 'combo' | 'goal'>> & {
      mechanic: 'tap-score';
      goal?: { time?: number };
      trajectory?: Partial<RiseConfig>;
      target?: Partial<TapScoreConfig['target']>;
      targets?: (Partial<TargetKind> & { kind: TargetKind['kind']; weight: number; penalty?: Partial<NonNullable<TargetKind['penalty']>> })[];
      ramp?: Partial<TapScoreConfig['ramp']>;
      combo?: Partial<TapScoreConfig['combo']>;
    });

/** The casual kit's title screen section */
export interface TitleScreenInput {
  subtitle?: string;
  backgroundTargets?: number;
}

/** Publisher data shared by all games (publisher/publisher.yaml) */
export interface Publisher {
  admob?: { publisherId?: string };
  developer?: { name?: string; email?: string; website?: string; appIdPrefix?: string };
}

export interface ResolvedGame {
  spec: 0;
  id: string;
  title: string;
  appId: string;
  version: { name: string; code: number };
  locale: string;
  /** The languages the game ships in, English first (game.yaml `languages`; default English only) */
  languages: string[];
  /** Names kept as they are in every language (game.yaml `glossary`) */
  glossary: string[];
  audience: AudienceProfile;
  channel: { id: string; platform: 'android' | 'web' };
  /** null for kit: code */
  theme: string | null;
  saveKey: string;
  /** Smallest player-facing touch target, CSS px */
  minTouchPx: number;
  /** null for kit: code */
  round: TapCollectConfig | TapScoreConfig | null;
  ads: { policy: AdPolicy; admob: AdMobConfig | null; rewarded: boolean } | null;
  billing: { product: string } | null;
  kit: KidsConfig | CasualConfig | CodeConfig;
  /** Web portal whose SDK the game talks to */
  /** The portal SDK the build talks to: the channel's, or a build target's (`gp build --target playgama`) */
  portal: 'crazygames' | 'playgama' | null;
  android: { admobAppId: string | null };
  build: { mode: 'dev' | 'release' };
  /** The listing texts, as written (`gp submission`) */
  listing: { description: string | null; controls: string | null; orientation: 'both' | 'landscape' | 'portrait'; tags: string[] };
  concept: ConceptInput | null;
  /** The `story` section as written, the genre filled in; null when the game has none */
  story: { depth: StoryDepth; premise: string | null; file: string | null; voiced: boolean; genre: StoryGenre | null } | null;
  /** The `money` section as written (defaults are derived by `moneyDesign`, with the code and the balance report); null when the game has none */
  money: MoneyInput | null;
  /** game.yaml `sound` as written: `music` is what plays (a string), `false` (none, on purpose) or null (not said: the code decides) */
  sound: { music: string | false | null; why: string | null };
  /** The upload's size and load budget (the channel's, or raised by game.yaml `budget`); null when the channel has none */
  budget: Budget | null;
}
