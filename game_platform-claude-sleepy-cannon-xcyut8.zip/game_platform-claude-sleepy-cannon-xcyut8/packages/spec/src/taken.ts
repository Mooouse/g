// Concepts already taken on CrazyGames: genre + theme pairs with live titles, from our searches of the portal
// (docs/research/ideas-audit-2026-09.md, crazygames-requirements-2026-09.md, and the docs/concept.md searches of the games:
// Germ Bait, Nimbus Drift, Dread Throne, Starsilk; Hang the Moon's and Candle Crypt's in their REPORT.md and concept).
// Titles found only off the portal (itch.io jams, Steam) are marked so: a reviewer who knows them sees a copy all the same.
// Our own games are here too, marked "(ours)": the next game must not be one of them either. The validator warns when a
// game's concept reads like one of them (W_CONCEPT_TAKEN): not a ban — a prompt to name the difference.
// Search results are not the catalogue: an entry means "found live", its absence means nothing. Re-check every quarter.

export interface TakenConcept {
  id: string;
  /** What the concept is, for the message */
  what: string;
  /** Every group must match the game's title + concept text (each group: any of its words) */
  match: RegExp[];
  /** The groups must match within this many words of each other ("drop and merge", not "drops" far from "merge") */
  near?: number;
  /** Found only off the portal (itch.io jams, Steam): still a prompt to name the difference, but it costs less in
   * `gp uniqueness` than a genre + theme pair live on CrazyGames, where the reviewer compares first */
  offPortal?: boolean;
  /** Live titles found, the most relevant first */
  titles: string[];
  checked: string;
}

export const TAKEN_CONCEPTS: TakenConcept[] = [
  {
    id: 'survivors-microbes',
    what: 'a survivors-like with cells or germs',
    match: [/\b(survivors?|auto-?attack\w*|hordes?|endless (waves|enemies)|level-?up cards?)\b/i, /\b(germs?|microbes?|bacteri\w*|virus\w*|petri|organisms?|single-?cell\w*|a cell|the cell|your cell)\b/i],
    titles: ['Cell Survivor (June 2026)', 'Petri Panic (ours, rejected)'],
    checked: '2026-09-30',
  },
  {
    id: 'survivors',
    what: 'a survivors-like (auto-attack, hordes, level-up cards)',
    match: [/\b(survivors?-?like|survivors?|auto-?attack\w*|hordes? of)\b/i],
    titles: ['≈ 20 "X Survivors": Shadow, World, Nightfall, Grimdark, Tower Core, Path of Survivor …'],
    checked: '2026-09-30',
  },
  {
    id: 'spinning-tops',
    what: 'a spinning-top / push-out arena',
    match: [/\b(spinning[- ]tops?|spin(ning)? tops?|gyro\w*|beyblade\w*|spinners?)\b/i, /\b(arena|push\w*|knock\w*|brawl\w*|clash\w*)\b/i],
    titles: ['Top Clash (July 2026)', 'Gyroblade (September 2026)', 'Spinz.io', 'Push.io', 'Chaos Arena', 'Spin Brawl (ours)'],
    checked: '2026-09-30',
  },
  {
    id: 'steal-base',
    what: 'stealing loot from rival bases and carrying it home',
    match: [/\b(steal\w*|heist\w*|rob\w*|grab\w*|loot\w*)\b/i, /\b(bases?|dens?|vaults?|carry\w*|home|stash\w*|hoard\w*)\b/i],
    near: 10,
    titles: ['Steal Brainrot Online (Aug 2025)', 'Treasure Champion: Chest Capture'],
    checked: '2026-10-03',
  },
  {
    id: 'draw-defense',
    what: 'drawing lines against waves',
    match: [/\bdraw(s|ing|n)?\b/i, /\b(waves?|defen[cs]e\w*)\b/i],
    titles: ['Draw Defense (November 2024)', 'DOP Noob: Draw to Save'],
    checked: '2026-09-30',
  },
  {
    id: 'chain-reaction',
    what: 'a one-tap chain reaction',
    match: [/\bchain[- ]reactions?\b/i],
    titles: ['Chill Reaction (June 2026)'],
    checked: '2026-09-30',
  },
  {
    id: 'pulse-circuit',
    what: 'a pulse or signal running through a board of parts that fire in turn',
    match: [/\b(pulses?|signals?|current)\b/i, /\b(circuit\w*|components?|parts?|nodes?|board|wires?|fire[sd]? in turn)\b/i],
    titles: ['Pulseboard (found live by Kettlebot, 2026-10-01)'],
    checked: '2026-10-01',
  },
  {
    id: 'colony',
    what: 'a growing colony / territory capture',
    match: [/\b(colon(y|ies)|territor(y|ies)|capture area)\b/i],
    titles: ['Celloid', 'Colony', 'Kiomet', 'Paper.io 2'],
    checked: '2026-09-30',
  },
  {
    id: 'tube-sort',
    what: 'a tube / liquid / colour sort puzzle',
    match: [/\b(sort(s|ing)? (puzzle|the|by|into)|(tube|liquid|water|ball|bottle|colou?r) sort\w*|sort\w* (tubes?|liquids?|water|balls?|bottles?|colou?rs?))\b/i],
    titles: ['17+ sort games, three from June–August 2026; colour mixing is live (Colors Craft, Color Match)'],
    checked: '2026-09-30',
  },
  {
    id: 'arrow-escape',
    what: 'an arrow / slide-out escape puzzle',
    match: [/\barrows?\b/i, /\b(escape\w*|slide\w* (out|off)|off the board)\b/i],
    titles: ['Arrow Escape (January 2026)', 'Arrow Escape: Puzzle (February 2026)', 'Arrow Slide Puzzle'],
    checked: '2026-09-30',
  },
  {
    id: 'drop-merge',
    what: 'a drop-and-merge (Suika-like) puzzle',
    match: [/\bmerg\w*\b/i, /\b(drop\w*|fruits?|suika|jars?)\b/i],
    // Nimbus Drift: "clouds … merge into storms" and a field's rain "drops" far apart are not a Suika-like
    near: 5,
    titles: ['11+ games: Merge Fruits (with a tilting jar), Fruit Merge: Juicy Drop, Drop Some Fruits …'],
    checked: '2026-09-30',
  },
  {
    id: 'ball-roguelite',
    what: 'a ball / brick roguelite',
    match: [/\b(balls?|bricks?|blocks?)\b/i, /\b(rogue\w*|bounc\w*|breaker)\b/i],
    titles: ['ABLOCKALYPSE', 'Bounce Heroes (balls that combine)'],
    checked: '2026-09-30',
  },
  {
    id: 'cozy-idle',
    what: 'a garden / aquarium / bakery idle',
    match: [/\b(idle|tycoon|incremental)\b/i, /\b(gardens?|aquarium|fish|ponds?|bakery|cafe|café)\b/i],
    titles: ['17+: Garden Idle, Florist Idle, Pixel Aquarium Tycoon (fish mutations) …'],
    checked: '2026-09-30',
  },
  {
    id: 'launch-upgrade',
    what: 'a launch-for-distance game with upgrades',
    match: [/\b(launch\w*|catapult\w*|cannon|fling\w*|yeet\w*|throw\w*)\b/i, /\b(distance|upgrades?|how far)\b/i],
    titles: ['Burrito Bison', 'Learn to Fly', 'Bouncemasters', 'Yeet the Gnome (ours)'],
    checked: '2026-09-30',
  },
  {
    id: 'microbes',
    what: 'a microbe / cell theme',
    match: [/\b(germs?|microbes?|bacteri\w*|petri|amoeba\w*|single-?cell\w*|a cell|the cell|your cell)\b/i],
    titles: ['Agar.io', 'Germs.io', 'Cell Survivor', 'Germ War', 'and two of our own games (Petri Panic, Germ Bait)'],
    checked: '2026-09-30',
  },
  // From the concept searches of games 6–11 (docs/team/retro-games-6-11.md)
  {
    id: 'bait-swarm',
    what: 'luring a swarm with bait into hazards',
    match: [/\b(bait\w*|lur(e|es|ed|ing)|sugar)\b/i, /\b(swarms?|hordes?|crowds?|germs?|microbes?)\b/i],
    near: 8,
    titles: ['Germ Bait (ours)'],
    checked: '2026-09-30',
  },
  {
    id: 'balance-mobile',
    what: 'a balance puzzle (weights on levers, a hanging mobile)',
    // Not "hang" or "scales" alone: "Tips: hang on to the rope" and "scales deflect weak weights" are no balance puzzle
    match: [/\b(balanc\w*|tip(s|ping|ped)?|levers?|weights?)\b/i, /\b(mobiles?|rods?|see-?saws?|fulcrum\w*|(balance|weighing|kitchen) scales?)\b/i],
    near: 6,
    titles: ['Hang the Moon (ours; the web\'s balance puzzles are single scales with algebra)'],
    checked: '2026-09-30',
  },
  {
    id: 'cursor-lasso',
    what: 'drawing a loop around enemies with the cursor',
    match: [/\b(loops?|lasso\w*|encircl\w*|circl(e|es|ing))\b/i, /\b(draw\w*|cursor|mouse|trac(e|es|ing))\b/i],
    near: 8,
    titles: ['Cowboy Lasso Master (CrazyGames)', 'Last Lasso and Loopy Lasso (GMTK Jam 2025)', 'Encircle (itch.io)', 'FIRELOOP'],
    checked: '2026-09-30',
  },
  {
    id: 'labyrinth-thread',
    what: 'a labyrinth with a thread (Minotaur, Ariadne)',
    match: [/\b(labyrinths?|mazes?|minotaur)\b/i, /\b(threads?|string|ariadne|spool\w*)\b/i],
    near: 8,
    offPortal: true,
    titles: ['Minotaur Maze (PROCJAM 2025: follow the thread back)', 'Starsilk (ours: the thread is light, fence and lasso)'],
    checked: '2026-09-30',
  },
  {
    id: 'rope-untangle',
    what: 'a rope / untangle puzzle',
    match: [/\b(untangl\w*|tangl(e|es|ed|ing))\b/i, /\b(ropes?|threads?|wires?|knots?|puzzles?)\b/i],
    near: 6,
    titles: ['Tangle Master', 'Twisted Tangle', 'Rope Stitch Puzzle', 'Crazy Rope'],
    checked: '2026-09-30',
  },
  {
    id: 'weather-puzzle',
    what: 'a weather / cloud puzzle (steer clouds, rain on fields)',
    // "Rain of arrows on the enemy field" is a metaphor and a battlefield, not weather over farmland
    match: [/\b(clouds?|rain\w*|weather|storms?)\b(?!\s+of\b)/i, /\b(puzzles?|(?<!\b(enemy|battle|force|mine|star|asteroid|playing) )fields?|crops?|herd\w*|steer\w*|blow\w*|wind)\b/i],
    near: 6,
    offPortal: true,
    titles: ['Cloud Shepherd (itch.io: cloud shapes over fields)', 'Rain on Your Parade (Steam: steer one cloud)', 'RainyCloud (Steam)', 'Nimbus Drift (ours)'],
    checked: '2026-09-30',
  },
  {
    id: 'liar-deduction',
    what: 'a who-is-lying deduction puzzle',
    match: [/\b(liars?|lying|lies)\b/i, /\b(deduc\w*|puzzles?|who|suspects?|clues?|cases?)\b/i],
    near: 6,
    titles: ['Braindom 2: Who is Lying? (CrazyGames)', 'Who is Lying (web: exactly one liar)', 'Clues by Sam'],
    checked: '2026-09-30',
  },
  {
    id: 'villain-td',
    what: 'a tower defense from the villain\'s side (heroes raid your dungeon)',
    match: [/\b(tower[- ]defen[cs]e|td|traps?|defend\w*)\b/i, /\b(villains?|demons?|demon (king|lord)|dark lord|evil|dungeon (keeper|lord|master)s?|(heroes|adventurers) (raid|invade|attack)\w*)\b/i],
    titles: ['Dungeon Warfare 1–2', 'Evil Tower (CrazyGames)', 'Legend of Keepers', 'Dread Throne (ours)'],
    checked: '2026-09-30',
  },
  {
    id: 'maze-td',
    what: 'a maze tower defense (walls or rotated tiles reroute the waves)',
    match: [/\b(tower[- ]defen[cs]e|td|towers?|waves?)\b/i, /\b(maz(e|es|ing)|rotat\w* tiles?|tiles? rotat\w*|reroute\w*)\b/i],
    near: 8,
    titles: ['Maze Tower Defence', 'Maze Warden TD', 'REROUTE', 'Emberward', 'Monster Tiles TD: Tower Wars (rotate a tile between waves)'],
    checked: '2026-09-30',
  },
  {
    id: 'twin-stick-roguelike',
    what: 'a room-clearing twin-stick roguelike (Soul Knight-like)',
    match: [/\b(twin-?stick|rogue-?(like|lite)s?|room-?clearing|bullet[- ]hell)\b/i, /\b(dungeons?|crypts?|rooms?|floors?|shoot\w*|guns?|weapons?)\b/i],
    titles: ['Soul Knight', 'Enter the Gungeon', 'The Binding of Isaac', 'Archero', 'Candle Crypt (ours)'],
    checked: '2026-09-30',
  },
];

/** The text the taken concepts are matched against: the parts as sentences, so that a negation in one (a title like
 * "Don't Look Down", a pitch ending in "no timer") can't reach into the next */
export function conceptText(...parts: (string | undefined)[]): string {
  return parts
    .map((p) => (p ?? '').trim())
    .filter(Boolean)
    .join('. ');
}

/** A negation up to the end of its clause, and at most NEGATION_REACH words: "Nothing is dropped, stacked or merged:" and
 * "You never draw with a cursor" say what the game is NOT (Hang the Moon, Starsilk) — the words in them don't make it
 * one. "With no timer, you drop fruits …" and "it isn't hard to drop and merge fruits" still say what it is. */
const NEGATION = /\b(no|not|nothing|never|without|neither|nor|none|cannot|\w+n['’]t)\b/gi;
const CLAUSE_END = /[.,;:!?()[\]—–\n]|\b(but|so|instead|yet|while|then)\b/gi;
/** After a comma, the rest of a negated list ("dropped, stacked or merged") is still negated */
const LIST_TAIL = /^\s*[\p{L}'’-]+(\s*,\s*[\p{L}'’-]+)*,?\s+(or|nor)\s+[\p{L}'’-]+/u;
const NEGATION_REACH = 4;
/** Words the reach doesn't count ("nothing is dropped", "never draw with a cursor") */
const FILLER = new Set(['is', 'are', 'was', 'were', 'be', 'a', 'an', 'the', 'any']);
const WORD = /[\p{L}\p{N}'’-]+/gu;

export function withoutNegations(text: string): string {
  let out = '';
  let at = 0;
  for (const m of text.matchAll(NEGATION)) {
    if (m.index! < at) continue;
    const from = m.index! + m[0].length;
    const rest = text.slice(from);
    let end = rest.length;
    for (const c of rest.matchAll(CLAUSE_END)) {
      if (c[0] === ',' && LIST_TAIL.test(rest.slice(c.index! + 1))) continue;
      end = c.index!;
      break;
    }
    const last = [...rest.matchAll(WORD)].filter((w) => !FILLER.has(w[0].toLowerCase()))[NEGATION_REACH - 1];
    if (last) end = Math.min(end, last.index! + last[0].length);
    const stop = from + end;
    out += text.slice(at, m.index!) + ' '.repeat(stop - m.index!);
    at = stop;
  }
  return out + text.slice(at);
}

function matches(t: TakenConcept, text: string): boolean {
  if (!t.match.every((re) => re.test(text))) return false;
  // Word positions of every match of every group; some pick of one per group, each at its own word ("levers" can't
  // stand for two groups), must fit in `near` words when the entry has a `near`
  const starts = [...text.matchAll(WORD)].map((w) => w.index!);
  const word = (i: number) => starts.filter((s) => s <= i).length - 1;
  const at = t.match.map((re) => [...text.matchAll(new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g'))].map((m) => word(m.index!)));
  const near = t.near ?? Infinity;
  const fits = (g: number, lo: number, hi: number, used: number[]): boolean =>
    g === at.length ||
    at[g].some((w) => !used.includes(w) && Math.max(hi, w) - Math.min(lo, w) <= near && fits(g + 1, Math.min(lo, w), Math.max(hi, w), [...used, w]));
  return fits(0, Infinity, -Infinity, []);
}

/** "Nimbus Drift (ours)" is the game called "Nimbus Drift", and only that one: "Tangle" is not "Tangle Master" */
function isOurs(title: string, own: string[]): boolean {
  const i = title.indexOf(' (ours');
  return i >= 0 && own.includes(title.slice(0, i).trim().toLowerCase());
}

/**
 * The taken concepts a game's text reads like (the most specific first: entries with more groups). Build `text` with
 * conceptText(title, pitch, different). `self` is the game's title, and its id: its own "(ours)" title isn't a match
 * against itself — also after a rename, when only the id still says it (Germ Bait → Petri Defense, id germ-bait) — and
 * an entry with no other title is skipped.
 */
export function takenConceptsFor(text: string, self?: string, id?: string): TakenConcept[] {
  const affirmed = withoutNegations(text);
  const own = [self, id?.replace(/-/g, ' ')].map((x) => x?.trim().toLowerCase()).filter((x): x is string => !!x);
  return TAKEN_CONCEPTS.filter((t) => matches(t, affirmed))
    .map((t) => (own.length ? { ...t, titles: t.titles.filter((x) => !isOurs(x, own)) } : t))
    .filter((t) => t.titles.length > 0)
    .sort((a, b) => b.match.length - a.match.length);
}
