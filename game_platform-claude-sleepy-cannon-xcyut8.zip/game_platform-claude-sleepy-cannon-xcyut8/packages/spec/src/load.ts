// Parse game.yaml keeping source positions, so every issue can point to a line.

import { isMap, isSeq, LineCounter, parseDocument, type Document } from 'yaml';
import type { Issue } from './errors.ts';

export interface Loaded {
  data: unknown;
  /** 1-based line of the node at a path (or of its closest existing parent) */
  lineOf(path: readonly (string | number)[]): number | undefined;
  issues: Issue[];
}

export function loadYaml(text: string): Loaded {
  const lc = new LineCounter();
  const doc: Document = parseDocument(text, { lineCounter: lc, prettyErrors: false, uniqueKeys: true });
  const issues: Issue[] = [];
  for (const e of doc.errors) {
    const line = e.linePos?.[0]?.line ?? lc.linePos(e.pos[0]).line;
    issues.push({ code: 'E_YAML', severity: 'error', path: [], message: e.message.split('\n')[0], fix: 'Check indentation (2 spaces), colons, quotes and brackets on this line.', line });
  }
  const lineOf = (path: readonly (string | number)[]): number | undefined => {
    for (let n = path.length; n >= 0; n--) {
      const p = path.slice(0, n);
      let node: unknown = p.length ? doc.getIn(p, true) : doc.contents;
      // For a map key, point at the key itself
      if (n > 0) {
        const parent: unknown = n > 1 ? doc.getIn(path.slice(0, n - 1), true) : doc.contents;
        if (isMap(parent)) {
          const pair = parent.items.find((it) => (it.key as { value?: unknown })?.value === path[n - 1]);
          if (pair?.key) node = pair.key;
        } else if (isSeq(parent)) node = parent.items[path[n - 1] as number];
      }
      const range = (node as { range?: [number, number, number] } | undefined)?.range;
      if (range) return lc.linePos(range[0]).line;
    }
    return undefined;
  };
  return { data: issues.length ? null : doc.toJS(), lineOf, issues };
}
