// Real outcomes, recorded per game in publisher/results.yaml: portal verdicts, Basic Launch metrics, plays and revenue.
// The money model (money.ts) compares its predictions with them and, once there are enough, narrows its ranges.
//
// The rule (docs/guides/game-design.md → Design for money → Calibration), one for every quantity:
//   fewer than MIN_RESULTS recorded outcomes → reported next to the forecast, the ranges stay as the table says;
//   MIN_RESULTS or more → each of low / mid / high moves toward what was observed by n / (n + PRIOR_WEIGHT):
//     probabilities (approval at review, Full Launch after Basic Launch): toward the observed rate k / n;
//     plays per day: toward the observed min / median / max;
//     revenue per play: the model's per-play revenue is scaled toward the median of observed ÷ predicted — only for
//       games whose predicted per-play revenue is at least MIN_PER_PLAY (a design the model says earns ~nothing tells
//       nothing about the price of an ad: dividing by it would scale everything ×millions), and the scale is clamped
//       to PER_PLAY_SCALE (0.1–10).
//   The table's numbers count as PRIOR_WEIGHT results: three real games pull it half-way, thirty almost all the way.
//   A retro-forecast (a record without `predicted`) runs idea mode on what the record says: genre, concept,
//   uniqueness and — when recorded — the real design (sessionMin, breaks, rewarded), else the genre's defaults.

import type { JsonSchema } from '@gp/core/schema';
import { checkSchema } from './check-schema.ts';
import type { Issue } from './errors.ts';
import { forecast, GENRES, ideaDesign, MONEY_TABLE, RESUBMISSION_ROW, RESUBMISSIONS, type Calibration, type Range, type Resubmission } from './money.ts';
import { CHANNELS } from './profiles.ts';

export const MIN_RESULTS = 3;
export const PRIOR_WEIGHT = 3;
/** Below this predicted revenue per play (EUR; = €0.1 per 1,000 plays) a game's recorded revenue doesn't scale the model */
export const MIN_PER_PLAY = 0.0001;
/** The per-play scale from recorded revenue stays inside this */
export const PER_PLAY_SCALE = { min: 0.1, max: 10 } as const;

export interface RecordedResult {
  game: string;
  title?: string;
  repo?: string;
  channel: string;
  genre?: string;
  /** The concept's pitch as submitted: a retro-forecast of the review odds reads it (taken concepts) */
  concept?: string;
  /** `gp uniqueness` at submission, when it existed */
  uniqueness?: number;
  /** The design as submitted (money.session / money.rewarded): the retro-forecast uses it instead of the genre's defaults */
  sessionMin?: number;
  breaks?: number;
  rewarded?: string[];
  submitted?: string;
  /** What `gp forecast` said at submission (forecast.md prints these lines) */
  predicted?: { pApproval?: number; pFullLaunch?: number; revenuePerDay?: [number, number, number] };
  review?: { verdict: 'approved' | 'rejected' | 'pending'; date?: string; reason?: string };
  /** The portal category it was submitted under: Basic Launch scores rank a game against its peers, and the category picks them */
  category?: string;
  basicLaunch?: {
    verdict?: 'full-launch' | 'retry' | 'stopped' | 'pending';
    conversion1min?: number;
    avgPlaytimeMin?: number;
    d1?: number;
    plays?: number;
    days?: number;
    /** The score screen: each metric scores 1–5 per device class, Full Launch needs ≥ 9 of 15 on one (BASIC_LAUNCH) */
    scores?: BasicLaunchScores;
  };
  fullLaunch?: { playsPerDay?: number; revenuePerDayEUR?: number; month?: number };
  installsPerDay?: number;
  notes?: string;
}

/** One metric on the Basic Launch score screen: the raw value, its score, and the value where the next score starts */
export interface MetricScore {
  value?: number;
  score?: number;
  next?: number;
}

/** One device class on the score screen */
export interface DeviceScores {
  playtime?: MetricScore;
  d1?: MetricScore;
  conversion?: MetricScore;
  /** The screen's total (3–15); when all three scores are there it must be their sum */
  total?: number;
}

export interface BasicLaunchScores {
  /** The day the screen was read */
  date?: string;
  /**
   * The build the scores measured: "1.3.6", or a range "1.0.0–1.3.6" when updates went live during the window. Without
   * it the brief infers it from publisher/updates.yaml (the versions finished before the screen) and says so
   */
  version?: string;
  desktop?: DeviceScores;
  /** "Mobile and Tablet" on the screen */
  mobile?: DeviceScores;
}

/**
 * CrazyGames' Basic Launch scoring as we know it (docs/research/feedback-and-metrics-2026-10.md §1): three metrics, each
 * scored 1–5 per device class (Desktop; Mobile and Tablet) against peer games — so the same raw value scores differently by
 * category and device — and Full Launch needs at least 9 of 15 on a device class. The thresholds are not published: the
 * ones we have seen are in publisher/results.yaml (`next`).
 */
export const BASIC_LAUNCH = {
  metrics: ['playtime', 'd1', 'conversion'] as const,
  devices: ['desktop', 'mobile'] as const,
  minScore: 1,
  maxScore: 5,
  fullLaunchAt: 9,
  of: 15,
  labels: { playtime: 'average playtime', d1: 'D1 retention', conversion: 'gameplay conversion (≥ 1 min played)' },
  units: { playtime: 'min', d1: 'share', conversion: 'share' },
} as const;

/** A device class's total: the screen's, or the sum of its three scores when all are recorded */
export function deviceTotal(d: DeviceScores | undefined): number | null {
  if (!d) return null;
  if (typeof d.total === 'number') return d.total;
  const xs = BASIC_LAUNCH.metrics.map((m) => d[m]?.score);
  return xs.every((x) => typeof x === 'number') ? (xs as number[]).reduce((a, b) => a + b, 0) : null;
}

/** "Desktop 7/15 (playtime 4 · D1 2 · conversion 1), Mobile 9/15 …" — or null when nothing is recorded */
export function scoresLine(s: BasicLaunchScores | undefined): string | null {
  if (!s) return null;
  const parts = BASIC_LAUNCH.devices.flatMap((dev) => {
    const d = s[dev];
    if (!d) return [];
    const t = deviceTotal(d);
    const each = BASIC_LAUNCH.metrics.map((m) => (d[m]?.score !== undefined ? `${m === 'd1' ? 'D1' : m} ${d[m]!.score}` : null)).filter(Boolean).join(' · ');
    return [`${dev === 'desktop' ? 'Desktop' : 'Mobile'} ${t ?? '?'}/${BASIC_LAUNCH.of}${t !== null && t >= BASIC_LAUNCH.fullLaunchAt ? ' ✓' : ''}${each ? ` (${each})` : ''}`];
  });
  return parts.length ? parts.join(', ') : null;
}

const DATE = { type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}$', description: 'YYYY-MM-DD (quote it)' } as const;
const SHARE = (description: string): JsonSchema => ({ type: 'number', minimum: 0, maximum: 1, description });

const SCORE = (what: string, value: JsonSchema): JsonSchema => ({
  type: 'object',
  description: `${what}: the raw value, its score and where the next score starts`,
  properties: {
    value,
    score: { type: 'integer', minimum: 1, maximum: 5, description: 'The score on the screen, 1–5' },
    next: { ...value, description: `Where the next score starts (the screen shows it), same unit as value` },
  },
  additionalProperties: false,
});
const DEVICE = (name: string): JsonSchema => ({
  type: 'object',
  description: `${name}: the three metrics and the total`,
  properties: {
    playtime: SCORE('Average playtime', { type: 'number', minimum: 0, description: 'minutes (9m31s = 9.52)' }),
    d1: SCORE('D1 retention', SHARE('a share: 2.96 % = 0.0296')),
    conversion: SCORE('Gameplay conversion', SHARE('a share of players past the first minute: 51.25 % = 0.5125')),
    total: { type: 'integer', minimum: 3, maximum: 15, description: 'The screen\'s total of 15 (the sum of the three scores)' },
  },
  additionalProperties: false,
});

export const RESULTS_SCHEMA: JsonSchema = {
  title: 'publisher/results.yaml',
  description: 'Real outcomes per game: what the portal or store said and what the game earned. The money model compares its forecasts with them.',
  type: 'object',
  properties: {
    results: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          game: { type: 'string', pattern: '^[a-z][a-z0-9-]{1,39}$', description: 'Game id' },
          title: { type: 'string', minLength: 1 },
          repo: { type: 'string', description: 'Where the game lives (owner/repo)' },
          channel: { enum: Object.keys(CHANNELS), description: 'Where it was submitted' },
          category: { type: 'string', minLength: 2, description: 'The portal category it was submitted under (Basic Launch scores rank it against that category\'s games: choose it on purpose)' },
          genre: { enum: [...GENRES], description: 'The genre the model benchmarks it with' },
          concept: { type: 'string', minLength: 10, description: 'The pitch as submitted (a retro-forecast reads it)' },
          uniqueness: { type: 'number', minimum: 0, maximum: 100, description: 'gp uniqueness at submission' },
          sessionMin: { type: 'number', exclusiveMinimum: 0, description: 'The designed session, minutes (money.session.minutes): the retro-forecast uses it' },
          breaks: { type: 'integer', minimum: 0, description: 'Natural breaks per session (money.session.breaks): the retro-forecast uses it' },
          rewarded: { type: 'array', items: { type: 'string', minLength: 1 }, description: 'Rewarded placements or kinds (revive, x2, hint, …): the retro-forecast uses them' },
          submitted: DATE,
          predicted: {
            type: 'object',
            description: 'What gp forecast said at submission (copy the lines from forecast.md)',
            properties: {
              pApproval: SHARE('P(approval), mid'),
              pFullLaunch: SHARE('P(Full Launch), mid'),
              revenuePerDay: { type: 'array', items: { type: 'number', minimum: 0 }, minItems: 3, maxItems: 3, description: '[pessimistic, median, optimistic] EUR/day in Full Launch' },
            },
            additionalProperties: false,
          },
          review: {
            type: 'object',
            properties: { verdict: { enum: ['approved', 'rejected', 'pending'] }, date: DATE, reason: { type: 'string' } },
            required: ['verdict'],
            additionalProperties: false,
          },
          basicLaunch: {
            type: 'object',
            properties: {
              verdict: { enum: ['full-launch', 'retry', 'stopped', 'pending'] },
              conversion1min: SHARE('share of players past the first minute'),
              avgPlaytimeMin: { type: 'number', minimum: 0 },
              d1: SHARE('day-1 retention'),
              plays: { type: 'integer', minimum: 0 },
              days: { type: 'integer', minimum: 0 },
              scores: {
                type: 'object',
                description: 'The Basic Launch score screen: per device class, each metric as the raw value and its score 1–5 (Full Launch needs 9+ of 15 on a device class)',
                properties: {
                  date: DATE,
                  version: { type: 'string', pattern: '^\\d+\\.\\d+(\\.\\d+)?( ?[–-] ?\\d+\\.\\d+(\\.\\d+)?)?$', description: 'The build the scores measured (game.yaml version.name): "1.3.6", or "1.0.0–1.3.6" when updates went live during the Basic Launch window. `gp design` labels the scores with it (without it: inferred from publisher/updates.yaml)' },
                  desktop: DEVICE('Desktop'),
                  mobile: DEVICE('Mobile and Tablet'),
                },
                additionalProperties: false,
              },
            },
            additionalProperties: false,
          },
          fullLaunch: {
            type: 'object',
            properties: { playsPerDay: { type: 'number', minimum: 0 }, revenuePerDayEUR: { type: 'number', minimum: 0 }, month: { type: 'integer', minimum: 1 } },
            additionalProperties: false,
          },
          installsPerDay: { type: 'number', minimum: 0 },
          notes: { type: 'string' },
        },
        required: ['game', 'channel'],
        additionalProperties: false,
      },
    },
  },
  required: ['results'],
  additionalProperties: false,
};

/** Schema problems in a parsed results.yaml (an empty list: fine) */
export function checkResults(data: unknown): Issue[] {
  const issues = checkSchema(data, RESULTS_SCHEMA, () => []);
  if (issues.length) return issues;
  // A score screen's total is the sum of its three scores
  ((data as { results?: RecordedResult[] }).results ?? []).forEach((r, i) => {
    for (const dev of BASIC_LAUNCH.devices) {
      const d = r.basicLaunch?.scores?.[dev];
      if (!d || typeof d.total !== 'number') continue;
      const sum = deviceTotal({ ...d, total: undefined });
      if (sum !== null && sum !== d.total)
        issues.push({ code: 'E_RESULTS_SCORES', severity: 'error', path: ['results', i, 'basicLaunch', 'scores', dev, 'total'], message: `${r.game}: ${dev} total ${d.total}, but its scores add up to ${sum}`, fix: 'Copy the total and the three scores from the same score screen.' });
    }
  });
  return issues;
}

const median = (xs: number[]) => {
  const s = [...xs].sort((a, b) => a - b);
  return s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
};

/** Move each of low / mid / high toward the observed ones by n / (n + PRIOR_WEIGHT) */
export function blend(prior: Range, observed: Range, n: number): Range {
  const w = n / (n + PRIOR_WEIGHT);
  return { low: prior.low + w * (observed.low - prior.low), mid: prior.mid + w * (observed.mid - prior.mid), high: prior.high + w * (observed.high - prior.high) };
}

export interface Comparison {
  game: string;
  what: string;
  predicted: string;
  actual: string;
  /** For verdicts: the Brier term (p − outcome)²; null for numbers */
  brier: number | null;
  /** The prediction was recorded at submission (true) or made now from the record (a retro-forecast) */
  recorded: boolean;
}

export interface CalibrationReport {
  calibration: Calibration;
  comparisons: Comparison[];
  /** Mean Brier score over the verdicts (0 perfect, 0.25 a coin flip) */
  brier: number | null;
  counts: { review: number; basicLaunch: number; plays: number; revenue: number };
  markdown: string;
}

const pct = (p: number) => `${Math.round(p * 100)}%`;

/** A retro-forecast for a recorded game: idea mode from what the record says (concept, genre, uniqueness, the design) */
function retro(r: RecordedResult) {
  const { design } = ideaDesign({ channel: r.channel, genre: r.genre, pitch: r.concept, title: r.title, unique: r.uniqueness, sessionMin: r.sessionMin, breaks: r.breaks, rewarded: r.rewarded });
  return forecast(design);
}

/** EUR per day in the revenue stage, per scenario: month 2 ÷ 30 (the whole path: active days, "Remove ads", every channel) */
export function revenuePerDay(f: { months: Record<'pessimistic' | 'median' | 'optimistic', [number, number, number]> }): Range {
  return { low: f.months.pessimistic[1] / 30, mid: f.months.median[1] / 30, high: f.months.optimistic[1] / 30 };
}

/** What a record's outcome makes of the game's next submission: after a stop, after a rejection, or nothing (approved, pending) */
function outcomeOf(r: RecordedResult): Resubmission | null {
  if (r.basicLaunch?.verdict === 'stopped') return 'after-stop';
  if (r.review?.verdict === 'rejected') return 'after-rejection';
  return null;
}

/**
 * The game's next submission on `channel`, read from its records (file order = time order): a resubmission after a Basic
 * Launch stop or after a rejection when its latest record says so; null for a new game, or one whose latest submission
 * was approved and is still in Basic Launch (an update, not a resubmission)
 */
/**
 * Who a game is in publisher/results.yaml: its ids (game.yaml's and its folder's), its title, its repository (owner/repo).
 * A record whose `game` differs from game.yaml's id (Idle Garage Evolution 1.5.0: recorded under another id) is still found
 */
export interface GameKey {
  ids: readonly string[];
  title?: string | null;
  repo?: string | null;
}

/** Words of a name that say nothing about which game it is */
const NAME_NOISE = new Set(['idle', 'game', 'games', 'super', 'mega', 'tycoon', 'simulator', 'clicker', 'merge', 'rush', 'royale', 'the', 'and', 'with', 'evolution', 'legend', 'legends', 'quest', 'world', 'master', 'puzzle']);
const nameWords = (s: string | null | undefined) => new Set((s ?? '').toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length >= 4 && !NAME_NOISE.has(w)));
/** owner/repo from "QmaCyber/game19", a remote URL or a proxy path ending in it; lower case */
export const normRepo = (r: string | null | undefined): string | null => {
  const m = (r ?? '').trim().replace(/\.git$/, '').replace(/\/+$/, '').match(/([\w.-]+)\/([\w.-]+)$/);
  return m ? `${m[1]}/${m[2]}`.toLowerCase() : null;
};

/**
 * A game's records, in file order: by id or title; and by repo — a record of the same repository counts when the
 * repository holds that one game only, or when the record's id or title shares a word with the game's (a repository
 * reused for a new game — game6 held three — doesn't make the new game a resubmission of the old)
 */
export function recordsOf(results: readonly RecordedResult[], key: GameKey): RecordedResult[] {
  const ids = new Set(key.ids);
  const title = key.title?.toLowerCase() ?? null;
  const byName = (r: RecordedResult) => ids.has(r.game) || (!!title && r.title?.toLowerCase() === title);
  const repo = normRepo(key.repo);
  if (!repo) return results.filter(byName);
  const sameRepo = results.filter((r) => normRepo(r.repo) === repo);
  const one = new Set(sameRepo.map((r) => r.game)).size === 1;
  const mine = new Set([...key.ids.flatMap((i) => [...nameWords(i)]), ...nameWords(key.title)]);
  const shares = (r: RecordedResult) => [...nameWords(r.game), ...nameWords(r.title)].some((w) => mine.has(w));
  return results.filter((r) => byName(r) || (normRepo(r.repo) === repo && (one || shares(r))));
}

export function resubmissionOf(results: readonly RecordedResult[], game: string | GameKey, channel: string): { kind: Resubmission; last: RecordedResult } | null {
  const mine = recordsOf(results, typeof game === 'string' ? { ids: [game] } : game).filter((r) => r.channel === channel);
  const last = mine.at(-1);
  if (!last) return null;
  const kind = outcomeOf(last);
  return kind ? { kind, last } : null;
}

/** The recorded resubmissions on a channel: a record whose game had an earlier record ending in a stop or a rejection */
export function resubmissions(results: readonly RecordedResult[], channel: string): { game: string; kind: Resubmission; verdict: 'approved' | 'rejected' | 'pending' }[] {
  const out: { game: string; kind: Resubmission; verdict: 'approved' | 'rejected' | 'pending' }[] = [];
  const before = new Map<string, Resubmission | null>();
  for (const r of results) {
    if (r.channel !== channel) continue;
    const prev = before.get(r.game);
    if (prev && r.review) out.push({ game: r.game, kind: prev, verdict: r.review.verdict });
    before.set(r.game, outcomeOf(r));
  }
  return out;
}

/** What the recorded results say about the model on a channel: comparisons, and the narrowing when there are enough */
export function calibrate(results: readonly RecordedResult[], channel: string): CalibrationReport {
  const on = results.filter((r) => r.channel === channel);
  const comparisons: Comparison[] = [];
  const notes: string[] = [];
  const calibration: Calibration = { notes };

  // Review verdicts
  const reviewed = on.filter((r) => r.review && r.review.verdict !== 'pending');
  for (const r of reviewed) {
    const p = r.predicted?.pApproval ?? retro(r).pApproval.mid;
    const ok = r.review!.verdict === 'approved';
    comparisons.push({ game: r.game, what: 'review', predicted: `P(approval) ${pct(p)}`, actual: `${r.review!.verdict}${r.review!.date ? ` (${r.review!.date})` : ''}${r.review!.reason ? `: "${r.review!.reason}"` : ''}`, brier: (p - (ok ? 1 : 0)) ** 2, recorded: r.predicted?.pApproval !== undefined });
  }
  if (reviewed.length >= MIN_RESULTS) {
    const rate = reviewed.filter((r) => r.review!.verdict === 'approved').length / reviewed.length;
    calibration.approval = (p) => blend(p, { low: rate, mid: rate, high: rate }, reviewed.length);
    notes.push(`P(approval) pulled toward the recorded rate ${pct(rate)} (${reviewed.length} reviews, weight ${reviewed.length}/${reviewed.length + PRIOR_WEIGHT})`);
  }

  // Basic Launch verdicts
  const launched = on.filter((r) => r.basicLaunch?.verdict && r.basicLaunch.verdict !== 'pending');
  for (const r of launched) {
    const p = r.predicted?.pFullLaunch ?? retro(r).pFullLaunch.mid;
    const ok = r.basicLaunch!.verdict === 'full-launch';
    const m = r.basicLaunch!;
    const metrics = [m.conversion1min !== undefined && `1-min ${pct(m.conversion1min)}`, m.avgPlaytimeMin !== undefined && `${m.avgPlaytimeMin} min`, m.d1 !== undefined && `D1 ${pct(m.d1)}`].filter(Boolean).join(', ');
    const scores = scoresLine(m.scores);
    comparisons.push({ game: r.game, what: 'Basic Launch', predicted: `P(Full Launch) ${pct(p)}`, actual: `${m.verdict}${metrics ? ` (${metrics})` : ''}${scores ? `; scores ${scores}` : ''}`, brier: (p - (ok ? 1 : 0)) ** 2, recorded: r.predicted?.pFullLaunch !== undefined });
  }
  if (launched.length >= MIN_RESULTS) {
    const rate = launched.filter((r) => r.basicLaunch!.verdict === 'full-launch').length / launched.length;
    calibration.fullLaunch = (p) => blend(p, { low: rate, mid: rate, high: rate }, launched.length);
    notes.push(`P(Full Launch) pulled toward the recorded rate ${pct(rate)} (${launched.length} Basic Launches)`);
  }

  // Resubmissions: the cap on P(approval) for a game judged before, toward the recorded rate of its kind
  const again = resubmissions(on, channel).filter((x) => x.verdict !== 'pending');
  for (const kind of RESUBMISSIONS) {
    const xs = again.filter((x) => x.kind === kind);
    if (!xs.length) continue;
    const ok = xs.filter((x) => x.verdict === 'approved').length;
    const what = kind === 'after-stop' ? 'after a Basic Launch stop' : 'after a rejection';
    const row = MONEY_TABLE[RESUBMISSION_ROW[kind]];
    const prior = { low: row.low, mid: row.mid, high: row.high };
    if (xs.length >= MIN_RESULTS) {
      const rate = ok / xs.length;
      (calibration.resubmission ??= {})[kind] = blend(prior, { low: rate, mid: rate, high: rate }, xs.length);
      notes.push(`resubmissions ${what}: ${ok} of ${xs.length} approved (${xs.map((x) => `${x.game} ${x.verdict}`).join(', ')}) — their P(approval) cap pulled toward ${pct(rate)}`);
    } else notes.push(`resubmissions ${what}: ${ok} of ${xs.length} approved (${xs.map((x) => `${x.game} ${x.verdict}`).join(', ')}) — fewer than ${MIN_RESULTS}: the cap is the table's`);
  }

  // Plays and revenue in Full Launch
  const played = on.filter((r) => typeof r.fullLaunch?.playsPerDay === 'number');
  const earned = played.filter((r) => typeof r.fullLaunch?.revenuePerDayEUR === 'number');
  for (const r of earned) {
    const f = retro(r);
    const pr = r.predicted?.revenuePerDay;
    const model = pr ? { low: pr[0], mid: pr[1], high: pr[2] } : revenuePerDay(f);
    const act = r.fullLaunch!.revenuePerDayEUR!;
    comparisons.push({ game: r.game, what: 'revenue/day', predicted: `€${model.low.toFixed(1)}–€${model.high.toFixed(1)} (mid €${model.mid.toFixed(1)})`, actual: `€${act.toFixed(1)}/day (${r.fullLaunch!.playsPerDay} plays/day)${act < model.low ? ' — below the range' : act > model.high ? ' — above the range' : ' — inside the range'}`, brier: null, recorded: !!pr });
  }
  if (played.length >= MIN_RESULTS) {
    const xs = played.map((r) => r.fullLaunch!.playsPerDay!);
    calibration.plays = (p) => blend(p, { low: Math.min(...xs), mid: median(xs), high: Math.max(...xs) }, xs.length);
    notes.push(`plays/day pulled toward the recorded ${Math.min(...xs)}–${Math.max(...xs)} (median ${median(xs)}, ${xs.length} games)`);
  }
  // Revenue per play: observed ÷ predicted, only where the model predicted a real per-play revenue (and plays > 0)
  const scalable = earned.filter((r) => r.fullLaunch!.playsPerDay! > 0 && retro(r).unit.eur.mid >= MIN_PER_PLAY);
  if (earned.length > scalable.length)
    notes.push(`${earned.length - scalable.length} game(s) with recorded revenue left out of the per-play scale: the model predicted under €${(MIN_PER_PLAY * 1000).toFixed(1)} per 1,000 plays (or no plays) — nothing to divide by`);
  if (scalable.length >= MIN_RESULTS) {
    const fit = (x: number) => Math.min(PER_PLAY_SCALE.max, Math.max(PER_PLAY_SCALE.min, x));
    const ratios = scalable.map((r) => fit(r.fullLaunch!.revenuePerDayEUR! / r.fullLaunch!.playsPerDay! / retro(r).unit.eur.mid));
    const b = blend({ low: 1, mid: 1, high: 1 }, { low: Math.min(...ratios), mid: median(ratios), high: Math.max(...ratios) }, ratios.length);
    const k = { low: fit(b.low), mid: fit(b.mid), high: fit(b.high) };
    calibration.perPlayScale = k;
    notes.push(`revenue per play scaled ×${k.low.toFixed(2)}–×${k.high.toFixed(2)} (mid ×${k.mid.toFixed(2)}) from ${ratios.length} games' recorded revenue (each ratio and the scale kept within ×${PER_PLAY_SCALE.min}–×${PER_PLAY_SCALE.max})`);
  }

  const verdicts = comparisons.filter((c) => c.brier !== null);
  const brier = verdicts.length ? verdicts.reduce((s, c) => s + c.brier!, 0) / verdicts.length : null;
  const counts = { review: reviewed.length, basicLaunch: launched.length, plays: played.length, revenue: earned.length };
  if (!notes.length) notes.push(`${on.length ? `${on.length} recorded result(s) on ${channel}` : `no recorded results on ${channel}`}: fewer than ${MIN_RESULTS} of any kind — the ranges are the table's (publisher/results.yaml)`);
  const markdown = [
    `**Calibration (${channel}, publisher/results.yaml):** ${counts.review} review verdict(s), ${counts.basicLaunch} Basic Launch verdict(s), ${counts.plays} with plays/day, ${counts.revenue} with revenue. Ranges narrow at ${MIN_RESULTS}+ of a kind.${brier !== null ? ` Brier score of the verdicts: ${brier.toFixed(3)} (0 = perfect, 0.25 = a coin flip).` : ''}`,
    '',
    ...(comparisons.length ? ['| Game | What | The model said | What happened |', '|---|---|---|---|', ...comparisons.map((c) => `| ${c.game} | ${c.what} | ${c.predicted}${c.recorded ? '' : ' (retro, from the record)'} | ${c.actual.replace(/\|/g, '\\|')} |`), ''] : []),
    ...notes.map((n) => `- ${n}`),
    '',
  ].join('\n');
  return { calibration, comparisons, brier, counts, markdown };
}
