// The catalog: every building block the platform has, by kind. Pure data from the packages' *.meta.ts.
// The validator checks references against it; `gp catalog` and the docs list it.

import { CONTENT_PACKS, RISE_META, STICKER_PACKS, TAP_COLLECT_META, TAP_SCORE_META, THEME_METAS } from '@gp/blocks/meta';
import { CASUAL_KIT_META } from '@gp/kit-casual/meta';
import { CODE_KIT_META } from '@gp/kit-code/meta';
import { KIDS_KIT_META } from '@gp/kit-kids/meta';

export const CATALOG = {
  kit: { [KIDS_KIT_META.id]: KIDS_KIT_META, [CASUAL_KIT_META.id]: CASUAL_KIT_META, [CODE_KIT_META.id]: CODE_KIT_META },
  mechanic: { [TAP_COLLECT_META.id]: TAP_COLLECT_META, [TAP_SCORE_META.id]: TAP_SCORE_META },
  trajectory: { [RISE_META.id]: RISE_META },
  theme: THEME_METAS,
  content: CONTENT_PACKS,
  stickers: STICKER_PACKS,
} as const;

export type CatalogKind = keyof typeof CATALOG;

export function catalogIds(kind: CatalogKind): string[] {
  return Object.keys(CATALOG[kind]);
}

export interface CatalogEntry {
  kind: CatalogKind;
  id: string;
  description: string;
}

export function catalogEntries(): CatalogEntry[] {
  const out: CatalogEntry[] = [];
  for (const kind of Object.keys(CATALOG) as CatalogKind[]) {
    for (const [id, v] of Object.entries(CATALOG[kind])) out.push({ kind, id, description: (v as { description: string }).description });
  }
  return out;
}
