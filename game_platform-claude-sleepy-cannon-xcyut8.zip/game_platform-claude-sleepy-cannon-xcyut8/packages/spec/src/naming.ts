// Game titles that players recognise. Spin Brawl had 135 plays on its first Basic Launch day while Dread Throne, Starsilk
// and Nimbus Drift had 14–20 (the dev portal, 2026-10-02): its "Brawl" points at a genre players already search for and
// love (Brawl Stars), while "Starsilk" or "Echoflies" say nothing in a 200 px thumbnail. A title is a portal's first
// filter: the search box, the tag pages and the thumbnail all read it before anyone sees the game.
//
// The rule: one HOOK word (a common word the genre's hit games made famous, never their name) + one word of the game's
// own (what is special about it). "Spin Brawl", "Nimbus Drift", "Yeet the Gnome" — not "Starsilk", "Splicebound".
// A hook is a common word, so it is free to use; the hit's NAME is not (E_TITLE_GENERIC keeps the protected names).
// `gp name` scores a title and suggests others; `gp validate` warns on a portal game whose title has no hook (W_TITLE_HOOK).

import type { Genre, SubGenre } from './money.ts';

export interface HookWord {
  /** The word as it appears in a title (matched case-insensitively, with simple plurals) */
  word: string;
  /** The genres it belongs to — a hook from another genre misleads the player (and the reviewer) */
  genres: Genre[];
  /** high: the word of a genre's biggest hits, searched daily; mid: a well-known genre word */
  strength: 'high' | 'mid';
  /** The hits that made the word familiar (for the report; never put their names in a title) */
  evokes: string;
  /** The sub-genres it is the word of (offered first to them: a deckbuilder gets "deck", not "defense") */
  subgenres?: SubGenre[];
}

const h = (word: string, genres: Genre[], strength: HookWord['strength'], evokes: string, subgenres?: SubGenre[]): HookWord => ({ word, genres, strength, evokes, ...(subgenres ? { subgenres } : {}) });

/** Curated from the CrazyGames top lists and the genre pages (docs/research/market-depth-2026-09.md, trends-2026-09.md) and
 * the store charts; re-check with the portal's search every quarter. */
export const HOOK_WORDS: HookWord[] = [
  // action, arena, io
  h('brawl', ['action', 'io'], 'high', 'Brawl Stars, Brawlhalla'),
  h('clash', ['strategy', 'action'], 'high', 'Clash Royale, Clash of Clans'),
  h('royale', ['action', 'io', 'strategy', 'shooting'], 'high', 'Clash Royale, battle royales'),
  h('arena', ['action', 'io', 'shooting'], 'mid', 'arena brawlers and .io games'),
  h('battle', ['action', 'io', 'strategy', 'shooting'], 'mid', 'Battle royales, Bullet Force'),
  h('legends', ['action', 'strategy'], 'mid', 'League of Legends, Apex Legends'),
  h('heroes', ['action', 'strategy'], 'mid', 'Hero Wars, hero collectors'),
  h('smash', ['action', 'driving', 'hypercasual'], 'high', 'Smash Karts, Super Smash Bros.'),
  h('survivor', ['action'], 'mid', 'Vampire Survivors (crowded: pair it with a word of your own, never "X Survivors" alone)'),
  h('ninja', ['action', 'hypercasual'], 'mid', 'ninja runners and slicers'),
  h('zombie', ['action', 'shooting'], 'mid', 'zombie shooters and defense'),
  h('monster', ['action', 'idle', 'strategy'], 'mid', 'monster tamers and battlers'),
  h('dungeon', ['action', 'strategy'], 'mid', 'dungeon crawlers and roguelikes', ['roguelite', 'deckbuilder']),
  h('rogue', ['action', 'strategy'], 'mid', 'roguelikes', ['roguelite', 'deckbuilder']),
  h('quest', ['action', 'puzzle'], 'mid', 'adventure quests'),
  h('io', ['io'], 'high', '.io games (Slither.io, Agar.io) — as a suffix: "Name.io"'),
  // shooting
  h('shooter', ['shooting'], 'mid', 'the shooter category'),
  h('sniper', ['shooting'], 'mid', 'sniper games'),
  h('strike', ['shooting'], 'high', 'Counter-Strike, Bullet Force'),
  h('wars', ['shooting', 'strategy', 'io'], 'mid', '"X Wars" titles (Tank Wars, Stick Wars)'),
  // strategy, tower defense
  h('defense', ['strategy'], 'high', 'tower defense (Bloons TD, Kingdom Rush)', ['tower-defense']),
  // deckbuilders (Velvet Domino Rogue: W_TITLE_HOOK offered only tower-defense words to a card roguelike)
  h('deck', ['strategy'], 'high', 'deckbuilders (Slay the Spire, Balatro, Inscryption)', ['deckbuilder']),
  h('deckbuilder', ['strategy'], 'high', 'the deckbuilder tag and search', ['deckbuilder']),
  h('card', ['strategy'], 'high', 'card battlers and deckbuilders', ['deckbuilder']),
  h('spire', ['strategy'], 'mid', 'Slay the Spire and its climbs', ['deckbuilder']),
  h('hand', ['strategy'], 'mid', 'poker-hand and card roguelikes', ['deckbuilder']),
  h('draft', ['strategy'], 'mid', 'drafting card games', ['deckbuilder']),
  h('solitaire', ['strategy', 'puzzle'], 'mid', 'solitaire roguelikes', ['deckbuilder']),
  h('tower', ['strategy', 'puzzle'], 'high', 'tower defense, tower stackers'),
  h('kingdom', ['strategy', 'idle'], 'mid', 'Kingdom Rush'),
  h('siege', ['strategy'], 'mid', 'siege and castle games'),
  h('empire', ['strategy', 'idle'], 'mid', 'empire builders'),
  h('rush', ['strategy', 'hypercasual', 'driving', 'action'], 'high', 'Kingdom Rush, Subway Surfers-style rush games'),
  // idle, incremental
  h('idle', ['idle'], 'high', 'idle games (Idle Breakout, Idle Miner)'),
  h('tycoon', ['idle'], 'high', 'tycoons (Roblox tycoons, Adventure Capitalist)'),
  h('clicker', ['idle'], 'high', 'clickers (Cookie Clicker)'),
  h('merge', ['idle', 'puzzle'], 'high', 'merge games (Merge Dragons, 2048-likes)'),
  h('craft', ['idle', 'action'], 'high', 'crafting and sandbox games'),
  h('factory', ['idle', 'puzzle'], 'mid', 'factory builders'),
  h('farm', ['idle'], 'mid', 'farm games'),
  h('miner', ['idle'], 'mid', 'Idle Miner, digging games'),
  h('simulator', ['idle', 'driving', 'other'], 'high', 'simulators'),
  // puzzle
  h('blast', ['puzzle', 'hypercasual'], 'high', 'Block Blast, Toon Blast'),
  h('crush', ['puzzle'], 'high', 'match-3 crushers'),
  h('block', ['puzzle'], 'high', 'Block Blast, block puzzles'),
  h('puzzle', ['puzzle'], 'mid', 'the puzzle category'),
  h('escape', ['puzzle'], 'high', 'escape rooms'),
  h('sort', ['puzzle'], 'high', 'sort puzzles (Water Sort, Ball Sort)'),
  h('match', ['puzzle'], 'mid', 'match-3'),
  h('tiles', ['puzzle'], 'mid', 'tile matchers'),
  h('connect', ['puzzle'], 'mid', 'connect puzzles'),
  h('logic', ['puzzle'], 'mid', 'logic puzzles'),
  // driving, runners, hypercasual
  h('drift', ['driving', 'hypercasual'], 'high', 'Drift Boss, drift racers'),
  h('racer', ['driving'], 'mid', 'racers'),
  h('moto', ['driving'], 'high', 'Moto X3M'),
  h('stunt', ['driving'], 'mid', 'stunt racers'),
  h('dash', ['hypercasual', 'action'], 'high', 'Geometry Dash-style dashers'),
  h('run', ['hypercasual', 'action'], 'high', 'runners'),
  h('jump', ['hypercasual'], 'mid', 'jumpers'),
  h('dodge', ['hypercasual', 'action'], 'mid', 'dodge games (bullet hell, avoiders)'),
  h('stack', ['hypercasual', 'puzzle'], 'mid', 'stackers'),
  h('hole', ['hypercasual', 'io'], 'mid', 'Hole.io'),
  h('parkour', ['hypercasual', 'action'], 'high', 'parkour and obby games'),
  h('obby', ['hypercasual', 'action'], 'high', 'Roblox-style obstacle courses'),
  h('party', ['hypercasual', 'io'], 'mid', 'party games'),
  h('flip', ['hypercasual'], 'mid', 'flip games'),
  h('yeet', ['hypercasual', 'idle'], 'mid', 'launch-and-fly games'),
];

/** Small words that are neither a hook nor the game's own */
const STOP = new Set(['the', 'a', 'an', 'of', 'and', 'in', 'on', 'to', 'for', 'with', 'at', 'my', 'your', 'vs', 'x']);

export interface TitleScore {
  title: string;
  genre: Genre;
  /** 0–100: hook 40 · own word 25 · length 15 · word count 10 · no coined compound 10 */
  score: number;
  /** The hook words found and whether they belong to the genre */
  hooks: { word: string; fits: boolean; strength: HookWord['strength']; evokes: string }[];
  /** The words of the game's own */
  own: string[];
  /** What costs points, plainly */
  issues: string[];
}

const words = (title: string) => title.toLowerCase().split(/[^a-z0-9.]+/).map((w) => w.replace(/\.$/, '')).filter(Boolean);

function hookOf(w: string): HookWord | undefined {
  const bare = w.replace(/^\./, '');
  return HOOK_WORDS.find((k) => bare === k.word || bare === `${k.word}s` || bare === `${k.word}es` || (k.word === 'io' && /\.io$/.test(w)));
}

/** A one-word coined title ("Starsilk", "Echoflies", "Splicebound", "Kettlebot") reads as nothing in a thumbnail and nobody
 * searches it. (In a title of two or more words a long word is usually a real one: "Gauntlet", "Lighthouse".) */
function coined(ws: string[]): string[] {
  const real = ws.filter((w) => !STOP.has(w));
  return real.length === 1 && real[0].length >= 7 && !hookOf(real[0]) ? real : [];
}

/** `sub`: the game's sub-genre (money.genre: deckbuilder) — its hooks are the ones suggested */
export function scoreTitle(title: string, genre: Genre, sub: SubGenre | null = null): TitleScore {
  const ws = words(title);
  const issues: string[] = [];
  const hooks: TitleScore['hooks'] = [];
  const own: string[] = [];
  for (const w of ws) {
    const k = hookOf(w) ?? (/\.io$/.test(w) ? hookOf('io') : undefined);
    if (k) hooks.push({ word: k.word, fits: k.genres.includes(genre), strength: k.strength, evokes: k.evokes });
    if (!STOP.has(w) && (!k || /\.io$/.test(w))) own.push(w.replace(/\.io$/, ''));
  }
  let score = 0;
  const fit = hooks.filter((x) => x.fits);
  const best = fit.find((x) => x.strength === 'high') ?? fit[0];
  if (best) score += best.strength === 'high' ? 40 : 28;
  else if (hooks.length) {
    score += 10;
    issues.push(`"${hooks[0].word}" is a ${HOOK_WORDS.find((k) => k.word === hooks[0].word)!.genres.join('/')} word, not ${/^[aeiou]/.test(genre) ? 'an' : 'a'} ${genre} one: it promises another game`);
  } else issues.push(`no word ${/^[aeiou]/.test(sub ?? genre) ? 'an' : 'a'} ${sub ?? genre} player knows: add a hook (${hooksFor(genre, sub).slice(0, 5).map((k) => k.word).join(', ')} …)`);
  const ownReal = own.filter((w) => w.length >= 3);
  if (ownReal.length) score += 25;
  else issues.push('no word of its own: a hook alone is a category, not a name (E_TITLE_GENERIC)');
  const len = title.length;
  score += len <= 16 ? 15 : len <= 24 ? 10 : len <= 35 ? 4 : 0;
  if (len > 24) issues.push(`${len} characters: a thumbnail shows ≈ 16–24 at a readable size`);
  const n = ws.filter((w) => !STOP.has(w)).length;
  score += n >= 2 && n <= 3 ? 10 : n === 4 ? 5 : 0;
  if (n < 2) issues.push('one word: a name and a promise need two');
  if (n > 4) issues.push(`${n} words: too long to read at a glance`);
  const made = coined(ws);
  if (made.length) issues.push(`"${made.join('", "')}": a coined word — nobody searches it and a thumbnail can't explain it; split it or pair it with a hook`);
  else score += 10;
  return { title, genre, score: Math.min(100, score), hooks, own: ownReal, issues };
}

/** The genre's hooks, strongest first; with a sub-genre, its own words first (a deckbuilder: deck, card …; then rogue, dungeon) */
export function hooksFor(genre: Genre, sub: SubGenre | null = null): HookWord[] {
  const own = (k: HookWord) => (sub && k.subgenres?.includes(sub) ? 0 : 1);
  const rank = (k: HookWord) => (k.strength === 'high' ? 0 : 1);
  return HOOK_WORDS.filter((k) => k.genres.includes(genre)).sort((a, b) => own(a) - own(b) || rank(a) - rank(b));
}

const cap = (w: string) => w.charAt(0).toUpperCase() + w.slice(1);

/** The genre said the way the portal's tags and search say it: the subtitle of a title that keeps its own name
 * ("Dread Throne: Tower Defense") */
export const GENRE_PHRASES: Record<Genre, string[]> = {
  strategy: ['Tower Defense', 'Kingdom Clash'],
  puzzle: ['Block Puzzle', 'Logic Puzzle'],
  idle: ['Idle Tycoon', 'Idle Clicker'],
  action: ['Dungeon Brawl', 'Roguelike Arena'],
  shooting: ['Arena Shooter', 'Zombie Strike'],
  io: ['Battle Arena'],
  driving: ['Drift Racer', 'Stunt Racer'],
  hypercasual: ['Rush', 'Dash'],
  kids: [],
  other: ['Simulator'],
};
/** A sub-genre said the portal's way, when it has its own (a deckbuilder isn't a "Tower Defense") */
export const SUBGENRE_PHRASES: Partial<Record<SubGenre, string[]>> = {
  deckbuilder: ['Deckbuilder', 'Card Roguelike'],
  roguelite: ['Roguelike', 'Dungeon Rogue'],
  'tower-defense': ['Tower Defense'],
};

/**
 * Titles built from the game's own words and the genre's hooks, best first. `own` are the words that make the game its
 * own (its hero, place, twist: "throne", "moth", "gnome"); `base` is a title to keep with a genre subtitle (a game already
 * on the portal keeps its name: "Dread Throne: Tower Defense"); `avoid` skips titles (taken, protected).
 */
export function suggestTitles(genre: Genre, own: string[], opts: { base?: string; avoid?: (t: string) => boolean; n?: number; sub?: SubGenre | null } = {}): TitleScore[] {
  const avoid = opts.avoid ?? (() => false);
  const sub = opts.sub ?? null;
  const mine = [...new Set(own.map((w) => w.trim().toLowerCase()).filter((w) => w.length >= 3 && !STOP.has(w) && !hookOf(w)))].slice(0, 4);
  const hooks = hooksFor(genre, sub).slice(0, 8);
  const out = new Map<string, TitleScore>();
  const add = (t: string) => {
    if (t.length <= 35 && !out.has(t) && !avoid(t)) out.set(t, scoreTitle(t, genre, sub));
  };
  if (opts.base) for (const p of (sub && SUBGENRE_PHRASES[sub]) || GENRE_PHRASES[genre]) add(`${opts.base}: ${p}`);
  for (const o of mine)
    for (const k of hooks) {
      if (k.word === 'io') add(`${cap(o)}.io`);
      else {
        add(`${cap(o)} ${cap(k.word)}`);
        if (k.strength === 'high') add(`${cap(k.word)} ${cap(o)}`);
      }
    }
  return [...out.values()].sort((a, b) => b.score - a.score || a.title.length - b.title.length).slice(0, opts.n ?? 8);
}

