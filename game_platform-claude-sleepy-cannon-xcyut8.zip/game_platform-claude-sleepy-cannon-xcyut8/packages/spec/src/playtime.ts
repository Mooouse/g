// The Basic Launch playtime score (1–5 per device class) a session length would get, fitted from our own score screens
// in publisher/results.yaml — every Basic Launch we had stopped on average playtime (3–6 min where 10+ is the bar).
//
// The fit, per device class: each recorded playtime with its score is a point in the middle of that score's band
// (value → score + 0.5: where in the band it sits is unknown), a recorded `next` is the exact start of the next band
// (next → score + 1); the points, sorted by minutes, are joined by straight lines (made non-decreasing), and outside
// them the line goes on with their overall slope. A session's score is that line's value, floored, clamped to 1–5. The
// minutes a score needs are where the line reaches it. Desktop decides (the dashboard counts Mobile and Tablet "only if
// it passes Desktop"). The scores are relative to a peer group (the category), so this is our games' scale, not a law.

import type { RecordedResult } from './results.ts';
import { BASIC_LAUNCH } from './results.ts';
import { forecast, type Calibration, type Lever, type MoneyDesign } from './money.ts';

export type Device = (typeof BASIC_LAUNCH.devices)[number];
export type Metric = (typeof BASIC_LAUNCH.metrics)[number];

/** One recorded playtime on a score screen */
export interface PlaytimePoint {
  game: string;
  value: number;
  score: number;
  next?: number;
}

export interface PlaytimeScale {
  device: Device;
  points: PlaytimePoint[];
  /** The fitted line: minutes → a continuous score (sorted, non-decreasing) */
  anchors: { min: number; score: number }[];
}

/** Below this many points a device's scale borrows the other device's line (or none: no fit) */
const MIN_POINTS = 2;

/** The recorded playtimes and their scores on one device class (records with a score screen) */
export function playtimePoints(results: readonly RecordedResult[], device: Device): PlaytimePoint[] {
  const out: PlaytimePoint[] = [];
  for (const r of results) {
    const p = r.basicLaunch?.scores?.[device]?.playtime;
    if (!p || typeof p.value !== 'number' || typeof p.score !== 'number') continue;
    out.push({ game: r.game, value: p.value, score: p.score, ...(typeof p.next === 'number' ? { next: p.next } : {}) });
  }
  return out;
}

/** The scale of one device class, fitted from results.yaml (null: fewer than MIN_POINTS recorded) */
export function playtimeScale(results: readonly RecordedResult[], device: Device): PlaytimeScale | null {
  const points = playtimePoints(results, device);
  if (points.length < MIN_POINTS) return null;
  const raw: { min: number; score: number }[] = [];
  for (const p of points) {
    raw.push({ min: p.value, score: p.score + 0.5 });
    if (p.next !== undefined && p.score < BASIC_LAUNCH.maxScore) raw.push({ min: p.next, score: p.score + 1 });
  }
  raw.sort((a, b) => a.min - b.min);
  // The same minutes twice: their mean; then non-decreasing (a running max)
  const anchors: { min: number; score: number }[] = [];
  for (const a of raw) {
    const last = anchors[anchors.length - 1];
    if (last && Math.abs(last.min - a.min) < 1e-9) {
      const n = (last as { n?: number }).n ?? 1;
      last.score = (last.score * n + a.score) / (n + 1);
      (last as { n?: number }).n = n + 1;
    } else anchors.push({ ...a });
  }
  for (let i = 1; i < anchors.length; i++) anchors[i]!.score = Math.max(anchors[i]!.score, anchors[i - 1]!.score);
  for (const a of anchors) delete (a as { n?: number }).n;
  return { device, points, anchors };
}

/** The line's value at `min` minutes (continuous; not yet floored or clamped) */
export function scaleAt(s: PlaytimeScale, min: number): number {
  const a = s.anchors;
  const first = a[0]!;
  const last = a[a.length - 1]!;
  const slope = last.min > first.min ? Math.max(0.05, (last.score - first.score) / (last.min - first.min)) : 0.4;
  if (min <= first.min) return first.score - (first.min - min) * slope;
  if (min >= last.min) return last.score + (min - last.min) * slope;
  for (let i = 1; i < a.length; i++) {
    const p = a[i - 1]!;
    const q = a[i]!;
    if (min <= q.min) return p.score + ((min - p.min) / (q.min - p.min)) * (q.score - p.score);
  }
  return last.score;
}

/** The score (1–5) a session of `min` minutes gets on this scale */
export function playtimeScore(s: PlaytimeScale, min: number): number {
  return Math.max(BASIC_LAUNCH.minScore, Math.min(BASIC_LAUNCH.maxScore, Math.floor(scaleAt(s, min) + 1e-9)));
}

/** The minutes where the score reaches `score` (bisection on the non-decreasing line), rounded to 0.1 */
export function minutesFor(s: PlaytimeScale, score: number): number {
  let lo = 0;
  let hi = 120;
  if (scaleAt(s, lo) >= score) return 0;
  for (let i = 0; i < 50; i++) {
    const mid = (lo + hi) / 2;
    if (scaleAt(s, mid) >= score) hi = mid;
    else lo = mid;
  }
  return Math.round(hi * 10) / 10;
}

/** The median recorded score of a metric on a device class (null: none recorded) */
export function typicalScore(results: readonly RecordedResult[], metric: Metric, device: Device): number | null {
  const xs = results.map((r) => r.basicLaunch?.scores?.[device]?.[metric]?.score).filter((x): x is number => typeof x === 'number').sort((a, b) => a - b);
  if (!xs.length) return null;
  return xs.length % 2 ? xs[xs.length >> 1]! : Math.floor((xs[xs.length / 2 - 1]! + xs[xs.length / 2]!) / 2);
}

/** What the session minutes come from: the design (money.session.minutes) and, when measured, gp qa's session estimate */
export interface SessionSource {
  name: 'design' | 'qa';
  minutes: number;
  from: string;
  /** qa: where the first natural stop came, minutes of play (null: none in the run) */
  firstStopMin?: number | null;
  firstStopWhy?: string | null;
}

export interface PlaytimeDevice {
  device: Device;
  /** The score per source (the same order as sources) */
  scores: number[];
  /** Minutes for 3 (the per-metric bar of 9 of 15), 4 and 5 */
  needs: Record<3 | 4 | 5, number>;
  /** Our games' median score of the other two metrics on this device (null: none recorded) */
  others: Record<'d1' | 'conversion', number | null>;
  /** Playtime scores no better than either other metric does for our games: it is the weakest */
  weakest: boolean;
}

export interface PlaytimeLens {
  sources: SessionSource[];
  /** The source the verdict reads: the QA estimate when there is one (what a player meets), else the design */
  basis: SessionSource;
  devices: PlaytimeDevice[];
  /** Desktop decides: playtime is the weakest metric there (or on the only device with a scale) */
  weakest: boolean;
  /** The recorded points behind the fit, per device */
  points: Record<Device, number>;
  scales: Partial<Record<Device, PlaytimeScale>>;
}

/** The playtime lens of a design: its score on each device from each source, what a 3 needs, and whether it is the weakest */
export function playtimeLens(results: readonly RecordedResult[], sources: SessionSource[]): PlaytimeLens | null {
  if (!sources.length) return null;
  const scales: Partial<Record<Device, PlaytimeScale>> = {};
  for (const dev of BASIC_LAUNCH.devices) {
    const s = playtimeScale(results, dev);
    if (s) scales[dev] = s;
  }
  if (!Object.keys(scales).length) return null;
  const basis = sources.find((s) => s.name === 'qa') ?? sources[0]!;
  const devices: PlaytimeDevice[] = [];
  for (const dev of BASIC_LAUNCH.devices) {
    const s = scales[dev];
    if (!s) continue;
    const others = { d1: typicalScore(results, 'd1', dev), conversion: typicalScore(results, 'conversion', dev) };
    const mine = playtimeScore(s, basis.minutes);
    const known = [others.d1, others.conversion].filter((x): x is number => x !== null);
    devices.push({
      device: dev,
      scores: sources.map((src) => playtimeScore(s, src.minutes)),
      needs: { 3: minutesFor(s, 3), 4: minutesFor(s, 4), 5: minutesFor(s, 5) },
      others,
      weakest: known.length ? known.every((x) => mine <= x) : mine < 3,
    });
  }
  const gate = devices.find((d) => d.device === 'desktop') ?? devices[0]!;
  const points = { desktop: scales.desktop?.points.length ?? 0, mobile: scales.mobile?.points.length ?? 0 };
  return { sources, basis, devices, weakest: gate.weakest, points, scales };
}

export const PLAYTIME_LEVER = 'Playtime: the first natural stop after 10 min';

/**
 * The lever when playtime is the weakest metric: the session the players meet (the QA estimate, else the design) taken to
 * 12 min with a meta — its expected value against the same design at the minutes measured. First in the list either way
 */
export function playtimeLever(d: MoneyDesign, lens: PlaytimeLens, calibration?: Calibration): Lever {
  const now = Math.min(d.sessionMin, lens.basis.minutes);
  const base = forecast({ ...d, sessionMin: now }, calibration).expected.mid;
  const after = forecast({ ...d, sessionMin: Math.max(12, d.sessionMin), breaks: Math.max(d.breaks, 2), metaMin: Math.max(d.metaMin ?? 0, 30) }, calibration).expected.mid;
  const gate = lens.devices.find((x) => x.device === 'desktop') ?? lens.devices[0]!;
  const i = lens.sources.indexOf(lens.basis);
  const stop = lens.basis.name === 'qa' && lens.basis.firstStopMin != null ? `; the first natural stop at ${clock(lens.basis.firstStopMin)}${lens.basis.firstStopWhy ? ` (${lens.basis.firstStopWhy})` : ''}` : '';
  const scores = lens.devices.map((x) => `${x.device} ${x.scores[i]}/5`).join(', ');
  return {
    name: PLAYTIME_LEVER,
    change: `${lens.basis.name === 'qa' ? 'gp qa estimates' : 'the design says'} ${lens.basis.minutes.toFixed(1)} min${stop} → playtime ${scores}, the weakest Basic Launch score; a 3 needs ${gate.needs[3]} min on ${gate.device}, a 4 ${gate.needs[4]} min — auto-continue into the next run, the next goal always on screen, a meta reward every 2–3 min, no dead end after the results (docs/guides/first-minute.md → The session)`,
    delta: after - base,
    after,
  };
}

/** 4.5 → "4:30" */
export function clock(min: number): string {
  const s = Math.max(0, Math.round(min * 60));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
