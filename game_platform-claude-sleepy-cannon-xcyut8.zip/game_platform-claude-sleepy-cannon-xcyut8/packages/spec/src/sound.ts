// Music on a portal: game.yaml `sound` and what the game's code shows (pure: the CLI reads the files and passes them).
//
// Players and judges asked for background music in six of our games, and 6 of the 10 quality rejections of
// 2026-10-02…06 had none (docs/research/feedback-and-metrics-2026-10.md §3.2). QA can't hear, so the rule asks the code
// (does it call createMusic from @gp/core/sound?) and game.yaml (`sound.music`: what plays, for music of the game's own).

import type { Issue } from './errors.ts';
import type { GameSpecInput, ResolvedGame } from './types.ts';

type Report = (code: string, path: (string | number)[], message: string, fix: string) => void;

const FIX =
  "Add music through the host: `createMixer(host)` and `createMusic(mixer, { calm: musicTheme('calm', seed) })` from @gp/core/sound, with music and effects sliders in the settings (docs/guides/code-games.md#music-and-ambience); for music of the game's own, say what plays in game.yaml `sound: { music: \"…\" }`.";

/** The channels where a code game must have music (an error), and where it is only advised */
export const MUSIC_REQUIRED_CHANNELS = ['crazygames'] as const;

/**
 * One source file: does it start the platform's music? An import of createMusic (or the themes) from @gp/core/sound,
 * or a createMusic(…) call. Comments don't count.
 */
export function sourceHasMusic(src: string): boolean {
  const code = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1');
  const imp = /import\s*\{([^}]*)\}\s*from\s*['"]@gp\/core\/sound['"]/g;
  for (const m of code.matchAll(imp)) if (/\b(createMusic|musicTheme|bossTheme)\b/.test(m[1])) return true;
  return /\bcreateMusic\s*\(/.test(code);
}

/** game.yaml `sound` as written (resolve.ts) — and what can be said of it without the code */
export function resolveSound(spec: GameSpecInput, channel: string, err: Report, warn: Report): ResolvedGame['sound'] {
  const music = spec.sound?.music;
  const why = spec.sound?.why?.trim() || null;
  const required = spec.kit === 'code' && (MUSIC_REQUIRED_CHANNELS as readonly string[]).includes(channel);
  if (music === false && required) {
    if (!why)
      err('E_SOUND_MUSIC', ['sound', 'music'], `channel ${channel}: \`sound.music: false\` without a reason — a CrazyGames code game needs music (players and judges asked for it in six of our games)`, FIX);
    else
      warn('W_SOUND_MUSIC', ['sound', 'music'], `channel ${channel}: no music, on purpose ("${why}") — gp review --check and gp submission refuse it on CrazyGames`, FIX);
  }
  if (typeof music === 'string' && why)
    warn('W_SOUND_MUSIC', ['sound', 'why'], '`sound.why` explains no music, but `sound.music` says what plays', 'Remove `sound.why`.');
  return { music: typeof music === 'string' ? music.trim() : music === false ? false : null, why };
}

/**
 * The code's side (the CLI passes whether any source file starts the music): a CrazyGames code game whose code starts
 * no music and whose game.yaml doesn't say what plays is an error. `sound.music: false` was reported by resolveSound.
 */
export function musicIssues(game: Pick<ResolvedGame, 'kit' | 'channel' | 'sound'>, codeHasMusic: boolean): Issue[] {
  if (game.kit.kit !== 'code' || codeHasMusic || game.sound.music !== null) return [];
  if (!(MUSIC_REQUIRED_CHANNELS as readonly string[]).includes(game.channel.id)) return [];
  return [
    {
      code: 'E_SOUND_MUSIC',
      severity: 'error',
      path: ['sound', 'music'],
      message: `channel ${game.channel.id}: no music — the code calls no createMusic (@gp/core/sound) and game.yaml has no \`sound.music\` saying what plays (reviewers asked for music in six of our games; 6 of 10 quality rejections had none)`,
      fix: FIX,
    },
  ];
}

/** Whether a game has music as far as the platform can tell: the code starts it, or game.yaml says what plays */
export function hasMusic(game: Pick<ResolvedGame, 'sound'>, codeHasMusic: boolean): boolean {
  return codeHasMusic || typeof game.sound.music === 'string';
}
