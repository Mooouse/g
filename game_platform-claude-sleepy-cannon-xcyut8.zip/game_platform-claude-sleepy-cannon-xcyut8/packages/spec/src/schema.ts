// The full game.yaml schema: platform fields + the round (mechanic) + the kit's sections.
// Also written to packages/spec/schema/game.schema.json for editor autocompletion (`gp schema`).

import type { JsonSchema } from '@gp/core/schema';
import { LANGUAGE_CODES, LANGUAGES } from '@gp/core/i18n';
import { CATALOG } from './catalog.ts';
import { AUDIENCES, CHANNELS } from './profiles.ts';
import { GENRES, LOOT_COSTS, RETURN_KINDS, REWARDED_KINDS, SUBGENRES } from './money.ts';
import { STORY_DEPTHS, STORY_GENRES } from './story-depth.ts';

export const SPEC_VERSION = 0;

const adLimit = (description: string): JsonSchema => ({ type: 'number', minimum: 0, description });

/**
 * The schema of a game that uses a given kit and round mechanic. Platform fields are the same for every game;
 * the kit adds its sections, the mechanic defines `round`. A new kit or mechanic is a catalog entry, not a validator change.
 */
export function gameSchema(kitId: string, mechanicId: string): JsonSchema {
  const kit = CATALOG.kit[kitId as keyof typeof CATALOG.kit] as (typeof CATALOG.kit)[keyof typeof CATALOG.kit] & { round?: false };
  const props = { ...PLATFORM_SCHEMA.properties, kit: { type: 'string', description: PLATFORM_SCHEMA.properties!.kit.description, 'x-gp-ref': 'kit' } } as Record<string, JsonSchema>;
  let required = [...PLATFORM_SCHEMA.required!, ...kit.required];
  if (kit.round === false) {
    // A kit whose game brings its own mechanics and look (kit: code): no round, no theme
    delete props.theme;
    required = required.filter((k) => k !== 'round' && k !== 'theme');
    return { ...PLATFORM_SCHEMA, properties: { ...props, ...(kit.sections as Record<string, JsonSchema>) }, required };
  }
  const mech = CATALOG.mechanic[mechanicId as keyof typeof CATALOG.mechanic] as (typeof CATALOG.mechanic)[keyof typeof CATALOG.mechanic];
  const round: JsonSchema = {
    ...mech.schema,
    properties: { ...mech.schema.properties, mechanic: { type: 'string', description: 'Mechanic id', 'x-gp-ref': 'mechanic' } },
  };
  return { ...PLATFORM_SCHEMA, properties: { ...props, round, ...(kit.sections as Record<string, JsonSchema>) }, required };
}

const PLATFORM_SCHEMA: JsonSchema = {
  title: 'game.yaml',
  description: 'One game on the platform. Everything not listed as required has a default.',
  type: 'object',
  properties: {
    spec: { const: SPEC_VERSION, description: 'GameSpec version. Always 0 for now.' },
    id: { type: 'string', pattern: '^[a-z][a-z0-9-]{1,39}$', description: 'Game id: kebab-case, also the folder name under games/', examples: ['balloon-pop'] },
    title: { type: 'string', minLength: 1, maxLength: 50, description: 'Game title: the store title and the launcher label (Google Play: ≤ 30 characters)' },
    appId: {
      type: 'string',
      pattern: '^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$',
      description: 'Android application id (reverse domain). Required on Android channels; never change it after the first release.',
      examples: ['com.qma.balloonpop'],
    },
    version: {
      type: 'object',
      description: 'Release version',
      properties: {
        name: { type: 'string', pattern: '^\\d+\\.\\d+\\.\\d+$', default: '1.0.0', description: 'Visible version' },
        code: { type: 'integer', minimum: 1, default: 1, description: '+1 for every upload to Google Play' },
      },
      additionalProperties: false,
    },
    locale: { type: 'string', pattern: '^[a-z]{2}(-[A-Z]{2})?$', default: 'en-US', description: 'Language of texts and text-to-speech (BCP 47)' },
    languages: {
      type: 'array',
      items: { enum: [...LANGUAGE_CODES] },
      minItems: 1,
      default: ['en'],
      description: `The languages the game ships in, English first (CrazyGames requires English). The texts are in games/<id>/strings/<code>.yaml; the platform's own (host, kits, shop, dialogue, picker) are translated already. A portal game declares the ten its audience speaks most (W_I18N_LANGS): ${LANGUAGES.filter((l) => l.top)
        .map((l) => `${l.code} (${l.english})`)
        .join(', ')}; ${LANGUAGES.filter((l) => !l.top)
        .map((l) => l.code)
        .join(', ')} are ready too. docs/guides/i18n.md`,
      examples: [['en', 'es', 'pt-BR', 'fr', 'de', 'ru', 'tr', 'it', 'pl', 'id']],
    },
    glossary: {
      type: 'array',
      items: { type: 'string', minLength: 1 },
      description: 'Names that stay as they are in every language: the characters, places and the game\'s own words (the title always does). `gp validate` warns when a translation drops one (W_I18N_GLOSSARY); `gp translate` gives the list to the translator',
      examples: [['Everflame', 'Ambrose']],
    },
    audience: { enum: Object.keys(AUDIENCES), description: 'Who plays. Sets touch sizes and child-safety rules (`gp explain audience`).' },
    channel: { enum: Object.keys(CHANNELS), description: 'Where the game is published. Sets ads, purchases and policy rules (`gp explain channel`).' },
    kit: { type: 'string', description: 'Kit: the scenes around the round (menu, result screens) and the game.yaml sections they add', 'x-gp-ref': 'kit' },
    theme: { type: 'string', description: 'Theme id: background, tap target, colors, pop sound', 'x-gp-ref': 'theme' },
    saveKey: { type: 'string', pattern: '^[a-z0-9._-]+$', description: 'localStorage key. Default: "<id>.save.v1". Never change it after release.' },
    privacyPolicyUrl: { type: 'string', pattern: '^https?://', description: 'Privacy policy page (https). Required on Google Play.' },
    listing: {
      type: 'object',
      description: 'The listing texts the portal form asks for. `gp submission` checks them and writes listing.md with the form answers.',
      properties: {
        description: {
          type: 'string',
          minLength: 150,
          maxLength: 2000,
          description: 'What the game is, honestly (genre and the twist), what the player does and why it is fun — then a short feature list. Must match the covers and the video',
        },
        controls: { type: 'string', minLength: 10, maxLength: 800, description: 'Every control, per device: "Mouse: …", "Keyboard: …", "Touch: …"' },
        orientation: { enum: ['both', 'landscape', 'portrait'], default: 'both', description: 'Screen orientations the game supports (the form asks)' },
        tags: { type: 'array', items: { type: 'string', minLength: 2 }, maxItems: 6, description: 'Genre and tags for the form (e.g. Action, Clicker, Physics)' },
      },
      additionalProperties: false,
    },
    concept: {
      type: 'object',
      description:
        'What makes the game its own, written BEFORE building it. Required where the channel reviews originality (CrazyGames rejected Petri Panic: "The concept is quite close to existing titles"). How to search the portal and what counts as a difference: docs/guides/game-design.md#originality-what-portals-reject',
      properties: {
        pitch: { type: 'string', minLength: 20, maxLength: 200, description: 'One sentence: what the player does and why it is fun' },
        closest: {
          type: 'array',
          items: { type: 'string', minLength: 2 },
          minItems: 3,
          description: 'At least 3 games already on the channel it could be mistaken for (search the portal by genre and tags, and the top of the category)',
        },
        different: {
          type: 'string',
          minLength: 40,
          maxLength: 400,
          description: 'What the player DOES here that none of them has: the core action, a rule or the goal. A theme, art style, setting or name is not a difference',
        },
        twist: {
          type: 'object',
          description:
            'The moment the twist happens in play. The game calls `host.twist("<event>")` right then; `gp qa` lets the demo bot play and checks it happens within `within` seconds (a new player must meet it early), `gp uniqueness` scores it. docs/guides/uniqueness.md',
          properties: {
            event: { type: 'string', pattern: '^[a-z][a-z0-9-]{1,39}$', description: 'Event name, kebab-case (e.g. "bait-feeds-swarm")' },
            within: { type: 'number', minimum: 5, maximum: 120, default: 30, description: 'Seconds of play by which a new player meets the twist' },
            explained: {
              type: 'string',
              minLength: 3,
              maxLength: 120,
              description:
                'The words on screen that explain the twist to a new player (the whole hint, or a phrase from it, as the game shows it; case and spacing are ignored), e.g. "your echo flies the dotted path". `gp qa` plays the first run with the demo bot and checks the text is visible — in the DOM, or in a host.qa canvasUi rect with `text` — before or when the twist first fires, long enough to read: 2 s + 50 ms per character of the text it appears in (≤ 8 s). Echoflies\' playtest found its explanation on screen for 30 ms. docs/guides/uniqueness.md#the-explanation',
            },
          },
          required: ['event'],
          additionalProperties: false,
        },
        progression: {
          type: 'string',
          minLength: 10,
          maxLength: 300,
          description:
            'What the currency or the run buys, in the shape that fits the genre: unlocks that change how you play (a roster of heroes or tools), tiers that open the next set, pacts (a gain with a cost), run choices (pick 1 of 3) — or a level shop, for idle and launch-distance games only. e.g. "Gems buy new candles, each with its own class power; feats are picked 1 of 3 at every level-up". docs/guides/upgrades.md',
        },
      },
      required: ['pitch', 'closest', 'different'],
      additionalProperties: false,
    },
    story: {
      type: 'object',
      description:
        'How much story the game has, and where it is. Optional: most games need at most a premise, and a game that needs none leaves this out. `gp story` prints the depth this kind of game takes and why, and forms a starting story file; `gp validate` checks the story against its depth (docs/guides/story.md)',
      properties: {
        depth: {
          enum: STORY_DEPTHS,
          description:
            'none: no story · premise: one line, who, what, why (≤ 30 words) · barks: a character reacts to events in a bubble (≤ 60 characters, never blocks play; 50–200 barks) · chapters: 6–12 short scenes unlocked by progress, played between runs, skippable · branching: chapters whose choices set flags that change later lines, 2–3 endings. Each depth includes the lighter ones. What fits comes from the audience, channel, kit and genre (the table in `gp explain story.depth`); outside it is a warning, never an error',
        },
        premise: { type: 'string', minLength: 10, maxLength: 200, description: 'The one line the story is: who, what, why ("the pigs stole the eggs"), ≤ 30 words. It feeds the title screen, the covers and the store text. Required at depth premise' },
        file: {
          type: 'string',
          pattern: '^[A-Za-z0-9_./-]+\\.(ts|mjs|js|json)$',
          description:
            'The story as data, relative to the game folder (e.g. story.ts): `export const STORY: StoryDef` for chapters and branching, bark lists (`export const BARKS = { event: [lines] }`) for barks. Data only (`import type` from @gp/core): `gp validate` loads it. Required at depth chapters and branching',
          examples: ['story.ts'],
        },
        voiced: { type: 'boolean', description: 'Every story line is spoken (TTS or audio). Must be true for ages-2-5 and ages-6-8 from depth barks up' },
        genre: {
          enum: STORY_GENRES,
          description:
            'The kind of game, for the recommended depth (default: from the kit, listing.tags and the concept): action (arcade, survivors, roguelike, tower defense), idle (clicker, incremental, merge), puzzle (levels), choices (choosing is the play)',
        },
      },
      required: ['depth'],
      additionalProperties: false,
    },
    money: {
      type: 'object',
      description:
        'The money design, written with the concept BEFORE building: how long a session is, where its natural breaks are (the only places a midgame ad can go), what each rewarded offer gives, how long the meta lasts, why a player returns tomorrow. `gp forecast` estimates what it earns (ranges, with the confidence of each input), `gp validate` checks what can be checked against the channel. Every field has a default (the genre, the kit, the code, the balance report); on a portal a `kit: code` game writes it (the template has it as TODO). docs/guides/game-design.md#design-for-money',
      properties: {
        genre: {
          type: 'string',
          description: `The game's genre (gp catalog genres): the benchmarks (average play and D1 per genre on CrazyGames) and what its players expect (gp validate: I_GENRE_EXPECTS, W_GENRE_BLOCK). ${GENRES.join(', ')} — or a sub-genre, benchmarked as its genre: ${Object.entries(SUBGENRES).map(([k, v]) => `${k} (${v})`).join(', ')}. Default: from listing.tags and the kit`,
          examples: ['puzzle'],
        },
        hybrid: {
          type: 'array',
          maxItems: 3,
          items: { type: 'string' },
          description:
            "The genres of a second layer the game has, on top of `genre` (an idle base under an action game, a rebirth in a speed runner: `hybrid: [idle]`). The blocks of that genre then fit (W_GENRE_BLOCK doesn't warn about offlineEarnings, Prestige or Sites); the benchmarks and the must-haves stay the main genre's. Genres or sub-genres, as `genre`",
          examples: [['idle']],
        },
        covers: {
          type: 'object',
          additionalProperties: { type: 'string', minLength: 5, maxLength: 200 },
          description:
            "The genre's must-haves the game builds with its own code, where `gp validate` can't see them (no block of the platform imported, no sign its search knows): the must-have's id (`gp explain genre.<g>` lists them) → where it is, in words. I_GENRE_EXPECTS and `gp design`'s brief then count it as there (\"✓ own code\"). Say it only for what a player really finds in the game: the reviewer and the designer check it. An id that is no must-have of the game's genre warns (W_MONEY_COVERS)",
          examples: [{ shop: 'the garage upgrade list with ×1 / ×10 / MAX and milestones (src/garage/shop.ts)' }],
        },
        loot: {
          type: 'array',
          maxItems: 16,
          description:
            'The game\'s random rolls (each LootTable source: an egg, a chest, a drop): what a roll costs and where its odds are shown. A roll for real money or for a currency sold for real money is refused (E_PAID_RANDOM: PEGI 16 from June 2026); a roll for a rewarded ad is a spin (W_REWARDED_RANDOM) — the ad gives a floor or a second item instead; odds not shown warn (W_LOOT_ODDS). docs/guides/live-world.md',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string', pattern: '^[a-z][a-z0-9-]{1,39}$', description: 'The LootTable source the game rolls' },
              cost: { enum: [...LOOT_COSTS], description: 'What a roll costs: earned (a currency won by playing), free (a daily egg), ad (a rewarded ad: a spin, warned), purchase (real money: refused), bought (a currency sold for real money: refused)' },
              odds: { type: 'string', minLength: 5, maxLength: 160, description: 'Where the player sees each tier\'s chance before the roll ("the egg card lists each tier\'s chance")' },
            },
            required: ['id', 'cost'],
            additionalProperties: false,
          },
        },
        session: {
          type: 'object',
          description: 'One session as designed',
          properties: {
            minutes: { type: 'number', minimum: 1, maximum: 240, description: 'Target minutes a player plays in one session (CrazyGames: Basic Launch compares average playtime; top games 10+). Default: the genre average. A code game that declares balance.difficulty.winningRunMin: `gp forecast` reads a winning run\'s minutes instead (the bot\'s, else the range\'s middle) and scales `breaks` to it' },
            breaks: {
              type: 'integer',
              minimum: 0,
              maximum: 500,
              description: 'Natural breaks inside a session: moments the player goes on to the next run, level or day ("Play again", "Next level") — the only places `host.adBreak()` may show a midgame ad. The channel then allows at most one per 3 min (CrazyGames). Default: from the genre\'s run length (a code game without host.adBreak() has none)',
            },
            breaksAt: { type: 'string', minLength: 5, maxLength: 200, description: 'Where they are, in words: "level end → Next level; death → Play again"' },
          },
          additionalProperties: false,
        },
        rewarded: {
          type: 'array',
          maxItems: 8,
          description:
            'Rewarded offers (13+ only: never for children). Each is optional for the player — a same-size "No thanks" next to it (`gp qa` measures it) — never on the active play screen, and gives something the player wants. Default: the placements found in the code',
          items: {
            type: 'object',
            properties: {
              placement: { type: 'string', pattern: '^[a-z][a-z0-9-]{1,39}$', description: 'The id the game passes to host.rewarded() / rewardedButton()' },
              kind: { enum: [...REWARDED_KINDS], description: 'What kind of reward: revive, continue, x2 (double the run\'s reward), reroll, trial (a locked thing for one run), hint, undo, boost, restock (a fresh shop stock now: restockShop), spin (an extra spin of a lucky wheel), currency (the shop\'s currency for an ad), other. Always a guaranteed thing, never a spin (W_REWARDED_RANDOM)' },
              gives: { type: 'string', minLength: 5, maxLength: 160, description: 'What the player gets, as the button says it ("Continue with half your wax")' },
              per: { enum: ['run', 'level', 'session'], description: 'How often it can be offered. Default: once a session for a revive, continue or trial (CrazyGames: a revive at most once per session), per level for a hint or undo, per run otherwise' },
            },
            required: ['placement', 'kind', 'gives'],
            additionalProperties: false,
          },
        },
        meta: {
          type: 'object',
          description: 'The progression\'s length. `gp forecast` takes it from the balance report when the game exports balance()',
          properties: { minutes: { type: 'number', minimum: 0, maximum: 100000, description: 'Minutes of play until the progression is done (10–180 on CrazyGames: docs/guides/upgrades.md)' } },
          additionalProperties: false,
        },
        returns: {
          type: 'object',
          description: 'Why a player comes back tomorrow (Basic Launch reads D1: strong games 10–15%)',
          properties: {
            kind: { enum: [...RETURN_KINDS], description: 'daily (a seed, a case, a calendar), meta (a goal left at 80%), story (the next chapter), social, none' },
            what: { type: 'string', minLength: 5, maxLength: 200, description: 'The reason, in words' },
          },
          required: ['kind'],
          additionalProperties: false,
        },
        removeAdsPrice: { type: 'number', minimum: 0.49, maximum: 19.99, description: 'The "Remove ads" price in EUR, for the forecast (kids apps on Google Play; the product is monetization.removeAds)' },
      },
      additionalProperties: false,
    },
    sound: {
      type: 'object',
      description:
        "The game's sound, where the code doesn't show it. On `channel: crazygames` a `kit: code` game needs music (E_SOUND_MUSIC): the code calls `createMusic` from @gp/core/sound — then nothing is needed here — or `music` says what plays (music code or tracks of the game's own). docs/guides/code-games.md#music-and-ambience",
      properties: {
        music: {
          oneOf: [
            { type: 'string', minLength: 5, maxLength: 200, description: "What plays, and where: the game's own music (e.g. \"own synth in sound.ts: a theme per act, a boss theme; music and effects sliders\")" },
            { const: false, description: '`false` — no music, on purpose; needs `why`. A warning (W_SOUND_MUSIC); `gp review --check` and `gp submission` still refuse it on CrazyGames' },
          ],
          description: 'What music plays, or `false` (with `why`)',
          examples: ['own synth in sound.ts: a theme per act, a boss theme; music and effects sliders'],
        },
        why: { type: 'string', minLength: 5, maxLength: 200, description: 'Why there is no music (with `music: false`)' },
      },
      additionalProperties: false,
    },
    budget: {
      type: 'object',
      description:
        "The upload's size budget, raised on purpose (a physics, 3D or engine game). `gp build --target <portal>` prints the upload raw and gzipped, each npm package's share and the estimated time to a tappable Play on a slow phone, and warns above the channel's budget (CrazyGames: 400 KB gzipped, 3 s); this raises the size budget and the load warning with it. Never above the channel's hard limit (CrazyGames: 20 MB, which fails the build). `gp forecast` reads the size and the load time either way. docs/guides/code-games.md#the-size-and-load-budget",
      properties: {
        gzipKB: { type: 'integer', minimum: 1, maximum: 20480, description: 'Warn above this many KB of the upload gzipped (the channel\'s budget otherwise)', examples: [1500] },
      },
      required: ['gzipKB'],
      additionalProperties: false,
    },
    monetization: {
      type: 'object',
      description: 'Ads and purchases. Defaults come from the channel.',
      properties: {
        ads: {
          type: 'object',
          properties: {
            enabled: { type: 'boolean', description: 'Default: true where the channel has ads' },
            rewarded: {
              type: 'boolean',
              description:
                'Rewarded ads (the player taps "watch an ad" for a bonus). Default: true where the channel allows them. A code game calls `host.rewarded(placement)` from the button\'s tap handler (or uses `rewardedButton()`); the YAML kits have no rewarded buttons yet',
            },
            appId: { type: 'string', description: 'AdMob App ID, or `auto` (filled in by `gp admob provision`)', default: 'auto' },
            interstitial: { type: 'string', description: 'AdMob interstitial ad unit ID, or `auto`', default: 'auto' },
            limits: {
              type: 'object',
              description: 'Stricter ad limits than the channel (never looser)',
              properties: {
                noAdsAfterLaunchSec: adLimit('No ads in the first N seconds'),
                firstAdAfterRound: adLimit('First ad not before the end of this round (or firstAdAfterSec, whichever comes first, where the channel has it)'),
                firstAdAfterSec: adLimit('Or: the first ad once the session has lasted this many seconds, if that comes before round firstAdAfterRound (CrazyGames: 300). Only on a channel that has this time path; a game may only raise it'),
                everyRounds: adLimit('At most one ad per this many rounds'),
                minIntervalSec: adLimit('At most one ad per this many seconds'),
              },
              additionalProperties: false,
            },
          },
          additionalProperties: false,
        },
        removeAds: {
          oneOf: [
            { type: 'boolean', description: '`false` — no "Remove ads" purchase' },
            {
              type: 'object',
              properties: { product: { type: 'string', pattern: '^[a-z0-9_.]{1,100}$', default: 'remove_ads', description: 'Google Play product id (one-time)' } },
              additionalProperties: false,
            },
          ],
          description: 'One-time "Remove ads" purchase. Default: `{ product: remove_ads }` where the channel has purchases',
        },
      },
      additionalProperties: false,
    },
  },
  required: ['spec', 'id', 'title', 'audience', 'channel', 'kit', 'theme', 'round'],
  additionalProperties: false,
};

/** The schema with the kids kit and tap-collect — written to game.schema.json for editors */
export const GAME_SCHEMA: JsonSchema = gameSchema('kids', 'tap-collect');
