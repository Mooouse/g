// @gp/art/pixel: the grid, ramps, outline, volume, dithering, clean-up, RotSprite, a model's pseudo-pixels back to
// its grid, and the craft checks — each check shown to fire on the defect and to stay quiet on the clean drawing.

import { describe, expect, it } from 'vitest';
import { oklab, oklch } from '../src/color.ts';
import {
  depixelize,
  detectPixelPitch,
  lintPixelArt,
  lintPixelImage,
  lintPixelSet,
  lintPixelFrames,
  pixelArt,
  pixelCleanup,
  pixelDither,
  pixelDownscale,
  pixelFlat,
  pixelOutline,
  pixelRamp,
  pixelRows,
  pixelScale2x,
  pixelShade,
  pixelToRgba,
  pixelThinOutline,
  pixelTrim,
  pixelViewport,
  rotSprite,
  type PixelArt,
  type RgbaImage,
} from '../src/pixel.ts';

const codes = (a: PixelArt, o = {}) => lintPixelArt(a, o).issues.map((i) => i.code);
const count = (a: PixelArt) => a.px.reduce((n, v) => n + (v ? 1 : 0), 0);

/** A filled disc of one colour, radius r */
function disc(r: number, color = '#d4531c'): PixelArt {
  const n = 2 * r + 1;
  const rows = Array.from({ length: n }, (_, y) => Array.from({ length: n }, (_, x) => ((x - r) ** 2 + (y - r) ** 2 <= r * r + r ? 'f' : '.')).join(''));
  return pixelArt(rows, { f: color });
}

describe('the grid', () => {
  it('reads rows of letters and writes them back', () => {
    const a = pixelArt(['.kk.', 'kffk', '.kk.'], { k: '#1a1020', f: '#ffa033' });
    expect([a.w, a.h, a.colors]).toEqual([4, 3, ['#1a1020', '#ffa033']]);
    const { rows, key } = pixelRows(a);
    expect(pixelArt(rows, key).px).toEqual(a.px);
  });
  it('refuses a letter not in the key', () => {
    expect(() => pixelArt(['.x.'], { k: '#000' })).toThrow(/"x" at 1,0/);
  });
  it('trims to the pixels', () => {
    const t = pixelTrim(pixelArt(['....', '.k..', '..k.', '....'], { k: '#000' }));
    expect([t.art.w, t.art.h, t.x, t.y]).toEqual([2, 2, 1, 1]);
  });
});

describe('pixelRamp', () => {
  it('turns cool in the shadows and warm in the lights, the lightness rising step by step', () => {
    const r = pixelRamp('#d4531c', 5);
    expect(r).toHaveLength(5);
    const L = r.map((c) => oklab(c)[0]);
    for (let i = 1; i < L.length; i++) expect(L[i]!).toBeGreaterThan(L[i - 1]!);
    const hue = (c: string) => oklch(c)[2];
    // The base is orange (≈ 45°): the shadow turns toward violet (lower/backwards round to 275), the light toward yellow
    expect(hue(r[0]!)).toBeLessThan(hue(r[2]!));
    expect(hue(r[4]!)).toBeGreaterThan(hue(r[2]!));
  });
});

describe('pixelOutline', () => {
  it('draws a closed line outside the shape, growing the grid by one', () => {
    const a = pixelOutline(disc(4));
    expect([a.w, a.h]).toEqual([11, 11]);
    const { issues, stats } = lintPixelArt(a);
    expect(stats.outline).toBe(1);
    expect(issues.map((i) => i.code)).not.toContain('P_OUTLINE_BROKEN');
  });
  it('selout: darker on the shadow side than on the lit side', () => {
    const a = pixelOutline(disc(5), { selout: true });
    const L = (x: number, y: number) => oklab(a.colors[a.px[y * a.w + x]! - 1]!)[0];
    // top-left lit, bottom-right in shadow
    expect(L(6, 0)).toBeGreaterThan(L(6, a.h - 1));
  });
});

describe('pixelShade', () => {
  it('lights the side facing the light, without pillow shading', () => {
    const a = pixelShade(disc(7));
    const L = (x: number, y: number) => oklab(a.colors[a.px[y * a.w + x]! - 1]!)[0];
    expect(L(4, 4)).toBeGreaterThan(L(10, 10));
    expect(a.colors.length).toBeGreaterThanOrEqual(3);
    expect(codes(pixelOutline(a))).not.toContain('P_PILLOW');
  });
});

describe('the craft checks', () => {
  it('pillow shading: rings lighter toward the middle', () => {
    const r = 8, ramp = pixelRamp('#3a7bd5', 5);
    const rows = Array.from({ length: 2 * r + 1 }, (_, y) =>
      Array.from({ length: 2 * r + 1 }, (_, x) => {
        const d = Math.hypot(x - r, y - r);
        return d > r + 0.4 ? '.' : String(Math.max(0, Math.min(4, Math.floor((r - d) / 1.8))));
      }).join(''),
    );
    const a = pixelArt(rows, Object.fromEntries(ramp.map((c, i) => [String(i), c])));
    expect(codes(a)).toContain('P_PILLOW');
  });
  it('noise: a stray close shade is found and cleaned; an eye with real contrast stays', () => {
    const rows = ['ffffffff', 'ffffffff', 'fffgffff', 'ffffffff', 'fffffeff', 'ffffffff', 'ffffffff', 'ffffffff'];
    const a = pixelArt(rows, { f: '#3a7bd5', g: '#3f80d8', e: '#ffffff' });
    const { stats } = lintPixelArt(a);
    expect(stats.noise).toBe(1);
    const c = pixelCleanup(a);
    expect(c.art.colors).toContain('#ffffff');
    expect(c.art.colors).not.toContain('#3f80d8');
  });
  it('doubles: an outline that steps through L-corners', () => {
    const k = '#1a1020', f = '#d4531c';
    // A diagonal edge drawn with doubled steps (each step an L of three)
    // A 26-px triangle whose sloped side is drawn with doubled steps, and the same drawn pixel-perfect
    const tri = (doubled: boolean) => Array.from({ length: 26 }, (_, y) => (y === 25 ? 'k'.repeat(26) : ('k' + 'f'.repeat(Math.max(0, y - 1)) + (y ? 'k' : '') + (doubled && y ? 'k' : '')).padEnd(26, '.').slice(0, 26)));
    const bad = pixelArt(tri(true), { k, f });
    const good = pixelArt(tri(false), { k, f });
    expect(lintPixelArt(bad).stats.doubles).toBeGreaterThan(lintPixelArt(good).stats.doubles);
    expect(codes(bad)).toContain('P_DOUBLES');
    expect(codes(good)).not.toContain('P_DOUBLES');
  });
  it('jaggies: one-pixel bumps on the silhouette', () => {
    // A 24-px-tall bar whose left side wobbles out by one pixel every few rows
    const rows = Array.from({ length: 24 }, (_, y) => (y % 4 === 2 ? 'f' : '.') + 'f'.repeat(12));
    expect(codes(pixelArt(rows, { f: '#d4531c' }))).toContain('P_JAGGIES');
    expect(codes(disc(6))).not.toContain('P_JAGGIES');
  });
  it('mixels: a sprite drawn at 2× is found, and shrinks back to its grid', () => {
    const a = pixelOutline(pixelShade(disc(4)));
    const big = pixelDownscale(pixelScale2x(a), 1);
    const twice = pixelArt(pixelRows(a).rows.flatMap((r) => [[...r].map((c) => c + c).join(''), [...r].map((c) => c + c).join('')]), pixelRows(a).key);
    expect(codes(twice)).toContain('P_UPSCALED');
    expect(pixelRows(pixelDownscale(twice, 2)).rows.join('|').length).toBe(pixelRows(a).rows.join('|').length);
    const back = pixelDownscale(twice, 2);
    expect([...back.px].map((v) => back.colors[v - 1] ?? '.')).toEqual([...a.px].map((v) => a.colors[v - 1] ?? '.'));
    expect(big.w).toBe(a.w * 2);
  });
  it('a 2-px outline (a 16 px sprite scaled 2×) is found and thinned to 1 px', () => {
    const a = pixelOutline(pixelShade(disc(6)));
    const twice = pixelArt(pixelRows(a).rows.flatMap((r) => { const w = [...r].map((c) => c + c).join(''); return [w, w]; }), pixelRows(a).key);
    const scaled = pixelScale2x(a);
    expect(codes(scaled)).toContain('P_THICK_OUTLINE');
    const thin = pixelThinOutline(scaled);
    expect(codes(thin)).not.toContain('P_THICK_OUTLINE');
    expect(lintPixelArt(thin).stats.outline).toBeGreaterThan(0.9);
    expect(thin.colors.every((c) => scaled.colors.includes(c))).toBe(true);
    expect(twice.w).toBe(scaled.w);
  });
  it('flat values and a lost silhouette', () => {
    const a = pixelArt(['ffffffff', 'fgffffgf', 'ffffffff', 'ffgfffff', 'ffffffff'], { f: '#7a6a8a', g: '#806f90' });
    expect(codes(a)).toContain('P_FLAT');
    expect(codes(disc(5, '#5a5a6a'), { background: '#5e5e6c' })).toContain('P_CONTRAST');
  });
  it('a clean, shaded, outlined sprite passes', () => {
    expect(lintPixelArt(pixelOutline(pixelShade(disc(7)))).issues.filter((i) => i.severity === 'warning')).toEqual([]);
  });
  it('RGBA: half-transparent edges and painted pictures', () => {
    const im = pixelToRgba(disc(5));
    for (let i = 3; i < im.d.length; i += 4) if (im.d[i] === 0 && i % 7 === 0) im.d[i] = 90;
    expect(lintPixelImage(im).issues.map((i) => i.code)).toContain('P_SOFT_EDGE');
  });
});

describe('tiles and the set', () => {
  it('a tile whose edges do not meet shows its seam; a wrapping one does not', () => {
    const rows = (f: (x: number, y: number) => string) => Array.from({ length: 16 }, (_, y) => Array.from({ length: 16 }, (_, x) => f(x, y)).join(''));
    const key = { a: '#3a2f48', b: '#4a3c58', c: '#8a7f9c' };
    const seam = pixelArt(rows((x, y) => (x === 15 && y % 3 ? 'c' : y === 15 && x % 2 ? 'c' : (x + y) % 5 ? 'a' : 'b')), key);
    // A flagstone: a lighter top and left edge, a darker bottom and right — a grid on purpose
    const slab = pixelArt(rows((x, y) => (y === 0 || x === 0 ? 'c' : x === 15 || y === 15 ? 'a' : 'b')), key);
    expect(codes(slab, { tile: true })).toContain('P_TILE_GRID');
    expect(codes(slab, { tile: true })).not.toContain('P_SEAM');
    const ok = pixelArt(rows((x, y) => ((x + y) % 4 ? 'a' : 'b')), key);
    expect(codes(seam, { tile: true })).toContain('P_SEAM');
    expect(codes(ok, { tile: true })).not.toContain('P_SEAM');
  });
  it('the set: one sprite lit from the other side', () => {
    const lit = pixelOutline(pixelShade(disc(7)));
    const other = pixelOutline(pixelShade(disc(7), { light: [1, 1] }));
    expect(lintPixelArt(lit).stats.light).not.toBeNull();
    const set = [lit, lit, lit, lit, other].map((a, i) => ({ name: `s${i}`, stats: lintPixelArt(a).stats }));
    const issues = lintPixelSet(set);
    expect(issues.map((i) => i.code)).toContain('P_SET_LIGHT');
    expect(issues.find((i) => i.code === 'P_SET_LIGHT')!.message).toContain('s4');
    expect(lintPixelSet(set.slice(0, 4))).toEqual([]);
  });
});

describe('lintPixelFrames', () => {
  it('flicker: lone pixels that blink between frames; a bob of one pixel is fine', () => {
    const a = pixelOutline(pixelShade(disc(6)));
    const { rows, key } = pixelRows(a);
    const bob = pixelArt(['.'.repeat(a.w), ...rows.slice(0, -1)], key);
    expect(lintPixelFrames([a, bob])).toEqual([]);
    // Speckle: every 7th pixel swapped to another colour
    const noisy = pixelArt(rows.map((r, y) => [...r].map((c, x) => (c !== '.' && (x * 3 + y * 5) % 7 === 0 ? (c === 'a' ? 'b' : 'a') : c)).join('')), key);
    expect(lintPixelFrames([a, noisy]).map((i) => i.code)).toContain('P_FLICKER');
  });
});

describe('pixelDither', () => {
  it('half and half is a checker', () => {
    const a = pixelDither(pixelArt(['....', '....', '....', '....'], {}), '#000000', '#ffffff', () => 0.5);
    const { rows } = pixelRows(a);
    expect(new Set(rows.join(''))).toEqual(new Set(['a', 'b']));
    expect(rows[0]![0]).not.toBe(rows[0]![1]);
    expect(rows[0]![0]).not.toBe(rows[1]![0]);
  });
});

describe('rotSprite', () => {
  it('turns without new colours and keeps the pixel count close', () => {
    const a = pixelOutline(pixelArt(['ffffffffff', 'ffffffffff', 'ff........'], { f: '#d4531c' }));
    for (const ang of [Math.PI / 2, Math.PI / 6, 1]) {
      const r = rotSprite(a, ang);
      expect(r.colors.every((c) => a.colors.includes(c))).toBe(true);
      expect(Math.abs(count(r) - count(a)) / count(a)).toBeLessThan(0.2);
    }
    // A quarter turn swaps width and height
    const q = pixelTrim(rotSprite(a, Math.PI / 2)).art;
    expect([q.w, q.h]).toEqual([a.h, a.w]);
  });
});

describe('depixelize', () => {
  /** The sprite drawn as a model draws "pixel art": blocks of a non-whole pitch, an offset, soft block edges, noise */
  function asModel(a: PixelArt, pitch: number, off: number): RgbaImage {
    const big = pixelToRgba(a);
    const w = Math.ceil(a.w * pitch + off * 2), h = Math.ceil(a.h * pitch + off * 2);
    const d = new Uint8ClampedArray(w * h * 4);
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647 - 0.5) * 10;
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        const fx = (x - off) / pitch, fy = (y - off) / pitch;
        const sx = Math.floor(fx), sy = Math.floor(fy);
        if (sx < 0 || sy < 0 || sx >= a.w || sy >= a.h) continue;
        // a blurred pixel at each block's border: the average of this block and its left neighbour
        const edgeX = fx - sx < 0.06 && sx > 0;
        const i = (sy * a.w + sx) * 4, j = (sy * a.w + sx - 1) * 4, o = (y * w + x) * 4;
        for (let k = 0; k < 4; k++) d[o + k] = edgeX ? (big.d[i + k]! + big.d[j + k]!) / 2 : big.d[i + k]! + (k < 3 && big.d[i + 3] ? rnd() : 0);
      }
    return { w, h, d };
  }
  it('finds the block pitch of a pseudo-pixel picture and gives back the sprite', () => {
    const a = pixelTrim(pixelOutline(pixelShade(disc(9)))).art;
    const im = asModel(a, 21.33, 37);
    const g = detectPixelPitch(im);
    expect(g.x).toBeGreaterThan(20.8);
    expect(g.x).toBeLessThan(21.9);
    const r = depixelize(im, { palette: a.colors });
    expect(r.found).toBe(true);
    expect([r.art.w, r.art.h]).toEqual([a.w, a.h]);
    let same = 0;
    for (let i = 0; i < a.px.length; i++) if (a.colors[a.px[i]! - 1] === r.art.colors[r.art.px[i]! - 1]) same++;
    expect(same / a.px.length).toBeGreaterThan(0.97);
  });
  it('real pixels: no block grid', () => {
    expect(detectPixelPitch(pixelToRgba(pixelOutline(pixelShade(disc(9))))).x).toBe(1);
  });
});

describe('pixelViewport', () => {
  it('a whole-number scale, the buffer grown to the device aspect', () => {
    expect(pixelViewport(1920, 1080, 384, 216)).toEqual({ scale: 5, w: 384, h: 216 });
    expect(pixelViewport(1280, 720, 384, 216)).toEqual({ scale: 3, w: 427, h: 240 });
    // A phone held upright, a 216-px-tall design: never below scale 1
    expect(pixelViewport(780, 1688, 384, 216).scale).toBe(2);
    expect(pixelViewport(200, 100, 384, 216)).toEqual({ scale: 1, w: 200, h: 100 });
  });
});

describe('pixelFlat', () => {
  it('one colour for the silhouette test and the hit flash', () => {
    expect(pixelFlat(pixelShade(disc(3))).colors).toEqual(['#ffffff']);
  });
});
