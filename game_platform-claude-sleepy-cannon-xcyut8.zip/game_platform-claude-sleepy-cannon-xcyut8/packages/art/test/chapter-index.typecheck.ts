// Not a test file: the type checker (`npm run typecheck`) checks that what gp art writes into assets/index.ts for a game
// with chapters (fixtures/chapter-index.ts, kept current by packages/cli/test/chapters.test.ts) is what createAssets
// takes, and that its drawables go where an image goes. Nothing runs it.

import { createAssets, drawImageSprite, frameAt, isPlaceholder, type Drawable, type SizedImage } from '../src/assets.ts';
import { ASSETS, PARTS } from './fixtures/chapter-index.ts';

export async function useChapters(ctx: CanvasRenderingContext2D): Promise<void> {
  const assets = createAssets(ASSETS);
  await assets.ready(0);
  assets.prefetch(1);
  await assets.ready(['redCar', 'redCarWheel1']);
  const car: Drawable = assets.img.redCar;
  const sized: SizedImage = car;
  drawImageSprite(ctx, sized, 10, 10, 100, { anchorY: 1 });
  assets.draw(ctx, 'hero', 0, 0, 64);
  const f = frameAt(assets.frames('hero'), 0.5);
  ctx.drawImage(f, 0, 0, f.naturalWidth, f.naturalHeight);
  const wheel = PARTS.redCarWheel1;
  ctx.drawImage(assets.img[wheel.of], wheel.x, wheel.y);
  if (!isPlaceholder(car)) ctx.drawImage(car, 0, 0);
  const img: HTMLImageElement | null = assets.get('garage');
  void img;
  // @ts-expect-error an id that isn't in ART
  assets.sprite('blueCar');
}
