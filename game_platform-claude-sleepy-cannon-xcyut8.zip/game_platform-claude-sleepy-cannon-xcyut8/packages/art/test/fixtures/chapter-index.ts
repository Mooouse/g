// Written by gp art from game.yaml `art` — don't edit. The images and what made them: this folder, provenance.yaml.
// Chapters (art.assets[].chapter): chapter 0 is in the game's script, a later chapter loads after Play — `const assets = createAssets(ASSETS)`, `await assets.ready(0)` in start(), `assets.prefetch(1)` after Play, draw with `assets.draw` or `assets.img.<id>` (a placeholder until decoded) (@gp/art/assets).

import garage from './garage.webp';
import redCar from './red-car.webp?gp-chapter=1';
import redCarWheel1 from './red-car-wheel-1.webp?gp-chapter=1';
import hero from './hero.webp?gp-chapter=2';
import heroF1 from './hero-1.webp?gp-chapter=2';
import heroF2 from './hero-2.webp?gp-chapter=2';
import redCar_thumb from './thumbs/red-car.webp';

export const ART = { garage, redCar, redCarWheel1, hero } as const;
export type ArtId = keyof typeof ART;
/** Each animated sprite's frames, in order: `const frames = await loadFrames(FRAMES)`, then `frameAt(frames.<id>, t, fps)` */
export const FRAMES = { hero: [heroF1, heroF2] } as const;
/** Parts cut from a sprite (gp art import: wheels, paint masks): draw each with its centre at (x, y) of `of`, in that sprite's pixels */
export const PARTS = { redCarWheel1: { of: 'redCar', x: 10, y: 20 } } as const;
/** The chapter of each image loaded after Play (the rest: chapter 0, in the game's script) */
export const CHAPTERS = { redCar: 1, redCarWheel1: 1, hero: 2 } as const;
/** Each later image's size in px: its placeholder's, before it is decoded */
export const SIZES = { redCar: [720, 310], hero: [128, 256] } as const;
/** Each later image's 32 px thumbnail (in the script, before Play): drawn in its place until it is decoded */
export const THUMBS = { redCar: redCar_thumb } as const;
/** Everything createAssets (@gp/art/assets) needs */
export const ASSETS = { urls: ART, frames: FRAMES, chapters: CHAPTERS, sizes: SIZES, thumbs: THUMBS } as const;
