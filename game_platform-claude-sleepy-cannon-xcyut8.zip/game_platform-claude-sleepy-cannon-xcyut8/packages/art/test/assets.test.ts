// @gp/art/assets: which animation frame is drawn when, and the chapters' scheduler (createAssets) — what is decoded
// when, in what order, how many at once, and what is drawn until then. The browser half (data blocks, placeholders,
// warm-ups on a real canvas) is in test-browser/assets.test.ts.

import { describe, expect, it } from 'vitest';
import { assetSource, callSite, createAssets, frameAt, isPlaceholder, type AssetsOptions, type Placeholder } from '../src/assets.ts';

describe('frameAt', () => {
  const f = ['a', 'b', 'c'];
  it('loops at the frame rate', () => {
    expect([0, 0.124, 0.125, 0.25, 0.375, 0.5].map((t) => frameAt(f, t, 8))).toEqual(['a', 'a', 'b', 'c', 'a', 'b']);
  });
  it('holds the last frame of a one-shot, and never reads before the first', () => {
    expect(frameAt(f, 10, 8, false)).toBe('c');
    expect(frameAt(f, -1, 8)).toBe('a');
    expect(() => frameAt([], 0)).toThrow();
  });
});

/** A fake world: decodes that resolve when the test says, idle slices run by hand, placeholders as plain objects */
function world(opts: { failing?: string[] } = {}) {
  const pending = new Map<string, { ok: (img: HTMLImageElement) => void; fail: (e: Error) => void }>();
  const started: string[] = [];
  const warmed: string[] = [];
  const slices: ((d: { didTimeout: boolean; timeRemaining(): number }) => void)[] = [];
  const o: AssetsOptions = {
    decode: (url) =>
      new Promise((ok, fail) => {
        started.push(url);
        if (opts.failing?.includes(url)) fail(new Error('bad'));
        else pending.set(url, { ok, fail });
      }),
    warm: (img) => void warmed.push((img as unknown as { src: string }).src),
    idle: (cb) => void slices.push(cb),
    placeholder: (size, thumb) => ({ gpPlaceholder: true, naturalWidth: size?.[0] ?? 64, naturalHeight: size?.[1] ?? 64, thumb }) as unknown as Placeholder,
    now: () => 1000,
    // The early-chapter warning has its own tests below
    dev: false,
  };
  const flush = () => new Promise((r) => setTimeout(r, 0));
  return {
    o,
    started,
    warmed,
    /** Run the idle slices queued so far (a busy frame: no time left after the first job) */
    async slice(remaining = 0) {
      const now = slices.splice(0);
      for (const cb of now) cb({ didTimeout: remaining === 0, timeRemaining: () => remaining });
      await flush();
    },
    /** Finish these decodes */
    async decoded(...urls: string[]) {
      for (const u of urls) pending.get(u)?.ok({ src: u, naturalWidth: 10, naturalHeight: 5 } as unknown as HTMLImageElement);
      await flush();
    },
  };
}

const MANIFEST = {
  urls: { garage: 'g.webp', car1: 'c1.webp', car2: 'c2.webp', car3: 'c3.webp', car4: 'c4.webp', car5: 'c5.webp', hero: 'h.webp' },
  frames: { hero: ['h1.webp', 'h2.webp'] },
  chapters: { car2: 1, car3: 1, car4: 1, car5: 2 },
  sizes: { car2: [720, 310], car3: [700, 300], car4: [700, 300], car5: [700, 300] },
  thumbs: { car2: 't2.webp' },
} as const;

describe('createAssets: chapters', () => {
  it('ready(0) decodes chapter 0 only; a later chapter waits until asked', async () => {
    const w = world();
    const a = createAssets(MANIFEST, { ...w.o, concurrency: 8 });
    expect(a.chapters).toEqual([0, 1, 2]);
    expect(a.ids(1)).toEqual(['car2', 'car3', 'car4']);
    expect(a.chapterOf('car1')).toBe(0);
    let ready = false;
    void a.ready(0).then(() => (ready = true));
    await w.slice(50);
    // garage, car1, hero and its two frames: the frames are in their sprite's chapter
    expect(w.started.sort()).toEqual(['c1.webp', 'g.webp', 'h.webp', 'h1.webp', 'h2.webp']);
    await w.decoded('g.webp', 'c1.webp', 'h.webp', 'h1.webp', 'h2.webp');
    expect(ready).toBe(false);
    // Decoded, then warmed up in an idle slice (the first-draw decode), one by one or while the slice lasts
    await w.slice(50);
    expect(ready).toBe(true);
    expect(w.warmed).toHaveLength(5);
    expect(a.progress(0)).toEqual({ done: 5, total: 5 });
    expect(a.progress(1)).toEqual({ done: 0, total: 3 });
    expect(a.loaded('car2')).toBe(false);
    expect(w.started.some((u) => /c[2-5]/.test(u))).toBe(false);
  });

  it('a busy frame starts and warms one image a slice; never more than `concurrency` decoding', async () => {
    const w = world();
    const a = createAssets(MANIFEST, { ...w.o, concurrency: 2 });
    void a.ready(1);
    await w.slice(0);
    expect(w.started).toEqual(['c2.webp']);
    await w.slice(0);
    expect(w.started).toEqual(['c2.webp', 'c3.webp']);
    await w.slice(0);
    // two in flight: the third waits
    expect(w.started).toHaveLength(2);
    await w.decoded('c2.webp', 'c3.webp');
    await w.slice(0);
    expect(w.warmed).toEqual(['c2.webp']);
    await w.slice(0);
    expect(w.warmed).toEqual(['c2.webp', 'c3.webp']);
    expect(w.started).toContain('c4.webp');
  });

  it('drawn before it is decoded: the placeholder at its size, asked for first in line; the image once decoded', async () => {
    const w = world();
    const a = createAssets(MANIFEST, { ...w.o, concurrency: 1 });
    a.prefetch(1);
    const p = a.img.car4;
    expect(isPlaceholder(p)).toBe(true);
    expect([p.naturalWidth, p.naturalHeight]).toEqual([700, 300]);
    expect(isPlaceholder(a.sprite('car2'))).toBe(true);
    expect((a.sprite('car2') as unknown as { thumb: string }).thumb).toBe('t2.webp');
    // car2 and car4 drawn (on demand) go before car3, which is only prefetched
    await w.slice(0);
    expect(w.started).toEqual(['c2.webp']);
    await w.decoded('c2.webp');
    await w.slice(0);
    expect(w.started).toEqual(['c2.webp', 'c4.webp']);
    expect(a.get('car2')).not.toBeNull();
    expect(isPlaceholder(a.img.car2)).toBe(false);
    expect(a.get('car3')).toBeNull();
  });

  it('an animated sprite: its frames, the sprite in place of one not decoded yet', async () => {
    const w = world();
    const a = createAssets(MANIFEST, { ...w.o, concurrency: 8 });
    void a.ready('hero');
    await w.slice(50);
    await w.decoded('h.webp', 'h1.webp');
    await w.slice(50);
    const f = a.frames('hero');
    expect(f.map((x) => (x as unknown as { src: string }).src)).toEqual(['h1.webp', 'h.webp']);
    expect(a.loaded('hero')).toBe(false);
  });

  it('a picture that cannot be decoded rejects ready() with its id and stays a placeholder', async () => {
    const w = world({ failing: ['c5.webp'] });
    const a = createAssets(MANIFEST, { ...w.o });
    const r = a.ready(2).then(() => 'ok', (e: Error) => e.message);
    await w.slice(50);
    expect(await r).toMatch(/car5/);
    expect(isPlaceholder(a.img.car5)).toBe(true);
    // asked again: it doesn't try forever
    await expect(a.ready('car5')).rejects.toThrow(/car5/);
  });

  it('draw(): the placeholder, then the image fading in over it', async () => {
    const w = world();
    let t = 1000;
    const a = createAssets(MANIFEST, { ...w.o, now: () => t, fadeMs: 200 });
    const drawn: { img: string; alpha: number }[] = [];
    class FakeCtx {
      globalAlpha = 1;
      private stack: number[] = [];
      save() {
        this.stack.push(this.globalAlpha);
      }
      restore() {
        this.globalAlpha = this.stack.pop() ?? 1;
      }
      translate() {}
      rotate() {}
      scale() {}
      drawImage(img: { src?: string; gpPlaceholder?: boolean }) {
        drawn.push({ img: img.gpPlaceholder ? 'placeholder' : img.src!, alpha: +this.globalAlpha.toFixed(2) });
      }
    }
    const ctx = new FakeCtx() as unknown as CanvasRenderingContext2D;
    a.draw(ctx, 'car3', 0, 0, 100);
    expect(drawn).toEqual([{ img: 'placeholder', alpha: 1 }]);
    await w.slice(0);
    await w.decoded('c3.webp');
    await w.slice(0);
    drawn.length = 0;
    t = 1100;
    a.draw(ctx, 'car3', 0, 0, 100);
    expect(drawn).toEqual([{ img: 'placeholder', alpha: 0.5 }, { img: 'c3.webp', alpha: 0.5 }]);
    drawn.length = 0;
    t = 1300;
    a.draw(ctx, 'car3', 0, 0, 100);
    expect(drawn).toEqual([{ img: 'c3.webp', alpha: 1 }]);
  });

  it('assetSource: a data: URI or a URL as it is outside a page with data blocks', async () => {
    expect(await assetSource('data:image/webp;base64,AAAA')).toBe('data:image/webp;base64,AAAA');
    expect(await assetSource('chapters/1/car.webp')).toBe('chapters/1/car.webp');
  });
});

// Dev only: a later chapter asked for at boot starts decoding before the first screen. gp qa fails that in its
// production section; the warning says it at once, with the line that asked
describe('createAssets: the early-chapter warning (dev builds)', () => {
  const setup = (o: { dev?: boolean; painted?: boolean } = {}) => {
    const w = world();
    const said: string[] = [];
    let painted = o.painted ?? false;
    const a = createAssets(MANIFEST, { ...w.o, concurrency: 8, dev: o.dev ?? true, warn: (m) => void said.push(m), painted: () => painted });
    return { w, a, said, paint: () => (painted = true) };
  };

  it('ready(<later chapter>) at boot: one warning naming the chapter and the call site, never a second', () => {
    const { a, said } = setup();
    void a.ready(0);
    expect(said).toEqual([]);
    void a.ready(1);
    void a.ready(2);
    void a.prefetch(1);
    expect(said).toHaveLength(1);
    expect(said[0]).toContain('ready(1) asks for chapter 1 before the first screen (chapter 0 not decoded yet)');
    expect(said[0]).toMatch(/at .*assets\.test\.ts:\d+/);
  });

  it('an id of a later chapter, or a prefetch, counts too', () => {
    const one = setup();
    one.a.ready(['car1', 'car5']).catch(() => {});
    expect(one.said[0]).toContain('ready(["car1","car5"]) asks for chapter 2');
    const two = setup();
    two.a.prefetch(2);
    expect(two.said[0]).toContain('prefetch(2) asks for chapter 2');
  });

  it('chapter 0 decoded but nothing painted yet: still the boot; decoded and painted: silent (Play, the game drawing on)', async () => {
    const decoded = async () => {
      const t = setup();
      void t.a.ready(0);
      await t.w.slice(50);
      await t.w.decoded('g.webp', 'c1.webp', 'h.webp', 'h1.webp', 'h2.webp');
      await t.w.slice(50);
      expect(t.a.progress(0)).toEqual({ done: 5, total: 5 });
      return t;
    };
    const early = await decoded();
    void early.a.ready(1);
    expect(early.said).toHaveLength(1);
    expect(early.said[0]).toContain('(before the first paint)');
    const later = await decoded();
    later.paint();
    void later.a.ready(1);
    later.a.prefetch(2);
    expect(later.said).toEqual([]);
  });

  it('production (dev: false) stays silent', () => {
    const { a, said } = setup({ dev: false });
    void a.ready(1);
    a.prefetch(2);
    expect(said).toEqual([]);
  });

  it('callSite: the first frame outside the module', () => {
    const stack = ['Error', '    at callSite (http://x/@fs/p/packages/art/src/assets.ts:250:20)', '    at Object.ready (http://x/@fs/p/packages/art/src/assets.ts:480:7)', '    at start (http://x/main.ts:40:12)'].join('\n');
    expect(callSite(stack, '/@fs/p/packages/art/src/assets.ts')).toBe('start (http://x/main.ts:40:12)');
    expect(callSite('Error', '/assets.ts')).toBeNull();
  });
});
