// A later asset chapter's image (game.yaml art.assets[].chapter; gp art writes `import car40 from './car40.webp?gp-chapter=1'`
// in assets/index.ts): the build keeps it out of the game's script (packages/cli/src/chapters.ts); the module is its URL.
// Pulled in by @gp/art/assets (a triple-slash reference), so a game that uses createAssets has these types.
declare module '*?gp-chapter=1' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=2' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=3' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=4' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=5' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=6' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=7' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=8' {
  const url: string;
  export default url;
}
declare module '*?gp-chapter=9' {
  const url: string;
  export default url;
}
