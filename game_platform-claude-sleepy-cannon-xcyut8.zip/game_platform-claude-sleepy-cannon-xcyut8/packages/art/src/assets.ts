/// <reference path="./chapter-imports.d.ts" />
// Generated art (gp art): load the game's images before the first frame. assets/index.ts exports ART, a map of id → the
// bundled URL (a data: URI in a one-file portal upload); `await loadImages(ART)` decodes them all, so the first frame never
// draws an empty sprite; animated sprites are in FRAMES: `await loadFrames(FRAMES)`, then `frameAt(frames.hero, t)`. Draw
// them with drawImage (Canvas 2D), Texture.from (Pixi), this.textures.addImage (Phaser) or a THREE.Texture. Keep the life in code on top: @gp/art light, fx, rig and camera (docs/guides/art.md#5-generated-art-gp-art).
//
// Chapters (game.yaml art.assets[].chapter, docs/guides/art.md#52-chapters-what-loads-before-play): a game with many
// pictures loads only chapter 0 before Play. `createAssets(ASSETS)` (assets/index.ts) decodes a chapter when asked
// (`ready`, `prefetch`) or an image when it is drawn (on demand), a few at a time in idle time, and draws a placeholder (its
// low-res thumbnail, else a soft silhouette of its size) until then. In the one-file portal upload a later chapter's images
// are data blocks at the end of index.html, after the game's script (`<script type="application/octet-stream"
// data-gp-asset>`, never parsed as script): the game starts while they still arrive. In `gp dev` and a multi-file build
// they are files (chapters/<n>/…), fetched when first needed.

/** A drawable with a size: an image, or a placeholder canvas that carries its image's size (drawImageSprite takes both) */
export type SizedImage = CanvasImageSource & { readonly naturalWidth: number; readonly naturalHeight: number };

/** What `createAssets` draws while an image isn't decoded yet: a small canvas with the full image's size */
export interface Placeholder extends HTMLCanvasElement {
  readonly naturalWidth: number;
  readonly naturalHeight: number;
  readonly gpPlaceholder: true;
}

/** An image of a chapter, or its placeholder until it is decoded */
export type Drawable = HTMLImageElement | Placeholder;

/** A placeholder, not the image yet */
export const isPlaceholder = (img: unknown): img is Placeholder => !!img && (img as { gpPlaceholder?: unknown }).gpPlaceholder === true;

/** The data blocks of a one-file upload: the build writes one per later-chapter image, after the game's script */
export const ASSET_BLOCK = 'script[data-gp-asset]';
/** A block's data: URL by its asset URL, once read (it stays: two loaders of one image never fetch it as a file) */
const blocks = new Map<string, string>();

/** Read the data blocks the page has received in full (a block still arriving is shorter than its data-n) */
function scanBlocks(): void {
  if (typeof document === 'undefined') return;
  for (const el of document.querySelectorAll<HTMLScriptElement>(ASSET_BLOCK)) {
    const text = el.text;
    if (text.length < Number(el.dataset.n ?? 0)) continue;
    blocks.set(el.dataset.gpAsset ?? '', `data:${el.dataset.type ?? 'application/octet-stream'};base64,${text}`);
    // The string lives on in the cache (and the image's src): the page needn't hold a second copy
    el.remove();
  }
}

const nextTick = () => new Promise<void>((r) => setTimeout(r, 40));

/**
 * Where to load an image from: its data block in a one-file upload (waiting while the page is still arriving: the blocks
 * come after the game's script), else the URL itself — a file in `gp dev` and in a multi-file build, a data: URI as is
 */
export async function assetSource(url: string): Promise<string> {
  if (/^(data|blob):/.test(url) || typeof document === 'undefined') return url;
  for (;;) {
    scanBlocks();
    const hit = blocks.get(url);
    if (hit) return hit;
    if (document.readyState !== 'loading') {
      scanBlocks();
      return blocks.get(url) ?? url;
    }
    await nextTick();
  }
}

async function decodeImage(url: string): Promise<HTMLImageElement> {
  const img = new Image();
  img.decoding = 'async';
  img.src = await assetSource(url);
  await img.decode();
  return img;
}

let scratch: CanvasRenderingContext2D | null = null;
/**
 * The first drawImage of an image decodes it again, synchronously, on the main thread — whatever img.decode() did
 * (Chromium at 4× CPU: ≈ 29 ms for a 720×310 WebP; a frame with four new pictures took 116 ms). Drawing it once into a
 * 1×1 CPU canvas and reading a pixel back does that decode now, in an idle slice, and the game's canvas then draws it in
 * ≈ 3 ms (measured: docs/guides/code-games.md#asset-chapters-what-play-waits-for). An ImageBitmap (createImageBitmap)
 * decodes off the main thread, but in Chromium's software GL the game then drew at 30 fps where <img> drew at 60, and it
 * stuttered as much while loading: the frame rate is what QA checks.
 */
export function warmImage(img: CanvasImageSource): void {
  if (typeof document === 'undefined') return;
  if (!scratch) {
    const c = document.createElement('canvas');
    c.width = c.height = 1;
    scratch = c.getContext('2d', { willReadFrequently: true });
  }
  if (!scratch) return;
  scratch.drawImage(img, 0, 0, 1, 1);
  scratch.getImageData(0, 0, 1, 1);
}

/** Decode every image of a { id: url } map; resolves when all are ready (a failed one rejects with its id) */
export async function loadImages<K extends string>(urls: Readonly<Record<K, string>>): Promise<Record<K, HTMLImageElement>> {
  const entries = await Promise.all(
    (Object.entries(urls) as [K, string][]).map(async ([id, url]) => {
      const img = new Image();
      img.decoding = 'async';
      img.src = await assetSource(url);
      try {
        await img.decode();
      } catch {
        throw new Error(`@gp/art/assets: the image "${id}" could not be decoded`);
      }
      return [id, img] as const;
    }),
  );
  return Object.fromEntries(entries) as Record<K, HTMLImageElement>;
}

/** Decode every animation of a { id: [url, …] } map (assets/index.ts FRAMES) */
export async function loadFrames<K extends string>(frames: Readonly<Record<K, readonly string[]>>): Promise<Record<K, HTMLImageElement[]>> {
  const entries = await Promise.all(
    (Object.entries(frames) as [K, readonly string[]][]).map(async ([id, urls]) => {
      const imgs = await loadImages(Object.fromEntries(urls.map((u, i) => [`${id}-${i + 1}`, u])) as Record<string, string>);
      return [id, urls.map((_, i) => imgs[`${id}-${i + 1}`]!)] as const;
    }),
  );
  return Object.fromEntries(entries) as Record<K, HTMLImageElement[]>;
}

// --- Chapters: what loads before Play, and the rest in idle time ----------------------------------------------------

/** What assets/index.ts exports as ASSETS (gp art writes it); everything but `urls` is optional */
export interface AssetManifest<K extends string = string> {
  /** id → URL (ART) */
  readonly urls: Readonly<Record<K, string>>;
  /** An animated sprite's frames (FRAMES): in its chapter */
  readonly frames?: Readonly<Partial<Record<K, readonly string[]>>>;
  /** id → chapter (CHAPTERS); missing: 0, loaded before Play */
  readonly chapters?: Readonly<Partial<Record<K, number>>>;
  /** id → [width, height] in px (SIZES): a placeholder's size before its image is decoded */
  readonly sizes?: Readonly<Partial<Record<K, readonly [number, number]>>>;
  /** id → a low-res thumbnail's URL (THUMBS, bundled with chapter 0): the placeholder until the image is decoded */
  readonly thumbs?: Readonly<Partial<Record<K, string>>>;
}

export interface AssetsOptions {
  /** Images decoding at once (default 4): the decoder threads, not the frame, do the work */
  concurrency?: number;
  /** Start a decode only when an idle period has this many ms left (default 4): a frame is never kept waiting */
  idleMs?: number;
  /** Placeholders cross-fade into their image over this many ms in `draw` (default 180) */
  fadeMs?: number;
  /** Tests: how an image is decoded, warmed up (its first-draw decode, in an idle slice), and how idle time is waited for */
  decode?: (url: string) => Promise<HTMLImageElement>;
  warm?: (img: HTMLImageElement) => void;
  idle?: (cb: (deadline: { didTimeout: boolean; timeRemaining(): number }) => void) => void;
  placeholder?: (size: readonly [number, number] | undefined, thumb: string | undefined) => Placeholder;
  now?: () => number;
  /**
   * Dev builds: a `ready` or `prefetch` of a later chapter before the first screen logs one console warning naming the
   * chapter and the call site; `false` switches it off. A production build has none of it (the code is dropped)
   */
  dev?: boolean;
  /** Tests: where the early-chapter warning goes (default console.warn), and whether the page has painted yet */
  warn?: (message: string) => void;
  painted?: () => boolean;
}

/** What is asked for: a chapter's number, an id, or several ids */
export type AssetSelection<K extends string> = number | K | readonly K[];

export interface Assets<K extends string> {
  /** Every id: its image once decoded, its placeholder before — reading one asks for it (on demand, first in line) */
  readonly img: Readonly<Record<K, Drawable>>;
  /** The image, or its placeholder while it is being decoded (asks for it) */
  sprite(id: K): Drawable;
  /** The decoded image, or null (asks for it) */
  get(id: K): HTMLImageElement | null;
  /** Decoded (with its frames) */
  loaded(id: K): boolean;
  /** An animated sprite's frames: each decoded one, or the sprite (or its placeholder) in its place */
  frames(id: K): Drawable[];
  chapterOf(id: K): number;
  /** The ids of a chapter */
  ids(chapter: number): K[];
  /** The chapters there are, in order */
  readonly chapters: readonly number[];
  /** Resolves when everything selected is decoded (rejects with the id of an image that could not be) */
  ready(what: AssetSelection<K>): Promise<void>;
  /** Start decoding ahead of time, after anything asked for by `ready` or drawn */
  prefetch(what: AssetSelection<K>): void;
  /** How many images (frames count) of a chapter — or of all — are decoded */
  progress(chapter?: number): { done: number; total: number };
  /** drawImageSprite of the image, or of its placeholder, cross-fading when the image arrives */
  draw(ctx: CanvasRenderingContext2D, id: K, x: number, y: number, height: number, o?: Parameters<typeof drawImageSprite>[5]): void;
}

interface Job {
  key: string;
  url: string;
  chapter: number;
  /** 0 drawn (on demand), 1 asked for by ready(), 2 prefetched, 3 not asked for */
  pri: number;
  seq: number;
  state: 'idle' | 'queued' | 'loading' | 'done' | 'failed';
  img: HTMLImageElement | null;
  at: number;
  waiters: { ok: () => void; fail: (e: Error) => void }[];
}

const PLACEHOLDER_PX = 32;

/** A placeholder canvas: the thumbnail (when there is one) or a soft silhouette, at the image's size */
export function makePlaceholder(size: readonly [number, number] | undefined, thumb: string | undefined): Placeholder {
  const [w, h] = size ?? [64, 64];
  const k = PLACEHOLDER_PX / Math.max(w, h, 1);
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w * k));
  c.height = Math.max(1, Math.round(h * k));
  Object.defineProperties(c, { naturalWidth: { value: w }, naturalHeight: { value: h }, gpPlaceholder: { value: true } });
  const g = c.getContext('2d');
  if (g) {
    // A silhouette: a soft rounded block of the image's shape, never a hole in the scene
    g.fillStyle = 'rgba(140, 146, 160, 0.32)';
    const r = Math.min(c.width, c.height) * 0.3;
    g.beginPath();
    g.roundRect(0, 0, c.width, c.height, r);
    g.fill();
    if (thumb) {
      const t = new Image();
      t.decoding = 'async';
      t.src = thumb;
      t.decode().then(
        () => {
          g.clearRect(0, 0, c.width, c.height);
          g.drawImage(t, 0, 0, c.width, c.height);
        },
        () => {},
      );
    }
  }
  return c as Placeholder;
}

const defaultIdle: NonNullable<AssetsOptions['idle']> = (cb) => {
  const ric = (globalThis as { requestIdleCallback?: (f: (d: IdleDeadline) => void, o?: { timeout: number }) => number }).requestIdleCallback;
  // A game that keeps the main thread busy still gets its pictures: the timeout runs a slice anyway
  if (ric) ric(cb, { timeout: 250 });
  else setTimeout(() => cb({ didTimeout: true, timeRemaining: () => 8 }), 16);
};

/** This module's own path: its frames are skipped when the early-chapter warning names the call site */
function selfPath(): string {
  try {
    return new URL(import.meta.url).pathname;
  } catch {
    return '/assets.ts';
  }
}

/** The first stack frame outside this module — the game's line that asked (`start (…/main.ts:40:12)`), or null */
export function callSite(stack: string | undefined = new Error().stack, self = selfPath()): string | null {
  for (const line of (stack ?? '').split('\n').slice(1)) {
    const at = line.trim().replace(/^at\s+/, '');
    if (!at || at.includes(self) || /^(async\s+)?(new\s+)?Promise\b|^<anonymous>|^native\b/.test(at)) continue;
    return at;
  }
  return null;
}

/** The browser's first contentful paint has happened (QA's "first screen" is it and chapter 0 decoded) */
const defaultPainted = () => {
  try {
    return (globalThis.performance?.getEntriesByName?.('first-contentful-paint')?.length ?? 0) > 0;
  } catch {
    return false;
  }
};

/**
 * The early-chapter warning (dev builds): a `ready` or `prefetch` of a later chapter before the first screen — chapter 0
 * decoded and the first paint, as gp qa's production check counts it — or the player's first input (Play) logs one
 * console warning with the chapter and the call site; after the first screen, or once it has warned, it is silent
 */
function earlyChapterWatch(opts: AssetsOptions, zeroDone: () => boolean): (call: 'ready' | 'prefetch', what: unknown, list: readonly { chapter: number }[]) => void {
  const warn = opts.warn ?? ((m: string) => console.warn(m));
  const painted = opts.painted ?? defaultPainted;
  let watch = true;
  let acted = false;
  if (typeof addEventListener === 'function') {
    const act = () => {
      acted = true;
      removeEventListener('pointerdown', act, true);
      removeEventListener('keydown', act, true);
    };
    addEventListener('pointerdown', act, true);
    addEventListener('keydown', act, true);
  }
  return (call, what, list) => {
    if (!watch) return;
    const zero = zeroDone();
    if (acted || (zero && painted())) {
      watch = false;
      return;
    }
    const later = [...new Set(list.map((j) => j.chapter).filter((c) => c > 0))].sort((a, b) => a - b);
    if (!later.length) return;
    watch = false;
    const asked = typeof what === 'number' ? String(what) : JSON.stringify(what);
    const site = callSite();
    warn(
      `[@gp/art/assets] ${call}(${asked}) asks for chapter ${later.join(', ')} before the first screen (${zero ? 'before the first paint' : 'chapter 0 not decoded yet'})${site ? `, at ${site}` : ''}: ` +
        `it starts decoding now, ahead of what Play waits for, and gp qa fails it ("no later-chapter image decoded before the first screen"). ` +
        `Ask for it after Play (prefetch on Play, ready where it is drawn); a cover's picture: host.qa({ cover: { ready: () => assets.ready([…]) } }). Dev builds only, once`,
    );
  };
}

const mark = (name: string) => {
  try {
    globalThis.performance?.mark?.(name);
  } catch {
    // marks are a measurement aid only
  }
};

/**
 * The game's images by chapter (game.yaml art.assets[].chapter): `const assets = createAssets(ASSETS)` from
 * assets/index.ts, then `await assets.ready(0)` in start() (what the first minutes draw) and, after Play,
 * `assets.prefetch(1)`. Draw with `assets.draw(ctx, 'car40', x, y, h)` or `drawImageSprite(ctx, assets.img.car40, …)`:
 * an image not decoded yet is drawn as its placeholder and asked for. Decoding is spread over idle time, a few at a time,
 * so a frame never waits for it (game19: creating 300 images at boot pushed its first screen past 3 s).
 */
export function createAssets<K extends string>(manifest: AssetManifest<K>, opts: AssetsOptions = {}): Assets<K> {
  const concurrency = Math.max(1, opts.concurrency ?? 4);
  const idleMs = opts.idleMs ?? 4;
  const fadeMs = opts.fadeMs ?? 180;
  const decode = opts.decode ?? decodeImage;
  const warm = opts.warm ?? warmImage;
  const idle = opts.idle ?? defaultIdle;
  const place = opts.placeholder ?? makePlaceholder;
  const now = opts.now ?? (() => globalThis.performance?.now?.() ?? Date.now());
  const ids = Object.keys(manifest.urls) as K[];
  const chapterOf = (id: K) => Math.max(0, Math.floor(manifest.chapters?.[id] ?? 0));
  const jobs = new Map<string, Job>();
  const byId = new Map<K, Job[]>();
  let seq = 0;
  for (const id of ids) {
    const list: Job[] = [];
    const add = (key: string, url: string) => {
      const j: Job = { key, url, chapter: chapterOf(id), pri: 3, seq: seq++, state: 'idle', img: null, at: 0, waiters: [] };
      jobs.set(key, j);
      list.push(j);
    };
    add(id, manifest.urls[id]);
    (manifest.frames?.[id] ?? []).forEach((u, i) => add(`${id}#${i + 1}`, u));
    byId.set(id, list);
  }
  const chapters = [...new Set(ids.map(chapterOf))].sort((a, b) => a - b);
  const started = new Set<number>();
  const finished = new Set<number>();
  const holders = new Map<K, Placeholder>();
  let inflight = 0;
  let scheduled = false;

  // Dev builds only (the whole check is dropped from a production build): a later chapter asked for at boot
  const early = import.meta.env?.DEV && opts.dev !== false ? earlyChapterWatch(opts, () => !chapters.includes(0) || finished.has(0)) : null;

  const select = (what: AssetSelection<K>): Job[] =>
    typeof what === 'number' ? [...jobs.values()].filter((j) => j.chapter === what) : (typeof what === 'string' ? [what as K] : (what as readonly K[])).flatMap((id) => byId.get(id) ?? []);

  const queue = (list: Job[], pri: number) => {
    for (const j of list) {
      if (j.state === 'done' || j.state === 'loading' || j.state === 'failed') continue;
      j.pri = Math.min(j.pri, pri);
      j.state = 'queued';
    }
    pump();
  };

  const settle = (j: Job) => {
    const w = j.waiters.splice(0);
    for (const x of w) (j.state === 'done' ? x.ok() : x.fail(new Error(`@gp/art/assets: the image "${j.key}" could not be decoded`)));
    const ch = j.chapter;
    if (!finished.has(ch) && [...jobs.values()].every((x) => x.chapter !== ch || x.state === 'done' || x.state === 'failed')) {
      finished.add(ch);
      mark(`gp:assets:chapter-${ch}:ready`);
    }
  };

  /** Decoded, waiting for its warm-up draw (one per idle slice: it is the costly part on the main thread) */
  const warmQ: { j: Job; img: HTMLImageElement }[] = [];

  const finish = (j: Job, img: HTMLImageElement | null) => {
    j.img = img;
    j.at = now();
    j.state = img ? 'done' : 'failed';
    inflight--;
    settle(j);
  };

  const start = (j: Job) => {
    j.state = 'loading';
    inflight++;
    if (!started.has(j.chapter)) {
      started.add(j.chapter);
      mark(`gp:assets:chapter-${j.chapter}:start`);
    }
    decode(j.url).then(
      (img) => {
        warmQ.push({ j, img });
        pump();
      },
      () => {
        finish(j, null);
        pump();
      },
    );
  };

  const next = (): Job | undefined => {
    let best: Job | undefined;
    for (const j of jobs.values()) if (j.state === 'queued' && (!best || j.pri < best.pri || (j.pri === best.pri && (j.chapter < best.chapter || (j.chapter === best.chapter && j.seq < best.seq))))) best = j;
    return best;
  };

  function pump() {
    if (scheduled || (!warmQ.length && (inflight >= concurrency || !next()))) return;
    scheduled = true;
    idle((deadline) => {
      scheduled = false;
      // Warm-ups (the most asked-for first): the first-draw decode, done here instead of in a frame — at least one a
      // slice, more while the idle period lasts (before the first screen there is plenty)
      warmQ.sort((a, b) => a.j.pri - b.j.pri || a.j.seq - b.j.seq);
      for (let n = 0; warmQ.length && (n === 0 || deadline.timeRemaining() > idleMs); n++) {
        const { j, img } = warmQ.shift()!;
        try {
          warm(img);
        } catch {
          // a picture that can't be drawn fails when the game draws it, not here
        }
        finish(j, img);
      }
      // Then new decodes (off the main thread): at least one a slice, more while the idle period lasts
      for (let n = 0; inflight < concurrency && (n === 0 || deadline.timeRemaining() > idleMs); n++) {
        const j = next();
        if (!j) break;
        start(j);
      }
      pump();
    });
  }

  const sprite = (id: K): Drawable => {
    const main = byId.get(id)?.[0];
    if (!main) throw new Error(`@gp/art/assets: no image "${id}"`);
    if (main.img) return main.img;
    if (main.state !== 'failed') queue([main], 0);
    let p = holders.get(id);
    if (!p) {
      p = place(manifest.sizes?.[id], manifest.thumbs?.[id]);
      holders.set(id, p);
    }
    return p;
  };

  const img = {} as Record<K, Drawable>;
  for (const id of ids) Object.defineProperty(img, id, { get: () => sprite(id), enumerable: true });

  return {
    img,
    sprite,
    get(id) {
      const s = sprite(id);
      return isPlaceholder(s) ? null : s;
    },
    loaded: (id) => (byId.get(id) ?? []).every((j) => j.state === 'done'),
    frames(id) {
      const [main, ...frames] = byId.get(id) ?? [];
      if (!main) throw new Error(`@gp/art/assets: no image "${id}"`);
      const fallback = sprite(id);
      if (frames.some((f) => !f.img)) queue(frames, 0);
      return frames.map((f) => f.img ?? fallback);
    },
    chapterOf,
    ids: (chapter) => ids.filter((id) => chapterOf(id) === chapter),
    chapters,
    ready(what) {
      const list = select(what);
      early?.('ready', what, list);
      queue(list, 1);
      return Promise.all(
        list.map((j) =>
          j.state === 'done' ? undefined : j.state === 'failed' ? Promise.reject(new Error(`@gp/art/assets: the image "${j.key}" could not be decoded`)) : new Promise<void>((ok, fail) => j.waiters.push({ ok, fail })),
        ),
      ).then(() => undefined);
    },
    prefetch(what) {
      const list = select(what);
      early?.('prefetch', what, list);
      queue(list, 2);
    },
    progress(chapter) {
      const list = [...jobs.values()].filter((j) => chapter === undefined || j.chapter === chapter);
      return { done: list.filter((j) => j.state === 'done').length, total: list.length };
    },
    draw(ctx, id, x, y, height, o = {}) {
      const s = sprite(id);
      const main = byId.get(id)![0]!;
      // An image decoded before it was ever drawn as a placeholder is simply there; one that replaces a placeholder fades in
      const t = isPlaceholder(s) ? 0 : holders.has(id) ? Math.min(1, (now() - main.at) / Math.max(1, fadeMs)) : 1;
      const a = o.alpha ?? 1;
      if (t < 1) {
        const p = holders.get(id);
        if (p) drawImageSprite(ctx, p, x, y, height, { ...o, alpha: a * (1 - t) });
      }
      if (t > 0) drawImageSprite(ctx, s, x, y, height, { ...o, alpha: a * t });
    },
  };
}

/**
 * The frame to draw at time `t` (seconds) at `fps` frames a second: looping, or held on the last one (`loop: false`, an
 * attack or a death played from t = 0). The frames share their sprite's scale, not its bounds (a raised arm makes one
 * taller), so draw each at its own height times one factor, feet down:
 * `const k = 120 / img.hero.naturalHeight; const f = frameAt(frames.hero, t); drawImageSprite(ctx, f, x, y, f.naturalHeight * k, { anchorY: 1 })`.
 * A jump's height, a lunge's reach: move the sprite in code.
 */
export function frameAt<T>(frames: readonly T[], t: number, fps = 8, loop = true): T {
  if (!frames.length) throw new Error('@gp/art/assets: frameAt needs at least one frame');
  const i = Math.floor(Math.max(0, t) * fps);
  return frames[loop ? i % frames.length : Math.min(i, frames.length - 1)]!;
}

/**
 * Pixel art (game.yaml art.technique: pixel): drawn at a whole-number `scale` with smoothing off and snapped to whole
 * pixels, so every art pixel stays a crisp square. (x, y) is the feet (anchorY 1, the default) or the centre (0.5).
 */
export function drawPixelSprite(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement | HTMLCanvasElement,
  x: number,
  y: number,
  scale: number,
  o: { flip?: boolean; alpha?: number; anchorY?: number } = {},
): void {
  const k = Math.max(1, Math.round(scale));
  const w = img.width * k, h = img.height * k;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
  const left = Math.round(x - w / 2), top = Math.round(y - h * (o.anchorY ?? 1));
  if (o.flip) {
    ctx.translate(left + w, top);
    ctx.scale(-1, 1);
    ctx.drawImage(img, 0, 0, w, h);
  } else ctx.drawImage(img, left, top, w, h);
  ctx.restore();
}

/**
 * Draw an image centred at (x, y), `height` px tall (the width follows its aspect), with an optional squash/stretch and
 * rotation — a generated sprite gets the same life as a code-drawn one (breathe, bob, squash from @gp/art/rig).
 */
export function drawImageSprite(
  ctx: CanvasRenderingContext2D,
  img: SizedImage,
  x: number,
  y: number,
  height: number,
  o: { sx?: number; sy?: number; rot?: number; alpha?: number; flip?: boolean; anchorY?: number } = {},
): void {
  const h = height;
  const w = (img.naturalWidth / img.naturalHeight) * h;
  ctx.save();
  ctx.translate(x, y);
  if (o.rot) ctx.rotate(o.rot);
  ctx.scale((o.flip ? -1 : 1) * (o.sx ?? 1), o.sy ?? 1);
  if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
  // anchorY 0.5: centred; 1: the feet at y (a character standing on the ground)
  ctx.drawImage(img, -w / 2, -h * (o.anchorY ?? 0.5), w, h);
  ctx.restore();
}
