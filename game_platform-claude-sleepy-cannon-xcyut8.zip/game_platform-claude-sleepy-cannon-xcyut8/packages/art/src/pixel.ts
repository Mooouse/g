// @gp/art/pixel — pixel art in code, drawn by the rules pixel artists use and checked by them (docs/guides/pixel-art.md).
// A sprite is a grid of palette indices (`PixelArt`), written as rows of letters with a key (the way Candle Crypt and
// Swarm Smash draw theirs). On it: hue-shifted ramps, outlines (plain and selective), volume from one light, ordered
// dithering, clean-up of noise, rotation that keeps the pixels (RotSprite), a model's pseudo-pixels back to its grid
// (depixelize), the craft checks (lintPixelArt: what `gp pixel` reports) and a low-resolution view with whole-pixel
// scaling and a smooth camera (PixelView). Everything but pixelCanvas and PixelView is plain data: it runs in Node too.

import { css, oklab, parse, ramp as colorRamp, shade } from './color.ts';

/** A pixel sprite: w × h palette indices, 0 transparent, i + 1 the colour colors[i] (hex) */
export interface PixelArt {
  readonly w: number;
  readonly h: number;
  readonly px: Uint8Array;
  readonly colors: readonly string[];
}

/** RGBA pixels (ImageData's shape; gp's PNG decoder gives the same) */
export interface RgbaImage {
  w: number;
  h: number;
  d: Uint8ClampedArray;
}

/** Any CSS colour as #rrggbb (alpha dropped: a pixel is there or not) */
export function hex(c: string): string {
  const [r, g, b] = parse(c);
  return css([r, g, b]);
}

const KEYS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&*+-=?@^~';

interface Mutable {
  w: number;
  h: number;
  px: Uint8Array;
  colors: string[];
}

const blank = (w: number, h: number, colors: readonly string[] = []): Mutable => ({ w, h, px: new Uint8Array(w * h), colors: [...colors] });
const copy = (a: PixelArt): Mutable => ({ w: a.w, h: a.h, px: new Uint8Array(a.px), colors: [...a.colors] });
const at = (a: PixelArt, x: number, y: number): number => (x < 0 || y < 0 || x >= a.w || y >= a.h ? 0 : a.px[y * a.w + x]!);

/** The index of a colour in m (added when new); 255 colours at most */
function indexOf(m: Mutable, c: string): number {
  const h = hex(c);
  let i = m.colors.indexOf(h);
  if (i < 0) {
    if (m.colors.length >= 255) throw new Error('@gp/art/pixel: more than 255 colours in one sprite');
    i = m.colors.push(h) - 1;
  }
  return i + 1;
}

/** Drop colours no pixel uses (and renumber) */
function compact(m: Mutable): PixelArt {
  const used = new Set<number>();
  for (const v of m.px) if (v) used.add(v);
  const order = [...used].sort((a, b) => a - b);
  const map = new Map(order.map((v, i) => [v, i + 1]));
  const px = m.px.map((v) => (v ? map.get(v)! : 0));
  return { w: m.w, h: m.h, px, colors: order.map((v) => m.colors[v - 1]!) };
}

// --- Grids ---------------------------------------------------------------------------------------------------------

/**
 * A sprite from rows of letters: each letter a colour of `key`, '.' or ' ' transparent.
 *   pixelArt(['.kk.', 'kffk', '.kk.'], { k: '#1a1020', f: '#ffa033' })
 */
export function pixelArt(rows: readonly string[], key: Readonly<Record<string, string>>): PixelArt {
  const w = Math.max(0, ...rows.map((r) => [...r].length));
  const m = blank(w, rows.length);
  rows.forEach((r, y) =>
    [...r].forEach((ch, x) => {
      if (ch === '.' || ch === ' ') return;
      const c = key[ch];
      if (!c) throw new Error(`@gp/art/pixel: "${ch}" at ${x},${y} is not in the key`);
      m.px[y * w + x] = indexOf(m, c);
    }),
  );
  return m;
}

/** Back to rows of letters and their key (to paste a generated or cleaned sprite into a game's code) */
export function pixelRows(a: PixelArt): { rows: string[]; key: Record<string, string> } {
  if (a.colors.length > KEYS.length) throw new Error(`@gp/art/pixel: ${a.colors.length} colours — at most ${KEYS.length} have a letter`);
  const rows: string[] = [];
  for (let y = 0; y < a.h; y++) {
    let r = '';
    for (let x = 0; x < a.w; x++) {
      const v = a.px[y * a.w + x]!;
      r += v ? KEYS[v - 1] : '.';
    }
    rows.push(r);
  }
  return { rows, key: Object.fromEntries(a.colors.map((c, i) => [KEYS[i]!, c])) };
}

/** OKLab distance (≈ 0.02 is the smallest step a player sees between two flat colours) */
function dist(a: string, b: string): number {
  const [l1, a1, b1] = oklab(a);
  const [l2, a2, b2] = oklab(b);
  return Math.hypot(l1 - l2, a1 - a2, b1 - b2);
}

function nearestOf(palette: readonly string[]): (r: number, g: number, b: number) => string {
  const labs = palette.map((c) => [hex(c), oklab(c)] as const);
  const cache = new Map<number, string>();
  return (r, g, b) => {
    const k = (r << 16) | (g << 8) | b;
    let out = cache.get(k);
    if (out) return out;
    const [L, A, B] = oklab(css([r, g, b]));
    let best = Infinity;
    for (const [h, [l2, a2, b2]] of labs) {
      const d = (L - l2) ** 2 + (A - a2) ** 2 + (B - b2) ** 2;
      if (d < best) { best = d; out = h; }
    }
    cache.set(k, out!);
    return out!;
  };
}

/** A sprite from RGBA pixels: a pixel is there when its alpha ≥ `alpha`; with a palette, each colour snaps to it */
export function pixelFromRgba(im: RgbaImage, o: { palette?: readonly string[]; alpha?: number } = {}): PixelArt {
  const cut = o.alpha ?? 128;
  const snap = o.palette?.length ? nearestOf(o.palette) : null;
  const m = blank(im.w, im.h);
  const idx = new Map<string, number>();
  for (let i = 0; i < im.w * im.h; i++) {
    const d = im.d;
    if (d[i * 4 + 3]! < cut) continue;
    const c = snap ? snap(d[i * 4]!, d[i * 4 + 1]!, d[i * 4 + 2]!) : css([d[i * 4]!, d[i * 4 + 1]!, d[i * 4 + 2]!]);
    let v = idx.get(c);
    if (v === undefined) {
      if (m.colors.length >= 255) throw new Error('@gp/art/pixel: more than 255 colours — not pixel art yet: depixelize() it, or give a palette');
      v = m.colors.push(c);
      idx.set(c, v);
    }
    m.px[i] = v;
  }
  return m;
}

/** RGBA pixels of a sprite, each art pixel `scale` × `scale` */
export function pixelToRgba(a: PixelArt, scale = 1): RgbaImage {
  const k = Math.max(1, Math.round(scale));
  const w = a.w * k, h = a.h * k;
  const d = new Uint8ClampedArray(w * h * 4);
  const rgb = a.colors.map((c) => parse(c));
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const v = a.px[Math.floor(y / k) * a.w + Math.floor(x / k)]!;
      if (!v) continue;
      const [r, g, b] = rgb[v - 1]!;
      const j = (y * w + x) * 4;
      d[j] = r; d[j + 1] = g; d[j + 2] = b; d[j + 3] = 255;
    }
  return { w, h, d };
}

/** A canvas of the sprite at `scale` (browser): draw it with drawPixelSprite (@gp/art/assets), smoothing off */
export function pixelCanvas(a: PixelArt, scale = 1): HTMLCanvasElement {
  const im = pixelToRgba(a, scale);
  const c = document.createElement('canvas');
  c.width = im.w;
  c.height = im.h;
  if (im.w && im.h) c.getContext('2d')!.putImageData(new ImageData(new Uint8ClampedArray(im.d), im.w, im.h), 0, 0);
  return c;
}

/** The sprite cut to its pixels, and where its top-left was */
export function pixelTrim(a: PixelArt): { art: PixelArt; x: number; y: number } {
  let x0 = a.w, y0 = a.h, x1 = -1, y1 = -1;
  for (let y = 0; y < a.h; y++) for (let x = 0; x < a.w; x++) if (a.px[y * a.w + x]) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  if (x1 < 0) return { art: blank(0, 0), x: 0, y: 0 };
  const m = blank(x1 - x0 + 1, y1 - y0 + 1, a.colors);
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) m.px[y * m.w + x] = a.px[(y + y0) * a.w + x + x0]!;
  return { art: compact(m), x: x0, y: y0 };
}

/** Mirrored left to right (a sprite facing the other way) */
export function pixelMirror(a: PixelArt): PixelArt {
  const m = blank(a.w, a.h, a.colors);
  for (let y = 0; y < a.h; y++) for (let x = 0; x < a.w; x++) m.px[y * a.w + x] = a.px[y * a.w + a.w - 1 - x]!;
  return m;
}

/** Every pixel one colour: the silhouette test (does it read in one colour?) and the hit flash (white) */
export function pixelFlat(a: PixelArt, color = '#ffffff'): PixelArt {
  return { w: a.w, h: a.h, px: a.px.map((v) => (v ? 1 : 0)), colors: [hex(color)] };
}

/** Each colour as its grey of the same lightness: the value test (do the ramps still carry the form?) */
export function pixelValues(a: PixelArt): PixelArt {
  return { ...a, colors: a.colors.map((c) => { const v = Math.round(Math.max(0, Math.min(1, oklab(c)[0])) ** 3 * 255); return css([v, v, v]); }) };
}

/** One sprite drawn onto another at (x, y): transparent pixels of `top` leave `base` as it is */
export function pixelStamp(base: PixelArt, top: PixelArt, x: number, y: number): PixelArt {
  const m = copy(base);
  for (let j = 0; j < top.h; j++)
    for (let i = 0; i < top.w; i++) {
      const v = top.px[j * top.w + i]!;
      const X = x + i, Y = y + j;
      if (!v || X < 0 || Y < 0 || X >= m.w || Y >= m.h) continue;
      m.px[Y * m.w + X] = indexOf(m, top.colors[v - 1]!);
    }
  return compact(m);
}

// --- Colour ----------------------------------------------------------------------------------------------------------

/**
 * A pixel-art ramp of `steps` colours from shadow to light, the base in the middle: the shadows turn cool (toward
 * blue-violet), the lights warm (toward yellow), the saturation peaks in the mid-tones — never a ramp that only
 * darkens toward black. 3–5 steps per material read at 16–48 px; `hueShift` 0 gives plain lightness steps.
 */
export function pixelRamp(base: string, steps = 5, o: { hueShift?: number; spread?: number } = {}): string[] {
  const out: string[] = [];
  for (const c of colorRamp(base, steps, o.spread ?? 0.85, o.hueShift ?? 1)) {
    const h = hex(c);
    if (!out.length || dist(out[out.length - 1]!, h) >= 0.02) out.push(h);
  }
  return out;
}

// --- Outline, volume, dithering ----------------------------------------------------------------------------------

const N4 = [[1, 0], [-1, 0], [0, 1], [0, -1]] as const;
const N8 = [...N4, [1, 1], [1, -1], [-1, 1], [-1, -1]] as const;

export interface OutlineOptions {
  /** The line's colour (default: the sprite's darkest colour pushed toward a cool near-black — never pure #000) */
  color?: string;
  /** Selective outline: each line pixel a dark shade of the fill it borders, lighter on the lit side (soft, painterly) */
  selout?: boolean;
  /** Where the light comes from (default top-left: [-1, -1]) — selout's lit side */
  light?: readonly [number, number];
  /** Also the diagonal corners (a squarer line; default false: rounder) */
  corners?: boolean;
  /** Grow the grid by one pixel on every side so the line fits (default true) */
  pad?: boolean;
}

/** A 1-pixel outline around the sprite's shape, outside it (the drawing keeps every pixel) */
export function pixelOutline(a: PixelArt, o: OutlineOptions = {}): PixelArt {
  const p = o.pad === false ? 0 : 1;
  const m = blank(a.w + 2 * p, a.h + 2 * p, a.colors);
  for (let y = 0; y < a.h; y++) for (let x = 0; x < a.w; x++) m.px[(y + p) * m.w + x + p] = a.px[y * a.w + x]!;
  const src = { ...m, px: new Uint8Array(m.px) } as PixelArt;
  const darkest = a.colors.reduce((d, c) => (oklab(c)[0] < oklab(d)[0] ? c : d), a.colors[0] ?? '#000000');
  const line = o.color ? hex(o.color) : hex(shade(darkest, -0.75));
  const [lx, ly] = o.light ?? [-1, -1];
  const nb = o.corners ? N8 : N4;
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      if (src.px[y * m.w + x]) continue;
      let fill = 0, fx = 0, fy = 0;
      for (const [dx, dy] of nb) {
        const v = at(src, x + dx, y + dy);
        if (v) { fill = v; fx = dx; fy = dy; if (Math.abs(dx) + Math.abs(dy) === 1) break; }
      }
      if (!fill) continue;
      if (!o.selout) { m.px[y * m.w + x] = indexOf(m, line); continue; }
      // The line pixel sits on the side of the fill opposite (fx, fy): lit when that side faces the light
      const lit = -fx * lx + -fy * ly > 0;
      m.px[y * m.w + x] = indexOf(m, shade(src.colors[fill - 1]!, lit ? -0.45 : -0.85));
    }
  return compact(m);
}

/** Steps from the edge inward (4-connected chamfer distance), 0 outside */
function edgeDistance(a: PixelArt): Float32Array {
  const d = new Float32Array(a.w * a.h);
  const big = a.w + a.h;
  for (let i = 0; i < d.length; i++) d[i] = a.px[i] ? big : 0;
  const get = (x: number, y: number) => (x < 0 || y < 0 || x >= a.w || y >= a.h ? 0 : d[y * a.w + x]!);
  for (let y = 0; y < a.h; y++) for (let x = 0; x < a.w; x++) if (d[y * a.w + x]) d[y * a.w + x] = Math.min(d[y * a.w + x]!, get(x - 1, y) + 1, get(x, y - 1) + 1);
  for (let y = a.h - 1; y >= 0; y--) for (let x = a.w - 1; x >= 0; x--) if (d[y * a.w + x]) d[y * a.w + x] = Math.min(d[y * a.w + x]!, get(x + 1, y) + 1, get(x, y + 1) + 1);
  return d;
}

export interface ShadeOptions {
  /** Where the light comes from (default top-left: [-1, -1]); one light for the whole game */
  light?: readonly [number, number];
  /** Ramp steps per colour (default 5: two shadows, the base, a light, a highlight) */
  steps?: number;
  /** Put the brightest step on the few pixels that face the light most (default true) */
  highlight?: boolean;
  /** Leave these colours as they are (the outline, eyes, glints) */
  keep?: readonly string[];
}

/**
 * Volume for a flat drawing: each colour becomes its own ramp, lit from one side. The light side of the whole shape
 * is lighter and the far side darker (not a ring of shadow along every edge — that is pillow shading).
 * Draw the shapes flat, one colour per material, then shade; look at it and fix by hand what reads wrong.
 */
export function pixelShade(a: PixelArt, o: ShadeOptions = {}): PixelArt {
  const [lx0, ly0] = o.light ?? [-1, -1];
  const ll = Math.hypot(lx0, ly0) || 1;
  const lx = lx0 / ll, ly = ly0 / ll;
  const steps = Math.max(3, o.steps ?? 5);
  const mid = Math.floor((steps - 1) / 2);
  const keep = new Set((o.keep ?? []).map(hex));
  const ramps = a.colors.map((c) => (keep.has(c) ? [c] : colorRamp(c, steps, 0.8, 1).map(hex)));
  const d = edgeDistance(a);
  let n = 0, cx = 0, cy = 0;
  for (let y = 0; y < a.h; y++) for (let x = 0; x < a.w; x++) if (a.px[y * a.w + x]) { n++; cx += x; cy += y; }
  if (!n) return a;
  cx /= n; cy /= n;
  const R = Math.max(1, Math.sqrt(n / Math.PI));
  const depth = Math.max(2, R / 2);
  const m = copy(a);
  const D = (x: number, y: number) => (x < 0 || y < 0 || x >= a.w || y >= a.h ? 0 : d[y * a.w + x]!);
  for (let y = 0; y < a.h; y++)
    for (let x = 0; x < a.w; x++) {
      const v = a.px[y * a.w + x]!;
      if (!v || keep.has(a.colors[v - 1]!)) continue;
      // The form as a whole (where the pixel sits toward the light) and its edge (which way the surface turns there)
      const rx = (x - cx) / R, ry = (y - cy) / R;
      const gx = (D(x + 1, y) - D(x - 1, y)) / 2, gy = (D(x, y + 1) - D(x, y - 1)) / 2;
      const gl = Math.hypot(gx, gy);
      const edge = gl ? (-(gx * lx + gy * ly) / gl) * Math.max(0, 1 - (d[y * a.w + x]! - 1) / depth) : 0;
      const b = 0.75 * (rx * lx + ry * ly) + 0.45 * edge;
      const ramp = ramps[v - 1]!;
      if (ramp.length === 1) continue;
      const s = (o.highlight ?? true) && b > 0.85 && edge > 0.3 ? 2 : b > 0.35 ? 1 : b < -0.55 ? -2 : b < -0.15 ? -1 : 0;
      const i = Math.max(0, Math.min(ramp.length - 1, mid + s));
      m.px[y * a.w + x] = indexOf(m, ramp[i]!);
    }
  return compact(m);
}

/** The 4 × 4 ordered (Bayer) dither thresholds, 0…15 */
export const BAYER4: readonly (readonly number[])[] = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5],
];

/**
 * Ordered dithering between two colours: `t(x, y)` says how much of `b` (0…1) — or null to leave the pixel. `levels`
 * rounds t first (default 3: a, a 50 % checker, b — the classic look; dithering at more levels than that reads as noise
 * at play size). Use it for large soft areas (sky, fog, a big glow), not on small sprites.
 */
export function pixelDither(a: PixelArt, colorA: string, colorB: string, t: (x: number, y: number) => number | null, levels = 3): PixelArt {
  const m = copy(a);
  const ia = indexOf(m, colorA), ib = indexOf(m, colorB);
  const q = Math.max(2, levels) - 1;
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      const v = t(x, y);
      if (v === null) continue;
      const k = Math.round(Math.max(0, Math.min(1, v)) * q) / q;
      m.px[y * m.w + x] = k * 16 > BAYER4[y & 3]![x & 3]! ? ib : ia;
    }
  return compact(m);
}

// --- Clean-up, scaling, rotation ---------------------------------------------------------------------------------

/** Noise: a pixel whose 8 neighbours are all something else, most of them one close colour (not a detail: an eye differs a lot) */
function noiseAt(a: PixelArt, x: number, y: number, contrast: number): number {
  const v = a.px[y * a.w + x]!;
  if (!v) return 0;
  const votes = new Map<number, number>();
  for (const [dx, dy] of N8) {
    const u = at(a, x + dx, y + dy);
    if (u === v) return 0;
    votes.set(u, (votes.get(u) ?? 0) + 1);
  }
  let best = 0, n = 0;
  for (const [u, c] of votes) if (c > n) { best = u; n = c; }
  if (!best || n < 5) return 0;
  return dist(a.colors[v - 1]!, a.colors[best - 1]!) < contrast ? best : 0;
}

/**
 * Noise out, near-twins merged: a stray pixel of a close shade inside a cluster takes the cluster's colour (details
 * with real contrast — eyes, glints — stay), and colours a player can't tell apart become one. The usual first pass on
 * a model's or a scaler's output.
 */
export function pixelCleanup(a: PixelArt, o: { contrast?: number; merge?: number } = {}): { art: PixelArt; fixed: number; merged: number } {
  const m = copy(a);
  // Near-twin colours: each into the more common one
  const count = new Array(m.colors.length + 1).fill(0) as number[];
  for (const v of m.px) count[v]!++;
  const into = m.colors.map((_, i) => i + 1);
  let merged = 0;
  const order = m.colors.map((_, i) => i + 1).sort((p, q) => count[q]! - count[p]!);
  for (let i = 0; i < order.length; i++)
    for (let j = i + 1; j < order.length; j++) {
      const p = order[i]!, q = order[j]!;
      if (into[q - 1] !== q || into[p - 1] !== p) continue;
      if (dist(m.colors[p - 1]!, m.colors[q - 1]!) < (o.merge ?? 0.02)) { into[q - 1] = p; merged++; }
    }
  for (let i = 0; i < m.px.length; i++) if (m.px[i]) m.px[i] = into[m.px[i]! - 1]!;
  const snapshot = { ...m, px: new Uint8Array(m.px) } as PixelArt;
  let fixed = 0;
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      const u = noiseAt(snapshot, x, y, o.contrast ?? 0.08);
      if (u) { m.px[y * m.w + x] = u; fixed++; }
    }
  return { art: compact(m), fixed, merged };
}

/**
 * A 2-px outline thinned to 1 px: the line's inner layer takes a dark shade of the fill it touches (picked from the
 * sprite's own colours, so no new colour comes in). The fix for a small sprite scaled up 2× (P_THICK_OUTLINE).
 */
export function pixelThinOutline(a: PixelArt): PixelArt {
  const lights = a.colors.map(L);
  const minL = Math.min(...lights);
  const dark = (v: number) => v > 0 && lights[v - 1]! <= minL + 0.12;
  const outer = (x: number, y: number) => N4.some(([dx, dy]) => !at(a, x + dx, y + dy));
  const m = copy(a);
  for (let y = 0; y < a.h; y++)
    for (let x = 0; x < a.w; x++) {
      const v = a.px[y * a.w + x]!;
      if (!dark(v) || outer(x, y)) continue;
      // Inner layer: next to the outer line on one side and to fill on another
      if (!N4.some(([dx, dy]) => dark(at(a, x + dx, y + dy)) && outer(x + dx, y + dy))) continue;
      const fills = N8.map(([dx, dy]) => at(a, x + dx, y + dy)).filter((u) => u && !dark(u));
      if (!fills.length) continue;
      const votes = new Map<number, number>();
      for (const u of fills) votes.set(u, (votes.get(u) ?? 0) + 1);
      const fill = [...votes.entries()].sort((p, q) => q[1] - p[1])[0]![0];
      // The sprite's colour nearest to a shadow of that fill, never the line colour itself
      const want = shade(a.colors[fill - 1]!, -0.45);
      let best = fill, bd = Infinity;
      a.colors.forEach((c, i) => { if (dark(i + 1)) return; const d = dist(c, want); if (d < bd) { bd = d; best = i + 1; } });
      m.px[y * a.w + x] = best;
    }
  return compact(m);
}

/** Scale2x (EPX): twice the size, the stairs smoothed, no new colour */
export function pixelScale2x(a: PixelArt): PixelArt {
  const m = blank(a.w * 2, a.h * 2, a.colors);
  for (let y = 0; y < a.h; y++)
    for (let x = 0; x < a.w; x++) {
      const P = at(a, x, y), A = at(a, x, y - 1), B = at(a, x + 1, y), C = at(a, x - 1, y), D = at(a, x, y + 1);
      const ok = C !== B && A !== D;
      const o = [ok && C === A ? A : P, ok && A === B ? B : P, ok && D === C ? C : P, ok && B === D ? D : P];
      m.px[2 * y * m.w + 2 * x] = o[0]!;
      m.px[2 * y * m.w + 2 * x + 1] = o[1]!;
      m.px[(2 * y + 1) * m.w + 2 * x] = o[2]!;
      m.px[(2 * y + 1) * m.w + 2 * x + 1] = o[3]!;
    }
  return m;
}

/** k times smaller: each cell's most common pixel (transparent counts) — an upscaled sprite back to its own grid */
export function pixelDownscale(a: PixelArt, k: number): PixelArt {
  const f = Math.max(1, Math.round(k));
  const m = blank(Math.ceil(a.w / f), Math.ceil(a.h / f), a.colors);
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      const votes = new Map<number, number>();
      for (let j = 0; j < f; j++) for (let i = 0; i < f; i++) { const v = at(a, x * f + i, y * f + j); votes.set(v, (votes.get(v) ?? 0) + 1); }
      // Ties go to the cell's centre pixel
      const centre = at(a, x * f + (f >> 1), y * f + (f >> 1));
      let best = centre, n = votes.get(centre) ?? 0;
      for (const [v, c] of votes) if (c > n) { best = v; n = c; }
      m.px[y * m.w + x] = best;
    }
  return compact(m);
}

/**
 * Rotated by `angle` radians with the pixels kept (RotSprite): 8× up with Scale2x three times, turned with nearest
 * sampling, then back down — each pixel the most common of its 8 × 8 cell. No blur and no new colour, the lines stay
 * one pixel wide. The result is centred on the sprite's centre and big enough for any angle; make the angles once at
 * load (pixelRotations), never per frame.
 */
export function rotSprite(a: PixelArt, angle: number): PixelArt {
  const big = pixelScale2x(pixelScale2x(pixelScale2x(a)));
  const cos = Math.cos(angle), sin = Math.sin(angle);
  const side = Math.ceil(Math.hypot(a.w, a.h)) | 1;
  const W = side * 8;
  const cx = big.w / 2, cy = big.h / 2;
  const turned = blank(W, W, big.colors);
  for (let y = 0; y < W; y++)
    for (let x = 0; x < W; x++) {
      const dx = x + 0.5 - W / 2, dy = y + 0.5 - W / 2;
      const sx = Math.floor(cos * dx + sin * dy + cx), sy = Math.floor(-sin * dx + cos * dy + cy);
      turned.px[y * W + x] = at(big, sx, sy);
    }
  return pixelDownscale(turned, 8);
}

/** The sprite at n angles round the circle (0, 2π/n, …), made once: a weapon, a ship, a projectile aimed anywhere */
export function pixelRotations(a: PixelArt, n = 16): PixelArt[] {
  return Array.from({ length: n }, (_, i) => rotSprite(a, (i * 2 * Math.PI) / n));
}

// --- A model's picture back to its pixels ------------------------------------------------------------------------

/** Where colour changes along one axis, counted over the whole image */
function edgeHistogram(im: RgbaImage, axis: 'x' | 'y'): Float64Array {
  const n = axis === 'x' ? im.w : im.h;
  const out = new Float64Array(n);
  const d = im.d;
  for (let y = axis === 'y' ? 1 : 0; y < im.h; y++)
    for (let x = axis === 'x' ? 1 : 0; x < im.w; x++) {
      const i = (y * im.w + x) * 4, j = axis === 'x' ? i - 4 : i - im.w * 4;
      const diff = Math.abs(d[i]! - d[j]!) + Math.abs(d[i + 1]! - d[j + 1]!) + Math.abs(d[i + 2]! - d[j + 2]!) + Math.abs(d[i + 3]! - d[j + 3]!);
      if (diff > 60) out[axis === 'x' ? x : y]! += 1;
    }
  return out;
}

function pitchOf(hist: Float64Array, maxPitch: number): { pitch: number; phase: number; score: number } {
  let total = 0;
  for (const v of hist) total += v;
  if (!total) return { pitch: 1, phase: 0, score: 0 };
  const scores: { p: number; s: number; ph: number }[] = [];
  for (let p = 2; p <= maxPitch; p += 0.02) {
    let re = 0, im = 0;
    for (let x = 0; x < hist.length; x++) {
      const v = hist[x]!;
      if (!v) continue;
      const t = (2 * Math.PI * x) / p;
      re += v * Math.cos(t);
      im += v * Math.sin(t);
    }
    const s = Math.hypot(re, im) / total;
    scores.push({ p, s, ph: (((Math.atan2(im, re) / (2 * Math.PI)) * p) % p + p) % p });
  }
  const best = Math.max(...scores.map((x) => x.s));
  if (best < 0.55) return { pitch: 1, phase: 0, score: best };
  // Half, a third … of the true pitch score as well as it does: the largest pitch that scores near the best is the grid
  const pick = scores.filter((x) => x.s >= best * 0.88).reduce((a, b) => (b.p > a.p ? b : a));
  // Refine around the pick (local maximum)
  const local = scores.filter((x) => Math.abs(x.p - pick.p) < 0.3).reduce((a, b) => (b.s > a.s ? b : a));
  return { pitch: local.p, phase: local.ph, score: local.s };
}

/**
 * The size of a picture's own pixels. A model draws "pixel art" as big blocks (pseudo-pixels) of a pitch of its own —
 * 1024 px with 21.3 px blocks is a 48 px sprite. Found from where the colour changes along each axis; pitch 1 means
 * no block grid was found (real pixels, or a picture that isn't pixel art).
 */
export function detectPixelPitch(im: RgbaImage, maxPitch = 64): { x: number; y: number; ox: number; oy: number; score: number } {
  const px = pitchOf(edgeHistogram(im, 'x'), Math.min(maxPitch, im.w / 4));
  const py = pitchOf(edgeHistogram(im, 'y'), Math.min(maxPitch, im.h / 4));
  // Square pixels: when one axis found a grid and the other is close or missing, use one pitch for both
  let x = px.pitch, y = py.pitch;
  if (x > 1 && y > 1 && Math.abs(x - y) / Math.max(x, y) < 0.12) x = y = (x * px.score + y * py.score) / (px.score + py.score);
  else if (x > 1 && y === 1) y = x;
  else if (y > 1 && x === 1) x = y;
  return { x, y, ox: px.phase, oy: py.phase, score: Math.min(px.score || py.score, py.score || px.score) };
}

/**
 * A model's pseudo-pixel picture back to real pixels: the block grid found (detectPixelPitch), each block read from
 * its middle (its most common colour — the blurred block edges ignored), snapped to the palette, cleaned of noise.
 * No grid found: the picture is cut into `fallback`-px cells the same way (a guess — say so).
 */
export function depixelize(im: RgbaImage, o: { palette?: readonly string[]; alpha?: number; fallback?: number } = {}): { art: PixelArt; pitch: number; found: boolean } {
  const g = detectPixelPitch(im);
  const found = g.x > 1;
  const px = found ? g.x : Math.max(1, o.fallback ?? 1);
  const py = found ? g.y : px;
  const ox = found ? g.ox : 0, oy = found ? g.oy : 0;
  const x0 = ox - Math.ceil(ox / px) * px, y0 = oy - Math.ceil(oy / py) * py;
  const cols = Math.ceil((im.w - x0) / px), rows = Math.ceil((im.h - y0) / py);
  const snap = o.palette?.length ? nearestOf(o.palette) : null;
  const cut = o.alpha ?? 128;
  const m = blank(cols, rows);
  for (let cy = 0; cy < rows; cy++)
    for (let cx = 0; cx < cols; cx++) {
      // The middle half of the block
      const a0 = x0 + cx * px + px * 0.25, a1 = x0 + cx * px + px * 0.75;
      const b0 = y0 + cy * py + py * 0.25, b1 = y0 + cy * py + py * 0.75;
      const votes = new Map<string, number>();
      let solid = 0, all = 0;
      for (let y = Math.max(0, Math.floor(b0)); y < Math.min(im.h, Math.ceil(b1)); y++)
        for (let x = Math.max(0, Math.floor(a0)); x < Math.min(im.w, Math.ceil(a1)); x++) {
          const i = (y * im.w + x) * 4;
          all++;
          if (im.d[i + 3]! < cut) continue;
          solid++;
          // Bucket by 4 bits a channel so a block's slight noise votes together; the bucket's colour is snapped below
          const r = im.d[i]!, gg = im.d[i + 1]!, b = im.d[i + 2]!;
          const k = snap ? snap(r, gg, b) : css([(r >> 3) * 8 + 4, (gg >> 3) * 8 + 4, (b >> 3) * 8 + 4]);
          votes.set(k, (votes.get(k) ?? 0) + 1);
        }
      if (!all || solid * 2 < all) continue;
      let best = '', n = 0;
      for (const [k, c] of votes) if (c > n) { best = k; n = c; }
      m.px[cy * cols + cx] = indexOf(m, best);
    }
  const clean = pixelCleanup(m, { merge: snap ? 0 : 0.03 });
  return { art: pixelTrim(clean.art).art, pitch: px, found };
}

// --- The craft checks ----------------------------------------------------------------------------------------------

export interface PixelIssue {
  code: string;
  severity: 'warning' | 'info';
  message: string;
  fix: string;
  /** Up to 24 pixels where it shows (x, y) */
  at?: [number, number][];
}

export interface PixelStats {
  w: number;
  h: number;
  colors: number;
  opaque: number;
  /** OKLab lightness range of the colours used (0…1) */
  values: number;
  /** Share of the silhouette's edge pixels in the outline colour */
  outline: number;
  /** Share of the outline's edge pixels with more line behind them (near 1: a 2-px outline) */
  thick: number;
  noise: number;
  doubles: number;
  bumps: number;
  /** Share of fill pixels with no 4-neighbour of their colour */
  singles: number;
  /** Lightness against depth (distance to the edge): near 1 and no direction is pillow shading */
  pillow: number;
  /** k > 1: every pixel is a k × k block (drawn k times too big) */
  upscaled: number;
  /** Where the light comes from, degrees (0 from the right, 90 from below, −90 from above, ±180 from the left — screen y
   *  down); null when the shading shows no direction */
  light: number | null;
}

export interface LintOptions {
  /** The colour behind the sprite in play (the contrast check) */
  background?: string;
  /** Most colours one sprite should use (default 16 up to 64 px, 32 bigger) */
  maxColors?: number;
  /** A tile or a background: no outline and no silhouette expected */
  tile?: boolean;
}

const L = (c: string) => oklab(c)[0];
/** A stray pixel this close to its surroundings (OKLab) is noise; a ramp step (≈ 0.08–0.15) placed alone is texture */
const NOISE = 0.06;
const cap = (xs: [number, number][]) => xs.slice(0, 24);

/** The largest k such that every pixel is a k × k block aligned to the grid (2…8), else 1 */
function blockScale(a: PixelArt): number {
  for (let k = 8; k >= 2; k--) {
    if (a.w % k || a.h % k || a.w / k < 2 || a.h / k < 2) continue;
    let ok = true;
    for (let y = 0; y < a.h && ok; y++) for (let x = 0; x < a.w && ok; x++) if (a.px[y * a.w + x] !== a.px[(y - (y % k)) * a.w + x - (x % k)]) ok = false;
    if (ok) return k;
  }
  return 1;
}

/**
 * The craft rules, checked on the grid — what a pixel artist looks for first: too many or near-twin colours, noise and
 * pixels without a cluster, a broken outline, doubled corners on lines, one-pixel bumps on the silhouette, no value
 * range, pillow shading, a sprite drawn at 2× next to 1× art (mixels), a silhouette lost against the background.
 * Each issue says what to do; warnings are what a player sees at play size, info is a style question.
 */
export function lintPixelArt(a: PixelArt, o: LintOptions = {}): { issues: PixelIssue[]; stats: PixelStats } {
  const issues: PixelIssue[] = [];
  const used = [...new Set(a.px)].filter((v) => v).map((v) => a.colors[v - 1]!);
  let opaque = 0;
  for (const v of a.px) if (v) opaque++;
  const stats: PixelStats = { w: a.w, h: a.h, colors: used.length, opaque, values: 0, outline: 0, thick: 0, noise: 0, doubles: 0, bumps: 0, singles: 0, pillow: 0, upscaled: 1, light: null };
  if (!opaque) return { issues, stats };
  const lights = used.map(L);
  stats.values = Math.max(...lights) - Math.min(...lights);

  // Mixels: drawn k times too big
  stats.upscaled = blockScale(a);
  if (stats.upscaled > 1)
    issues.push({ code: 'P_UPSCALED', severity: 'warning', message: `every pixel is a ${stats.upscaled}×${stats.upscaled} block: the sprite is drawn ${stats.upscaled}× too big, and next to 1× art its pixels are bigger than the rest (mixels)`, fix: `Shrink it to its own grid (pixelDownscale(art, ${stats.upscaled})) and draw it at the game's one pixel scale; one pixel size for the whole game.` });

  // Colours
  const maxColors = o.maxColors ?? (Math.max(a.w, a.h) <= 64 ? 16 : 32);
  if (used.length > maxColors)
    issues.push({ code: 'P_COLORS', severity: 'warning', message: `${used.length} colours (at most ${maxColors} for a sprite this size)`, fix: 'Pick 3–5 steps per material from one palette (pixelRamp) and snap the rest to it: fewer colours read cleaner and tie the set together.' });
  const twins: string[] = [];
  for (let i = 0; i < used.length; i++) for (let j = i + 1; j < used.length; j++) if (dist(used[i]!, used[j]!) < 0.025) twins.push(`${used[i]} ≈ ${used[j]}`);
  if (twins.length)
    issues.push({ code: 'P_NEAR_COLORS', severity: 'warning', message: `${twins.length} pair(s) of colours a player can't tell apart: ${twins.slice(0, 4).join(', ')}`, fix: 'Merge each pair into one (pixelCleanup merges them): two near-identical shades are noise, not detail.' });

  // The edge and the outline
  const edge: [number, number][] = [];
  for (let y = 0; y < a.h; y++)
    for (let x = 0; x < a.w; x++)
      if (a.px[y * a.w + x] && N4.some(([dx, dy]) => !at(a, x + dx, y + dy))) edge.push([x, y]);
  const minL = Math.min(...lights);
  const dark = (v: number) => v > 0 && L(a.colors[v - 1]!) <= minL + 0.12;
  const darkEdge = edge.filter(([x, y]) => dark(a.px[y * a.w + x]!));
  stats.outline = edge.length ? darkEdge.length / edge.length : 0;
  const lined = stats.outline >= 0.8;
  if (!o.tile && Math.max(a.w, a.h) >= 8) {
    if (stats.outline > 0.4 && stats.outline < 0.72) {
      const gaps = edge.filter(([x, y]) => !dark(a.px[y * a.w + x]!));
      issues.push({ code: 'P_OUTLINE_BROKEN', severity: 'warning', message: `the outline covers ${Math.round(stats.outline * 100)} % of the silhouette's edge: a line with gaps reads as a mistake`, fix: 'Close the line all round (pixelOutline), or leave it open on purpose — a glowing part, the lit side (selout: pixelOutline({ selout: true })) — never at random.', at: cap(gaps) });
    } else if (stats.outline <= 0.35 && o.background === undefined)
      issues.push({ code: 'P_NO_OUTLINE', severity: 'info', message: 'no outline: the silhouette relies on its colours against the background', fix: 'Fine on a calm background; over a busy one a 1-pixel dark line or a selective outline keeps the sprite readable.' });
  }

  // A thick line: behind most edge pixels (away from the outside) the line goes on — a 2-px outline, the usual mark of
  // a 16 px sprite scaled to 32 (the line should stay 1 px at any size)
  let behind = 0;
  for (const [x, y] of darkEdge)
    for (const [dx, dy] of N4)
      if (!at(a, x + dx, y + dy)) { if (dark(at(a, x - dx, y - dy))) behind++; break; }
  stats.thick = darkEdge.length ? behind / darkEdge.length : 0;
  const thick = lined && stats.thick > 0.6 && Math.max(a.w, a.h) >= 20;
  if (thick)
    issues.push({ code: 'P_THICK_OUTLINE', severity: 'warning', message: `the outline is 2 px thick (${Math.round(stats.thick * 100)} % of the edge): heavy and blocky next to 1-px detail — what a 2× scale of a small sprite does`, fix: 'Thin it to 1 px (pixelThinOutline: the outer pixel stays, the inner one becomes a dark shade of the fill), or redraw at the new size (gp art redraw).' });

  // Doubles: an L-corner on a one-pixel line whose arms are single pixels (a staircase, not a square corner). At
  // 16 px every pixel is a decision: lines are checked from 24 px up
  const isLine = (x: number, y: number) => { const v = at(a, x, y); return lined && dark(v); };
  const doubles: [number, number][] = [];
  if (lined && !thick && Math.max(a.w, a.h) >= 24)
    for (const [x, y] of darkEdge)
      for (const [hx, vy] of [[1, 1], [1, -1], [-1, 1], [-1, -1]] as const) {
        if (!isLine(x + hx, y) || !isLine(x, y + vy) || isLine(x + hx, y + vy)) continue;
        // A thick line (the pixel opposite the corner is line too) is not a doubled one-pixel line
        if (isLine(x - hx, y) && isLine(x, y - vy)) continue;
        // Both arms a single pixel (each goes on diagonally): a diagonal drawn in L-steps. A run turning into a
        // diagonal (one long arm) is a corner an artist may keep
        const shortH = !isLine(x + 2 * hx, y), shortV = !isLine(x, y + 2 * vy);
        if (shortH && shortV) { doubles.push([x, y]); break; }
      }
  stats.doubles = doubles.length;
  if (doubles.length >= 3 && doubles.length > darkEdge.length * 0.05)
    issues.push({ code: 'P_DOUBLES', severity: 'warning', message: `${doubles.length} doubled corners on the outline: the line steps through an extra pixel, so it looks thick and jagged`, fix: 'Make lines pixel-perfect: each step joins the next at a corner (diagonally), never through an L of three pixels; keep the step lengths regular (1-1, 2-1, 2-2 …).', at: cap(doubles) });

  // Bumps: a one-pixel notch on the silhouette's profile (left, right, top, bottom)
  const bumps: [number, number][] = [];
  const profile = (n: number, get: (i: number) => number | null, toXY: (i: number, v: number) => [number, number]) => {
    for (let i = 1; i < n - 1; i++) {
      const p = get(i - 1), c = get(i), q = get(i + 1);
      if (p === null || c === null || q === null) continue;
      if (p !== q || Math.abs(c - p) !== 1) continue;
      // Only on a smooth stretch: teeth, fingers and flames alternate on purpose
      const pp = i >= 2 ? get(i - 2) : p, qq = i + 2 < n ? get(i + 2) : q;
      if (pp === null || qq === null || Math.abs(pp - p) > 1 || Math.abs(qq - q) > 1 || pp === c || qq === c) continue;
      bumps.push(toXY(i, c));
    }
  };
  const left = (y: number) => { for (let x = 0; x < a.w; x++) if (a.px[y * a.w + x]) return x; return null; };
  const right = (y: number) => { for (let x = a.w - 1; x >= 0; x--) if (a.px[y * a.w + x]) return x; return null; };
  const top = (x: number) => { for (let y = 0; y < a.h; y++) if (a.px[y * a.w + x]) return y; return null; };
  const bottom = (x: number) => { for (let y = a.h - 1; y >= 0; y--) if (a.px[y * a.w + x]) return y; return null; };
  if (!o.tile && Math.max(a.w, a.h) >= 24) {
    profile(a.h, left, (y, x) => [x, y]);
    profile(a.h, right, (y, x) => [x, y]);
    profile(a.w, top, (x, y) => [x, y]);
    profile(a.w, bottom, (x, y) => [x, y]);
  }
  stats.bumps = bumps.length;
  if (bumps.length >= 3 && bumps.length > edge.length * 0.04)
    issues.push({ code: 'P_JAGGIES', severity: 'warning', message: `${bumps.length} one-pixel bumps on the silhouette: the curve wobbles in and out`, fix: 'Smooth each curve into steps that only grow or only shrink (1, 1, 2, 3 … then back), no single pixel sticking out or in.', at: cap(bumps) });

  // Noise and clusters
  const noise: [number, number][] = [];
  let fill = 0, singles = 0;
  for (let y = 0; y < a.h; y++)
    for (let x = 0; x < a.w; x++) {
      const v = a.px[y * a.w + x]!;
      if (!v) continue;
      if (!o.tile && noiseAt(a, x, y, NOISE)) noise.push([x, y]);
      if (lined && dark(v)) continue;
      fill++;
      if (!N4.some(([dx, dy]) => at(a, x + dx, y + dy) === v)) singles++;
    }
  stats.noise = noise.length;
  stats.singles = fill ? singles / fill : 0;
  if (noise.length >= 3 && noise.length > opaque * 0.015)
    issues.push({ code: 'P_NOISE', severity: 'warning', message: `${noise.length} stray pixels of a close shade inside a colour area`, fix: 'Remove them (pixelCleanup): a lone pixel only a little lighter or darker reads as dirt. Keep lone pixels with real contrast — an eye, a glint.', at: cap(noise) });
  if (!o.tile && fill >= 60 && Math.max(a.w, a.h) >= 24 && stats.singles > 0.2)
    issues.push({ code: 'P_CLUSTERS', severity: 'warning', message: `${Math.round(stats.singles * 100)} % of the fill pixels touch no pixel of their own colour: the texture is noise, not shapes`, fix: 'Shade in clusters — areas of one colour, 2+ pixels wide — and keep single pixels for the few details that need them.' });

  // Value range
  if (!o.tile && used.length >= 2 && stats.values < 0.3 && opaque >= 30)
    issues.push({ code: 'P_FLAT', severity: 'warning', message: `the colours span only ${Math.round(stats.values * 100)} % of the lightness range: no volume, and the sprite turns to mush in grey`, fix: 'Give each material 3–4 values from shadow to light (pixelRamp, pixelShade) and look at pixelValues(art): the form must read in grey.' });

  // Pillow shading: lighter toward the middle in every direction, no light direction
  const d = edgeDistance(a);
  const inner: { x: number; y: number; l: number; d: number }[] = [];
  for (let y = 0; y < a.h; y++)
    for (let x = 0; x < a.w; x++) {
      const v = a.px[y * a.w + x]!;
      if (!v || (lined && dark(v))) continue;
      inner.push({ x, y, l: L(a.colors[v - 1]!), d: d[y * a.w + x]! });
    }
  if (inner.length >= 30) {
    const n = inner.length;
    const ml = inner.reduce((s, p) => s + p.l, 0) / n, md = inner.reduce((s, p) => s + p.d, 0) / n;
    let cov = 0, vl = 0, vd = 0;
    for (const p of inner) { cov += (p.l - ml) * (p.d - md); vl += (p.l - ml) ** 2; vd += (p.d - md) ** 2; }
    const r = vl && vd ? cov / Math.sqrt(vl * vd) : 0;
    // The light's direction: where the lighter half sits against the darker half
    const lit = inner.filter((p) => p.l > ml), shaded = inner.filter((p) => p.l <= ml);
    const c = (xs: typeof inner) => [xs.reduce((s, p) => s + p.x, 0) / (xs.length || 1), xs.reduce((s, p) => s + p.y, 0) / (xs.length || 1)];
    const [ax, ay] = c(lit), [bx, by] = c(shaded);
    const offset = lit.length && shaded.length ? Math.hypot(ax! - bx!, ay! - by!) / Math.sqrt(n) : 1;
    stats.pillow = r > 0 ? Math.max(0, r * (1 - Math.min(1, offset / 0.25))) : 0;
    if (offset >= 0.2) stats.light = Math.round((Math.atan2(ay! - by!, ax! - bx!) * 180) / Math.PI);
    if (!o.tile && r > 0.55 && offset < 0.12)
      issues.push({ code: 'P_PILLOW', severity: 'warning', message: 'pillow shading: darker along every edge and lighter toward the middle, with no side the light comes from', fix: 'Pick one light (top-left is the usual) for the whole game: the side facing it light, the far side dark, the shadow following the form, not the outline (pixelShade does this).' });
  }

  // A tile's seam: across the wrap (right edge to left, bottom to top) the colours jump more than anywhere inside
  if (o.tile && opaque === a.w * a.h && a.w >= 8 && a.h >= 8) {
    let inside = 0, n = 0, wrap = 0, m = 0;
    const l = (x: number, y: number) => L(a.colors[a.px[y * a.w + x]! - 1]!);
    for (let y = 0; y < a.h; y++) for (let x = 0; x < a.w; x++) {
      const v = l(x, y);
      if (x + 1 < a.w) { inside += Math.abs(v - l(x + 1, y)); n++; } else { wrap += Math.abs(v - l(0, y)); m++; }
      if (y + 1 < a.h) { inside += Math.abs(v - l(x, y + 1)); n++; } else { wrap += Math.abs(v - l(x, 0)); m++; }
    }
    const mi = inside / n, mw = wrap / m;
    // A bevelled block (flagstones, bricks): each edge row and column is one colour — a grid on purpose
    const uniform = (xs: number[]) => { const c = new Map<number, number>(); for (const v of xs) c.set(v, (c.get(v) ?? 0) + 1); return Math.max(...c.values()) >= xs.length * 0.85; };
    const col = (x: number) => Array.from({ length: a.h }, (_, y) => a.px[y * a.w + x]!), row = (y: number) => Array.from(a.px.subarray(y * a.w, (y + 1) * a.w));
    const framed = [col(0), col(a.w - 1), row(0), row(a.h - 1)].every(uniform);
    if (mw > 2 * mi + 0.03 && framed)
      issues.push({ code: 'P_TILE_GRID', severity: 'info', message: 'the tile is a framed block (each edge one colour): laid, it shows a grid of blocks', fix: 'Right for flagstones, bricks and crates; for ground, grass, sand or water use a tile that wraps (clusters running across the edges) and a variant or two, so the grid disappears.' });
    else if (mw > 2 * mi + 0.03)
      issues.push({ code: 'P_SEAM', severity: 'warning', message: `the tile's edges don't meet: across the wrap the colour jumps ${mw.toFixed(2)} on average, inside it ${mi.toFixed(2)} — a grid of lines when it is laid`, fix: 'Lay it 2 × 2 and paint across the joins: let clusters run off one edge and in at the other, and keep the edge rows the same value as the rest.' });
  }

  // Contrast against the background
  if (o.background !== undefined && edge.length) {
    const bg = L(hex(o.background));
    const low = edge.filter(([x, y]) => Math.abs(L(a.colors[a.px[y * a.w + x]! - 1]!) - bg) < 0.12);
    if (low.length > edge.length * 0.5)
      issues.push({ code: 'P_CONTRAST', severity: 'warning', message: `${Math.round((low.length / edge.length) * 100)} % of the silhouette's edge is about as light as the background (${hex(o.background)}): the sprite melts into it`, fix: 'An outline darker (or lighter) than the background, or a background a step further away in value: what the player must see stands apart in grey first.', at: cap(low) });
  }
  return { issues, stats };
}

/**
 * What makes a set of sprites one game: one light, one pixel size, one outline rule, one palette. Takes each sprite's
 * stats (lintPixelArt) by name; the findings name the sprites that stand apart.
 */
export function lintPixelSet(sprites: readonly { name: string; stats: PixelStats; tile?: boolean }[]): PixelIssue[] {
  const issues: PixelIssue[] = [];
  const lit = sprites.filter((s) => s.stats.light !== null && !s.tile);
  if (lit.length >= 4) {
    const rad = (d: number) => (d * Math.PI) / 180;
    const cx = lit.reduce((t, s) => t + Math.cos(rad(s.stats.light!)), 0), cy = lit.reduce((t, s) => t + Math.sin(rad(s.stats.light!)), 0);
    const mean = (Math.atan2(cy, cx) * 180) / Math.PI;
    const off = lit.filter((s) => Math.abs(((s.stats.light! - mean + 540) % 360) - 180) > 120);
    if (off.length && off.length <= lit.length / 3)
      issues.push({ code: 'P_SET_LIGHT', severity: 'warning', message: `${off.length} sprite(s) lit from another side than the rest (the set's light comes from ${Math.round(mean)}°): ${off.slice(0, 8).map((s) => s.name).join(', ')}`, fix: 'One light for the whole game: shade these from the same side as the others (mirror the shading, or pixelShade with the set\'s light).' });
  }
  const big = sprites.filter((s) => s.stats.upscaled > 1);
  if (big.length && big.length < sprites.length)
    issues.push({ code: 'P_SET_DENSITY', severity: 'warning', message: `${big.length} sprite(s) drawn at a bigger pixel size than the rest (mixels): ${big.slice(0, 8).map((s) => `${s.name} ${s.stats.upscaled}×`).join(', ')}`, fix: 'One pixel size for the whole game: shrink them to their own grid (pixelDownscale) or redraw them at the game\'s density.' });
  const solid = sprites.filter((s) => !s.tile && Math.max(s.stats.w, s.stats.h) >= 8 && s.stats.opaque >= 20);
  const lined = solid.filter((s) => s.stats.outline >= 0.8), bare = solid.filter((s) => s.stats.outline <= 0.35);
  if (solid.length >= 5 && lined.length >= solid.length * 0.2 && bare.length >= solid.length * 0.2)
    issues.push({ code: 'P_SET_OUTLINE', severity: 'info', message: `${lined.length} sprite(s) with an outline and ${bare.length} without: ${bare.slice(0, 6).map((s) => s.name).join(', ')} …`, fix: 'One outline rule for the set (all lined, all selout, or none) — unless the unlined ones are effects, light or background on purpose.' });
  return issues;
}

/**
 * An animation's frames, one after the other (and the last back to the first when it loops): pixels that blink on or
 * off alone between two frames (flicker — the eye reads it as noise) and a body that jumps more than a pixel when the
 * pose doesn't call for it. Frames are compared aligned at their bottom centre (the feet).
 */
export function lintPixelFrames(frames: readonly PixelArt[], o: { loop?: boolean } = {}): PixelIssue[] {
  if (frames.length < 2) return [];
  const issues: PixelIssue[] = [];
  const pairs: [number, number][] = frames.slice(1).map((_, i) => [i, i + 1]);
  if (o.loop ?? true) pairs.push([frames.length - 1, 0]);
  const flicker: string[] = [];
  const jumps: string[] = [];
  for (const [i, j] of pairs) {
    const a = frames[i]!, b = frames[j]!;
    const W = Math.max(a.w, b.w), H = Math.max(a.h, b.h);
    const ox = (f: PixelArt) => Math.floor((W - f.w) / 2), oy = (f: PixelArt) => H - f.h;
    const get = (f: PixelArt, x: number, y: number) => { const v = at(f, x - ox(f), y - oy(f)); return v ? f.colors[v - 1]! : ''; };
    const changed = (x: number, y: number) => x >= 0 && y >= 0 && x < W && y < H && get(a, x, y) !== get(b, x, y);
    let alone = 0, total = 0;
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        if (!changed(x, y)) continue;
        total++;
        if (!N8.some(([dx, dy]) => changed(x + dx, y + dy))) alone++;
      }
    if (alone >= 3 && alone > total * 0.15) flicker.push(`${i + 1}→${j + 1}: ${alone}`);
    // The body's centre of mass (opaque pixels) between the frames
    const centre = (f: PixelArt) => { let n = 0, cx = 0, cy = 0; for (let y = 0; y < f.h; y++) for (let x = 0; x < f.w; x++) if (f.px[y * f.w + x]) { n++; cx += x + ox(f); cy += y + oy(f); } return [cx / (n || 1), cy / (n || 1)]; };
    const [ax, ay] = centre(a), [bx, by] = centre(b);
    if (Math.hypot(ax! - bx!, ay! - by!) > 2.5) jumps.push(`${i + 1}→${j + 1}: ${Math.hypot(ax! - bx!, ay! - by!).toFixed(1)} px`);
  }
  if (flicker.length)
    issues.push({ code: 'P_FLICKER', severity: 'warning', message: `pixels that blink on or off alone between frames (${flicker.join(', ')}): the animation crawls with noise`, fix: 'Move pixels in clusters from frame to frame; a lone pixel that changes should be part of a shape that moves (or stay the same in both frames).' });
  if (jumps.length)
    issues.push({ code: 'P_FRAME_JUMP', severity: 'info', message: `the body jumps between frames (${jumps.join(', ')})`, fix: 'Fine for a leap or a hit; in a walk, idle or run the body moves 1 px at a time — keep the feet on the same line and the frames the same size.' });
  return issues;
}

/** lintPixelArt on RGBA pixels, plus what only RGBA shows: half-transparent pixels (a soft edge is not pixel art) */
export function lintPixelImage(im: RgbaImage, o: LintOptions & { palette?: readonly string[] } = {}): { issues: PixelIssue[]; stats: PixelStats; art: PixelArt } {
  let soft = 0, solid = 0;
  for (let i = 3; i < im.d.length; i += 4) { const v = im.d[i]!; if (v > 0 && v < 255) soft++; if (v >= 128) solid++; }
  let art: PixelArt;
  let tooMany = false;
  try {
    art = pixelFromRgba(im, { palette: o.palette });
  } catch {
    tooMany = true;
    art = depixelize(im, { palette: o.palette }).art;
  }
  const r = lintPixelArt(art, o);
  if (tooMany)
    r.issues.unshift({ code: 'P_NOT_PIXELS', severity: 'warning', message: 'more than 255 colours: a painted or scaled picture, not pixel art', fix: 'Bring it back to whole pixels in the game\'s palette (depixelize(im, { palette })) — gp art does for technique: pixel.' });
  if (soft > Math.max(4, solid * 0.02))
    r.issues.unshift({ code: 'P_SOFT_EDGE', severity: 'warning', message: `${soft} half-transparent pixels: a blurred edge, which turns to a halo on any background`, fix: 'Every pixel fully there or not there; any anti-aliasing is done by hand inside the sprite, never into transparency.' });
  return { ...r, art };
}

// --- The low-resolution view ------------------------------------------------------------------------------------

/** The whole-number scale and the buffer size that fill a device of dw × dh px with a design resolution of bw × bh */
export function pixelViewport(dw: number, dh: number, bw: number, bh: number): { scale: number; w: number; h: number } {
  const scale = Math.max(1, Math.floor(Math.min(dw / bw, dh / bh) + 1e-6));
  return { scale, w: Math.ceil(dw / scale), h: Math.ceil(dh / scale) };
}

/**
 * The pixel game's screen: a low-resolution buffer (the design resolution — 320 × 180, 384 × 216, 480 × 270 … — grown
 * to the device's aspect, so no black bars) scaled up by a whole number with smoothing off. The world is drawn on whole
 * art pixels (`begin` snaps the camera), so no sprite ever lands between pixels and nothing shimmers; the camera's
 * fraction is put back at present as a shift of whole device pixels — the smooth camera of pixel games, without mixels.
 *
 *   const view = new PixelView([384, 216]);
 *   view.resize(canvas.width, canvas.height);        // device px, on every resize
 *   const g = view.begin(cam.x, cam.y);              // world coordinates in art px
 *   drawPixelSprite(g, hero, hx, hy, 1);  …
 *   view.hud();  drawPixelText(g, …);                 // screen-fixed layer, no camera
 *   view.present(ctx);
 */
export class PixelView {
  readonly canvas: HTMLCanvasElement;
  readonly ctx: CanvasRenderingContext2D;
  scale = 1;
  /** The visible area in art px (the buffer is one pixel bigger each way, for the smooth camera) */
  w = 0;
  h = 0;
  private fx = 0;
  private fy = 0;
  private hudCanvas: HTMLCanvasElement | null = null;
  private hudCtx: CanvasRenderingContext2D | null = null;
  private hudUsed = false;

  readonly base: readonly [number, number];

  constructor(base: readonly [number, number], o: { smooth?: boolean } = {}) {
    this.base = base;
    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d')!;
    this.smooth = o.smooth ?? true;
    this.resize(base[0], base[1]);
  }

  /** The camera's sub-pixel motion at present (default true); false: the camera moves in whole art pixels */
  smooth: boolean;

  resize(deviceW: number, deviceH: number): void {
    const v = pixelViewport(deviceW, deviceH, this.base[0], this.base[1]);
    this.scale = v.scale;
    this.w = v.w;
    this.h = v.h;
    this.canvas.width = v.w + 1;
    this.canvas.height = v.h + 1;
    this.ctx.imageSmoothingEnabled = false;
  }

  /** Clear and set the world transform for a camera at (x, y) art px (its top-left) */
  begin(camX = 0, camY = 0, clear = '#000000'): CanvasRenderingContext2D {
    const ix = Math.floor(camX), iy = Math.floor(camY);
    this.fx = this.smooth ? camX - ix : 0;
    this.fy = this.smooth ? camY - iy : 0;
    const g = this.ctx;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.imageSmoothingEnabled = false;
    g.fillStyle = clear;
    g.fillRect(0, 0, this.canvas.width, this.canvas.height);
    g.setTransform(1, 0, 0, 1, -ix, -iy);
    return g;
  }

  /** The screen-fixed layer (art px from the top-left, no camera, no sub-pixel shift): the HUD, cleared each begin() */
  hud(): CanvasRenderingContext2D {
    if (!this.hudCanvas) {
      this.hudCanvas = document.createElement('canvas');
      this.hudCtx = this.hudCanvas.getContext('2d')!;
    }
    const c = this.hudCanvas, g = this.hudCtx!;
    if (c.width !== this.w || c.height !== this.h) { c.width = this.w; c.height = this.h; }
    if (!this.hudUsed) { g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, c.width, c.height); }
    g.imageSmoothingEnabled = false;
    this.hudUsed = true;
    return g;
  }

  /** Scale the buffer onto the device canvas: whole-number scale, the camera's fraction as whole device pixels */
  present(target: CanvasRenderingContext2D): void {
    const s = this.scale;
    target.save();
    target.setTransform(1, 0, 0, 1, 0, 0);
    target.imageSmoothingEnabled = false;
    target.drawImage(this.canvas, -Math.round(this.fx * s), -Math.round(this.fy * s), this.canvas.width * s, this.canvas.height * s);
    if (this.hudUsed && this.hudCanvas) target.drawImage(this.hudCanvas, 0, 0, this.w * s, this.h * s);
    target.restore();
    this.hudUsed = false;
  }

  /** A device pixel (a tap) to art px of the world, for a camera at (camX, camY) */
  toWorld(deviceX: number, deviceY: number, camX = 0, camY = 0): [number, number] {
    return [deviceX / this.scale + camX, deviceY / this.scale + camY];
  }
}
