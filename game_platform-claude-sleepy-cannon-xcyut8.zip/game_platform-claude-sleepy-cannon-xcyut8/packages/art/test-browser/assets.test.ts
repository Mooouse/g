// @gp/art/assets in the browser (Playwright's Chromium): a later chapter's data block read only once it has arrived in
// full and dropped from the page, a placeholder that carries its image's size and shows its thumbnail, createAssets
// decoding chapter 0 for ready(0) and nothing of chapter 1 until asked, real <img> elements warmed up so the game's
// canvas draws them without a second decode. Runs with `npm run test:browser`.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

async function open(): Promise<Page> {
  const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
  await page.goto(base);
  await page.waitForFunction('!!window.art');
  return page;
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const run = <R>(page: Page, fn: (art: any, T: any) => R) => page.evaluate(`(${fn.toString()})(window.art, window.T)`) as Promise<Awaited<R>>;

describe('@gp/art/assets: chapters in the browser', () => {
  it('a data block is read when it is whole, then dropped from the page; a URL without a block is fetched as it is', async () => {
    const page = await open();
    const r = await run(page, async (art) => {
      const c = document.createElement('canvas');
      c.width = 8;
      c.height = 4;
      c.getContext('2d')!.fillRect(0, 0, 8, 4);
      const b64 = c.toDataURL('image/png').split(',')[1]!;
      const block = (path: string, text: string, n: number) => {
        const s = document.createElement('script');
        s.type = 'application/octet-stream';
        s.dataset.gpAsset = path;
        s.dataset.gpChapter = '1';
        s.dataset.type = 'image/png';
        s.dataset.n = String(n);
        s.text = text;
        document.body.append(s);
      };
      block('chapters/1/whole.png', b64, b64.length);
      // Still arriving: shorter than its data-n — the page is complete here, so the URL is what is left
      block('chapters/1/partial.png', b64.slice(0, 10), b64.length);
      const whole = await art.assetSource('chapters/1/whole.png');
      const partial = await art.assetSource('chapters/1/partial.png');
      const again = await art.assetSource('chapters/1/whole.png');
      const img = new Image();
      img.src = whole;
      await img.decode();
      return { whole: whole.slice(0, 22), partial, again: again === whole, left: [...document.querySelectorAll('script[data-gp-asset]')].map((s) => (s as HTMLElement).dataset.gpAsset), w: img.naturalWidth };
    });
    expect(r.whole).toBe('data:image/png;base64,');
    expect(r.partial).toBe('chapters/1/partial.png');
    expect(r.again).toBe(true);
    expect(r.left).toEqual(['chapters/1/partial.png']);
    expect(r.w).toBe(8);
  });

  it('createAssets: chapter 0 for ready(0), chapter 1 only when asked; a placeholder with its size and thumbnail until then', async () => {
    const page = await open();
    const r = await run(page, async (art) => {
      const pic = (w: number, h: number, color: string) => {
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        const g = c.getContext('2d')!;
        g.fillStyle = color;
        g.fillRect(0, 0, w, h);
        return c.toDataURL('image/webp', 0.9);
      };
      const assets = art.createAssets({
        urls: { garage: pic(320, 180, '#203040'), car: pic(400, 200, '#d02020'), van: pic(300, 300, '#20a040') },
        chapters: { car: 1, van: 1 },
        sizes: { car: [400, 200], van: [300, 300] },
        thumbs: { car: pic(32, 16, '#d02020') },
      });
      const marks = () => performance.getEntriesByType('mark').map((m) => m.name).filter((n) => n.startsWith('gp:assets'));
      await assets.ready(0);
      const after0 = { marks: marks(), car: assets.progress(1), garage: assets.get('garage') instanceof HTMLImageElement };
      // Drawn before it is decoded: the placeholder (asks for it)
      const ph = assets.img.car;
      const holder = { placeholder: art.isPlaceholder(ph), w: ph.naturalWidth, h: ph.naturalHeight, canvasW: ph.width };
      await new Promise((r) => setTimeout(r, 50));
      const thumbPx = [...ph.getContext('2d').getImageData(8, 8, 1, 1).data];
      const silhouette = [...art.makePlaceholder([100, 100], undefined).getContext('2d').getImageData(16, 16, 1, 1).data];
      await assets.ready(1);
      const car = assets.img.car;
      // The game's canvas draws a warmed-up picture without decoding it again
      const g = document.createElement('canvas').getContext('2d')!;
      g.canvas.width = 400;
      g.canvas.height = 200;
      const t = performance.now();
      g.drawImage(car, 0, 0);
      g.getImageData(0, 0, 1, 1);
      const drawMs = performance.now() - t;
      return { after0, holder, thumbPx, silhouette, loaded: assets.loaded('car') && assets.loaded('van'), isImg: car instanceof HTMLImageElement, drawMs, marks: marks() };
    });
    expect(r.after0.marks).toEqual(['gp:assets:chapter-0:start', 'gp:assets:chapter-0:ready']);
    expect(r.after0.car).toEqual({ done: 0, total: 2 });
    expect(r.after0.garage).toBe(true);
    expect(r.holder).toEqual({ placeholder: true, w: 400, h: 200, canvasW: 32 });
    // The thumbnail's red, not the silhouette's grey
    expect(r.thumbPx[0]).toBeGreaterThan(150);
    expect(r.thumbPx[1]).toBeLessThan(80);
    expect(r.silhouette[3]).toBeGreaterThan(40);
    expect(r.silhouette[3]).toBeLessThan(140);
    expect(r.loaded).toBe(true);
    expect(r.isImg).toBe(true);
    expect(r.drawMs).toBeLessThan(15);
    expect(r.marks).toEqual(['gp:assets:chapter-0:start', 'gp:assets:chapter-0:ready', 'gp:assets:chapter-1:start', 'gp:assets:chapter-1:ready']);
  });

  it("the dev build's early-chapter warning names the game's line that asked, not the module's own", async () => {
    const page = await open();
    const said = await run(page, (art) => {
      const out: string[] = [];
      const assets = art.createAssets({ urls: { shed: 'shed.png', car: 'car.png' }, chapters: { car: 1 } }, { decode: () => new Promise(() => {}), warn: (m: string) => out.push(m), painted: () => false });
      function gameStart() {
        void assets.ready(1);
      }
      gameStart();
      return out;
    });
    expect(said).toHaveLength(1);
    expect(said[0]).toContain('ready(1) asks for chapter 1 before the first screen');
    expect(said[0]).toMatch(/, at gameStart \(/);
  });
});
