// A temporary portal game with many painted pictures, for the asset-chapter tests and the before/after measurement
// (chapters.test.ts, tools/chapters-bench.ts): N dummy WebP "cars" of ≈ 35 KB each (game19's owner pictures average that),
// made in Chromium — nothing big is committed. The game loads chapter 0 before its Play button and the rest after Play.

import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Browser } from 'playwright';
import { assetsDir, indexFor, loadProvenance, sha256, writeProvenance, writeThumbs, type ArtAsset } from '../src/art.ts';
import { artSpec } from '../src/art.ts';
import type { GameLocation } from '../src/paths.ts';

export interface ChapterGame {
  loc: GameLocation;
  /** The pictures' ids, in order */
  ids: string[];
  /** Their WebP bytes in all */
  bytes: number;
}

/** N dummy pictures (720×310, ≈ 35 KB WebP each: soft shapes and grain, so WebP can't shrink them to nothing) */
export async function dummyPictures(browser: Browser, n: number, seed = 1): Promise<Buffer[]> {
  const page = await browser.newPage();
  try {
    await page.setContent('<body></body>');
    const b64 = await page.evaluate(
      async ({ n, seed }) => {
        let s = seed >>> 0 || 1;
        const rnd = () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
        const out: string[] = [];
        for (let i = 0; i < n; i++) {
          const c = document.createElement('canvas');
          c.width = 720;
          c.height = 310;
          const g = c.getContext('2d')!;
          const hue = Math.floor(rnd() * 360);
          const grd = g.createLinearGradient(0, 0, 720, 310);
          grd.addColorStop(0, `hsl(${hue} 70% 55%)`);
          grd.addColorStop(1, `hsl(${(hue + 60) % 360} 60% 30%)`);
          // A car-ish silhouette on transparency: a body and two wheels
          g.fillStyle = grd;
          g.beginPath();
          g.roundRect(20, 90, 680, 150, 60);
          g.fill();
          g.beginPath();
          g.roundRect(170, 30, 330, 110, 50);
          g.fill();
          for (const x of [170, 550]) {
            g.fillStyle = '#1b1b22';
            g.beginPath();
            g.arc(x, 240, 62, 0, Math.PI * 2);
            g.fill();
          }
          // Grain and blotches inside the body: the detail of a painted picture
          const d = g.getImageData(0, 0, 720, 310);
          for (let p = 0; p < d.data.length; p += 4) {
            if (!d.data[p + 3]) continue;
            const k = (rnd() - 0.5) * 34;
            d.data[p] += k;
            d.data[p + 1] += k;
            d.data[p + 2] += k;
          }
          g.putImageData(d, 0, 0);
          for (let b = 0; b < 30; b++) {
            g.fillStyle = `hsla(${Math.floor(rnd() * 360)} 60% 60% / 0.25)`;
            g.beginPath();
            g.arc(40 + rnd() * 640, 60 + rnd() * 170, 6 + rnd() * 30, 0, Math.PI * 2);
            g.fill();
          }
          out.push(c.toDataURL('image/webp', 0.86).split(',')[1]!);
        }
        return out;
      },
      { n, seed },
    );
    return b64.map((x) => Buffer.from(x, 'base64'));
  } finally {
    await page.close();
  }
}

const GAME_YAML = (id: string, assets: ArtAsset[]) => `spec: 0
id: ${id}
title: "Chapter Garage"
audience: general
channel: crazygames
kit: code
entry: main.ts
background: "#14161c"
concept:
  pitch: "A test garage with many painted cars, to measure what Play waits for."
  closest: ["Idle Garage", "Car Restoration", "Garage Tycoon"]
  different: "Nothing: a platform test fixture for asset chapters, never submitted."
money:
  genre: idle
  session: { minutes: 10, breaks: 3, breaksAt: "a car is done → the next car" }
  rewarded: []
  returns: { kind: meta, what: "Only a test fixture: the cars collected" }
sound: { music: false, why: "A platform test fixture, never submitted" }
budget: { gzipKB: 4000 }
listing:
  description: "Chapter Garage is a platform test fixture: a garage of painted cars, the first few loaded before Play and the rest after it, to measure the time to a tappable Play. (Not a game for release.)"
  controls: "Mouse or touch: tap Play."
  orientation: both
  tags: [Casual]
art:
  style: "the owner's own finished pictures (gp art import): a test fixture of dummy painted cars"
  keep: ["the cars read as cars at play size"]
  assets:
${assets.map((a) => `    - { id: ${a.id}, kind: sprite, source: import, prompt: "dummy car ${a.id}"${a.chapter ? `, chapter: ${a.chapter}` : ''} }`).join('\n')}
`;

/**
 * The game's code: chapter 0 decoded before the title's Play button (performance.mark('fixture:play-ready')), chapter 1
 * prefetched after Play, every car drawn each frame — a placeholder until it is decoded. Without chapters, the way a game
 * ships today: every picture decoded with loadImages before Play. window.__fx reports what it saw
 */
const MAIN_TS = (chapters: boolean) => `import type { GameContext } from '@gp/core';
${
  chapters
    ? `import { createAssets, isPlaceholder } from '@gp/art/assets';
import { ASSETS } from './assets/index.ts';
const load = () => {
  const a = createAssets(ASSETS);
  return { ids: Object.keys(ASSETS.urls) as (keyof typeof ASSETS.urls)[], first: a.ids(0), ready: () => a.ready(0), later: () => (a.prefetch(1), a.ready(1)), placeholder: (id: keyof typeof ASSETS.urls) => isPlaceholder(a.img[id]), draw: (g: CanvasRenderingContext2D, id: keyof typeof ASSETS.urls, x: number, y: number, h: number) => a.draw(g, id, x, y, h) };
};`
    : `import { drawImageSprite, loadImages } from '@gp/art/assets';
import { ART } from './assets/index.ts';
const load = () => {
  let img: Record<string, HTMLImageElement> | null = null;
  const ids = Object.keys(ART) as (keyof typeof ART)[];
  return { ids, first: ids, ready: async () => { img = await loadImages(ART); }, later: async () => {}, placeholder: () => false, draw: (g: CanvasRenderingContext2D, id: keyof typeof ART, x: number, y: number, h: number) => { if (img) drawImageSprite(g, img[id]!, x, y, h); } };
};`
}

export default async function start({ host, canvas, ui }: GameContext): Promise<void> {
  const assets = load();
  const fx = { firstFrame: 0, playReady: 0, played: 0, chapter1Ready: 0, placeholders: 0, frames: [] as number[], times: [] as number[] };
  (window as unknown as { __fx: typeof fx }).__fx = fx;
  const g = canvas.getContext('2d')!;
  let playing = false;
  let last = 0;
  const frame = (t: number) => {
    if (!fx.firstFrame) {
      fx.firstFrame = t;
      performance.mark('fixture:first-frame');
    }
    if (last) fx.frames.push(t - last);
    fx.times.push(t);
    last = t;
    if (canvas.width !== innerWidth || canvas.height !== innerHeight) {
      canvas.width = innerWidth;
      canvas.height = innerHeight;
    }
    g.fillStyle = '#14161c';
    g.fillRect(0, 0, canvas.width, canvas.height);
    const shown = playing ? assets.ids : assets.first;
    const cols = 10;
    const w = canvas.width / cols;
    let ph = 0;
    shown.forEach((id, i) => {
      const x = (i % cols) * w + w / 2;
      const y = Math.floor(i / cols) * (w * 0.5) + w * 0.3;
      if (assets.placeholder(id)) ph++;
      assets.draw(g, id, x, y, w * 0.4);
    });
    fx.placeholders = ph;
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
  await assets.ready();
  const play = document.createElement('button');
  play.dataset.gp = 'play';
  play.textContent = 'Play';
  play.style.cssText = 'position:absolute;left:50%;top:70%;transform:translate(-50%,-50%);font:700 28px sans-serif;padding:16px 48px';
  play.onclick = () => {
    play.remove();
    playing = true;
    fx.played = performance.now();
    host.gameplay(true);
    void assets.later().then(() => {
      fx.chapter1Ready = performance.now();
    });
  };
  ui.append(play);
  fx.playReady = performance.now();
  performance.mark('fixture:play-ready');
}
`;

/**
 * The game in `dir/<id>`: `first` pictures in chapter 0, the rest in chapter `later` (0: every picture before Play, the
 * way a game without chapters ships today). Thumbnails, provenance and assets/index.ts as gp art import writes them
 */
export async function makeChapterGame(browser: Browser, dir: string, id: string, pictures: Buffer[], first: number, later: number): Promise<ChapterGame> {
  const gameDir = join(dir, id);
  const loc: GameLocation = { id, dir: gameDir, file: join(gameDir, 'game.yaml') };
  mkdirSync(join(gameDir, 'assets'), { recursive: true });
  const ids = pictures.map((_, i) => `car-${String(i + 1).padStart(3, '0')}`);
  const assets: ArtAsset[] = ids.map((x, i) => ({ id: x, kind: 'sprite', source: 'import', prompt: `dummy car ${x}`, ...(i >= first && later ? { chapter: later } : {}) }));
  writeFileSync(loc.file, GAME_YAML(id, assets));
  writeFileSync(join(gameDir, 'main.ts'), MAIN_TS(later > 0 && first < pictures.length));
  const prov = loadProvenance(loc);
  const date = '2026-10-20';
  pictures.forEach((buf, i) => {
    writeFileSync(join(assetsDir(loc), `${ids[i]}.webp`), buf);
    prov.files[`${ids[i]}.webp`] = { kind: 'sprite', model: 'the owner (gp art import)', prompt: `dummy car ${ids[i]}`, style: null, size: [720, 310], bytes: buf.length, sha256: sha256(buf), date, source: 'owner', original: `${ids[i]}.png`, originalSha256: sha256(buf) };
  });
  const page = await browser.newPage();
  try {
    await page.setContent('<body></body>');
    await writeThumbs(loc, artSpec(loc)!, page, prov, date);
  } finally {
    await page.close();
  }
  writeProvenance(loc, prov);
  writeFileSync(join(assetsDir(loc), 'index.ts'), indexFor(loc, artSpec(loc)!));
  return { loc, ids, bytes: pictures.reduce((a, b) => a + b.length, 0) };
}
