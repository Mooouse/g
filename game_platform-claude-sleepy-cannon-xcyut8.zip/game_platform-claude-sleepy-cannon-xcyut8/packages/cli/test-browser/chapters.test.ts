// Asset chapters in a real browser (Playwright's Chromium): a portal game with 30 painted pictures (5 before Play, 25 in
// chapter 1, chapters-fixture.ts) built by buildPortal into its one index.html, served gzipped on the slow-phone network
// (1.6 Mbps, 150 ms RTT). The game's Play is tappable while the page is still arriving; no later-chapter image is decoded
// before the first frame (nor before Play: the game asks for chapter 1 on Play); after Play they all arrive from the page's
// own data blocks — no other request — and the placeholders give way to the pictures.

import { createServer, type Server } from 'node:http';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { gzipSync } from 'node:zlib';
import { chromium, type Browser } from 'playwright';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { assetChapters } from '../../qa/src/portal-suite.ts';
import { checkGame } from '../src/game.ts';
import { buildPortal } from '../src/portal-build.ts';
import { dummyPictures, makeChapterGame } from './chapters-fixture.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-chapters-browser-'));
let browser: Browser;
let server: Server;
let url = '';
let size: Awaited<ReturnType<typeof buildPortal>>['size'];
let qaDir = '';
const env = process.env.NODE_ENV;

const SDK = `(() => { const calls = []; window.__sdk = { calls };
  const game = {}; for (const f of ['loadingStart','loadingStop','gameplayStart','gameplayStop','happytime']) game[f] = () => calls.push(f);
  game.settings = { muteAudio: false }; game.addSettingsChangeListener = () => {};
  window.CrazyGames = { SDK: { environment: 'crazygames', init: async () => {}, game, ad: { requestAd: (t, cb) => cb.adError && cb.adError({ code: 'other' }) },
    data: { getItem: () => null, setItem: () => {}, removeItem: () => {}, clear: () => {} } } }; })();`;

beforeAll(async () => {
  // vitest sets NODE_ENV=test, which Vite would take over the production mode: as in gp
  delete process.env.NODE_ENV;
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const game = await makeChapterGame(browser, tmp, 'chapter-garage', await dummyPictures(browser, 30), 5, 1);
  const r = checkGame(game.loc, 'dev');
  expect(r.issues.filter((i) => i.severity === 'error')).toEqual([]);
  const pkg = await buildPortal(game.loc, r.game!);
  expect(pkg.problems).toEqual([]);
  size = pkg.size;
  qaDir = join(game.loc.dir, 'qa');
  // The upload as a portal serves it: gzipped, streamed
  const body = gzipSync(readFileSync(pkg.file), { level: 9 });
  server = createServer((req, res) => {
    if ((req.url ?? '/').split('?')[0] !== '/') {
      res.writeHead(404).end();
      return;
    }
    res.writeHead(200, { 'content-type': 'text/html', 'content-encoding': 'gzip', 'cache-control': 'no-store' });
    let i = 0;
    const pump = () => {
      while (i < body.length) {
        const ok = res.write(body.subarray(i, i + 16384));
        i += 16384;
        if (!ok) return void res.once('drain', pump);
      }
      res.end();
    };
    pump();
  });
  await new Promise<void>((ok) => server.listen(0, '127.0.0.1', ok));
  url = `http://127.0.0.1:${(server.address() as { port: number }).port}/`;
}, 240_000);

afterAll(async () => {
  process.env.NODE_ENV = env;
  await browser?.close();
  server?.close();
  rmSync(tmp, { recursive: true, force: true });
});

describe('asset chapters in the one-file upload', () => {
  it('the size report: the first load is a fraction of the file', () => {
    expect(size.chapters!.map((c) => [c.chapter, c.files])).toEqual([[1, 25]]);
    expect(size.first!.gzip).toBeLessThan(size.gzipBytes * 0.35);
  });

  it('Play is tappable while the later chapter still arrives; none of it decoded before the first frame; all of it after Play, from the page itself', { timeout: 180_000 }, async () => {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    await ctx.route('https://sdk.crazygames.com/**', (route) => route.fulfill({ contentType: 'application/javascript', body: SDK }));
    const page = await ctx.newPage();
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(e.message));
    const requests: string[] = [];
    page.on('request', (r) => {
      const u = new URL(r.url());
      if (u.origin === new URL(url).origin) requests.push(u.pathname);
    });
    const cdp = await ctx.newCDPSession(page);
    await cdp.send('Network.enable');
    await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 150, downloadThroughput: 1.6384e6 / 8, uploadThroughput: 96_000 });
    await page.goto(url, { waitUntil: 'commit' });
    await page.waitForSelector('[data-gp=play]', { state: 'visible', timeout: 60_000 });
    const atPlay = await page.evaluate(() => {
      const mark = (n: string) => performance.getEntriesByName(n)[0]?.startTime ?? null;
      return {
        loading: document.readyState === 'loading',
        firstFrame: mark('fixture:first-frame'),
        playReady: mark('fixture:play-ready'),
        chapter0: mark('gp:assets:chapter-0:ready'),
        chapter1: mark('gp:assets:chapter-1:start'),
      };
    });
    // The game is up before the page has arrived: the later chapter doesn't hold Play
    expect(atPlay.loading).toBe(true);
    expect(atPlay.firstFrame).not.toBeNull();
    expect(atPlay.chapter0).not.toBeNull();
    expect(atPlay.chapter1).toBeNull();
    await page.click('[data-gp=play]');
    // Right after Play: the cars are placeholders (thumbnails), then pictures
    await page.waitForFunction(() => (window as unknown as { __fx: { placeholders: number } }).__fx.placeholders > 0, null, { timeout: 10_000 });
    await page.waitForFunction(() => (window as unknown as { __fx: { chapter1Ready: number; placeholders: number } }).__fx.chapter1Ready > 0, null, { timeout: 120_000, polling: 250 });
    const after = await page.evaluate(() => {
      const fx = (window as unknown as { __fx: { chapter1Ready: number; played: number; placeholders: number } }).__fx;
      return { start: performance.getEntriesByName('gp:assets:chapter-1:start')[0]!.startTime, played: fx.played, ready: fx.chapter1Ready, blocksLeft: document.querySelectorAll('script[data-gp-asset]').length };
    });
    expect(after.start).toBeGreaterThanOrEqual(after.played);
    expect(after.start).toBeGreaterThan(atPlay.firstFrame!);
    // Every block read (and dropped from the page), every placeholder replaced on the next frames
    expect(after.blocksLeft).toBe(0);
    await page.waitForFunction(() => (window as unknown as { __fx: { placeholders: number } }).__fx.placeholders === 0, null, { timeout: 5_000 });
    // gp qa's production check says the same, and notes the size report's first load beside it
    const checks: { name: string; ok: boolean; details?: string }[] = [];
    const infos: string[] = [];
    await assetChapters({ outDir: qaDir, check: (_s, name, ok, details) => void checks.push({ name, ok, details }), info: (_s, name, d) => void infos.push(`${name}: ${d}`) }, page);
    expect(checks).toHaveLength(1);
    expect(checks[0]!.ok, checks[0]!.details).toBe(true);
    expect(checks[0]!.details).toMatch(/^25 image\(s\) in chapter 1 after the script/);
    expect(infos.join('\n')).toMatch(/before Play \d+ KB gzipped, ≈ [\d.]+ s to a tappable Play on a slow phone; after it chapter 1/);
    // One file: nothing but the page itself
    expect([...new Set(requests)]).toEqual(['/']);
    expect(errors).toEqual([]);
    await ctx.close();
  });
});
