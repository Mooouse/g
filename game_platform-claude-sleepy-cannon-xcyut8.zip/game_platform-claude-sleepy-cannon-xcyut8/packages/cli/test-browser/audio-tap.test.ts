// Browser test of `gp video --sound`'s audio tap (packages/cli/src/audio-tap.ts): the page's AudioContext plays one
// frame of audio per frame of the virtual clock, the soundtrack has exactly one frame of samples per kept frame, and
// what the game asks for (suspend on a pause, resume after it) decides which frames are silent. `npm run test:browser`.

import { chromium, type Browser } from 'playwright';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { installProbe } from '@gp/qa/probe';
import { integratedLufs } from '@gp/qa/sound';
import { audioMeter, audioTap, connectMeter, runAudio, takeAudio, takeMeter } from '../src/audio-tap.ts';
import { advanceClock, virtualClock } from '../src/clock.ts';

let browser: Browser;

beforeAll(async () => {
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined, args: ['--autoplay-policy=no-user-gesture-required'] });
}, 60000);

afterAll(async () => {
  await browser?.close();
});

// A tone from 100 ms of game time; the game pauses its sound at 300 ms and resumes at 400 ms
const PAGE = `<!doctype html><script>
  const ctx = new AudioContext();
  window.states = [];
  setTimeout(() => {
    const o = ctx.createOscillator();
    o.connect(ctx.destination);
    o.start();
    states.push(ctx.state);
  }, 100);
  setTimeout(() => { ctx.suspend(); states.push(ctx.state); }, 300);
  setTimeout(() => { ctx.resume(); states.push(ctx.state); }, 400);
</script>`;

describe('audioTap', () => {
  it("records the page's sound frame by frame on the virtual clock, silent while the game has it suspended", async () => {
    const page = await browser.newPage();
    await page.addInitScript(audioTap);
    await page.addInitScript(virtualClock);
    // localhost: a secure context, as the dev server is (the AudioWorklet needs one)
    await page.route('http://localhost:9/', (r) => r.fulfill({ contentType: 'text/html', body: PAGE }));
    await page.goto('http://localhost:9/');
    // The worklet module loads
    await page.waitForTimeout(300);
    const dt = 1000 / 30;
    for (let k = 0; k < 15; k++) {
      await advanceClock(page, dt);
      await runAudio(page, dt, true);
    }
    // One off-camera frame: played, not kept
    await advanceClock(page, dt);
    await runAudio(page, dt, false);
    const { rate, pcm, error } = await takeAudio(page);
    expect(error).toBe('');
    const per = Math.round(rate / 30);
    expect(pcm.length).toBe(15 * per * 4);
    // The loudness of each kept frame (left channel)
    const rms = Array.from({ length: 15 }, (_, k) => {
      let s = 0;
      for (let i = 0; i < per; i++) s += pcm.readInt16LE((k * per + i) * 4) ** 2;
      return Math.sqrt(s / per);
    });
    const loud = (k: number) => rms[k]! > 1000;
    const quiet = (k: number) => rms[k]! < 10;
    const shape = rms.map((_, k) => (loud(k) ? 'X' : quiet(k) ? '.' : '?')).join('');
    expect([0, 1].every(quiet), shape).toBe(true);
    expect([3, 4, 5, 6, 7].every(loud), shape).toBe(true);
    expect([9, 10].every(quiet), shape).toBe(true);
    expect([12, 13, 14].every(loud), shape).toBe(true);
    // The game sees the state it asked for, not the recorder's own suspends between frames
    expect(await page.evaluate(() => (window as unknown as { states: string[] }).states)).toEqual(['running', 'suspended', 'running']);
    await page.close();
  });
});

// gp qa's sound section: the meter in real time (audioMeter) — a 1 kHz tone of amplitude 0.5 on a bus tagged as the
// mixer's effects bus reads ≈ −6 LUFS on the effects input and the mix (K-weighting is ≈ 0 dB at 1 kHz); pushed to 2.5×
// it clips, and the meter counts the samples
const METER_PAGE = `<!doctype html><script>
  const ctx = new AudioContext();
  const bus = ctx.createGain();
  Object.defineProperty(bus, '__gpBus', { value: 'sfx' });
  bus.connect(ctx.destination);
  const g = ctx.createGain();
  g.gain.value = 0.5;
  const o = ctx.createOscillator();
  o.frequency.value = 1000;
  o.connect(g).connect(bus);
  o.start();
  window.loud = () => g.gain.setValueAtTime(2.5, ctx.currentTime);
</script>`;

describe('audioMeter', () => {
  it('meters the mix and the effects bus apart: loudness in LUFS, peaks, clipped samples', { timeout: 30000 }, async () => {
    const page = await browser.newPage();
    await page.addInitScript(audioMeter);
    await page.addInitScript(installProbe);
    await page.route('http://localhost:9/', (r) => r.fulfill({ contentType: 'text/html', body: METER_PAGE }));
    await page.goto('http://localhost:9/');
    await page.waitForTimeout(400);
    expect(await connectMeter(page)).toEqual({ sfx: true, bed: false });
    await page.waitForTimeout(1500);
    const quiet = await takeMeter(page);
    expect(quiet.error).toBe('');
    expect((quiet.rows.length * 128) / quiet.rate).toBeGreaterThan(1);
    const end = quiet.rows.at(-1)![0] / quiet.rate;
    const late = quiet.rows.filter((r) => r[0] / quiet.rate > end - 1);
    expect(integratedLufs(late, quiet.rate, 1)).toBeCloseTo(-6, 0);
    expect(integratedLufs(late, quiet.rate, 0)).toBeCloseTo(-6, 0);
    expect(Math.max(...late.map((r) => r[2]))).toBeCloseTo(0.5, 1);
    expect(late.reduce((n, r) => n + r[3], 0)).toBe(0);
    // ≈ 2 × 1000 crossings a second (the mono sum of both channels)
    const zcr = late.reduce((n, r) => n + r[8], 0) / ((late.length * 128) / quiet.rate);
    expect(zcr).toBeGreaterThan(1800);
    expect(zcr).toBeLessThan(2200);
    await page.evaluate(() => (window as unknown as { loud: () => void }).loud());
    await page.waitForTimeout(400);
    const loud = await takeMeter(page);
    expect(loud.rows.reduce((n, r) => n + r[3], 0)).toBeGreaterThan(100);
    await page.close();
  });
});
