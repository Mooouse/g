// Browser test of gp video's virtual clock, exported for tools (packages/cli/src/clock.ts): nothing moves in real time,
// an advance runs the due timers in order and then the frame's rAF callbacks. Runs with `npm run test:browser`.

import { chromium, type Browser } from 'playwright';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { advanceClock, virtualClock } from '../src/clock.ts';

let browser: Browser;

beforeAll(async () => {
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
});

const PAGE = `<!doctype html><script>
  window.log = [];
  setTimeout(() => log.push('t50@' + performance.now()), 50);
  setTimeout(() => log.push('t10@' + performance.now()), 10);
  const id = setInterval(() => log.push('i20'), 20);
  setTimeout(() => clearInterval(id), 45);
  const frame = (ts) => { log.push('raf@' + ts); requestAnimationFrame(frame); };
  requestAnimationFrame(frame);
</script>`;

describe('virtualClock', () => {
  it('stands still in real time and advances only when told: timers in order, then rAF with the new time', async () => {
    const page = await browser.newPage();
    await page.addInitScript(virtualClock);
    // A real navigation (init scripts don't run for setContent)
    await page.route('http://clock.test/', (r) => r.fulfill({ contentType: 'text/html', body: PAGE }));
    await page.goto('http://clock.test/');
    await page.waitForTimeout(150);
    expect(await page.evaluate(() => (window as unknown as { log: string[] }).log)).toEqual([]);
    await advanceClock(page, 40);
    expect(await page.evaluate(() => (window as unknown as { log: string[] }).log)).toEqual(['t10@40', 'i20', 'i20', 'raf@40']);
    await advanceClock(page, 20);
    expect(await page.evaluate(() => ({ log: (window as unknown as { log: string[] }).log.slice(4), now: performance.now() }))).toEqual({ log: ['t50@60', 'raf@60'], now: 60 });
    await page.close();
  });
});
