// gp stage: the design lifecycle (GDLC) — the phase a game is in, read from fixture artifacts; a missing file is "not
// yet"; --check; the slice warning; phase 6 from the portal's records; and the gate gp submission enforces.

import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, utimesSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import type { RecordedResult } from '@gp/spec';
import { appendLog, recordTemplate } from '../src/brief.ts';
import { checkGame } from '../src/game.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import { FIRST_LOOK_PASS, PHASES, liveChecks, phaseOf, phaseState, sliceWarning, stageMarkdown, stageReport, submissionGates, weakestMetrics, type StageReport } from '../src/stage.ts';
import { gdlcStep } from '../src/submission.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-stage-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

// A gp init repository: repo/games/forge (the art showcase without its outputs), repo/docs/
const repo = join(tmp, 'repo');
const dir = join(repo, 'games', 'forge');
const qa = join(dir, 'qa');
const fresh = () => {
  rmSync(repo, { recursive: true, force: true });
  mkdirSync(join(repo, 'docs'), { recursive: true });
  cpSync(join(ROOT, 'docs/examples/art'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) });
  // A twist, so the slice can pass
  const y = readFileSync(join(dir, 'game.yaml'), 'utf8').replace(/^(\s+different: .*)$/m, '$1\n  twist: { event: chain, within: 20, explained: "Chain the sparks" }');
  writeFileSync(join(dir, 'game.yaml'), y);
  mkdirSync(qa, { recursive: true });
};
const write = (f: string, s: string | object) => {
  mkdirSync(join(f, '..'), { recursive: true });
  writeFileSync(f, typeof s === 'string' ? s : JSON.stringify(s, null, 2));
};
/** Every file in the folder as old as `ms`: the game's code is older than the evidence written after it */
const age = (files: string[], ms = Date.now() - 3600_000) => {
  for (const f of files) utimesSync(f, ms / 1000, ms / 1000);
};
const report = async (o: { results?: RecordedResult[]; today?: string } = {}) => {
  const loc = locateGame(dir);
  const r = checkGame(loc, 'dev');
  return stageReport({ loc, issues: r.issues, game: r.game, results: o.results ?? [], updates: [], repo: null, today: o.today ?? '2026-10-23' });
};
const check = (rep: StageReport, id: string) => rep.phases.flatMap((p) => p.checks).find((c) => c.id === id)!;

const QA = (o: { feel?: boolean; failed?: number } = {}) => ({
  game: 'art-showcase',
  date: new Date().toISOString(),
  platform: null,
  mode: 'full',
  passed: 10,
  failed: o.failed ?? 0,
  checks: [
    ...(o.feel === false ? [] : [{ scope: 'feel', name: 'no more than 3 flashes in any second (WCAG 2.3.1)', ok: true, details: '' }]),
    { scope: 'first minute', name: 'a new player who touches nothing is still playing after 12 s', ok: true, details: '' },
    { scope: 'first minute', name: 'at most 25 words on screen before the first action', ok: (o.failed ?? 0) === 0, details: '' },
    { scope: 'balance', name: 'the first purchase within 3 min', ok: true, details: '' },
  ],
  infos: [{ scope: 'feel', name: 'feel: variety over time', details: 'distinct by 2 min: 3 · 5 min: 5', section: 'feel' }],
});
const LOOK = (keep: number, goal = 'chain sparks across the deck for a high score') => `# First look\n\n- Goal: ${goal}\n- Controls: click or tap the deck\n- Hook: the chains of sparks\n- Keep playing: ${keep}/5 — I want to see the bigger chains\n`;

/** Everything phases 1 and 2 ask for, written as the commands would */
const phase1and2 = (keep = 4) => {
  write(join(repo, 'docs', 'concept.md'), '# Forge Night — concept\n\n| Idea | Searches | Verdict |\n|---|---|---|\n| A. chains | site:crazygames.com chain | keep |\n\nRunner-up: B. a forge idle — forecast €12 vs €18.\n');
  write(join(qa, 'forecast.md'), '# Forge Night — money forecast (crazygames)\n\n**Expected value: €18** (months 1–3)\n');
  write(join(qa, 'uniqueness.md'), '# Forge Night — uniqueness\n\n**Score 82/100 — unique enough** (70+ passes `gp submission`)\n');
  write(join(qa, 'uniqueness.json'), { at: new Date().toISOString(), declared: true, event: 'chain', within: 20, demo: true, seenSec: 4.2, explained: { phrase: 'Chain the sparks', ok: true } });
  write(join(qa, 'qa-results.json'), QA());
  write(join(qa, 'first-look.md'), LOOK(keep));
};

beforeEach(fresh);

describe('the phases', () => {
  it('seven phases in order, each with its question, files, checks, review and exit; --check names them by number or id', () => {
    expect(PHASES.map((p) => p.id)).toEqual(['brief', 'concept', 'slice', 'session', 'content', 'release', 'live']);
    for (const p of PHASES) for (const k of ['question', 'review', 'exit'] as const) expect(p[k].length).toBeGreaterThan(10);
    for (const p of PHASES) expect(p.artifacts.length && p.automated.length).toBeTruthy();
    expect(phaseOf('2')?.id).toBe('slice');
    expect(phaseOf('Release')?.n).toBe(5);
    expect(phaseOf('9')).toBeNull();
  });

  it('a phase: n/a when nothing applies, fail over todo, advice does not count', () => {
    const c = (state: 'pass' | 'fail' | 'todo' | 'na', required = true) => ({ id: 'x', what: 'x', state, evidence: '', required, seen: false });
    expect(phaseState([c('na')])).toBe('na');
    expect(phaseState([c('pass'), c('todo'), c('fail')])).toBe('fail');
    expect(phaseState([c('pass'), c('todo')])).toBe('todo');
    expect(phaseState([c('pass'), c('fail', false)])).toBe('pass');
  });

  it('docs/guides/gdlc.md names every phase and the enforced gates', () => {
    const doc = readFileSync(join(ROOT, 'docs/guides/gdlc.md'), 'utf8');
    for (const p of PHASES) expect(doc).toContain(p.name);
    expect(doc).toContain('gp stage');
    expect(doc).toMatch(/first look[^\n]*≥ 4/i);
  });
});

describe('phase detection from the files', () => {
  it('nothing written yet: phase 1, every missing file is "not yet", no ТЗ → phase 0 n/a; no crash', async () => {
    const rep = await report();
    expect(rep.phases[0].state).toBe('na');
    expect(rep.current?.def.id).toBe('concept');
    expect(check(rep, 'concept.forecast').state).toBe('todo');
    expect(check(rep, 'slice.firstLook').state).toBe('todo');
    expect(check(rep, 'release.review').state).toBe('todo');
    expect(check(rep, 'live.answer').state).toBe('todo');
    expect(rep.behind).toEqual([]);
    expect(rep.next).toMatch(/docs\/concept\.md/);
    expect(stageMarkdown(rep)).toMatch(/^# Forge Night — design lifecycle/);
  });

  it('phase 1 met → the slice; the first look at 4/5 and the twist in play → the slice met, the game in phase 3', async () => {
    phase1and2(3);
    let rep = await report();
    expect(rep.phases[1].state).toBe('pass');
    expect(rep.current?.def.id).toBe('slice');
    expect(check(rep, 'slice.firstLook')).toMatchObject({ state: 'fail', enforced: true });
    expect(check(rep, 'slice.firstLook').evidence).toMatch(/keep playing 3\/5/);
    expect(check(rep, 'slice.twist').state).toBe('pass');
    write(join(qa, 'first-look.md'), LOOK(FIRST_LOOK_PASS));
    rep = await report();
    expect(rep.phases[2].state).toBe('pass');
    expect(rep.current?.def.id).toBe('session');
    // No qa/session.json: the 10 minutes are not yet measured
    expect(check(rep, 'session.tenMin').state).toBe('todo');
  });

  it('a goal "don\'t know" fails the slice whatever the score; a twist that never fires fails it too', async () => {
    phase1and2(5);
    write(join(qa, 'first-look.md'), LOOK(5, "don't know"));
    expect(check(await report(), 'slice.firstLook').state).toBe('fail');
    write(join(qa, 'first-look.md'), LOOK(5));
    write(join(qa, 'uniqueness.json'), { declared: true, event: 'chain', within: 20, demo: true, seenSec: null });
    expect(check(await report(), 'slice.twist').state).toBe('fail');
  });

  it('the session: a first stop before 10 min fails phase 3; a design.md makes the work reach phase 4 and flags the open gates behind it', async () => {
    phase1and2(4);
    write(join(qa, 'session.json'), { at: new Date().toISOString(), playedSec: 900, short: true, lines: { stop: '4:10 of play (break 2)', estimate: '≈ 6 min' } });
    let rep = await report();
    expect(check(rep, 'session.tenMin').state).toBe('fail');
    expect(rep.current?.def.id).toBe('session');
    expect(rep.behind).toEqual([]);
    write(join(dir, 'design.md'), '# Forge Night — design proposals\n\nDesigner: d · Date: 2026-10-22\n');
    rep = await report();
    expect(rep.reached).toBe(4);
    expect(rep.behind.map((p) => p.def.id)).toEqual(['session']);
    expect(check(rep, 'content.design').state).toBe('fail'); // malformed design.md
  });

  it('release: a QA run older than the code and a stale zip fail; quality.md missing is "not yet"', async () => {
    phase1and2(4);
    write(join(dir, 'art-showcase-1.0.0-submission.zip'), 'zip');
    const old = Date.now() - 7200_000;
    age([join(qa, 'qa-results.json'), join(dir, 'art-showcase-1.0.0-submission.zip')], old);
    write(join(qa, 'qa-results.json'), { ...QA(), date: new Date(old).toISOString() });
    age([join(qa, 'qa-results.json')], old);
    const rep = await report();
    expect(check(rep, 'release.qa').state).toBe('fail');
    expect(check(rep, 'release.qa').evidence).toMatch(/older than the code/);
    expect(check(rep, 'release.submission').state).toBe('fail');
    expect(check(rep, 'release.review').state).toBe('todo');
    expect(rep.reached).toBe(5);
  });

  it('a ТЗ in docs/gdd.md: phase 0 is "not yet" without its record, met when the loop is closed', async () => {
    write(join(repo, 'docs', 'gdd.md'), '# Forge Night\n\n§1 A night shift of sparks.\n');
    let rep = await report();
    expect(check(rep, 'brief.loop')).toMatchObject({ state: 'todo', enforced: true });
    expect(rep.current?.def.id).toBe('brief');
    expect(rep.next).toMatch(/gp brief .*docs\/gdd\.md/);
    write(join(repo, 'docs', 'gdd-review.md'), appendLog(recordTemplate('Forge Night', 'docs/gdd.md'), '- r1 critic: no further questions'));
    rep = await report();
    expect(rep.phases[0].state).toBe('pass');
  });
});

describe('the slice warning (built past the slice without the first look)', () => {
  it('warns from phase 4 on (a design.md, or the command entering it), not before; silent once the first look passes', async () => {
    phase1and2(4);
    rmSync(join(qa, 'first-look.md'));
    let rep = await report();
    expect(sliceWarning(rep)).toBeNull();
    expect(sliceWarning(rep, 4)).toMatch(/built past the vertical slice .*gp review .*--first-look/);
    write(join(dir, 'design.md'), '# x\n');
    rep = await report();
    expect(sliceWarning(rep)).toMatch(/without its gate/);
    write(join(qa, 'first-look.md'), LOOK(4));
    expect(sliceWarning(await report(), 5)).toBeNull();
  });
});

describe('phase 6: the portal\'s answers', () => {
  const approved = (bl: NonNullable<RecordedResult['basicLaunch']>): RecordedResult[] => [{ game: 'art-showcase', channel: 'crazygames', review: { verdict: 'approved', date: '2026-10-12' }, basicLaunch: bl }];
  const scores = { date: '2026-10-20', desktop: { playtime: { score: 3 }, d1: { score: 2 }, conversion: { score: 3 }, total: 8 }, mobile: { playtime: { score: 2 }, d1: { score: 2 }, conversion: { score: 1 }, total: 5 } };
  const df = join(tmp, 'design.md');

  it('the weakest metric per device', () => {
    expect(weakestMetrics(scores)).toEqual([
      { device: 'desktop', metric: 'D1', score: 2, total: 8 },
      { device: 'mobile', metric: 'conversion', score: 1, total: 5 },
    ]);
  });

  it('stopped with no patch inside the window and no design round after the scores: both open, the window closed is a fail', () => {
    writeFileSync(df, '# x\n\nDesigner: d · Date: 2026-10-14\n');
    const c = liveChecks(approved({ verdict: 'stopped', scores }), [{ version: '1.4.0', uploaded: '2026-10-21' }], { id: 'g', today: '2026-10-23', designFile: df });
    expect(c.map((x) => [x.id, x.state])).toEqual([['live.answer', 'pass'], ['live.metrics', 'pass'], ['live.nextRound', 'todo'], ['live.patch', 'fail']]);
    expect(c[1].evidence).toMatch(/mobile 5\/15: conversion 1\/5 weakest/);
  });

  it('a patch inside the window and a design round after the scores meet it; pending says the days left', () => {
    writeFileSync(df, '# x\n\nDesigner: d · Date: 2026-10-21\n');
    const ok = liveChecks(approved({ verdict: 'stopped', scores }), [{ version: '1.3.0', uploaded: '2026-10-16' }], { id: 'g', today: '2026-10-23', designFile: df });
    expect(ok.every((x) => x.state === 'pass')).toBe(true);
    const pending = liveChecks(approved({ verdict: 'pending' }), [], { id: 'g', today: '2026-10-23', designFile: df });
    expect(pending.find((x) => x.id === 'live.patch')).toMatchObject({ state: 'todo' });
    expect(pending.find((x) => x.id === 'live.patch')!.evidence).toMatch(/10 day\(s\) left/);
  });

  it('rejected: the answer fails and the next round is due; no record: "not yet"', () => {
    writeFileSync(df, '# x\n\nDate: 2026-10-01\n');
    const rej = liveChecks([{ game: 'g', channel: 'crazygames', review: { verdict: 'rejected', date: '2026-10-18', reason: 'The overall quality…' } }], [], { id: 'g', today: '2026-10-23', designFile: df });
    expect(rej.map((x) => x.state)).toEqual(['fail', 'todo']);
    expect(liveChecks([], [], { id: 'g', today: '2026-10-23', designFile: df })[0].state).toBe('todo');
  });

  it('read from publisher/results.yaml through stageReport', async () => {
    const rep = await report({ results: approved({ verdict: 'full-launch' }) });
    expect(rep.phases[6].state).toBe('pass');
  });
});

describe('the submission gate', () => {
  it('refuses a new submission while the first look is under 4/5 (CrazyGames) or the ТЗ review is open; an update only warns about the first look', async () => {
    phase1and2(3);
    let rep = await report();
    expect(submissionGates(rep, { update: false })).toMatchObject({ ok: false });
    expect(submissionGates(rep, { update: false }).detail).toMatch(/phase 2 .*keep playing 3\/5/);
    expect(submissionGates(rep, { update: true })).toMatchObject({ ok: true });
    expect(submissionGates(rep, { update: true }).detail).toMatch(/an update: a warning/);
    write(join(qa, 'first-look.md'), LOOK(4));
    rep = await report();
    expect(submissionGates(rep, { update: false }).ok).toBe(true);
    write(join(repo, 'docs', 'gdd.md'), '# Forge Night\n\n§1 A night shift.\n');
    rep = await report();
    const g = submissionGates(rep, { update: true });
    expect(g.ok).toBe(false);
    expect(g.detail).toMatch(/phase 0/);
  });

  it('gp submission\'s step reads the game\'s files: no first look → refused', async () => {
    phase1and2(4);
    rmSync(join(qa, 'first-look.md'));
    const loc = locateGame(dir);
    const r = checkGame(loc, 'dev');
    const step = await gdlcStep(loc, r.game!, { update: false });
    expect(step).toMatchObject({ field: 'Design gates (gp stage)', ok: false });
    expect(step.detail).toMatch(/no qa\/first-look\.md/);
    write(join(qa, 'first-look.md'), LOOK(5));
    expect((await gdlcStep(loc, r.game!, { update: false })).ok).toBe(true);
  });
});

describe('gp stage (the command)', () => {
  const gp = (...args: string[]) => {
    try {
      return { code: 0, out: execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), 'stage', ...args], { encoding: 'utf8', cwd: ROOT }) };
    } catch (e) {
      const x = e as { status: number; stdout: string };
      return { code: x.status, out: x.stdout };
    }
  };

  it('writes qa/stage.md; --check <phase> exits 1 while the gate isn\'t met, 0 when it is or does not apply', () => {
    phase1and2(4);
    const all = gp(dir);
    expect(all.code).toBe(0);
    expect(all.out).toMatch(/◀ the game is here/);
    expect(existsSync(join(qa, 'stage.md'))).toBe(true);
    expect(gp(dir, '--check', '0').code).toBe(0); // no ТЗ: n/a
    expect(gp(dir, '--check', 'slice').code).toBe(0);
    expect(gp(dir, '--check=session').code).toBe(1);
    expect(gp(dir, '--check', 'release').code).toBe(1);
    expect(gp(dir, '--check', '9').code).toBe(1);
    const json = JSON.parse(gp(dir, '--json').out);
    expect(json.current).toBe(3);
  }, 60_000);
});
