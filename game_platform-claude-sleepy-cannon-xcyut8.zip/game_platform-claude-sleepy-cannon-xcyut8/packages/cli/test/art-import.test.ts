// gp art import: an owner's finished pictures made into assets — the pixel steps on a small generated "car" (a red body,
// a blue emblem, a window, two wheels on a light grey studio gradient, a logo in the corner), then the whole run on a
// copy of the code example: files, game.yaml `source: import` and parts, provenance (`source: owner`), validate, re-runs.

import { cpSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { parse } from 'yaml';
import { cutCircle, decodeImage, encodeImage, eraseRects, importArt, loadCleanup, paintMask, patchRects, removeBackground, slugId, trimBox } from '../src/art-import.ts';
import { artChecks, generateArt, sha256 } from '../src/art.ts';
import { checkGame } from '../src/game.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import type { Rgba } from '../src/upscale.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-art-import-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

const W = 240, H = 140;
const WHEELS: [number, number, number][] = [[70, 100, 19], [170, 100, 19]];

/** The test picture: everything drawn with soft (covered) edges, the backdrop a gradient with a little noise */
function car(): Rgba {
  const d = new Uint8ClampedArray(W * H * 4);
  let seed = 7;
  const noise = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) % 7) - 3;
  const put = (x: number, y: number, c: number[], a: number) => {
    const p = (y * W + x) * 4;
    for (let k = 0; k < 3; k++) d[p + k] = d[p + k]! * (1 - a) + c[k]! * a;
  };
  const rect = (x0: number, y0: number, x1: number, y1: number, c: (x: number, y: number) => number[]) => {
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) put(x, y, c(x, y), 1);
  };
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const g = 224 - (y * 22) / H + noise();
      d.set([g, g, g + 2, 255], (y * W + x) * 4);
    }
  rect(4, 4, 24, 14, () => [20, 20, 20]); // a logo on the backdrop
  rect(30, 40, 210, 100, (_, y) => [215 - (y - 40), 35, 30]); // the body, shaded top to bottom
  rect(90, 45, 150, 58, () => [150, 200, 230]); // the window
  rect(108, 70, 116, 78, () => [30, 60, 220]); // the emblem
  for (const [cx, cy, r] of WHEELS)
    for (let y = cy - r - 2; y <= cy + r + 2; y++)
      for (let x = cx - r - 2; x <= cx + r + 2; x++) {
        const dd = Math.hypot(x - cx, y - cy);
        put(x, y, [40, 40, 44], Math.min(1, Math.max(0, r + 0.5 - dd)));
        put(x, y, [160, 160, 165], Math.min(1, Math.max(0, 6.5 - dd)));
      }
  return { w: W, h: H, d };
}
const px = (im: Rgba, x: number, y: number) => Array.from(im.d.subarray((y * im.w + x) * 4, (y * im.w + x) * 4 + 4));

describe('gp art import: the pixels', () => {
  it('floods the plain backdrop away from the borders, keeps the subject, and softens the edge', () => {
    const cut = removeBackground(car());
    expect(cut.key[0]).toBeGreaterThan(200);
    expect(cut.borderPlain).toBeGreaterThan(0.9);
    for (const [x, y] of [[0, 0], [W - 1, 0], [0, H - 1], [W - 1, H - 1], [120, 20], [120, 130]]) expect(px(cut.im, x, y)[3], `${x},${y}`).toBe(0);
    expect(px(cut.im, 60, 60)[3]).toBe(255); // the body
    expect(px(cut.im, 120, 50)[3]).toBe(255); // the window, inside: never reached from the border
    expect(px(cut.im, 70, 100)[3]).toBe(255); // a hub
    expect(px(cut.im, 10, 8)[3]).toBe(255); // the logo isn't the backdrop's colour: erase does it
    // A wheel's anti-aliased rim against the backdrop is half transparent, and its colour isn't lightened by it
    const rim = [...Array(6).keys()].map((i) => px(cut.im, 70, 118 + i)).find((p) => p[3]! > 0 && p[3]! < 255);
    expect(rim).toBeDefined();
    expect(rim![0]).toBeLessThan(120);
    eraseRects(cut.im, [[0, 0, 28, 18]]);
    expect(px(cut.im, 10, 8)[3]).toBe(0);
    const box = trimBox(cut.im)!;
    expect(box[0]).toBeGreaterThanOrEqual(26);
    expect(box[0]).toBeLessThanOrEqual(30);
    expect(box[1]).toBeGreaterThanOrEqual(36);
    expect(box[1] + box[3]).toBeGreaterThanOrEqual(119);
    expect(box[1] + box[3]).toBeLessThanOrEqual(124);
  });

  it('patches an emblem from its surroundings, cuts the wheels out, and masks the body\'s paint', () => {
    const im = car();
    patchRects(im, [[106, 68, 12, 12]]);
    const e = px(im, 112, 74);
    expect(e[0]).toBeGreaterThan(150);
    expect(e[2]).toBeLessThan(80);
    const body = removeBackground(im).im;
    const { part, centre } = cutCircle(body, WHEELS[0]!);
    expect(part.w).toBe(41);
    expect(centre).toEqual([70, 100]);
    expect(px(part, 20, 20).slice(0, 3).every((c) => c > 140)).toBe(true); // the hub at the part's centre
    expect(px(part, 20, 20)[3]).toBe(255);
    expect(px(part, 0, 0)[3]).toBe(0);
    expect(px(body, 70, 100)[3]).toBe(0); // the arch is empty
    expect(px(body, 70, 75)[3]).toBe(255); // the body above it isn't
    const m = paintMask(body);
    expect(Math.min(m.hue!, 360 - m.hue!)).toBeLessThan(10);
    expect(m.share).toBeGreaterThan(0.5);
    expect(px(m.mask, 60, 60)[3]).toBeGreaterThan(200);
    expect(px(m.mask, 120, 50)[3]).toBe(0); // the window
    expect(px(m.mask, 170, 100)[3]).toBe(0); // the other wheel (grey)
  });

  it('names assets after their files and reads cleanup.json strictly', () => {
    expect(slugId('Red Car (final).PNG')).toBe('red-car-final');
    expect(slugId('2CV.jpg')).toBe('img-2cv');
    expect(slugId('Citroën DS — side view, studio, high resolution.png')).toBe('citroen-ds-side-view-studio-hig');
    const f = join(tmp, 'bad.json');
    writeFileSync(f, JSON.stringify({ 'a.png': { tolerence: 3 } }));
    expect(() => loadCleanup(f)).toThrow(/unknown setting\(s\) tolerence/);
    writeFileSync(f, JSON.stringify({ 'a.png': { split: { wheels: [[1, 2]] } } }));
    expect(() => loadCleanup(f)).toThrow(/\[cx, cy, r\]/);
  });
});

describe('gp art import: the run', () => {
  const dir = join(tmp, 'g');
  const pics = join(tmp, 'pictures');
  let loc: ReturnType<typeof locateGame>;
  beforeAll(async () => {
    cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|dist-playgama|qa|node_modules|store|submission|assets)$/.test(f) });
    loc = locateGame(dir);
    mkdirSync(pics, { recursive: true });
    // The pictures are PNGs made by the same browser encoder the command uses; a backdrop picture goes in as a background
    const { chromium } = await import('playwright');
    const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
    const page = await browser.newPage();
    writeFileSync(join(pics, 'Red Car.png'), await encodeImage(page, car(), W, H, 'image/png'));
    writeFileSync(join(pics, 'backdrop.png'), await encodeImage(page, car(), W, H, 'image/png'));
    await browser.close();
    writeFileSync(join(pics, 'cleanup.json'), JSON.stringify({ 'Red Car.png': { erase: [[0, 0, 28, 18]], patch: [[106, 68, 12, 12]], split: { wheels: WHEELS }, recolor: true }, backdrop: { kind: 'background', size: [160, 90] } }));
  }, 60000);

  it('writes the WebP sprites, the parts, game.yaml, provenance and assets/index.ts — and gp validate is clean', async () => {
    const res = await importArt(loc, pics, { size: 128 });
    expect(res.warnings).toEqual([]);
    expect(res.made.sort()).toEqual(['backdrop.webp', 'red-car-paint.webp', 'red-car-wheel-1.webp', 'red-car-wheel-2.webp', 'red-car.webp']);
    const assets = join(dir, 'assets');
    expect(readFileSync(join(assets, 'red-car.webp')).subarray(8, 12).toString()).toBe('WEBP');
    const game = parse(readFileSync(loc.file, 'utf8'));
    const byId = Object.fromEntries(game.art.assets.map((a: { id: string }) => [a.id, a]));
    expect(byId['red-car']).toMatchObject({ kind: 'sprite', source: 'import', size: 128, prompt: "the owner's picture Red Car.png" });
    expect(byId.backdrop).toMatchObject({ kind: 'background', source: 'import', size: [160, 90] });
    expect(byId['red-car-wheel-1'].part.of).toBe('red-car');
    const prov = parse(readFileSync(join(assets, 'provenance.yaml'), 'utf8'));
    const body = prov.files['red-car.webp'];
    expect(body).toMatchObject({ source: 'owner', original: 'Red Car.png', originalSha256: sha256(readFileSync(join(pics, 'Red Car.png'))) });
    expect(body.date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(Math.max(...body.size)).toBe(128);
    expect(prov.files['backdrop.webp'].size).toEqual([160, 90]);
    expect(prov.files['red-car-paint.webp'].size).toEqual(body.size);
    // The wheels sit where they were, at the body's scale: front at ≈ 70 − 28 original px from the body's left edge
    const [wx, wy] = byId['red-car-wheel-1'].part.at;
    const k = body.scale;
    expect(Math.abs(wx - (70.5 - 28) * k)).toBeLessThan(2);
    expect(wy).toBeGreaterThan(body.size[1] * 0.6);
    expect(prov.files['red-car-wheel-1.webp'].size[0]).toBe(Math.round(41 * k));
    const index = readFileSync(join(assets, 'index.ts'), 'utf8');
    expect(index).toContain("import redCarWheel1 from './red-car-wheel-1.webp';");
    expect(index).toMatch(/export const PARTS = \{ redCarWheel1: \{ of: 'redCar', x: [\d.]+, y: [\d.]+ \}, redCarWheel2: .*redCarPaint: /);
    // The WebP keeps the cut-out: transparent corners, an opaque body
    const { chromium } = await import('playwright');
    const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
    const back = await decodeImage(await browser.newPage(), join(assets, 'red-car.webp'), undefined);
    await browser.close();
    expect(px(back.im, 0, 0)[3]).toBe(0);
    expect(px(back.im, back.im.w - 1, 0)[3]).toBe(0);
    expect(px(back.im, Math.round(back.im.w * 0.2), Math.round(back.im.h * 0.3))[3]).toBeGreaterThan(240);
    expect(res.preview && readFileSync(res.preview).subarray(1, 4).toString()).toBe('PNG');
    // Checked like generated art: only the missing art.keep (a new art section) is left
    expect(artChecks(loc).map((i) => i.code)).toEqual(['W_ART_KEEP']);
    const issues = checkGame(loc, 'dev').issues;
    expect(issues.filter((i) => i.severity === 'error')).toEqual([]);
    expect(issues.filter((i) => i.code.includes('_ART_')).map((i) => i.code)).toEqual(['W_ART_KEEP']);
    // gp art leaves the imports alone (no style board, no model)
    const gen = await generateArt(loc, { provider: 'mock' });
    expect(gen.made).toEqual([]);
    expect(gen.kept).toContain('red-car.webp');
  }, 60000);

  it('keeps what is unchanged, drops a part taken out of cleanup.json, and flags a changed file', async () => {
    expect((await importArt(loc, pics, { size: 128 })).made).toEqual([]);
    writeFileSync(join(pics, 'cleanup.json'), JSON.stringify({ 'Red Car.png': { erase: [[0, 0, 28, 18]], split: { wheels: [WHEELS[0]] } }, backdrop: { kind: 'background', size: [160, 90] } }));
    const res = await importArt(loc, pics, { size: 128 });
    expect(res.made).toEqual(['red-car.webp', 'red-car-wheel-1.webp']);
    expect(res.removed.sort()).toEqual(['red-car-paint.webp', 'red-car-wheel-2.webp']);
    const ids = parse(readFileSync(loc.file, 'utf8')).art.assets.map((a: { id: string }) => a.id);
    expect(ids.sort()).toEqual(['backdrop', 'red-car', 'red-car-wheel-1']);
    expect(artChecks(loc).map((i) => i.code)).toEqual(['W_ART_KEEP']);
    const f = join(dir, 'assets', 'backdrop.webp');
    writeFileSync(f, Buffer.concat([readFileSync(f), Buffer.from([0])]));
    expect(artChecks(loc).map((i) => i.code)).toContain('W_ART_PROVENANCE');
    // A part of nothing is an error
    writeFileSync(loc.file, readFileSync(loc.file, 'utf8') + '    - { id: ghost-wheel, kind: sprite, source: import, prompt: "a wheel of nothing", part: { of: no-car, at: [1, 2] } }\n');
    expect(artChecks(loc).map((i) => i.code)).toContain('E_ART_PART');
  }, 60000);

  it('refuses to overwrite a generated asset of the same id', async () => {
    const other = join(tmp, 'g2');
    cpSync(dir, other, { recursive: true });
    const l2 = locateGame(other);
    writeFileSync(l2.file, readFileSync(l2.file, 'utf8').replace(/- \{ id: backdrop, kind: background, source: import,/, '- { id: backdrop, kind: background,'));
    await expect(importArt(l2, pics, {})).rejects.toThrow(/already has an art asset "backdrop" that isn't imported/);
  });
});
