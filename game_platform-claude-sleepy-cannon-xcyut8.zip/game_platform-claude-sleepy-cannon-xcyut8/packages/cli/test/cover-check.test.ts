// The cover click-through check on synthetic thumbnails: each measure moves the way it should

import { describe, expect, it } from 'vitest';
import { COVER_THRESHOLDS, borderSides, colourfulness, formatVerdict, judgeCover, measureCover, packMask, silhouetteContrast, unpackMask, type Thumb } from '../src/cover-check.ts';

type RGB = [number, number, number];
const W = 200;
const H = 112;
function image(w: number, h: number, px: (x: number, y: number) => RGB): Thumb {
  const rgba = new Uint8Array(w * h * 4);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const [r, g, b] = px(x, y);
      const i = (y * w + x) * 4;
      rgba[i] = r;
      rgba[i + 1] = g;
      rgba[i + 2] = b;
      rgba[i + 3] = 255;
    }
  return { w, h, rgba };
}
const mask = (w: number, h: number, on: (x: number, y: number) => boolean) => {
  const m = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) m[y * w + x] = on(x, y) ? 1 : 0;
  return m;
};
// A deterministic "busy" texture: hue and value change every few pixels
const noise = (x: number, y: number): RGB => {
  const k = (Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1;
  const v = Math.abs(k);
  return [Math.round(255 * v), Math.round(255 * (1 - v)), Math.round(128 + 127 * Math.sin(x / 3))];
};

describe('colourfulness (Hasler–Süsstrunk)', () => {
  it('is 0 for grey and matches the formula for red | blue', () => {
    expect(colourfulness(image(10, 10, () => [128, 128, 128]))).toBeCloseTo(0, 5);
    // rg: 255 | 0 → μ 127.5, σ 127.5; yb: 127.5 | −255 → μ −63.75, σ 191.25
    const expected = Math.hypot(127.5, 191.25) + 0.3 * Math.hypot(127.5, 63.75);
    expect(colourfulness(image(10, 10, (x) => (x < 5 ? [255, 0, 0] : [0, 0, 255])))).toBeCloseTo(expected, 3);
  });
});

describe('measureCover', () => {
  it('a flat dark screenshot: near-black, flat, no detail, no colour — a low score with the fixes', () => {
    const m = measureCover(image(W, H, () => [14, 12, 24]));
    expect(m.darkShare).toBe(1);
    expect(m.flatShare).toBe(1);
    expect(m.edgeDensity).toBe(0);
    expect(m.colourfulness).toBeLessThan(10);
    const v = judgeCover(m);
    expect(v.score).toBeLessThan(COVER_THRESHOLDS.score);
    expect(v.partial).toBe(true);
    const text = formatVerdict('flat.png', v).join('\n');
    expect(text).toContain('nothing to decode');
    expect(text).toContain('not measured');
  });
  it('a big, outlined title reads; the same letters without an outline on a pale sky do not', () => {
    // Letters: three bars in the middle 60 % of the width; an outline band of 2 px round them
    const inLetter = (x: number, y: number) => y >= 30 && y < 70 && x >= 40 && x < 160 && (x - 40) % 40 < 28;
    const nearLetter = (x: number, y: number) => {
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) if (inLetter(x + dx, y + dy)) return true;
      return false;
    };
    const titleFill = mask(W, H, inLetter);
    const title = mask(W, H, nearLetter);
    const facts = { titleText: 'Forge Night', titleLines: 1, letterPx: 16 };
    const sky: RGB = [200, 225, 255];
    const outlined = image(W, H, (x, y) => (inLetter(x, y) ? [255, 250, 235] : nearLetter(x, y) ? [30, 12, 50] : sky));
    const bare = image(W, H, (x, y) => (inLetter(x, y) ? [255, 250, 235] : sky));
    const a = measureCover(outlined, { title, titleFill }, facts).title!;
    const b = measureCover(bare, { title, titleFill }, facts).title!;
    expect(a.contrast).toBeGreaterThan(10);
    expect(b.contrast).toBeLessThan(1.5);
    // The bars span x 40–147, the outline 2 px more each side
    expect(a.widthShare).toBeCloseTo(112 / W, 2);
    expect(a.words).toBe(2);
    const vb = judgeCover(measureCover(bare, { title, titleFill }, facts));
    expect(vb.checks.find((c) => c.id === 'titleContrast')!.score).toBe(0);
    expect(vb.partial).toBe(false);
  });
  it('without the masks a cover is a warning however well the picture scores (a small title and hero go unseen)', () => {
    const v = judgeCover(measureCover(image(W, H, (x, y) => (Math.hypot(x - 100, y - 56) < 30 ? [255, 210, 60] : [40 + x, 20, 160]))));
    expect(v.partial).toBe(true);
    expect(formatVerdict('legacy.png', v)[0]).toMatch(/^⚠ .*not measured/);
  });
  it('a small title is flagged by its width and letter size', () => {
    const titleFill = mask(W, H, (x, y) => y >= 10 && y < 16 && x >= 80 && x < 120);
    const m = measureCover(image(W, H, noise), { titleFill, title: titleFill }, { titleText: 'Starsilk', letterPx: 5 });
    const v = judgeCover(m);
    expect(v.checks.find((c) => c.id === 'titleWidth')!.score).toBe(0);
    expect(v.checks.find((c) => c.id === 'letterPx')!.score).toBe(0);
  });
  it('too many words in the title', () => {
    const t = mask(W, H, (x, y) => y > 20 && y < 60 && x > 20 && x < 180);
    const v = judgeCover(measureCover(image(W, H, noise), { title: t, titleFill: t }, { titleText: 'The Very Long Name Of A Game', letterPx: 14 }));
    expect(v.checks.find((c) => c.id === 'words')!.score).toBe(0);
  });
  it('a busy texture is cluttered; a few big shapes are not', () => {
    expect(measureCover(image(W, H, noise)).edgeDensity).toBeGreaterThan(COVER_THRESHOLDS.edgeDensity[3]);
    const shapes = measureCover(image(W, H, (x, y) => (Math.hypot(x - 60, y - 56) < 40 ? [255, 120, 30] : Math.hypot(x - 150, y - 50) < 30 ? [40, 220, 255] : [40, 30, 90])));
    expect(shapes.edgeDensity).toBeLessThan(COVER_THRESHOLDS.edgeDensity[2]);
    expect(shapes.edgeDensity).toBeGreaterThan(0);
  });
});

describe('the hero', () => {
  const disk = mask(W, H, (x, y) => Math.hypot(x - 70, y - 56) < 40);
  it('a light hero on a dark scene stands off it; a grey one on grey does not', () => {
    const pop = image(W, H, (x, y) => (disk[y * W + x] ? [240, 240, 250] : [30, 20, 70]));
    const flat = image(W, H, () => [120, 120, 120]);
    expect(silhouetteContrast(pop, disk)).toBeGreaterThan(50);
    expect(silhouetteContrast(flat, disk)).toBeLessThan(1);
  });
  it('an outline round the hero separates it even from a background of its own colour', () => {
    const ring = (x: number, y: number) => {
      const d = Math.hypot(x - 70, y - 56);
      return d >= 40 && d < 42;
    };
    const img = image(W, H, (x, y) => (ring(x, y) ? [20, 10, 40] : [200, 120, 60]));
    expect(silhouetteContrast(img, disk)).toBeGreaterThan(40);
  });
  it('its size is its share of the cover', () => {
    const m = measureCover(image(W, H, noise), { hero: disk });
    expect(m.subject.measured).toBe(true);
    expect(m.subject.area).toBeCloseTo((Math.PI * 40 * 40) / (W * H), 1);
  });
});

describe('borders', () => {
  it('finds a frame of one colour round the picture, and none on a full-bleed one', () => {
    const framed = image(W, H, (x, y) => (x < 8 || y < 8 || x >= W - 8 || y >= H - 8 ? [20, 30, 60] : noise(x, y)));
    expect(borderSides(framed)).toBe(4);
    expect(borderSides(image(W, H, noise))).toBe(0);
    expect(judgeCover(measureCover(framed)).checks.find((c) => c.id === 'border')!.score).toBe(0);
  });
});

describe('masks on disk', () => {
  it('pack and unpack round-trip', () => {
    const m = mask(37, 23, (x, y) => (x * 7 + y * 3) % 5 === 0);
    expect(Array.from(unpackMask(packMask(m), m.length))).toEqual(Array.from(m));
  });
});
