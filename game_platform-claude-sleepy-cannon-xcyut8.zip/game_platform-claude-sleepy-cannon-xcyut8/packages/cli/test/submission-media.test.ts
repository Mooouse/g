// gp submission --reuse-media: media older than the game's code are not reused (Kettlebot 1.1.0 shipped old covers);
// with --full (a game with an update history submitted anew) they are kept as they are

import { mkdirSync, mkdtempSync, rmSync, utimesSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { staleMedia } from '../src/paths.ts';
import { mediaPlan, newestSourceMs } from '../src/submission.ts';

const dir = mkdtempSync(join(tmpdir(), 'gp-media-'));
afterAll(() => rmSync(dir, { recursive: true, force: true }));

describe('newestSourceMs', () => {
  it("takes the game's own files and ignores its outputs", () => {
    for (const d of ['store', 'qa', 'src']) mkdirSync(join(dir, d), { recursive: true });
    const old = new Date('2026-01-01T00:00:00Z');
    const now = new Date('2026-10-01T00:00:00Z');
    const later = new Date('2026-12-01T00:00:00Z');
    writeFileSync(join(dir, 'game.yaml'), 'x');
    writeFileSync(join(dir, 'src', 'render.ts'), 'x');
    writeFileSync(join(dir, 'store', 'cover.png'), 'x');
    writeFileSync(join(dir, 'qa', 'report.md'), 'x');
    utimesSync(join(dir, 'game.yaml'), old, old);
    utimesSync(join(dir, 'src', 'render.ts'), now, now);
    utimesSync(join(dir, 'store', 'cover.png'), later, later);
    utimesSync(join(dir, 'qa', 'report.md'), later, later);
    expect(newestSourceMs(dir)).toBe(now.getTime());
  });

  it('ignores Markdown: a REPORT.md or quality.md written after the videos does not make them stale', () => {
    const later = new Date('2027-01-01T00:00:00Z');
    writeFileSync(join(dir, 'REPORT.md'), 'x');
    utimesSync(join(dir, 'REPORT.md'), later, later);
    expect(newestSourceMs(dir)).toBe(new Date('2026-10-01T00:00:00Z').getTime());
  });

  it('ignores the handover zips and the other targets\' upload folders (gp stage: a zip is not newer code)', () => {
    const later = new Date('2027-01-01T00:00:00Z');
    mkdirSync(join(dir, 'upload-playgama'), { recursive: true });
    for (const f of ['g-1.0.0-submission.zip', join('upload-playgama', 'index.html')]) {
      writeFileSync(join(dir, f), 'x');
      utimesSync(join(dir, f), later, later);
    }
    expect(newestSourceMs(dir)).toBe(new Date('2026-10-01T00:00:00Z').getTime());
  });
});

describe('staleMedia (gp review: Almus Gate\'s reviewer judged stale videos)', () => {
  it('lists the media older than the code', () => {
    const fresh = join(dir, 'store', 'cover.png');
    const old = join(dir, 'store', 'preview-1920x1080.mp4');
    writeFileSync(old, 'x');
    utimesSync(old, new Date('2026-09-01T00:00:00Z'), new Date('2026-09-01T00:00:00Z'));
    expect(staleMedia([fresh, old, join(dir, 'store', 'missing.mp4')], newestSourceMs(dir))).toEqual([old]);
  });
});

describe('mediaPlan: what gp submission renders', () => {
  const store = join(dir, 'plan-store');
  const media = ['cover-1920x1080.png', 'cover-800x1200.png', 'cover-800x800.png', 'preview-1920x1080.mp4', 'preview-1080x1920.mp4'];
  const code = new Date('2026-10-10T00:00:00Z').getTime();
  const put = (names: string[], when: string) => {
    mkdirSync(store, { recursive: true });
    for (const n of names) {
      writeFileSync(join(store, n), 'x');
      utimesSync(join(store, n), new Date(when), new Date(when));
    }
  };
  it('without --reuse-media: everything', () => {
    put(media, '2026-10-12T00:00:00Z');
    expect(mediaPlan(store, code, {})).toEqual({ covers: true, videos: 'all', note: null });
    expect(mediaPlan(store, code, { full: true })).toEqual({ covers: true, videos: 'all', note: null });
  });
  it('--reuse-media: nothing while the media are newer than the code; all again when they are older', () => {
    put(media, '2026-10-12T00:00:00Z');
    expect(mediaPlan(store, code, { reuseMedia: true })).toEqual({ covers: false, videos: null, note: null });
    put(['cover-800x800.png', 'preview-1080x1920.mp4'], '2026-10-01T00:00:00Z');
    const p = mediaPlan(store, code, { reuseMedia: true });
    expect(p).toMatchObject({ covers: true, videos: 'all' });
    expect(p.note).toContain('rendered again despite --reuse-media');
  });
  it('--full --reuse-media: old media are kept as they are (a note names them), only a missing one is rendered', () => {
    put(media, '2026-10-12T00:00:00Z');
    put(['cover-800x800.png', 'preview-1080x1920.mp4'], '2026-10-01T00:00:00Z');
    const p = mediaPlan(store, code, { reuseMedia: true, full: true });
    expect(p).toMatchObject({ covers: false, videos: null });
    expect(p.note).toMatch(/kept as they are \(--full --reuse-media\).*cover-800x800\.png, preview-1080x1920\.mp4/);
    // A missing portrait video: that orientation alone
    rmSync(join(store, 'preview-1080x1920.mp4'));
    expect(mediaPlan(store, code, { reuseMedia: true, full: true })).toMatchObject({ covers: false, videos: 'portrait' });
    rmSync(join(store, 'preview-1920x1080.mp4'));
    expect(mediaPlan(store, code, { reuseMedia: true, full: true })).toMatchObject({ videos: 'all' });
    rmSync(join(store, 'cover-800x1200.png'));
    expect(mediaPlan(store, code, { reuseMedia: true, full: true })).toMatchObject({ covers: true });
  });
});
