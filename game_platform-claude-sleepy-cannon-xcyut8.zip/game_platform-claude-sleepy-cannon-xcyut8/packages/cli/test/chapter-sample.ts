// A game's art with chapters, for assets/index.ts: chapters.test.ts checks that indexSource writes exactly
// packages/art/test/fixtures/chapter-index.ts, and the type checker checks that file against @gp/art/assets
// (chapter-index.typecheck.ts) — so what gp art writes is what createAssets takes.

import type { ArtSpec, IndexInfo } from '../src/art.ts';

export const SAMPLE_ART: ArtSpec = {
  style: 'the owner’s own finished pictures, a test',
  assets: [
    { id: 'garage', kind: 'background', prompt: 'the first garage', source: 'import' },
    { id: 'red-car', kind: 'sprite', prompt: 'the red coupe', source: 'import', chapter: 1 },
    { id: 'red-car-wheel-1', kind: 'sprite', prompt: 'its wheel', source: 'import', part: { of: 'red-car', at: [10, 20] } },
    { id: 'hero', kind: 'sprite', prompt: 'the mechanic', frames: ['walking', 'standing'], chapter: 2 },
  ],
};

export const SAMPLE_INFO: IndexInfo = { size: (f) => (f === 'red-car.webp' ? [720, 310] : f === 'hero.webp' ? [128, 256] : undefined), thumb: (id) => id === 'red-car' };

/** Where the generated sample lives */
export const SAMPLE_INDEX = new URL('../../art/test/fixtures/chapter-index.ts', import.meta.url);
