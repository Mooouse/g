// gp submission: an update carries patch notes of at most 2000 characters (owner, 2026-10-03: Dread Throne 1.2.0 had none)

import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { handoverZip, isUpdate, PATCH_NOTES_MAX, patchNotesStep } from '../src/submission.ts';

const root = mkdtempSync(join(tmpdir(), 'gp-notes-'));
afterAll(() => rmSync(root, { recursive: true, force: true }));

const game = (name: string, changelog?: string, notes?: string) => {
  const dir = join(root, name);
  mkdirSync(join(dir, 'submission'), { recursive: true });
  if (changelog !== undefined) writeFileSync(join(dir, 'CHANGELOG.md'), changelog);
  if (notes !== undefined) writeFileSync(join(dir, 'patch-notes.md'), notes);
  return { loc: { id: name, dir, file: join(dir, 'game.yaml') }, out: join(dir, 'submission') };
};
const TWO = '# X — changes\n\n## 1.1.0 — 2026-10-03\n\n- new\n\n## 1.0.0 — 2026-10-01\n\n- first\n';

describe('patch notes', () => {
  it('a first version needs none', () => {
    const g = game('first', '# X\n\n## 1.0.0 — 2026-10-01\n\n- first\n');
    expect(isUpdate(g.loc.dir)).toBe(false);
    expect(patchNotesStep(g.loc, g.out)).toBeNull();
    expect(patchNotesStep(game('nolog').loc, g.out)).toBeNull();
  });

  it('an update without patch-notes.md is not complete', () => {
    const g = game('missing', TWO);
    expect(isUpdate(g.loc.dir)).toBe(true);
    const step = patchNotesStep(g.loc, g.out)!;
    expect(step.ok).toBe(false);
    expect(step.detail).toContain('patch-notes.md');
  });

  it('copies notes within the limit and counts characters, not bytes', () => {
    const text = 'Новое: 16 строений, магазин, бесконечный режим.';
    const g = game('ok', TWO, `${text}\n\n`);
    const step = patchNotesStep(g.loc, g.out)!;
    expect(step.ok).toBe(true);
    expect(step.detail).toBe(`${[...text].length}/${PATCH_NOTES_MAX} characters`);
    expect(readFileSync(join(g.out, 'patch-notes.md'), 'utf8')).toBe(`${text}\n`);
  });

  it('refuses notes over the limit, and empty ones', () => {
    const long = game('long', TWO, 'я'.repeat(PATCH_NOTES_MAX + 1));
    expect(patchNotesStep(long.loc, long.out)!.ok).toBe(false);
    expect(existsSync(join(long.out, 'patch-notes.md'))).toBe(false);
    const empty = game('empty', TWO, '  \n');
    expect(patchNotesStep(empty.loc, empty.out)!.ok).toBe(false);
  });
});

describe('W_PATCH_NOTES in gp validate', () => {
  it('warns an update without patch notes, not a first version', async () => {
    const { mkdtempSync, writeFileSync, cpSync, rmSync } = await import('node:fs');
    const { tmpdir } = await import('node:os');
    const { join } = await import('node:path');
    const { checkGame } = await import('../src/game.ts');
    const { locateGame } = await import('../src/paths.ts');
    const dir = mkdtempSync(join(tmpdir(), 'gp-pn-'));
    try {
      const game = join(dir, 'code');
      cpSync(join(process.cwd(), 'docs/examples/code'), game, { recursive: true, filter: (p) => !/[\\/](qa|dist|upload|store|submission)([\\/]|$)/.test(p) });
      const codes = () => checkGame(locateGame(game), 'dev').issues.map((i) => i.code);
      writeFileSync(join(game, 'CHANGELOG.md'), '# Changelog\n\n## 1.0.0\n- first\n');
      expect(codes()).not.toContain('W_PATCH_NOTES');
      writeFileSync(join(game, 'CHANGELOG.md'), '# Changelog\n\n## 1.1.0\n- more\n\n## 1.0.0\n- first\n');
      expect(codes()).toContain('W_PATCH_NOTES');
      writeFileSync(join(game, 'patch-notes.md'), 'New levels.\n');
      expect(codes()).not.toContain('W_PATCH_NOTES');
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it('the handover zip of an update holds index.html, listing.md and the patch notes — nothing else (the owner, 2026-10-10)', async () => {
    const g = game('handover', TWO, 'Patch notes');
    for (const f of ['index.html', 'listing.md', 'patch-notes.md', 'forecast.md', 'cover-square-800x800.png']) writeFileSync(join(g.out, f), f);
    const up = await handoverZip(g.loc, g.out, '1.1.0', true);
    expect(up.names).toEqual(['index.html', 'listing.md', 'patch-notes.md']);
    expect(up.file).toBe(join(g.loc.dir, 'handover-1.1.0-update.zip'));
    expect(readFileSync(up.file).subarray(0, 2).toString()).toBe('PK');
    const full = await handoverZip(g.loc, g.out, '1.0.0', false);
    expect(full.names).toContain('forecast.md');
    expect(full.names).toContain('cover-square-800x800.png');
    expect(existsSync(join(g.loc.dir, 'handover-1.0.0-submission.zip'))).toBe(true);
  });
});
