// Asset chapters (game.yaml art.assets[].chapter): the import a later chapter's image gets in assets/index.ts, the data
// blocks the one-file upload carries after the game's script (and the files a multi-file build writes instead), the
// size report that counts the first load apart, the dev server's URLs, the thumbnails, and what gp validate says.
// The browser half — nothing of a later chapter decoded before the first frame, all of it after Play — is
// test-browser/chapters.test.ts.

import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { splitUpload } from '@gp/spec';
import { loadCleanup } from '../src/art-import.ts';
import { artChecks, artSpec, assetChapter, indexFor, indexSource, loadProvenance, sha256, staleThumbs, THUMB_PX, thumbFile, writeProvenance, writeThumbs, type ArtSpec } from '../src/art.ts';
import { chapterBlock, chapterOfImport, chapterOfPath, foldChapters } from '../src/chapters.ts';
import { checkGame } from '../src/game.ts';
import { SAMPLE_ART, SAMPLE_INDEX, SAMPLE_INFO } from './chapter-sample.ts';
import { ROOT, type GameLocation } from '../src/paths.ts';
import { buildPortal } from '../src/portal-build.ts';
import { LATER_CHAPTERS, sizeLines } from '../src/size.ts';
import { buildWeb, startDev } from '../src/vite.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-chapters-'));
// vitest sets NODE_ENV=test, which Vite would take over the production mode: as in gp
const env = process.env.NODE_ENV;
beforeAll(() => {
  delete process.env.NODE_ENV;
});
afterAll(() => {
  process.env.NODE_ENV = env;
  rmSync(tmp, { recursive: true, force: true });
});

describe('the chapter of an import and of a published file', () => {
  it('reads ?gp-chapter=N and chapters/N/…', () => {
    expect(chapterOfImport('./car.webp?gp-chapter=2')).toBe(2);
    expect(chapterOfImport('./car.webp?x=1&gp-chapter=3')).toBe(3);
    expect(chapterOfImport('./car.webp?gp-chapter=')).toBeNull();
    expect(chapterOfImport('./car.webp')).toBeNull();
    expect(chapterOfPath('chapters/1/car.webp')).toBe(1);
    expect(chapterOfPath('assets/index.js')).toBeNull();
    expect(chapterOfPath('chapters/1/x/car.webp')).toBeNull();
  });
});

describe('the one-file page with chapters', () => {
  const html = '<!doctype html><html><head><title>x</title><script type="module">boot()</script></head><body><canvas id="game"></canvas></body></html>';
  it('the script, async, at the end of the body, then the blocks in chapter order — data-n their base64 length', () => {
    const files = [
      { path: 'chapters/2/c.webp', chapter: 2, data: Buffer.from('ccc') },
      { path: 'chapters/1/b.webp', chapter: 1, data: Buffer.from('bbbb') },
      { path: 'chapters/1/a.webp', chapter: 1, data: Buffer.from('aa') },
    ];
    const out = foldChapters(html.replace('<script type="module">boot()</script>', ''), '<script type="module">boot()</script>', files);
    expect(out.indexOf('<script type="module" async>boot()</script>')).toBeGreaterThan(out.indexOf('<canvas id="game">'));
    const order = [...out.matchAll(/data-gp-asset="([^"]+)"/g)].map((m) => m[1]);
    expect(order).toEqual(['chapters/1/a.webp', 'chapters/1/b.webp', 'chapters/2/c.webp']);
    expect(out.indexOf('async>boot()')).toBeLessThan(out.indexOf('data-gp-asset'));
    expect(out.endsWith('</body></html>')).toBe(true);
    expect(chapterBlock(files[1]!)).toBe(`<script type="application/octet-stream" data-gp-asset="chapters/1/b.webp" data-gp-chapter="1" data-type="image/webp" data-n="8">${Buffer.from('bbbb').toString('base64')}</script>`);
    // The size model splits it back
    const parts = splitUpload(out);
    expect(parts.first).toContain('async>boot()');
    expect(parts.chapters.map((c) => [c.chapter, c.files])).toEqual([[1, 2], [2, 1]]);
  });
});

describe('assets/index.ts with chapters', () => {
  const art = SAMPLE_ART;
  it('a later chapter imported with ?gp-chapter=N (its frames and parts with it), CHAPTERS, SIZES, THUMBS and ASSETS', () => {
    expect(assetChapter(art, art.assets[2]!)).toBe(1);
    const src = indexSource(art, { size: (f) => (f === 'red-car.webp' ? [720, 310] : undefined), thumb: (id) => id === 'red-car' });
    expect(src).toContain("import garage from './garage.webp';");
    expect(src).toContain("import redCar from './red-car.webp?gp-chapter=1';");
    expect(src).toContain("import redCarWheel1 from './red-car-wheel-1.webp?gp-chapter=1';");
    expect(src).toContain("import heroF2 from './hero-2.webp?gp-chapter=2';");
    expect(src).toContain("import redCar_thumb from './thumbs/red-car.webp';");
    expect(src).toContain('export const CHAPTERS = { redCar: 1, redCarWheel1: 1, hero: 2 } as const;');
    expect(src).toContain('export const SIZES = { redCar: [720, 310] } as const;');
    expect(src).toContain('export const THUMBS = { redCar: redCar_thumb } as const;');
    expect(src).toContain('export const ASSETS = { urls: ART, frames: FRAMES, chapters: CHAPTERS, sizes: SIZES, thumbs: THUMBS } as const;');
    expect(src).toContain('createAssets(ASSETS)');
    // The sample the type checker checks against createAssets is what gp art writes now
    expect(indexSource(SAMPLE_ART, SAMPLE_INFO)).toBe(readFileSync(SAMPLE_INDEX, 'utf8'));
  });
  it('a game without chapters keeps the index it had (no new exports, no stale warning after the update)', () => {
    const plain: ArtSpec = { ...art, assets: art.assets.map(({ chapter: _c, ...a }) => a) };
    const src = indexSource(plain);
    expect(src).toContain('`const img = await loadImages(ART)`');
    expect(src).not.toMatch(/CHAPTERS|ASSETS|gp-chapter/);
  });
});

/** A copy of the code example with three imported "pictures": the garage before Play, two cars after it */
function chapterGame(name: string): GameLocation {
  const dir = join(tmp, name);
  cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) });
  const loc = { id: name, dir, file: join(dir, 'game.yaml') };
  writeFileSync(
    loc.file,
    readFileSync(loc.file, 'utf8') +
      `art:
  style: "the owner's own finished pictures (gp art import): a test of asset chapters"
  keep: ["the cars read as cars"]
  assets:
    - { id: garage, kind: background, source: import, prompt: "the first garage" }
    - { id: car-a, kind: sprite, source: import, prompt: "the first late car", chapter: 1 }
    - { id: car-b, kind: sprite, source: import, prompt: "the second late car", chapter: 1 }
`,
  );
  mkdirSync(join(dir, 'assets'), { recursive: true });
  const prov = loadProvenance(loc);
  for (const [id, n] of [['garage', 3000], ['car-a', 5000], ['car-b', 7000]] as const) {
    const buf = Buffer.alloc(n, id.charCodeAt(id.length - 1));
    writeFileSync(join(dir, 'assets', `${id}.webp`), buf);
    prov.files[`${id}.webp`] = { kind: 'sprite', model: 'the owner', prompt: id, style: null, size: [64, 32], bytes: n, sha256: sha256(buf), date: '2026-10-20', source: 'owner', original: `${id}.png`, originalSha256: sha256(buf) };
  }
  writeProvenance(loc, prov);
  writeFileSync(join(dir, 'assets', 'index.ts'), indexFor(loc, artSpec(loc)!));
  // The game uses them (else the bundler drops the module)
  writeFileSync(join(dir, 'main.ts'), `${readFileSync(join(dir, 'main.ts'), 'utf8')}\nimport { ASSETS } from './assets/index.ts';\n(globalThis as { gpTestAssets?: unknown }).gpTestAssets = ASSETS;\n`);
  return loc;
}

describe('a build with asset chapters', () => {
  it('the one-file upload: chapter 0 in the script, the later chapter as data blocks after it; the size report counts the first load', { timeout: 120_000 }, async () => {
    const loc = chapterGame('one-file');
    const r = checkGame(loc, 'dev');
    expect(r.issues.filter((i) => i.severity === 'error'), JSON.stringify(r.issues)).toEqual([]);
    const pkg = await buildPortal(loc, r.game!);
    expect(pkg.problems).toEqual([]);
    expect(readdirSync(join(loc.dir, 'upload')).sort()).toEqual(['index.html', 'size.json']);
    const html = readFileSync(join(loc.dir, 'upload/index.html'), 'utf8');
    const head = html.slice(0, html.indexOf('</head>'));
    expect(head).not.toContain('<script type="module"');
    const script = html.indexOf('<script type="module" async>');
    expect(script).toBeGreaterThan(html.indexOf('<canvas id="game">'));
    expect(script).toBeLessThan(html.indexOf('data-gp-asset'));
    // The garage in the script, as before; the cars only in their blocks, byte for byte
    const b64 = (id: string) => readFileSync(join(loc.dir, 'assets', `${id}.webp`)).toString('base64');
    const js = html.slice(script, html.indexOf('</script>', script));
    expect(js).toContain(b64('garage'));
    expect(js).not.toContain(b64('car-a'));
    expect(js).toMatch(/["'`]chapters\/1\/car-a\.webp["'`]/);
    const blocks = [...html.matchAll(/data-gp-asset="([^"]+)" data-gp-chapter="(\d)" data-type="([^"]+)" data-n="(\d+)">([^<]*)</g)];
    expect(blocks.map((m) => [m[1], m[2], m[3]])).toEqual([['chapters/1/car-a.webp', '1', 'image/webp'], ['chapters/1/car-b.webp', '1', 'image/webp']]);
    expect(blocks[1]![5]).toBe(b64('car-b'));
    expect(Number(blocks[1]![4])).toBe(b64('car-b').length);
    // The budget counts what Play waits for
    const size = pkg.size;
    expect(size.first!.gzip).toBeLessThan(size.gzipBytes);
    expect(size.first!.raw + size.chapters!.reduce((a, c) => a + c.rawBytes, 0)).toBeLessThanOrEqual(size.rawBytes);
    expect(size.chapters!.map((c) => [c.chapter, c.files])).toEqual([[1, 2]]);
    expect(size.chapters![0]!.inMs).toBeGreaterThanOrEqual(size.load.tappableMs - size.load.cpuMs) // never before the first load (the fixture's tiny images can round to the same ms);
    expect(size.packages.find((p) => p.name === LATER_CHAPTERS)!.bytes).toBe(size.chapters![0]!.rawBytes);
    const lines = sizeLines(size).join('\n');
    expect(lines).toMatch(/Chapters: before Play [\d.]+ KB gzipped .* after Play chapter 1 [\d.]+ KB gzipped in 2 images/);
    expect(lines).toContain('the later chapters arrive after it');
    // The build's own folder keeps them as files: a multi-file build of the same game
    expect(readdirSync(join(loc.dir, 'dist', 'chapters', '1')).sort()).toEqual(['car-a.webp', 'car-b.webp']);
  });

  it('a multi-file build (web, Android): the later chapter as files the game fetches by their relative path', { timeout: 120_000 }, async () => {
    const loc = chapterGame('multi-file');
    const out = await buildWeb(loc, 'dev', false, join(tmp, 'multi-out'));
    expect(readFileSync(join(out, 'chapters/1/car-b.webp'))).toEqual(readFileSync(join(loc.dir, 'assets/car-b.webp')));
    const js = readdirSync(join(out, 'assets')).filter((f) => f.endsWith('.js')).map((f) => readFileSync(join(out, 'assets', f), 'utf8')).join('\n');
    expect(js).toMatch(/["'`]chapters\/1\/car-b\.webp["'`]/);
    expect(js).not.toContain(readFileSync(join(loc.dir, 'assets/car-b.webp')).toString('base64'));
  });

  it('gp dev: a later chapter is a URL the dev server serves, not inlined', { timeout: 60_000 }, async () => {
    const loc = chapterGame('dev');
    const server = await startDev(loc, undefined, { frozen: true });
    try {
      const index = await server.transformRequest(`/@fs${join(loc.dir, 'assets/index.ts')}`);
      expect(index?.code).toMatch(/car-a\.webp\?(import&)?url"/);
      expect(index?.code).not.toMatch(/gp-chapter=/);
      const mod = await server.transformRequest(`/@fs${join(loc.dir, 'assets/car-a.webp')}?url`);
      expect(mod?.code).toMatch(/export default "\/@fs\/.*car-a\.webp"/);
    } finally {
      await server.close();
    }
  });
});

/**
 * A copy of the code example whose pictures come from an import tool of its own (no game.yaml art.assets): it writes its
 * own index outside assets/ — painted/index.ts with `?gp-chapter=2` imports, as Idle Garage Evolution's chapters.py
 * does — and feeds createAssets({ urls, chapters }) itself
 */
function ownToolGame(name: string): GameLocation {
  const dir = join(tmp, name);
  cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) });
  mkdirSync(join(dir, 'painted', 'sub'), { recursive: true });
  for (const [f, n] of [['shed.webp', 3000], ['car.webp', 5000], ['sub/car.webp', 6000]] as const) writeFileSync(join(dir, 'painted', f), Buffer.alloc(n, f.length));
  writeFileSync(
    join(dir, 'painted', 'index.ts'),
    `// Written by the game's own import tool
import { createAssets } from '@gp/art/assets';
import shed from './shed.webp';
import car from './car.webp?gp-chapter=2';
import car2 from './sub/car.webp?gp-chapter=2';

export const PICTURES = createAssets({ urls: { shed, car, car2 }, chapters: { car: 2, car2: 2 } });
`,
  );
  writeFileSync(join(dir, 'main.ts'), `${readFileSync(join(dir, 'main.ts'), 'utf8')}\nimport { PICTURES } from './painted/index.ts';\n(globalThis as { gpTestPictures?: unknown }).gpTestPictures = PICTURES;\n`);
  return { id: name, dir, file: join(dir, 'game.yaml') };
}

describe('a game with its own import tool: ?gp-chapter=N imports outside assets/index.ts', () => {
  it('the one-file upload carries them as data blocks after the script (a name taken twice gets -2); production drops the dev warning', { timeout: 120_000 }, async () => {
    // A dev server started by an earlier test sets NODE_ENV=development, which the build would take over
    delete process.env.NODE_ENV;
    const loc = ownToolGame('own-tool');
    const r = checkGame(loc, 'dev');
    expect(r.issues.filter((i) => i.severity === 'error'), JSON.stringify(r.issues)).toEqual([]);
    const pkg = await buildPortal(loc, r.game!);
    expect(pkg.problems).toEqual([]);
    const html = readFileSync(join(loc.dir, 'upload/index.html'), 'utf8');
    const b64 = (f: string) => readFileSync(join(loc.dir, 'painted', f)).toString('base64');
    const script = html.indexOf('<script type="module" async>');
    expect(script).toBeGreaterThan(0);
    const js = html.slice(script, html.indexOf('</script>', script));
    expect(js).toContain(b64('shed.webp'));
    expect(js).not.toContain(b64('car.webp'));
    expect(js).not.toContain(b64('sub/car.webp'));
    expect(js).toMatch(/["'`]chapters\/2\/car\.webp["'`]/);
    expect(js).toMatch(/["'`]chapters\/2\/car-2\.webp["'`]/);
    const blocks = [...html.matchAll(/data-gp-asset="([^"]+)" data-gp-chapter="(\d)" data-type="[^"]+" data-n="\d+">([^<]*)</g)];
    expect(blocks.map((m) => [m[1], m[2]]).sort()).toEqual([['chapters/2/car-2.webp', '2'], ['chapters/2/car.webp', '2']]);
    // Each picture byte for byte (which of the two gets -2 is the bundler's order)
    expect(blocks.map((m) => [b64('car.webp'), b64('sub/car.webp')].indexOf(m[3]!)).sort()).toEqual([0, 1]);
    expect(pkg.size.chapters!.map((c) => [c.chapter, c.files])).toEqual([[2, 2]]);
    // createAssets is in the upload, its dev-only early-chapter warning is not
    expect(js).toContain('could not be decoded');
    expect(js).not.toContain('Dev builds only, once');
    expect(js).not.toContain('[@gp/art/assets] ');
  });

  it('gp dev: the same imports are URLs the dev server serves', { timeout: 60_000 }, async () => {
    const loc = ownToolGame('own-tool-dev');
    const server = await startDev(loc, undefined, { frozen: true });
    try {
      const index = await server.transformRequest(`/@fs${join(loc.dir, 'painted/index.ts')}`);
      expect(index?.code).toMatch(/painted\/car\.webp\?(import&)?url"/);
      expect(index?.code).toMatch(/sub\/car\.webp\?(import&)?url"/);
      expect(index?.code).not.toMatch(/gp-chapter=/);
    } finally {
      await server.close();
    }
  });
});

describe('the thumbnails and what gp validate says', () => {
  it('thumbnails for the later chapters only, made again when the image changes, gone when it is back in chapter 0', { timeout: 60_000 }, async () => {
    const loc = chapterGame('thumbs');
    // Real pictures this time: the thumbnail is drawn from them
    const { chromium } = await import('playwright');
    const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
    try {
      const page = await b.newPage();
      await page.setContent('<body></body>');
      const png = async (w: number, h: number, color: string) =>
        Buffer.from(
          await page.evaluate(
            ({ w, h, color }) => {
              const c = document.createElement('canvas');
              c.width = w;
              c.height = h;
              const g = c.getContext('2d')!;
              g.fillStyle = color;
              g.fillRect(0, 0, w, h);
              return c.toDataURL('image/webp').split(',')[1]!;
            },
            { w, h, color },
          ),
          'base64',
        );
      writeFileSync(join(loc.dir, 'assets/car-a.webp'), await png(640, 320, '#c03030'));
      writeFileSync(join(loc.dir, 'assets/car-b.webp'), await png(300, 600, '#3060c0'));
      expect(staleThumbs(loc, artSpec(loc)!)).toEqual(['car-a', 'car-b']);
      expect(artChecks(loc).find((i) => i.code === 'W_ART_MISSING')?.message).toMatch(/2 later-chapter image\(s\) without a current thumbnail/);
      const prov = loadProvenance(loc);
      const made = await writeThumbs(loc, artSpec(loc)!, page, prov, '2026-10-20');
      expect(made).toEqual([thumbFile('car-a'), thumbFile('car-b')]);
      expect(prov.files[thumbFile('car-a')]!.size).toEqual([THUMB_PX, THUMB_PX / 2]);
      expect(prov.files[thumbFile('car-b')]!.size).toEqual([THUMB_PX / 2, THUMB_PX]);
      expect(existsSync(join(loc.dir, 'assets', thumbFile('garage')))).toBe(false);
      writeProvenance(loc, prov);
      expect(staleThumbs(loc, artSpec(loc)!)).toEqual([]);
      // Unchanged: kept
      expect(await writeThumbs(loc, artSpec(loc)!, page, prov, '2026-10-20')).toEqual([]);
      // car-b back in chapter 0: its thumbnail goes
      writeFileSync(loc.file, readFileSync(loc.file, 'utf8').replace('"the second late car", chapter: 1', '"the second late car"'));
      await writeThumbs(loc, artSpec(loc)!, page, prov, '2026-10-20');
      expect(existsSync(join(loc.dir, 'assets', thumbFile('car-b')))).toBe(false);
      expect(prov.files[thumbFile('car-b')]).toBeUndefined();
    } finally {
      await b.close();
    }
  });

  it('a part in another chapter than its sprite is an error (E_ART_CHAPTER); cleanup.json takes a chapter 0–9', () => {
    const loc = chapterGame('parts');
    writeFileSync(loc.file, readFileSync(loc.file, 'utf8') + '    - { id: car-a-wheel-1, kind: sprite, source: import, prompt: "a wheel of car-a", part: { of: car-a, at: [5, 5] }, chapter: 2 }\n');
    expect(artChecks(loc).find((i) => i.code === 'E_ART_CHAPTER')?.message).toContain('car-a-wheel-1 (chapter 2) is a part of car-a (chapter 1)');
    const f = join(tmp, 'cleanup.json');
    writeFileSync(f, JSON.stringify({ 'a.png': { chapter: 12 } }));
    expect(() => loadCleanup(f)).toThrow(/chapter is a whole number 0–9/);
    writeFileSync(f, JSON.stringify({ defaults: { chapter: 1 } }));
    expect(loadCleanup(f).defaults.chapter).toBe(1);
  });
});
