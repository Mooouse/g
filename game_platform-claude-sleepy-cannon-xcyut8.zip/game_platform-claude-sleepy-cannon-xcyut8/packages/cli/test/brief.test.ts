// gp brief: the ТЗ review — the record's parser and its states, the ТЗ check, whose turn it is, the round cap, where the
// files are, the briefs, and the command end to end on a sample ТЗ (packages/cli/test/fixtures/brief/gdd.md).

import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { KEPT_DIRS, KEPT_REPORTS } from '@gp/qa';
import {
  BRIEF_ANSWER,
  BRIEF_CAP,
  BRIEF_CATEGORIES,
  BRIEF_CRITIC,
  BRIEF_DIR,
  BRIEF_OWNER,
  QUESTIONS_PER_ROUND,
  answerBrief,
  appendLog,
  briefCommand,
  briefGenre,
  categoryOf,
  checkRecord,
  criticBrief,
  escalateAtCap,
  groundsIn,
  locateBrief,
  nextTurn,
  optionCount,
  ownerMarkdown,
  ownerQuestions,
  parseRecord,
  quotesIn,
  recordOf,
  recordTemplate,
  referencesIn,
  setRound,
  verifyTz,
  type BriefContext,
} from '../src/brief.ts';
import { ROOT } from '../src/paths.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-brief-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

const FIXTURE = join(ROOT, 'packages/cli/test/fixtures/brief/gdd.md');
const TZ = readFileSync(FIXTURE, 'utf8');

/** A record: the template, these items before the log, these log lines */
const record = (items: string, log: string[] = [], round = 1, cap = BRIEF_CAP) => {
  let t = setRound(recordTemplate('Glass District', 'docs/gdd.md', cap), round, cap).replace('## Log', `${items.trim()}\n\n## Log`);
  for (const l of log) t = appendLog(t, l);
  return t;
};

const Q1 = `## Q1 · scope · open
Q (r1): §6 puts 12 floors, 40 implants and 8 bosses into the first version while §8 says the slice is the first floor. Which is it?
Ground: lesson \`feel-over-features\`; W_SCOPE at more than 15 screens`;

const Q1_ANSWERED = `## Q1 · scope · answered
Q (r1): §6 puts 12 floors, 40 implants and 8 bosses into the first version while §8 says the slice is the first floor. Which is it?
Ground: lesson \`feel-over-features\`; W_SCOPE at more than 15 screens
A (r1, change): The first version is three floors and one boss; the rest goes to the updates.
ТЗ: §6 — "Первая версия: 3 этажа, 1 босс"`;

const OWNER_ITEM = `## Q2 · money · owner
Q (r1): §7 says no daily rewards and the only offer is a revive. What brings a player back tomorrow?
Ground: \`cg.full.returnNone\`; lesson \`daily-visible\`
A (r1, owner): The owner wrote "no daily rewards" by name: his call.
Options: 1) без ежедневного; 2) ежедневный контракт с таблицей дня
Recommend: 2) — даёт причину вернуться завтра
Владельцу: Добавить ежедневный контракт — один этаж дня с таблицей? Рекомендую: да.`;

describe('the record: format and parser', () => {
  it('the template parses: no items, no problems, round 1 of the cap; its example item is inside a comment', () => {
    const r = parseRecord(recordTemplate('Glass District', 'docs/gdd.md'));
    expect(r.title).toBe('Glass District');
    expect(r.tz).toBe('docs/gdd.md');
    expect(r.items).toEqual([]);
    expect(r.problems).toEqual([]);
    expect([r.round, r.cap, r.criticRound, r.noFurther]).toEqual([1, BRIEF_CAP, 0, null]);
  });

  it('each state comes from the history, and a heading that says otherwise is a problem', () => {
    const r = parseRecord(record(`${Q1_ANSWERED}\n\n${OWNER_ITEM}\n\n## Q3 · ambiguity · closed\nQ (r1): §5 gives no price for an implant and no credits per enemy: how many runs to the first one?\nGround: lesson \`balance\`\nA (r1, keep): The ТЗ says it in §5 already, the critic read an old copy.\nClose (r2): yes, §5 says it.`, [], 2));
    expect(r.items.map((i) => [i.id, i.category, i.state])).toEqual([
      ['Q1', 'scope', 'answered'],
      ['Q2', 'money', 'owner'],
      ['Q3', 'ambiguity', 'closed'],
    ]);
    expect(r.problems).toEqual([]);
    const bad = parseRecord(record(Q1_ANSWERED.replace('· answered', '· closed')));
    expect(bad.problems.map((p) => p.message).join('\n')).toMatch(/Q1: the heading says closed, its history says answered/);
    expect(bad.items[0].state).toBe('answered');
  });

  it('a dispute, then an answer to it; a long entry goes on over lines; bold labels and Russian labels count', () => {
    const t = record(
      `## Q1 · scope · answered\n**Q (r1):** §6 puts 12 floors and 8 bosses into the first version,\n  and §8 says the slice is the first floor: which?\n**Ground:** lesson \`feel-over-features\`\nОтвет (r1, change): Три этажа и один босс в первой версии.\nТЗ: §6 — «Первая версия: 3 этажа»\nDispute (r2): three floors are still 24 rooms to finish: which rooms, and how many enemy kinds?\nA (r2, change): Twenty rooms and six kinds of enemies, listed in the ТЗ.\nТЗ: §6 — "20 комнат, 6 видов врагов"`,
      ['- r1 critic: 1 new question', '- r1 maker: 1 change', '- r2 critic: 1 disputed'],
      2,
    );
    const r = parseRecord(t);
    expect(r.problems).toEqual([]);
    const it = r.items[0];
    expect(it.entries.map((e) => e.kind)).toEqual(['question', 'answer', 'dispute', 'answer']);
    expect(it.entries[0].text).toMatch(/first version, and §8 says/);
    expect(it.entries[1].answer).toBe('change');
    expect(it.state).toBe('answered');
    expect(r.criticRound).toBe(2);
    expect(r.log.map((l) => l.actor)).toEqual(['critic', 'maker', 'critic']);
  });

  it('a question needs a ground that names a platform fact; the critic owns those problems', () => {
    const none = parseRecord(record('## Q1 · scope · open\nQ (r1): §6 puts 12 floors and 8 bosses into the first version: which floor is the slice?'));
    expect(none.problems[0]).toMatchObject({ who: 'critic', item: 'Q1' });
    expect(none.problems[0].message).toMatch(/no "Ground: …"/);
    const vague = parseRecord(record('## Q1 · scope · open\nQ (r1): §6 puts 12 floors and 8 bosses into the first version: which floor is the slice?\nGround: it feels like too much'));
    expect(vague.problems[0].message).toMatch(/names no platform fact/);
    expect(groundsIn('lesson `session-length`, W_SESSION_SHORT, cg.full.gateMin, 400 KB, docs/guides/first-minute.md, `mountResults`, Candle Crypt', { games: ['Candle Crypt'] })).toEqual(
      expect.arrayContaining(['W_SESSION_SHORT', 'cg.full.gateMin', 'lesson session-length', 'budget', 'docs/guides/first-minute.md', 'mountResults', 'Candle Crypt']),
    );
    expect(groundsIn('it feels like too much')).toEqual([]);
  });

  it('a change needs a ТЗ line with a quote; an owner item needs 2–3 options, a recommendation and the question — in Russian', () => {
    const noTz = parseRecord(record(Q1_ANSWERED.replace(/\nТЗ: .*$/m, '')));
    expect(noTz.problems.map((p) => p.message).join('\n')).toMatch(/a change with no "ТЗ:" line/);
    const noQuote = parseRecord(record(Q1_ANSWERED.replace(/ТЗ: .*$/m, 'ТЗ: §6 rewritten')));
    expect(noQuote.problems.map((p) => p.message).join('\n')).toMatch(/quotes nothing/);
    const bare = parseRecord(record(OWNER_ITEM.split('\n').slice(0, 4).join('\n')));
    const msgs = bare.problems.map((p) => p.message).join('\n');
    expect(msgs).toMatch(/Options/);
    expect(msgs).toMatch(/Recommend/);
    expect(msgs).toMatch(/Владельцу/);
    expect(bare.problems.every((p) => p.who === 'maker')).toBe(true);
    const english = parseRecord(record(OWNER_ITEM.replace(/^Владельцу: .*$/m, 'Владельцу: Should we add a daily contract?')));
    expect(english.problems.map((p) => p.message).join('\n')).toMatch(/not in Russian/);
    const one = parseRecord(record(OWNER_ITEM.replace(/^Options: .*$/m, 'Options: 1) только ежедневный контракт')));
    expect(one.problems.map((p) => p.message).join('\n')).toMatch(/1 option\(s\) — 2 or 3/);
    expect([optionCount('1) а; 2) б; 3) в'), optionCount('а) да б) нет'), optionCount('none')]).toEqual([3, 2, 0]);
    const noKind = parseRecord(record(Q1_ANSWERED.replace('A (r1, change)', 'A (r1)')));
    expect(noKind.problems.map((p) => p.message).join('\n')).toMatch(/the answer has no kind/);
  });

  it('a wrong category, a duplicate id, a round past the header, a second question in one item, a placeholder left in', () => {
    const r = parseRecord(record(`${Q1.replace('· scope ·', '· vibes ·')}\n\n${Q1}\nQ (r1): and another question in the same item, about the bosses of §6?\n\n## Q2 · ambiguity · open\nQ (r3): §5 gives no price for an implant: how many runs to the first one?\nGround: lesson \`balance\`\n\n## Q3 · scope · open\nQ (r1): <the question: quote the ТЗ, say what clashes>\nGround: lesson \`balance\``));
    const m = r.problems.map((p) => p.message).join('\n');
    expect(m).toMatch(/"vibes" is not a category/);
    expect(m).toMatch(/Q1 is there twice/);
    expect(m).toMatch(/a second question in one item/);
    expect(m).toMatch(/round 3 is past the record's round \(1\)/);
    expect(m).toMatch(/placeholder/);
    expect(categoryOf('Trademarks')?.id).toBe('originality');
    expect(categoryOf('first 10 min')?.id).toBe('first-10min');
    expect(categoryOf('vibes')).toBeNull();
    expect(BRIEF_CATEGORIES.map((c) => c.id)).toEqual(['scope', 'contradiction', 'feasibility', 'portal', 'money', 'originality', 'ambiguity', 'first-30s', 'first-10min']);
  });

  it(`a round asks ${QUESTIONS_PER_ROUND} new questions at most, and «no further questions» with new questions in the same round is a problem`, () => {
    const many = Array.from({ length: QUESTIONS_PER_ROUND + 1 }, (_, k) => `## Q${k + 1} · scope · open\nQ (r1): §6 puts ${k + 2} floors into the first version: which one is the slice?\nGround: W_SCOPE`).join('\n\n');
    expect(parseRecord(record(many)).problems.map((p) => p.message).join('\n')).toMatch(/asks 13 new questions/);
    const both = parseRecord(record(Q1, ['- r1 critic: no further questions']));
    expect(both.problems.map((p) => p.message).join('\n')).toMatch(/one or the other/);
    expect(both.noFurther).toBe(1);
  });
});

describe('the ТЗ check: was it changed where the answers say', () => {
  const rec = (tzLine: string, round = 1) => parseRecord(record(Q1_ANSWERED.replace(/ТЗ: .*$/m, tzLine).replace('A (r1', `A (r${round}`), [], round));

  it('the quote must be in the ТЗ (markdown, case, spaces and «» against "" don\'t matter)', () => {
    expect(verifyTz(rec('ТЗ: §6 — "Первая версия: 3 этажа, 1 босс"'), '## 6\n**Первая версия:** 3 этажа,\n1 босс (на 3-м)')).toEqual([]);
    const miss = verifyTz(rec('ТЗ: §6 — "Первая версия: 3 этажа, 1 босс"'), '12 этажей башни, 8 боссов');
    expect(miss[0]).toMatchObject({ who: 'maker', item: 'Q1' });
    expect(miss[0].message).toMatch(/the ТЗ doesn't — edit the ТЗ/);
  });

  it('…and new since the ТЗ the critic read that round; a removal must be gone, and have been there', () => {
    const snap = { 1: 'Первая версия: 3 этажа, 1 босс — уже было' };
    expect(verifyTz(rec('ТЗ: §6 — "Первая версия: 3 этажа, 1 босс"'), 'Первая версия: 3 этажа, 1 босс', snap)[0].message).toMatch(/already in the ТЗ the critic read in round 1/);
    expect(verifyTz(rec('ТЗ: §6 — "Первая версия: 3 этажа, 1 босс"'), 'Первая версия: 3 этажа, 1 босс', { 1: '12 этажей' })).toEqual([]);
    expect(verifyTz(rec('ТЗ: §6 — removed "полная озвучка диалогов"'), 'диалоги текстом', { 1: 'полная озвучка диалогов' })).toEqual([]);
    expect(verifyTz(rec('ТЗ: §6 — removed "полная озвучка диалогов"'), 'и полная озвучка диалогов')[0].message).toMatch(/still there/);
    expect(verifyTz(rec('ТЗ: §6 — removed "полная озвучка диалогов"'), 'диалоги текстом', { 1: 'диалоги текстом' })[0].message).toMatch(/didn't have it either/);
    expect(verifyTz(rec('ТЗ: §6 — "Первая версия: 3 этажа, 1 босс" (superseded by Q7)'), 'нет такого текста')).toEqual([]);
  });

  it('only an item\'s last ТЗ line is checked; a quote may hold «…»', () => {
    expect(quotesIn('§4 — "кнопки «удар» и «фокус» справа" and «стик «слева» внизу»')).toEqual(['кнопки «удар» и «фокус» справа', 'стик «слева» внизу']);
    const t = record(`${Q1_ANSWERED}\nDispute (r2): three floors are still too many for the first submission: which one?\nA (r2, change): One floor and its boss, the rest in the updates.\nТЗ: §6 — "Первая версия: один этаж и его босс"`, [], 2);
    expect(checkRecord(t, { tz: 'Первая версия: один этаж и его босс' }).problems).toEqual([]);
  });
});

describe('whose turn', () => {
  const at = (items: string, log: string[] = [], round = 1, cap = BRIEF_CAP) => nextTurn(parseRecord(record(items, log, round, cap)));

  it('critic → maker → critic → … → done when the critic has no further questions', () => {
    expect(nextTurn(null)).toMatchObject({ who: 'critic', round: 1 });
    expect(nextTurn(parseRecord(recordTemplate('X', 'docs/gdd.md')))).toMatchObject({ who: 'critic', round: 1 });
    expect(at(Q1, ['- r1 critic: 1 new question'])).toMatchObject({ who: 'maker', round: 1, items: ['Q1'] });
    expect(at(Q1_ANSWERED, ['- r1 critic: 1 new question', '- r1 maker: 1 change'])).toMatchObject({ who: 'critic', round: 2, items: ['Q1'] });
    const closed = `${Q1_ANSWERED.replace('· answered', '· closed')}\nClose (r2): §6 now names the slice.`;
    // Everything ruled on, but round 2 didn't say it has no more: the critic again
    expect(at(closed, [], 2)).toMatchObject({ who: 'critic', round: 3 });
    expect(at(closed, ['- r2 critic: 1 closed — no further questions'], 2)).toMatchObject({ who: 'done', round: 2 });
    // An owner item doesn't wait for the owner
    expect(at(`${closed}\n\n${OWNER_ITEM}`, ['- r2 critic: no further questions'], 2).who).toBe('done');
    // A critic who says so at once, with no questions: done
    expect(nextTurn(parseRecord(appendLog(recordTemplate('X', 'docs/gdd.md'), '- r1 critic: no further questions')))).toMatchObject({ who: 'done', round: 1 });
  });

  it('the critic fixes its own entries first; the maker its answers, with the items they are about', () => {
    expect(at('## Q1 · scope · open\nQ (r1): §6 puts 12 floors and 8 bosses into the first version: which is the slice?')).toMatchObject({ who: 'critic', round: 1, items: ['Q1'] });
    const t = at(Q1_ANSWERED.replace(/\nТЗ: .*$/m, ''), ['- r1 maker: 1 change']);
    expect(t).toMatchObject({ who: 'maker', round: 1, items: ['Q1'] });
    expect(t.fix[0].message).toMatch(/a change with no "ТЗ:" line/);
  });

  it('the round cap: after the critic\'s last round it is done, and a dispute raised in it goes to the owner', () => {
    const disputed = `${Q1_ANSWERED.replace('· answered', '· disputed')}\nDispute (r2): three floors are still too many for a first submission: which one floor?`;
    const rec = parseRecord(record(disputed, ['- r2 critic: 1 disputed'], 2, 2));
    expect(nextTurn(rec)).toMatchObject({ who: 'maker', round: 2 });
    const esc = escalateAtCap(record(disputed, ['- r2 critic: 1 disputed'], 2, 2), rec);
    expect(esc.escalated).toEqual(['Q1']);
    expect(esc.text).toMatch(/^## Q1 · scope · owner$/m);
    expect(esc.text).toMatch(/^Escalated \(r2\): the round cap \(2\)/m);
    expect(esc.text).toMatch(/^- r2 gp brief: the round cap — Q1 disputed at the last round → owner$/m);
    const after = parseRecord(esc.text);
    expect(after.items[0].state).toBe('owner');
    // The maker writes the owner's question, then it is done
    expect(nextTurn(after)).toMatchObject({ who: 'maker', round: 2, items: ['Q1'] });
    const filled = parseRecord(esc.text.replace(/(under this line\.)/, '$1\nOptions: 1) один этаж; 2) три этажа\nRecommend: 1) — срез быстрее\nВладельцу: Первая версия — один этаж или три? Рекомендую один.'));
    expect(filled.problems).toEqual([]);
    expect(nextTurn(filled)).toMatchObject({ who: 'done', round: 2 });
    expect(ownerQuestions(filled)[0]).toMatchObject({ id: 'Q1', ask: 'Первая версия — один этаж или три? Рекомендую один.', recommend: '1) — срез быстрее' });
    // Below the cap a dispute is the maker's to answer
    const below = parseRecord(record(disputed, [], 2, 5));
    expect(escalateAtCap(record(disputed, [], 2, 5), below).escalated).toEqual([]);
    // At the cap, answers never ruled on stay answered: done all the same
    expect(at(Q1_ANSWERED.replace('A (r1', 'A (r2'), ['- r2 critic: 1 new question'], 2, 2)).toMatchObject({ who: 'done', items: ['Q1'] });
  });

  it('setRound and appendLog edit the header and the log', () => {
    const t = setRound(recordTemplate('X', 'docs/gdd.md', 5), 3, 5);
    expect(parseRecord(t)).toMatchObject({ round: 3, cap: 5 });
    expect(setRound('# X — ТЗ review\n\n## Log\n', 2, 4)).toMatch(/^Round: 2 of 4$/m);
    const l = appendLog(appendLog(t, '- r1 critic: 2 new questions'), '- r1 maker: 2 change');
    expect(parseRecord(l).log.map((x) => x.text)).toEqual(['2 new questions', '2 change']);
    expect(appendLog('# X\n', '- r1 critic: no further questions')).toMatch(/## Log\n\n- r1 critic: no further questions\n$/);
  });
});

describe('where the files are', () => {
  it('a game repository: its docs/gdd.md, the record beside it, the briefs in the game\'s qa/', () => {
    const repo = join(tmp, 'repo');
    mkdirSync(join(repo, 'games/glass/'), { recursive: true });
    mkdirSync(join(repo, 'docs'), { recursive: true });
    writeFileSync(join(repo, 'games/glass/game.yaml'), 'id: glass\ntitle: "Glass District"\nchannel: crazygames\nmoney: { genre: TODO }\n');
    writeFileSync(join(repo, 'docs/gdd.md'), TZ);
    const byGame = locateBrief(join(repo, 'games/glass'));
    expect(byGame).toMatchObject({ tz: join(repo, 'docs/gdd.md'), record: join(repo, 'docs/gdd-review.md'), work: join(repo, 'games/glass/qa') });
    expect(byGame.game).toMatchObject({ id: 'glass', title: 'Glass District', channel: 'crazygames', genre: null });
    expect(locateBrief(join(repo, 'docs/gdd.md')).game?.id).toBe('glass');
    expect(locateBrief(join(repo, 'docs/gdd.md'), { out: join(tmp, 'out') }).work).toBe(join(tmp, 'out'));
    const loose = join(tmp, 'loose');
    mkdirSync(loose, { recursive: true });
    writeFileSync(join(loose, 'brief.md'), TZ);
    expect(locateBrief(join(loose, 'brief.md'))).toMatchObject({ record: join(loose, 'brief-review.md'), work: join(loose, 'qa'), game: null });
    const bare = join(tmp, 'bare/games/x');
    mkdirSync(bare, { recursive: true });
    writeFileSync(join(bare, 'game.yaml'), 'id: x\n');
    expect(() => locateBrief(bare)).toThrow(/No ТЗ for x: looked at/);
    expect(recordOf('/a/docs/gdd.md')).toBe('/a/docs/gdd-review.md');
    // How the briefs tell the agents to run it: scripts/gp.sh in a game's repository, npm run gp from the platform
    expect(briefCommand(byGame)).toBe(`npm run gp -- brief ${join(repo, 'docs/gdd.md')}`);
    mkdirSync(join(repo, 'scripts'), { recursive: true });
    writeFileSync(join(repo, 'scripts/gp.sh'), '#!/usr/bin/env bash\n');
    expect(briefCommand(byGame)).toBe('scripts/gp.sh brief docs/gdd.md');
  });

  it('gp qa keeps the briefs and the round copies of the ТЗ', () => {
    for (const f of [BRIEF_CRITIC, BRIEF_ANSWER, BRIEF_OWNER]) expect(KEPT_REPORTS).toContain(f);
    expect(KEPT_DIRS).toContain(BRIEF_DIR);
  });
});

describe('the facts and the briefs', () => {
  it('the genre from the ТЗ\'s words (a sub-genre named with its genre wins), --genre and game.yaml first', () => {
    expect(briefGenre(undefined, null, TZ)?.id).toBe('roguelite');
    expect(briefGenre('puzzle', null, TZ)).toMatchObject({ id: 'puzzle', from: '--genre' });
    expect(briefGenre(undefined, { id: 'g', dir: '.', title: null, channel: null, genre: 'idle' }, TZ)).toMatchObject({ id: 'idle', from: 'game.yaml money.genre' });
    expect(briefGenre(undefined, null, 'A game about gardens.')).toBeNull();
  });

  it('the names a ТЗ borrows: the games it points at, protected names, taken concepts', () => {
    const r = referencesIn(TZ);
    expect(r.named).toEqual(expect.arrayContaining(['Katana Zero', 'Hotline Miami', 'Hades']));
    expect(referencesIn('Craft blocks like Minecraft does, a survivors-like with germs').brands).toContain('minecraft');
    expect(referencesIn('A survivors-like with germs and hordes of microbes.').taken.length).toBeGreaterThan(0);
    expect(referencesIn('как в Hollow Knight, в духе Dead Cells').named).toEqual(['Hollow Knight', 'Dead Cells']);
  });

  const ctx = (over: Partial<BriefContext> = {}): BriefContext => ({
    paths: { tz: '/r/docs/gdd.md', record: '/r/docs/gdd-review.md', work: '/r/games/g/qa', game: null },
    title: 'Glass District',
    channel: 'crazygames',
    genre: briefGenre(undefined, null, TZ),
    tzText: TZ,
    results: [
      { game: 'candle-crypt', title: 'Candle Crypt', channel: 'crazygames', review: { verdict: 'rejected', reason: 'The overall quality of the game does not yet meet the expectations of our platform' } },
      { game: 'petri-panic', title: 'Petri Panic', channel: 'crazygames', review: { verdict: 'rejected', reason: 'The concept is quite close to existing titles' } },
      { game: 'hang-the-moon', title: 'Hang the Moon', channel: 'crazygames', review: { verdict: 'approved' }, basicLaunch: { verdict: 'stopped', avgPlaytimeMin: 4.8 } },
    ],
    date: '2026-10-23',
    cap: BRIEF_CAP,
    command: 'npm run gp -- brief docs/gdd.md',
    ...over,
  });

  it("the critic's brief: the round, the categories, the format, and the platform's facts to ground each question in", async () => {
    const md = await criticBrief(ctx(), null, nextTurn(null));
    expect(md).toMatch(/^# Glass District — the ТЗ critic's brief, round 1 of 5/);
    expect(md).toMatch(/did not write this ТЗ and will not build the game/);
    expect(md).toMatch(/Задай вопрос о критике ТЗ/);
    for (const c of BRIEF_CATEGORIES) expect(md).toContain(`\`${c.id}\``);
    expect(md).toMatch(/numbered from \*\*Q1\*\*/);
    expect(md).toMatch(/400 KB gzipped/);
    expect(md).toMatch(/Rejected 1× "The overall quality/);
    expect(md).toMatch(/Hang the Moon: playtime 4\.8 min/);
    expect(md).toMatch(/cg\.full\.gateMin/);
    expect(md).toMatch(/Roguelite \(Action\)/);
    expect(md).toMatch(/`seed`: a run seed/);
    expect(md).toMatch(/\*\*Katana Zero\*\*/);
    expect(md).toMatch(/\| `session-length` \|/);
    expect(md).toMatch(/Known gaps/);
    // Its example item parses (the format it teaches is the one --check reads)
    const example = md.match(/```markdown\n([\s\S]*?)```/)![1];
    expect(parseRecord(record(example)).problems).toEqual([]);
  });

  it('round 2+: the answers to rule on, the owner items to check, what is settled', async () => {
    const rec = parseRecord(record(`${Q1_ANSWERED}\n\n${OWNER_ITEM}`, ['- r1 critic: 2 new questions', '- r1 maker: 1 change, 1 owner']));
    const turn = nextTurn(rec);
    const md = await criticBrief(ctx(), rec, turn);
    expect(md).toMatch(/round 2 of 5/);
    expect(md).toMatch(/### 1\. Rule on every answer \(1\)/);
    expect(md).toMatch(/\*\*Q1 · scope · answered\*\*/);
    expect(md).toMatch(/sent 1 item\(s\) to the owner: Q2/);
    expect(md).toMatch(/numbered from \*\*Q3\*\*/);
    const last = await criticBrief(ctx({ cap: 2 }), rec, turn);
    expect(last).toMatch(/This is the last round/);
  });

  it("the maker's brief: the items with their history, the three kinds of answer, the fixes first", () => {
    const rec = parseRecord(record(`${Q1}\n\n${Q1_ANSWERED.replace('Q1', 'Q2').replace(/\nТЗ: .*$/m, '')}`, ['- r1 critic: 2 new questions']));
    const turn = nextTurn(rec);
    expect(turn).toMatchObject({ who: 'maker', items: ['Q1', 'Q2'] });
    const md = answerBrief(ctx(), rec, turn);
    expect(md).toMatch(/the ТЗ maker's brief, round 1 of 5/);
    expect(md).toMatch(/\*\*keep\*\*/);
    expect(md).toMatch(/\*\*change\*\* — \*\*edit the ТЗ first\*\*/);
    expect(md).toMatch(/Не спрашивай — делай/);
    expect(md).toMatch(/Fix these first[\s\S]*a change with no "ТЗ:" line/);
    expect(md).toMatch(/## The items \(2\)/);
    // Its examples parse
    const examples = [...md.matchAll(/```markdown\n([\s\S]*?)```/g)].map((m) => m[1]);
    expect(examples).toHaveLength(2);
    const asItems = `${Q1.replace('· open', '· answered')}\n${examples[0]}\n\n${OWNER_ITEM.split('\n').slice(0, 3).join('\n').replace('Q2', 'Q2')}\n${examples[1]}`;
    expect(parseRecord(record(asItems)).problems).toEqual([]);
  });

  it("the owner's questions, in Russian", () => {
    const md = ownerMarkdown('Glass District', 'docs/gdd.md', 'docs/gdd-review.md', parseRecord(record(OWNER_ITEM)), '2026-10-23');
    expect(md).toMatch(/^# Вопросы владельцу по ТЗ «Glass District»/);
    expect(md).toMatch(/1\. \*\*Добавить ежедневный контракт — один этаж дня с таблицей\? Рекомендую: да\.\*\* \(Q2, монетизация\)/);
    expect(md).toMatch(/Варианты: 1\) без ежедневного/);
    expect(ownerMarkdown('X', 'a', 'b', parseRecord(record(Q1)), '2026-10-23')).toMatch(/Вопросов к владельцу нет/);
  });
});

describe('gp brief, end to end on the sample ТЗ', () => {
  const gp = (...args: string[]) => {
    try {
      return { code: 0, out: execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), 'brief', ...args], { cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }) };
    } catch (e) {
      const x = e as { status: number; stdout: string };
      return { code: x.status, out: x.stdout };
    }
  };

  it('round 1: the record and the critic\'s brief; then the maker; a ТЗ not edited fails --check; edited, the critic again; no further questions — done', { timeout: 60_000 }, () => {
    const dir = join(tmp, 'e2e/docs');
    mkdirSync(dir, { recursive: true });
    cpSync(FIXTURE, join(dir, 'gdd.md'));
    const tz = join(dir, 'gdd.md');
    const rec = join(dir, 'gdd-review.md');
    expect(gp(tz, '--check').code).toBe(1);
    const first = gp(tz);
    expect(first.code).toBe(0);
    expect(first.out).toMatch(/round 1 of 5, the critic/);
    expect(existsSync(join(dir, 'qa', BRIEF_CRITIC))).toBe(true);
    expect(readFileSync(join(dir, 'qa', BRIEF_DIR, 'gdd-r1.md'), 'utf8')).toBe(TZ);
    expect(parseRecord(readFileSync(rec, 'utf8'))).toMatchObject({ title: 'Glass District', round: 1, cap: 5 });
    // The critic asks
    writeFileSync(rec, appendLog(readFileSync(rec, 'utf8').replace('## Log', `${Q1}\n\n## Log`), '- r1 critic: 1 new question'));
    expect(gp(tz).out).toMatch(/the maker: 1 item\(s\) to answer \(Q1\)/);
    // The maker answers without editing the ТЗ: --check refuses
    writeFileSync(rec, appendLog(readFileSync(rec, 'utf8').replace(Q1, Q1_ANSWERED), '- r1 maker: 1 change'));
    const stale = gp(tz, '--check');
    expect(stale.code).toBe(1);
    expect(stale.out).toMatch(/Q1: the answer says the ТЗ now reads "Первая версия: 3 этажа, 1 босс"/);
    // …edits it: the critic's round 2
    writeFileSync(tz, TZ.replace('12 этажей башни, 40 имплантов, 8 боссов', 'Первая версия: 3 этажа, 1 босс; потом 12 этажей башни, 40 имплантов, 8 боссов'));
    const r2 = gp(tz);
    expect(r2.out).toMatch(/round 2 of 5, the critic: 1 answer\(s\) to rule on/);
    expect(existsSync(join(dir, 'qa', BRIEF_DIR, 'gdd-r2.md'))).toBe(true);
    // The critic closes it and has no further questions
    writeFileSync(rec, appendLog(readFileSync(rec, 'utf8').replace('## Q1 · scope · answered', '## Q1 · scope · closed').replace(/(ТЗ: §6 — .*)$/m, '$1\nClose (r2): §6 now names the slice.'), '- r2 critic: 1 closed — no further questions'));
    const done = gp(tz);
    expect(done.out).toMatch(/the ТЗ review is done/);
    expect(existsSync(join(dir, 'qa', BRIEF_OWNER))).toBe(true);
    const ok = gp(tz, '--check');
    expect(ok.code).toBe(0);
    expect(ok.out).toMatch(/✓ .*ТЗ review — 1 item: 1 closed · round 2 of 5 · no further questions \(r2\)/);
    const json = JSON.parse(gp(tz, '--check', '--json').out);
    expect(json).toMatchObject({ ok: true, turn: { who: 'done' } });
  });
});
