// The previews' list and front page (the build itself is build.test.ts's)

import { describe, expect, it } from 'vitest';
import { previewIndex, upsertPreview, type PreviewEntry } from '../src/preview.ts';

const a: PreviewEntry = { id: 'alpha', title: 'Alpha', version: '1.2.0', updated: '2026-10-01T10:00:00.000Z', gzipKB: 120 };
const b: PreviewEntry = { id: 'beta', title: 'Beta & <Co>', updated: '2026-10-02T10:00:00.000Z', cover: true };

describe('previews', () => {
  it('replaces a game in place of its old entry, newest first', () => {
    const list = upsertPreview(upsertPreview([], a), b);
    expect(list.map((e) => e.id)).toEqual(['beta', 'alpha']);
    const again = upsertPreview(list, { ...a, updated: '2026-10-03T00:00:00.000Z' });
    expect(again.map((e) => e.id)).toEqual(['alpha', 'beta']);
    expect(again).toHaveLength(2);
  });

  it('links each game to its folder and escapes titles', () => {
    const html = previewIndex([b, a]);
    expect(html).toContain('href="beta/"');
    expect(html).toContain('src="beta/cover.png"');
    expect(html).not.toContain('src="alpha/cover.png"');
    expect(html).toContain('Beta &amp; &lt;Co&gt;');
    expect(html).toContain('120 KB gz');
    expect(html).toContain('v1.2.0');
  });
});

describe('publisher/updates.yaml', () => {
  it('has one well-formed entry per version of a game', async () => {
    const { readFileSync } = await import('node:fs');
    const { join } = await import('node:path');
    const { parse } = await import('yaml');
    const { ROOT } = await import('../src/paths.ts');
    const { updates } = parse(readFileSync(join(ROOT, 'publisher', 'updates.yaml'), 'utf8')) as { updates: Record<string, unknown>[] };
    const seen = new Set<string>();
    for (const u of updates) {
      expect(u.game, JSON.stringify(u)).toMatch(/^[a-z0-9-]+$/);
      expect(u.version, String(u.game)).toMatch(/^\d+\.\d+\.\d+$/);
      expect(['baseline', 'patch', 'update', 'remake']).toContain(u.kind);
      expect(String(u.date)).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(Array.isArray(u.changes) && u.changes.length > 0, String(u.game)).toBe(true);
      const key = `${u.game}@${u.version}`;
      expect(seen.has(key), key).toBe(false);
      seen.add(key);
    }
  });
});
