// gp quota: the month's spend from the log, counted from the plan's reset day; check stops at the reserve; the service's
// own balance wins when it is lower; the config from publisher/quota.yaml.

import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { loadQuotas, periodStart, quotaState, readLog, record, type ServiceQuota } from '../src/quota.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-quota-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));
const q: ServiceQuota = { monthly: 100, reserve: 10, resetDay: 15, enabled: true };

describe('gp quota', () => {
  it('the month starts on the reset day', () => {
    expect(periodStart(new Date('2026-10-20T12:00:00Z'), 15).toISOString()).toBe('2026-10-15T00:00:00.000Z');
    expect(periodStart(new Date('2026-10-03T12:00:00Z'), 15).toISOString()).toBe('2026-09-15T00:00:00.000Z');
    expect(periodStart(new Date('2026-01-05T00:00:00Z'), 15).toISOString()).toBe('2025-12-15T00:00:00.000Z');
  });
  it('records, counts this month only, and stops at the reserve', () => {
    const f = join(tmp, 'art', 'quota-log.json');
    record(f, 'pixellab', 50, 'last month', new Date('2026-10-01T10:00:00Z'));
    record(f, 'pixellab', 85, 'the hero', new Date('2026-10-16T10:00:00Z'));
    record(f, 'flux', 3, undefined, new Date('2026-10-16T10:00:00Z'));
    const now = new Date('2026-10-20T00:00:00Z');
    const s = quotaState('pixellab', q, readLog(f), now);
    expect([s.used, s.left, s.ok]).toEqual([85, 15, true]);
    record(f, 'pixellab', 5, undefined, new Date('2026-10-17T00:00:00Z'));
    expect(quotaState('pixellab', q, readLog(f), now).ok).toBe(false);
    expect(() => record(f, 'pixellab', -1)).toThrow(/whole number/);
  });
  it("the service's own balance wins when lower; an unknown or disabled service is never ok", () => {
    expect(quotaState('pixellab', q, [], new Date(), 8)).toMatchObject({ left: 8, ok: false });
    expect(quotaState('pixellab', q, [], new Date(), 500).left).toBe(100);
    expect(quotaState('nope', undefined, []).ok).toBe(false);
    expect(quotaState('flux', { ...q, enabled: false }, []).ok).toBe(false);
  });
  it('the platform config: PixelLab Apprentice 2,000 with a reserve of 50, FLUX off', () => {
    const c = loadQuotas();
    expect(c.pixellab).toMatchObject({ monthly: 2000, reserve: 50, enabled: true });
    expect(c.flux?.enabled).toBe(false);
  });
});
