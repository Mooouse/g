// gp review's calibrated look: the reference shots (publisher/reference/), the pick, the game's frames and the sheet.

import { copyFileSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { loadResults } from '../src/forecast.ts';
import { locateGame } from '../src/paths.ts';
import { MAX_APPROVED, MAX_REFERENCE_BYTES, SHEET_H, SHEET_W, buildReviewSheet, gameCells, loadReferences, pickReferences } from '../src/review-sheet.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-review-sheet-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

/** A JPEG's size from its first SOF marker */
function jpegSize(buf: Buffer): { w: number; h: number } | null {
  if (buf[0] !== 0xff || buf[1] !== 0xd8) return null;
  for (let i = 2; i < buf.length - 9; ) {
    if (buf[i] !== 0xff) return null;
    const m = buf[i + 1];
    const len = buf.readUInt16BE(i + 2);
    if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7) };
    i += 2 + len;
  }
  return null;
}

describe('the reference shots (publisher/reference/index.yaml)', () => {
  const { refs, problems } = loadReferences();

  it('is well-formed: every file a 1280×720 JPEG of ≤ 100 KB, at most 12 approved, approved and rejected both there', () => {
    expect(problems).toEqual([]);
    expect(refs.filter((r) => r.outcome === 'approved').length).toBeGreaterThanOrEqual(3);
    expect(refs.filter((r) => r.outcome === 'approved').length).toBeLessThanOrEqual(MAX_APPROVED);
    expect(refs.filter((r) => r.outcome === 'rejected').length).toBeGreaterThanOrEqual(2);
    for (const r of refs) {
      expect(r.file, r.file).toMatch(new RegExp(`^${r.outcome}/${r.game}-\\d+\\.jpg$`));
      expect(statSync(r.path).size, r.file).toBeLessThanOrEqual(MAX_REFERENCE_BYTES);
      expect(jpegSize(readFileSync(r.path)), r.file).toEqual({ w: SHEET_W, h: SHEET_H });
    }
  });

  it('each shot is of a game whose answer on that date publisher/results.yaml records as that outcome', () => {
    const { results } = loadResults();
    for (const r of refs) {
      const rec = results.find((x) => x.game === r.game && x.review?.date === r.date);
      expect(rec, `${r.file}: ${r.game} ${r.date}`).toBeTruthy();
      expect(rec!.review!.verdict, r.file).toBe(r.outcome);
      if (r.outcome === 'rejected') expect(rec!.review!.reason, r.file).toMatch(/overall quality/);
    }
  });

  it('the pick: 3 approved (title, play, meta), 2 rejected (title, play), each of a different game, the genre first', () => {
    const p = pickReferences(refs, 'puzzle');
    expect(p.approved).toHaveLength(3);
    expect(p.rejected).toHaveLength(2);
    expect(new Set(p.approved.map((r) => r.game)).size).toBe(3);
    expect(new Set(p.rejected.map((r) => r.game)).size).toBe(2);
    expect(p.approved.map((r) => r.screen)).toEqual(['title', 'play', 'meta']);
    expect(p.approved[0].genre).toBe('puzzle');
    expect(p.rejected.map((r) => r.screen)).toEqual(['title', 'play']);
    // Deterministic
    expect(pickReferences(refs, 'puzzle')).toEqual(p);
    expect(pickReferences(refs, 'action').approved[0].genre).toBe('action');
  });
});

describe("the game's frames and the sheet", () => {
  const game = (name: string, files: string[]) => {
    const dir = join(tmp, name);
    mkdirSync(join(dir, 'qa'), { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'id: x\n');
    const src = loadReferences().refs[0].path;
    for (const f of files) {
      mkdirSync(join(dir, f, '..'), { recursive: true });
      copyFileSync(src, join(dir, f));
    }
    return locateGame(dir);
  };

  it('from the QA: the declared title, the desktop play frame, a declared meta screen before the results, the cover', () => {
    const loc = game('cells', ['qa/screen-title-desktop-1280x720.png', 'qa/desktop-1280x720-1-first-screen.png', 'qa/desktop-1280x720-2-play.png', 'qa/screen-paused-desktop-1280x720.png', 'qa/screen-results-desktop-1280x720.png', 'qa/screen-shop-desktop-1280x720.png', 'store/cover-landscape-1920x1080.png']);
    const c = gameCells(loc);
    expect(c.map((x) => x.id)).toEqual(['title', 'play-1', 'play-2', 'meta', 'cover']);
    expect(c[0].file).toMatch(/screen-title-desktop-1280x720\.png$/);
    expect(c[1].file).toMatch(/desktop-1280x720-2-play\.png$/);
    expect(c[2]).toMatchObject({ file: null, note: expect.stringContaining('not captured') });
    expect(c[3]).toMatchObject({ label: 'meta: shop', file: expect.stringMatching(/screen-shop-desktop/) });
    expect(c[4].file).toMatch(/cover-landscape-1920x1080\.png$/);
    // Captured frames win; without a declared meta screen the results stand in
    const cap = gameCells(game('cells-2', ['qa/screen-results-desktop-1280x720.png']), { first: '/x/review-title.png', 'play-1': '/x/review-play-1.png', 'play-2': '/x/review-play-2.png' });
    expect(cap.map((x) => x.file)).toEqual(['/x/review-title.png', '/x/review-play-1.png', '/x/review-play-2.png', expect.stringMatching(/screen-results/), null]);
    expect(cap[3].label).toBe('meta: results');
  });

  it('composes qa/review-sheet.png in the browser: the game row over the references row', { timeout: 60_000 }, async () => {
    const loc = game('sheet', ['qa/screen-title-desktop-1280x720.png', 'qa/desktop-1280x720-2-play.png']);
    const s = await buildReviewSheet(loc, { title: 'Sheet Test', money: null } as never, { capture: false });
    expect(s.problems).toEqual([]);
    expect(s.file).toMatch(/qa[\\/]review-sheet\.png$/);
    const png = readFileSync(s.file!);
    expect(png.subarray(1, 4).toString()).toBe('PNG');
    // Five 480-px columns: the sheet is wider than 2400 px, and two rows of 270-px pictures tall
    expect(png.readUInt32BE(16)).toBeGreaterThan(2400);
    expect(png.readUInt32BE(20)).toBeGreaterThan(2 * 270);
    expect(s.approved).toHaveLength(3);
    expect(s.rejected).toHaveLength(2);
  });
});
