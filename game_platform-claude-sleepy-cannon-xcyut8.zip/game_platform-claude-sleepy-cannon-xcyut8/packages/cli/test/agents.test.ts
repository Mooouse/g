// gp agents: the template's subagents installed into a game repository and kept up to date; the template's frontmatter
// names the model each class runs on (docs/guides/routing.md).

import { execFileSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { AGENTS_TEMPLATE, installAgents } from '../src/agents.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-agents-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

describe('the routing subagents', () => {
  it('each class on its model: mechanic Haiku, architect Opus, the artists Sonnet', () => {
    const model = (f: string) => /^model:\s*(\S+)/m.exec(readFileSync(join(AGENTS_TEMPLATE, f), 'utf8'))?.[1];
    expect(readdirSync(AGENTS_TEMPLATE).sort()).toEqual(['architect.md', 'mechanic.md', 'pixel-artist.md', 'promo-artist.md']);
    expect([model('mechanic.md'), model('architect.md'), model('pixel-artist.md'), model('promo-artist.md')]).toEqual(['haiku', 'opus', 'sonnet', 'sonnet']);
    expect(readFileSync(join(AGENTS_TEMPLATE, 'pixel-artist.md'), 'utf8')).toMatch(/never draw or redraw a sprite/i);
  });

  it('installs them into a game repository, updates a changed one, and --check says what is missing', () => {
    const repo = join(tmp, 'game');
    mkdirSync(join(repo, 'games', 'demo'), { recursive: true });
    writeFileSync(join(repo, 'games', 'demo', 'game.yaml'), 'id: demo\n');
    execFileSync('git', ['init', '-q', repo]);
    const loc = { id: 'demo', dir: join(repo, 'games', 'demo'), file: join(repo, 'games', 'demo', 'game.yaml') };
    const check = installAgents(loc, { check: true });
    expect(check.added).toHaveLength(4);
    expect(readdirSync(repo)).not.toContain('.claude');
    expect(installAgents(loc).added).toHaveLength(4);
    writeFileSync(join(repo, '.claude', 'agents', 'mechanic.md'), 'old');
    const again = installAgents(loc);
    expect([again.added, again.updated, again.same.length]).toEqual([[], ['mechanic.md'], 3]);
    expect(installAgents(loc, { check: true }).updated).toEqual([]);
  });
});
