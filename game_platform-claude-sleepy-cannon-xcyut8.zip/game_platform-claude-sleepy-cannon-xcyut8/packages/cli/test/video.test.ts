import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { describe, expect, it } from 'vitest';
import { ROOT } from '../src/paths.ts';
import { fadeOut } from '../src/audio-tap.ts';
import { contactSheet, DEFAULT_SCRIPT, FPS, PLAY_SELECTOR, sheetFrames, sheetName, videoName, type VideoApi, type VideoScript } from '../src/video.ts';

/** A fake recorder: which steps were filmed before and after the tap on Play */
function record(): { api: VideoApi; filmedBeforeTap: () => number; filmedAfterTap: () => number } {
  let tapped = false;
  let before = 0;
  let after = 0;
  const api = {
    page: null as never,
    orientation: 'landscape',
    sec: (s: number) => Math.round(s * 30),
    async step(frames: number, o: { film?: boolean } = {}) {
      if (o.film === false) return;
      if (tapped) after += frames;
      else before += frames;
    },
    async tap(sel: string) {
      if (sel === PLAY_SELECTOR) tapped = true;
      return true;
    },
    visible: async () => true,
    until: async () => true,
    demo: async () => true,
    filmed: () => (before + after) / 30,
    length: 15,
  } satisfies VideoApi;
  return { api, filmedBeforeTap: () => before, filmedAfterTap: () => after };
}

describe('the contact sheet (gp video, gp video --frames): what the video shows, without ffmpeg', () => {
  it('a frame a second and the last, each with its time and what it is', () => {
    const total = 15 * FPS;
    const f = sheetFrames(total, 10 * FPS, { cover: FPS / 2, play: new Set([FPS]), file: (i) => `f${i}.jpg` });
    expect(f.map((x) => x.sec)).toEqual([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
    expect(f[0]).toEqual({ file: 'f0.jpg', sec: 0, marks: ['cover'] });
    expect(f[1].marks).toEqual(['play']);
    expect(f[9].marks).toEqual([]);
    // Past what was filmed: the end card
    expect(f[10].marks).toEqual(['end']);
    expect(f.at(-1)!.file).toBe(`f${total - 1}.jpg`);
    expect(sheetName('preview-1920x1080')).toBe('preview-1920x1080-frames.png');
  });

  it('composes the frames into one PNG in the browser', { timeout: 60_000 }, async () => {
    const { chromium } = await import('playwright');
    const dir = mkdtempSync(join(tmpdir(), 'gp-sheet-'));
    const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
    try {
      // Three frames as the recorder writes them (JPEG screenshots of a page)
      const page = await browser.newPage({ viewport: { width: 320, height: 180 } });
      const files: string[] = [];
      for (const [i, color] of ['#c33', '#3c3', '#33c'].entries()) {
        await page.setContent(`<body style="margin:0;background:${color}">`);
        files.push(join(dir, `f${i}.jpg`));
        await page.screenshot({ path: files[i], type: 'jpeg' });
      }
      const out = join(dir, 'sheet.png');
      await contactSheet(browser, files.map((file, i) => ({ file, sec: i, marks: i === 0 ? ['cover'] : i === 2 ? ['end'] : [] })), out, { title: 'Test Game', video: 'preview-1920x1080.mp4', width: 1920, height: 1080 });
      const png = readFileSync(out);
      expect(png.subarray(1, 4).toString()).toBe('PNG');
      // 4 columns of 480 px with 12 px gaps (a landscape video)
      expect(png.readUInt32BE(16)).toBe(4 * 480 + 5 * 12);
      // Its pixels: the three frames' colours are in it (read back through the browser)
      const seen = await page.evaluate(async (b64) => {
        const img = new Image();
        img.src = `data:image/png;base64,${b64}`;
        await img.decode();
        const c = Object.assign(document.createElement('canvas'), { width: img.width, height: img.height });
        const g = c.getContext('2d')!;
        g.drawImage(img, 0, 0);
        // The middle of each of the first three thumbnails (below the 18 px header)
        return [0, 1, 2].map((k) => Array.from(g.getImageData(12 + k * 492 + 240, 12 + 30 + 135, 1, 1).data.slice(0, 3)));
      }, png.toString('base64'));
      const near = (a: number[], b: number[]) => a.every((v, i) => Math.abs(v - b[i]) < 40);
      expect(near(seen[0], [0xcc, 0x33, 0x33]), JSON.stringify(seen)).toBe(true);
      expect(near(seen[1], [0x33, 0xcc, 0x33]), JSON.stringify(seen)).toBe(true);
      expect(near(seen[2], [0x33, 0x33, 0xcc]), JSON.stringify(seen)).toBe(true);
    } finally {
      await browser.close();
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe('gp video --sound / --max: a gameplay video, never a preview', () => {
  it('keeps the preview names for a silent 15–20 s video, and names anything else gameplay-…', () => {
    expect(videoName('preview-1920x1080')).toBe('preview-1920x1080');
    expect(videoName('preview-1920x1080', { seconds: 20 })).toBe('preview-1920x1080');
    // The portal wants no sound, and 15–20 s: gp submission must not take these for its previews
    expect(videoName('preview-1920x1080', { sound: true })).toBe('gameplay-1920x1080');
    expect(videoName('preview-1080x1920', { seconds: 60 })).toBe('gameplay-1080x1920');
    expect(videoName('preview-1080x1920', { seconds: 8 })).toBe('gameplay-1080x1920');
    expect(videoName('trailer', { sound: true })).toBe('gameplay-trailer');
  });
  it('a long video\'s contact sheet shows at most about 30 frames', () => {
    const f = sheetFrames(120 * FPS, 120 * FPS, { cover: 0, play: new Set(), file: (i) => `f${i}.jpg` });
    expect(f.length).toBeLessThanOrEqual(31);
    expect(f.slice(0, 3).map((x) => x.sec)).toEqual([0, 4, 8]);
    expect(f.at(-1)!.file).toBe(`f${120 * FPS - 1}.jpg`);
  });
  it('fades the soundtrack out before the end card', () => {
    const rate = 1000;
    const pcm = Buffer.alloc(1000 * 4);
    for (let i = 0; i < 1000; i++) {
      pcm.writeInt16LE(10000, i * 4);
      pcm.writeInt16LE(-10000, i * 4 + 2);
    }
    fadeOut(pcm, rate, 0.25);
    expect(pcm.readInt16LE(0)).toBe(10000);
    expect(pcm.readInt16LE(749 * 4)).toBe(10000);
    expect(Math.abs(pcm.readInt16LE(999 * 4))).toBe(0);
    expect(Math.abs(pcm.readInt16LE(875 * 4 + 2))).toBeLessThan(6000);
  });
  it('the default script films the length it is given', async () => {
    let filmed = 0;
    const r = record();
    await DEFAULT_SCRIPT({ ...r.api, length: 40, step: async (n, o = {}) => void (o.film === false ? 0 : (filmed += n)) });
    expect(filmed).toBe(40 * 30);
  });
});

describe('gp video scripts keep the title off camera', () => {
  it('the default script films nothing before it taps Play', async () => {
    const r = record();
    await DEFAULT_SCRIPT(r.api);
    expect(r.filmedBeforeTap()).toBe(0);
    expect(r.filmedAfterTap()).toBeGreaterThan(0);
  });
  it("the gp init template's video.mjs films nothing before it taps Play", async () => {
    const file = join(ROOT, 'templates/game-repo/games/__ID__/video.mjs');
    expect(readFileSync(file, 'utf8')).toContain('[data-gp=play]');
    const script = ((await import(pathToFileURL(file).href)) as { default: VideoScript }).default;
    const r = record();
    await script(r.api);
    expect(r.filmedBeforeTap()).toBe(0);
    expect(r.filmedAfterTap()).toBeGreaterThan(0);
  });
});
