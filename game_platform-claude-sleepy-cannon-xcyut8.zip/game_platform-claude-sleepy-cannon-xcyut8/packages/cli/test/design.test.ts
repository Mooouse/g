// gp design: the designer's brief, the design.md format and its parser, the genre facts, and the Gemini second opinion
// (against a mocked transport: no real call, ever).

import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { GENRE_BLOCKS, genreChecks, recordsOf, resubmissionOf, type RecordedResult, type ResolvedGame } from '@gp/spec';
import { KEPT_DIRS, KEPT_REPORTS } from '@gp/qa';
import {
  DESIGN_BRIEF,
  DESIGN_DIR,
  DESIGN_GEMINI,
  DESIGN_SECTIONS,
  DESIGN_SHEET,
  HITS_HEADING,
  changelogHead,
  buildLabel,
  designBrief,
  designerPrompt,
  designSummary,
  designTemplate,
  frameFile,
  genreFacts,
  geminiMarkdown,
  measuredBuild,
  ownMetricsSection,
  ownResults,
  parseDesign,
  parseItem,
  runSection,
  secondOpinion,
  stopsLines,
  withState,
  type DesignFacts,
  type UpdateEntry,
} from '../src/design.ts';
import { DEFAULT_DESIGN_MODEL, FLASH_MODEL, GEMINI_KEY_HELP, PROBE_TEXT, askGemini, geminiKey, newestFlash, nextModel, noQuota, redact, replacementModel, resolveModel, GeminiError, type GeminiHttp, type HttpRequest, type HttpResponse } from '../src/gemini.ts';
import { LESSONS } from '../src/lessons.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import type { ReviewFacts } from '../src/review.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-design-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

const GOOD = `# Forge Night — design proposals

Designer: agent-d · Date: 2026-10-20 · Played: gp dev, 16 min at 1280×720, 6 min at 360×800

## Top 3

1. [high] The results card starts the next shift after 3 s, with "beat 13 400" as its goal — playtime: at 0:42 the first
   results screen offers only Play again and Menu, the session estimate stops there → \`mountResults({ autoContinueSec: 3 })\` with goalFromSnapshot · effort S
2. [high] A daily shift with a fixed seed and a score band on the title — D1: nothing on the title changes by tomorrow → \`dailyTable\` and \`mountStreakCard\` · effort M
3. [mid] Chains score ×1.0 → ×1.5 → ×2 with a rising pitch — conversion: the first 30 s have no celebrated moment until 0:24 → ScoreSequencer in main.ts, the chain counter · effort S

## First minute

- [high] Boot a first visit straight into the shift, the title after it — conversion: a Play click at 0:00 is a second gate after the portal's → host.firstVisit in main.ts · effort S
- [low] A ghost hand on the deck for the first tap — first minute: at 0:03 nothing says where to tap → \`coachHand\` · effort S

## Session

- [mid] A boss jelly every third shift — session: from 1:30 every shift looks the same → main.ts spawns, \`BossPatterns\` · effort M

## Coming back

- [none] — the Top 3's daily covers it

## Phones

- [mid] Move the HUD gauges off the thumb arc — conversion on phones: at 360×800 the gauges sit under the right thumb → the layout in scene.ts · effort S

## Juice and feel

- [low] A sound for a missed tap — playtime: a tap on empty deck at 0:12 is silent → \`createSfx\` recipe deny · effort S

## Content and variety

- [mid] Two more creatures with their own move (a hopper, a splitter) — playtime: one kind of jelly for 3 minutes → a data table in scene.ts · effort M

## ${HITS_HEADING}

- Tap Tap Boom: a combo meter that fills the screen with colour → a chain bar of our own, in the deck's lamps
- **Idle Factory**: an upgrade between shifts → one pick of 3 after each shift (RunChoices)

## Not now

- a workshop screen: a new system nobody would polish in time
`;

describe('design.md: the format and its parser', () => {
  it('reads the Top 3, the sections, the [none] lines and the hits', () => {
    const r = parseDesign(GOOD, { title: 'Forge Night' });
    expect(r.problems).toEqual([]);
    expect(r.ok).toBe(true);
    expect(r.top.map((t) => `${t.effect} ${t.effort}`)).toEqual(['high S', 'high M', 'mid S']);
    // A change may carry an arrow of its own ("×1.0 → ×1.5"): the first one after the dash ends the why
    expect(r.top[2]).toMatchObject({ change: 'Chains score ×1.0 → ×1.5 → ×2 with a rising pitch', metrics: ['conversion'], how: 'ScoreSequencer in main.ts, the chain counter', blocks: ['ScoreSequencer'] });
    expect(r.top[0]).toMatchObject({ line: 7, metrics: ['playtime'] });
    expect(r.top[0].blocks).toContain('mountResults');
    expect(r.top[1].metrics).toEqual(['D1']);
    expect(r.items.map((i) => i.section)).toEqual(['first-minute', 'first-minute', 'session', 'phones', 'feel', 'content']);
    expect(r.none).toEqual([{ section: 'return', why: "the Top 3's daily covers it", line: GOOD.split('\n').findIndex((l) => l.startsWith('- [none]')) + 1 }]);
    expect(r.hits.map((h) => h.game)).toEqual(['Tap Tap Boom', 'Idle Factory']);
  });

  it('the template the brief shows: refused as it is, accepted once filled in', () => {
    const tpl = designTemplate('Lantern Walk');
    const raw = parseDesign(tpl, { title: 'Lantern Walk' });
    expect(raw.ok).toBe(false);
    expect(raw.problems.map((p) => p.message).join('\n')).toContain('placeholder');
    const filled = tpl
      .replace(/<what to add or change, exactly>|<the change with the best expected effect for its effort>|<the second>|<the third>/g, 'The results card starts the next run after 3 s')
      .replace(/<the metric it moves and what you saw, with the time>|<metric, what you saw>/g, 'playtime: at 1:10 only Play again')
      .replace(/<how: the platform block, or what to change in the game code>|<how>/g, '`mountResults({ autoContinueSec: 3 })`')
      .replace(/<a top CrazyGames game of the genre>|<another>/g, 'Some Hit')
      .replace(/<what it does in its first minute, session or return that ours doesn't>|<what it does>/g, 'a daily run')
      .replace(/<what we take, in our own shape>|<what we take>/g, 'dailyTable');
    const r = parseDesign(filled, { title: 'Lantern Walk' });
    expect(r.problems).toEqual([]);
    expect(r.top).toHaveLength(3);
    expect(r.items).toHaveLength(DESIGN_SECTIONS.length);
    expect(r.hits).toHaveLength(2);
  });

  it('refuses generic advice, a why without a metric, a how without a block or code, no effort, a bad effect', () => {
    const msg = (body: string) => parseItem(body, 'session', 1).problems.join(' | ');
    expect(msg('[high] Improve the graphics — playtime: it looks dull → main.ts · effort M')).toMatch(/generic advice/);
    expect(msg('[high] Make it more fun — conversion: boring → game code · effort S')).toMatch(/generic advice/);
    expect(msg('[high] Bigger buttons on the results — they are small → mountResults · effort S')).toMatch(/names no metric/);
    expect(msg('[high] Bigger buttons on the results — playtime: small at 1:10 → make them bigger · effort S')).toMatch(/names no block and no code/);
    expect(msg('[high] Bigger buttons on the results — playtime: small at 1:10 → mountResults')).toMatch(/effort: none at the end/);
    expect(msg('[urgent] Bigger buttons — playtime → mountResults · effort S')).toMatch(/not an effect/);
    expect(msg('Bigger buttons — playtime → mountResults · effort S')).toMatch(/starts with its expected effect/);
    expect(msg('[mid] Bigger buttons, playtime, mountResults · effort S')).toMatch(/a proposal is/);
    // Effort in other spellings; the how naming a file or game.yaml is code
    expect(parseItem('[mid] Shorter shift: 30 s — playtime: 40 s drags at 0:35 → game.yaml money and main.ts SHIFT (effort: small)', 'session', 1).item?.effort).toBe('S');
    expect(parseItem('[low] A louder thud — playtime: hits feel light → createSfx | effort L', 'feel', 1).item).toMatchObject({ effort: 'L', blocks: ['createSfx'] });
  });

  it('each problem names its part — why, how, effort, change — and quotes it', () => {
    const issues = (body: string) => parseItem(body, 'session', 1).issues;
    expect(issues('[high] Bigger buttons on the results — they are small → mountResults · effort S')).toEqual([expect.objectContaining({ part: 'why', text: 'they are small', message: expect.stringMatching(/^why: "they are small" names no metric/) })]);
    expect(issues('[high] Bigger buttons on the results — playtime: small at 1:10 → make them bigger · effort S')).toEqual([expect.objectContaining({ part: 'how', message: expect.stringMatching(/^how: "make them bigger" names no block and no code/) })]);
    expect(issues('[high] Improve the graphics — playtime: it looks dull → main.ts · effort M')[0]).toMatchObject({ part: 'change', message: expect.stringMatching(/^change: "Improve the graphics" is generic advice/) });
    expect(issues('[high] Bigger buttons — playtime at 1:10 → mountResults')[0].part).toBe('effort');
    expect(issues('[high] Bigger buttons — playtime at 1:10 · effort S')[0]).toMatchObject({ part: 'format', message: expect.stringMatching(/no " → " after the why/) });
  });

  it("the how may name the game's code by an identifier: a call, Class.method, a src/ path, a `name`", () => {
    const how = (h: string) => parseItem(`[high] A daily car on the title — D1: nothing new tomorrow at 0:00 → ${h} · effort S`, 'return', 1);
    for (const ok of ['dailyCar() picks the car of the day', 'Garage.openNext on the 5th car', 'src/garage/daily.ts', 'the `carOfDay` table', 'spawnBoss(3) every third shift']) expect(how(ok).item, ok).not.toBeNull();
    for (const no of ['make them bigger', 'a daily car, e.g. a red one', 'better rewards (more of them)']) expect(how(no).problems.join(), no).toMatch(/names no block and no code/);
  });

  it('a problem in a proposal over several lines is reported on the line its part is on', () => {
    const text = GOOD.replace('→ main.ts spawns, `BossPatterns` · effort M', '→\n  make them harder · effort M');
    const r = parseDesign(text, { title: 'Forge Night' });
    const line = text.split('\n').findIndex((l) => l.trim() === 'make them harder · effort M') + 1;
    expect(r.problems).toEqual([{ line, message: expect.stringMatching(/^how: "make them harder" names no block and no code.*\(the proposal starts on line \d+\)$/) }]);
  });

  it('the summary counts the Top 3 apart from the sections', () => {
    expect(designSummary(parseDesign(GOOD, { title: 'Forge Night' }))).toBe("Top 3 + 6 proposals in the sections (1 high), 2 of the genre's hits");
  });

  it('the structure: the heading, exactly three on top, every section, the hits, at least one [high]', () => {
    const msgs = (t: string) => parseDesign(t, { title: 'Forge Night' }).problems.map((p) => p.message).join('\n');
    expect(msgs(GOOD.replace('# Forge Night', '# Other Game'))).toMatch(/doesn't name this game/);
    expect(msgs(GOOD.replace(/^3\. .*\n/m, ''))).toMatch(/Top 3 has 2 proposal/);
    expect(msgs(GOOD.replace('## Phones', '## Notes'))).toMatch(/no "## Phones" section/);
    expect(msgs(GOOD.replace(/## Coming back\n\n- \[none\][^\n]*\n/, '## Coming back\n\n'))).toMatch(/"## Coming back" has no proposal/);
    expect(msgs(GOOD.replace('- [none] — the Top 3\'s daily covers it', '- [none]'))).toMatch(/say why nothing is needed/);
    expect(msgs(GOOD.replace(/- \*\*Idle Factory\*\*[^\n]*\n/, ''))).toMatch(/1 hit\(s\): name at least two/);
    expect(msgs(GOOD.replace(`## ${HITS_HEADING}`, '## Others'))).toMatch(/no "## The genre's hits" section/);
    expect(msgs(GOOD.replace(/\[high\]/g, '[mid]'))).toMatch(/no \[high\] proposal/);
    // Headings may carry the metric after the name
    expect(parseDesign(GOOD.replace('## Session', '## Session (playtime)'), { title: 'Forge Night' }).ok).toBe(true);
  });

  it('every section names lessons and blocks that exist', () => {
    const ids = new Set(LESSONS.map((l) => l.id));
    for (const s of DESIGN_SECTIONS) {
      for (const l of s.lessons) expect(ids.has(l), `${s.id}: lesson ${l}`).toBe(true);
      for (const b of s.blocks) expect(GENRE_BLOCKS[b], `${s.id}: block ${b}`).toBeTruthy();
    }
  });

  it('gp qa keeps what gp design writes in qa/', () => {
    for (const f of [DESIGN_BRIEF, DESIGN_SHEET, DESIGN_GEMINI]) expect(KEPT_REPORTS).toContain(f);
    expect(KEPT_DIRS).toContain(DESIGN_DIR);
    expect(frameFile(0)).toBe('frame-0m00.jpg');
    expect(frameFile(130)).toBe('frame-2m10.jpg');
  });
});

describe('the facts', () => {
  const idle = { kit: { kit: 'code' }, audience: { id: 'general' }, money: { genre: 'idle' }, listing: { tags: [] } } as unknown as ResolvedGame;

  it("the genre's must-haves and blocks against what the code imports", () => {
    const g = genreFacts(idle, ['UpgradeShop', 'mountUpgradeShop', 'formatAmount'], 'const perSec = 3;');
    expect(g.genre).toBe('idle');
    expect(g.expects.find((e) => /level shop/.test(e.what))?.have).toBe(true);
    expect(g.expects.find((e) => /offline earnings/.test(e.what))?.have).toBe(false);
    expect(g.blocks.find((b) => b.name === 'UpgradeShop')?.used).toBe(true);
    expect(g.blocks.find((b) => b.name === 'offlineEarnings')?.used).toBe(false);
    // An idle-only block is never offered to an action game
    const action = genreFacts({ ...idle, money: { genre: 'action' } } as never, [], '');
    expect(action.blocks.some((b) => b.name === 'offlineEarnings')).toBe(false);
  });

  it('own results by id, folder id or title; the CHANGELOG head; the stops on record', () => {
    const results = [
      { game: 'idle-garage-evolution', title: 'Idle Garage Evolution', channel: 'crazygames', basicLaunch: { verdict: 'stopped', scores: { date: '2026-10-20', desktop: { playtime: { score: 3 }, d1: { score: 2 }, conversion: { score: 3 } } } } },
      { game: 'nimbus-drift', title: 'Nimbus Drift', channel: 'crazygames', basicLaunch: { verdict: 'stopped' } },
      { game: 'other', channel: 'crazygames' },
    ] as RecordedResult[];
    expect(ownResults(results, { id: 'garage', title: 'Idle Garage Evolution' }, { id: 'x' }).map((r) => r.game)).toEqual(['idle-garage-evolution']);
    expect(ownResults(results, { id: 'g', title: 'G' }, { id: 'other' }).map((r) => r.game)).toEqual(['other']);
    expect(stopsLines(results)).toEqual(['- Idle Garage Evolution (2026-10-20): Desktop 8/15 (playtime 3 · D1 2 · conversion 3)', '- Nimbus Drift: stopped (no numbers recorded)']);
    const dir = join(tmp, 'log');
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'CHANGELOG.md'), '# Changelog\n\n## 1.2.0\n- a daily\n\n## 1.1.0\n- music\n\n## 1.0.0\n- first\n');
    expect(changelogHead(dir)).toBe('## 1.2.0\n- a daily\n\n## 1.1.0\n- music');
    expect(changelogHead(tmp)).toBeNull();
  });
});

/** Facts as gp review and gp design read them, for a game with no QA run yet */
function facts(over: Partial<DesignFacts> = {}): DesignFacts {
  const review = {
    uniqueness: { score: 81, verdict: 'its own', gate: null, markdownTable: '' },
    forecast: { line: 'P(approval) 50–60 %', levers: ['Playtime: a session of 10+ min'] },
    code: { rewarded: [], adBreak: true },
    progression: 'an upgrade shop',
    size: null,
    qa: null,
    screenshots: [],
    media: [],
    staleMedia: [],
    balance: null,
    session: { bot: 'demo', playedSec: 600, lines: { stop: '1:10 of play (break 1): the results with only Play again', breaks: '1. 1:10 results', pulls: 'nothing', estimate: '≈ 4 min expected' } },
    firstMinute: { playReadyMs: 1200, words: 31 },
    scope: { systems: ['an upgrade shop'], screens: ['title', 'shop', 'results'], madeHours: 5 },
    results: [{ game: 'idle-garage-evolution', title: 'Idle Garage Evolution', channel: 'crazygames', basicLaunch: { verdict: 'stopped', scores: { date: '2026-10-20', desktop: { playtime: { value: 8.28, score: 3 }, d1: { value: 0.0171, score: 2 }, conversion: { value: 0.6539, score: 3 }, total: 8 } } } }],
    issues: [],
  } as unknown as ReviewFacts;
  const g = { kit: { kit: 'code' }, audience: { id: 'general' }, money: { genre: 'idle' }, listing: { tags: [] } } as unknown as ResolvedGame;
  return {
    review,
    genre: genreFacts(g, ['UpgradeShop'], ''),
    imported: ['UpgradeShop', 'paint'],
    own: review.results,
    changelog: '## 1.4.0\n- the garage map',
    run: { frames: [{ sec: 0, file: '/g/qa/design/frame-0m00.jpg', label: 'the first screen' }, { sec: 10, file: '/g/qa/design/frame-0m10.jpg', label: 'in play' }], breaks: [{ atSec: 70, taps: ['next'], how: 'tap' }], reachedSec: 180, targetSec: 180, demo: true, sheet: '/g/qa/design-sheet.png', problems: [] },
    gemini: null,
    previous: null,
    ...over,
  };
}

const GAME = {
  id: 'garage',
  title: 'Garage Evolution',
  audience: { id: 'general' },
  channel: { id: 'crazygames' },
  kit: { kit: 'code' },
  concept: { pitch: 'Merge cars into better cars', closest: ['Merge Cars'], different: 'the garage grows', twist: { event: 'merge', within: 20, explained: 'merge two of a kind' } },
  money: { genre: 'idle', session: { minutes: 8, breaks: 3, breaksAt: 'each garage level' }, rewarded: [{ placement: 'offline-x2', kind: 'x2', gives: 'double the offline earnings' }], returns: { kind: 'offline', what: 'the garage earns while away' } },
  story: null,
  listing: { tags: [] },
} as unknown as ResolvedGame;

describe('the brief', () => {
  const loc = { id: 'garage', dir: '/g', file: '/g/game.yaml' };

  it('the task, the rules and the format, the run, the metrics, the genre and every section', () => {
    const b = designBrief(loc, GAME, facts(), '2026-10-20');
    expect(b).toMatch(/^# Garage Evolution — game design brief/);
    expect(b).toContain('a game designer agent who did not make this game');
    expect(b).toContain('- Idle Garage Evolution (2026-10-20): Desktop 8/15');
    expect(b).toMatch(/at least 15 minutes as a new player/);
    expect(b).toMatch(/Desktop first \(1280×720, mouse and keyboard\), then the phone \(360×800, touch only\)/);
    expect(b).toMatch(/experienced player/);
    expect(b).toContain('site:crazygames.com idle');
    expect(b).toContain(designTemplate('Garage Evolution').trimEnd());
    expect(b).toContain('/g/qa/design-sheet.png');
    expect(b).toContain('- 1:10: tapped `next`');
    expect(b).toContain('- 0:10 in play: /g/qa/design/frame-0m10.jpg');
    // The game's own scores and where a point is cheapest
    expect(b).toMatch(/\| Desktop \| 8\.28 min → \*\*3\/5\*\* \| 1\.71 % → \*\*2\/5\*\* \| 65\.4 % → \*\*3\/5\*\* \| 8\/15 \(1 short of 9\) \|/);
    expect(b).toContain('Weakest per device — where a point is likely cheapest: desktop: D1 retention (2/5)');
    expect(b).toContain('## The genre: Idle / incremental');
    expect(b).toMatch(/- ✗ offline earnings/);
    expect(b).toMatch(/\| `offlineEarnings` \| @gp\/core \| .* \| — \|/);
    expect(b).toMatch(/\| `UpgradeShop` \| @gp\/core \| .* \| ✓ used \|/);
    expect(b).toContain('- First natural stop: 1:10 of play (break 1): the results with only Play again');
    expect(b).toMatch(/✗ Words on screen in the first seconds of the run: 31/);
    expect(b).toContain('the reason to return is: offline — the garage earns while away');
    expect(b).toContain('## 1.4.0\n- the garage map');
    for (const s of DESIGN_SECTIONS) expect(b).toContain(`### ${s.heading} — `);
    // The catalogued blocks the code imports; the rest only counted
    expect(b).toContain('**Platform blocks the code imports:** `UpgradeShop` (and 1 more names from @gp/*');
    expect(b).toContain('None yet: `gp design garage --gemini`');
    expect(designBrief(loc, GAME, facts({ gemini: '/g/qa/design-gemini.md' }), '2026-10-20')).toContain('/g/qa/design-gemini.md has what Gemini made of a gameplay video');
  });

  it('without a run or a record: says so', () => {
    const b = designBrief(loc, GAME, facts({ run: null, own: [] }), '2026-10-20');
    expect(b).toContain('No run captured');
    expect(b).toContain('No record of this game in publisher/results.yaml yet');
  });

  it("Gemini's prompt: the same rules and format, the game's facts, the blocks; no file paths to open", () => {
    const p = designerPrompt(GAME, facts(), { video: 75 });
    expect(p).toContain('a 75-second gameplay video of "Garage Evolution"');
    expect(p).toContain(designTemplate('Garage Evolution').trimEnd());
    expect(p).toContain('- offlineEarnings (@gp/core):');
    expect(p).toContain('- UpgradeShop (@gp/core): a level shop');
    expect(p).toContain('Its Basic Launch: Desktop 8/15');
    expect(p).toContain('missing');
    expect(p).not.toContain('gp design --check');
    expect(designerPrompt(GAME, facts(), { frames: 19 })).toContain('19 frames (one every 10 s)');
  });
});

// --- Gemini, mocked ----------------------------------------------------------------------------------------------------

const KEY = 'AIzaSy-TEST-KEY-never-printed-0123';
const ANSWER = GOOD.replace('Forge Night', 'Garage Evolution');

/** A mock of the Gemini API: records every request; answers the upload, the polling and generateContent */
function mockGemini(opts: { status?: number; text?: string; states?: string[] } = {}) {
  const calls: { req: HttpRequest; key: string }[] = [];
  const states = [...(opts.states ?? ['ACTIVE'])];
  const http: GeminiHttp = async (req, key): Promise<HttpResponse> => {
    calls.push({ req, key });
    if (req.url.endsWith('/upload/v1beta/files')) return { status: 200, headers: { 'x-goog-upload-url': 'https://upload.example/session-1' }, text: '{}' };
    if (req.url === 'https://upload.example/session-1') return { status: 200, headers: {}, text: JSON.stringify({ file: { name: 'files/abc', uri: 'https://generativelanguage.googleapis.com/v1beta/files/abc', mimeType: 'video/mp4', state: 'PROCESSING' } }) };
    if (req.method === 'GET') return { status: 200, headers: {}, text: JSON.stringify({ name: 'files/abc', uri: 'https://generativelanguage.googleapis.com/v1beta/files/abc', mimeType: 'video/mp4', state: states.shift() ?? 'ACTIVE' }) };
    if (opts.status && opts.status !== 200) return { status: opts.status, headers: {}, text: opts.text ?? '' };
    return { status: 200, headers: {}, text: JSON.stringify({ candidates: [{ content: { parts: [{ text: 'thinking…', thought: true }, { text: opts.text ?? ANSWER }] } }] }) };
  };
  return { http, calls };
}
const noSleep = async () => {};
const body = (r: HttpRequest) => JSON.parse(String(r.body)) as { contents: { parts: Record<string, unknown>[] }[] };

describe('Gemini (mocked HTTP)', () => {
  const video = join(tmp, 'gameplay-design.mp4');
  writeFileSync(video, Buffer.alloc(2048, 7));

  it('a small video goes inline, before the prompt; the key goes to the transport only', async () => {
    const m = mockGemini();
    const a = await askGemini({ prompt: 'Be a designer.', media: { kind: 'video', file: video }, model: 'gemini-x', key: KEY, http: m.http, sleep: noSleep });
    expect(a.text).toBe(ANSWER.trim());
    expect(a.sent).toMatch(/inline/);
    expect(m.calls).toHaveLength(1);
    const { req, key } = m.calls[0];
    expect(key).toBe(KEY);
    expect(req.url).toBe('https://generativelanguage.googleapis.com/v1beta/models/gemini-x:generateContent');
    expect(req.url + JSON.stringify(req.headers)).not.toContain(KEY);
    const parts = body(req).contents[0].parts;
    expect(parts[0]).toEqual({ inlineData: { mimeType: 'video/mp4', data: Buffer.alloc(2048, 7).toString('base64') } });
    expect(parts[1]).toEqual({ text: 'Be a designer.' });
  });

  it('a big video through the Files API: start, upload and finalize, wait until ACTIVE, then fileData', async () => {
    const m = mockGemini({ states: ['PROCESSING', 'ACTIVE'] });
    const a = await askGemini({ prompt: 'p', media: { kind: 'video', file: video }, model: 'gemini-x', key: KEY, http: m.http, sleep: noSleep, inlineMax: 1000 });
    expect(a.sent).toMatch(/Files API .*files\/abc/);
    const urls = m.calls.map((c) => `${c.req.method} ${c.req.url}`);
    expect(urls).toEqual([
      'POST https://generativelanguage.googleapis.com/upload/v1beta/files',
      'POST https://upload.example/session-1',
      'GET https://generativelanguage.googleapis.com/v1beta/files/abc',
      'GET https://generativelanguage.googleapis.com/v1beta/files/abc',
      'POST https://generativelanguage.googleapis.com/v1beta/models/gemini-x:generateContent',
    ]);
    expect(m.calls[0].req.headers).toMatchObject({ 'X-Goog-Upload-Protocol': 'resumable', 'X-Goog-Upload-Command': 'start', 'X-Goog-Upload-Header-Content-Length': '2048', 'X-Goog-Upload-Header-Content-Type': 'video/mp4' });
    expect(m.calls[1].req.headers).toMatchObject({ 'X-Goog-Upload-Command': 'upload, finalize', 'X-Goog-Upload-Offset': '0' });
    expect(Buffer.isBuffer(m.calls[1].req.body) && m.calls[1].req.body.length).toBe(2048);
    expect(body(m.calls[4].req).contents[0].parts[0]).toEqual({ fileData: { mimeType: 'video/mp4', fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/abc' } });
  });

  it('frames instead of a video; errors say what to do and never carry the key', async () => {
    const frame = join(tmp, 'frame-0m10.jpg');
    writeFileSync(frame, Buffer.from([0xff, 0xd8, 0xff]));
    const m = mockGemini();
    await askGemini({ prompt: 'p', media: { kind: 'frames', files: [frame, frame] }, model: 'm', key: KEY, http: m.http, sleep: noSleep });
    expect(body(m.calls[0].req).contents[0].parts.slice(0, 2)).toEqual([{ inlineData: { mimeType: 'image/jpeg', data: '/9j/' } }, { inlineData: { mimeType: 'image/jpeg', data: '/9j/' } }]);

    const fail = async (status: number, text: string) => askGemini({ prompt: 'p', media: { kind: 'frames', files: [frame] }, model: 'm', key: KEY, http: mockGemini({ status, text }).http, sleep: noSleep }).then(() => '', (e: Error) => e.message);
    const refused = await fail(403, JSON.stringify({ error: { message: `API key not valid: ${KEY}` } }));
    expect(refused).toMatch(/Gemini API 403: the key was refused/);
    expect(refused).not.toContain(KEY);
    expect(refused).toContain('***');
    expect(await fail(429, JSON.stringify({ error: { message: 'quota', details: [{ quotaId: 'free_tier', quotaValue: '0' }] } }) + ' limit: 0')).toMatch(/free tier/);
    expect(await fail(500, '{"error":{"message":"backend"}}')).toBe('Gemini API 500: backend');
    expect(await askGemini({ prompt: 'p', media: { kind: 'frames', files: [frame] }, model: 'm', key: KEY, http: mockGemini({ text: '' }).http, sleep: noSleep }).catch((e: Error) => e.message)).toMatch(/no text/);
  });

  it('the key from the environment; the help never names one', () => {
    expect(geminiKey({ GEMINI_API_KEY: 'k1' })).toBe('k1');
    expect(geminiKey({ GOOGLE_API_KEY: 'k2' })).toBe('k2');
    expect(geminiKey({})).toBeNull();
    expect(geminiKey({ GEMINI_VIA_NETWORK: '1' })).toBe('');
    expect(GEMINI_KEY_HELP).toContain('GEMINI_API_KEY');
    expect(redact(`a ${KEY} b ${KEY}`, KEY)).toBe('a *** b ***');
    expect(redact('text', '')).toBe('text');
  });

  it('secondOpinion writes qa/design-gemini.md with the answer and its format check — and never the key', async () => {
    const dir = join(tmp, 'garage');
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'id: garage\n');
    const loc = locateGame(dir);
    const m = mockGemini({ text: `${ANSWER}\n(key ${KEY})` });
    const res = await secondOpinion(loc, GAME, facts({ run: { ...facts().run!, frames: [{ sec: 0, file: video, label: 'x' }] } }), { key: KEY, model: 'gemini-x', seconds: 75, run: null, date: '2026-10-20', http: m.http, sleep: noSleep, videoFile: video });
    expect(res.error).toBeUndefined();
    const md = readFileSync(res.file!, 'utf8');
    expect(res.file).toBe(join(dir, 'qa', DESIGN_GEMINI));
    expect(md).toMatch(/^<!-- gp design --gemini, 2026-10-20: gemini-x, shown the video inline/);
    expect(md).toContain('# Garage Evolution — design proposals');
    expect(md).toMatch(/Format check \(gp design's parser\): well-formed — Top 3 \+ 6 proposals in the sections \(1 high\), 2 of the genre's hits/);
    expect(md).not.toContain(KEY);
    // First the one-word check, then the prompt with the video
    expect(body(m.calls[0].req).contents[0].parts).toEqual([{ text: PROBE_TEXT }]);
    expect(body(m.calls[1].req).contents[0].parts[1].text).toContain('You are a senior game designer');
    // Nothing to show: an error, no file
    expect(await secondOpinion(loc, GAME, facts(), { key: KEY, model: 'm', seconds: 75, run: null, date: 'd', http: m.http, videoFile: null })).toMatchObject({ file: null, error: expect.stringMatching(/nothing to show Gemini/) });
    expect(geminiMarkdown({ title: 'X' }, { text: '# X\n', model: 'm', sent: 's' }, 'd', 'w')).toMatch(/Format check .*problem/);
  });
});

describe('gp design (the command)', () => {
  const env = { ...process.env, GP_NO_LOG: '1', NO_COLOR: '1', GEMINI_API_KEY: '', GOOGLE_API_KEY: '', GEMINI_VIA_NETWORK: '' };
  function gp(args: string[]): { code: number; out: string } {
    try {
      return { code: 0, out: execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), ...args], { cwd: ROOT, encoding: 'utf8', env, stdio: ['ignore', 'pipe', 'pipe'] }) };
    } catch (e) {
      const x = e as { status: number; stdout: string; stderr: string };
      return { code: x.status, out: x.stdout + x.stderr };
    }
  }

  it('writes the brief without a run; --gemini without a key says how to set it and the rest still works; --check judges design.md', { timeout: 120_000 }, () => {
    const dir = join(tmp, 'forge');
    cpSync(join(ROOT, 'docs/examples/art'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) });
    const r = gp(['design', dir, '--no-capture', '--gemini']);
    expect(r.code, r.out).toBe(0);
    expect(r.out).toMatch(/--gemini skipped\. No Gemini API key: set GEMINI_API_KEY/);
    expect(r.out).toContain(DESIGN_BRIEF);
    const brief = readFileSync(join(dir, 'qa', DESIGN_BRIEF), 'utf8');
    expect(brief).toMatch(/^# Forge Night — game design brief/);
    expect(brief).toContain('No run captured');
    expect(existsSync(join(dir, 'qa', DESIGN_GEMINI))).toBe(false);

    expect(gp(['design', dir, '--check'])).toMatchObject({ code: 1, out: expect.stringMatching(/design\.md is missing/) });
    writeFileSync(join(dir, 'design.md'), GOOD);
    const ok = gp(['design', dir, '--check']);
    expect(ok.code, ok.out).toBe(0);
    expect(ok.out).toMatch(/✓ forge: design\.md — Top 3 \+ 6 proposals in the sections \(1 high\), 2 of the genre's hits/);
    writeFileSync(join(dir, 'design.md'), GOOD.replace('the chain counter · effort S', 'the chain counter'));
    const bad = gp(['design', dir, '--check']);
    expect(bad.code).toBe(1);
    expect(bad.out).toMatch(/design\.md:\d+ {2}effort: none at the end of "[^"]*the chain counter"/);
    expect(gp(['design', dir, '--minutes', '99']).out).toMatch(/--minutes 99: 1 to 15/);
  });
});

// --- The friction of the first real run (Idle Garage Evolution 1.5.0) ------------------------------------------------

/**
 * A scripted Gemini: per model, what generateContent answers (a status and a body; 200 by default), and models.list.
 * Every request is recorded; the key is echoed into error bodies, so a test sees whether it ever leaks
 */
function scriptedGemini(by: Record<string, { status: number; text?: string }[] | { status: number; text?: string }>, list: { name: string; supportedGenerationMethods?: string[] }[] = []) {
  const calls: { req: HttpRequest; key: string }[] = [];
  const queues = new Map(Object.entries(by).map(([k, v]) => [k, Array.isArray(v) ? [...v] : v]));
  const http: GeminiHttp = async (req, key): Promise<HttpResponse> => {
    calls.push({ req, key });
    if (req.method === 'GET' && req.url.includes('/v1beta/models?')) return { status: 200, headers: {}, text: JSON.stringify({ models: list }) };
    if (req.url.endsWith('/upload/v1beta/files')) return { status: 200, headers: { 'x-goog-upload-url': 'https://upload.example/s' }, text: '{}' };
    if (req.url === 'https://upload.example/s') return { status: 200, headers: {}, text: JSON.stringify({ file: { name: 'files/v', uri: 'https://generativelanguage.googleapis.com/v1beta/files/v', mimeType: 'video/mp4', state: 'ACTIVE' } }) };
    const model = decodeURIComponent(req.url.match(/models\/([^:]+):generateContent/)?.[1] ?? '');
    const q = queues.get(model);
    const next = Array.isArray(q) ? (q.length > 1 ? q.shift()! : q[0]) : q;
    if (next && next.status !== 200) return { status: next.status, headers: {}, text: (next.text ?? '').replaceAll('$KEY', key) };
    return { status: 200, headers: {}, text: JSON.stringify({ candidates: [{ content: { parts: [{ text: next?.text ?? ANSWER }] } }] }) };
  };
  const models = () => calls.filter((c) => c.req.url.includes(':generateContent')).map((c) => decodeURIComponent(c.req.url.match(/models\/([^:]+):/)![1]));
  return { http, calls, models };
}
const err = (message: string, extra: Record<string, unknown> = {}) => JSON.stringify({ error: { message, ...extra } });
const FREE_TIER_429 = err('You exceeded your current quota. Quota exceeded for metric: generativelanguage.googleapis.com/generate_content_free_tier_requests, limit: 0, model: gemini-3.1-pro (key $KEY)', { details: [{ quotaId: 'GenerateRequestsPerDayPerProjectPerModel-FreeTier', quotaValue: '0' }] }) + ' free_tier';

describe('Gemini: the model a new key can use (the mocked transport)', () => {
  const video = join(tmp, 'gameplay-fallback.mp4');
  writeFileSync(video, Buffer.alloc(4096, 3));

  it('the default is a Flash model; the parts of a refusal are read: a named replacement, no quota, the newest Flash', () => {
    expect(DEFAULT_DESIGN_MODEL).toMatch(/flash/);
    expect(FLASH_MODEL).toMatch(/flash/);
    expect(replacementModel(err('models/gemini-2.5-pro is no longer available to new users. Please use gemini-3.1-pro-preview instead.'), 'gemini-2.5-pro')).toBe('gemini-3.1-pro-preview');
    expect(replacementModel(err('Model gemini-2.5-flash is not found for API version v1beta. Use gemini-3.8-flash.'), 'gemini-2.5-flash')).toBe('gemini-3.8-flash');
    expect(replacementModel(err('models/gemini-x is not found for API version v1beta'), 'gemini-x')).toBeNull();
    expect(replacementModel(err('gemini-x is retired; please update to the latest model, gemini-4.1-flash.'), 'gemini-x')).toBe('gemini-4.1-flash');
    expect(replacementModel(err('gemini-x was retired (see gemini-4.1-flash).'), 'gemini-x')).toBe('gemini-4.1-flash');
    expect(noQuota(429, FREE_TIER_429)).toBe(true);
    expect(noQuota(429, err('Resource has been exhausted (e.g. check quota).', { details: [{ retryDelay: '17s' }] }))).toBe(false);
    expect(nextModel('gemini-3.1-pro-preview', new GeminiError('x', 429, FREE_TIER_429))).toMatchObject({ model: FLASH_MODEL, why: expect.stringMatching(/no quota on this key — the free tier gives Pro none/) });
    expect(nextModel(FLASH_MODEL, new GeminiError('x', 429, FREE_TIER_429))).toBeNull();
    expect(newestFlash([{ name: 'models/gemini-2.5-flash' }, { name: 'models/gemini-3.8-flash-lite' }, { name: 'models/gemini-3.8-flash-preview-09' }, { name: 'models/gemini-3.8-flash' }, { name: 'models/gemini-3.8-flash-image' }, { name: 'models/gemini-4.0-flash', supportedGenerationMethods: ['embedContent'] }])).toBe('gemini-3.8-flash');
  });

  it("Garage's five tries in one: an old Pro (404, names the preview) → the preview (429, no quota) → Flash, before any video; the key never in a message", async () => {
    const g = scriptedGemini({
      'gemini-2.5-pro': { status: 404, text: err('models/gemini-2.5-pro is no longer available to new users. Please use gemini-3.1-pro-preview instead.') },
      'gemini-3.1-pro-preview': { status: 429, text: FREE_TIER_429 },
    });
    const log: string[] = [];
    const r = await resolveModel({ model: 'gemini-2.5-pro', key: KEY, http: g.http, sleep: noSleep, log: (l) => log.push(l) });
    expect(r.model).toBe(FLASH_MODEL);
    expect(g.models()).toEqual(['gemini-2.5-pro', 'gemini-3.1-pro-preview', FLASH_MODEL]);
    // The checks are one-word questions: no media
    for (const c of g.calls) expect(JSON.stringify(c.req.body)).not.toContain('inlineData');
    expect(log.join('\n')).toMatch(/gemini-2\.5-pro is not available to this key \(404\); the API names gemini-3\.1-pro-preview/);
    expect(log.join('\n')).toMatch(/gemini-3\.1-pro-preview has no quota on this key — the free tier gives Pro none/);
    expect(r.notes).toHaveLength(2);
    expect(JSON.stringify({ log, r })).not.toContain(KEY);
    for (const c of g.calls) expect(c.req.url + JSON.stringify(c.req.headers ?? {})).not.toContain(KEY);
  });

  it('a 404 that names nothing: the newest Flash the key lists; no model at all: an error without the key', async () => {
    const g = scriptedGemini({ 'gemini-old-flash': { status: 404, text: err(`models/gemini-old-flash is not found ($KEY)`) } }, [{ name: 'models/gemini-3.8-flash', supportedGenerationMethods: ['generateContent'] }]);
    expect((await resolveModel({ model: 'gemini-old-flash', key: KEY, http: g.http, sleep: noSleep })).model).toBe('gemini-3.8-flash');
    const none = scriptedGemini({ 'gemini-old-flash': { status: 404, text: err(`gone ($KEY)`) } }, []);
    const e = await resolveModel({ model: 'gemini-old-flash', key: KEY, http: none.http, sleep: noSleep }).then(() => null, (x: Error) => x);
    expect(e?.message).toMatch(/Gemini API 404/);
    expect(e?.message).not.toContain(KEY);
    // Flash itself without quota: said plainly, no loop
    const flash = scriptedGemini({ [FLASH_MODEL]: { status: 429, text: FREE_TIER_429 } });
    const f = await resolveModel({ model: FLASH_MODEL, key: KEY, http: flash.http, sleep: noSleep }).then(() => null, (x: Error) => x);
    expect(f?.message).toMatch(/no quota for this model \(the free tier gives it none/);
    expect(f?.message).not.toContain(KEY);
    expect(flash.models()).toEqual([FLASH_MODEL]);
  });

  it('a 502 with the video inline: one retry, then the Files API', async () => {
    const g = scriptedGemini({ m: [{ status: 502, text: err('upstream request failed') }, { status: 502, text: err('upstream request failed') }, { status: 200 }] });
    const log: string[] = [];
    const a = await askGemini({ prompt: 'p', media: { kind: 'video', file: video }, model: 'm', key: KEY, http: g.http, sleep: noSleep, log: (l) => log.push(l) });
    const seq = g.calls.map((c) => `${c.req.method} ${c.req.url.replace(/^https:\/\/[^/]+/, '')}`);
    expect(seq).toEqual(['POST /v1beta/models/m:generateContent', 'POST /v1beta/models/m:generateContent', 'POST /upload/v1beta/files', 'POST /s', 'POST /v1beta/models/m:generateContent']);
    expect(body(g.calls[0].req).contents[0].parts[0]).toHaveProperty('inlineData');
    expect(body(g.calls[4].req).contents[0].parts[0]).toEqual({ fileData: { mimeType: 'video/mp4', fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/v' } });
    expect(a.sent).toMatch(/Files API/);
    expect(a.notes.join()).toMatch(/502: upstream request failed with the video inline, after a retry: sending it through the Files API/);
    expect(log.join()).toMatch(/through the Files API/);
  });

  it('a 404 at the real question still goes to the named model once', async () => {
    const g = scriptedGemini({ old: { status: 404, text: err('Please use gemini-3.8-flash instead.') } });
    const a = await askGemini({ prompt: 'p', media: { kind: 'video', file: video }, model: 'old', key: KEY, http: g.http, sleep: noSleep });
    expect(a.model).toBe('gemini-3.8-flash');
    expect(a.notes[0]).toMatch(/names gemini-3\.8-flash/);
  });

  it('secondOpinion checks the model before the video: no model, no recording, the error says so', async () => {
    const dir = join(tmp, 'garage-q');
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'id: garage-q\n');
    const g = scriptedGemini({ 'gemini-3.1-pro-preview': { status: 429, text: FREE_TIER_429 }, [FLASH_MODEL]: { status: 429, text: FREE_TIER_429 } });
    const logs: string[] = [];
    // videoFile undefined: a video would be recorded (a dev server, a browser) — it must never get there
    const res = await secondOpinion(locateGame(dir), GAME, facts(), { key: KEY, model: 'gemini-3.1-pro-preview', seconds: 90, run: null, date: 'd', http: g.http, sleep: noSleep, log: (l) => logs.push(l) });
    expect(res.file).toBeNull();
    expect(res.error).toMatch(/no quota .* — no video was recorded/);
    expect(logs.join('\n')).toMatch(/gemini-3\.1-pro-preview has no quota on this key — the free tier gives Pro none/);
    expect(JSON.stringify({ res, logs })).not.toContain(KEY);
    // A fallback that answers: the file says which model and why
    const ok = scriptedGemini({ 'gemini-3.1-pro-preview': { status: 429, text: FREE_TIER_429 } });
    const done = await secondOpinion(locateGame(dir), GAME, facts(), { key: KEY, model: 'gemini-3.1-pro-preview', seconds: 90, run: null, date: 'd', http: ok.http, sleep: noSleep, videoFile: video });
    expect(done.model).toBe(FLASH_MODEL);
    expect(readFileSync(done.file!, 'utf8')).toMatch(new RegExp(`^<!-- gp design --gemini, d: ${FLASH_MODEL.replace(/\./g, '\\.')}, .*On the way: gemini-3\\.1-pro-preview has no quota`));
  });
});

describe("the brief: the build the scores measured, the game's records by repo, own code, the run's auto-continue", () => {
  const loc = { id: 'garage', dir: '/g', file: '/g/game.yaml' };
  const updates: UpdateEntry[] = [
    { game: 'garage-evolution', repo: 'QmaCyber/game19', version: '1.0.0', date: '2026-10-13' },
    { game: 'garage-evolution', repo: 'QmaCyber/game19', version: '1.2.0', date: '2026-10-14' },
    { game: 'garage-evolution', repo: 'QmaCyber/game19', version: '1.3.6', date: '2026-10-17' },
    { game: 'garage-evolution', repo: 'QmaCyber/game19', version: '1.4.0', date: '2026-10-19' },
    { game: 'garage-evolution', repo: 'QmaCyber/game19', version: '1.5.0', date: '2026-10-20' },
  ];
  const rec = (version?: string): RecordedResult =>
    ({ game: 'garage-evolution', title: 'Idle Garage Evolution', repo: 'QmaCyber/game19', channel: 'crazygames', basicLaunch: { verdict: 'stopped', scores: { date: '2026-10-20', ...(version ? { version } : {}), desktop: { playtime: { value: 8.28, score: 3 }, d1: { score: 2 }, conversion: { score: 3 } } } } }) as RecordedResult;

  it('each score screen says the build it measured: recorded, or inferred from updates.yaml (and says so)', () => {
    expect(measuredBuild(rec('1.0.0–1.3.6'), updates)).toEqual({ version: '1.0.0–1.3.6', inferred: false });
    expect(measuredBuild(rec(), updates)).toEqual({ version: '1.0.0–1.4.0', inferred: true });
    expect(measuredBuild(rec(), [])).toBeNull();
    expect(buildLabel(null)).toMatch(/not recorded/);
    const s = ownMetricsSection([rec('1.0.0–1.3.6')], { updates, current: '1.5.0' }).join('\n');
    expect(s).toContain('**The score screen of 2026-10-20 measured build 1.0.0–1.3.6.** This checkout is 1.5.0: what changed since 1.3.6');
    expect(s).toContain('| Device (build 1.0.0–1.3.6) |');
    expect(ownMetricsSection([rec()], { updates, current: '1.4.0' }).join('\n')).toMatch(/measured build 1\.0\.0–1\.4\.0\? \(inferred: .*\)\.\*\* This checkout is 1\.4\.0\./);
    expect(stopsLines([rec('1.0.0–1.3.6')])).toEqual(['- Idle Garage Evolution (2026-10-20, build 1.0.0–1.3.6): Desktop 8/15 (playtime 3 · D1 2 · conversion 3)']);
    const b = designBrief(loc, { ...GAME, version: { name: '1.5.0', code: 15 } } as ResolvedGame, facts({ own: [rec('1.0.0–1.3.6')], updates }), '2026-10-20');
    expect(b).toContain('measured build 1.0.0–1.3.6');
    expect(b).toContain('This checkout is 1.5.0');
  });

  it("the game's records by repo too — but a repository reused for another game is not this game's history", () => {
    const results = [
      rec(),
      { game: 'germ-bait', title: 'Germ Bait', repo: 'QmaCyber/game6', channel: 'crazygames', review: { verdict: 'rejected' } },
      { game: 'velvet-domino-rogue', title: 'Velvet Domino Rogue', repo: 'QmaCyber/game6', channel: 'crazygames', review: { verdict: 'rejected' } },
    ] as RecordedResult[];
    // game.yaml says idle-garage-evolution with another title: found by its repo
    expect(ownResults(results, { id: 'idle-garage-evolution', title: 'Garage Evo' }, { id: 'idle-garage-evolution' }, 'https://github.com/QmaCyber/game19.git').map((r) => r.game)).toEqual(['garage-evolution']);
    expect(ownResults(results, { id: 'idle-garage-evolution', title: 'Garage Evo' }, { id: 'x' }, null)).toEqual([]);
    // A new game in game6: none of the old games' records
    expect(ownResults(results, { id: 'kite-royale', title: 'Kite Royale' }, { id: 'kite-royale' }, 'QmaCyber/game6')).toEqual([]);
    expect(ownResults(results, { id: 'velvet-domino', title: 'Velvet Domino' }, { id: 'velvet-domino' }, 'QmaCyber/game6').map((r) => r.game)).toEqual(['velvet-domino-rogue']);
    // gp submission --full's history (the forecast's resubmission): by repo too
    expect(resubmissionOf(results, { ids: ['idle-garage-evolution'], repo: 'QmaCyber/game19' }, 'crazygames')?.kind).toBe('after-stop');
    expect(resubmissionOf(results, 'idle-garage-evolution', 'crazygames')).toBeNull();
    expect(recordsOf(results, { ids: [], repo: 'http://local_proxy@127.0.0.1:1234/git/QmaCyber/game19' })).toHaveLength(1);
  });

  it('a must-have the game builds in its own code (money.covers): ✓ own code in the brief, no I_GENRE_EXPECTS; a wrong id warns', () => {
    const g = { kit: { kit: 'code' }, audience: { id: 'general' }, money: { genre: 'idle', covers: { shop: 'the garage list with ×1 / ×10 / MAX (src/garage/shop.ts)' } }, listing: { tags: [] } } as unknown as ResolvedGame;
    const f = genreFacts(g, [], 'const perSec = 3;');
    expect(f.expects.find((e) => e.id === 'shop')).toMatchObject({ have: true, own: 'the garage list with ×1 / ×10 / MAX (src/garage/shop.ts)' });
    const b = designBrief(loc, GAME, facts({ genre: f }), '2026-10-20');
    expect(b).toMatch(/- ✓ own code a level shop: .* \(`shop`\) — money\.covers: the garage list with ×1 \/ ×10 \/ MAX/);
    const issues = genreChecks({ genre: 'idle', sub: null, from: 'money.genre idle', named: true, imported: ['offlineEarnings', 'Prestige', 'formatAmount'], source: '', money: { genre: 'idle', covers: { shop: 'src/garage/shop.ts: ×1 / ×10 / MAX', 'level-shop': 'the same' } } });
    expect(issues.map((i) => i.code)).toEqual(['W_MONEY_COVERS']);
    expect(issues[0].message).toMatch(/money\.covers "level-shop" is no must-have of Idle .*: growth, shop, offline, prestige/);
    // Without covers the hint names it, and says how to declare it
    const hint = genreChecks({ genre: 'idle', sub: null, from: 'money.genre idle', named: true, imported: ['offlineEarnings', 'Prestige', 'formatAmount'], source: '', money: { genre: 'idle' } });
    expect(hint.map((i) => i.code)).toEqual(['I_GENRE_EXPECTS']);
    expect(hint[0].fix).toMatch(/money\.covers: \{ shop: "<where it is>" \}/);
  });

  it('a results card that went on by itself is no stop; the frames carry host.qa({ state })', () => {
    const run = { ...facts().run!, breaks: [{ atSec: 25, taps: [], how: 'auto' as const, autoSec: 3 }, { atSec: 50, taps: [], how: 'auto' as const, autoSec: 3 }, { atSec: 70, taps: ['next'], how: 'tap' as const }], state: false };
    const s = runSection('garage', run).join('\n');
    expect(s).toMatch(/1 stop\(s\) a player meets; 2 results card\(s\) that went on by themselves \(auto-continue: \*\*not stops\*\*/);
    expect(s).toContain('- 0:25: the card went on by itself after its 3-s countdown (mountResults autoContinueSec) — not a stop');
    expect(s).toContain('- 1:10: tapped `next`');
    expect(s).toMatch(/has no `host\.qa\(\{ state \}\)`/);
    expect(withState('in play', { screen: 'play', stage: 'garage 2, car 3 of 8', goal: '3/5 cars', touch: [{ x: 1, y: 2, label: 'nut' }] })).toBe('in play — garage 2, car 3 of 8 · goal: 3/5 cars · touch: nut');
    expect(withState('stopped: between runs', { screen: 'results' })).toBe('stopped: between runs — screen results');
    expect(withState('the first screen', null)).toBe('the first screen');
  });

  it('the brief sends the designer to a frozen build, with the URL when gp design --serve keeps one up; ?qa-demo=0 and qaState()', () => {
    const b = designBrief(loc, GAME, facts(), '2026-10-20', { url: 'http://localhost:5199/' });
    expect(b).toContain('**http://localhost:5199/** (`gp design --serve` keeps it up: no file watcher, no HMR)');
    expect(b).toContain('`npm run gp -- dev garage --frozen`');
    expect(b).toMatch(/Never the plain `gp dev` while you play: its HMR reloads the page/);
    expect(b).toContain("await page.goto('http://localhost:5199/' + '?seed=1&qa-demo=0');");
    expect(b).toContain('window.__gp.host.qaState()');
    expect(designBrief(loc, GAME, facts(), '2026-10-20')).toContain("await page.goto(URL + '?seed=1&qa-demo=0');");
    expect(designBrief(loc, GAME, facts({ run: { ...facts().run!, state: true } }), '2026-10-20')).toMatch(/This game says where it is: `window\.__gp\.host\.qaState\(\)`/);
  });
});
