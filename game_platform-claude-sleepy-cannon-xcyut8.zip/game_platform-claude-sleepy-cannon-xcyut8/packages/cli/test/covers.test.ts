// gp covers refuses a page that shows the player's can't-run screen (Kettlebot: a TDZ error in coverFrame gave a ✓), and
// takes the game's cover hook even when the game flagged its own frame before the hook was registered

import { chromium, type Browser } from 'playwright';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { coverProblem, waitForCover } from '../src/covers.ts';

describe('coverProblem', () => {
  it('passes a page that shows the game', () => {
    expect(coverProblem('landscape', false, [])).toBeNull();
  });
  it('fails the can\'t-run screen and names the error', () => {
    const p = coverProblem('landscape', true, ["Cannot access 'LANES' before initialization"]);
    expect(p).toContain("can't run");
    expect(p).toContain('LANES');
  });
});

// gp covers and gp video take the cover hook even when the game flags its own frame first (Idle Garage Evolution 1.5.1:
// the hook waited for its car's chapter, the frame was flagged at boot, and the covers were shot from the plain frame)
describe('waitForCover: a hook that comes after the frame flag still wins, every wait bounded', () => {
  let browser: Browser;
  beforeAll(async () => {
    browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  }, 60_000);
  afterAll(async () => {
    await browser?.close();
  });
  /** A page like a code game at ?cover=1: the host, its driver, start() done at `loadedAt`, the hook at `hookAt` */
  const page = async (o: { host?: boolean; flagAt?: number; loadedAt?: number; hookAt?: number }) => {
    const p = await browser.newPage();
    await p.setContent('<body></body>');
    await p.evaluate((o) => {
      const host: { isLoaded: boolean; qaDriver: { cover?: unknown } } = { isLoaded: false, qaDriver: {} };
      if (o.host !== false) (window as unknown as { __gp: unknown }).__gp = { host };
      const at = (ms: number | undefined, f: () => void) => ms !== undefined && (ms ? setTimeout(f, ms) : f());
      at(o.flagAt, () => (document.body.dataset.cover = 'ready'));
      at(o.loadedAt, () => (host.isLoaded = true));
      at(o.hookAt, () => (host.qaDriver = { cover: { scene() {} } }));
    }, o);
    return p;
  };
  const timed = async (f: () => Promise<{ found: string | null; notes: string[] }>) => {
    const t0 = Date.now();
    const r = await f();
    return { ...r, ms: Date.now() - t0 };
  };

  it('the frame flagged at once, the hook after the game is loaded: the hook, with a note', async () => {
    const p = await page({ flagAt: 0, loadedAt: 300, hookAt: 900 });
    const r = await timed(() => waitForCover(p, { graceMs: 3000 }));
    expect(r.found).toBe('hook');
    expect(r.notes.join(' ')).toContain('after body[data-cover=ready]');
    expect(r.ms).toBeLessThan(3000);
  });

  it('a frame and no hook: the frame, after the grace period', async () => {
    const p = await page({ flagAt: 0, loadedAt: 200 });
    const r = await timed(() => waitForCover(p, { graceMs: 600 }));
    expect(r).toMatchObject({ found: 'frame', notes: [] });
    expect(r.ms).toBeGreaterThanOrEqual(700);
    expect(r.ms).toBeLessThan(3000);
  });

  it('a hook at once is composed only once start() is done', async () => {
    const p = await page({ hookAt: 0, loadedAt: 700 });
    const r = await timed(() => waitForCover(p));
    expect(r).toMatchObject({ found: 'hook', notes: [] });
    expect(r.ms).toBeGreaterThanOrEqual(650);
  });

  it('a start() that never finishes: taken anyway, bounded, and said', async () => {
    const p = await page({ hookAt: 0 });
    const r = await timed(() => waitForCover(p, { startMs: 500 }));
    expect(r.found).toBe('hook');
    expect(r.notes.join(' ')).toContain("start() hadn't finished");
    expect(r.ms).toBeLessThan(2500);
  });

  it('a block kit (no host): its frame at once; nothing at all: null', async () => {
    const kit = await page({ host: false, flagAt: 0 });
    const k = await timed(() => waitForCover(kit));
    expect(k).toMatchObject({ found: 'frame', notes: [] });
    expect(k.ms).toBeLessThan(1000);
    const none = await page({ loadedAt: 0 });
    expect((await waitForCover(none, { waitMs: 300 })).found).toBeNull();
  });
});
