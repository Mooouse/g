// gp art: the pipeline end to end on the mock provider (no network) — style board, cut-out sprites, a cropped background,
// assets/index.ts, provenance.yaml and the validate checks; the prompts and sizes as pure functions.

import { cpSync, existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { parse } from 'yaml';
import { artChecks, processImage, aspectFor, assetPrompt, framePrompt, freeTierBlocked, generateArt, indexSource, quotaMessage, recordArt, retryDelaySec, sha256, targetSize, type ArtSpec } from '../src/art.ts';
import { checkGame } from '../src/game.ts';
import { locateGame, ROOT } from '../src/paths.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-art-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

const ART = `art:
  style: "chunky cartoon shapes, soft cel shading, warm dusk light from the upper left"
  keep: ["a microscope slide at dusk"]
  assets:
    - { id: hero-cell, kind: sprite, prompt: "a round friendly cell with big eyes", size: 128 }
    - { id: sky, kind: background, prompt: "a dusky microscope slide", size: [640, 360] }
`;

function game(): ReturnType<typeof locateGame> {
  const dir = join(tmp, 'g');
  cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|dist-playgama|qa|node_modules|store|submission|assets)$/.test(f) });
  writeFileSync(join(dir, 'game.yaml'), readFileSync(join(dir, 'game.yaml'), 'utf8') + '\n' + ART);
  return locateGame(dir);
}

describe('gp art', () => {
  const spec: ArtSpec = { style: 'chunky vector, dusk light', assets: [{ id: 'hero', kind: 'sprite', prompt: 'a knight' }, { id: 'bg', kind: 'background', prompt: 'a crypt', size: [1280, 720] }] };

  it('asks for sprites on the key and backgrounds full-bleed, in the style, at the right aspect', () => {
    expect(assetPrompt(spec, spec.assets[0]!, true)).toMatch(/flat pure green \(#00FF00\) background[\s\S]*Match the attached style reference/);
    expect(assetPrompt(spec, spec.assets[1]!, false)).toMatch(/full-bleed/);
    expect(aspectFor(spec.assets[0]!)).toBe('1:1');
    expect(aspectFor(spec.assets[1]!)).toBe('16:9');
    expect(targetSize(spec.assets[0]!)).toEqual([256, 256]);
    expect(indexSource(spec)).toContain("export const ART = { hero, bg } as const;");
  });

  it('makes the style board and every asset, cuts sprites out, records provenance, and validate is clean', async () => {
    const loc = game();
    expect(artChecks(loc).map((i) => i.code)).toContain('W_ART_MISSING');
    const res = await generateArt(loc, { provider: 'mock' });
    expect(res.made).toEqual(['style.webp', 'hero-cell.webp', 'sky.webp']);
    expect(res.warnings).toEqual([]);
    const dir = join(loc.dir, 'assets');
    for (const f of ['style.webp', 'hero-cell.webp', 'sky.webp', 'index.ts', 'provenance.yaml']) expect(existsSync(join(dir, f)), f).toBe(true);
    // WebP files, the sprite trimmed into its bound, the background exactly its size
    expect(readFileSync(join(dir, 'hero-cell.webp')).subarray(8, 12).toString()).toBe('WEBP');
    const prov = parse(readFileSync(join(dir, 'provenance.yaml'), 'utf8'));
    expect(Math.max(...prov.files['hero-cell.webp'].size)).toBeLessThanOrEqual(128);
    expect(prov.files['sky.webp'].size).toEqual([640, 360]);
    expect(prov.files['hero-cell.webp'].sha256).toBe(sha256(readFileSync(join(dir, 'hero-cell.webp'))));
    expect(prov.files['hero-cell.webp'].style).toBe(prov.files['style.webp'].sha256);
    expect(prov.files['hero-cell.webp'].prompt).toContain('a round friendly cell');
    expect(readFileSync(join(dir, 'index.ts'), 'utf8')).toContain("import heroCell from './hero-cell.webp';");
    expect(artChecks(loc)).toEqual([]);
    expect(checkGame(loc, 'dev').issues.filter((i) => i.code.includes('_ART_'))).toEqual([]);
    // A second run keeps what exists
    expect((await generateArt(loc, { provider: 'mock' })).made).toEqual([]);
  }, 60000);

  it('flags a hand-edited image until --record, and a duplicate id as an error', async () => {
    const loc = locateGame(join(tmp, 'g'));
    const f = join(loc.dir, 'assets', 'sky.webp');
    writeFileSync(f, Buffer.concat([readFileSync(f), Buffer.from([0])]));
    expect(artChecks(loc).map((i) => i.code)).toEqual(['W_ART_PROVENANCE']);
    expect(recordArt(loc)).toEqual(['sky.webp']);
    expect(artChecks(loc)).toEqual([]);
    expect(parse(readFileSync(join(loc.dir, 'assets', 'provenance.yaml'), 'utf8')).files['sky.webp'].edited).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    writeFileSync(loc.file, readFileSync(loc.file, 'utf8') + '    - { id: sky, kind: tile, prompt: "slide glass texture" }\n');
    expect(artChecks(loc).map((i) => i.code)).toContain('E_ART_ID');
  });
});

describe('gp art: the cartoon look', () => {
  it('sends the house cartoon style with every request and warns on realism words', async () => {
    const { HOUSE_STYLE, REALISM_WORDS, stylePrompt } = await import('../src/art.ts');
    const spec: ArtSpec = { style: 'chunky cartoon shapes', assets: [{ id: 'hero', kind: 'sprite', prompt: 'a knight' }] };
    expect(assetPrompt(spec, spec.assets[0]!, false)).toContain(HOUSE_STYLE);
    expect(stylePrompt(spec)).toContain('Not photorealistic');
    expect(REALISM_WORDS.test('photorealistic 8k knight')).toBe(true);
    expect(REALISM_WORDS.test('chunky cartoon shapes, soft cel shading')).toBe(false);
  });
  it('pixel art: the pixel house style in sentences, and a warning on blend words', async () => {
    const { PIXEL_STYLE, PIXEL_BLEND_WORDS } = await import('../src/art.ts');
    const spec: ArtSpec = { style: 'dark crypt pixel art, candle light', technique: 'pixel', assets: [{ id: 'hero', kind: 'sprite', prompt: 'a knight', size: 32 }] };
    expect(assetPrompt(spec, spec.assets[0]!, false)).toContain(PIXEL_STYLE);
    expect(PIXEL_STYLE).toMatch(/hue-shifted steps[\s\S]*1-pixel dark outline/);
    expect(PIXEL_BLEND_WORDS.test('pixel knight, smooth shading, soft lighting')).toBe(true);
    expect(PIXEL_BLEND_WORDS.test('3–4 hue-shifted steps, flat fills, 1-px outline')).toBe(false);
  });
});

describe('gp art: animation frames and the key art', () => {
  const ANIM = `art:
  style: "chunky cartoon shapes, soft cel shading, warm dusk light from the upper left"
  keep: ["a crypt lit by the hero's candle"]
  assets:
    - { id: hero, kind: sprite, prompt: "a little living candle", size: 128, frames: ["walking, left foot forward", "walking, right foot forward"] }
    - { id: cover, kind: keyart, prompt: "the candle facing a ghoul in a crypt", size: [640, 360] }
`;
  it('paints each frame from its sprite at the sprite\'s scale, and the key art after the hero', async () => {
    const dir = join(tmp, 'anim');
    cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|dist-playgama|qa|node_modules|store|submission|assets)$/.test(f) });
    writeFileSync(join(dir, 'game.yaml'), readFileSync(join(dir, 'game.yaml'), 'utf8') + '\n' + ANIM);
    const loc = locateGame(dir);
    expect(artChecks(loc).find((i) => i.code === 'W_ART_MISSING')?.message).toContain('hero-1');
    const res = await generateArt(loc, { provider: 'mock' });
    expect(res.made).toEqual(['style.webp', 'hero.webp', 'hero-1.webp', 'hero-2.webp', 'cover.webp']);
    const prov = parse(readFileSync(join(dir, 'assets', 'provenance.yaml'), 'utf8'));
    expect(prov.files['hero-1.webp'].from).toBe(prov.files['hero.webp'].sha256);
    expect(prov.files['hero-1.webp'].scale).toBe(prov.files['hero.webp'].scale);
    expect(prov.files['hero-2.webp'].prompt).toContain('Only the pose changes: walking, right foot forward');
    expect(prov.files['cover.webp'].size).toEqual([640, 360]);
    expect(prov.files['cover.webp'].prompt).toMatch(/second reference image \(a little living candle\)/);
    const index = readFileSync(join(dir, 'assets', 'index.ts'), 'utf8');
    expect(index).toContain("import heroF2 from './hero-2.webp';");
    expect(index).toContain('export const FRAMES = { hero: [heroF1, heroF2] } as const;');
    expect(artChecks(loc)).toEqual([]);
    // A new sprite repaints its frames; the key art stays
    const again = await generateArt(loc, { provider: 'mock', only: ['hero'] });
    expect(again.made).toEqual(['hero.webp', 'hero-1.webp', 'hero-2.webp']);
    // Frames on a still image, or a frame file that is another asset's id, are errors
    writeFileSync(loc.file, readFileSync(loc.file, 'utf8') + '    - { id: hero-1, kind: tile, prompt: "wax floor", frames: ["melting"] }\n');
    expect(artChecks(loc).map((i) => i.code)).toEqual(expect.arrayContaining(['E_ART_ID', 'E_ART_FRAMES']));
  }, 60000);

  it('asks for the same character with one pose changed', () => {
    const spec: ArtSpec = { style: 'chunky cartoon', assets: [{ id: 'hero', kind: 'sprite', prompt: 'a candle', frames: ['jumping'] }] };
    expect(framePrompt(spec, spec.assets[0]!, 'jumping')).toMatch(/exactly the same character[\s\S]*Only the pose changes: jumping[\s\S]*#00FF00/);
  });
});

describe('gp art: the quota', () => {
  // The answer of a key on the free tier (2026-10-10): no image quota at all
  const FREE = JSON.stringify({ error: { code: 429, message: 'You exceeded your current quota.\n* Quota exceeded for metric: generativelanguage.googleapis.com/generate_content_free_tier_requests, limit: 0, model: gemini-2.5-flash-preview-image', details: [{ '@type': 'type.googleapis.com/google.rpc.RetryInfo', retryDelay: '63265s' }] } }, null, 2);
  const BUSY = JSON.stringify({ error: { code: 429, message: 'Resource has been exhausted', details: [{ '@type': 'type.googleapis.com/google.rpc.RetryInfo', retryDelay: '17s' }] } }, null, 2);
  it('says the free tier needs billing, and waits out a short rate limit', () => {
    expect(freeTierBlocked(FREE)).toBe(true);
    expect(freeTierBlocked(BUSY)).toBe(false);
    expect(quotaMessage('', FREE)).toMatch(/free tier[\s\S]*Set up billing[\s\S]*does not pay for the API/);
    expect(retryDelaySec(BUSY)).toBe(17);
    expect(retryDelaySec('{}')).toBe(10);
    expect(quotaMessage('Resource has been exhausted', BUSY)).toContain('retry in 17 s');
  });
});

describe('gp art: drawn by hand (the svg provider) and what the art keeps', () => {
  const OUTLINE = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="30" fill="#f6e6c6" stroke="#2b1a3a" stroke-width="8"/></svg>';
  const SVGART = `art:
  style: "chunky cartoon shapes, bold dark outlines, flat cel shading"
  keep: ["a dark crypt lit by the hero's candle"]
  assets:
    - { id: blob, kind: sprite, prompt: "a round blob", size: 100, frames: ["squashed"] }
    - { id: ground, kind: tile, prompt: "stones", size: 64 }
`;
  it('renders the game\'s own SVGs without keying their outlines out, and renders a changed drawing again', async () => {
    const dir = join(tmp, 'svg');
    cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|dist-playgama|qa|node_modules|store|submission|assets|art)$/.test(f) });
    writeFileSync(join(dir, 'game.yaml'), readFileSync(join(dir, 'game.yaml'), 'utf8') + '\n' + SVGART);
    const loc = locateGame(dir);
    await expect(generateArt(loc, { provider: 'svg' })).rejects.toThrow(/no drawing art\/blob\.svg/);
    cpSync(join(ROOT, 'docs/examples/code/game.yaml'), join(dir, 'unused.yaml'));
    const { mkdirSync } = await import('node:fs');
    mkdirSync(join(dir, 'art'), { recursive: true });
    writeFileSync(join(dir, 'art', 'blob.svg'), OUTLINE);
    writeFileSync(join(dir, 'art', 'blob-1.svg'), OUTLINE.replace('r="30"', 'r="24"'));
    writeFileSync(join(dir, 'art', 'ground.svg'), '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#433857"/></svg>');
    const res = await generateArt(loc, { provider: 'svg' });
    expect(res.made).toEqual(['style.webp', 'blob.webp', 'blob-1.webp', 'ground.webp']);
    expect(res.costUSD).toBe(0);
    const prov = parse(readFileSync(join(dir, 'assets', 'provenance.yaml'), 'utf8'));
    expect(prov.files['blob.webp'].model).toMatch(/^svg/);
    expect(prov.files['blob.webp'].source).toBe(sha256(Buffer.from(OUTLINE)));
    // The dark outline survives (a key from the corners would have eaten it): trimmed to the circle, about 100 px
    expect(Math.max(...prov.files['blob.webp'].size)).toBeGreaterThan(90);
    // The frame keeps the sprite's scale: a smaller circle stays smaller
    expect(Math.max(...prov.files['blob-1.webp'].size)).toBeLessThan(Math.max(...prov.files['blob.webp'].size));
    expect(artChecks(loc)).toEqual([]);
    expect((await generateArt(loc, { provider: 'svg' })).made).toEqual([]);
    writeFileSync(join(dir, 'art', 'ground.svg'), '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#3b314e"/></svg>');
    expect((await generateArt(loc, { provider: 'svg' })).made).toEqual(['style.webp', 'ground.webp']);
  }, 60000);

  it('sends what the art keeps with every request, and warns when it says nothing', async () => {
    const spec: ArtSpec = { style: 'chunky cartoon', keep: ['danger reads red'], assets: [{ id: 'hero', kind: 'sprite', prompt: 'a candle', frames: ['walk'] }] };
    expect(assetPrompt(spec, spec.assets[0]!, false)).toContain("Keep the game's identity and what its play needs from the art: danger reads red.");
    expect(framePrompt(spec, spec.assets[0]!, 'walk')).toContain('danger reads red');
    const dir = join(tmp, 'nokeep');
    cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|dist-playgama|qa|node_modules|store|submission|assets)$/.test(f) });
    writeFileSync(join(dir, 'game.yaml'), readFileSync(join(dir, 'game.yaml'), 'utf8') + '\nart:\n  style: "chunky cartoon shapes, flat cel shading"\n  assets:\n    - { id: hero, kind: sprite, prompt: "a candle" }\n');
    expect(artChecks(locateGame(dir)).map((i) => i.code)).toContain('W_ART_KEEP');
  });
});

describe('gp art: pixel art on a grid, in the game\'s palette', () => {
  it('snaps every pixel to the palette at the grid size, lossless PNG, no blended edge', async () => {
    const dir = join(tmp, 'pixel');
    cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|dist-playgama|qa|node_modules|store|submission|assets|art)$/.test(f) });
    writeFileSync(join(dir, 'game.yaml'), readFileSync(join(dir, 'game.yaml'), 'utf8') + `
art:
  style: "dark crypt pixel art, candle light"
  technique: pixel
  palette: ["#1a1020", "#fff3d6", "#ecd3a0", "#b8976a", "#ffa033", "#7c46c6", "#48267c"]
  keep: ["a crypt lit by the hero's candle"]
  assets:
    - { id: hero, kind: sprite, prompt: "a living candle", size: 32, frames: ["walking"] }
    - { id: floor, kind: tile, prompt: "flagstones", size: 32 }
`);
    const loc = locateGame(dir);
    const res = await generateArt(loc, { provider: 'mock' });
    expect(res.made).toEqual(['style.webp', 'hero.png', 'hero-1.png', 'floor.png']);
    expect(readFileSync(join(dir, 'assets', 'index.ts'), 'utf8')).toContain("import hero from './hero.png';");
    expect(artChecks(loc)).toEqual([]);
    const { chromium } = await import('playwright');
    const b = await chromium.launch();
    try {
      const page = await b.newPage();
      const colours = await page.evaluate(async (src) => {
        const img = new Image();
        img.src = src;
        await img.decode();
        const c = document.createElement('canvas');
        c.width = img.width;
        c.height = img.height;
        const g = c.getContext('2d')!;
        g.drawImage(img, 0, 0);
        const d = g.getImageData(0, 0, c.width, c.height).data;
        const set = new Set<string>();
        let partial = 0;
        for (let i = 0; i < d.length; i += 4) {
          if (d[i + 3]! > 0 && d[i + 3]! < 255) partial++;
          if (d[i + 3] === 255) set.add('#' + [d[i]!, d[i + 1]!, d[i + 2]!].map((v) => v.toString(16).padStart(2, '0')).join(''));
        }
        return { w: c.width, h: c.height, set: [...set], partial };
      }, `data:image/png;base64,${readFileSync(join(dir, 'assets', 'hero.png')).toString('base64')}`);
      expect(Math.max(colours.w, colours.h)).toBeLessThanOrEqual(32);
      expect(colours.partial).toBe(0);
      for (const c of colours.set) expect(['#1a1020', '#fff3d6', '#ecd3a0', '#b8976a', '#ffa033', '#7c46c6', '#48267c']).toContain(c);
    } finally {
      await b.close();
    }
  }, 60000);
});

describe('gp art: a model\'s pseudo-pixels back to its grid', () => {
  it('finds the block pitch of a 1024 px picture on the key and gives back the sprite pixel for pixel', async () => {
    const px = await import('../../art/src/pixel.ts');
    const { encodePng } = await import('../src/pixel.ts');
    // A 21 × 21 shaded, outlined disc, drawn the way a model draws "pixel art": 21.33 px blocks at an offset, on green
    const r = 9, n = 2 * r + 1;
    const disc = px.pixelArt(Array.from({ length: n }, (_, y) => Array.from({ length: n }, (_, x) => ((x - r) ** 2 + (y - r) ** 2 <= r * r + r ? 'f' : '.')).join('')), { f: '#d4531c' });
    const sprite = px.pixelOutline(px.pixelShade(disc));
    const pitch = 21.33, off = 180, W = 1024;
    const d = new Uint8ClampedArray(W * W * 4);
    const src = px.pixelToRgba(sprite);
    for (let y = 0; y < W; y++)
      for (let x = 0; x < W; x++) {
        const sx = Math.floor((x - off) / pitch), sy = Math.floor((y - off) / pitch);
        const o = (y * W + x) * 4;
        const inside = sx >= 0 && sy >= 0 && sx < sprite.w && sy < sprite.h && src.d[(sy * sprite.w + sx) * 4 + 3]! > 0;
        if (inside) { const i = (sy * sprite.w + sx) * 4; d[o] = src.d[i]!; d[o + 1] = src.d[i + 1]!; d[o + 2] = src.d[i + 2]!; }
        else { d[o] = 0; d[o + 1] = 255; d[o + 2] = 0; }
        d[o + 3] = 255;
      }
    const { chromium } = await import('playwright');
    const b = await chromium.launch();
    try {
      const page = await b.newPage();
      const out = await processImage(page, encodePng({ w: W, h: W, d }), 'sprite', [32, 32], 0.86, undefined, true, { palette: [...sprite.colors] });
      expect(out.size).toEqual([sprite.w, sprite.h]);
      const { decodePng } = await import('../src/pixel.ts');
      const got = px.pixelFromRgba(decodePng(out.webp));
      let same = 0;
      for (let i = 0; i < sprite.px.length; i++) if (sprite.colors[sprite.px[i]! - 1] === got.colors[got.px[i]! - 1]) same++;
      expect(same / sprite.px.length).toBeGreaterThan(0.97);
    } finally {
      await b.close();
    }
  }, 60000);
});

describe('gp art: existing images (from, cut, flip) and gp assets', () => {
  it('takes a cell of a sheet, mirrored, snapped to the palette; gp assets lists and numbers the sheet', async () => {
    const dir = join(tmp, 'from');
    cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|dist-playgama|qa|node_modules|store|submission|assets|assets-src|art)$/.test(f) });
    const { mkdirSync } = await import('node:fs');
    mkdirSync(join(dir, 'assets-src'), { recursive: true });
    const { chromium } = await import('playwright');
    const b = await chromium.launch();
    try {
      // A 64×32 sheet: a red square on the left of cell 0, a blue one in cell 1
      const page = await b.newPage();
      const png = await page.evaluate(() => {
        const c = document.createElement('canvas');
        c.width = 64;
        c.height = 32;
        const g = c.getContext('2d')!;
        g.fillStyle = '#e03030';
        g.fillRect(2, 8, 10, 16);
        g.fillStyle = '#3050e0';
        g.fillRect(40, 8, 16, 16);
        return c.toDataURL('image/png').split(',')[1]!;
      });
      writeFileSync(join(dir, 'assets-src', 'sheet.png'), Buffer.from(png, 'base64'));
      writeFileSync(join(dir, 'game.yaml'), readFileSync(join(dir, 'game.yaml'), 'utf8') + `
art:
  style: "dark crypt pixel art"
  technique: pixel
  palette: ["#1a1020", "#ec3a3f", "#3052ac"]
  keep: ["the crypt's palette"]
  assets:
    - { id: imp, kind: sprite, prompt: "an imp", from: assets-src/sheet.png, cut: [0, 0, 32, 32], flip: true, size: 32 }
    - { id: orb, kind: sprite, prompt: "an orb", from: assets-src/sheet.png, cut: [32, 0, 32, 32], size: 32 }
`);
      const loc = locateGame(dir);
      const res = await generateArt(loc, { provider: 'gemini' });
      expect(res.made).toEqual(['style.webp', 'imp.png', 'orb.png']);
      expect(res.costUSD).toBe(0);
      const prov = parse(readFileSync(join(dir, 'assets', 'provenance.yaml'), 'utf8'));
      expect(prov.files['imp.png'].prompt).toBe('assets-src/sheet.png [0, 0, 32, 32], mirrored');
      // trimmed to the square, pixel for pixel (no margin, no resampling), every pixel the palette's red
      expect(prov.files['imp.png'].size).toEqual([10, 16]);
      const px = await page.evaluate(async (src) => {
        const img = new Image();
        img.src = src;
        await img.decode();
        const c = document.createElement('canvas');
        c.width = img.width;
        c.height = img.height;
        c.getContext('2d')!.drawImage(img, 0, 0);
        return [...c.getContext('2d')!.getImageData(4, 4, 1, 1).data];
      }, `data:image/png;base64,${readFileSync(join(dir, 'assets', 'imp.png')).toString('base64')}`);
      expect(px).toEqual([0xec, 0x3a, 0x3f, 255]);
      expect(artChecks(loc)).toEqual([]);
      expect((await generateArt(loc, { provider: 'gemini' })).made).toEqual([]);
      // redraw: the old sprite is the design the model keeps, at the new size
      writeFileSync(loc.file, readFileSync(loc.file, 'utf8') + '    - { id: imp-hd, kind: sprite, prompt: "the imp", from: assets-src/sheet.png, cut: [0, 0, 32, 32], redraw: true, size: 48 }\n');
      const hd = await generateArt(loc, { provider: 'mock' });
      expect(hd.made).toEqual(['imp-hd.png']);
      const p2 = parse(readFileSync(join(dir, 'assets', 'provenance.yaml'), 'utf8')).files['imp-hd.png'];
      expect(p2.prompt).toMatch(/Redraw the first reference image — the imp — as the same design at 48×48 pixels[\s\S]*Do not change, add or remove anything of the design[\s\S]*\(from assets-src\/sheet\.png\)/);
      expect(Math.max(...p2.size)).toBeLessThanOrEqual(48);
      const { listImages, sheetImage } = await import('../src/assets.ts');
      expect(await listImages(loc, join(dir, 'assets-src', 'sheet.png'))).toEqual([{ file: 'assets-src/sheet.png', w: 64, h: 32 }]);
      const sheet = await sheetImage(loc, 'assets-src/sheet.png', { w: 32, h: 32, margin: 0, gap: 0 });
      expect([sheet.cols, sheet.rows]).toEqual([2, 1]);
      expect(existsSync(sheet.file)).toBe(true);
    } finally {
      await b.close();
    }
  }, 60000);
});
