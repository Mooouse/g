// gp review: the reviewer's brief, the quality.md format and its parser, and the gate in gp submission.

import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { loadResults } from '../src/forecast.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import { CRAZYGAMES_BLOCKING, QUALITY_CHECKLIST, RESEARCH_FILE, VERDICT_TRAITS, basicLaunchSection, checklistSource, codeHasMusic, declaredScreens, emojiInCode, firstMinuteLines, lastPassSection, namesScreen, niceLookHints, parseQuality, parseSession, qualityGate, qualityTemplate, sessionSection, resubmissions, scopeSection, screensFromShots, sheetSection, verdictLessons } from '../src/review.ts';
import { qualityStep } from '../src/submission.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-review-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

const GOOD = `# Germ Dodge — quality review

Reviewer: agent-b · Date: 2026-10-01 · Played: gp dev, 12 min, 1280×720 and 360×800

## Findings

- [blocking] The first screen shows 80 words of rules before Play → cut them to one line and show the arrows in play
- [nice] The hit has no sound or shake →
  add a short thud and a 100 ms shake
* [NICE] Covers show a plain screenshot -> stage the cell and a big title in the ?cover frame

## Checked and fine

- anything here is free text, [whatever] it says
`;

describe('parseQuality', () => {
  it('reads [blocking] and [nice] findings, "→" or "->", continuation lines, any case of the level', () => {
    const r = parseQuality(GOOD, { title: 'Germ Dodge' });
    expect(r.problems).toEqual([]);
    expect(r.ok).toBe(true);
    expect(r.title).toBe('Germ Dodge — quality review');
    expect(r.blocking).toHaveLength(1);
    expect(r.nice).toHaveLength(2);
    expect(r.blocking[0]).toMatchObject({ line: 7, what: 'The first screen shows 80 words of rules before Play', change: 'cut them to one line and show the arrows in play' });
    expect(r.nice[0]).toMatchObject({ line: 8, change: 'add a short thud and a 100 ms shake' });
    expect(r.nice[1].change).toBe('stage the cell and a big title in the ?cover frame');
  });

  it('the template the brief shows, filled in, is valid; left as it is, it is not', () => {
    const tpl = qualityTemplate('Lantern Walk');
    const raw = parseQuality(tpl, { title: 'Lantern Walk' });
    expect(raw.ok).toBe(false);
    expect(raw.problems.map((p) => p.message).join('\n')).toContain('placeholder');
    const filled = tpl
      .replace(/<what is wrong[^>]*>/, 'The shop is a list of +stat cards')
      .replace(/<what would make it better>/, 'No sound on a hit')
      .replace(/<what to change>/g, 'make it the game\'s own')
      .replace(/<1–5>\/5 — <why, compared with the references>/g, '4/5 — as finished as Potion Logic\'s');
    const r = parseQuality(filled, { title: 'Lantern Walk', scores: true });
    expect(r.problems).toEqual([]);
    expect(r.blocking).toHaveLength(1);
    expect(r.nice).toHaveLength(1);
    expect(r.scores.map((x) => `${x.screen} ${x.score}`)).toEqual(['title 4', 'play-1 4', 'play-2 4', 'meta 4']);
    // The scores' placeholders left in: malformed
    expect(parseQuality(tpl.replace(/<what is wrong[^>]*>/, 'x').replace(/<what would make it better>/, 'y').replace(/<what to change>/g, 'z'), { scores: true }).problems.map((p) => p.message)).toContain("the template's placeholder is still in this score");
  });

  it('reports what is malformed, with the line', () => {
    const bad = parseQuality(
      `# Germ Dodge — quality review

## Findings

- [major] The title is hard to read → bigger font
- The run never ends → end it
- [blocking] Something is off
Some loose text
- [nice]  → nothing said
`,
      { title: 'Germ Dodge' },
    );
    expect(bad.ok).toBe(false);
    const by = Object.fromEntries(bad.problems.map((p) => [p.line, p.message]));
    expect(by[5]).toContain('"[major]" is not a level');
    expect(by[6]).toContain('without a level');
    expect(by[7]).toContain('what to change');
    expect(by[8]).toContain('only findings');
    expect(by[9]).toContain('what to change');
  });

  it('a file without the heading, the section or any finding; a review of another game', () => {
    expect(parseQuality('## Findings\n\n- [nice] a → b\n').problems[0].message).toContain('no heading');
    expect(parseQuality('# Germ Dodge — quality review\n\nAll good.\n').problems[0].message).toContain('"## Findings"');
    expect(parseQuality('# Germ Dodge — quality review\n\n## Findings\n\n## Notes\n- [nice] a → b\n').problems[0].message).toContain('no findings');
    expect(parseQuality(GOOD, { title: 'Starsilk' }).problems[0].message).toContain("doesn't name this game");
  });
});

describe('## Scores: the review sheet scored 1–5, below 3 a [blocking] finding', () => {
  const scored = (scores: string, findings = '- [nice] The hit has no sound → add a thud') => `# Germ Dodge — quality review\n\n## Scores\n\nFree text is fine here.\n\n${scores}\n\n## Findings\n\n${findings}\n`;
  const ALL4 = '- title: 4/5 — as lit as Hang the Moon\'s\n- Play 1: 5 — fills the frame\n- play-2: 4/5: busy and readable\n- meta: n/a — the game has no meta screen';

  it('reads every screen, "Play 1" as play-1, n/a for meta; required only with scores: true (CrazyGames)', () => {
    const r = parseQuality(scored(ALL4), { scores: true });
    expect(r.problems).toEqual([]);
    expect(r.scores).toMatchObject([{ screen: 'title', score: 4 }, { screen: 'play-1', score: 5 }, { screen: 'play-2', score: 4 }, { screen: 'meta', score: null }]);
    expect(parseQuality(GOOD).problems).toEqual([]);
    expect(parseQuality(GOOD, { scores: true }).problems[0].message).toContain('no "## Scores" section');
  });

  it('a missing screen, a score out of range, no reason, n/a off meta: malformed, with the line', () => {
    const m = (x: string) => parseQuality(scored(x), { scores: true }).problems.map((p) => p.message).join('\n');
    expect(m('- title: 4/5 — fine\n- play-1: 4/5 — fine\n- meta: 4/5 — fine')).toContain('no score for play-2');
    expect(m(ALL4.replace('5 — fills', '7 — fills'))).toContain('"7" is not a score');
    expect(m(ALL4.replace(' — as lit as Hang the Moon\'s', ''))).toContain('say why title scores 4');
    expect(m(ALL4.replace('play-2: 4/5: busy and readable', 'play-2: n/a — skipped'))).toContain('"n/a" only for meta');
  });

  it('a score below 3 needs a [blocking] finding that names the screen; the gate then stops on it', () => {
    const low = ALL4.replace('title: 4/5', 'title: 2/5');
    const r = parseQuality(scored(low), { scores: true });
    expect(r.ok).toBe(false);
    expect(r.problems[0]).toMatchObject({ line: 7, message: expect.stringContaining('title scores 2/5, below 3: write it as a [blocking] finding') });
    // Named in a [nice] finding is not enough; in a [blocking] one it is (and the gate stops on the finding instead)
    expect(parseQuality(scored(low, '- [nice] The title is plain → a lit logo'), { scores: true }).ok).toBe(false);
    const named = parseQuality(scored(low, '- [blocking] title (2/5): a small logo in an empty room → a framed, lit title card'), { scores: true });
    expect(named.problems).toEqual([]);
    expect(named.blocking).toHaveLength(1);
    expect(parseQuality(scored(ALL4.replace('Play 1: 5', 'play-1: 2'), '- [blocking] The first moments of play (play 1) are tiny sprites in a dark field → zoom the camera in'), { scores: true }).problems).toEqual([]);
  });

  it('namesScreen: title also as "first screen", play 1 as play-1, not play-12', () => {
    expect(namesScreen('The first screen is empty', 'title')).toBe(true);
    expect(namesScreen('In Play 2 the HUD is cut', 'play-2')).toBe(true);
    expect(namesScreen('play-12 is fine', 'play-1')).toBe(false);
    expect(namesScreen('the meta screen is a list', 'meta')).toBe(true);
    expect(namesScreen('the shop is a list', 'meta')).toBe(false);
  });

  it('a [nice] finding about the look of the first screen or play is pointed out (a hint, not a refusal)', () => {
    const r = parseQuality(scored(ALL4, '- [nice] The HUD font is small at 1280×720 → a bigger display face\n- [nice] The results could pay more → +10 %'), { scores: true });
    expect(r.ok).toBe(true);
    expect(niceLookHints(r).map((f) => f.line)).toEqual([14]);
  });
});

describe('## Session: where the reviewer would have closed the tab', () => {
  const withSession = (line: string) => GOOD.replace('## Checked and fine', `## Session\n\n${line}\n\n## Checked and fine`);
  it('reads "mm:ss — why" and "none — why"; the template\'s placeholder counts as not written; anything else is malformed', () => {
    expect(parseQuality(withSession("- Where I'd stop: 4:30 — the third results screen had nothing new"), {}).session).toMatchObject({ stopSec: 270, why: 'the third results screen had nothing new' });
    expect(parseQuality(withSession("- Where I'd stop: none — played 12:00 and wanted the next forge"), {}).session).toMatchObject({ stopSec: null });
    expect(parseQuality(withSession("- Where I'd stop: <mm:ss, or none> — <why>"), {}).session).toBeNull();
    expect(parseQuality(withSession("- Where I'd stop: <mm:ss, or none> — <why>"), {}).problems).toEqual([]);
    expect(parseQuality(withSession("- Where I'd stop: soon"), {}).problems.map((p) => p.message).join()).toContain('mm:ss');
    expect(parseQuality(withSession('nothing parsable here'), {}).problems.map((p) => p.message).join()).toContain("Where I'd stop");
    expect(parseSession(['## Session', '', '* where i’d have stopped: 12:05 - the goal stopped moving'], [])).toMatchObject({ stopSec: 725 });
  });
  it('on CrazyGames a stop before 8:00 needs a [blocking] finding that names the session; at 8:00 or later it does not', () => {
    const early = withSession("- Where I'd stop: 4:30 — nothing pulls into the next run");
    const r = parseQuality(early, { session: true });
    expect(r.ok).toBe(false);
    expect(r.problems.map((p) => p.message).join()).toContain('before 8:00');
    expect(parseQuality(early, {}).ok).toBe(true);
    const named = early.replace('- [nice] The hit', '- [blocking] The session ends at 4:30: the results have only Play again → auto-continue and show the next goal\n- [nice] The hit');
    expect(parseQuality(named, { session: true }).problems).toEqual([]);
    expect(parseQuality(withSession("- Where I'd stop: 8:00 — the forge was done"), { session: true }).problems).toEqual([]);
  });
  it('the brief: play 12 minutes on desktop, the format, the 8:00 rule on CrazyGames, and qa/session.json', () => {
    const md = sessionSection({ channel: { id: 'crazygames' } } as never, { bot: 'demo', playedSec: 540, short: true, lines: { stop: '1:00 of play (break 1): the results with only Play again', breaks: '1. 1:00 results', pulls: 'nothing', estimate: '≈ 4.5 min expected' } }).join('\n');
    expect(md).toContain('12 minutes as a new player (desktop)');
    expect(md).toContain("- Where I'd stop: mm:ss — <why>");
    expect(md).toContain('a stop before 8:00 is a `[blocking]` finding');
    expect(md).toContain('W_SESSION_SHORT');
    expect(md).toContain('First natural stop: 1:00 of play (break 1)');
    expect(sessionSection({ channel: { id: 'web' } } as never, null).join('\n')).not.toContain('8:00 is a');
  });
});

describe('the gate in gp submission', () => {
  const game = (name: string, text?: string) => {
    const dir = join(tmp, name);
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'id: x\n');
    if (text !== undefined) writeFileSync(join(dir, 'quality.md'), text);
    return locateGame(dir);
  };
  const out = (name: string) => {
    const d = join(tmp, `${name}-submission`);
    mkdirSync(d, { recursive: true });
    return d;
  };

  it('missing: ✗, says to run gp review; nothing copied', () => {
    const loc = game('missing');
    const g = qualityGate(loc, { title: 'Germ Dodge' });
    expect(g.ok).toBe(false);
    expect(g.detail).toContain('is missing');
    expect(g.detail).toContain('gp review missing');
    const dir = out('missing');
    const step = qualityStep(loc, { title: 'Germ Dodge' }, dir);
    expect(step).toMatchObject({ field: 'Quality review', file: null, ok: false });
    expect(existsSync(join(dir, 'quality.md'))).toBe(false);
  });

  it('a [blocking] finding: ✗ with the count and the first finding; nothing copied', () => {
    const loc = game('blocking', GOOD);
    const dir = out('blocking');
    const step = qualityStep(loc, { title: 'Germ Dodge' }, dir);
    expect(step.ok).toBe(false);
    expect(step.detail).toMatch(/1 \[blocking\] finding\(s\), e\.g\. line 7: "The first screen/);
    expect(step.detail).toContain('gp review blocking');
    expect(existsSync(join(dir, 'quality.md'))).toBe(false);
  });

  it('malformed: ✗ with the problems', () => {
    const loc = game('malformed', '# Germ Dodge — quality review\n\n## Findings\n\n- [minor] x → y\n');
    const step = qualityStep(loc, { title: 'Germ Dodge' }, out('malformed'));
    expect(step.ok).toBe(false);
    expect(step.detail).toContain('malformed');
    expect(step.detail).toContain('line 5');
  });

  it('only [nice] findings: ✓, and quality.md goes into the submission folder', () => {
    const text = GOOD.replace('- [blocking] The first screen', '- [nice] The first screen');
    const loc = game('passes', text);
    const dir = out('passes');
    const step = qualityStep(loc, { title: 'Germ Dodge' }, dir);
    expect(step).toMatchObject({ file: 'quality.md', ok: true });
    expect(step.detail).toBe('no [blocking] findings, 3 [nice]');
    expect(readFileSync(join(dir, 'quality.md'), 'utf8')).toBe(text);
  });
});

describe('the brief', () => {
  it('every checklist item has its source line in the research', () => {
    const research = readFileSync(RESEARCH_FILE, 'utf8').split('\n');
    for (const item of QUALITY_CHECKLIST) {
      const s = checklistSource(item, research);
      expect(s, item.anchor).not.toBeNull();
      expect(research[s!.line - 1]).toContain(item.anchor);
      expect(s!.section, item.anchor).not.toBe('');
    }
  });

  it('the verdict traits name real recorded games; the lessons count from results.yaml', () => {
    const { results } = loadResults();
    const ids = new Set(results.map((r) => r.game));
    for (const id of Object.keys(VERDICT_TRAITS)) expect(ids.has(id), id).toBe(true);
    const md = verdictLessons(results);
    expect(md).toContain('data, not causes');
    expect(md).toMatch(/\| Starsilk \| approved \|/);
    // Counted out of the games whose trait is recorded; the others are named as not recorded
    expect(md).toMatch(/In \d+ of \d+( \(\+\d+ not recorded\))? quality rejections and \d+ of \d+( \(\+\d+ not recorded\))? approved games/);
    expect(md).not.toContain('nine games');
    if (results.some((r) => r.basicLaunch?.verdict === 'stopped')) expect(md).toContain('Approval is not the launch');
    expect(md).toContain('Starsilk was approved with `mountUpgradeShop`');
  });

  const env = { ...process.env, GP_NO_LOG: '1', NO_COLOR: '1' };
  function gp(args: string[]): { code: number; out: string } {
    try {
      return { code: 0, out: execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), ...args], { cwd: ROOT, encoding: 'utf8', env, stdio: ['ignore', 'pipe', 'pipe'] }) };
    } catch (e) {
      const x = e as { status: number; stdout: string; stderr: string };
      return { code: x.status, out: x.stdout + x.stderr };
    }
  }

  it('gp review writes qa/review-brief.md with the facts, the screenshots, the checklist and the lessons; --check judges quality.md', { timeout: 60_000 }, () => {
    const dir = join(tmp, 'germ-dodge');
    cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) });
    // A QA run as gp qa leaves it
    mkdirSync(join(dir, 'qa'), { recursive: true });
    writeFileSync(join(dir, 'qa', 'qa-results.json'), JSON.stringify({ game: 'code-example', date: '2026-10-01T10:00:00.000Z', passed: 93, failed: 1, checks: [{ scope: 'ads fail', name: 'the offer says why', ok: false, details: 'no message' }], infos: [{ scope: 'desktop-1280x720', name: 'look: depth in the play frame (flat — a hint)', details: '62% of the play frame is one flat colour (#112233)' }] }));
    for (const f of ['desktop-1-first-screen.png', 'desktop-1280x720-1-first-screen.png', 'desktop-1280x720-2-play.png', 'ads-fail-rewarded.png', 'production-frame-821x462-play.png']) writeFileSync(join(dir, 'qa', f), '');

    const r = gp(['review', dir, '--no-capture']);
    expect(r.code, r.out).toBe(0);
    expect(r.out).toContain('qa/review-brief.md');
    expect(r.out).toContain('quality.md now:');
    // The review sheet, from the QA's shots (no capture): the game's frames beside 3 approved and 2 rejected references
    expect(r.out).toMatch(/✓ review sheet: .*qa\/review-sheet\.png — title, play-1 beside 3 approved and 2 rejected references/);
    expect(existsSync(join(dir, 'qa', 'review-sheet.png'))).toBe(true);
    const brief = readFileSync(join(dir, 'qa', 'review-brief.md'), 'utf8');
    expect(brief).toContain('# Germ Dodge — quality review brief');
    expect(brief).toContain('**Concept:** Steer a cell');
    expect(brief).toMatch(/\*\*Uniqueness:\*\* \d+\/100/);
    expect(brief).toContain('**Forecast:** money (estimates)');
    expect(brief).toContain('**93 passed, 1 failed**');
    expect(brief).toContain('[ads fail] the offer says why — no message');
    expect(brief).toMatch(/desktop-1-first-screen\.png — the first screen/);
    expect(brief).toMatch(/production-frame-821x462-play\.png — the portal's small iframe/);
    expect(brief).toContain('no preview videos yet');
    expect(brief).toMatch(/\| 1 \| First minute \| A new player lands in gameplay at once.*line \d+/);
    expect(brief).not.toContain('(not found:');
    expect(brief).toContain('## Lessons from our nine portal verdicts');
    expect(brief).toContain('## The look: art direction (docs/guides/art.md)');
    expect(brief).toContain('No pure-black or thick black outlines');
    // CrazyGames: the desktop first, the sheet and its scores, the last pass, the promotions to [blocking], the platform's own findings, the scope check, Basic Launch
    expect(brief).toContain('Play the desktop first — 1280×720');
    expect(brief).toContain('## The review sheet: the look against what CrazyGames approved and rejected');
    expect(brief).toMatch(/- \*\*Approved\*\* — .*publisher\/reference\/approved\/.*\.jpg/);
    expect(brief).toMatch(/- `play-2` \(play, later\): \*\*not captured/);
    expect(brief).toContain('The look and the layout of the first screen and of play are never `[nice]`');
    expect(brief).toContain('No new systems in the last pass before submission — only feel (juice, sound, typography, layout).');
    expect(brief).toMatch(/4 of 6 resubmissions after a Basic Launch stop were rejected/);
    expect(brief).toContain('Swarm Smash 1.2.0 (0 blocking / 0 nice');
    expect(brief).toContain('## [blocking] on CrazyGames');
    expect(brief).toContain('a maximum of 1 click is allowed');
    expect(brief).toContain('✗ music: none in the code or in game.yaml (`sound.music: false`)');
    expect(brief).toContain('### The scope check: prototype risk');
    expect(brief).toMatch(/Screens declared to QA \(host\.qa\(\{ screens \}\)\): title, paused/);
    expect(brief).toContain('## Basic Launch: how the portal scores the first week');
    expect(brief).toMatch(/\| Candle Crypt \| .* \| 2026-10-10 \| Desktop \| 9\.52 min → \*\*4\*\* .* \| 7\/15 ✗ \(< 9\) \|/);
    expect(brief).toContain('- [desktop-1280x720] 62% of the play frame is one flat colour (#112233)');
    // The format it asks for is the one the parser reads
    expect(brief).toContain(qualityTemplate('Germ Dodge').split('\n')[6]);

    const check = () => gp(['review', dir, '--check']);
    expect(check().code).toBe(1);
    expect(check().out).toContain('is missing');
    writeFileSync(join(dir, 'quality.md'), GOOD);
    const blocked = check();
    expect(blocked.code).toBe(1);
    expect(blocked.out).toContain('quality.md:7  [blocking] The first screen shows 80 words');
    // On CrazyGames quality.md needs the sheet's scores
    writeFileSync(join(dir, 'quality.md'), GOOD.replace('[blocking]', '[nice]'));
    const unscored = check();
    expect(unscored.code).toBe(1);
    expect(unscored.out).toContain('no "## Scores" section');
    const SCORES = '## Scores\n\n- title: 4/5 — lit, one style\n- play-1: 4/5 — fills the frame\n- play-2: 4/5 — readable\n- meta: 4/5 — drawn\n\n';
    writeFileSync(join(dir, 'quality.md'), GOOD.replace('[blocking]', '[nice]').replace('## Findings', `${SCORES}## Findings`));
    // Germ Dodge has no music (`sound.music: false`): on CrazyGames the gate refuses it whatever the reviewer wrote
    const silent = check();
    expect(silent.code).toBe(1);
    expect(silent.out).toContain('no music');
    const yaml = join(dir, 'game.yaml');
    writeFileSync(yaml, readFileSync(yaml, 'utf8').replace(/^sound: .*$/m, 'sound: { music: "a soft synth loop of its own, music and effects sliders" }'));
    // On CrazyGames the blind first look too (gp review --first-look)
    const blind = check();
    expect(blind.code).toBe(1);
    expect(blind.out).toContain('first-look.md is missing');
    writeFileSync(join(dir, 'qa', 'first-look.md'), '# First look\n\n- Goal: dodge the germs\n- Controls: drag\n- Hook: they split\n- Keep playing: 4/5 — lively\n');
    const ok = check();
    expect(ok.code, ok.out).toBe(0);
    expect(ok.out).toContain('no [blocking] findings, 3 [nice]; scores title 4, play-1 4, play-2 4, meta 4');
  });
});

describe('the first minute, Basic Launch and the scope check', () => {
  it('first-minute.json as pass/fail lines: the limits, the twist, new fields in any shape, missing fields skipped', () => {
    const lines = firstMinuteLines(
      { at: 'x', playReadyMs: 400, playToRunMs: null, idleEndSec: 7, words: 31, firstHighlightSec: 9, twistSec: 40, demoEndSec: null, clicksToGameplay: 2, touchControlsVisible: false, touchBot: { reachedRun: true, sec: 3 }, cpu4xFps: { fps: 41 }, startLoudness: -2, somethingNew: { ok: false } },
      30,
    );
    const by = (re: RegExp) => lines.find((l) => re.test(l.text))!;
    expect(by(/^Play tappable/).ok).toBe(true);
    expect(by(/^Clicks from opening/)).toMatchObject({ ok: false, text: expect.stringContaining('2') });
    expect(by(/^Play → the run/).ok).toBe(false);
    expect(by(/touches nothing/)).toMatchObject({ ok: false, text: expect.stringContaining('7 s') });
    expect(by(/^Words/).ok).toBe(false);
    expect(by(/^Touch controls visible/).ok).toBe(false);
    expect(by(/naive touch bot/).ok).toBe(true);
    expect(by(/4× CPU/)).toMatchObject({ ok: true, text: expect.stringContaining('41 fps') });
    expect(by(/Loudness/).ok).toBeNull();
    expect(by(/celebrated/).ok).toBe(true);
    expect(by(/^The twist/).ok).toBe(false);
    expect(by(/^somethingNew/).ok).toBe(false);
    expect(lines.some((l) => /^at:/.test(l.text))).toBe(false);
    // gp qa's own touch bot: a loss inside its 60 s fails the line
    const bot = (failedAt: unknown) => firstMinuteLines({ touchBot: { gameplaySec: 0.5, playedSec: 60, events: 3, taps: 80, drags: 30, endedOn: 'play', sec: 60, failedAt } }, null)[0];
    expect(bot(null)).toMatchObject({ ok: true, text: expect.stringMatching(/for 60 s\) keeps playing without a loss: yes/) });
    expect(bot({ type: 'fail', sec: 41.2 })).toMatchObject({ ok: false, text: expect.stringContaining('no — a fail after 41.2 s') });
    // An older file: only what it has
    expect(firstMinuteLines({ words: 3 }, null)).toEqual([{ ok: true, text: expect.stringContaining('3') }]);
  });

  it('the Basic Launch section: the 1–5 scores, 9 of 15, every recorded score screen', () => {
    const md = basicLaunchSection([{ game: 'x-game', title: 'X Game', channel: 'crazygames', category: 'Puzzle', basicLaunch: { scores: { date: '2026-10-10', desktop: { playtime: { value: 6, score: 3 }, d1: { score: 3 }, conversion: { value: 0.6, score: 3, next: 0.65 } } } } }]).join('\n');
    expect(md).toContain('each 1–5 per device class');
    expect(md).toContain('≥ 9 of 15 on a device class');
    expect(md).toContain('play the desktop (1280×720) first, then the phone');
    expect(md).toMatch(/\| X Game \| Puzzle \| 2026-10-10 \| Desktop \| 6 min → \*\*3\*\* \| \*\*3\*\* \| 60\.00 % → \*\*3\*\* \(next at 65\.00 %\) \| 9\/15 ✓ \(≥ 9\) \|/);
  });

  it('resubmissions after a Basic Launch stop: 4 of 6 rejected (publisher/results.yaml), and the last-pass rule', () => {
    const { results } = loadResults();
    const re = resubmissions(results);
    expect(re.map((r) => `${r.game} ${r.verdict}`).sort()).toEqual(['candle-crypt approved', 'candle-crypt rejected', 'garage-evolution rejected', 'hang-the-moon approved', 'spin-brawl rejected', 'starsilk rejected']);
    const md = lastPassSection({ id: 'candle-crypt', title: 'Candle Crypt' }, results, ['abc123 Candle Crypt: a new boss rush mode']).join('\n');
    expect(md).toContain('No new systems in the last pass before submission — only feel (juice, sound, typography, layout).');
    expect(md).toContain('4 of 6 resubmissions after a Basic Launch stop were rejected (Spin Brawl 2026-10-11, Starsilk 2026-10-11, Candle Crypt 2026-10-12 for the overall quality; Idle Garage Evolution 2026-10-21: "The game would benefit from additional stability and technical improvements before publishing"); Hang the Moon, Candle Crypt came back approved');
    expect(md).toContain('**This game has been answered before**: stopped after Basic Launch (2026-10-10); rejected on 2026-10-12');
    expect(md).toContain('- abc123 Candle Crypt: a new boss rush mode');
    expect(lastPassSection({ id: 'new-game', title: 'New' }, results).join('\n')).not.toContain('answered before');
    expect(sheetSection(null).join('\n')).toContain('No review sheet in this brief');
    expect(sheetSection(null).join('\n')).toContain('**3** — a game, but plainer');
  });

  it('the scope check: more than 3 systems in under a day is a [blocking] prototype risk', () => {
    const risky = scopeSection({ systems: ['an upgrade shop', 'a daily', 'a pact tree', 'levels with stars'], screens: ['title', 'shop'], madeHours: 3 }, null).join('\n');
    expect(risky).toContain('4 systems in a game made in under a day');
    const fine = scopeSection({ systems: ['an upgrade shop', 'a daily', 'a pact tree', 'levels with stars'], screens: [], madeHours: 50 }, null).join('\n');
    expect(fine).not.toContain('systems in a game made in under a day:');
  });

  it('the scope check: more than 15 declared screens is a [blocking] prototype risk whatever the hours (W_SCOPE_SCREENS)', () => {
    const screens = Array.from({ length: 16 }, (_, i) => `s${i}`);
    const many = scopeSection({ systems: [], screens, madeHours: 300 }, null).join('\n');
    expect(many).toContain('16 screens declared to QA, more than 15 (W_SCOPE_SCREENS)');
    expect(scopeSection({ systems: [], screens: screens.slice(0, 15), madeHours: 300 }, null).join('\n')).not.toContain('screens declared to QA, more than');
  });

  it('the CrazyGames promotions name the nine placeholder signs', () => {
    expect(CRAZYGAMES_BLOCKING).toHaveLength(9);
    expect(CRAZYGAMES_BLOCKING.map((b) => b.what).join('\n')).toMatch(/music[\s\S]*Emoji[\s\S]*plain list[\s\S]*2 short lines[\s\S]*1 click[\s\S]*Touch controls[\s\S]*Half the screen[\s\S]*platform sheet[\s\S]*first 5 s/);
  });

  it('music and emoji in the code: createMusic counts, emoji in strings are found', () => {
    const dir = join(tmp, 'music-code');
    mkdirSync(join(dir, 'strings'), { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'id: x\n');
    writeFileSync(join(dir, 'main.ts'), "import { createMusic } from '@gp/core/sound';\nconst icon = '💎';\nconst done = '✓ Done'; // © the comment's ◆ is not code\nconst lock = '◆ ● ▶ ✕';\nconst note = '© 2026 ™';\n");
    writeFileSync(join(dir, 'strings', 'en.yaml'), 'coins: "🪙 Coins"\n');
    const loc = locateGame(dir);
    expect(codeHasMusic(loc)).toBe(true);
    const e = emojiInCode(loc);
    expect(e.files).toHaveLength(2);
    expect(e.chars).toEqual(expect.arrayContaining(['💎', '🪙', '✓', '◆', '●', '▶', '✕']));
    // © ® ™ are marks in a sentence, not icons
    expect(e.chars).not.toContain('©');
    expect(e.chars).not.toContain('™');
    writeFileSync(join(dir, 'main.ts'), "import { createMixer } from '@gp/core/sound';\n");
    expect(codeHasMusic(loc)).toBe(false);
  });
});

describe('the screens of the scope check', () => {
  it("the top-level keys of host.qa({ screens }), not a screen's own setup (Garage read as \"streak, day, n, claimed\")", () => {
    const code = `host.qa({ screens: { streak: { day: 3, n: 7, claimed: false }, 'shop-late': () => { open({ tab: 1 }) }, title: () => go(a ? b : c) }, play })`;
    expect(declaredScreens(code)).toEqual(['streak', 'shop-late', 'title']);
    expect(declaredScreens('host.qa({ play })')).toEqual([]);
  });
  it("the shots gp qa took (screen-<name>-<size>.png) name the screens it opened, a language's not counted", () => {
    expect(screensFromShots(['screen-journal-beasts-desktop-1280x720.png', 'screen-win-phone-portrait-360x800.png', 'screen-win-mobile-800x450.png', 'lang-fr-screen-x-mobile-800x450.png', 'desktop-1280x720-2-play.png'])).toEqual(['journal-beasts', 'win']);
  });
});
