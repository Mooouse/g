// Pixel-art upscaling at build time (gp assets upscale / compare, an art asset's `upscale`): a game's own sprites made
// bigger without changing their design. The rule-based scalers — nearest, Scale2x (EPX), xBR (Hyllian), xBRZ (Zenju) —
// and, when a Python with spandrel is given, ESRGAN models; then back to whole pixels in the game's palette, with the
// small details (eyes, mouths, glints) kept pixel for pixel. Candle Crypt, 2026-10-10: xBRZ 4× → 32 px with the details
// kept held the design best; the ESRGAN pixel-art models tried either blurred it or redrew the characters.

import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

type Page = import('playwright').Page;
export interface Rgba {
  w: number;
  h: number;
  d: Uint8ClampedArray;
}
export type UpscaleMethod = 'nearest' | 'scale2x' | 'xbr' | 'xbrz' | `esrgan:${string}`;
export interface UpscaleOptions {
  method: UpscaleMethod;
  /** How much bigger the result is (2: 16 px → 32 px) */
  factor: number;
  /** Back to whole pixels in these colours (hex); empty: the image's own colours */
  palette?: string[];
  /** Keep the details pixel for pixel: interior pixels that differ from most of their neighbours (default true) */
  keepDetails?: boolean;
}

export const UPSCALE_METHODS = ['nearest', 'scale2x', 'xbr', 'xbrz'] as const;

const require = createRequire(import.meta.url);
const here = dirname(fileURLToPath(import.meta.url));

export function nearest(im: Rgba, k: number): Rgba {
  const w = im.w * k, h = im.h * k, d = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = (((y / k) | 0) * im.w + ((x / k) | 0)) * 4;
      d.set(im.d.subarray(i, i + 4), (y * w + x) * 4);
    }
  return { w, h, d };
}

/** Scale2x / EPX (AdvMAME2x): corners take a neighbour's colour where two neighbours agree */
export function scale2x(im: Rgba): Rgba {
  const W = im.w, H = im.h, src = new Uint32Array(im.d.slice().buffer);
  const at = (x: number, y: number) => (x < 0 || y < 0 || x >= W || y >= H ? 0 : src[y * W + x]!);
  const out = new Uint32Array(W * 2 * H * 2);
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const P = src[y * W + x]!, A = at(x, y - 1), B = at(x + 1, y), C = at(x - 1, y), D = at(x, y + 1);
      const o = y * 2 * W * 2 + x * 2;
      out[o] = C === A && C !== D && A !== B ? A : P;
      out[o + 1] = A === B && A !== C && B !== D ? B : P;
      out[o + W * 2] = D === C && D !== B && C !== A ? C : P;
      out[o + W * 2 + 1] = B === D && B !== A && D !== C ? D : P;
    }
  return { w: W * 2, h: H * 2, d: new Uint8ClampedArray(out.buffer) };
}

/** xBRZ (Zenju's "scale by rules", 2–6×): smooth curves and diagonals, transparent outside the sprite */
export function xbrz(im: Rgba, k: number): Rgba {
  const { xbrzScale, xbrzColorFormat, xbrzConfig } = require('xbrz-js') as {
    xbrzScale: (k: number, src: Uint32Array, dst: Uint32Array, w: number, h: number, f: number, c: unknown) => void;
    xbrzColorFormat: { argb: number };
    xbrzConfig: (o: object) => unknown;
  };
  const f = Math.max(2, Math.min(6, Math.round(k)));
  const dst = new Uint32Array(im.w * f * im.h * f);
  xbrzScale(f, new Uint32Array(im.d.slice().buffer), dst, im.w, im.h, xbrzColorFormat.argb, xbrzConfig({ oobRead: 'transparent' }));
  return { w: im.w * f, h: im.h * f, d: new Uint8ClampedArray(dst.buffer) };
}

/** xBR (Hyllian, 2–4×), keeping the image's colours (no blend) */
export async function xbr(im: Rgba, k: number): Promise<Rgba> {
  // xbr-js ships an ES module without a main entry: its file by path
  const m = (await import(require.resolve('xbr-js/dist/xBRjs.esm.js'))) as Record<string, (a: Uint32Array, w: number, h: number, o: object) => Uint32Array>;
  const f = Math.max(2, Math.min(4, Math.round(k)));
  const out = m[`xbr${f}x`]!(new Uint32Array(im.d.slice().buffer), im.w, im.h, { blendColors: false, scaleAlpha: true });
  return { w: im.w * f, h: im.h * f, d: new Uint8ClampedArray(out.buffer) };
}

const hex = (h: string): [number, number, number] => {
  const v = parseInt(h.replace('#', '').slice(0, 6), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
};

/** The image's own opaque colours */
export function coloursOf(im: Rgba): string[] {
  const s = new Set<string>();
  for (let i = 0; i < im.d.length; i += 4) if (im.d[i + 3]! >= 128) s.add('#' + [im.d[i]!, im.d[i + 1]!, im.d[i + 2]!].map((v) => v.toString(16).padStart(2, '0')).join(''));
  return [...s];
}

/** Shrink by a whole factor: each pixel the most common palette colour of its cell, opaque when most of the cell is */
export function snap(im: Rgba, k: number, palette: string[]): Rgba {
  const pal = palette.map(hex);
  const w = Math.floor(im.w / k), h = Math.floor(im.h / k), d = new Uint8ClampedArray(w * h * 4);
  const near = (r: number, g: number, b: number) => {
    let bi = 0, bd = Infinity;
    for (let i = 0; i < pal.length; i++) {
      const [R, G, B] = pal[i]!;
      const q = 2 * (r - R) ** 2 + 4 * (g - G) ** 2 + 3 * (b - B) ** 2;
      if (q < bd) { bd = q; bi = i; }
    }
    return bi;
  };
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const votes = new Map<number, number>();
      let solid = 0;
      for (let yy = 0; yy < k; yy++)
        for (let xx = 0; xx < k; xx++) {
          const i = ((y * k + yy) * im.w + x * k + xx) * 4;
          if (im.d[i + 3]! < 128) continue;
          solid++;
          const c = near(im.d[i]!, im.d[i + 1]!, im.d[i + 2]!);
          votes.set(c, (votes.get(c) ?? 0) + 1);
        }
      if (!solid || solid * 2 < k * k) continue;
      const c = [...votes].sort((a, b) => b[1] - a[1])[0]![0];
      d.set([...pal[c]!, 255], (y * w + x) * 4);
    }
  return { w, h, d };
}

/** Copy the small details of the source over the upscaled image, pixel for pixel (eyes, teeth, glints don't melt) */
export function keepDetails(src: Rgba, up: Rgba): Rgba {
  const W = src.w, H = src.h, k = up.w / W, d = new Uint8ClampedArray(up.d);
  const px = (x: number, y: number) => (x < 0 || y < 0 || x >= W || y >= H ? null : src.d.subarray((y * W + x) * 4, (y * W + x) * 4 + 4));
  const same = (a: Uint8ClampedArray, b: Uint8ClampedArray) => a[0] === b[0] && a[1] === b[1] && a[2] === b[2] && a[3] === b[3];
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const p = px(x, y);
      if (!p || p[3]! < 128) continue;
      let edge = false, sameN = 0;
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const q = px(x + dx, y + dy);
          if (!q || q[3]! < 128) edge = true;
          else if (same(p, q)) sameN++;
        }
      if (edge || sameN > 2) continue;
      for (let yy = 0; yy < k; yy++) for (let xx = 0; xx < k; xx++) d.set(p, ((y * k + yy) * up.w + x * k + xx) * 4);
    }
  return { ...up, d };
}

/**
 * An ESRGAN model through spandrel (Python), PNG in and out: GP_PYTHON names a python with torch, spandrel, numpy and
 * pillow (`python3 -m venv v && v/bin/pip install --index-url https://download.pytorch.org/whl/cpu torch torchvision &&
 * v/bin/pip install spandrel pillow numpy`); models: openmodeldb.info (the .pth file)
 */
export function esrganPng(png: Buffer, model: string): Buffer {
  const py = process.env.GP_PYTHON || 'python3';
  const dir = mkdtempSync(join(tmpdir(), 'gp-esrgan-'));
  try {
    writeFileSync(join(dir, 'in.png'), png);
    execFileSync(py, [join(here, 'esrgan.py'), model, join(dir, 'in.png'), join(dir, 'out.png')], { stdio: ['ignore', 'ignore', 'pipe'] });
    return readFileSync(join(dir, 'out.png'));
  } catch (e) {
    throw new Error(`esrgan: ${String((e as { stderr?: Buffer }).stderr ?? e).trim().split('\n').pop()} — GP_PYTHON must be a python with torch, spandrel, numpy and pillow (packages/cli/src/upscale.ts)`);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

/** PNG ↔ RGBA through the browser page gp already runs (no image library) */
export async function decodePng(page: Page, png: Buffer): Promise<Rgba> {
  const r = await page.evaluate(async (src) => {
    const img = new Image();
    img.src = src;
    await img.decode();
    const c = document.createElement('canvas');
    c.width = img.naturalWidth;
    c.height = img.naturalHeight;
    const g = c.getContext('2d', { willReadFrequently: true })!;
    g.drawImage(img, 0, 0);
    return { w: c.width, h: c.height, d: Array.from(g.getImageData(0, 0, c.width, c.height).data) };
  }, `data:image/png;base64,${png.toString('base64')}`);
  return { w: r.w, h: r.h, d: new Uint8ClampedArray(r.d) };
}
export async function encodePng(page: Page, im: Rgba): Promise<Buffer> {
  const b64 = await page.evaluate(({ w, h, d }) => {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d')!.putImageData(new ImageData(new Uint8ClampedArray(d), w, h), 0, 0);
    return c.toDataURL('image/png').split(',')[1]!;
  }, { w: im.w, h: im.h, d: Array.from(im.d) });
  return Buffer.from(b64, 'base64');
}

/** One sprite made `factor` times bigger, its design kept: the scaler, then whole pixels in the palette, the details kept */
export async function upscale(im: Rgba, o: UpscaleOptions, page: Page): Promise<Rgba> {
  const k = Math.max(1, Math.round(o.factor));
  const palette = o.palette?.length ? o.palette : coloursOf(im);
  let big: Rgba;
  // Smooth scalers run bigger than the factor (a whole multiple of it), then come back to whole pixels: curves, no blur
  const over = (max: number) => (k * 2 <= max ? k * 2 : k);
  if (o.method === 'nearest') return nearest(im, k);
  if (o.method === 'scale2x') {
    big = im;
    while (big.w < im.w * k) big = scale2x(big);
    big = snap(big, big.w / (im.w * k), palette);
  } else if (o.method === 'xbr') {
    const f = over(4);
    big = snap(await xbr(im, f), f / k, palette);
  } else if (o.method === 'xbrz') {
    const f = over(6);
    big = snap(xbrz(im, f), f / k, palette);
  } else if (o.method.startsWith('esrgan:')) {
    const out = await decodePng(page, esrganPng(await encodePng(page, im), o.method.slice(7)));
    big = snap(out, Math.max(1, Math.round(out.w / (im.w * k))), palette);
  } else throw new Error(`upscale: unknown method ${o.method} (${UPSCALE_METHODS.join(', ')}, esrgan:<model.pth>)`);
  return o.keepDetails === false ? big : keepDetails(im, big);
}
