// What people who judged our games keep asking for: the reviewers (the sheet's «Принятые рекомендации»), the owner, a
// contest jury and the portal. Each lesson is one flaw that came back in several games, how a reviewer spots it in
// play, the usual fix with the platform's tools, and what gp already measures of it. `gp review` hands them to the
// second agent with the portal's checklist (a plain flaw is [blocking]: the game maker fixes it before submitting);
// `gp lessons` prints them for a game at design time. Every recommendation the loop takes is added to a lesson's
// sources here (docs/team/weekly-loop.md), verbatim, so the next game starts where the last one was told off.

export interface LessonSource {
  game: string;
  who: string;
  date: string;
  /** Verbatim, as written in the sheet */
  text: string;
}

export interface Lesson {
  id: string;
  /** The flaw, as the judges saw it */
  flaw: string;
  /** How the reviewer spots it in 10–15 minutes of play */
  look: string;
  /** The usual fix, with the platform's tools */
  fix: string;
  /** What gp already measures of it (the reviewer judges the rest) */
  measured?: string;
  sources: LessonSource[];
}

const s = (game: string, who: string, date: string, text: string): LessonSource => ({ game, who, date, text });

export const LESSONS: Lesson[] = [
  {
    id: 'variety',
    flaw: 'Too little variety: the same enemies, towers, weapons or tools for the whole game',
    look: 'Count the kinds you meet in 10 minutes — enemies that behave differently, weapons or tools that play differently. Fewer than ~4 of each, or a new kind less often than every 3–5 minutes, is what the judges named. In a roguelite, play into the late waves: do the drops and the shop keep offering the same few things?',
    fix: 'Each new kind changes a decision (range, speed, area, a counter to one enemy), not only a number; introduce one every 3–5 min; bosses at act ends. Data tables, not code paths: they feed the balance model too. In a roguelite the late offers stay varied: the share of the player’s own parts falls with the wave, a maxed thing is never offered, the last few drops and the last shop come back less often (Frankengun’s rollPart / rollShop); count the distinct offers per stage in the bot’s late waves',
    measured: 'gp qa’s feel section: host.seen(kind, id) counted at 2, 5 and 10 min of the demo bot’s play (on the virtual clock), a warning when nothing new appears for over 90 s and when the median gap between rewards is over 60 s; the balance model counts new things over time (goals)',
    sources: [
      s('Secret House Tycoon', 'Свин', '2026-10-10', 'Добавить размещение мебели и декора не строго по одному месту, а так как захочет игрок.'),
      s('Secret House Tycoon', 'Свин', '2026-10-10', 'Сделать очистку пола стен и окон разными действиями, допустим пол мы моем шваброй, стены тряпкой, а окна скребком.'),
      s('Spin Brawl', 'Свин', '2026-10-10', 'Сейчас игрок слишком стремительно теряет массу, я добрался до 500 массы но она настолько быстро теряется что это не нормально надо исправить, добавить фоновую музыку, разнообразить звуки ударов. Так же еще разнообразить ловушки добавив например шипы и нужно увеличить карту. В игре надо сделать онлайн режим сервер для этого будем использовать Photon кототрый рекомендуют сами Crazy Games. Так же сделать выбор режима игры с реальными игроками либо с ботами. Сделать улучшения не такими частыми. На телефоне добавить внешний вид стика управления сейчас его вообще нет. Добавить разные звуки при попадании в ловушки допустим попал в лед звук заморозки. При  применении улучшений добавить эффекты и звуки соответствующие редкости улучшения. Сделать панель с улушчениями на телефонах компактнее если улучшений слишком много.'),
      s('Firefly Rush', 'Жаслан', '2026-10-03', 'слишком просто, тупо летать и собирать'),
      s('Dread Throne', 'Свин', '2026-10-01', 'Больше разнообразия башен и ловушек'),
      s('Dread Throne', 'Свин', '2026-10-01', 'Новый вид противников, качественные анимации, разные атаки'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Больше уровней прокачки строений; минимум ещё 15 строений'),
      s('Echoflies', 'Свин', '2026-10-02', 'Разнообразить врагов, добавить боссов'),
      s('Starsilk', 'Ера', '2026-10-02', 'Больше уровней, механик, монстров со способностями, возможностей игрока'),
      s('Almus Gate', 'Жаслан', '2026-10-02', 'Больше способов и методов проверки'),
      s('Splicebound', 'Жаслан', '2026-10-02', 'Роботы вместо монстров: новое поле битвы, своя система поединка, типы атак, бой 3 на 3'),
      s('Spin Brawl', 'Жаслан, Свин', '2026-10-02', 'Больше скинов'),
      s('Candle Crypt', 'Жюри конкурса (через Жаслана)', '2026-10-03', 'Сделай анимацию и разнообразь ближнее оружие (на следующее обновление)'),
      s('Spin Brawl', 'Свин', '2026-10-03', 'В режим Арены добавить больше разнообразных ловушек на карте, к примеру спруты которые будут сковывать игрока, лед который будет намертво замораживать, тиски которые могут в рандомный момент сжаться и которые достаточно большого размера но при этом в тисках будет спавниться больше искр, что бы туда был смысл рискованно ходить.'),
      s('Alien Scan Logic', 'Свин', '2026-10-03', 'Сейчас в игре очень мало интерактивных предметов, он по сути всего один металлоискатель, надо  добавить большее разнообразия проверка документов, диалоги и тд, возьми пример с игры papers please и Quarantine Zone.'),
      s('Velvet Domino Rogue', 'Жаслан (через REPORT.md)', '2026-10-17', 'a visual style of its own, like Balatro; more mechanics — it\'s simple and dull now; harder and more interesting; more combinations, everything playing off everything; more dynamic; Russian as the second language; a shop like Balatro\'s'),
      s('Frankengun', 'Плейтестер (через REPORT.md)', '2026-10-18', 'A playtester\'s late-run complaint ("the same six upgrades keep dropping"): the drop roll gave 40 % to the grid\'s own unfinished parts and ×1.6 weight on top, and the shop\'s 45 % gadget slots kept drawing the few gadgets not yet maxed.'),
    ],
  },
  {
    id: 'animation',
    flaw: 'Stiff or missing animation: things slide and pop instead of moving; hits have no weight',
    look: 'Watch the hero idle and walk, an attack, a hit, a death. Static sprites that translate, no wind-up or recoil, no hit reaction, nothing alive on a still screen',
    fix: '@gp/art rig (idle breathing, walk cycle, squash and stretch, anticipation, recoil) and fx (hit flash, sparks, hit-stop, shake) — docs/guides/art.md',
    measured: 'gp qa: a flat play frame (a hint), the title animates or stands still on purpose',
    sources: [
      s('Dread Throne', 'Свин', '2026-10-01', 'Новый вид противников, качественные анимации, разные атаки'),
      s('Yeet the Gnome', 'Жаслан', '2026-10-01', 'Переработать спрайты и анимации'),
      s('Kettlebot', 'Свин', '2026-10-01', '9. Анимации и эффекты: переходы, свечение, сканирование, искры, пар, марево, предупреждения — без хаоса'),
      s('Splicebound', 'Жаслан', '2026-10-02', 'Полностью новый современный дизайн и анимации'),
      s('Candle Crypt', 'Жюри конкурса (через Жаслана)', '2026-10-03', 'Сделай анимацию и разнообразь ближнее оружие (на следующее обновление)'),
    ],
  },
  {
    id: 'smooth',
    flaw: 'Not smooth: jerky actions, a full-screen flash on a choice or in a menu, frame drops in a fight',
    look: 'Play the busiest moment at the laptop size; open and close every menu. Any white or full-screen flash, a stutter, an action that jumps instead of easing',
    fix: 'One game loop (the gp init skeleton’s frame()); crossfades between screens, no full-screen flash (Fx flash only for a real explosion); ease every move (tween); the art.md list of what is slow on a software rasterizer',
    measured: 'gp qa: frame rate at three sizes alone on the machine, a hint for two game loops',
    sources: [
      s('Rivet Clash', 'не указан', '2026-10-03', 'Игра плавнее: дёрганые действия, вспышка экрана при выборе и в меню'),
      s('Candle Crypt', 'Жаслан (через REPORT.md)', '2026-10-11', 'сильно рябит … убрать или незаметнее'),
    ],
  },
  {
    id: 'review-calibration',
    flaw: 'A review that measures compliance passes games the portal rejects: every checklist item ticked, 0 [blocking], and the game still plainer than what CrazyGames takes',
    look: 'Before the checklist, put the game\'s first screen and play at 1280×720 beside games the portal approved and rejected (qa/review-sheet.png) and score each screen 1–5: would it sit on the front page next to them? A review with 0 blocking and a 3/5 look is the pattern of our rejections',
    fix: 'Score the sheet first, in quality.md\'s `## Scores`; a screen below 4 is a [blocking] finding that says what would lift it; the look of the first screen and of play is never [nice]; fix those before any [nice] item',
    measured: 'gp review: the review sheet (the game\'s frames beside publisher/reference/); gp review --check and gp submission refuse a CrazyGames quality.md without scores, or with a score below 4 that no [blocking] finding names',
    sources: [
      s('Swarm Smash', 'publisher/results.yaml', '2026-10-12', '1.2.0 (7a236d9): a ≈ 33-min run dock to dock, the ship as a backpack, 78 parts, 16 synergies, 7 bosses; quality 0 blocking / 0 nice.'),
      s('Swarm Smash', 'CrazyGames', '2026-10-12', 'The overall quality of the game does not yet meet the expectations of our platform'),
      s('Candle Crypt', 'Второй агент (через REPORT.md)', '2026-10-11', 'Third review round: 0 blocking, 6 nice, all six fixed before submitting'),
      s('Candle Crypt', 'CrazyGames', '2026-10-12', 'The overall quality of the game does not yet meet the expectations of our platform'),
      s('Velvet Domino Rogue', 'Второй агент (через REPORT.md)', '2026-10-17', 're-check: 0 [blocking], 14 [nice] (a lucky opening can still go 30× over, codex toasts over the panel in landscape, Ceramic\'s faint slots — fixed, desktop HUD small, the swirl\'s pixel steps …)'),
      s('Velvet Domino Rogue', 'CrazyGames', '2026-10-18', 'The overall quality of the game does not yet meet the expectations of our platform'),
    ],
  },
  {
    id: 'feel-over-features',
    flaw: 'Features grew faster than feel: every pass added systems, and the screens a player meets stayed as plain as before',
    look: 'Read the game\'s last day of commits (gp review lists them): new mechanics, modes, shops, screens? Then play the first three minutes: does each new thing arrive with its own look, sound and feedback, or as a line of text and a number?',
    fix: 'No new systems in the last pass before submission — only feel (juice, sound, typography, layout); a new system waits for the next update, and goes in with its screens drawn, animated and heard',
    measured: 'gp review: the commits of the last day and the scope check (systems × hours); nothing measures feel',
    sources: [
      s('Candle Crypt', 'publisher/results.yaml', '2026-10-12', 'Resubmission of 1.7.2 (b5914f2) after the 2026-10-11 Basic Launch stop (approved 2026-10-02 as 1.3): 75 weapons, the light and d20, 32-px sprites, straight into play.'),
      s('Swarm Smash', 'publisher/results.yaml', '2026-10-12', '1.2.0 (7a236d9): a ≈ 33-min run dock to dock, the ship as a backpack, 78 parts, 16 synergies, 7 bosses; quality 0 blocking / 0 nice.'),
      s('Velvet Domino Rogue', 'коммит 864bd33 (game6)', '2026-10-17', 'Velvet Domino Rogue v3 (the owner\'s design document): a 2D network (crossroads on doubles, the Glassblower\'s T), closed contours that multiply, the kinetic domino fall with impulse, the table\'s things (bell, spring, glass, anvil, ink, vein, astral seal, rift, forge, resonator), moods (slope, ink), weight and landslides, cracks and halves, the [0|0] bomb, cursed [9|9], saw / weld / melt / flip in hand, the bet, the Bazaar, the Broken Axle; …'),
      s('Swarm Smash', 'Жаслан', '2026-10-10', 'Хочу более уникальную модель построения уровней. А еще проработанный сквозной сюжет. Хочу чтобы была высокая реиграбельность и длительные партии. А еще систему открытия новых предметов редких событий и разнообразных наслаивающихся друг на друга механик и тд и тп'),
    ],
  },
  {
    id: 'web-app-look',
    flaw: 'DOM screens look like a web app: system or default fonts, grey rounded buttons, rows of small text — a page, not a game',
    look: 'At 1280×720, look past the canvas: do the title, the panels, the buttons and the HUD read like a settings page (system-ui or Georgia, grey pills, 12–14 px rows) or like the game (its own display face, drawn buttons with its materials, icons, its palette)?',
    fix: 'One display face of the game for titles, numbers and buttons (a bundled font, not system-ui), the HUD and buttons drawn in the game\'s materials (@gp/art/hud, @gp/art/dom), drawn icons, and the platform\'s screens themed with their --gp-* variables; system fonts only for long text, never for what a player reads in play',
    measured: 'nothing yet: gp qa does not check fonts or button styles — the reviewer judges it on the review sheet',
    sources: [
      s('Kettlebot', 'Свин', '2026-10-01', '10. Типографика: современный технический шрифт, моноширинные показатели, минималистичные заголовки'),
      s('Swarm Smash', 'Агент игры (через REPORT.md)', '2026-10-11', '**UI**: a clean system font for text (the pixel font for titles and icons), glass panels, gradient buttons with glow, fade/slide screen transitions, loot cards that fly in with rarity as colour and glow (rare and legendary shine).'),
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'The most-seen meta screens use the platform\'s stock look, not the game\'s. The results screen (RUN OVER / ARENA CONQUERED) is mountResults with no theming: a slate-grey panel, a yellow pill "Play again", an underlined "Menu", and the run as five lines of plain text ("Waves cleared: 0 · Kills: 3 / Level reached: 0 · +0 cores / …").'),
    ],
  },
  {
    id: 'desktop-decides',
    flaw: 'Phone-first layouts, but the desktop decides: a layout made for 360×800 leaves 1280×720 small, empty or cramped, and the portal judges the desktop first',
    look: 'Play 1280×720 first, with a mouse: is the playfield most of the frame, the HUD readable without leaning in, the title filling the screen, nothing parked in a corner? Then 821×462 (the portal\'s small iframe), then the phone',
    fix: 'Lay out the desktop and the phone each on purpose (the playfield scales to the frame, the HUD to the short side, side panels small); look at the 1280×720 QA shots first; score the desktop frames on the review sheet before the phone',
    measured: 'gp qa: every declared screen at 1280×720 and in the portal frames (DPR 1); gp review: the review sheet at 1280×720',
    sources: [
      s('Candle Crypt', 'publisher/results.yaml', '2026-10-10', 'The dashboard\'s "Evaluation Prognosis" (owner, 2026-10-10): mobile counts "only if it passes Desktop" — <9 not enabled on Mobile & Tablet, 9–10 enabled with improvements recommended, >10 enabled. Desktop (7/15) is the gate.'),
      s('Velvet Domino Rogue', 'Второй агент (через REPORT.md)', '2026-10-17', 're-check: 0 [blocking], 14 [nice] (a lucky opening can still go 30× over, codex toasts over the panel in landscape, Ceramic\'s faint slots — fixed, desktop HUD small, the swirl\'s pixel steps …)'),
      s('Swarm Smash', 'Жаслан', '2026-10-10', 'Боковые штуки с уровнем и с моим крейсером сделай меньше. Сама игра должна быть больше посередине'),
    ],
  },
  {
    id: 'art-direction',
    flaw: 'A prototype look: flat panels, thick black outlines, muddy colours, empty space, a style that reads as a children’s game',
    look: 'Does the first screen look like a finished game on the portal’s front page? Mixed styles, plain rectangles, a brown or grey palette, large empty areas, default fonts',
    fix: 'One art direction for every screen (palette with roles, one light, material with volume, depth by layers): @gp/art palette, material, light, scenery, hud — docs/guides/art.md; game type, not the system’s fonts: a bundled face from @gp/art/type (useFont: Dela Gothic One, Nunito Black, Exo 2, the GP Pixel font) for titles, buttons and numbers; never mix the old and the new look. A retro style (pixel art) must still read as a game of today: lit and moving everything (light, glow, particles, parallax, idle motion), a rich palette, a modern HUD — not a flat 8-bit screen',
    measured: 'gp qa: a flat play frame (a hint); gp covers scores the covers; gp review’s art section',
    sources: [
      s('Kettlebot', 'Свин', '2026-10-01', 'Полностью переработать дизайн, сделать интуитивнее и визуально понятнее'),
      s('Kettlebot', 'Свин', '2026-10-01', '1. Полностью отказаться от текущего стиля (коричневый фон, толстые контуры, плоские панели, детский стиль, пустые пространства)'),
      s('Kettlebot', 'Свин', '2026-10-01', '2. Новый визуальный концепт: стильная sci-fi игра, промышленный футуризм, выразительный свет, тёмные поверхности, яркие акценты'),
      s('Kettlebot', 'Свин', '2026-10-01', '6. Новый фон: футуристический комплекс с глубиной, слои параллакса, туман, лёгкая анимация'),
      s('Kettlebot', 'Свин', '2026-10-01', '7. Палитра: тёмный navy/charcoal, холодный серый, cyan, blue; тёплые цвета только для опасности'),
      s('Kettlebot', 'Свин', '2026-10-01', '10. Типографика: современный технический шрифт, моноширинные показатели, минималистичные заголовки'),
      s('Kettlebot', 'Свин', '2026-10-01', '11. Общее ощущение: premium / futuristic / atmospheric / technical / cinematic / polished'),
      s('Kettlebot', 'Свин', '2026-10-01', '12. Сначала единый дизайн-концепт всего экрана, не смешивать старое и новое; механика сохраняется'),
      s('Almus Gate', 'Жаслан', '2026-10-02', 'Дизайн: космический digital sci-fi и киберпанк'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Обновить графику'),
      s('Candle Crypt', 'Жюри конкурса (через Жаслана)', '2026-10-03', 'Переделать графику и адаптацию под телефоны и скомпилить это все для телефона возможно поменять платформу (Это на будущее)'),
      s('Alien Scan Logic', 'Свин', '2026-10-03', 'И переработай графику игры возьми пример с тех же игр papers please и Quarantine Zone'),
      s('Sigil Clash', 'Свин', '2026-10-03', 'Иногда во время заврешения уровня и перехода в меню застывший задний фон превращается в белый ослепляющий холст из за того что эффекты так же остаются надо исправить.'),
      s('Candle Crypt', 'Жаслан', '2026-10-03', 'А ещё лагает на телефоне'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Сделать графику более детализированной но оставить пиксельарт.'),
      s('Swarm Smash', 'Жаслан', '2026-10-10', 'В swarm shash мне не нравится графика. Я хочу чтобы она была более живой. Игра ощущается старой. Надо сделать ее живее и новее'),
      s('Candle Crypt', 'Жаслан (через REPORT.md)', '2026-10-11', 'не нравится свет и то как выглядит зачарованное оружие … играю за пятно света'),
    ],
  },
  {
    id: 'visible-progress',
    flaw: 'Progress you can’t see: an upgrade changes a number, not the thing on screen; new things don’t arrive as you play',
    look: 'Buy an upgrade: does the tower, the weapon, the robot look different? Are new towers, heroes, abilities unlocked along the way, or all there from the start?',
    fix: 'Every tier changes the sprite (size, parts, glow); unlocks spread over the campaign (Roster, Tiers with stages); a choice of 1 of 3 after a level (RunChoices); rarity and drops for parts',
    measured: 'gp balance: when each new thing arrives, the longest stretch without one; the model’s purchase table',
    sources: [
      s('Dread Throne', 'Свин', '2026-10-01', 'Видимые изменения внешнего вида при улучшении строений'),
      s('Все игры', 'Жаслан', '2026-10-10', 'Ты везде засовываешь систему прокачки, но сначала нужно модулем гейм дизайна какая прокачка или типо того нужна, потому что магазины не всегда подходят'),
      s('Dread Throne', 'Свин', '2026-10-01', 'Новые башни и улучшения открываются по ходу прохождения'),
      s('Echoflies', 'Свин', '2026-10-02', 'Выбор улучшений персонажа после каждого уровня'),
      s('Splicebound', 'Жаслан', '2026-10-02', 'Обучение со сборкой первого робота, части тела, редкость и выбивание, сквозной сюжет, части подходят друг к другу'),
      s('Spin Brawl', 'Жаслан, Свин', '2026-10-02', 'Выбор улучшений по массе, редкость, гарантированная легендарка на круглых числах'),
      s('Spin Brawl', 'Свин', '2026-10-03', 'Сделать карсивые иконки для улучшений которые наглядно будут показывать, что именно улучшается.'),
      s('Velvet Domino Rogue', 'Жаслан (через REPORT.md)', '2026-10-17', 'no linear upgrades — open new possibilities'),
    ],
  },
  {
    id: 'structure',
    flaw: 'A flat campaign: level after level with nothing changing; too few stages; no reason to play another way',
    look: 'Does the place change (a new biome, new enemies, a boss) every few levels? Is there a mode for after the campaign (endless, a daily, a battle royale)?',
    fix: 'Acts of 3–5 stages, each with its own place, enemies and boss; an endless or daily mode (@gp/core daily); for an arena, a second mode with its own rule (shrinking zone, more players)',
    measured: 'the balance model: stages, the meta’s length, goals over time',
    sources: [
      s('Echoflies', 'Свин', '2026-10-02', 'Акты со сменой местности и врагов вместо подряд идущих уровней'),
      s('Swarm Smash', 'Жаслан', '2026-10-10', 'Хочу более уникальную модель построения уровней. А еще проработанный сквозной сюжет. Хочу чтобы была высокая реиграбельность и длительные партии. А еще систему открытия новых предметов редких событий и разнообразных наслаивающихся друг на друга механик и тд и тп'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Больше стейджей (уровней); баланс — где-то слишком легко, где-то тяжело'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Бесконечный режим: случайные карты, выбор размера карты (больше карта — больше тропинок врагов)'),
      s('Spin Brawl', 'Жаслан, Свин', '2026-10-02', 'Режим королевской битвы с сужением локации'),
      s('Spin Brawl', 'Жаслан, Свин', '2026-10-02', 'Арена на 50 игроков: ловушки, случайные бусты'),
      s('Spin Brawl', 'Жаслан, Свин', '2026-10-02', 'Текущий режим назвать «Классический»'),
      s('Spin Brawl', 'Свин', '2026-10-03', 'Сделай режим арены классическим, а классический сделай ареной.'),
      s('Nimbus Drift', 'Свин', '2026-10-10', 'Добавить фоновую музыку, сделать ползунок громкости в настройках, добавить локализацию языков в том числе русский.  Добавить больше уровней и глав, в каждой главе сделать свои виды препятствий, свои виды растений и внешний вид самой площадки. Сделать  10 актов в каждом по 30 уровней.'),
      s('Dread Throne', 'Свин', '2026-10-10', 'Иконки поворота слишком сильно выделяются, сделай их более приглушенными, при просмотре возможности улучшения строения если не хватает душ иконка прокачки горит серым но если душу уже накопились а ты еще остался в меню просмотра улучшения строения то кнопка не загорается хотя улучшение купить уже можно надо исправить. Сделать рисунки строений в магазине более большими сейчас они слишком мелкие. Игра сейчас слишком простая прям очень легкая, так же бесконечный режим он никак не усложняется, с каждой волной просто заходит больше врагов за большее время но они все идут по одному, враги должны становиться чуть сильнее и идти в большем количестве с каждой новой волной. По сути бесконечный режим с такими условиями не получится пройти и это нормально.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Сделать шанс на секретные комнаты выше и теперь они должны быть не только в стенах, а еще они могут скрываться под блоками которые ломаются по типу кусков льда и коробок.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'При выборе подземелий сделать разные уровни сложности потому что сейчас все три варианта дают одинаковый уровень сложности.'),
    ],
  },
  {
    id: 'balance',
    flaw: 'Uneven difficulty: too easy by the middle of the upgrades, a wall somewhere else',
    look: 'Play with the upgrades a player has by the middle: do stages still need thought? Is there a stage you retry many times? Is there one safe spot or one move that always wins (stay low, stay at the edge, never move)? Is it hard enough for a good player: how often does a skilled player win from scratch? Is any 1-of-3 offer a no-brainer — count what you pick over five runs: the same card every time, or one you never take?',
    fix: 'The balance model: power ÷ difficulty on arrival 0.9–1.1, no stretch won ≥ 95 % three stages running, no wall; difficulty grows faster than rewards — docs/guides/upgrades.md. Measure difficulty with a skill ladder of bots (`skills: { naive, average, skilled }` in balance()): the average one for the curve, a skilled one (tighter aim, quicker reactions, dodges most telegraphs) for how often a win comes from scratch, aimed at the owner’s target declared in game.yaml `balance.difficulty` (Frankengun: ≈ 4 wins in 20, over 120 seeds — 40 vary too much; a winning run 30–40 min) and measured again after every change to drops, shops or waves (its varied late drops alone doubled the skilled bot’s wins); a naive bot within 80 % of the skilled one means the game plays itself. Balance the choices by their pick rates, as Slay the Spire did over Early Access (Giovannetti, GDC 2019; docs/research/game-design-2026-10.md P1, P3): log every offer and the pick (choiceLog()), and an option taken over 60 % of the times it is offered dominates — weaken it or make it situational — one taken under 5 % is dead weight — give it a role or drop it; the runs should end in different builds, and a stage that is really hard must also be short (King)',
    measured: 'gp balance and gp qa: the model’s wall, grind and «plays itself» checks, the curve against the channel; from the bot’s runs the skill ladder (balance.difficulty: the win rate and the winning run fail outside the target), the pick rate of every offered option, build diversity, hard stages short',
    sources: [
      s('Dread Throne', 'Свин', '2026-10-01', 'Баланс: к середине прокачки слишком легко'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Больше стейджей (уровней); баланс — где-то слишком легко, где-то тяжело'),
      s('Spin Brawl', 'Свин', '2026-10-03', 'Сейчас в игре почему то стоит ограничение в 500 массы, его неообходимо убрать. Сделать баланс улучшений ведь если сейчас набрать 500 массы и выбрать все улучшения ты становишься неубиваемым по сути.'),
      s('Kite Royale', 'Жаслан', '2026-10-03', 'В Kate Royal можно просто низко лететь и выигрывать. Поэтому добавь какой-то функционал или типо штрафы на высоту полета'),
      s('Dread Throne', 'Свин', '2026-10-10', 'Иконки поворота слишком сильно выделяются, сделай их более приглушенными, при просмотре возможности улучшения строения если не хватает душ иконка прокачки горит серым но если душу уже накопились а ты еще остался в меню просмотра улучшения строения то кнопка не загорается хотя улучшение купить уже можно надо исправить. Сделать рисунки строений в магазине более большими сейчас они слишком мелкие. Игра сейчас слишком простая прям очень легкая, так же бесконечный режим он никак не усложняется, с каждой волной просто заходит больше врагов за большее время но они все идут по одному, враги должны становиться чуть сильнее и идти в большем количестве с каждой новой волной. По сути бесконечный режим с такими условиями не получится пройти и это нормально.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Увеличить урон у оружий ближнего боя, сейчас он крайне низкий.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'В комнате с большим количеством шипов и сундуком с наградой сундук может заспавниться прямо у входа, так  не должно быть он всего должен быть в конце комнаты за шипами.'),
      s('Frankengun', 'Жаслан (через REPORT.md)', '2026-10-18', 'Difficulty and length (the owner\'s targets, measured by a SKILLED bot from scratch, 120 seeds): a win in 24/120 runs (4 of 20) · a winning run ≈ 33 min (fights + 40 s per Pit Stop).'),
    ],
  },
  {
    id: 'controls',
    flaw: 'Awkward or outdated controls: an action on the wrong gesture, small targets on a phone, a missing way to undo or let go',
    look: 'Play the phone size with touch only: can every action be done with a thumb, without mis-taps? Does a tap do what a player expects (a tap on a tile selects it, not rotates it)? Can you cancel, drop, detach?',
    fix: 'Big thumb buttons in an arc, a floating joystick or drag-to-aim, auto-attack where aiming is a chore; dangerous actions on their own button; every hold-to-do has a way back. Forgive the input (docs/research/open-source-games-2026-10.md): a jump still works 0.1 s after leaving a ledge, a press 0.1 s early fires on landing, a 4 px nudge around corners, tap targets bigger than the drawn sprite (Celeste\'s Player.cs, MIT)',
    measured: 'gp qa: touch targets ≥ the minimum, nothing off screen, the canvas UI the game declares',
    sources: [
      s('Dread Throne', 'Свин', '2026-10-01', 'Вращение плитки только кнопкой справа вверху, не нажатием на плитку'),
      s('Dread Throne', 'Свин', '2026-10-01', 'Перенос строения на другую клетку за монеты'),
      s('Starsilk', 'Ера', '2026-10-02', 'Отцепиться от чекпоинта повторным нажатием Reel'),
      s('Starsilk', 'Ера', '2026-10-02', 'Уровни с мотыльком проходимые: до любой части карты через чекпоинты'),
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Сброс активного предмета удержанием L Ctrl'),
      s('Candle Crypt', 'Жаслан', '2026-10-03', 'Для Candle crypt Сделай управление с телефона получше. Там оно устаревшее'),
      s('Candle Crypt', 'Жаслан', '2026-10-03', 'На телефоне candle crypt все ещё не очень'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Сделать переход в полземелье ниже после босса строго по нажатию кнопки, во избежании случайного перехода после убийства босса.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Убрать автоматическое применение заклинаний у калиевой свечи.'),
    ],
  },
  {
    id: 'ui-layout',
    flaw: 'An unfinished interface: bars and lines leaving the screen, a cramped page, a shop squeezed into a side panel, a button that doesn’t answer at first',
    look: 'Every screen at 360×800 and 800×450: anything cut, outside the frame or overlapping? Does it all fit one screen, with nothing to scroll up and down? Is the play field most of the screen, the side panels small? Tap Play and every first button the moment it shows — does it react at once? A 3D game in portrait: is the thing in hand in view, does the view show enough across (≈ 65–70°), does a timer or a banner sit on the HUD?',
    fix: 'Layout from the safe area; one screen, no scrolling (Жаслан, 2026-10-10): pages or tabs instead of a long list (mountUpgradeShop pages itself), fewer or smaller rows; only a message, a notification or a long text may scroll (data-gp-scroll="<why>"); the play field takes most of the screen and the HUD is compact; a shop of its own when the items are many; buttons live from the frame they appear (no dead start); a 3D view in portrait takes its field of view from a horizontal angle and keeps the held thing inside the frustum (docs/guides/three-fps.md)',
    measured: 'gp qa: text off screen, clipped or spilling, a page or a panel that scrolls, every declared screen at every size',
    sources: [
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Пунктир навигации уходит за рамки'),
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Шкала зарядки выходит за экран'),
      s('Spin Brawl', 'Жаслан, Свин', '2026-10-02', 'Поправить вёрстку страниц'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Строения покупаются в отдельном удобном магазине вместо панели справа; UI/UX интерфейса'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Кнопка начала битвы не нажимается первые 2 секунды — исправить'),
      s('Kettlebot', 'Свин', '2026-10-01', '4. Новый интерфейс: технологичные полупрозрачные панели, тонкие линии, голограммы, круглые шкалы, индикаторы'),
      s('Kettlebot', 'Свин', '2026-10-01', '8. Композиция: игровая область — большая часть экрана, HUD вокруг неё, адаптивная раскладка'),
      s('Candle Crypt', 'Жаслан', '2026-10-03', 'В Candle crypt не сами кубы показывай. Кидай кубы в какой-то области чтобы там они бросались, а не по центру'),
      s('Dread Throne', 'Свин', '2026-10-10', 'Иконки поворота слишком сильно выделяются, сделай их более приглушенными, при просмотре возможности улучшения строения если не хватает душ иконка прокачки горит серым но если душу уже накопились а ты еще остался в меню просмотра улучшения строения то кнопка не загорается хотя улучшение купить уже можно надо исправить. Сделать рисунки строений в магазине более большими сейчас они слишком мелкие. Игра сейчас слишком простая прям очень легкая, так же бесконечный режим он никак не усложняется, с каждой волной просто заходит больше врагов за большее время но они все идут по одному, враги должны становиться чуть сильнее и идти в большем количестве с каждой новой волной. По сути бесконечный режим с такими условиями не получится пройти и это нормально.'),
      s('Swarm Smash', 'Жаслан', '2026-10-10', 'Боковые штуки с уровнем и с моим крейсером сделай меньше. Сама игра должна быть больше посередине'),
      s('все игры', 'Жаслан', '2026-10-10', 'Меня бесит что игры не помещаются в весь экран и приходится туда сюда двигать по оси y. Можешь сделать правило при котором все помещается в один экран (кроме сообщений, уведомлений и тд по необходимости)'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'В финальном меню забега где отображаюься все использованные оружия некоторые иконки которых очень сильно заужены, надо исправить и сделать их нормальными в полном размере.'),
      s('Candle Crypt', 'Жаслан (через CHANGELOG.md)', '2026-10-10', 'страница перегружена'),
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'Phone portrait (360×800), where most CrazyGames plays happen, hides the game\'s whole idea and crowds the HUD. (1) The gun in your hands, which is what you build, is almost entirely off the right edge, under the Lv/HYPE bars. […] (2) The vertical FOV is 82° (view.ts:128), so at this aspect you see only about 43° across, and robots hit you from outside the view.'),
    ],
  },
  {
    id: 'information',
    flaw: 'The player can’t see what happened or where they are: rolls, damage and the map stay hidden',
    look: 'After a fight, can you tell why you won or lost? Is there a map with where you are? Do random outcomes (dice, crits, drops) show?',
    fix: 'A log of the random outcomes (rolls, crits, drops), floating numbers, a detailed map with the player’s icon and corridors; it folds away on a phone',
    sources: [
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Карта: детализация, иконка игрока, коридоры на мини-карте, настройки мини-карты'),
      s('Candle Crypt', 'Жаслан', '2026-10-03', 'И сделай какую-нибудь область где будут показаны все броски кубиков'),
      s('Kettlebot', 'Свин', '2026-10-01', '5. Температура как визуальный язык: Normal → Warm → Danger → Critical, реагирует весь экран и робот'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Отмечать комнату входа на карты специальным знаком (сейчас она просто пустая).'),
      s('Velvet Domino Rogue', 'Жаслан (через REPORT.md)', '2026-10-17', 'I don\'t understand how much I\'ll get, when and why to discard, I can\'t change my bones'),
    ],
  },
  {
    id: 'sound',
    flaw: 'No music, or no way to set the volume',
    look: 'Is there background music? Are there volume sliders for music and effects in the settings?',
    fix: 'Background music per place through the host’s audio; two sliders (music, effects) in the settings, saved. A sound for every interaction state — hover, pick, drop, a denied move, hit, hurt, pickup, level-up — with ±5 % pitch variation and a pitch that rises with a combo (ZzFX presets, MIT, ≈ 1 KB, as two js13k winners do); music that builds in layers as the run grows (docs/research/open-source-games-2026-10.md)',
    measured: 'gp validate: E_SOUND_MUSIC on CrazyGames (the code calls createMusic, or game.yaml sound.music says what plays); gp review --check refuses a CrazyGames code game without music; gp qa: the portal’s mute, one AudioContext, and the sound section (effects against the music, long silences in play)',
    sources: [
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Ползунок громкости'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Фоновая музыка; ползунки громкости музыки и эффектов'),
      s('Firefly Rush', 'Свин', '2026-10-03', 'Добавить в игру музыку.'),
      s('Hang the Moon', 'Свин', '2026-10-10', 'Разнообразить количество планет, используй планеты солнечной системы и подписывай каждую планету реальными названиями. Добавь множество других языков в том числе русский. Добавь музыку на фон, в настройках добавь ползунки громкости для регулировки.'),
      s('Nimbus Drift', 'Свин', '2026-10-10', 'Добавить фоновую музыку, сделать ползунок громкости в настройках, добавить локализацию языков в том числе русский.  Добавить больше уровней и глав, в каждой главе сделать свои виды препятствий, свои виды растений и внешний вид самой площадки. Сделать  10 актов в каждом по 30 уровней.'),
      s('Kettlebot', 'Второй агент (gp review)', '2026-10-01', 'There is no music: only synth beeps from sound.ts. → Add a quiet looping ambient/industrial track, ducked during ads and off with the Sound button.'),
    ],
  },
  {
    id: 'juice',
    flaw: 'Flat feedback: actions make no sound, the same sound plays a hundred times, a score just appears — the game feels "simple and dull" though its rules are fine',
    look: 'Play 5 minutes with the sound on: does every tap, pick, hit, denied move and button answer at once? Does a long chain or combo build (quicker, higher, louder) and land with weight, or does a number simply change? Does one hit sound exactly like the last hundred? Can you tell how much a move will score before you make it?',
    fix: 'A sound within 150 ms of every action (createSfx: files or sfxRecipe — click, hit, deny, coin, whoosh, pop, thud, boom, struck materials), ±6 % pitch on every play and a pitch that climbs with a combo; the score as a trace played beat by beat (ScoreSequencer: quickening beats, count-up, labels at each spot, a roll, a land sized by the total against the target, a tap to fast-forward) and its result shown before the player commits (previewScore); shake, sparks and the music’s duck on the land, scaled by its size',
    measured: 'gp qa: the sound section — the share of taps, keys, button clicks and the game’s moments answered by a sound within 150 ms, exact repeats, effects against the music, clipping (qa/sound.json); the rest is yours — QA can’t judge a land’s weight',
    sources: [
      s('Velvet Domino Rogue', 'Жаслан (владелец, через REPORT.md)', '2026-10-17', "a visual style of its own, like Balatro; more mechanics — it's simple and dull now; harder and more interesting; more combinations, everything playing off everything; more dynamic"),
      s('Spin Brawl', 'Свин', '2026-10-10', 'Сейчас игрок слишком стремительно теряет массу, я добрался до 500 массы но она настолько быстро теряется что это не нормально надо исправить, добавить фоновую музыку, разнообразить звуки ударов. Так же еще разнообразить ловушки добавив например шипы и нужно увеличить карту. В игре надо сделать онлайн режим сервер для этого будем использовать Photon кототрый рекомендуют сами Crazy Games. Так же сделать выбор режима игры с реальными игроками либо с ботами. Сделать улучшения не такими частыми. На телефоне добавить внешний вид стика управления сейчас его вообще нет. Добавить разные звуки при попадании в ловушки допустим попал в лед звук заморозки. При  применении улучшений добавить эффекты и звуки соответствующие редкости улучшения. Сделать панель с улушчениями на телефонах компактнее если улучшений слишком много.'),
    ],
  },
  {
    id: 'retention',
    flaw: 'Approved, then stopped after Basic Launch: players leave after 4–7 minutes and 1–2 % come back the next day (targets: 10+ min, D1 10–15 %, 80 %+ past the first minute)',
    look: 'Play 15 minutes as a stranger: does something new arrive every 1–3 minutes of the first 10? Does the run itself change on the way (the place, the weather, the music, the enemies)? Close the tab mid-run and reopen: is the run still there? At the 15th minute, what is 60–80 % done that you want to finish tomorrow?',
    fix: 'Pace from time (docs/guides/upgrades.md: the anchor and the session-end check): the first reward inside 60 s, a new thing every 1–3 min early; a run that changes as it goes (a timeline of palette, weather, ambience and music layers); combos whose feedback grows; save the run on every move and resume it (2048, Hextris); end the session with a goal left at 60–80 % and a reason for tomorrow (a daily seed, offline progress re-simulated for idle games); difficulty offered, never silently changed',
    measured: 'gp balance / gp qa: the first-session pacing and the session-end snapshot when game.yaml declares balance.anchor; gp forecast: the return; publisher/results.yaml: the Basic Launch metrics',
    sources: [
      s('Spin Brawl', 'CrazyGames', '2026-10-09', 'The game did not reach the performance benchmarks during Basic Launch'),
      s('Hang the Moon', 'CrazyGames', '2026-10-09', 'The game did not reach the performance benchmarks during Basic Launch'),
      s('Starsilk', 'CrazyGames', '2026-10-09', 'The game did not reach the performance benchmarks during Basic Launch'),
    ],
  },
  {
    id: 'first-minute',
    flaw: 'Players leave in the first minute: a wait before Play, a screen between Play and the game, a loss before they understand, nothing rewarding early',
    look: 'Open the game on the phone size as a stranger and time it: when can you tap Play, does Play start the game, what if you touch nothing for 10 s, when does the game first celebrate you? Count the seconds of the first 30 with nothing to fight or choose (a corridor, an empty room, a wave counter over an empty floor) and the numbers on the HUD nobody has explained yet. Play the first minute on a phone with random thumbs too: are you still alive at its end?',
    fix: 'Play starts the run at once; the first seconds can\'t be lost; one short line of what to do; a reward in the first 20–30 s (a hit, a coin, a level up); no dead time: the first fight in the first room within 2–3 s and the first pick of 1 of 3 by 0:30 (the pixel-roguelite breakouts: Brotato’s first wave ends at 0:20 in its shop, an Archero room lasts under a minute and ends in a skill pick — docs/research/pixel-roguelites-2026-10.md §4); the game’s own vocabulary (dice, armour class, miss chance) on the HUD only once it matters, the twist’s one line on its first appearance; menus, story and shop after the first run. A new player’s first run forgives: a rookie factor on the damage taken in its first waves (save.runs === 0 — Frankengun: ×0.45 for waves 1–2, after which random thumbs lived through wave 1) and a cue that points to whatever hit you',
    measured: 'gp qa: the first-minute section (qa/first-minute.json — Play ready, Play → run, idle loss, words, first host.happytime) and the review brief',
    sources: [
      s('Basic Launch dashboard', 'CrazyGames', '2026-10-04', 'Минуту доиграли 20–68 % игроков (цель 80 %+), на следующий день вернулись 1–4 % (цель 10–15 %): Dread Throne, Starsilk, Nimbus Drift, Candle Crypt, Hang the Moon, Spin Brawl.'),
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'The first minute on a phone can be lost before the player understands anything. With a fresh save at 360×800 and random thumbs I was DOWN after about 35 s of wave 1, with 0 kills (seed 3).'),
      s('Candle Crypt', "CrazyGames (publisher/results.yaml, the owner's score screen)", '2026-10-22', 'Desktop 11/15 "Ready for Full Launch (>10)": playtime 13m33s → 5 · D1 18.18 % → 5 · conversion 42.22 % → 1 (2 at 53.95 %)'),
      s('Candle Crypt', 'Третий агент (gp review --first-look)', '2026-10-22', 'But the 30 s show little fighting: one skirmish at 8 s, then empty corridors and an empty room labelled "Wave 1 – 3 left".'),
    ],
  },
  {
    id: 'start-sound',
    flaw: 'A start that hurts: a loud or harsh sound in the first seconds, before the player chose anything',
    look: 'Open the game with the volume at a normal level and listen to the first 3 s of the title and of the first run: does anything boom, hiss or roar? Is a loop (boiling, wind, an engine) noise rather than a sound?',
    fix: 'Nothing loud in the first 3 s: music fades in over 1–2 s, effects start below the music, loops are soft and tonal (bubbling, not white noise); every level through the host’s mixer (@gp/core/sound createMixer), so the sliders and the portal’s mute reach it',
    measured: 'gp qa: the start’s loudness (qa/first-minute.json, when this platform measures it); otherwise yours — QA can’t hear',
    sources: [s('Potion Logic', 'Свин', '2026-10-10', 'Убрать оглушайющий звук кипения при старте, заменить текущий звук кипения который больше похож на шум, на какое нибудь бульканье воды.')],
  },
  {
    id: 'dominant-strategy',
    flaw: 'One way always wins: a safe spot, a single move or no input at all beats the game, so play stops being a choice',
    look: 'Try the dumb strategies for a few minutes each: stay low, stay at the edge, never move, spam one button, buy only one upgrade. Does any of them win as often as playing well? Does the game play itself between your inputs?',
    fix: 'Give the safe choice a cost and the risky one a reward (loot where it is dangerous, a penalty that grows the longer you camp); the demo bot plays the dumb strategy too and must lose more often than a fair player — measure it before and after; a fight needs a decision every few seconds',
    measured: 'gp balance: the model’s «plays itself» check (3+ stages won ≥ 95 % on arrival); a bot strategy is yours to write',
    sources: [
      s('Kite Royale', 'Жаслан', '2026-10-03', 'В Kate Royal можно просто низко лететь и выигрывать. Поэтому добавь какой-то функционал или типо штрафы на высоту полета'),
      s('Kettlebot', 'Второй агент (gp review)', '2026-10-01', 'The fight still plays itself. The player\'s only actions are one vent tap every 4 s and an occasional drag. In the re-check my bot again only vented the same blaster and got to the Server Vault boss.'),
      s('Spin Brawl', 'Свин', '2026-10-03', 'Сейчас в игре почему то стоит ограничение в 500 массы, его неообходимо убрать. Сделать баланс улучшений ведь если сейчас набрать 500 массы и выбрать все улучшения ты становишься неубиваемым по сути.'),
      s('Dread Throne', 'Свин', '2026-10-10', 'Иконки поворота слишком сильно выделяются, сделай их более приглушенными, при просмотре возможности улучшения строения если не хватает душ иконка прокачки горит серым но если душу уже накопились а ты еще остался в меню просмотра улучшения строения то кнопка не загорается хотя улучшение купить уже можно надо исправить. Сделать рисунки строений в магазине более большими сейчас они слишком мелкие. Игра сейчас слишком простая прям очень легкая, так же бесконечный режим он никак не усложняется, с каждой волной просто заходит больше врагов за большее время но они все идут по одному, враги должны становиться чуть сильнее и идти в большем количестве с каждой новой волной. По сути бесконечный режим с такими условиями не получится пройти и это нормально.'),
    ],
  },
  {
    id: 'mobile-controls-visible',
    flaw: 'Phone controls a new player can’t see: an invisible stick, gestures nobody shows, buttons that appear only after a touch',
    look: 'Open the game at 360×800 with touch only and look at the first frame of the run before touching: is the stick, the drag zone or every button drawn? Does the first touch do what the picture promises?',
    fix: 'Draw the touch controls from the first frame of the run (a stick base with its knob, or a ghost hand on the drag), sized for a thumb and in the thumb arc; they follow the finger but never vanish; on desktop show the keys instead',
    measured: 'gp qa: the touch controls visible at the first frame (qa/first-minute.json, when measured); touch targets ≥ the minimum',
    sources: [
      s('Spin Brawl', 'Свин', '2026-10-10', 'На телефоне добавить внешний вид стика управления сейчас его вообще нет.'),
      s('Candle Crypt', 'Жаслан', '2026-10-03', 'Для Candle crypt Сделай управление с телефона получше. Там оно устаревшее'),
    ],
  },
  {
    id: 'first-visit-gameplay',
    flaw: 'A first visit that doesn’t land in gameplay: a title, a menu, a story or a choice between the portal’s Play Now and the first action',
    look: 'Open the game with a fresh save (a private window) and count the clicks until you control the game. The portal’s Play Now is already one: on CrazyGames a second gate (our Play button, a mode choice, a prologue) costs conversion',
    fix: 'With no save, boot straight into a safe first run (firstRun from @gp/core when the platform has it); the title comes after the first run or on pause; at most one click to play; the menus, the story and the shop after the first minute',
    measured: 'gp qa: clicks to gameplay and Play → the run (qa/first-minute.json); the Basic Launch score screen: gameplay conversion (publisher/results.yaml)',
    sources: [
      s('CrazyGames requirements', 'CrazyGames', '2026-10-10', 'Games should land new users in gameplay immediately. If this is not feasible given the game specifics, a maximum of 1 click is allowed.'),
      s('Candle Crypt', 'CrazyGames (экран оценок, владелец)', '2026-10-10', 'Desktop 7/15 "Below requirements (<9)": gameplay conversion 51.25 % → 1 (2 at 54.00 %); Mobile and Tablet 9/15: conversion 1'),
      s('Starsilk', 'CrazyGames (письмо)', '2026-10-09', 'Desktop 4/15, mobile 5/15: время в игре 4m59s (2/5), D1 1.84 % (2/5), конверсия (сыграли ≥ 1 мин) 26.26 % (1/5).'),
    ],
  },
  {
    id: 'results-continue',
    flaw: 'Every results screen is an exit: the run or level ends on a page whose biggest button is Menu, so the session ends there',
    look: 'Finish five runs or levels. What is the biggest button on each results screen? Does it start the next run at once, and does the screen name the next goal (60–80 % done)? Count the screens per 15 minutes where a player could just close the tab',
    fix: 'The big button continues (Next, Play again, with the next goal named); Menu is small; on level games auto-continue after 3–5 s or offer a 1-of-3 choice before the next level; longer runs with fewer menu exits where the genre allows (mountResults from @gp/core when the platform has it)',
    measured: 'gp qa: the results screen’s primary action (when this platform checks it); the Basic Launch score screen: average playtime (publisher/results.yaml)',
    sources: [
      s('Hang the Moon', 'CrazyGames (письмо)', '2026-10-09', 'Desktop 5/15, mobile 5/15: время в игре 4m19s (2/5), D1 1.68 % (2/5), конверсия (сыграли ≥ 1 мин) 30.96 % (1/5).'),
      s('Starsilk', 'Ера', '2026-10-02', 'Больше уровней, механик, монстров со способностями, возможностей игрока'),
    ],
  },
  {
    id: 'session-length',
    flaw: 'Sessions end after 3–6 minutes: every Basic Launch we had stopped on average playtime, where successful titles have 10+ min a session',
    look: "Play 12 minutes from a fresh save on desktop as a new player and note the moment you would close the tab: a results screen with nothing pulling you into the next run, a goal that didn't move, a wait, an offer you must take to go on, a stretch with nothing new. Count the exits in 15 minutes, and what pulled you past each one",
    fix: "Auto-continue into the next run or level (mountResults autoContinueSec); the next goal always on screen with its progress moving (goal, goalFromSnapshot); a meta reward every 2–3 min (an unlock, an affordable upgrade, a new place); no dead end after the results (the big button continues, never the title); longer runs with fewer exits where the genre allows; offline and idle hooks only as extras — they bring players back, they don't keep them (docs/guides/first-minute.md → The session)",
    measured: "gp qa: the session section (qa/session.json: every break, what pulled on, the first natural stop and an estimate; W_SESSION_SHORT when the stop comes before 10 min on crazygames); gp review: the reviewer's ## Session (a stop before 8:00 is [blocking] on crazygames); gp forecast: the Basic Launch playtime score from the design and the QA estimate",
    sources: [
      s('Spin Brawl', 'CrazyGames (publisher/results.yaml)', '2026-10-09', 'Basic Launch ended 2026-10-09 (email): "did not reach the performance benchmarks". Desktop 8/15 (below), mobile 7/15:'),
      s('Dread Throne', 'CrazyGames (publisher/results.yaml, desktop)', '2026-10-12', 'playtime: { value: 3.3, score: 1 }'),
      s('Dread Throne', 'CrazyGames (publisher/results.yaml, mobile)', '2026-10-12', 'playtime: { value: 10.35, score: 3 }'),
      s('Candle Crypt', "CrazyGames (publisher/results.yaml, the owner's score screen)", '2026-10-10', 'Desktop 7/15 "Below requirements (<9)": playtime 9m31s → 4 (5 at 12m13s)'),
      s('Basic Launch dashboard', "CrazyGames (publisher/results.yaml, the owner's screenshot)", '2026-10-04', 'candle-crypt   117 · 11:41 · 2.50 % · 34 % · 0.7 %   (the only one over 10 min)'),
      s('Basic Launch dashboard', 'CrazyGames (publisher/results.yaml)', '2026-10-04', 'Targets: 10+ min, conversion 80 %+, D1 10–15 %.'),
      s('Potion Logic', 'CrazyGames (publisher/results.yaml, desktop)', '2026-10-14', 'playtime: { value: 3.87, score: 1 }'),
      s('Idle Garage Evolution', 'The owner (publisher/results.yaml)', '2026-10-14', "The owner's dashboard by 2026-10-14: mobile 5/15 (playtime 3m9s, D1 1.67 %, conversion 34.56 %); 1.2.0 (32b38e8) answers it."),
      s('Hang the Moon', 'CrazyGames (publisher/results.yaml)', '2026-10-19', "stopped again 2026-10-19 — 2.0's acts and planets lifted desktop conversion 61 % → 64 % and D1 2.37 % → 2.35 %, playtime still under 5 min."),
    ],
  },
  {
    id: 'daily-visible',
    flaw: 'No reason to come back tomorrow that the player can see: no daily, no goal left open, nothing on the title that changes by tomorrow',
    look: 'Play a session, then imagine tomorrow’s visit: what does the title promise (a new daily, a goal at 80 %, the next chapter)? Is it on the screen, or only in the code?',
    fix: 'A daily on the title with its state ("Daily ✓ · new in 6 h", @gp/core/daily) and a reward the first time each day — never a loss-framed streak; the last screen of a session names the goal left at 60–80 %; a welcome-back card on a return visit',
    measured: 'gp validate: E_MONEY_RETURN on CrazyGames (money.returns required); the Basic Launch score screen: D1 (publisher/results.yaml)',
    sources: [
      s('Candle Crypt', 'CrazyGames (экран оценок, владелец)', '2026-10-10', 'Desktop: D1 2.96 % → 2 (3 at 3.94 %); Mobile and Tablet: D1 3'),
      s('Hang the Moon', 'CrazyGames (письмо)', '2026-10-09', 'Desktop 5/15, mobile 5/15: время в игре 4m19s (2/5), D1 1.68 % (2/5), конверсия (сыграли ≥ 1 мин) 30.96 % (1/5).'),
    ],
  },
  {
    id: 'drawn-icons',
    flaw: 'Emoji or the system’s glyphs as the game’s icons: they look different on every phone, clash with the art and read as a placeholder',
    look: 'Look at every icon — items, upgrades, currencies, buttons, the HUD: is any of them an emoji or a font glyph (★ ❤ ⚙ ⚡, a ◆ currency, ▶ ◀ for play and paging, ✓ ✕) — in the strings files too? Do they share the game’s palette and light?',
    fix: 'Drawn icons in the game’s style (Path2D shapes through @gp/art material, or `gp art` assets), one size grid, readable at 360 px; emoji only where the game is about emoji. One icons set (inline SVG on one 24-unit grid, stroked in the thing’s colour) for every screen — @gp/core/icons has ~75 (icon("coin", { style: "solid", color }), drawIcon() on the canvas), and the platform’s own screens use it; a game’s own drawings take the same IconDef shape; the currency is the same drawn icon everywhere, and in a translated sentence its word, never a glyph',
    measured: 'gp review: emoji in the code’s strings (a hint for the reviewer)',
    sources: [
      s('Secret House Tycoon', 'Свин', '2026-10-10', 'Заменить иконку робота пылесоса сейчас он выглядит как губка.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Везде где используются эмодзи замени их на нарисованные иконки в стиле игры.'),
      s('Spin Brawl', 'Свин', '2026-10-03', 'Сделать карсивые иконки для улучшений которые наглядно будут показывать, что именно улучшается.'),
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'Emoji and font glyphs are used as the game\'s icons. ⚡ (an emoji: it rendered as a yellow colour emoji) starts every ability line on the Chassis screen (main.ts:541). ◆ is the currency in "Clear 8 waves: +200 ◆" (weekly event), in the contract line (main.ts:450) and in "Tier rewards: +70 ◆" on the win screen.'),
    ],
  },
  {
    id: 'themed-platform-screens',
    flaw: 'The platform’s own screens in their stock look: the results, the language sheet and the welcome-back card in slate grey with a yellow pill, beside the game’s art',
    look: 'Finish a run, open the language picker, read the welcome-back card (a new day, or the game’s CSS): do they wear the game’s panel, accent and font, or the platform’s slate grey and yellow? Does a third button colour come only from a stock screen? Do the results show the run itself, or lines of text?',
    fix: 'One call dresses every platform screen in the game’s look: screenTheme({ bg, panel, ink, muted, accent, accentInk, accent2, track, radius, font, display }) from @gp/core — the results, welcome back, the language sheet, the streak, the dialogue, the season, the shop, the sites map and the hint fall back to it; a face from @gp/art/type (useFont) for font and display, never the system’s; a screen’s own variables (--gp-results-* on #gp-results …) still win for one-off changes — docs/guides/code-games.md → Platform screens in the game’s look; on the results show what the run built (a picture of it: the model rendered off screen) and the stats as icon + number; one primary colour and one secondary across the game',
    measured: 'gp qa: screenshots of the results and the language sheet at every size; nothing compares them with the game’s look',
    sources: [
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'The most-seen meta screens use the platform\'s stock look, not the game\'s. The results screen (RUN OVER / ARENA CONQUERED) is mountResults with no theming: a slate-grey panel, a yellow pill "Play again", an underlined "Menu", and the run as five lines of plain text ("Waves cleared: 0 · Kills: 3 / Level reached: 0 · +0 cores / …").'),
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'Three button accents compete: magenta primaries, cyan "Back", and the yellow "Play again" from the stock results screen. → Pick one primary colour and one secondary.'),
    ],
  },
  {
    id: 'side-systems-later',
    flaw: 'A prototype look from too many systems at once: side screens a reviewer meets in the first ten minutes that aren’t finished — a text list, a placeholder picture, one icon for five things',
    look: 'From a fresh save, open every button the title shows in the first session. Count the systems around the core action, and the screens among them that are a plain text list, a blurred placeholder or stock cards. About ten systems with two or three unfinished is what a reviewer called a prototype risk',
    fix: 'Finish a screen or hide it: the side systems (a daily run, a weekly event, contracts, danger levels, an endless mode) appear only after the first runs (Frankengun: the daily run, the event and contracts after 2 runs; danger and Overtime after a win), so the first session meets a short title and only finished screens; a meta’s big unlocks get a picture (the model rendered off screen, as an armory renders its guns) and a drawn icon for what they do, not a text row',
    measured: 'gp qa: every declared screen at every size, with its screenshot; nothing judges whether a screen is finished',
    sources: [
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'Prototype risk: this game has about 10 systems around the core action, made in 9.7 h. […] → Finish those screens, or hide the side systems from a first session: show the weekly event, contracts, danger and Overtime only after the first 2–3 runs, so a reviewer\'s first 10 minutes meets only finished screens.'),
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'The Chassis screen (title → "Scrapper") is a plain six-row text list. Each chassis "picture" is a blurred coloured square (screen-chassis-*.png), on the meta\'s biggest unlocks (120–220 cores each, each with its own ability).'),
    ],
  },
  {
    id: 'onboarding',
    flaw: 'No real tutorial: the player is told, not shown, or left to guess',
    look: 'From a fresh save: do the first minutes teach each action by doing it, with the real controls highlighted? Or a wall of text, or nothing?',
    fix: 'Teach by doing, lightly: one short hint at the moment an action is first needed (a glowing button, three words), gone as soon as the player does it; never a chain of modal popups that stop play (Candle Crypt: «очень навязчивая»); skippable, and off for returning players',
    measured: 'gp qa: words on screen before the first action, the twist explained in time',
    sources: [
      s('Rivet Clash', 'не указан', '2026-10-03', 'Адекватное обучение'),
      s('Splicebound', 'Жаслан', '2026-10-02', 'Обучение со сборкой первого робота, части тела, редкость и выбивание, сквозной сюжет, части подходят друг к другу'),
      s('Candle Crypt', 'Жаслан', '2026-10-03', 'А ещё обучалку убери. Она очень навязчивая в Candle Crypt. Сделай ее попроще'),
    ],
  },
  {
    id: 'characters-story',
    flaw: 'No characters or story where the genre wants them: avatars instead of faces, no scenes between chapters',
    look: 'Do characters have faces and a look of their own? Does a chapter end with a scene? Can the player skip it and see it again?',
    fix: 'Portraits drawn in the game’s style; comic-card scenes after a chapter (mountDialogue), Skip, a Scenes button in the menu — docs/guides/story.md',
    measured: 'gp story: how much story the genre needs; gp qa: a dialog after Play has a Skip',
    sources: [
      s('Swarm Smash', 'Жаслан', '2026-10-10', 'А еще проработанный сквозной сюжет'),
      s('Dread Throne', 'Свин', '2026-10-01', 'Новый сюжет: сцены-комиксы карточками после главы, пропуск, кнопка сцен в меню'),
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Лица других свеч вместо аватарок'),
      s('Almus Gate', 'Жаслан', '2026-10-02', 'Упор на космос; 80+ заранее подготовленных персонажей с разными дизайнами'),
      s('Kettlebot', 'Свин', '2026-10-01', '3. Новый робот: металлический ремонтный робот с визором, кабелями, вентиляцией, износом и анимацией перегрева'),
    ],
  },
  {
    id: 'concept',
    flaw: 'Not its own game, or not what players look for: close to existing titles, nothing trendy or simple to grasp',
    look: 'Say the game in one sentence. Is it like the closest portal games with a new skin? Can a player get it in 10 seconds?',
    fix: 'Change the core action, goal or rule (gp uniqueness), not the text; a simple, current hook — docs/guides/uniqueness.md, game-ideas.md',
    measured: 'gp uniqueness, W_CONCEPT_TAKEN, the twist in play',
    sources: [
      s('Yeet the Gnome', 'Жаслан', '2026-10-01', 'Уникальная концепция геймплея'),
      s('Yeet the Gnome', 'Жаслан', '2026-10-01', 'Сделать что-то трендовое и простое'),
    ],
  },
  {
    id: 'cover-hero',
    flaw: 'A cover that doesn’t show the game’s hook: a generic hero (a box of a robot, an explosion) instead of what the title promises and the twist does',
    look: 'Look at store/cover-preview-200.png and say what the game is from the cover alone. Is the hero the twist — what the player builds, holds or does that the closest games don’t — big and in front? Does the picture keep the title’s promise?',
    fix: 'The hero is the twist, mid-action and in front; in a first-person game, the thing in the player’s hands (Frankengun: the stitched-together gun in hand, mismatched parts in robot paints, one more part snapping on with a spark); the world, the enemies and the blast behind it; the title the only text. Drawn with the game’s own models in host.qa({ cover }) — docs/guides/covers.md',
    measured: 'gp covers: the 200 px score (the title, contrast, colour, clutter, the hero’s size and outline) — not whether the hero is the hook',
    sources: [
      s('Frankengun', 'Второй агент (gp review)', '2026-10-18', 'The covers don\'t show what the name and the game are about. On all four covers the hero is a robot seen as two flat rectangles: a grey box head and a big dark-red panel, with no face, no limbs and no part coming off. It reads as a box at 200 px (cover-preview-200.png).'),
    ],
  },
  {
    id: 'title-key-art',
    flaw: 'A title screen that hides the game’s best picture behind a centred dark panel of buttons',
    look: 'At 1280×720, is the key art (the hero, the car, the arena) seen whole, full-bleed, with the logo and Play beside or over a clear part of it? Or does a panel cover the middle?',
    fix: 'Full-bleed key art with the hero in view; the logo and one big Play over its quiet part; side systems behind small icon buttons, not a column of menu rows',
    measured: 'not yet: the blind review of 2026-10-19 named it on four of six titles (docs/research/qa-calibration-2026-10.md)',
    sources: [
      s('Idle Garage Evolution', 'Слепой ревьюер (калибровка)', '2026-10-19', 'The title\'s modal covers the painted hero car, so the best art is hidden.'),
      s('Swarm Smash', 'Слепой ревьюер (калибровка)', '2026-10-19', 'The title is a busy menu box: a seed input field, four small buttons and very small pixel type over an empty starfield.'),
    ],
  },
  {
    id: 'meta-silhouettes',
    flaw: 'A collection or codex a new player opens and sees as rows of “???” silhouettes or near-identical dark icons',
    look: 'Open the album/codex on a fresh save: how much of it is silhouettes? Can you tell the locked entries apart?',
    fix: 'Show the first page partly filled (a few found in the first run), locked entries as tinted outlines with a hint of what they are, a counter instead of a wall of blanks',
    measured: 'not yet',
    sources: [
      s('Idle Garage Evolution', 'Слепой ревьюер (калибровка)', '2026-10-19', 'The meta screens are weak: the album is 15 "???" silhouette cards'),
      s('Velvet Domino Rogue', 'Слепой ревьюер (калибровка)', '2026-10-19', 'The codex is 37 near-identical dark icons that are hard to read.'),
    ],
  },
  {
    id: 'languages',
    flaw: 'English only',
    look: 'Is there a language picker on the title, and are the texts translated?',
    fix: 'The ten portal languages through host.t and strings/<code>.yaml, a languagePicker on the title — docs/guides/i18n.md',
    measured: 'gp validate (E_I18N_*, W_I18N_LANGS); gp qa plays the longest language',
    sources: [
      s('Starsilk', 'Ера', '2026-10-02', 'Поддержка многих языков'),
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Русский и испанский, выбор флагом в главном меню'),
      s('Dread Throne', 'не указан', '2026-10-02', 'Русский язык и смена языков русский/английский'),
      s('Nimbus Drift', 'Свин', '2026-10-10', 'Добавить фоновую музыку, сделать ползунок громкости в настройках, добавить локализацию языков в том числе русский.  Добавить больше уровней и глав, в каждой главе сделать свои виды препятствий, свои виды растений и внешний вид самой площадки. Сделать  10 актов в каждом по 30 уровней.'),
    ],
  },
  {
    id: 'bugs',
    flaw: 'Broken things a player meets: an item that does nothing, an enemy that freezes, effects that hang',
    look: 'Use every item, ability and enemy at least once; leave effects running through a pause and a menu',
    fix: 'A unit test per item effect, the bot plays every item; clear timers and effects when an enemy dies or a screen changes',
    measured: 'gp qa: console errors, the host contract; the balance model: a purchase that adds nothing fails',
    sources: [
      s('Secret House Tycoon', 'Свин', '2026-10-10', 'В задании дня при покраске стены а после смене цвета меняется цвет уже того что покрасил, но надо сделать так, что бы при смене цвета неообходимо было заного красить стену, еще при покраске стены закрашивается вообще все кроме пола то есть окно лестница дверь пороги и тд, надо это исправить.'),
      s('Secret House Tycoon', 'Свин', '2026-10-10', 'При вьезде в первый дом после очистки невозможно было продать одну вещь из за того, что перед ней стоял кот и я просто не мог нажать для продажи, надо исправить.'),
      s('Candle Crypt', 'Жаслан, Свин', '2026-10-02', 'Свитки сломаны'),
      s('Starsilk', 'Ера', '2026-10-02', 'Баг: враг с большой звездой зависает (эффекты, звуки, надписи)'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'После исчезновения сундука от него остается тень надо исправить.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'При использовании туманного шага прямо в стену можно застрять в стене без возможности выбраться надо исправить.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Торговец за воск иногда появляется без товара нужно сделать так что бы товар был всегда.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'Если скинуть активный предмет зажатием клавиши ctrl его потом будет невозможно подобрать, он будет постоянно сбрасывать его при поднятии, надо исправить.'),
      s('Candle Crypt', 'Свин', '2026-10-10', 'При игре за свечу монаха во 2 подземелье пропало одно из оружий просто исчезло надо так же исправить.'),
    ],
  },
];

/** The lessons as the review brief's section: a table the reviewer goes through, with who said it */
export function lessonsSection(): string[] {
  const L: string[] = [
    '## Lessons from the people who judged our games',
    '',
    `What reviewers, the owner and a contest jury told off our games for, ${LESSONS.reduce((n, l) => n + l.sources.length, 0)} remarks in ${LESSONS.length} lessons (packages/cli/src/lessons.ts; \`gp lessons\` prints the remarks verbatim). Go through each: if this game has the flaw plainly — a juror would say it in the first 10 minutes — it is \`[blocking]\`; if it is there but mild, \`[nice]\`; if not, nothing. "Measured" says what gp already checks: judge the rest.`,
    '',
    '| # | Flaw | How to see it | The usual fix | Measured | Said of |',
    '|---|---|---|---|---|---|',
  ];
  LESSONS.forEach((l, i) => {
    const games = [...new Set(l.sources.map((x) => x.game))];
    L.push(`| ${i + 1} | ${l.flaw} | ${l.look} | ${l.fix} | ${l.measured ?? '— (yours)'} | ${games.join(', ')} (${l.sources.length}) |`);
  });
  L.push('');
  return L;
}

/** `gp lessons`: every lesson with its remarks verbatim */
export function lessonsMarkdown(): string {
  const L: string[] = ['# Lessons from the people who judged our games', ''];
  for (const l of LESSONS) {
    L.push(`## ${l.flaw}`, '', `- **How to see it:** ${l.look}`, `- **The usual fix:** ${l.fix}`, ...(l.measured ? [`- **gp measures:** ${l.measured}`] : []), '- **Said:**');
    for (const x of l.sources) L.push(`  - ${x.game} — ${x.who}, ${x.date}: «${x.text}»`);
    L.push('');
  }
  return L.join('\n');
}
