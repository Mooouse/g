// Previews: the portal upload published where reviewers can play it before (and between) portal submissions.
// `gp preview <game> --to <dir>` builds the CrazyGames upload and copies it to <dir>/<id>/index.html — a checkout of
// the previews repository (GitHub Pages: https://<owner>.github.io/game-previews/<id>/, a stable URL per game).
// Outside CrazyGames the portal SDK reports 'disabled' and the game runs as a plain web build, without ads.
// <dir>/games.json lists every game; <dir>/index.html is rendered from it.

import { copyFileSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { ResolvedGame } from '@gp/spec';
import { buildPortal } from './portal-build.ts';
import type { GameLocation } from './paths.ts';

export interface PreviewEntry {
  id: string;
  title: string;
  /** game.yaml version.name: the patch this preview is */
  version?: string;
  /** ISO time of this publish */
  updated: string;
  /** The game's commit, when its folder is a git checkout */
  commit?: string;
  gzipKB?: number;
  /** cover.png sits next to index.html */
  cover?: boolean;
}

/** Entries the same game left under another id: a `gp rename`d game (same title, its old id) */
export function renamedFrom(list: PreviewEntry[], e: PreviewEntry): string[] {
  const t = e.title.trim().toLowerCase();
  return list.filter((x) => x.id !== e.id && x.title.trim().toLowerCase() === t).map((x) => x.id);
}

/** The list with `e` put in place of its old entry (or added) — and of the entries it left under an old id — newest first */
export function upsertPreview(list: PreviewEntry[], e: PreviewEntry): PreviewEntry[] {
  const old = new Set([e.id, ...renamedFrom(list, e)]);
  return [e, ...list.filter((x) => !old.has(x.id))].sort((a, b) => b.updated.localeCompare(a.updated));
}

/** What stays at an old preview link: a redirect to the new one (links already sent to reviewers keep working) */
export function redirectPage(to: string, title: string): string {
  return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=../${esc(to)}/">
<link rel="canonical" href="../${esc(to)}/"><title>${esc(title)}</title></head>
<body><a href="../${esc(to)}/">${esc(title)}</a></body></html>
`;
}

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!);

/** The previews' front page: one card per game, linking to <id>/ */
export function previewIndex(list: PreviewEntry[]): string {
  const cards = list
    .map((e) => {
      const img = e.cover ? `<img src="${esc(e.id)}/cover.png" alt="" loading="lazy">` : '';
      const meta = [e.version ? `v${e.version}` : '', e.updated.slice(0, 16).replace('T', ' ') + ' UTC', e.commit?.slice(0, 7), e.gzipKB != null ? `${e.gzipKB} KB gz` : '']
        .filter(Boolean)
        .join(' · ');
      return `<a class="card" href="${esc(e.id)}/">${img}<b>${esc(e.title)}</b><small>${esc(e.id)} · ${esc(meta)}</small></a>`;
    })
    .join('\n');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Game previews</title>
<style>
:root{color-scheme:light dark;--bg:#f6f6f4;--fg:#1d1d1b;--card:#fff;--mute:#6b6b66}
@media (prefers-color-scheme:dark){:root{--bg:#141413;--fg:#ececea;--card:#22221f;--mute:#9a9a94}}
body{margin:0;padding:24px 16px;background:var(--bg);color:var(--fg);font:16px/1.4 system-ui,sans-serif}
h1{font-size:22px;margin:0 0 4px}p{color:var(--mute);margin:0 0 20px}
.grid{display:grid;gap:14px;grid-template-columns:repeat(auto-fill,minmax(240px,1fr))}
.card{display:flex;flex-direction:column;gap:4px;padding:10px;border-radius:10px;background:var(--card);color:inherit;text-decoration:none}
.card img{width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:6px}.card small{color:var(--mute)}
</style></head><body>
<h1>Game previews</h1><p>The build that goes to CrazyGames, playable here without ads. Each game keeps its link.</p>
<div class="grid">
${cards}
</div></body></html>
`;
}

export interface PreviewResult {
  ok: boolean;
  problems: string[];
  url: string;
  entry?: PreviewEntry;
  /** Old ids of this game whose links now redirect here */
  renamed?: string[];
}

/** Build the upload and publish it into `to` (a checkout of the previews repository; committing is the caller's) */
export async function publishPreview(loc: GameLocation, game: ResolvedGame, to: string, commit?: string): Promise<PreviewResult> {
  const pkg = await buildPortal(loc, game);
  const url = `${game.id}/`;
  if (pkg.problems.length) return { ok: false, problems: pkg.problems, url };
  const dir = join(to, game.id);
  mkdirSync(dir, { recursive: true });
  copyFileSync(pkg.file, join(dir, 'index.html'));
  const cover = join(loc.dir, 'store', 'cover-1920x1080.png');
  if (existsSync(cover)) copyFileSync(cover, join(dir, 'cover.png'));
  const entry: PreviewEntry = {
    id: game.id,
    title: game.title,
    version: game.version.name,
    updated: new Date().toISOString(),
    ...(commit ? { commit } : {}),
    gzipKB: Math.round(pkg.size.gzipBytes / 1024),
    cover: existsSync(join(dir, 'cover.png')),
  };
  const listFile = join(to, 'games.json');
  const list = existsSync(listFile) ? (JSON.parse(readFileSync(listFile, 'utf8')) as PreviewEntry[]) : [];
  // A renamed game's old link: only a redirect stays there
  const renamed = renamedFrom(list, entry);
  for (const old of renamed) {
    rmSync(join(to, old), { recursive: true, force: true });
    mkdirSync(join(to, old), { recursive: true });
    writeFileSync(join(to, old, 'index.html'), redirectPage(game.id, game.title));
  }
  const next = upsertPreview(list, entry);
  writeFileSync(listFile, JSON.stringify(next, null, 2) + '\n');
  writeFileSync(join(to, 'index.html'), previewIndex(next));
  writeFileSync(join(to, '.nojekyll'), '');
  return { ok: true, problems: [], url, entry, renamed };
}
