// Asset chapters (game.yaml art.assets[].chapter; docs/guides/art.md#52-chapters-what-loads-before-play): a later chapter's
// image is imported as `./car40.webp?gp-chapter=1` (gp art writes assets/index.ts so). It is never inlined into the
// game's script:
// - `gp dev` (and QA's dev server): its URL, fetched when the game first needs it;
// - a build: a file of its own, dist/chapters/<n>/<name>, and the module is that relative path — a multi-file build
//   (web, Android) fetches it after Play;
// - the one-file portal upload (gp build --target crazygames | playgama | idos): inlineBuild folds those files into data
//   blocks at the very end of index.html, `<script type="application/octet-stream" data-gp-asset="chapters/1/car40.webp"
//   …>base64</script>`, and moves the game's script, `async`, in front of them. The browser runs the game as soon as the
//   script has arrived, while the blocks still stream in; @gp/art/assets (assetSource) reads a block by its path when the
//   game asks for that image. Measured: docs/guides/code-games.md#asset-chapters-what-play-waits-for.

import { readFileSync } from 'node:fs';
import { basename, extname } from 'node:path';
import type { Plugin } from 'vite';

/** The import query that puts an image into a later chapter */
export const CHAPTER_QUERY = 'gp-chapter';
/** Where a build writes the later chapters' files (relative to index.html) */
export const CHAPTER_DIR = 'chapters';
const VIRTUAL = '\0gp-chapter:';

export const MIME: Record<string, string> = { '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.avif': 'image/avif' };
export const mimeOf = (file: string) => MIME[extname(file).toLowerCase()] ?? 'application/octet-stream';

/** The chapter an import asks for (`?gp-chapter=1`), or null */
export function chapterOfImport(source: string): number | null {
  const m = new RegExp(`[?&]${CHAPTER_QUERY}=(\\d+)(?:&|$)`).exec(source);
  return m ? Number(m[1]) : null;
}

export function gpChapters(): Plugin {
  let serve = false;
  /** file → its published path, and the paths taken (two files of one name in a chapter get -2, -3 …) */
  const published = new Map<string, string>();
  const taken = new Set<string>();
  const publish = (chapter: number, file: string) => {
    const key = `${chapter}:${file}`;
    const known = published.get(key);
    if (known) return known;
    const ext = extname(file);
    const stem = basename(file, ext);
    let path = `${CHAPTER_DIR}/${chapter}/${stem}${ext}`;
    for (let i = 2; taken.has(path); i++) path = `${CHAPTER_DIR}/${chapter}/${stem}-${i}${ext}`;
    taken.add(path);
    published.set(key, path);
    return path;
  };
  return {
    name: 'gp-chapters',
    // Before Vite's own asset plugin, which would inline the image into the script
    enforce: 'pre',
    configResolved(c) {
      serve = c.command === 'serve';
    },
    buildStart() {
      published.clear();
      taken.clear();
    },
    async resolveId(source, importer) {
      const chapter = chapterOfImport(source);
      if (chapter === null) return null;
      const r = await this.resolve(source.replace(/\?.*$/, ''), importer, { skipSelf: true });
      if (!r) return null;
      // The dev server: the file's URL (Vite's ?url), fetched when the game first needs it
      if (serve) return `${r.id}?url`;
      return `${VIRTUAL}${chapter}:${r.id}`;
    },
    load(id) {
      if (!id.startsWith(VIRTUAL)) return null;
      const rest = id.slice(VIRTUAL.length);
      const at = rest.indexOf(':');
      const chapter = Number(rest.slice(0, at));
      const file = rest.slice(at + 1);
      const path = publish(chapter, file);
      this.emitFile({ type: 'asset', fileName: path, source: readFileSync(file) });
      return `export default ${JSON.stringify(path)};`;
    },
  };
}

export interface ChapterFile {
  /** The published path, relative to index.html: chapters/<n>/<name> */
  path: string;
  chapter: number;
  data: Buffer;
}

/** A published path → its chapter (chapters/<n>/…), or null */
export function chapterOfPath(path: string): number | null {
  const m = new RegExp(`^${CHAPTER_DIR}/(\\d+)/[^/]+$`).exec(path);
  return m ? Number(m[1]) : null;
}

const attr = (s: string) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');

/** One later-chapter image as the data block @gp/art/assets reads (its base64 length in data-n: a block still arriving is shorter) */
export function chapterBlock(f: ChapterFile): string {
  const b64 = f.data.toString('base64');
  return `<script type="application/octet-stream" data-gp-asset="${attr(f.path)}" data-gp-chapter="${f.chapter}" data-type="${mimeOf(f.path)}" data-n="${b64.length}">${b64}</script>`;
}

/**
 * The one-file page with asset chapters: the game's script (inlined, `<script type="module">…</script>`) taken out of
 * wherever it was and put, `async`, at the end of the body, followed by every later chapter's data blocks in chapter
 * order. An inline module script without `async` waits for the whole document — all the chapters — before it runs.
 */
export function foldChapters(html: string, script: string, files: ChapterFile[]): string {
  const blocks = [...files].sort((a, b) => a.chapter - b.chapter || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0)).map(chapterBlock).join('\n');
  const tail = `${script.replace(/^<script type="module">/, '<script type="module" async>')}\n${blocks}\n`;
  const at = html.lastIndexOf('</body>');
  return at < 0 ? html + tail : html.slice(0, at) + tail + html.slice(at);
}
