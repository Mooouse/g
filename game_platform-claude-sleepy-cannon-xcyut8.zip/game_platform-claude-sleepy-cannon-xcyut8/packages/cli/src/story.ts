// A game's story file: loading it, the checks `gp validate` adds for it, and `gp story` (how much story the game needs,
// a starting file for that depth, and what to correct). The table and the checks are data in @gp/spec
// (story-depth.ts); this file only reads the game's files. docs/guides/story.md
//
// The story file contract: data only, loaded by Node with type stripping (`import type` from @gp/core, no values; a
// relative import without an extension is resolved to .ts). Its exports are sorted by shape:
//   export const STORY: StoryDef                       chapters and branching (checked in full with validateStory)
//   export const BARKS = { event: ['line', …] }        barks (any export that is a string list, or a map of them)
//   export const CAST = { id: { name } }               characters, when there is no StoryDef
// anything else is the game's own format: its words are counted. A .json file holds the same keys (or a StoryDef).

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { createRequire, registerHooks } from 'node:module';
import { basename, join, relative } from 'node:path';
import {
  AUDIENCES,
  DEPTH_INFO,
  STORY_DEPTHS,
  allowedDepths,
  checkStoryContent,
  checkStorySection,
  contentDepth,
  depthOrder,
  describeContent,
  isStoryDef,
  metaWarning,
  readStoryExports,
  storyFit,
  storyGenre,
  type GameSpecInput,
  type Issue,
  type ResolvedGame,
  type StoryContent,
  type StoryDepth,
  type StoryFit,
  type StoryGenre,
} from '@gp/spec';
import { storyStrings } from '@gp/core/story';
import { parseDocument } from 'yaml';
import { loadStrings, stringsDir } from './i18n.ts';
import type { GameLocation } from './paths.ts';

let hooked = false;
/** Whether the hooks are on (Node 22.15+) */
let registered = false;
let loads = 0;
/** The fresh name a load gives a file (`story.gp-load-3.ts`) → the file on disk */
const onDisk = new Map<string, string>();
const FRESH = /^(.*)\0gp-load-(\d+)$/;
const freshName = (url: string, n: string): string => {
  const v = url.replace(/(\.[cm]?[jt]sx?|\.json)?$/, (ext) => `.gp-load-${n}${ext}`);
  onDisk.set(v, url);
  return v;
};

/**
 * Two resolve hooks for story files: `./data` → `./data.ts` (files written for a bundler), and a fresh module for every
 * load. Node caches a module by its file name, and an ESM story file (every one: `export const`) stays in the ESM
 * loader's cache even without its require.cache entry — so `gp story --write --force` reported on the file it had just
 * replaced. Each load asks for `<file>\0gp-load-<n>`: the file and the game's own files it imports get a name of that
 * load (`story.gp-load-<n>.ts`, read from the file on disk), packages stay shared.
 */
function hookExtensions(): void {
  if (hooked) return;
  hooked = true;
  try {
    registerHooks({
      resolve(spec, ctx, next) {
        const fresh = FRESH.exec(spec);
        const r = (() => {
          const s = fresh ? fresh[1] : spec;
          try {
            return next(s, ctx);
          } catch (e) {
            if (/^\.\.?\//.test(s) && !/\.[cm]?[jt]sx?$|\.json$/.test(s))
              for (const ext of ['.ts', '/index.ts'])
                try {
                  return next(s + ext, ctx);
                } catch {
                  // try the next one
                }
            throw e;
          }
        })();
        if (fresh) return { ...r, url: freshName(r.url, fresh[2]), shortCircuit: true };
        // An import of a freshly loaded file: the game's own files load fresh with it
        const parent = ctx.parentURL && onDisk.has(ctx.parentURL) ? /\.gp-load-(\d+)\.[cm]?[jt]sx?$/.exec(ctx.parentURL) : null;
        if (parent && r.url.startsWith('file:') && !r.url.includes('/node_modules/') && /\.[cm]?[jt]sx?$/.test(r.url))
          return { ...r, url: freshName(r.url, parent[1]), shortCircuit: true };
        return r;
      },
      load(url, ctx, next) {
        const file = onDisk.get(url);
        return file ? { ...next(file, ctx), shortCircuit: true } : next(url, ctx);
      },
    });
    registered = true;
  } catch {
    // an older Node: story files then need explicit .ts extensions (and a changed file is seen on the next run)
  }
}

/** The story file's exports, or why they can't be read */
export function loadStoryFile(file: string): { exports: Record<string, unknown> } | { error: string } {
  if (!existsSync(file) || !statSync(file).isFile()) return { error: 'no such file' };
  try {
    if (file.endsWith('.json')) {
      const data = JSON.parse(readFileSync(file, 'utf8')) as unknown;
      return { exports: isStoryDef(data) ? { STORY: data } : (data as Record<string, unknown>) };
    }
    hookExtensions();
    // A fresh load every time (see hookExtensions): the file as it is on disk now, not as an earlier load saw it
    return { exports: { ...(createRequire(import.meta.url)(registered ? `${file}\0gp-load-${++loads}` : file) as Record<string, unknown>) } };
  } catch (e) {
    return { error: (e as Error).message.split('\n')[0].replace(/\.gp-load-\d+/g, '') };
  }
}

/** A path as messages show it: relative to the game folder when it is inside it */
const shownIn = (loc: GameLocation, abs: string): string => {
  const r = relative(loc.dir, abs);
  return r && !r.startsWith('..') ? r : abs;
};

const gameCode = (loc: GameLocation, except: string[] = []): string[] =>
  existsSync(loc.dir) ? readdirSync(loc.dir).filter((f) => /\.(ts|mjs)$/.test(f) && !f.endsWith('.test.ts') && !f.endsWith('.d.ts') && !except.includes(f)) : [];

/** The @gp/core blocks that keep progress between runs: upgrades.ts, shop-ui.ts, progression.ts */
const META_BLOCKS = ['UpgradeShop', 'mountUpgradeShop', 'Roster', 'Tiers', 'PactTree', 'RunChoices'];

/** Whether a code game has meta progression (upgrades, unlocks between runs): chapters are a reward in it */
export function detectMeta(loc: GameLocation, kit: string): { meta: boolean; why: string } {
  if (kit !== 'code') return { meta: false, why: `kit ${kit} has no meta progression` };
  for (const f of gameCode(loc)) {
    const block = metaBlockIn(readFileSync(join(loc.dir, f), 'utf8'));
    if (block) return { meta: true, why: `${block} in ${f}` };
  }
  const named = gameCode(loc).find((f) => /^(meta|upgrades?|shop|progress(ion)?|unlocks?|prestige)\.ts$/.test(f));
  if (named) return { meta: true, why: named };
  return { meta: false, why: `no ${META_BLOCKS.join('/')} and no meta/upgrades/shop file` };
}

/** Source without its comments (a URL's `//` in a string stays), so a comment naming a block doesn't count */
const stripComments = (src: string): string => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:\\])\/\/.*$/gm, '$1');

/** The first meta progression block the code uses: `new Roster(…)`, `mountUpgradeShop(…)` or a value import of one */
export function metaBlockIn(src: string): string | null {
  const code = stripComments(src);
  const names = META_BLOCKS.join('|');
  const used = new RegExp(`\\bnew\\s+(${names})\\b|\\b(mountUpgradeShop)\\s*\\(`).exec(code);
  if (used) return used[1] ?? used[2];
  // A value import (not `import type`, not `type Roster` inside the braces): the game builds it somewhere else
  for (const m of code.matchAll(/\bimport\s+(type\s+)?\{([^}]*)\}\s*from/g)) {
    if (m[1]) continue;
    for (const part of m[2].split(',')) {
      const name = part.trim().split(/\s+as\s+/)[0];
      if (META_BLOCKS.includes(name)) return name;
    }
  }
  return null;
}

export interface StoryFileCheck {
  issues: Issue[];
  content: StoryContent | null;
}

/** The story file against its depth, and (code games) whether QA can find a Skip on the scenes */
export function checkStoryFile(loc: GameLocation, o: { file: string; depth: StoryDepth; audience: string; fit: StoryFit; kit: string }): StoryFileCheck {
  const abs = join(loc.dir, o.file);
  const shown = shownIn(loc, abs);
  const loaded = loadStoryFile(abs);
  if ('error' in loaded)
    return {
      content: null,
      issues: [
        {
          code: 'E_STORY_FILE',
          severity: 'error',
          path: ['story', 'file'],
          message: loaded.error === 'no such file' ? `story.file: ${shown} does not exist` : `story.file: ${shown} can't be loaded: ${loaded.error}`,
          fix: loaded.error === 'no such file' ? `Run \`gp story --write\` to form it for depth ${o.depth}, or fix the path.` : 'Keep the story file data only: `import type` from @gp/core, no values (the Bag goes in main.ts); or use a .json file.',
        },
      ],
    };
  const content = readStoryExports(loaded.exports);
  const issues = checkStoryContent(content, { depth: o.depth, audience: AUDIENCES[o.audience] ?? AUDIENCES.general, fit: o.fit, file: shown });
  if (o.kit === 'code' && depthOrder(o.depth) >= depthOrder('chapters')) {
    const code = gameCode(loc, [basename(abs)]).map((f) => readFileSync(join(loc.dir, f), 'utf8')).join('\n');
    if (!/\bmountDialogue\b|dialog-skip/.test(code))
      issues.push({ code: 'W_STORY_SKIP', severity: 'warning', path: ['story', 'file'], message: 'the story has scenes, but the game uses neither mountDialogue nor a data-gp="dialog-skip" button: QA can\'t find Skip', fix: 'Show scenes with mountDialogue (Skip is always there), or put data-gp="dialog" and data-gp="dialog-skip" on your own scene screen.' });
  }
  return { issues, content };
}

// --- The story in the player's language: its texts as strings/en.yaml keys ---------------------------------------

/** The story file's texts as strings keys → English: story.<line id>, story.<line id>.<choice id>, bark.<event>.<n> */
export function storyKeysOf(content: StoryContent): Record<string, string> {
  // BARKS = { event: [...] } → bark.<event>.<n>; another list keeps its export name (KING_BARKS.wave → bark.KING_BARKS.wave.<n>)
  const barks = Object.fromEntries(content.barks.map((b) => [b.name.replace(/^BARKS\./, ''), b.lines]));
  return storyStrings(content.def, barks);
}

const isStoryKey = (k: string) => k.startsWith('story.') || k.startsWith('bark.');

/** strings/en.yaml's text with the story's keys: every old story.* / bark.* key replaced by `keys` (flat dotted keys) */
export function withStoryStrings(enText: string, keys: Record<string, string>): string {
  const doc = parseDocument(enText || '{}');
  if (doc.contents && 'items' in doc.contents)
    for (const it of [...(doc.contents as { items: { key: unknown }[] }).items]) {
      const k = String((it.key as { value?: unknown })?.value ?? it.key);
      if (k === 'story' || k === 'bark' || isStoryKey(k)) doc.delete(k);
    }
  for (const [k, v] of Object.entries(keys)) doc.set(k, v);
  return doc.toString({ lineWidth: 0 });
}

/**
 * `gp story --strings`: the story file's texts into strings/en.yaml, so `gp translate` lists them for every language and
 * StoryRunner(…, { i18n: host.i18n }) / barkText() show them in the player's language (Swarm Smash kept a hand-made copy
 * in step with a test). Returns how many keys, or why not
 */
export function writeStoryStrings(loc: GameLocation, file: string, write: (file: string, text: string) => void): { keys: number; file: string } | { error: string } {
  const loaded = loadStoryFile(join(loc.dir, file));
  if ('error' in loaded) return { error: `${file}: ${loaded.error}` };
  const keys = storyKeysOf(readStoryExports(loaded.exports));
  if (!Object.keys(keys).length) return { error: `${file} has no lines, choices or barks` };
  const en = join(stringsDir(loc), 'en.yaml');
  write(en, withStoryStrings(existsSync(en) ? readFileSync(en, 'utf8') : '', keys));
  return { keys: Object.keys(keys).length, file: en };
}

/**
 * The story's keys in strings/en.yaml against the story file: once a game has put them there (gp story --strings), every
 * line, choice and bark must be there with the file's English (W_STORY_STRINGS); a story in a game of several languages
 * without them is told how (I_STORY_STRINGS)
 */
export function storyStringsChecks(loc: GameLocation, content: StoryContent, languages: readonly string[]): Issue[] {
  const keys = storyKeysOf(content);
  const n = Object.keys(keys).length;
  if (!n) return [];
  const en = loadStrings(loc).strings.en ?? {};
  const have = Object.keys(en).filter(isStoryKey);
  if (!have.length)
    return languages.length > 1
      ? [{ code: 'I_STORY_STRINGS', severity: 'info', path: ['story', 'file'], message: `the story's ${n} texts are English only: the game has ${languages.length} languages`, fix: 'Run `gp story --strings` (it writes them into strings/en.yaml as story.* and bark.* keys), then `gp translate`; show them with new StoryRunner(…, { i18n: host.i18n }) and barkText(host.i18n, event, i, line) (docs/guides/story.md).' }]
      : [];
  const missing = Object.keys(keys).filter((k) => en[k] === undefined);
  const changed = Object.keys(keys).filter((k) => typeof en[k] === 'string' && en[k] !== keys[k]);
  const stale = have.filter((k) => !(k in keys));
  if (!missing.length && !changed.length && !stale.length) return [];
  const list = (what: string, ks: string[]) => (ks.length ? [`${ks.length} ${what} (${ks.slice(0, 3).join(', ')}${ks.length > 3 ? ' …' : ''})`] : []);
  return [
    {
      code: 'W_STORY_STRINGS',
      severity: 'warning',
      path: ['story', 'file'],
      message: `strings/en.yaml is out of step with the story file: ${[...list('missing', missing), ...list('changed', changed), ...list('no longer in the story', stale)].join('; ')}`,
      fix: 'Run `gp story --strings` again (it rewrites the story.* and bark.* keys from the story file), then `gp translate`: the changed lines show as stale translations.',
    },
  ];
}

/** The story checks `gp validate` adds to a resolved game: its story file, and meta progression for chapters */
export function storyFileChecks(loc: GameLocation, game: ResolvedGame): Issue[] {
  const s = game.story;
  if (!s || s.depth === 'none') return [];
  const { fit } = storyFit({ audience: game.audience.id, kit: game.kit.kit, genre: s.genre ?? undefined });
  const issues: Issue[] = [];
  if (game.kit.kit === 'code') {
    const m = detectMeta(loc, 'code');
    const w = metaWarning(fit, s.depth, m.meta, m.why);
    if (w) issues.push({ code: 'W_STORY_DEPTH', severity: 'warning', path: ['story', 'depth'], ...w });
  }
  if (s.file) {
    const checked = checkStoryFile(loc, { file: s.file, depth: s.depth, audience: game.audience.id, fit, kit: game.kit.kit });
    issues.push(...checked.issues);
    if (checked.content && game.kit.kit === 'code') issues.push(...storyStringsChecks(loc, checked.content, game.languages));
  }
  return issues;
}

/** What the game's story file holds (the declared one, else story.ts when it exists), for the uniqueness score */
export function storyContentOf(loc: GameLocation, game: ResolvedGame): StoryContent | null {
  const file = game.story?.file ?? (existsSync(join(loc.dir, 'story.ts')) ? 'story.ts' : null);
  if (!file) return null;
  const loaded = loadStoryFile(join(loc.dir, file));
  return 'error' in loaded ? null : readStoryExports(loaded.exports);
}

// --- Forming: a starting story file for a depth ---------------------------------------------------------------------

interface FormInput {
  title: string;
  pitch: string | null;
  different: string | null;
  twist: string | null;
  voiced: boolean;
  audience: string;
}

const tsString = (s: string) => `'${s.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
const wrap = (s: string, prefix: string, width = 116): string[] => {
  const out: string[] = [];
  let line = '';
  for (const w of s.split(/\s+/)) {
    if ((line + ' ' + w).trim().length > width - prefix.length && line) {
      out.push(prefix + line);
      line = w;
    } else line = (line + ' ' + w).trim();
  }
  if (line) out.push(prefix + line);
  return out;
};

function header(f: FormInput, depth: StoryDepth): string[] {
  return [
    `// ${f.title}: the story as data, formed by \`gp story\` for depth "${depth}" (docs/guides/story.md). Replace every TODO,`,
    '// then run `gp story` again: it says what is left to correct (the same checks as `gp validate`).',
    ...(f.pitch ? ['//', ...wrap(`The pitch: ${f.pitch}`, '// ')] : []),
    ...(f.different ? wrap(`What is different: ${f.different}`, '// ') : []),
    '// The premise (game.yaml `story.premise`): one line, who wants what and why. Characters with a face and a voice carry',
    '// the rest; players who read less stay longer, so keep every line short.',
    ...(f.voiced ? ['// Every line is spoken (TTS or audio), and `story.voiced: true` says so: this audience reads slowly or not at all.'] : []),
    '// Keep this file data only (`import type`, no values): `gp validate` loads it to check it.',
  ];
}

function barksBlock(f: FormInput, compact: boolean): string[] {
  const events: [string, string][] = [
    ['run-start', 'a run starts'],
    [f.twist ?? 'twist', f.twist ? `the twist happens (where the game calls host.twist('${f.twist}'))` : 'the twist happens'],
    ['good', 'a good moment: a combo, a big hit, a new best'],
    ['bad', 'hurt, a miss, a close call'],
    ['idle', 'the player waits a few seconds'],
    ['run-end', 'the run is over'],
  ];
  const n = compact ? 2 : 3;
  return [
    '',
    '// Barks: a character reacts to what just happened, in a bubble, ≤ 60 characters, for about 3 s. Never a blocking scene',
    '// during play. In main.ts, one Bag per event (no repeats until all are used) and a cooldown (≥ 5 s apart):',
    '//',
    "//   import { Bag, barkText } from '@gp/core';",
    "//   import { BARKS, type BarkEvent } from './story';",
    '//   const bags = new Map<BarkEvent, Bag>();',
    '//   let barkCooldown = 0; // seconds: barkCooldown = Math.max(0, barkCooldown - dt) in your update',
    '//   function bark(event: BarkEvent, force = false): void {',
    '//     if (!force && barkCooldown > 0) return;',
    '//     let bag = bags.get(event);',
    '//     if (!bag) bags.set(event, (bag = new Bag(BARKS[event].length)));',
    '//     const i = bag.next();',
    "//     bubble.say(barkText(host.i18n, event, i, BARKS[event][i])); // your speech bubble, in the player's language",
    '//     // (`gp story --strings` puts the lines into strings/en.yaml; `gp translate` then lists them for every language)',
    '//     barkCooldown = 6;',
    '//   }',
    '',
    `/** Event → lines. ${compact ? 'A few to start; ' : ''}50–200 in all: a few per event, more for the ones that happen often */`,
    'export const BARKS = {',
    ...events.map(([e, what]) => `  ${/^[a-z][a-zA-Z0-9]*$/.test(e) ? e : tsString(e)}: [${['TODO: a line', 'TODO: another', 'TODO: a third'].slice(0, n).map(tsString).join(', ')}], // ${what}`),
    '} as const;',
    'export type BarkEvent = keyof typeof BARKS;',
  ];
}

/** The text of a starting story file for a depth (barks, chapters or branching) */
export function formStory(depth: StoryDepth, f: FormInput): string {
  if (depth === 'barks')
    return [
      ...header(f, depth),
      '',
      '/** Who talks: a name and a colour for the bubble */',
      'export const CAST = {',
      "  guide: { name: 'TODO: the character who talks', color: '#e0a526' },",
      '};',
      ...barksBlock(f, false),
      '',
    ].join('\n');
  const branching = depth === 'branching';
  const chapter = (n: number, lines: string[], extra = '') =>
    [`    ch${n}: {`, `      title: 'Chapter ${n} · TODO',`, "      at: 'run-end',", `      when: 'cleared >= ${n}',`, ...(extra ? [extra] : []), '      lines: [', ...lines.map((l) => `        ${l},`), '      ],', '    },'];
  const plain = (n: number) => chapter(n, [tsString(`hero: TODO: what the hero says after ${n === 1 ? 'the first run' : `run ${n}`}`), tsString('friend/worried: TODO: what is at stake now'), tsString('hero/happy: TODO: the promise of the next reveal')]);
  const scenes: string[] = [
    '    // After the first core action: the premise in one line (≤ 20 words), then play at once',
    "    premise: { at: 'first-action', lines: ['hero: TODO: the premise in one line.'] },",
    '    // One chapter after each cleared run or stage, as a reward at a break (never mid-action). At most 8 lines, ≤ 120 words.',
    ...(branching ? [] : [1, 2, 3, 4, 5, 6].flatMap(plain)),
  ];
  if (branching)
    scenes.push(
      ...plain(1),
      ...chapter(2, [
        tsString('friend: TODO: a question that matters later'),
        `{\n          who: 'hero',\n          text: 'TODO: the moment to choose',\n          choose: [\n            { id: 'help', text: 'TODO: the kind answer', do: { set: 'helped' }, then: ['friend/happy: TODO: the reply'] },\n            { id: 'refuse', text: 'TODO: the hard answer', then: ['friend/worried: TODO: the reply'] },\n          ],\n        }`,
      ]),
      ...plain(3),
      ...chapter(4, ["{ who: 'friend', text: 'TODO: a line if the hero helped', if: 'helped' }", "{ who: 'friend', text: 'TODO: a line if the hero refused', if: 'not helped' }", tsString('hero: TODO: the stakes rise')]),
      ...plain(5),
      ...chapter(6, [tsString('hero: TODO: the finale'), "{ text: 'TODO: the ending where they stay together', if: 'helped', ending: 'together' }", "{ text: 'TODO: the ending where the hero goes on alone', if: 'not helped', ending: 'alone' }"]),
    );
  return [
    ...header(f, depth),
    '//',
    '// Chapters: short scenes unlocked by progress, played between runs (docs/guides/story.md §4 has the main.ts wiring:',
    '// loadStory, dueScene at your safe points only, StoryRunner, mountDialogue (Skip is always there), commitScene, the',
    '// state in your save). A scene between runs is not gameplay: call host.gameplay(false) before it.',
    ...(branching ? ['// Branching, cosmetic: a flag set by a choice colours later lines, and the finale has 2–3 endings.'] : []),
    '// Scene and choice ids are save data: never rename them after a release.',
    '',
    "import type { StoryDef } from '@gp/core';",
    '',
    'export const STORY: StoryDef = {',
    '  cast: {',
    "    hero: { name: 'TODO: the hero', color: '#e0a526' },",
    "    friend: { name: 'TODO: a second character', color: '#7b44b8' },",
    '  },',
    "  moods: ['neutral', 'happy', 'worried'],",
    "  // Game vars: your code passes { cleared } (runs won or stages cleared) at each check",
    "  vars: { game: ['cleared'] },",
    "  chapters: ['ch1', 'ch2', 'ch3', 'ch4', 'ch5', 'ch6'],",
    '  scenes: {',
    ...scenes,
    '  },',
    '};',
    ...barksBlock(f, true),
    '',
  ].join('\n');
}

// --- gp story -----------------------------------------------------------------------------------------------------

export interface StoryCommandResult {
  lines: string[];
  code: number;
  /** A file gp story wrote (absolute), and the game.yaml section it added */
  wrote: string | null;
  section: { depth: StoryDepth; premise?: string; file?: string } | null;
  json: Record<string, unknown>;
}

export interface StoryCommandOptions {
  depth?: string;
  genre?: string;
  write?: boolean;
  force?: boolean;
  /** Write the formed file here instead of into the game (game.yaml is left alone) */
  out?: string;
}

const CELL: Record<string, string> = { default: 'DEFAULT', yes: 'yes', max: 'at most', weak: 'fine, gains from more', no: 'no' };

/**
 * `gp story`: the depth this kind of game takes and why; a starting story file for a depth (with --write, or when the
 * declared file doesn't exist yet), never over an existing file without --force; then what to correct as a to-do list.
 */
export function storyCommand(loc: GameLocation, spec: GameSpecInput, o: StoryCommandOptions, writeFile: (file: string, text: string) => void): StoryCommandResult {
  const lines: string[] = [];
  const out = (s = '') => lines.push(s);
  const res: StoryCommandResult = { lines, code: 0, wrote: null, section: null, json: {} };
  if (o.depth !== undefined && !STORY_DEPTHS.includes(o.depth as StoryDepth)) {
    out(`--depth ${o.depth}: use one of ${STORY_DEPTHS.join(', ')}`);
    return { ...res, code: 1 };
  }
  const audience = AUDIENCES[spec.audience] ?? AUDIENCES.general;
  const kit = spec.kit ?? 'code';
  const declared = spec.story ?? null;
  const genreIn = (o.genre as StoryGenre | undefined) ?? declared?.genre;
  const input = { audience: audience.id, kit, mechanic: spec.round?.mechanic, tags: spec.listing?.tags, text: `${spec.title ?? ''} ${spec.concept?.pitch ?? ''}`, genre: genreIn };
  const { fit, recommended, genre } = storyFit(input);
  const meta = detectMeta(loc, kit);
  const g = genre ? storyGenre(input) : null;

  out(`${spec.title ?? loc.id} (${loc.id}): ${audience.id} · ${spec.channel} · kit ${kit}${g ? ` · genre ${g.genre} (from ${g.from})` : ''} · meta progression: ${meta.meta ? 'yes' : 'no'} (${meta.why})`);
  out(`Recommended depth: ${recommended.join(' or ')} — ${fit.title}`);
  for (const d of STORY_DEPTHS) out(`  ${d.padEnd(9)} ${CELL[fit.depths[d]].padEnd(21)} ${DEPTH_INFO[d].what}${fit.notes[d] ? ` — here: ${fit.notes[d]}` : ''}`);
  out(`Supported here: ${allowedDepths(fit, meta.meta).join(', ')}. A story multiplies a core loop that already works; it never rescues a weak one.`);
  out(declared ? `Declared: story: { depth: ${declared.depth}${declared.file ? `, file: ${declared.file}` : ''}${declared.premise ? ', premise' : ''} }` : 'Declared: no story section in game.yaml');
  res.json = { recommended, fit: fit.id, genre, meta: meta.meta, declared };

  if (declared?.depth === 'none' || o.depth === 'none') {
    out('\n✓ No story needed for this game (depth none).');
    return res;
  }
  const file = declared?.file ?? 'story.ts';
  const target = o.out ?? join(loc.dir, file);
  const exists = existsSync(target);
  const fileCheck = (f: string, d: StoryDepth) => checkStoryFile(loc, { file: relative(loc.dir, f) || f, depth: d, audience: audience.id, fit, kit });
  let depth: StoryDepth | null = (o.depth as StoryDepth | undefined) ?? declared?.depth ?? null;
  const existing = existsSync(join(loc.dir, file)) ? fileCheck(join(loc.dir, file), depth ?? 'chapters').content : null;
  if (!depth && existing) depth = contentDepth(existing);
  if (!depth) {
    if (!o.write) {
      out('');
      if (fit.depths.none === 'weak') out(`This kind of game gains from a story (${fit.notes.none}). \`gp story --write\` forms a starting file for depth ${recommended[0]}.`);
      else out(`✓ No story needed for this game: none is fine for ${fit.title.split(' (')[0]}. If you want one, ${recommended.join(' or ')} is the default here: \`gp story --write\` (or \`--depth <depth> --write\`).`);
      return res;
    }
    depth = recommended[0];
  }
  if (depth === 'none') {
    out('\n✓ No story needed for this game (depth none).');
    return res;
  }

  // Forming
  const form = depthOrder(depth) >= depthOrder('barks') && (o.write || (!!declared && !exists));
  const f: FormInput = { title: spec.title ?? loc.id, pitch: spec.concept?.pitch && !/TODO/.test(spec.concept.pitch) ? spec.concept.pitch : null, different: spec.concept?.different && !/TODO/.test(spec.concept.different) ? spec.concept.different : null, twist: spec.concept?.twist?.event ?? null, voiced: !!fit.voiced, audience: audience.id };
  out('');
  if (form) {
    if (exists && !o.force) {
      out(`✗ ${shownIn(loc, target)} exists: not overwritten (--force replaces it). The checks below are on the file as it is.`);
      if (o.write) res.code = 1;
    } else {
      writeFile(target, formStory(depth, f));
      res.wrote = target;
      out(`✓ wrote ${target} — a starting ${depth} file: ${depth === 'barks' ? '6 events of TODO barks, a cast' : `6 chapters of TODO lines${depth === 'branching' ? ', a choice that sets a flag, 2 endings' : ''}, a first-action premise, a few barks`}`);
    }
  }
  if (!declared && !o.out && (o.write || form)) {
    res.section = { depth, premise: 'TODO: one line — who wants what, and why', ...(depthOrder(depth) >= depthOrder('barks') ? { file } : {}) };
    out(`✓ game.yaml: story: { depth: ${depth}, premise: TODO${res.section.file ? `, file: ${file}` : ''} } — write the premise`);
  } else if (!declared && (existing || res.wrote))
    out(`game.yaml has no story section: ${o.out && res.wrote ? `copy the file into the game as ${file}, then ` : ''}add \`story: { depth: ${depth}, file: ${file} }\` so \`gp validate\` checks it.`);
  else if (declared && o.depth && o.depth !== declared.depth) out(`Note: game.yaml says depth ${declared.depth}; set \`story.depth: ${depth}\` if that is the decision.`);

  // Correcting: the section against the kind of game, the file against its depth
  const issues: Issue[] = [];
  const report = (severity: Issue['severity']) => (code: string, path: (string | number)[], message: string, fix: string) => issues.push({ code, severity, path, message, fix });
  const section = { ...(declared ?? {}), ...(res.section ?? {}), depth, genre: genreIn };
  // Not declared yet: check it as the section gp story suggests (the file it found or formed, a premise still to write)
  if (!declared) {
    if (existsSync(target) && depthOrder(depth) >= depthOrder('barks')) section.file = file;
    if (!section.premise && depth === 'premise') section.premise = 'TODO';
  }
  checkStorySection(section, input, audience, { err: report('error'), warn: report('warning'), info: report('info') }, meta.meta);
  const checked = existsSync(target) && depthOrder(depth) >= depthOrder('barks') ? fileCheck(target, depth) : null;
  if (checked) issues.push(...checked.issues);
  else if (depthOrder(depth) >= depthOrder('barks') && !form) issues.push({ code: 'E_STORY_FILE', severity: 'error', path: ['story', 'file'], message: `${file} does not exist`, fix: 'Run `gp story --write` to form it.' });
  if (depth === 'premise' && !declared?.premise && !res.section) out('A premise lives in game.yaml, not in a file: story: { depth: premise, premise: "<who> <wants what>, <because>" } (≤ 30 words).');
  if (checked?.content) out(`${shownIn(loc, target)}: ${describeContent(checked.content)}${checked.content.cast.length ? `; cast: ${checked.content.cast.slice(0, 6).join(', ')}` : ''}${checked.content.def ? '' : ' (no StoryDef)'}`);

  const order = { error: 0, warning: 1, info: 2 } as const;
  issues.sort((a, b) => order[a.severity] - order[b.severity]);
  out('');
  if (!issues.length) out(`✓ Nothing to correct for depth ${depth}.`);
  else {
    out(`To correct (${issues.length}):`);
    for (const i of issues) out(`  [ ] ${i.severity} ${i.code}  ${i.message}\n      fix: ${i.fix}`);
  }
  if (issues.some((i) => i.severity === 'error')) res.code = 1;
  res.json = { ...res.json, depth, wrote: res.wrote, content: checked?.content ? { ...checked.content, def: undefined } : null, issues };
  return res;
}
