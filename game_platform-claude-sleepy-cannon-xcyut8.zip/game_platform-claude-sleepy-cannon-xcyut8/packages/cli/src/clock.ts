// The virtual clock `gp video` films on, for any tool that needs a game to run on it: an engine benchmark, a test that a
// game's simulation follows the clock and only the clock (the engine lab's tools/measure.mjs had to copy it).
// Installed before the page's own scripts, it replaces requestAnimationFrame, setTimeout/setInterval, performance.now,
// Date.now and the page's CSS/Web Animations: nothing moves until the tool advances it. With Playwright:
//
//   import { advanceClock, virtualClock } from '@gp/cli/clock';   // or packages/cli/src/clock.ts of the platform
//   await page.addInitScript(virtualClock);
//   await page.goto(url);
//   await advanceClock(page, 1000 / 30);   // one 30 fps frame: due timers, animations, then the rAF callbacks
//
// The page starts at performance.now() = 0. A callback that throws is logged ("[gp video] a game callback threw") and
// the clock goes on. An advance runs the due timers in time order (an interval re-arms; a 0 ms timer counts as 1 ms, so
// one that re-arms itself can't spin), then moves the animations, then calls this frame's rAF callbacks with the new time.

import type { Page } from 'playwright';

/** Install with page.addInitScript(virtualClock): it runs in the page, so it stays self-contained */
export const virtualClock = (): void => {
  let now = 0;
  // requestAnimationFrame callbacks by id, so cancelAnimationFrame works (a loop that cancels and re-requests must not run twice)
  let raf = new Map<number, FrameRequestCallback>();
  let rid = 1;
  const timers: { id: number; t: number; every: number; fn: () => void }[] = [];
  let tid = 1;
  const seen = new WeakSet<Animation>();
  const w = window as unknown as Record<string, unknown>;
  const safe = (fn: () => void) => {
    try {
      fn();
    } catch (e) {
      console.error('[gp video] a game callback threw', e);
    }
  };
  performance.now = () => now;
  const t0 = Date.now();
  Date.now = () => t0 + now;
  window.requestAnimationFrame = (cb) => {
    const id = rid++;
    raf.set(id, cb);
    return id;
  };
  window.cancelAnimationFrame = (id) => void raf.delete(id);
  const add = (fn: unknown, ms: unknown, every: boolean, args: unknown[]) => {
    const id = tid++;
    // At least 1 ms: a timer that re-arms itself with 0 ms must not spin forever inside one advance
    const d = Math.max(1, Number(ms) || 0);
    timers.push({ id, t: now + d, every: every ? d : 0, fn: () => (typeof fn === 'function' ? fn(...args) : undefined) });
    return id;
  };
  const clear = (id: unknown) => {
    const i = timers.findIndex((t) => t.id === id);
    if (i >= 0) timers.splice(i, 1);
  };
  w.setTimeout = (fn: unknown, ms?: unknown, ...args: unknown[]) => add(fn, ms, false, args);
  w.setInterval = (fn: unknown, ms?: unknown, ...args: unknown[]) => add(fn, ms, true, args);
  w.clearTimeout = clear;
  w.clearInterval = clear;
  w.__gpAdvance = (ms: number) => {
    now += ms;
    for (;;) {
      timers.sort((a, b) => a.t - b.t);
      const t = timers[0];
      if (!t || t.t > now) break;
      if (t.every) t.t += t.every;
      else timers.shift();
      safe(t.fn);
    }
    for (const a of document.getAnimations()) {
      if (!seen.has(a)) {
        seen.add(a);
        a.pause();
        a.currentTime = 0;
      } else a.currentTime = (Number(a.currentTime) || 0) + ms;
    }
    const cbs = raf;
    raf = new Map();
    for (const cb of cbs.values()) safe(() => cb(now));
  };
};

/** Move the page's virtual clock by `ms` milliseconds (window.__gpAdvance) */
export async function advanceClock(page: Page, ms: number): Promise<void> {
  await page.evaluate((dt) => (window as unknown as { __gpAdvance: (ms: number) => void }).__gpAdvance(dt), ms);
}
