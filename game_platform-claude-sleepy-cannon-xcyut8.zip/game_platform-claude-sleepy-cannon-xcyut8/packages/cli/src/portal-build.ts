// Web portal package: the production build as ONE self-contained index.html, checked against the channel's limits.
// CrazyGames' upload form takes files, not archives ("Archive files are not supported, please drag and drop the files
// directly"), with index.html at the root. Petri Panic, Spin Brawl and Yeet the Gnome (QmaCyber/game2, game3, game4) each
// had to fold their build into one file by hand; this does it for every game, and `gp qa` plays that very file.

import { mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { CHANNELS, type ResolvedGame, type SizeReport } from '@gp/spec';
import { chapterOfPath, foldChapters, type ChapterFile } from './chapters.ts';
import type { GameLocation } from './paths.ts';
import { sizeReport } from './size.ts';
import type { BuildPortal } from './vite-plugin.ts';
import { buildWeb } from './vite.ts';

function walk(dir: string, out: string[] = []): string[] {
  for (const e of readdirSync(dir)) {
    const p = join(dir, e);
    if (statSync(p).isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}

export interface PortalPackage {
  /** games/<id>/upload — what goes into the upload form (index.html only) */
  dir: string;
  file: string;
  bytes: number;
  problems: string[];
  /** The size report (also in upload/size.json): raw, gzipped, by npm package, the load estimate, the budget's warnings */
  size: SizeReport;
}

/**
 * Folds dist/ (one JS bundle, one stylesheet, assets inlined by the build) into one index.html. Later asset chapters
 * (dist/chapters/<n>/…, chapters.ts) become data blocks at the end, after the game's script, which then runs `async`
 */
export function inlineBuild(dist: string): { html: string; problems: string[] } {
  const problems: string[] = [];
  let html = readFileSync(join(dist, 'index.html'), 'utf8');
  const used = new Set<string>(['index.html']);
  const files = walk(dist).map((f) => relative(dist, f).split('\\').join('/'));
  const chapters: ChapterFile[] = files.flatMap((path) => {
    const chapter = chapterOfPath(path);
    return chapter === null ? [] : [{ path, chapter, data: readFileSync(join(dist, path)) }];
  });
  let script = '';
  html = html.replace(/<script type="module" crossorigin src="\.\/([^"]+\.js)"><\/script>/g, (_, f: string) => {
    used.add(f);
    // Inside <script> the HTML parser still reacts to "</script", "<!--" and "<script" (the last two switch it into a mode
    // where the closing tag no longer ends the element). \x3C is "<" in every JS context they can occur in: strings,
    // template literals, regular expressions, comments
    const js = readFileSync(join(dist, f), 'utf8').replace(/<(\/script|!--|script)/gi, (_, rest: string) => `\\x3C${rest}`);
    const tag = `<script type="module">${js}</script>`;
    if (!chapters.length) return tag;
    script += tag;
    return '';
  });
  if (chapters.length) {
    for (const c of chapters) used.add(c.path);
    html = foldChapters(html, script, chapters);
  }
  html = html.replace(/<link rel="stylesheet" crossorigin href="\.\/([^"]+\.css)">/g, (_, f: string) => {
    used.add(f);
    return `<style>${readFileSync(join(dist, f), 'utf8').replace(/<\/style/gi, '<\\/style')}</style>`;
  });
  // The hidden sourcemaps stay in dist/ (the size report reads them); they are not part of the page
  const rest = files.filter((f) => !used.has(f) && !f.endsWith('.map'));
  if (rest.length) problems.push(`files the page would load separately, not inlined: ${rest.slice(0, 5).join(', ')}${rest.length > 5 ? ' …' : ''} — import assets from code (the build inlines them) instead of fetching them by path`);
  if (/<(script|link)\b[^>]*(?:src|href)="\.?\/?assets\//.test(html)) problems.push('index.html still points to ./assets/ after inlining');
  return { html, problems };
}

export function checkUpload(game: ResolvedGame, html: string, target?: BuildPortal): string[] {
  const ch = CHANNELS[game.channel.id];
  const problems: string[] = [];
  const bytes = Buffer.byteLength(html);
  if (ch.webLimits && bytes > ch.webLimits.maxInitialMB * 1024 * 1024) problems.push(`${(bytes / 1048576).toFixed(1)} MB > ${ch.webLimits.maxInitialMB} MB initial download`);

  // A dev or E2E build must never be uploaded: it has test hooks and the fake ad instead of the portal's
  for (const [needle, what] of [['__app', 'test hooks (window.__app)'], ['TEST AD', 'the test ad stub'], ['__portal', 'the portal stub']] as const)
    if (html.includes(needle)) problems.push(`the build contains ${what} — build without --e2e and outside the dev server`);
  if (target === 'playgama') {
    if (!html.includes('bridge.playgama.com')) problems.push('the Playgama Bridge adapter is missing from the build');
  } else if (target === 'idos') {
    // iDos Games lets the framed game reach only its own hosts: the game must not try another portal's SDK. The adapters
    // stay in the bundle (createPortal picks one at run time); the game's portal, as built, must be none
    if (/\bportal:[`"']/.test(html)) problems.push('the iDos build still names a portal — it must be a plain web build (game.portal: null)');
  } else if (ch.portal === 'crazygames' && !html.includes('sdk.crazygames.com')) problems.push('the CrazyGames SDK adapter is missing from the build');
  return problems;
}

/**
 * Production build → games/<id>/upload/index.html, and its size report → upload/size.json (not part of the upload: the
 * form takes index.html). Nothing is written when a check fails: a broken package must not lie around. Over the size or
 * load budget is a warning (`size.over`); over the hard limit (maxInitialMB) a problem.
 */
/** Playgama Bridge reads it next to index.html. Empty: Bridge's defaults (its config editor adds placements, IAP, leaderboards) */
/**
 * playgama-bridge-config.json. Interstitials no closer than 180 s apart (Bridge's default is 60): every interstitial on
 * Playgama's sandbox brings its header bidding along (50+ user-sync frames) and the game stutters after it — the first one
 * ≈ 25 s at ≈ 8 fps (measured 2026-10-23); fewer ads, fewer freezes, and longer play toward the sandbox's 5:00 target.
 * PLAYGAMA_AD_POLICY's minIntervalSec matches it.
 */
export const PLAYGAMA_CONFIG = {
  advertisement: {
    minimumDelayBetweenInterstitial: 180,
    // Loaded right after init and used when the game asks without a placement: a filled ad opens in ≈ 0.5 s instead of
    // loading from cold at the break (the Playgama chat, 2026-10-24)
    interstitial: { preloadOnStart: 'level_completed', placementFallback: 'level_completed' },
  },
};

export async function buildPortal(loc: GameLocation, game: ResolvedGame, mode: 'dev' | 'release' = 'dev', target?: BuildPortal): Promise<PortalPackage> {
  const dist = await buildWeb(loc, mode, false, join(loc.dir, target ? `dist-${target}` : 'dist'), { singleFile: true, portal: target });
  const dir = join(loc.dir, target ? `upload-${target}` : 'upload');
  const file = join(dir, 'index.html');
  // Absolute paths are checked in the page as built, not in the game's code (which may hold any string)
  const page = readFileSync(join(dist, 'index.html'), 'utf8');
  const { html, problems } = inlineBuild(dist);
  if (/(?:src|href)="\/(?!\/)/.test(page)) problems.push('index.html uses absolute paths — portals serve the game from a subfolder');
  problems.push(...checkUpload(game, html, target));
  const size = sizeReport(html, dist, loc, game.budget);
  rmSync(dir, { recursive: true, force: true });
  if (!problems.length) {
    mkdirSync(dir, { recursive: true });
    writeFileSync(file, html);
    writeFileSync(join(dir, 'size.json'), JSON.stringify(size, null, 2) + '\n');
    if (target === 'playgama') {
      const config = JSON.stringify(PLAYGAMA_CONFIG, null, 2) + '\n';
      writeFileSync(join(dir, 'playgama-bridge-config.json'), config);
      // The cabinet takes a ZIP with index.html at its root
      const { zip } = await import('./zip.ts');
      writeFileSync(join(dir, `${game.id}-playgama.zip`), zip([
        { name: 'index.html', data: Buffer.from(html) },
        { name: 'playgama-bridge-config.json', data: Buffer.from(config) },
      ]));
    }
    if (target === 'idos') {
      // begin_build_upload takes a ZIP with index.html at its root
      const { zip } = await import('./zip.ts');
      writeFileSync(join(dir, `${game.id}-idos.zip`), zip([{ name: 'index.html', data: Buffer.from(html) }]));
    }
  }
  return { dir, file, bytes: Buffer.byteLength(html), problems, size };
}
