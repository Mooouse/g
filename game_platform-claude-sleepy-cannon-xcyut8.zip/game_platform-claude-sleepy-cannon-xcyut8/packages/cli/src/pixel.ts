// gp pixel: the pixel-art craft checks (@gp/art/pixel lintPixelArt) on a game's sprites — its PNGs (gp art's pixel
// assets, a pack's, the owner's) and the string-grid sprites in its own code (a module that exports { frames, pal },
// { rows, key } or PixelArt values). Writes qa/pixel.md (every finding with its fix) and qa/pixel-sheet.png (each
// sprite at 1× and 4×, its silhouette and its values in grey — the two tests artists make — the findings marked).
// PNG in and out in plain Node (zlib): no browser, no image library.

import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { basename, extname, isAbsolute, join, relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { deflateSync, inflateSync } from 'node:zlib';
import { parse as parseYaml } from 'yaml';
import {
  lintPixelArt,
  lintPixelImage,
  lintPixelFrames,
  lintPixelSet,
  pixelArt,
  pixelCleanup,
  pixelFlat,
  pixelThinOutline,
  pixelToRgba,
  pixelValues,
  type LintOptions,
  type PixelArt,
  type PixelIssue,
  type PixelStats,
  type RgbaImage,
} from '../../art/src/pixel.ts';
import type { GameLocation } from './paths.ts';

// --- PNG -------------------------------------------------------------------------------------------------------------

const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c; });
function crc32(b: Buffer): number {
  let c = -1;
  for (const v of b) c = CRC[(c ^ v) & 255]! ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}
function chunk(type: string, data: Buffer): Buffer {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}

/** RGBA → PNG (8-bit RGBA, no filter) */
export function encodePng(im: RgbaImage): Buffer {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(im.w, 0);
  ihdr.writeUInt32BE(im.h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const raw = Buffer.alloc((im.w * 4 + 1) * im.h);
  for (let y = 0; y < im.h; y++) Buffer.from(im.d.buffer, im.d.byteOffset + y * im.w * 4, im.w * 4).copy(raw, y * (im.w * 4 + 1) + 1);
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

/** PNG → RGBA: 8-bit grey, grey+alpha, RGB, RGBA and palette images, not interlaced (what games and packs use) */
export function decodePng(b: Buffer): RgbaImage {
  if (b.readUInt32BE(0) !== 0x89504e47) throw new Error('not a PNG');
  let w = 0, h = 0, depth = 0, type = 0, interlace = 0;
  let plte: Buffer | null = null, trns: Buffer | null = null;
  const idat: Buffer[] = [];
  for (let p = 8; p < b.length; ) {
    const len = b.readUInt32BE(p), t = b.subarray(p + 4, p + 8).toString('ascii'), data = b.subarray(p + 8, p + 8 + len);
    if (t === 'IHDR') { w = data.readUInt32BE(0); h = data.readUInt32BE(4); depth = data[8]!; type = data[9]!; interlace = data[12]!; }
    else if (t === 'PLTE') plte = data;
    else if (t === 'tRNS') trns = data;
    else if (t === 'IDAT') idat.push(data);
    p += 12 + len;
  }
  if (interlace || (depth !== 8 && !(type === 3 && depth <= 8))) throw new Error(`PNG: ${depth}-bit${interlace ? ', interlaced' : ''} not read — save it as 8-bit, not interlaced`);
  const ch = ({ 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 } as Record<number, number>)[type];
  if (!ch) throw new Error(`PNG colour type ${type}`);
  const bpp = type === 3 ? 1 : ch;
  const stride = type === 3 ? Math.ceil((w * depth) / 8) : w * ch;
  const raw = inflateSync(Buffer.concat(idat));
  const px = Buffer.alloc(stride * h);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)]!, row = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1));
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? px[y * stride + x - bpp]! : 0, up = y ? px[(y - 1) * stride + x]! : 0, c = y && x >= bpp ? px[(y - 1) * stride + x - bpp]! : 0;
      const pa = Math.abs(up - c), pb = Math.abs(a - c), pc = Math.abs(a + up - 2 * c);
      const pred = f === 1 ? a : f === 2 ? up : f === 3 ? (a + up) >> 1 : f === 4 ? (pa <= pb && pa <= pc ? a : pb <= pc ? up : c) : 0;
      px[y * stride + x] = (row[x]! + pred) & 255;
    }
  }
  const d = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4;
      if (type === 3) {
        const bits = depth, per = 8 / bits;
        const byte = px[y * stride + Math.floor(x / per)]!;
        const i = (byte >> (8 - bits * (1 + (x % per)))) & ((1 << bits) - 1);
        d[o] = plte![i * 3]!; d[o + 1] = plte![i * 3 + 1]!; d[o + 2] = plte![i * 3 + 2]!; d[o + 3] = trns && i < trns.length ? trns[i]! : 255;
      } else {
        const i = y * stride + x * ch;
        const g = px[i]!;
        if (type === 0) { d[o] = d[o + 1] = d[o + 2] = g; d[o + 3] = 255; }
        else if (type === 4) { d[o] = d[o + 1] = d[o + 2] = g; d[o + 3] = px[i + 1]!; }
        else { d[o] = px[i]!; d[o + 1] = px[i + 1]!; d[o + 2] = px[i + 2]!; d[o + 3] = type === 6 ? px[i + 3]! : 255; }
      }
    }
  return { w, h, d };
}

// --- Finding the sprites ---------------------------------------------------------------------------------------------

export interface PixelSprite {
  name: string;
  art: PixelArt;
  /** A PNG's own RGBA (for the soft-edge check) */
  image?: RgbaImage;
  file?: string;
  tile: boolean;
  /** An animation's frame: the sprite's name and the frame's index */
  of?: string;
}

const TILE = /(^|[^a-z])(tile|floor|wall|ground|bg|background|terrain|grass|water|brick|sky)/i;

const isRows = (v: unknown): v is string[] => Array.isArray(v) && v.length > 0 && v.every((r) => typeof r === 'string');
const isKey = (v: unknown): v is Record<string, string> => !!v && typeof v === 'object' && !Array.isArray(v) && Object.values(v).every((c) => typeof c === 'string');

/** Every sprite a module exports, by its path: { frames: string[][], pal } (each frame), { rows, key }, PixelArt */
export function spritesOf(mod: Record<string, unknown>, prefix = ''): PixelSprite[] {
  const out: PixelSprite[] = [];
  const seen = new Set<unknown>();
  const walk = (v: unknown, path: string, depth: number) => {
    if (!v || typeof v !== 'object' || seen.has(v) || depth > 5) return;
    seen.add(v);
    const o = v as Record<string, unknown>;
    const add = (name: string, art: () => PixelArt) => { try { out.push({ name, art: art(), tile: TILE.test(name) }); } catch { /* not a sprite after all */ } };
    if (Array.isArray(o.frames) && (isKey(o.pal) || isKey(o.key))) {
      const key = (o.pal ?? o.key) as Record<string, string>;
      const n = (o.frames as unknown[]).length;
      (o.frames as unknown[]).forEach((f, i) => { if (isRows(f)) add(n > 1 ? `${path}#${i + 1}` : path, () => pixelArt(f, key)); });
      if (n > 1) for (const s of out.slice(-n)) s.of = path;
      return;
    }
    if (isRows(o.rows) && isKey(o.key)) return add(path, () => pixelArt(o.rows as string[], o.key as Record<string, string>));
    if (typeof o.w === 'number' && typeof o.h === 'number' && o.px instanceof Uint8Array && Array.isArray(o.colors)) return add(path, () => o as unknown as PixelArt);
    if (Array.isArray(v)) v.forEach((x, i) => walk(x, `${path}[${i}]`, depth + 1));
    else for (const k of Object.keys(o)) walk(o[k], path ? `${path}.${k}` : k, depth + 1);
  };
  for (const k of Object.keys(mod)) walk(mod[k], prefix + k, 0);
  return out;
}

function pngsIn(dir: string): string[] {
  if (!existsSync(dir)) return [];
  const out: string[] = [];
  for (const n of readdirSync(dir).sort()) {
    const f = join(dir, n);
    if (statSync(f).isDirectory()) { if (n !== 'thumbs') out.push(...pngsIn(f)); }
    else if (extname(n).toLowerCase() === '.png') out.push(f);
  }
  return out;
}

/** The game's pixel settings from game.yaml: art.technique and art.palette, pixel { sprites, background } */
export function pixelSettings(loc: GameLocation): { technique?: string; palette?: string[]; sprites: string[]; background?: string } {
  const spec = (parseYaml(readFileSync(loc.file, 'utf8')) ?? {}) as { art?: { technique?: string; palette?: string[] }; pixel?: { sprites?: string | string[]; background?: string } };
  const s = spec.pixel?.sprites;
  return { technique: spec.art?.technique, palette: spec.art?.palette, sprites: s === undefined ? [] : Array.isArray(s) ? s : [s], background: spec.pixel?.background };
}

export async function collectSprites(loc: GameLocation, targets: string[]): Promise<PixelSprite[]> {
  const set = pixelSettings(loc);
  const files = targets.length ? targets : [...set.sprites, ...(set.technique === 'pixel' ? pngsIn(join(loc.dir, 'assets')) : [])];
  const out: PixelSprite[] = [];
  for (const t of files) {
    const f = isAbsolute(t) ? t : existsSync(join(loc.dir, t)) ? join(loc.dir, t) : resolve(t);
    if (!existsSync(f)) throw new Error(`${t}: no such file`);
    if (statSync(f).isDirectory()) { for (const p of pngsIn(f)) out.push(fromPng(loc, p, set.palette)); continue; }
    if (/\.png$/i.test(f)) { out.push(fromPng(loc, f, set.palette)); continue; }
    if (/\.[mc]?[jt]s$/i.test(f)) {
      const mod = (await import(pathToFileURL(f).href)) as Record<string, unknown>;
      const found = spritesOf(mod);
      if (!found.length) throw new Error(`${t}: exports no sprites — gp pixel reads { frames: string[][], pal }, { rows, key } and PixelArt values`);
      out.push(...found.map((s) => ({ ...s, file: relative(loc.dir, f) })));
      continue;
    }
    throw new Error(`${t}: a PNG, a folder of PNGs or a module of string-grid sprites`);
  }
  // A PNG animation: <id>.png, <id>-1.png, <id>-2.png … (gp art's frames) are one sprite's frames
  const pngs = out.filter((s) => s.image && !s.of);
  const base = (n: string) => n.replace(/(-\d+)?\.png$/i, '');
  const groups = new Map<string, PixelSprite[]>();
  for (const s of pngs) groups.set(base(s.name), [...(groups.get(base(s.name)) ?? []), s]);
  const frameNo = (n: string) => Number(/-(\d+)\.png$/i.exec(n)?.[1] ?? 0);
  for (const [b, group] of groups) {
    if (group.length < 2 || !group.some((s) => frameNo(s.name))) continue;
    for (const s of group) s.of = b;
    // The sprite itself first, then its frames in order — the order animations() compares them in
    const rest = out.filter((s) => s.of !== b);
    out.splice(0, out.length, ...rest, ...group.sort((p, q) => frameNo(p.name) - frameNo(q.name)));
  }
  return out;
}

function fromPng(loc: GameLocation, f: string, palette?: string[]): PixelSprite {
  const image = decodePng(readFileSync(f));
  const name = relative(loc.dir, f);
  return { name, art: lintPixelImage(image, { palette }).art, image, file: name, tile: TILE.test(basename(f)) };
}

// --- The report --------------------------------------------------------------------------------------------------

export interface PixelResult {
  sprite: PixelSprite;
  issues: PixelIssue[];
  stats: PixelStats;
}

export function lintSprites(sprites: PixelSprite[], o: LintOptions = {}): PixelResult[] {
  return sprites.map((s) => {
    const opts = { ...o, tile: o.tile ?? s.tile };
    const r = s.image ? lintPixelImage(s.image, opts) : lintPixelArt(s.art, opts);
    return { sprite: s, issues: r.issues, stats: r.stats };
  });
}

export function pixelReport(loc: GameLocation, results: PixelResult[]): string {
  results = [...results].sort((a, b) => rank(b) - rank(a));
  const warn = results.filter((r) => r.issues.some((i) => i.severity === 'warning'));
  const byCode = new Map<string, { n: number; fix: string }>();
  for (const r of results) for (const i of r.issues) { const e = byCode.get(i.code) ?? { n: 0, fix: i.fix }; e.n++; byCode.set(i.code, e); }
  const set = setIssues(results);
  const lines = [
    `# Pixel art — ${loc.id}`,
    '',
    `${results.length} sprite(s), ${warn.length} with a warning. The checks: docs/guides/pixel-art.md#the-checks-gp-pixel. Look at qa/pixel-sheet.png: each sprite at 1× and 4×, its silhouette (does it read in one colour?) and its values (does the form read in grey?), the findings marked in red.`,
    '',
    '## The set: one game',
    '',
    ...(set.length ? set.map((i) => `- ${i.severity === 'warning' ? '**' + i.code + '**' : i.code}: ${i.message} → ${i.fix}`) : ['One light, one pixel size and one outline rule across the sprites.']),
    '',
    '## By check',
    '',
    '| Check | Sprites | What to do |',
    '|---|---|---|',
    ...[...byCode.entries()].sort((a, b) => b[1].n - a[1].n).map(([c, e]) => `| ${c} | ${e.n} | ${e.fix.replace(/\|/g, '\\|')} |`),
    '',
    '## Sprites',
    '',
  ];
  for (const r of results) {
    if (!r.issues.length) continue;
    lines.push(`### ${r.sprite.name} (${r.stats.w}×${r.stats.h}, ${r.stats.colors} colours)`, '');
    for (const i of r.issues) lines.push(`- ${i.severity === 'warning' ? '**' + i.code + '**' : i.code}: ${i.message}${i.at?.length ? ` — at ${i.at.slice(0, 6).map(([x, y]) => `${x},${y}`).join(' ')}${i.at.length > 6 ? ' …' : ''}` : ''}`);
    lines.push('');
  }
  if (!results.some((r) => r.issues.length)) lines.push('Every sprite passes.', '');
  return lines.join('\n');
}

const rank = (r: PixelResult) => (r.issues.some((i) => i.severity === 'warning') ? 2 : r.issues.length ? 1 : 0);

/** Each sprite in a row: 1×, 4× on a checker with the findings marked, the silhouette and the values at 4× */
export function pixelSheet(results: PixelResult[], o: { only?: 'issues'; max?: number } = {}): RgbaImage {
  const rows = [...results].sort((a, b) => rank(b) - rank(a)).filter((r) => o.only !== 'issues' || r.issues.length).slice(0, o.max ?? 120);
  const Z = 4, pad = 6;
  const cellW = (r: PixelResult) => r.sprite.art.w;
  const rowH = (r: PixelResult) => Math.max(8, r.sprite.art.h) * Z + pad * 2;
  const W = Math.max(64, ...rows.map((r) => cellW(r) * (1 + 3 * Z) + pad * 5));
  const H = Math.max(16, rows.reduce((s, r) => s + rowH(r), 0));
  const d = new Uint8ClampedArray(W * H * 4);
  const put = (x: number, y: number, c: [number, number, number]) => { if (x < 0 || y < 0 || x >= W || y >= H) return; const i = (y * W + x) * 4; d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255; };
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) put(x, y, ((x >> 3) + (y >> 3)) & 1 ? [58, 58, 66] : [44, 44, 52]);
  const blit = (im: RgbaImage, x0: number, y0: number) => {
    for (let y = 0; y < im.h; y++) for (let x = 0; x < im.w; x++) { const i = (y * im.w + x) * 4; if (im.d[i + 3]! >= 128) put(x0 + x, y0 + y, [im.d[i]!, im.d[i + 1]!, im.d[i + 2]!]); }
  };
  let y = 0;
  for (const r of rows) {
    const a = r.sprite.art;
    const x1 = pad, x4 = pad * 2 + a.w, xs = x4 + a.w * Z + pad, xv = xs + a.w * Z + pad;
    blit(pixelToRgba(a, 1), x1, y + pad);
    blit(pixelToRgba(a, Z), x4, y + pad);
    blit(pixelToRgba(pixelFlat(a, '#f4f0e8'), Z), xs, y + pad);
    blit(pixelToRgba(pixelValues(a), Z), xv, y + pad);
    // The findings: a red frame round each marked pixel on the 4× view
    for (const i of r.issues) for (const [px, py] of i.at ?? []) for (let k = 0; k < Z; k++) { put(x4 + px * Z + k, y + pad + py * Z, [255, 40, 60]); put(x4 + px * Z + k, y + pad + py * Z + Z - 1, [255, 40, 60]); put(x4 + px * Z, y + pad + py * Z + k, [255, 40, 60]); put(x4 + px * Z + Z - 1, y + pad + py * Z + k, [255, 40, 60]); }
    // A bar on the left: red with a warning, amber with info only, green clean
    const colour: [number, number, number] = r.issues.some((i) => i.severity === 'warning') ? [230, 60, 70] : r.issues.length ? [230, 170, 50] : [70, 190, 110];
    for (let j = 0; j < rowH(r) - 2; j++) { put(0, y + 1 + j, colour); put(1, y + 1 + j, colour); }
    y += rowH(r);
  }
  return { w: W, h: H, d };
}

/** Each animation's frames checked together (flicker, jumps), the findings naming the sprite */
function animations(results: PixelResult[]): PixelIssue[] {
  const groups = new Map<string, PixelArt[]>();
  for (const r of results) if (r.sprite.of) groups.set(r.sprite.of, [...(groups.get(r.sprite.of) ?? []), r.sprite.art]);
  return [...groups.entries()].flatMap(([name, frames]) => lintPixelFrames(frames).map((i) => ({ ...i, message: `${name}: ${i.message}` })));
}

/** The set as one game (light, density, outline) and every animation's frames */
export const setIssues = (results: PixelResult[]): PixelIssue[] => [...lintPixelSet(results.map((r) => ({ name: r.sprite.name, stats: r.stats, tile: r.sprite.tile }))), ...animations(results)];

export interface PixelRun {
  results: PixelResult[];
  /** What makes the sprites one game (lintPixelSet) */
  set: PixelIssue[];
  report: string;
  sheet: string;
  fixed: string[];
}

/** gp pixel: lint, report, sheet; `fix` writes cleaned PNGs (noise out, near-twin colours merged, a 2-px outline thinned) */
export async function runPixel(loc: GameLocation, targets: string[], o: { background?: string; fix?: boolean } = {}): Promise<PixelRun> {
  const set = pixelSettings(loc);
  const sprites = await collectSprites(loc, targets);
  const results = lintSprites(sprites, { background: o.background ?? set.background });
  const qa = join(loc.dir, 'qa');
  mkdirSync(qa, { recursive: true });
  const report = join(qa, 'pixel.md');
  writeFileSync(report, pixelReport(loc, results));
  const sheet = join(qa, 'pixel-sheet.png');
  writeFileSync(sheet, encodePng(pixelSheet(results)));
  const fixed: string[] = [];
  if (o.fix) {
    const dir = join(qa, 'pixel-fixed');
    mkdirSync(dir, { recursive: true });
    for (const r of results) {
      if (!r.issues.some((i) => ['P_NOISE', 'P_NEAR_COLORS', 'P_THICK_OUTLINE'].includes(i.code))) continue;
      let a = pixelCleanup(r.sprite.art).art;
      if (r.issues.some((i) => i.code === 'P_THICK_OUTLINE')) a = pixelThinOutline(a);
      const f = join(dir, r.sprite.name.replace(/[^a-z0-9._-]+/gi, '_').replace(/\.png$/i, '') + '.png');
      writeFileSync(f, encodePng(pixelToRgba(a)));
      fixed.push(f);
    }
  }
  return { results, set: setIssues(results), report, sheet, fixed };
}
