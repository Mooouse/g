// gp agents: the subagents a game repository routes its work to (docs/guides/routing.md) — mechanic (Haiku), architect
// (Opus), pixel-artist and promo-artist (Sonnet) — installed into its .claude/agents/ from the platform's template, and
// kept up to date (a repository made before 2026-10-28 has none). The platform's own are in its .claude/agents/.

import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { ROOT, type GameLocation } from './paths.ts';

export const AGENTS_TEMPLATE = join(ROOT, 'templates', 'game-repo', '.claude', 'agents');

/** The repository a game lives in: its git top level, else the folder above games/<id> */
export function repoRootOf(loc: GameLocation): string {
  try {
    return execFileSync('git', ['-C', loc.dir, 'rev-parse', '--show-toplevel'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
  } catch {
    return resolve(dirname(dirname(loc.dir)));
  }
}

export interface AgentsResult {
  root: string;
  added: string[];
  updated: string[];
  same: string[];
  /** The platform's own checkout: its agents are its own, nothing is copied */
  platform: boolean;
}

/** Copy the template's agents into the game's repository (check: only say what is missing or out of date) */
export function installAgents(loc: GameLocation, o: { check?: boolean } = {}): AgentsResult {
  const root = repoRootOf(loc);
  const res: AgentsResult = { root, added: [], updated: [], same: [], platform: resolve(root) === resolve(ROOT) };
  if (res.platform) return res;
  const dir = join(root, '.claude', 'agents');
  for (const f of readdirSync(AGENTS_TEMPLATE).filter((n) => n.endsWith('.md')).sort()) {
    const want = readFileSync(join(AGENTS_TEMPLATE, f), 'utf8');
    const at = join(dir, f);
    const have = existsSync(at) ? readFileSync(at, 'utf8') : null;
    if (have === want) { res.same.push(f); continue; }
    (have === null ? res.added : res.updated).push(f);
    if (!o.check) {
      mkdirSync(dir, { recursive: true });
      writeFileSync(at, want);
    }
  }
  return res;
}
