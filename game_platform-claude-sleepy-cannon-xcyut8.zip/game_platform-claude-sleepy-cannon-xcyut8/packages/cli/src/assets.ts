// gp assets: take existing images instead of making new ones. `get` downloads an image or a pack into the game's
// assets-src/ (a zip is unpacked) and lists the images; `sheet` numbers a sprite sheet's cells on a grid so an art asset
// can take one with `from` + `cut` (gp art then cuts, trims, fits and — for pixel art — snaps it to the game's palette).

import { execFileSync } from 'node:child_process';
import { mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { basename, extname, join, relative } from 'node:path';
import { ASSETS_SRC_DIR } from './art.ts';
import type { GameLocation } from './paths.ts';

const IMAGE = /\.(png|gif|webp|jpe?g)$/i;

/** Unpack a zip next to it (into a folder of its name) and list every image under assets-src/ that came with it, with its size */
export async function listImages(loc: GameLocation, file: string): Promise<{ file: string; w: number; h: number }[]> {
  let root = file;
  if (/\.zip$/i.test(file)) {
    root = file.replace(/\.zip$/i, '');
    mkdirSync(root, { recursive: true });
    execFileSync('unzip', ['-o', '-q', file, '-d', root]);
  }
  const files: string[] = [];
  const walk = (d: string) => {
    for (const n of readdirSync(d)) {
      const f = join(d, n);
      if (statSync(f).isDirectory()) walk(f);
      else if (IMAGE.test(n)) files.push(f);
    }
  };
  if (statSync(root).isDirectory()) walk(root);
  else files.push(root);
  return Promise.all(files.sort().map(async (f) => ({ file: relative(loc.dir, f), ...imageSize(readFileSync(f)) })));
}

/** Width and height from a PNG, GIF or WebP header (0 × 0 when it can't tell) */
export function imageSize(b: Buffer): { w: number; h: number } {
  if (b.subarray(1, 4).toString() === 'PNG') return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
  if (b.subarray(0, 3).toString() === 'GIF') return { w: b.readUInt16LE(6), h: b.readUInt16LE(8) };
  if (b.subarray(8, 12).toString() === 'WEBP') {
    const kind = b.subarray(12, 16).toString();
    if (kind === 'VP8X') return { w: 1 + b.readUIntLE(24, 3), h: 1 + b.readUIntLE(27, 3) };
    if (kind === 'VP8L') { const v = b.readUInt32LE(21); return { w: (v & 0x3fff) + 1, h: ((v >> 14) & 0x3fff) + 1 }; }
    if (kind === 'VP8 ') return { w: b.readUInt16LE(26) & 0x3fff, h: b.readUInt16LE(28) & 0x3fff };
  }
  return { w: 0, h: 0 };
}

/** A sprite sheet enlarged with every grid cell numbered: qa/sheet-<name>.png */
export async function sheetImage(loc: GameLocation, image: string, g: { w: number; h: number; margin: number; gap: number }): Promise<{ file: string; cols: number; rows: number; example: string }> {
  const src = join(loc.dir, image);
  const { w, h } = imageSize(readFileSync(src));
  const step = (n: number, cell: number) => Math.max(0, Math.floor((n - 2 * g.margin + g.gap) / (cell + g.gap)));
  const cols = step(w, g.w), rows = step(h, g.h);
  const { chromium } = await import('playwright');
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  try {
    const page = await browser.newPage();
    const png = await page.evaluate(
      async ({ src, g, cols, rows }) => {
        const img = new Image();
        img.src = src;
        await img.decode();
        const z = Math.max(1, Math.min(8, Math.floor(2400 / img.width)));
        const c = document.createElement('canvas');
        c.width = img.width * z;
        c.height = img.height * z;
        const x = c.getContext('2d')!;
        x.imageSmoothingEnabled = false;
        x.fillStyle = '#3a3a3a';
        x.fillRect(0, 0, c.width, c.height);
        x.drawImage(img, 0, 0, c.width, c.height);
        x.font = `bold ${Math.max(10, Math.min(16, g.w * z * 0.3))}px monospace`;
        for (let r = 0; r < rows; r++)
          for (let q = 0; q < cols; q++) {
            const px = (g.margin + q * (g.w + g.gap)) * z, py = (g.margin + r * (g.h + g.gap)) * z;
            x.strokeStyle = 'rgba(255,0,255,.6)';
            x.strokeRect(px + 0.5, py + 0.5, g.w * z - 1, g.h * z - 1);
            const n = String(r * cols + q);
            x.lineWidth = 3;
            x.strokeStyle = '#000';
            x.strokeText(n, px + 2, py + 13);
            x.fillStyle = '#fff';
            x.fillText(n, px + 2, py + 13);
            x.lineWidth = 1;
          }
        return c.toDataURL('image/png').split(',')[1]!;
      },
      { src: `data:image/${extname(src).slice(1).replace('jpg', 'jpeg')};base64,${readFileSync(src).toString('base64')}`, g, cols, rows },
    );
    mkdirSync(join(loc.dir, 'qa'), { recursive: true });
    const file = join(loc.dir, 'qa', `sheet-${basename(src, extname(src))}.png`);
    writeFileSync(file, Buffer.from(png, 'base64'));
    return { file, cols, rows, example: `[margin + (n % ${cols}) × ${g.w + g.gap}, margin + ⌊n / ${cols}⌋ × ${g.h + g.gap}, ${g.w}, ${g.h}]` };
  } finally {
    await browser.close();
  }
}

export { ASSETS_SRC_DIR };

/**
 * Every pixel-art scaler on one image, side by side at the same size on screen: qa/upscale-<name>.png — pick the one that
 * keeps the design (then an art asset's `upscale`, or `gp assets upscale`)
 */
export async function compareUpscalers(loc: GameLocation, image: string, factor: number, models: string[], palette?: string[]): Promise<string> {
  const u = await import('./upscale.ts');
  const { chromium } = await import('playwright');
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  try {
    const page = await browser.newPage();
    const src = await u.decodePng(page, readFileSync(join(loc.dir, image)));
    const methods: string[] = [...u.UPSCALE_METHODS, ...models.map((m) => `esrgan:${m}`)];
    const cols: { label: string; im: import('./upscale.ts').Rgba }[] = [{ label: `original ${src.w}×${src.h}`, im: src }];
    for (const m of methods) {
      try {
        cols.push({ label: `${m.replace(/^esrgan:.*[\\/]/, 'esrgan ').replace(/\.pth$/, '')} ×${factor}`, im: await u.upscale(src, { method: m as import('./upscale.ts').UpscaleMethod, factor, palette }, page) });
      } catch (e) {
        cols.push({ label: `${m}: ${(e as Error).message.slice(0, 40)}`, im: { w: 1, h: 1, d: new Uint8ClampedArray(4) } });
      }
    }
    const png = await page.evaluate(
      ({ cols }) => {
        const cell = 260, c = document.createElement('canvas');
        c.width = cols.length * cell;
        c.height = cell + 40;
        const g = c.getContext('2d')!;
        g.imageSmoothingEnabled = false;
        g.fillStyle = '#2a2333';
        g.fillRect(0, 0, c.width, c.height);
        g.fillStyle = '#e7d6ff';
        g.font = 'bold 14px sans-serif';
        g.textAlign = 'center';
        cols.forEach(({ label, im }, i) => {
          g.fillText(label, i * cell + cell / 2, 24);
          const t = document.createElement('canvas');
          t.width = im.w;
          t.height = im.h;
          t.getContext('2d')!.putImageData(new ImageData(new Uint8ClampedArray(im.d), im.w, im.h), 0, 0);
          const k = Math.floor((cell - 20) / Math.max(im.w, im.h)) || 1;
          g.drawImage(t, i * cell + (cell - im.w * k) / 2, 40 + (cell - im.h * k) / 2, im.w * k, im.h * k);
        });
        return c.toDataURL('image/png').split(',')[1]!;
      },
      { cols: cols.map((c) => ({ label: c.label, im: { w: c.im.w, h: c.im.h, d: Array.from(c.im.d) } })) },
    );
    mkdirSync(join(loc.dir, 'qa'), { recursive: true });
    const file = join(loc.dir, 'qa', `upscale-${basename(image, extname(image))}.png`);
    writeFileSync(file, Buffer.from(png, 'base64'));
    return file;
  } finally {
    await browser.close();
  }
}

/** One image upscaled with a method, written next to it as <name>@<factor>x.png (or `out`) */
export async function upscaleFile(loc: GameLocation, image: string, o: import('./upscale.ts').UpscaleOptions, out?: string): Promise<string> {
  const u = await import('./upscale.ts');
  const { chromium } = await import('playwright');
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  try {
    const page = await browser.newPage();
    const res = await u.upscale(await u.decodePng(page, readFileSync(join(loc.dir, image))), o, page);
    const file = out ? join(loc.dir, out) : join(loc.dir, image.replace(/\.png$/i, '') + `@${o.factor}x.png`);
    writeFileSync(file, await u.encodePng(page, res));
    return file;
  } finally {
    await browser.close();
  }
}
