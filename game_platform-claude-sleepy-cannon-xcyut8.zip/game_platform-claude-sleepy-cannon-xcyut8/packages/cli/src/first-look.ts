// `gp review --first-look`: a blind first contact. A separate agent who knows nothing about the game sees only the first
// 30 s of a fresh player's run and says what the goal is, what the controls are, what the hook is and whether it would
// keep playing.
//
// Our reviewer reads a 300-line brief — concept, twist, systems, money — before it plays: the opposite of a naive player
// (Fullerton, Lemarchand; docs/research/game-design-2026-10.md P17). Swarm Smash went out with 0 blocking findings and
// was rejected for "overall quality". So the first look carries no text of ours: no title, no concept, no listing, no
// report — six frames and four questions.
//
//   games/<id>/qa/first-look-<t>s.png    the frames at 0, 3, 8, 15, 22 and 30 s, 1280×720 (the dev build, a virtual
//                                        clock, ?seed=1, a fresh save, Play tapped and the demo bot on after frame 0)
//   games/<id>/qa/first-look.png         the strip: the six frames, each with its time and nothing else
//   games/<id>/qa/first-look-brief.md    the blind agent's task
//   games/<id>/qa/first-look.md          its answers (fixed format: parseFirstLook); `gp review --check` reads them on
//                                        CrazyGames. gp qa keeps all of these (KEPT_REPORTS, @gp/qa).

import { existsSync, mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { freshRun, SHEET_H, SHEET_W } from './review-sheet.ts';
import type { GameLocation } from './paths.ts';

export const FIRST_LOOK_TIMES = [0, 3, 8, 15, 22, 30] as const;
export const FIRST_LOOK_FILE = 'first-look.md';
export const FIRST_LOOK_BRIEF = 'first-look-brief.md';
export const FIRST_LOOK_STRIP = 'first-look.png';
/** "Keep playing" at or below this is a [blocking] finding in quality.md */
export const FIRST_LOOK_LOW = 2;

export const frameName = (t: number) => `first-look-${String(t).padStart(2, '0')}s.png`;

/** Every file `gp review --first-look` writes or reads in qa/ (gp qa keeps them) */
export const FIRST_LOOK_FILES = [FIRST_LOOK_FILE, FIRST_LOOK_BRIEF, FIRST_LOOK_STRIP, ...FIRST_LOOK_TIMES.map(frameName)];

/**
 * The six frames of a fresh player's first 30 s: frame 0 is the first screen as it loads (Play not yet tapped), then Play
 * is tapped and the demo bot plays, and the clock counts on from frame 0. A run that ends meanwhile goes on to whatever
 * the game shows then: that is what the player sees too.
 */
export async function captureFirstLook(loc: GameLocation): Promise<{ frames: { t: number; file: string }[]; problems: string[] }> {
  const qa = join(loc.dir, 'qa');
  mkdirSync(qa, { recursive: true });
  const frames: { t: number; file: string }[] = [];
  let t0 = 0;
  const { problems } = await freshRun(
    loc,
    async ({ page, now }) => {
      t0 = now();
      const file = join(qa, frameName(0));
      await page.screenshot({ path: file });
      frames.push({ t: 0, file });
    },
    async ({ page, now, step }) => {
      for (const t of FIRST_LOOK_TIMES.slice(1)) {
        await step(Math.max(0, t - (now() - t0)));
        const file = join(qa, frameName(t));
        await page.screenshot({ path: file });
        frames.push({ t, file });
      }
    },
  );
  return { frames, problems };
}

/** The strip as HTML: 3 × 2 frames at half size, each captioned with its time only (no title: it is blind) */
export function stripHtml(frames: readonly { t: number; file: string }[], img: (file: string) => string): string {
  const w = SHEET_W / 2;
  const h = SHEET_H / 2;
  const cells = frames.map((f) => `<figure><img src="${img(f.file)}"><figcaption>${f.t} s</figcaption></figure>`).join('');
  return `<!doctype html><meta charset="utf-8"><style>
    body { margin: 0; padding: 12px; background: #15171c; color: #e8e8ea; font: bold 18px/1 system-ui, sans-serif; width: max-content; }
    .row { display: grid; grid-template-columns: repeat(3, ${w}px); gap: 10px; }
    figure { margin: 0; } img { display: block; width: ${w}px; height: ${h}px; object-fit: contain; background: #000; outline: 2px solid #333; }
    figcaption { padding: 6px 2px 4px; }
  </style><div class="row">${cells}</div>`;
}

/** Compose qa/first-look.png from the frames (Playwright) */
export async function composeStrip(loc: GameLocation, frames: readonly { t: number; file: string }[]): Promise<string> {
  const { chromium } = await import('playwright');
  const file = join(loc.dir, 'qa', FIRST_LOOK_STRIP);
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  try {
    // Exactly the strip's width: three half-size frames, two 10-px gaps, 12-px padding each side
    const page = await browser.newPage({ viewport: { width: (3 * SHEET_W) / 2 + 2 * 10 + 2 * 12, height: 800 }, deviceScaleFactor: 1 });
    await page.setContent(stripHtml(frames, (f) => `data:image/png;base64,${readFileSync(f).toString('base64')}`));
    await page.waitForFunction(() => [...document.images].every((i) => i.complete), null, { timeout: 30000 });
    await page.screenshot({ path: file, fullPage: true });
  } finally {
    await browser.close();
  }
  return file;
}

/** The template of first-look.md; the parser accepts it once the placeholders are filled (a test keeps them in step) */
export function firstLookTemplate(): string {
  return [
    '# First look',
    '',
    '- Goal: <what the player is trying to do, in one sentence — or "don\'t know">',
    '- Controls: <what the player presses, clicks or drags — or "don\'t know">',
    '- Hook: <what, if anything, would make you play on — or "none">',
    '- Keep playing: <1–5>/5 — <why>',
    '- Unclear: <optional: what you could not tell from the frames — or delete this line>',
    '',
  ].join('\n');
}

/**
 * The blind agent's task. It names no title, concept, listing or report — only the frames and the questions — and
 * tells the agent not to open anything else of the game's.
 */
export function firstLookBrief(frames: readonly { t: number; file: string }[], strip: string | null, answerFile: string, problems: readonly string[] = []): string {
  const L = [
    '# A first look — blind',
    '',
    'You are a player who has never heard of this game. You see what a new player sees in their first 30 seconds on a desktop (1280×720): the first screen as it loads, then a run — someone pressed Play and plays it.',
    '',
    '**Look only at the pictures below.** Do not open any other file of the game\'s (its code, game.yaml, docs, reports, store texts): the point is that you know nothing about it. If you already know this game, say so in `Unclear` and answer as best you can as a stranger.',
    '',
    strip ? `- The strip, every frame with its time: ${strip}` : '- (The strip could not be composed: look at the frames one by one.)',
    ...frames.map((f) => `- ${f.t} s: ${f.file}`),
    '',
    'Answer from the pictures alone. Guessing is fine when you say it is a guess; "don\'t know" is a real answer — a new player who can\'t tell the goal leaves.',
    '',
    `Write **${answerFile}** in exactly this format (it is parsed):`,
    '',
    '```markdown',
    firstLookTemplate().trimEnd(),
    '```',
    '',
    '- **Goal**: what the player is trying to achieve, as you understand it from the frames. "don\'t know" when you can\'t tell.',
    '- **Controls**: what the player does with the mouse or keyboard (the frames show the screen; infer from what is on it).',
    '- **Hook**: the one thing that would make you want to see more — or "none".',
    '- **Keep playing**: 1–5, would you keep playing after these 30 s? 1 = close the tab, 3 = maybe a minute more, 5 = can\'t wait to play. Then why.',
    '',
  ];
  if (problems.length) L.push('Capture notes (not about the game): ' + problems.join('; '), '');
  return L.join('\n');
}

export interface FirstLook {
  goal: string;
  controls: string;
  hook: string;
  keep: number | null;
  keepWhy: string;
  unclear: string | null;
  /** The goal is "don't know" (or another way to say it) */
  goalUnknown: boolean;
  problems: { line: number; message: string }[];
  ok: boolean;
}

const UNKNOWN = /^(?:i\s+)?(?:don'?t|do not|can'?t|cannot)\s+(?:know|tell|say)|^(?:unknown|unclear|no idea|not sure|none|n\/a|\?+)\b|^\?+$/i;

/** first-look.md → its answers, and what is wrong with the file */
export function parseFirstLook(text: string): FirstLook {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const problems: { line: number; message: string }[] = [];
  const field = (name: string, required = true): { value: string; line: number } | null => {
    const re = new RegExp(`^[-*]\\s+(?:\\*\\*)?${name}(?:\\*\\*)?\\s*:\\s*(?:\\*\\*)?\\s*(.*)$`, 'i');
    const i = lines.findIndex((l) => re.test(l.trim()));
    if (i < 0) {
      if (required) problems.push({ line: 1, message: `no "- ${name}: …" line` });
      return null;
    }
    const value = lines[i].trim().match(re)![1].replace(/\*\*/g, '').trim();
    if (/<[^>]*>/.test(value)) {
      if (!required) return null;
      problems.push({ line: i + 1, message: `the template's placeholder is still in "${name}"` });
      return { value: '', line: i + 1 };
    }
    if (!value && required) problems.push({ line: i + 1, message: `"${name}" is empty: answer it, or "don't know"` });
    return { value, line: i + 1 };
  };
  if (!lines.some((l) => /^#\s+\S/.test(l))) problems.push({ line: 1, message: 'no heading: the file starts with "# First look"' });
  const goal = field('Goal');
  const controls = field('Controls');
  const hook = field('Hook');
  const keepRaw = field('Keep playing');
  const unclear = field('Unclear', false);
  let keep: number | null = null;
  let keepWhy = '';
  if (keepRaw?.value) {
    const m = keepRaw.value.match(/^(\d+(?:[.,]\d+)?)\s*(?:\/\s*5)?\s*(?:[—–:-]\s*)?(.*)$/);
    const n = m ? Number(m[1].replace(',', '.')) : NaN;
    if (!m || !Number.isInteger(n) || n < 1 || n > 5) problems.push({ line: keepRaw.line, message: '"Keep playing" is "<1–5>/5 — <why>": a whole number from 1 to 5' });
    else {
      keep = n;
      keepWhy = m[2].trim();
      if (!keepWhy) problems.push({ line: keepRaw.line, message: `say why: "- Keep playing: ${n}/5 — <why>"` });
    }
  }
  const g = goal?.value ?? '';
  return {
    goal: g,
    controls: controls?.value ?? '',
    hook: hook?.value ?? '',
    keep,
    keepWhy,
    unclear: unclear?.value || null,
    goalUnknown: !!goal && !!g && UNKNOWN.test(g),
    problems: problems.sort((a, b) => a.line - b.line),
    ok: !problems.length,
  };
}

export function readFirstLook(loc: GameLocation): { file: string; look: FirstLook | null } {
  const file = join(loc.dir, 'qa', FIRST_LOOK_FILE);
  return { file, look: existsSync(file) ? parseFirstLook(readFileSync(file, 'utf8')) : null };
}

/** Why the first look calls for a [blocking] finding: "keep playing" ≤ 2, or the goal not told — else null */
export function firstLookAlarm(fl: FirstLook): string | null {
  const why: string[] = [];
  if (fl.goalUnknown) why.push(`the goal: "${fl.goal}"`);
  if (fl.keep !== null && fl.keep <= FIRST_LOOK_LOW) why.push(`keep playing ${fl.keep}/5`);
  return why.length ? why.join(', ') : null;
}

/** Whether a quality.md finding speaks of the first look */
export const NAMES_FIRST_LOOK = /\bfirst[\s-]?look\b|\bfirst contact\b|\bblind\b/i;
