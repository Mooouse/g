// `gp stage`: the Game Design Lifecycle (GDLC) — game design as a gate at every phase, the way SSDLC makes security one
// (the owner, 2026-10-23: «пусть платформа работает в парадигме геймдизайн на каждом этапе. Это как SSDLC но для игр»).
//
// Seven phases, each with the design question it answers, the files it leaves, its automated checks, the review by an
// agent who didn't make the game, and an exit criterion — the gate (PHASES; docs/guides/gdlc.md). `gp stage <id>` reads
// what the other commands wrote (it reruns nothing: qa/qa-results.json, qa/session.json, qa/uniqueness.json,
// qa/first-look.md, qa/forecast.md, qa/uniqueness.md, quality.md, design.md, docs/gdd-review.md, docs/concept.md,
// publisher/results.yaml and updates.yaml) and says which phase the game is in, which gates hold, with evidence, and the
// next action. It writes qa/stage.md. A missing file is "not yet", never a crash: older games are in older phases.
//
//   gp stage <id>                  the report (and qa/stage.md)
//   gp stage <id> --check <phase>  exit 1 while that phase's gate isn't met (a number 0–6 or the phase's id)
//
// Enforced where it already bites (SUBMISSION_GATES): `gp submission` refuses a new submission while the ТЗ review is open
// (when there is a ТЗ) or the blind first look is under 4/5 or didn't tell the goal (CrazyGames); `gp design`, `gp review`,
// `gp build --target crazygames` and `gp qa` warn when the game is built past the slice without a passed first look.

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { parse as parseYaml } from 'yaml';
import { CHANNELS, type Issue, type RecordedResult, type ResolvedGame } from '@gp/spec';
import type { QaResults } from '@gp/qa';
import { gameRepo, newestSourceMs, shown, type GameLocation } from './paths.ts';

export type PhaseId = 'brief' | 'concept' | 'slice' | 'session' | 'content' | 'release' | 'live';

export interface PhaseDef {
  n: number;
  id: PhaseId;
  name: string;
  /** The design question the phase must answer */
  question: string;
  /** The files it leaves */
  artifacts: string[];
  /** The automated checks (existing commands) */
  automated: string[];
  /** The review by an agent who didn't make the game */
  review: string;
  /** The exit criterion: the gate */
  exit: string;
}

export const PHASES: PhaseDef[] = [
  {
    n: 0,
    id: 'brief',
    name: 'Brief',
    question: 'Is the ТЗ buildable, consistent and the game\'s own — before anything is built on it?',
    artifacts: ['docs/gdd.md (the ТЗ, edited in place)', 'docs/gdd-review.md (the record)', 'qa/brief-owner.md'],
    automated: ['`gp brief --check` (grounds, ТЗ quotes, states)'],
    review: 'the critic: an agent who did not write the ТЗ and will not build the game (`gp brief`)',
    exit: 'the loop closed: nothing open or disputed, the critic\'s «no further questions». No ТЗ: not applicable',
  },
  {
    n: 1,
    id: 'concept',
    name: 'Concept',
    question: 'What does the player do that the 3 closest portal games don\'t, in one sentence — and where does it earn?',
    artifacts: ['game.yaml `concept` and `money`', 'docs/concept.md (the ideas searched, the runner-up)', 'qa/forecast.md', 'qa/uniqueness.md'],
    automated: ['`gp validate` (E_CONCEPT, E_MONEY*)', '`gp forecast --idea` (the idea and the runner-up)', '`gp forecast`', '`gp uniqueness` ≥ 70'],
    review: 'the ТЗ critic\'s originality and money questions (phase 0); without a ТЗ, `gp brief docs/concept.md` (advised)',
    exit: 'validate 0 errors; the hook, the difference and 3 closest games; the genre and the money design; docs/concept.md with no TODO; forecast.md; uniqueness ≥ 70',
  },
  {
    n: 2,
    id: 'slice',
    name: 'Vertical slice: the first 30 s',
    question: 'Does the core verb feel good in the first 30 s, and does a stranger see the goal and the twist?',
    artifacts: ['the playable slice (host.qa demo)', 'qa/first-look.md', 'qa/uniqueness.json (the twist in play)', 'qa/feel.json'],
    automated: ['`gp qa`: the twist (host.twist within concept.twist.within, its words readable) and the feel section'],
    review: 'the blind first look (`gp review --first-look`): an agent who knows nothing about the game sees six frames of 30 s',
    exit: 'first look "keep playing" ≥ 4/5 and the goal told; the twist fires in play; no failed feel check',
  },
  {
    n: 3,
    id: 'session',
    name: 'First session',
    question: 'Does a new player get into play at once and stay 10 minutes — and is the progression paced?',
    artifacts: ['qa/first-minute.json', 'qa/session.json', 'qa/balance.md'],
    automated: ['`gp qa`: the first-minute section, the session section (W_SESSION_SHORT), the balance section (`balance()`, `balanceModel()`)'],
    review: 'the numbers decide here; the reviewer\'s session lens (quality.md `## Session`) checks them in phase 5',
    exit: 'every first-minute check green; the first natural stop after 10 min of play (CrazyGames); the balance report green',
  },
  {
    n: 4,
    id: 'content',
    name: 'Content and meta',
    question: 'Is there something new every minute or two, and a reason to come back tomorrow?',
    artifacts: ['design.md (a `gp design` round)', 'game.yaml `money.returns`, `money.covers`'],
    automated: ['`gp design --check`', '`gp validate` I_GENRE_EXPECTS (the genre\'s must-haves)', '`gp qa` feel: variety over time'],
    review: 'the designer agent (`gp design`): plays 15+ min and proposes what moves playtime, D1 and conversion',
    exit: 'design.md ✓ (its Top 3 built); a reason to return (money.returns); the genre\'s must-haves met or covered; something new within the feel section\'s gap',
  },
  {
    n: 5,
    id: 'release',
    name: 'Release candidate',
    question: 'Would the portal\'s reviewer pass it, and does the owner have everything the form asks for?',
    artifacts: ['quality.md', 'qa/report.md (a full run)', 'store/ covers and videos', 'submission/ and its zip'],
    automated: ['the full `gp qa` green on the current code', '`gp review --check`', '`gp submission` (uniqueness, forecast, covers, videos, listing; the GDLC gates)'],
    review: 'the quality reviewer (`gp review`): a second agent plays it against the portal\'s requirements and our verdicts',
    exit: '`gp review --check` ✓; the full QA green and newer than the code; the submission zip newer than the code',
  },
  {
    n: 6,
    id: 'live',
    name: 'Live',
    question: 'What did the players do, which metric is weakest, and what does the next version change for it?',
    artifacts: ['publisher/results.yaml (the verdict, the score screen)', 'publisher/updates.yaml (each patch, uploaded)', 'design.md after the scores', 'patch-notes.md'],
    automated: ['`gp design` reads the scores (the weakest metric per device)', '`gp forecast --results`'],
    review: 'the designer agent\'s next round, on the weakest metric',
    exit: 'the portal\'s answer recorded; after Basic Launch the score screen and a design round after it; a patch uploaded inside the window — or Full Launch',
  },
];

/** pass: met · fail: the evidence says no · todo: no evidence yet ("not yet") · na: doesn't apply to this game */
export type CheckState = 'pass' | 'fail' | 'todo' | 'na';

export interface GateCheck {
  id: string;
  /** What is checked, in a few words */
  what: string;
  state: CheckState;
  /** The file and its date, or the check's result */
  evidence: string;
  /** What to do when it isn't met */
  next?: string;
  /** Part of the gate (false: advice, shown but not counted) */
  required: boolean;
  /** Its evidence exists (a file was written): the phase has been worked on */
  seen: boolean;
  /** `gp submission` refuses a new submission while it isn't met */
  enforced?: boolean;
}

export interface PhaseResult {
  def: PhaseDef;
  state: CheckState;
  checks: GateCheck[];
  /** Some evidence of the phase exists */
  started: boolean;
}

export interface StageReport {
  id: string;
  title: string;
  channel: string;
  date: string;
  phases: PhaseResult[];
  /** The phase the game is in: the first whose gate isn't met (null: every gate met) */
  current: PhaseResult | null;
  /** The furthest phase with evidence of work (-1: none) */
  reached: number;
  /** Phases before `reached` whose gate isn't met: built past an open gate */
  behind: PhaseResult[];
  next: string;
}

/** The phase a `--check` argument names: 0–6, or the id (brief, concept, slice, session, content, release, live) */
export function phaseOf(arg: string): PhaseDef | null {
  const a = arg.trim().toLowerCase();
  return PHASES.find((p) => String(p.n) === a || p.id === a) ?? null;
}

/** "Keep playing" of the blind first look a phase-2 gate needs (Candle Crypt's 3/5 went with a 1/5 conversion) */
export const FIRST_LOOK_PASS = 4;
/** The session the phase-3 gate wants before the first natural stop (W_SESSION_SHORT) */
export const SESSION_GATE_MIN = 10;
/** Basic Launch lasts 7–21 days: a patch goes in inside this window */
export const BASIC_LAUNCH_DAYS = 21;
export const STAGE_FILE = 'stage.md';

// --- What the other commands wrote ------------------------------------------------------------------------------------

type Raw = Record<string, unknown>;
const obj = (v: unknown): Raw => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Raw) : {});
const str = (v: unknown): string => (typeof v === 'string' ? v.trim() : '');
const day = (ms: number) => new Date(ms).toISOString().slice(0, 10);
const mtime = (f: string) => statSync(f).mtimeMs;
const at = (f: string) => `${shown(f)} · ${day(mtime(f))}`;
const readJson = <T>(f: string): T | null => {
  try {
    return JSON.parse(readFileSync(f, 'utf8')) as T;
  } catch {
    return null;
  }
};
const todoText = (s: string) => !s || /^\s*TODO\b/i.test(s);

export interface StageInput {
  loc: GameLocation;
  /** The validator's issues (gp validate) — cheap, so gp stage runs it */
  issues: Issue[];
  /** The resolved game, when game.yaml validates (null: errors — the raw file is read instead) */
  game?: ResolvedGame | null;
  /** publisher/results.yaml's records (default: loaded) */
  results?: readonly RecordedResult[];
  /** publisher/updates.yaml's entries (default: loaded) */
  updates?: readonly { game: string; repo?: string; version: string; date?: string; uploaded?: string }[];
  /** The game's repository (default: from git) — finds its records under another id */
  repo?: string | null;
  /** Today, YYYY-MM-DD (tests) */
  today?: string;
}

/** The game, the evidence on disk, and every phase's checks */
export async function stageReport(input: StageInput): Promise<StageReport> {
  const { loc, issues } = input;
  const today = input.today ?? new Date().toISOString().slice(0, 10);
  let raw: Raw = {};
  try {
    raw = obj(parseYaml(readFileSync(loc.file, 'utf8')));
  } catch {
    raw = {};
  }
  const game = input.game ?? null;
  const id = game?.id ?? (str(raw.id) || loc.id);
  const title = game?.title ?? (str(raw.title) || id);
  const channel = game?.channel.id ?? (str(raw.channel) || '?');
  const kit = game?.kit.kit ?? str(raw.kit);
  const portal = !!CHANNELS[channel]?.portal;
  const crazy = channel === 'crazygames';
  const qaDir = join(loc.dir, 'qa');
  const q = (f: string) => join(qaDir, f);
  const sourceMs = (() => {
    try {
      return newestSourceMs(loc.dir);
    } catch {
      return 0;
    }
  })();
  const concept = obj(raw.concept);
  const money = obj(raw.money);
  const errors = issues.filter((i) => i.severity === 'error');
  const warnings = issues.filter((i) => i.severity === 'warning');
  const notPortal = (c: Omit<GateCheck, 'state' | 'evidence' | 'seen'>): GateCheck => ({ ...c, state: 'na', evidence: `not a portal game (channel ${channel})`, seen: false });

  // --- 0 Brief: the ТЗ review loop (gp brief), when there is a ТЗ ---
  const b = await import('./brief.ts');
  const brief: GateCheck[] = [];
  {
    let paths: ReturnType<typeof b.locateBrief> | null = null;
    try {
      paths = b.locateBrief(loc.dir);
    } catch {
      paths = null;
    }
    const base = { id: 'brief.loop', what: 'the ТЗ review loop closed (gp brief --check)', required: true, enforced: true };
    if (!paths) brief.push({ ...base, state: 'na', evidence: 'no ТЗ (docs/gdd.md): the idea came without one', seen: false });
    else if (!existsSync(paths.record))
      brief.push({ ...base, state: 'todo', evidence: `${at(paths.tz)}, no record (${shown(paths.record)})`, next: `gp brief ${shown(paths.tz)} → give qa/${b.BRIEF_CRITIC} to a critic agent (one who didn't write the ТЗ and won't build the game)`, seen: true });
    else {
      const rec = b.checkRecord(readFileSync(paths.record, 'utf8'), { tz: readFileSync(paths.tz, 'utf8'), snapshots: b.loadSnapshots(paths) });
      const turn = b.nextTurn(rec, rec.cap);
      const ok = !rec.problems.length && turn.who === 'done';
      const owner = b.ownerQuestions(rec).length;
      brief.push({
        ...base,
        state: ok ? 'pass' : 'fail',
        evidence: `${at(paths.record)}: ${b.stateSummary(rec)} · round ${rec.criticRound} of ${rec.cap}${rec.noFurther ? ` · no further questions (r${rec.noFurther})` : ''}${rec.problems.length ? ` · ${rec.problems.length} problem(s)` : ''}`,
        next: ok ? undefined : rec.problems.length ? `gp brief ${shown(paths.tz)} --check lists the record's problems: fix them` : `gp brief ${shown(paths.tz)}: the ${turn.who}'s turn (round ${turn.round}) — ${turn.why}`,
        seen: true,
      });
      if (owner)
        brief.push({ id: 'brief.owner', what: 'the owner\'s questions sent', required: false, state: existsSync(join(paths.work, b.BRIEF_OWNER)) ? 'pass' : 'todo', evidence: `${owner} question(s) for the owner${existsSync(join(paths.work, b.BRIEF_OWNER)) ? ` in ${at(join(paths.work, b.BRIEF_OWNER))}` : ''}`, next: `send the owner qa/${b.BRIEF_OWNER} (gp brief writes it when the loop is done)`, seen: true });
    }
  }

  // --- 1 Concept ---
  const con: GateCheck[] = [];
  con.push({
    id: 'concept.validate',
    what: 'game.yaml validates (gp validate)',
    required: true,
    state: errors.length ? 'fail' : 'pass',
    evidence: `${errors.length} error(s), ${warnings.length} warning(s)${errors.length ? `: ${[...new Set(errors.map((e) => e.code))].slice(0, 4).join(', ')}` : ''}`,
    next: errors.length ? `gp validate ${id}: fix the errors` : undefined,
    seen: true,
  });
  if (!portal) con.push(notPortal({ id: 'concept.hook', what: 'the hook in one sentence', required: true }));
  else {
    const pitch = str(concept.pitch);
    const different = str(concept.different);
    const closest = Array.isArray(concept.closest) ? concept.closest.filter((x) => typeof x === 'string' && x.trim() && !todoText(x)) : [];
    const hookOk = !todoText(pitch) && !todoText(different);
    con.push({
      id: 'concept.hook',
      what: 'the hook in one sentence and what differs (concept.pitch, concept.different)',
      required: true,
      state: hookOk ? 'pass' : raw.concept ? 'fail' : 'todo',
      evidence: hookOk ? `"${pitch.slice(0, 110)}${pitch.length > 110 ? '…' : ''}"` : raw.concept ? 'concept.pitch or concept.different is empty or TODO' : 'no concept in game.yaml',
      next: hookOk ? undefined : 'write concept.pitch (what the player does, one sentence) and concept.different (what the closest games don\'t do) — gp explain concept',
      seen: !!raw.concept,
    });
    con.push({
      id: 'concept.closest',
      what: 'the 3 closest portal games (concept.closest)',
      required: true,
      state: closest.length >= 3 ? 'pass' : raw.concept ? 'fail' : 'todo',
      evidence: closest.length ? closest.join(', ') : 'none named',
      next: closest.length >= 3 ? undefined : 'search the portal for the genre and the theme (site:crazygames.com <genre> <theme>) and name the 3 closest games',
      seen: !!raw.concept,
    });
    const hasMoney = !!raw.money;
    const genre = str(money.genre);
    con.push({
      id: 'concept.money',
      what: 'the genre and the money design (money: genre, session, breaks, rewarded, returns)',
      required: true,
      state: hasMoney && genre ? 'pass' : hasMoney ? 'fail' : 'todo',
      evidence: hasMoney ? `genre ${genre || '— (missing)'}${obj(money.session).minutes ? `, a ${obj(money.session).minutes}-min session with ${obj(money.session).breaks ?? '?'} break(s)` : ''}` : 'no money section in game.yaml',
      next: hasMoney && genre ? undefined : 'write `money` in game.yaml with money.genre (gp explain money, gp explain genres)',
      seen: hasMoney,
    });
    const notes = conceptNotesOf(loc);
    con.push({
      id: 'concept.ideas',
      what: 'the ideas searched and the runner-up\'s forecast (docs/concept.md)',
      required: true,
      state: !notes ? 'todo' : notes.todo ? 'fail' : 'pass',
      evidence: !notes ? 'no docs/concept.md' : `${at(notes.file)}${notes.todo ? ': TODO left' : ''}`,
      next: !notes ? 'write docs/concept.md (templates/game-repo/docs/concept.md): the ideas searched on the portal, the chosen one and the runner-up, each with `gp forecast --idea`' : notes.todo ? `fill the TODOs in ${shown(notes.file)}: the searches, the closest games, the runner-up's forecast` : undefined,
      seen: !!notes,
    });
    const fc = q('forecast.md');
    con.push({
      id: 'concept.forecast',
      what: 'the money forecast of the design (gp forecast → qa/forecast.md)',
      required: true,
      state: existsSync(fc) ? 'pass' : 'todo',
      evidence: existsSync(fc) ? `${at(fc)}${forecastLineOf(fc)}` : 'no qa/forecast.md',
      next: existsSync(fc) ? undefined : `gp forecast ${id}`,
      seen: existsSync(fc),
    });
    const un = uniquenessOf(q('uniqueness.md'));
    con.push({
      id: 'concept.uniqueness',
      what: 'uniqueness ≥ 70 (gp uniqueness)',
      required: true,
      state: !un ? 'todo' : un.score >= 70 && !un.gate ? 'pass' : 'fail',
      evidence: !un ? 'no qa/uniqueness.md' : `${at(un.file)}: ${un.score}/100 — ${un.verdict}`,
      next: !un ? `gp uniqueness ${id}` : un.score >= 70 && !un.gate ? undefined : 'change the game (the core action, the goal, a rule), not the text — qa/uniqueness.md says what',
      seen: !!un,
    });
    // The concept's review by another agent: the ТЗ critic covered it; without a ТЗ, the same loop on docs/concept.md
    const briefDone = brief[0]?.id === 'brief.loop' && brief[0].state === 'pass';
    const cr = notes ? conceptReviewOf(b, notes.file) : null;
    con.push({
      id: 'concept.review',
      what: 'the concept reviewed by an agent who didn\'t make it (the ТЗ critic, or gp brief docs/concept.md)',
      required: false,
      state: briefDone || cr?.ok ? 'pass' : cr ? 'fail' : 'todo',
      evidence: briefDone ? 'the ТЗ review covered originality and money' : cr ? `${at(cr.record)}: ${cr.summary}` : 'no review of the concept',
      next: briefDone || cr?.ok ? undefined : 'advised: gp brief docs/concept.md — the critic asks about originality and money before anything is built',
      seen: briefDone || !!cr,
    });
  }

  // --- The last QA run (gp qa) ---
  const qa = readJson<QaResults>(q('qa-results.json'));
  const qaAt = qa ? `qa/qa-results.json · ${String(qa.date).slice(0, 10)} (${qa.mode ?? 'full'})` : '';
  const scope = (s: string) => (qa?.checks ?? []).filter((c) => c.scope === s);
  const infos = (re: RegExp) => (qa?.infos ?? []).filter((i) => re.test(i.scope) || re.test(i.name));

  // --- 2 Vertical slice ---
  const slice: GateCheck[] = [];
  {
    const { readFirstLook, FIRST_LOOK_BRIEF } = await import('./first-look.ts');
    const { file, look } = readFirstLook(loc);
    const base = { id: 'slice.firstLook', what: `the blind first look: keep playing ≥ ${FIRST_LOOK_PASS}/5 and the goal told (gp review --first-look)`, required: crazy, enforced: crazy };
    if (!portal) slice.push(notPortal(base));
    else if (!look) slice.push({ ...base, state: 'todo', evidence: 'no qa/first-look.md', next: `gp review ${id} --first-look → give qa/${FIRST_LOOK_BRIEF}, and nothing else, to an agent who knows nothing about the game`, seen: false });
    else {
      const stale = mtime(file) < sourceMs ? ' (older than the code: a new blind look once the first 30 s change)' : '';
      const low = look.ok && ((look.keep ?? 0) < FIRST_LOOK_PASS || look.goalUnknown);
      slice.push({
        ...base,
        state: !look.ok || low ? 'fail' : 'pass',
        evidence: !look.ok ? `${at(file)}: malformed — ${look.problems[0]?.message ?? ''}` : `${at(file)}: keep playing ${look.keep}/5${look.goalUnknown ? ', the goal not told' : `, goal "${look.goal.slice(0, 70)}"`}${stale}`,
        next: !look.ok
          ? `rewrite qa/first-look.md in the format of qa/${FIRST_LOOK_BRIEF}`
          : low
            ? `change the first 30 s (gp lessons → first-minute: a fight or a score in the first seconds, the goal on screen, a choice by 0:30), then a new blind agent: gp review ${id} --first-look`
            : undefined,
        seen: true,
      });
    }
    const twist = obj(concept.twist);
    const tw = readJson<{ at?: string; declared?: boolean; seenSec?: number | null; within?: number; event?: string; explained?: { ok?: boolean; phrase?: string } }>(q('uniqueness.json'));
    const tbase = { id: 'slice.twist', what: 'the twist happens in play, early, and is explained (gp qa)', required: portal };
    if (!portal) slice.push(notPortal(tbase));
    else if (!str(twist.event)) slice.push({ ...tbase, state: 'fail', evidence: 'no concept.twist in game.yaml (W_TWIST_MISSING)', next: 'declare concept.twist { event, within, explained } and call host.twist(event) where it happens (docs/guides/uniqueness.md)', seen: false });
    else if (!tw || tw.declared === false) slice.push({ ...tbase, state: 'todo', evidence: tw ? 'the last gp qa ran before concept.twist was declared' : 'not measured yet (qa/uniqueness.json)', next: `gp qa ${id}: the demo bot plays and the twist must fire within ${twist.within ?? 30} s`, seen: false });
    else {
      const seen = typeof tw.seenSec === 'number';
      const expl = tw.explained ? tw.explained.ok !== false : true;
      slice.push({
        ...tbase,
        state: seen && expl ? 'pass' : 'fail',
        evidence: `qa/uniqueness.json · ${str(tw.at).slice(0, 10)}: "${tw.event}" ${seen ? `at ${tw.seenSec!.toFixed(1)} s (within ${tw.within} s)` : `not within ${tw.within} s`}${tw.explained ? `, explained ${expl ? '✓' : '✗'} ("${tw.explained.phrase}")` : twist.explained ? '' : ', no concept.twist.explained (W_TWIST_UNEXPLAINED)'}`,
        next: seen && expl ? undefined : !seen ? 'make the twist happen in the first run (host.twist where it fires; the demo bot must meet it), then gp qa' : 'show the twist\'s words on screen before or when it fires, long enough to read (docs/guides/uniqueness.md#the-explanation)',
        seen: true,
      });
    }
    const feel = scope('feel');
    const feelWarn = (qa?.infos ?? []).filter((i) => i.scope === 'feel' && i.warn);
    const feelFile = q('feel.json');
    const fbase = { id: 'slice.feel', what: 'the core verb answers and feels (gp qa feel section)', required: true };
    if (!qa || (!feel.length && !existsSync(feelFile))) slice.push({ ...fbase, state: 'todo', evidence: qa ? `${qaAt}: no feel section (a --quick run?)` : 'no QA run yet', next: `gp qa ${id} (the full run has the feel section)`, seen: false });
    else {
      const failed = feel.filter((c) => !c.ok);
      slice.push({
        ...fbase,
        state: failed.length ? 'fail' : 'pass',
        evidence: `${qaAt}: ${feel.length - failed.length}/${feel.length} feel check(s)${failed.length ? ` — failed: ${failed.map((c) => c.name).join('; ')}` : ''}${feelWarn.length ? ` · ${feelWarn.length} warning(s): ${feelWarn.map((w) => w.name.replace(/^feel:\s*/, '')).join(', ')}` : ''}`,
        next: failed.length ? 'fix the failed feel checks (qa/report.md says how)' : undefined,
        seen: true,
      });
    }
  }

  // --- 3 First session ---
  const sess: GateCheck[] = [];
  {
    const fm = scope('first minute');
    const failed = fm.filter((c) => !c.ok);
    sess.push({
      id: 'session.firstMinute',
      what: 'a new player\'s first minute (gp qa first-minute section)',
      required: true,
      state: !fm.length ? 'todo' : failed.length ? 'fail' : 'pass',
      evidence: !fm.length ? (qa ? `${qaAt}: no first-minute section` : 'no QA run yet') : `${qaAt}: ${fm.length - failed.length}/${fm.length} green${failed.length ? ` — failed: ${failed.map((c) => c.name).join('; ').slice(0, 300)}` : ''}`,
      next: !fm.length ? `gp qa ${id}` : failed.length ? 'fix the first minute (docs/guides/first-minute.md)' : undefined,
      seen: fm.length > 0,
    });
    const s = readJson<{ at?: string; playedSec?: number; short?: boolean; lines?: { stop?: string; estimate?: string } }>(q('session.json'));
    const sbase = { id: 'session.tenMin', what: `the first natural stop after ${SESSION_GATE_MIN} min of play (gp qa session; W_SESSION_SHORT)`, required: crazy };
    if (!s) sess.push({ ...sbase, state: 'todo', evidence: 'no qa/session.json', next: `gp qa ${id} (the full run plays a new player's session)`, seen: false });
    else {
      const reached = (s.playedSec ?? 0) >= SESSION_GATE_MIN * 60;
      sess.push({
        ...sbase,
        state: s.short ? 'fail' : reached ? 'pass' : 'todo',
        evidence: `qa/session.json · ${str(s.at).slice(0, 10)}: first stop ${s.lines?.stop ?? '?'}${s.lines?.estimate ? ` — ${s.lines.estimate}` : ''}`,
        next: s.short ? 'push the first natural stop past 10 min: auto-continue into the next run (mountResults autoContinueSec), the next goal on the results, a meta reward every 2–3 min (docs/guides/first-minute.md → The session)' : reached ? undefined : `the full gp qa ${id} plays 15 min (a --quick run plays less)`,
        seen: true,
      });
    }
    const bbase = { id: 'session.balance', what: 'the progression curve (gp qa balance section: balance(), balanceModel())', required: kit === 'code' };
    if (kit !== 'code') sess.push({ ...bbase, state: 'na', evidence: `kit ${kit || '?'}: no balance bot`, seen: false });
    else {
      const bc = scope('balance');
      const bf = bc.filter((c) => !c.ok);
      const none = infos(/^balance$/).some((i) => i.scope === 'balance' && /exports no balance\(\)/.test(i.details));
      sess.push({
        ...bbase,
        state: !qa ? 'todo' : bf.length ? 'fail' : bc.length ? 'pass' : none ? 'fail' : 'todo',
        evidence: !qa ? 'no QA run yet' : bc.length ? `${qaAt}: ${bc.length - bf.length}/${bc.length} balance check(s)${bf.length ? ` — failed: ${bf.map((c) => c.name).join('; ').slice(0, 240)}` : ''}` : none ? `${qaAt}: the game exports no balance() — its curve is not checked` : `${qaAt}: no balance section`,
        next: bf.length ? `gp balance ${id}: fix the curve (docs/guides/upgrades.md)` : bc.length ? undefined : 'export balance() (and balanceModel()) from bot.ts, then gp qa (docs/guides/upgrades.md#3-the-balance-report)',
        seen: !!qa && (bc.length > 0 || none),
      });
    }
  }

  // --- 4 Content and meta ---
  const content: GateCheck[] = [];
  {
    const design = await import('./design.ts');
    const f = join(loc.dir, design.DESIGN_FILE);
    if (!existsSync(f))
      content.push({ id: 'content.design', what: 'a design round (gp design → design.md, by a designer agent)', required: portal, state: portal ? 'todo' : 'na', evidence: 'no design.md', next: `gp design ${id} → give qa/${design.DESIGN_BRIEF} to a designer agent (one who didn't make the game); build its Top 3`, seen: false });
    else {
      const rep = design.parseDesign(readFileSync(f, 'utf8'), { title });
      content.push({
        id: 'content.design',
        what: 'a design round (gp design → design.md, by a designer agent)',
        required: portal,
        state: rep.ok ? 'pass' : 'fail',
        evidence: `${shown(f)} · ${designDate(f)}: ${rep.ok ? design.designSummary(rep) : `${rep.problems.length} problem(s) — gp design ${id} --check`}`,
        next: rep.ok ? undefined : `gp design ${id} --check lists what to fix in design.md`,
        seen: true,
      });
    }
    const ret = obj(money.returns);
    const kind = str(ret.kind) || str(money.returns);
    content.push(
      !portal
        ? notPortal({ id: 'content.return', what: 'a reason to come back tomorrow (money.returns)', required: true })
        : {
            id: 'content.return',
            what: 'a reason to come back tomorrow (money.returns)',
            required: true,
            state: kind && kind !== 'none' ? 'pass' : raw.money ? 'fail' : 'todo',
            evidence: kind ? `${kind}${str(ret.what) ? `: ${str(ret.what).slice(0, 100)}` : ''}` : 'no money.returns',
            next: kind && kind !== 'none' ? undefined : 'give D1 a reason: a daily (dailyStreak, dailyOrder, dailyTable), a meta with the next goal named, a season (docs/guides/first-minute.md)',
            seen: false,
          },
    );
    const expects = issues.find((i) => i.code === 'I_GENRE_EXPECTS');
    content.push(
      kit !== 'code'
        ? { id: 'content.mustHaves', what: 'the genre\'s must-haves', required: false, state: 'na', evidence: `kit ${kit || '?'}: the kit has them`, seen: false }
        : !str(money.genre)
          ? { id: 'content.mustHaves', what: 'the genre\'s must-haves (I_GENRE_EXPECTS)', required: portal, state: 'todo', evidence: 'no money.genre', next: 'name the genre: money.genre (gp catalog genres)', seen: false }
          : {
              id: 'content.mustHaves',
              what: 'the genre\'s must-haves (I_GENRE_EXPECTS)',
              required: portal,
              state: expects ? 'fail' : 'pass',
              evidence: expects ? expects.message.slice(0, 240) : `every must-have of ${str(money.genre)} met or covered (money.covers)`,
              next: expects ? `build them from the blocks (gp catalog blocks --genre ${str(money.genre)}), or say where the game's own code has one: money.covers` : undefined,
              seen: false,
            },
    );
    const variety = (qa?.infos ?? []).find((i) => i.name === 'feel: variety over time');
    content.push({
      id: 'content.variety',
      what: 'something new every minute or two (gp qa feel: variety over time)',
      required: portal,
      state: !variety ? (portal ? 'todo' : 'na') : variety.warn ? 'fail' : /not measured|not called|not counted/.test(variety.details) ? 'todo' : 'pass',
      evidence: !variety ? (qa ? `${qaAt}: not measured` : 'no QA run yet') : `${qaAt}: ${variety.details.slice(0, 220)}`,
      next: !variety ? `gp qa ${id} (the full run's feel section)` : variety.warn ? 'bring in a new enemy, item or place every minute or so (gp lessons → variety)' : /not measured|not called|not counted/.test(variety.details) ? 'call host.seen(kind, id) when the player meets something new, and give the game a demo bot (host.qa({ demo }))' : undefined,
      seen: false,
    });
  }

  // --- 5 Release candidate ---
  const release: GateCheck[] = [];
  {
    const full = qa && (qa.mode ?? 'full') === 'full';
    const qaStale = qa ? Date.parse(qa.date) < sourceMs : false;
    release.push({
      id: 'release.qa',
      what: 'the full gp qa all green, on the current code',
      required: true,
      state: !qa ? 'todo' : qa.failed > 0 ? 'fail' : !full ? 'todo' : qaStale ? 'fail' : 'pass',
      evidence: !qa ? 'no QA run yet' : `${qaAt}: ${qa.passed} passed, ${qa.failed} failed${qaStale ? ` — older than the code (changed ${day(sourceMs)})` : ''}`,
      next: !qa ? `gp qa ${id}` : qa.failed > 0 ? `fix the failures (qa/report.md), gp qa ${id} --failed, then the full run` : !full ? `the full gp qa ${id} (the last run was ${qa.mode})` : qaStale ? `the code changed after the run: gp qa ${id} again` : undefined,
      // A QA run is the evidence of phases 2 and 3: it runs from the first playable build, so it isn't phase-5 work
      seen: false,
    });
    if (!portal) release.push(notPortal({ id: 'release.review', what: 'the quality review (gp review --check)', required: true }));
    else {
      const { qualityGate } = await import('./review.ts');
      const gate = qualityGate(loc, { title, channel: { id: channel } as ResolvedGame['channel'], kit: { kit } as ResolvedGame['kit'], ...(game ? { sound: game.sound } : {}) });
      release.push({
        id: 'release.review',
        what: 'the quality review: quality.md with no [blocking] finding (gp review --check)',
        required: true,
        state: !gate.exists ? 'todo' : gate.ok ? 'pass' : 'fail',
        evidence: gate.exists ? `${at(gate.file)}: ${gate.detail}` : 'no quality.md',
        next: gate.ok ? undefined : gate.exists ? gate.detail : `gp review ${id} (after the full gp qa) → give qa/review-brief.md to a second agent (a reviewer who didn't make the game)`,
        seen: gate.exists,
      });
      const store = join(loc.dir, 'store');
      const media = ['cover-1920x1080.png', 'cover-800x1200.png', 'cover-800x800.png', 'preview-1920x1080.mp4', 'preview-1080x1920.mp4'].map((m) => join(store, m));
      const have = media.filter((m) => existsSync(m));
      const old = have.filter((m) => mtime(m) < sourceMs);
      release.push({
        id: 'release.media',
        what: 'the covers and the preview videos, newer than the code (gp covers, gp video)',
        required: false,
        state: have.length < media.length ? 'todo' : old.length ? 'fail' : 'pass',
        evidence: `${have.length}/${media.length} in store/${old.length ? `, ${old.length} older than the code` : ''}${existsSync(join(store, 'cover-check.md')) ? ` · ${shown(join(store, 'cover-check.md'))}` : ''}`,
        next: have.length < media.length || old.length ? `gp covers ${id} and gp video ${id} (gp submission renders them too); look at them` : undefined,
        seen: have.length > 0,
      });
      const zip = submissionZip(loc);
      release.push({
        id: 'release.submission',
        what: 'the submission folder and its zip, newer than the code (gp submission)',
        required: true,
        state: !zip ? 'todo' : zip.ms < sourceMs ? 'fail' : 'pass',
        evidence: zip ? `${shown(zip.file)} · ${day(zip.ms)}${zip.ms < sourceMs ? ` — older than the code (changed ${day(sourceMs)})` : ''}` : 'no submission zip',
        next: !zip || zip.ms < sourceMs ? `gp submission ${id} → send the owner the zip with REPORT.md` : undefined,
        seen: !!zip,
      });
    }
  }

  // --- 6 Live ---
  const live: GateCheck[] = [];
  if (!portal) live.push(notPortal({ id: 'live.answer', what: 'the portal\'s answer', required: true }));
  else {
    const { loadResults } = await import('./forecast.ts');
    const design = await import('./design.ts');
    const results = input.results ?? loadResults().results;
    const repo = input.repo !== undefined ? input.repo : gameRepo(loc.dir);
    const own = design.ownResults(results, { id, title }, loc, repo);
    const updates = (input.updates ?? design.loadUpdates()).filter((u) => u.game === id || u.game === loc.id || (repo && u.repo && u.repo.toLowerCase() === repo.toLowerCase()));
    live.push(...liveChecks(own, updates, { id, today, designFile: join(loc.dir, design.DESIGN_FILE) }));
  }

  const defs = PHASES;
  const lists = [brief, con, slice, sess, content, release, live];
  const phases: PhaseResult[] = defs.map((def, i) => ({ def, checks: lists[i], state: phaseState(lists[i]), started: lists[i].some((c) => c.seen) }));
  return assemble({ id, title, channel, date: today, phases });
}

/** The phase's state from its checks: na when nothing applies, fail if a required check fails, todo if one is missing */
export function phaseState(checks: readonly GateCheck[]): CheckState {
  const req = checks.filter((c) => c.required && c.state !== 'na');
  if (!req.length) return checks.some((c) => c.state !== 'na') ? 'pass' : 'na';
  if (req.some((c) => c.state === 'fail')) return 'fail';
  if (req.some((c) => c.state === 'todo')) return 'todo';
  return 'pass';
}

const met = (s: CheckState) => s === 'pass' || s === 'na';

/** The current phase, how far the work has gone, the gates left behind and the next action */
export function assemble(r: Pick<StageReport, 'id' | 'title' | 'channel' | 'date' | 'phases'>): StageReport {
  const current = r.phases.find((p) => !met(p.state)) ?? null;
  // A phase counts as reached by its own files only (design.md, quality.md, the store, a zip, a portal record): a QA run,
  // which starts with the first playable build, reaches phase 3 at most
  const reached = Math.max(-1, ...r.phases.filter((p) => p.started).map((p) => p.def.n));
  // Phases 1–3 overlap while the slice is built (gp qa measures 2 and 3 from the first playable build); from content and
  // meta on (phase 4: design.md, quality.md, the store, a zip, a record), an open gate before it is flagged
  const behind = reached >= 4 ? r.phases.filter((p) => p.def.n < reached && !met(p.state)) : [];
  const first = current?.checks.find((c) => c.required && !met(c.state));
  const next = !current ? 'every gate is met: watch the next score screen and record it in publisher/results.yaml' : first?.next ?? `phase ${current.def.n}: ${current.def.exit}`;
  return { ...r, current, reached, behind, next };
}

/** One line for gp qa, gp build, gp design and gp review */
export function stageLine(rep: StageReport): string {
  const c = rep.current;
  return c ? `GDLC: phase ${c.def.n} ${c.def.name} (${c.state === 'fail' ? 'gate not met' : 'gate not yet met'}) — next: ${rep.next}` : 'GDLC: every gate met';
}

/**
 * The warning when the game is built past the slice without a passed phase-2 gate: work of phase 4 or later exists (or
 * the command doing it, `entering`), and the blind first look is missing, low or malformed. null when fine
 */
export function sliceWarning(rep: StageReport, entering = -1): string | null {
  const slice = rep.phases[2];
  if (met(slice.state) || Math.max(rep.reached, entering) < 4) return null;
  const fl = slice.checks.find((c) => c.id === 'slice.firstLook');
  const why = fl && !met(fl.state) ? `the blind first look: ${fl.evidence}` : slice.checks.filter((c) => c.required && !met(c.state)).map((c) => `${c.what}: ${c.evidence}`).join('; ');
  const next = (fl && !met(fl.state) ? fl.next : slice.checks.find((c) => c.required && !met(c.state))?.next) ?? '';
  return `⚠ GDLC: ${rep.id} is built past the vertical slice (phase 2) without its gate — ${why}. Content and polish on a first 30 s a stranger wouldn't stay for is the work CrazyGames' conversion score throws away (Candle Crypt: a first look of 3/5, conversion 1/5). ${next}`;
}

// --- Phase 6: the portal's answers ----------------------------------------------------------------------------------

const addDays = (d: string, n: number) => new Date(Date.parse(`${d}T00:00:00Z`) + n * 86400000).toISOString().slice(0, 10);
const daysBetween = (a: string, b: string) => Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86400000);

/** The weakest metric of each device class on a score screen: "desktop 7/15: conversion 1/5 weakest" */
export function weakestMetrics(scores: NonNullable<NonNullable<RecordedResult['basicLaunch']>['scores']>): { device: string; metric: string; score: number; total: number | null }[] {
  const out: { device: string; metric: string; score: number; total: number | null }[] = [];
  for (const device of ['desktop', 'mobile'] as const) {
    const d = scores[device];
    if (!d) continue;
    const m = (['playtime', 'd1', 'conversion'] as const).map((k) => ({ k, s: d[k]?.score })).filter((x): x is { k: 'playtime' | 'd1' | 'conversion'; s: number } => typeof x.s === 'number');
    if (!m.length) continue;
    const w = m.reduce((a, b) => (b.s < a.s ? b : a));
    out.push({ device, metric: w.k === 'd1' ? 'D1' : w.k, score: w.s, total: d.total ?? null });
  }
  return out;
}

/** design.md's own date ("Date: 2026-10-20" in its header), else the file's */
export function designDate(file: string): string {
  const m = readFileSync(file, 'utf8').slice(0, 600).match(/\bDate:\s*(\d{4}-\d{2}-\d{2})/);
  return m ? m[1] : day(mtime(file));
}

/** Phase 6's checks from the game's records (the newest answer), its patches and design.md's date */
export function liveChecks(own: readonly RecordedResult[], updates: readonly { version: string; date?: string; uploaded?: string }[], o: { id: string; today: string; designFile: string }): GateCheck[] {
  const L: GateCheck[] = [];
  const rec = [...own].sort((a, b) => (a.review?.date ?? '').localeCompare(b.review?.date ?? '')).at(-1);
  const where = 'publisher/results.yaml';
  if (!rec || !rec.review || rec.review.verdict === 'pending') {
    L.push({ id: 'live.answer', what: 'the portal\'s answer recorded', required: true, state: 'todo', evidence: rec ? `${where}: ${rec.title ?? rec.game} — waiting for the review${rec.submitted ? ` (submitted ${rec.submitted})` : ''}` : `no record of ${o.id} in ${where}`, next: rec ? 'wait for the portal\'s answer, then record it in publisher/results.yaml' : 'send the owner the submission zip; when the portal answers, record it in publisher/results.yaml (forecast.md has the lines)', seen: !!rec });
    return L;
  }
  const v = rec.review;
  const dated = v.date ? ` ${v.date}` : '';
  const design = existsSync(o.designFile) ? designDate(o.designFile) : null;
  if (v.verdict === 'rejected') {
    L.push({ id: 'live.answer', what: 'the portal\'s answer recorded', required: true, state: 'fail', evidence: `${where}: rejected${dated} — "${v.reason ?? '?'}"`, next: `gp design ${o.id}: what a resubmission changes ("as a new game including significant improvements"), then the loop from the slice (gp submission --full)`, seen: true });
    const after = !!design && !!v.date && design >= v.date;
    L.push({ id: 'live.nextRound', what: 'a design round after the answer (gp design)', required: true, state: after ? 'pass' : 'todo', evidence: design ? `design.md · ${design}${after ? '' : ` — before the answer (${v.date})`}` : 'no design.md', next: after ? undefined : `gp design ${o.id} → a designer agent's design.md after the rejection`, seen: !!design });
    return L;
  }
  L.push({ id: 'live.answer', what: 'the portal\'s answer recorded', required: true, state: 'pass', evidence: `${where}: approved${dated}`, seen: true });
  const bl = rec.basicLaunch ?? {};
  const scores = bl.scores;
  const weak = scores ? weakestMetrics(scores) : [];
  const weakText = weak.map((w) => `${w.device}${w.total !== null ? ` ${w.total}/15` : ''}: ${w.metric} ${w.score}/5 weakest`).join(' · ');
  const start = v.date ?? null;
  const verdict = bl.verdict ?? 'pending';
  const closed = verdict !== 'pending';
  const end = start ? (closed && scores?.date && scores.date >= start ? scores.date : addDays(start, BASIC_LAUNCH_DAYS)) : null;
  if (verdict === 'full-launch') {
    L.push({ id: 'live.metrics', what: 'the Basic Launch read', required: true, state: 'pass', evidence: `Full Launch${weakText ? ` · ${weakText}` : ''}`, seen: true });
    L.push({ id: 'live.nextRound', what: 'a design round on the weakest metric', required: false, state: design ? 'pass' : 'todo', evidence: design ? `design.md · ${design}` : 'no design.md', next: design ? undefined : `gp design ${o.id}: the next update`, seen: !!design });
    return L;
  }
  L.push({
    id: 'live.metrics',
    what: 'the Basic Launch score screen recorded (basicLaunch.scores)',
    required: true,
    state: weak.length ? 'pass' : closed ? 'fail' : 'todo',
    evidence: weak.length ? `${where} · ${scores?.date ?? '?'}: ${weakText}` : `Basic Launch ${verdict}${start ? ` since ${start}` : ''}, no score screen recorded`,
    next: weak.length ? undefined : 'write the dashboard\'s score screen into publisher/results.yaml (basicLaunch.scores: each metric\'s value and score per device)',
    seen: true,
  });
  const ref = scores?.date ?? null;
  const after = !!design && !!ref && design >= ref;
  L.push({
    id: 'live.nextRound',
    what: 'a design round after the scores, on the weakest metric (gp design)',
    required: !!ref,
    state: !ref ? 'todo' : after ? 'pass' : 'todo',
    evidence: design ? `design.md · ${design}${ref && !after ? ` — before the score screen (${ref})` : ''}` : 'no design.md',
    next: after ? undefined : `gp design ${o.id}${weak[0] ? `: the weakest metric is ${weak[0].device} ${weak[0].metric} (${weak[0].score}/5)` : ''}`,
    seen: !!design,
  });
  if (start && end) {
    const inside = updates.filter((u) => {
      const when = u.uploaded ?? u.date;
      return !!when && when > start && when <= end;
    });
    const open = o.today <= end && !closed;
    const left = daysBetween(o.today, end);
    L.push({
      id: 'live.patch',
      what: `a patch uploaded inside the Basic Launch window (${start} → ${end})`,
      required: true,
      state: inside.length ? 'pass' : open ? 'todo' : 'fail',
      evidence: inside.length ? `publisher/updates.yaml: ${inside.map((u) => `${u.version} (${u.uploaded ?? u.date})`).join(', ')}` : open ? `no patch yet — ${left} day(s) left` : 'no patch uploaded inside the window',
      next: inside.length ? undefined : open ? `build design.md's Top 3${weak[0] ? ` for ${weak[0].device} ${weak[0].metric}` : ''}, gp submission, and have the owner upload it before ${end} (Garage Evolution's 1.4.0 went live after its window closed: the scores never saw it)` : 'the window closed: the next version is a resubmission (gp design, then gp submission --full)',
      seen: inside.length > 0,
    });
  }
  return L;
}

// --- Small readers ---------------------------------------------------------------------------------------------------

/** docs/concept.md beside the game (a gp init repository: games/<id>/ → ../../docs/concept.md; or the game's own docs/) */
export function conceptNotesOf(loc: GameLocation): { file: string; todo: boolean } | null {
  const repo = basename(dirname(loc.dir)) === 'games' ? dirname(dirname(loc.dir)) : null;
  const tried = [...(repo ? [join(repo, 'docs', 'concept.md')] : []), join(loc.dir, 'docs', 'concept.md'), join(loc.dir, 'concept.md')];
  const file = tried.find((f) => existsSync(f));
  return file ? { file, todo: /\bTODO\b/.test(readFileSync(file, 'utf8')) } : null;
}

/** The concept's own review loop (gp brief docs/concept.md → docs/concept-review.md), when it was run */
function conceptReviewOf(b: typeof import('./brief.ts'), concept: string): { record: string; ok: boolean; summary: string } | null {
  const record = b.recordOf(concept);
  if (!existsSync(record)) return null;
  // Where gp brief keeps that loop's round copies (the game's qa/, else qa/ beside the file)
  const paths = b.locateBrief(concept);
  const rec = b.checkRecord(readFileSync(record, 'utf8'), { tz: readFileSync(concept, 'utf8'), snapshots: b.loadSnapshots(paths) });
  const ok = !rec.problems.length && b.nextTurn(rec, rec.cap).who === 'done';
  return { record, ok, summary: `${b.stateSummary(rec)}${ok ? ' · closed' : ' · open'}` };
}

function forecastLineOf(file: string): string {
  const t = readFileSync(file, 'utf8');
  const m = t.match(/expected value[^\n]{0,160}/i);
  return m ? ` — ${m[0].replace(/\*\*/g, '').trim().slice(0, 140)}` : '';
}

function uniquenessOf(file: string): { file: string; score: number; verdict: string; gate: boolean } | null {
  if (!existsSync(file)) return null;
  const m = readFileSync(file, 'utf8').match(/\*\*Score (\d+)\/100 — ([^*]+)\*\*([^\n]*)/);
  if (!m) return null;
  return { file, score: Number(m[1]), verdict: m[2].trim(), gate: /Gate:/.test(m[3]) };
}

/** The newest `<id>-<version>-submission.zip` / `-update.zip` beside the game */
function submissionZip(loc: GameLocation): { file: string; ms: number } | null {
  if (!existsSync(loc.dir)) return null;
  const zips = readdirSync(loc.dir)
    .filter((f) => /-(submission|update)\.zip$/.test(f))
    .map((f) => ({ file: join(loc.dir, f), ms: mtime(join(loc.dir, f)) }))
    .sort((a, b) => b.ms - a.ms);
  return zips[0] ?? null;
}

// --- The report ------------------------------------------------------------------------------------------------------

const MARK: Record<CheckState, string> = { pass: '✓', fail: '✗', todo: '·', na: '–' };
const STATE: Record<CheckState, string> = { pass: 'met', fail: 'not met', todo: 'not yet', na: 'n/a' };

export function stageMarkdown(rep: StageReport): string {
  const L: string[] = [`# ${rep.title} — design lifecycle (GDLC)`, ''];
  L.push(`Written by \`gp stage ${rep.id}\` on ${rep.date} from the files the other commands wrote (nothing rerun). Channel ${rep.channel}. The phases and why each gate exists: docs/guides/gdlc.md.`, '');
  L.push(rep.current ? `**Phase ${rep.current.def.n} — ${rep.current.def.name}:** ${rep.current.def.question}` : '**Every gate is met.**', '');
  L.push(`**Next:** ${rep.next}`, '');
  for (const b of rep.behind) L.push(`> ⚠ Built past phase ${b.def.n} (${b.def.name}) without its gate: the work of phase ${rep.reached} rests on it — ${b.checks.filter((c) => c.required && !met(c.state)).map((c) => c.what).join('; ')}.`, '');
  L.push('| # | Phase | Gate | Checks |', '|---|---|---|---|');
  for (const p of rep.phases) {
    const req = p.checks.filter((c) => c.required && c.state !== 'na');
    L.push(`| ${p.def.n} | ${p.def.name}${rep.current === p ? ' ◀' : ''} | ${MARK[p.state]} ${STATE[p.state]} | ${req.filter((c) => c.state === 'pass').length}/${req.length} |`);
  }
  L.push('');
  for (const p of rep.phases) {
    L.push(`## ${p.def.n} ${p.def.name} — ${STATE[p.state]}`, '', `*${p.def.question}* Exit: ${p.def.exit}. Review: ${p.def.review}.`, '');
    for (const c of p.checks) {
      L.push(`- ${MARK[c.state]} **${c.what}**${c.required ? '' : ' (advice)'}${c.enforced && c.required ? ' (gp submission refuses without it)' : ''} — ${c.evidence.replace(/\|/g, '\\|')}`);
      if (c.next && !met(c.state)) L.push(`  → ${c.next}`);
    }
    L.push('');
  }
  return L.join('\n');
}

/** Terminal lines: the phase table and the next action */
export function stageLines(rep: StageReport): string[] {
  const L: string[] = [];
  for (const p of rep.phases) {
    L.push(`${MARK[p.state]} ${p.def.n} ${p.def.name.padEnd(30)} ${STATE[p.state].padEnd(8)}${rep.current === p ? ' ◀ the game is here' : ''}`);
    for (const c of p.state === 'na' ? [] : p.checks) if (c.required || c.state === 'fail') L.push(`    ${MARK[c.state]} ${c.what} — ${c.evidence}`);
  }
  for (const b of rep.behind) L.push(`⚠ built past phase ${b.def.n} (${b.def.name}) without its gate`);
  L.push(`Next: ${rep.next}`);
  return L;
}

// --- Enforcement: gp submission ----------------------------------------------------------------------------------------

/**
 * The GDLC gates `gp submission` enforces (keep it light: the rest is reported): the ТЗ review loop when there is a ТЗ
 * (phase 0) and, on CrazyGames, the blind first look ≥ 4/5 with the goal told (phase 2). An update to a live game (not
 * --full) gets the first look as a warning, not a refusal: a patch inside the Basic Launch window must not wait for it.
 */
export function submissionGates(rep: StageReport, o: { update: boolean }): { ok: boolean; detail: string } {
  const enforced = rep.phases.flatMap((p) => p.checks.filter((c) => c.enforced && c.required && !met(c.state)).map((c) => ({ p, c })));
  const refuse = enforced.filter(({ c }) => !(o.update && c.id === 'slice.firstLook'));
  const warned = enforced.filter((x) => !refuse.includes(x));
  const others = rep.phases.filter((p) => p.def.n < 5 && !met(p.state) && !enforced.some((x) => x.p === p)).map((p) => `${p.def.n} ${p.def.name}`);
  if (refuse.length)
    return { ok: false, detail: `${refuse.map(({ p, c }) => `phase ${p.def.n} (${p.def.name}): ${c.evidence} → ${c.next ?? c.what}`).join('; ')} — gp stage ${rep.id}` };
  const parts = [
    `phase 0 ${met(rep.phases[0].state) ? (rep.phases[0].state === 'na' ? 'n/a (no ТЗ)' : '✓') : '✗'}`,
    `phase 2 first look ${warned.length ? `✗ (an update: a warning — ${warned[0].c.evidence})` : met(rep.phases[2].checks.find((c) => c.id === 'slice.firstLook')?.state ?? 'na') ? '✓' : '·'}`,
    ...(others.length ? [`not enforced, still open: ${others.join(', ')} (gp stage ${rep.id})`] : []),
  ];
  return { ok: true, detail: parts.join(' · ') };
}
