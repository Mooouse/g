// `gp review`: a quality review by a second agent before the portal submission, and its result, games/<id>/quality.md.
//
// CrazyGames rejected three of our games on 2026-10-01 with "The overall quality of the game does not yet meet the
// expectations of our platform" (Yeet the Gnome, Brew & Banter, Germ Line — publisher/results.yaml). No automatic check
// measures "quality", so the platform does what it can: it assembles a brief for a reviewer who didn't make the game —
// the portal's quality requirements as a checklist (each with its source line in the research), what the platform
// already knows about the game (concept, money, story, uniqueness, forecast, size, QA and where its screenshots and
// videos are), and the traits of the games the portal has answered for, as data. The reviewer writes quality.md in a
// fixed format; `gp submission` refuses to complete while it is missing, malformed or has a [blocking] finding.
//
//   games/<id>/qa/review-brief.md   written by gp review (regenerated, not committed: qa/ is rebuilt by gp qa)
//   games/<id>/quality.md           written by the reviewer (committed; copied into submission/ when it passes)

import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { artSpec } from './art.ts';
import { lessonsSection } from './lessons.ts';
import { iconGlyphs } from '@gp/qa/glyphs';
import { BASIC_LAUNCH, deviceTotal, hasMusic, recordsOf, SCOPE_MAX_SCREENS, sourceHasMusic, type Issue, type RecordedResult, type ResolvedGame } from '@gp/spec';
import { gameRepo, newestSourceMs, ROOT, shown, staleMedia, type GameLocation } from './paths.ts';
import { SCORED_SCREENS, SHEET_FILE, type ReviewSheet } from './review-sheet.ts';
import { FIRST_LOOK_BRIEF, FIRST_LOOK_FILE, FIRST_LOOK_LOW, NAMES_FIRST_LOOK, firstLookAlarm, readFirstLook, type FirstLook } from './first-look.ts';
import { samenessSection } from './sameness.ts';

export const QUALITY_FILE = 'quality.md';
export const BRIEF_FILE = 'review-brief.md';
export const RESEARCH_FILE = join(ROOT, 'docs/research/crazygames-requirements-2026-09.md');

// --- What the code shows ------------------------------------------------------------------------------------------

/** The game's own source files (not its tests, its build output or node_modules), two folders deep */
export function gameSources(dir: string, depth = 0): string[] {
  if (!existsSync(dir) || depth > 2) return [];
  const out: string[] = [];
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (e.isDirectory()) {
      if (!['node_modules', 'dist', 'dist-playgama', 'upload', 'qa', 'store', 'submission', 'android', 'tools', 'standalone', 'test', 'tests'].includes(e.name) && !e.name.startsWith('.')) out.push(...gameSources(join(dir, e.name), depth + 1));
    } else if (/\.(ts|mjs|js)$/.test(e.name) && !/\.(test|spec|d)\.ts$/.test(e.name) && e.name !== 'video.mjs') out.push(join(dir, e.name));
  }
  return out;
}

/** Whether the game's code starts the platform's music (createMusic from @gp/core/sound): gp validate and the gate read it */
export function codeHasMusic(loc: GameLocation): boolean {
  return gameSources(loc.dir).some((f) => sourceHasMusic(readFileSync(f, 'utf8')));
}

const stripComments = (src: string) => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1');

/**
 * Emoji and symbol glyphs in the game's code and English strings: a hint that they stand in for drawn icons (Candle
 * Crypt 2026-10-10: «Везде где используются эмодзи замени их на нарисованные иконки в стиле игры»). Not only emoji: the
 * symbol blocks too (◆ ✓ ✕ ◎ ● ▌ ▶ — Frankengun's review; `@gp/qa/glyphs`), as gp qa finds them on screen. Which files,
 * and which characters.
 */
export function emojiInCode(loc: GameLocation): { files: string[]; chars: string[] } {
  const files: string[] = [];
  const chars = new Set<string>();
  const en = join(loc.dir, 'strings', 'en.yaml');
  for (const f of [...gameSources(loc.dir), ...(existsSync(en) ? [en] : [])]) {
    const found = stripComments(readFileSync(f, 'utf8')).match(iconGlyphs());
    if (!found) continue;
    files.push(f);
    for (const c of found) chars.add(c);
  }
  return { files, chars: [...chars].slice(0, 16) };
}

/** The systems around the core the code shows (the platform's blocks it uses), for the scope check */
const SYSTEMS: [RegExp, string][] = [
  [/\b(UpgradeShop|mountUpgradeShop)\b/, 'an upgrade shop'],
  [/\bRoster\b/, 'unlocks (Roster)'],
  [/\bTiers\b/, 'tiers'],
  [/\bPactTree\b/, 'a pact tree'],
  [/\bRunChoices\b/, 'run choices'],
  [/\b(recordStars|levelOpen|loadStars)\b/, 'levels with stars'],
  [/\b(loadDaily|recordDaily|daySeed)\b/, 'a daily'],
  [/\b(mountDialogue|StoryRunner|loadStory)\b/, 'a story with dialogue'],
  [/\bcreatePhysics\b/, 'physics'],
  [/\b(WebSocket|Photon|Colyseus|PeerJS)\b/, 'online multiplayer'],
];

export interface ScopeFacts {
  systems: string[];
  /** The screens the game declares to QA (host.qa({ screens })) */
  screens: string[];
  /** Hours between the first and the last commit of the game folder (null: not a git checkout) */
  madeHours: number | null;
}

/** The screens `gp qa` opened, from its shots' names (screen-<name>-<size>.png; a language's lang-<code>-… not counted) */
export function screensFromShots(files: readonly string[]): string[] {
  const out = new Set<string>();
  for (const f of files) {
    const m = /^screen-(.+)-(?:phone-portrait|phone-landscape|desktop|mobile)-\d+x\d+\.png$/.exec(f);
    if (m) out.add(m[1]);
  }
  return [...out];
}

/**
 * The top-level keys of each `screens: { … }` object in the code (host.qa({ screens })). Only depth 1 counts: a screen's
 * own setup object ({ streak: { day, n, claimed } }) is not a screen — the lazy regex before 2026-10-19 listed Garage's
 * screens as "streak, day, n, claimed"
 */
export function declaredScreens(code: string): string[] {
  const out = new Set<string>();
  for (const m of code.matchAll(/\bscreens\s*:\s*\{/g)) {
    let depth = 1;
    let token = '';
    for (let i = (m.index ?? 0) + m[0].length; i < code.length && depth > 0; i++) {
      const ch = code[i];
      if (ch === '{' || ch === '(' || ch === '[') depth++;
      else if (ch === '}' || ch === ')' || ch === ']') depth--;
      if (depth !== 1) {
        token = '';
        continue;
      }
      if (ch === ':') {
        const k = /['"]?([A-Za-z][\w-]*)['"]?\s*$/.exec(token);
        if (k) out.add(k[1]);
        token = '';
      } else if (ch === ',') token = '';
      else token += ch;
    }
  }
  return [...out];
}

/**
 * The screens the last `gp qa` opened from host.qa({ screens }): the names of its screen-<name>-<size>.png shots and of its
 * checks ("<name>" <size>: …, qa/qa-results.json). null without a QA run. This is the reliable count: the declaration is
 * code (a function per screen, often built in a loop), which no static reading gets right (declaredScreens is the fallback)
 */
export function qaScreens(qaDir: string): string[] | null {
  if (!existsSync(qaDir)) return null;
  const out = new Set(screensFromShots(readdirSync(qaDir)));
  const results = join(qaDir, 'qa-results.json');
  if (existsSync(results)) {
    try {
      const j = JSON.parse(readFileSync(results, 'utf8')) as { checks?: { name?: string }[] };
      for (const c of j.checks ?? []) {
        const m = /^"([^"]+)" (?:phone-portrait|phone-landscape|desktop|mobile)-\d+x\d+:/.exec(c.name ?? '');
        if (m) out.add(m[1]);
      }
    } catch {
      /* a QA run being written: the shots alone */
    }
  } else if (!out.size) return null;
  return [...out];
}

/** More screens than this on a first CrazyGames submission is W_SCOPE (the calibration of 2026-10-19: 16–20 on the rejected games, 10–12 on the approved) */
export { SCOPE_MAX_SCREENS };

/**
 * W_SCOPE for `gp validate`: a CrazyGames code game with no record in publisher/results.yaml (a first submission) whose
 * last `gp qa` opened more than SCOPE_MAX_SCREENS declared screens. Nothing before the first QA run (the screens are code).
 */
export function scopeIssues(loc: GameLocation, game: Pick<ResolvedGame, 'id' | 'title'> & { channel: { id: string }; kit: { kit: string } }, results: readonly RecordedResult[]): Issue[] {
  if (game.channel.id !== 'crazygames' || game.kit.kit !== 'code') return [];
  const title = game.title.toLowerCase();
  if (results.some((r) => r.channel === 'crazygames' && (r.game === game.id || r.game === loc.id || r.title?.toLowerCase() === title))) return [];
  const screens = qaScreens(join(loc.dir, 'qa'));
  if (!screens || screens.length <= SCOPE_MAX_SCREENS) return [];
  return [
    {
      code: 'W_SCOPE',
      severity: 'warning',
      path: ['concept'],
      message: `a first CrazyGames submission with ${screens.length} screens (the last gp qa opened ${screens.slice(0, 8).join(', ')}${screens.length > 8 ? ', …' : ''}): our rejected games had 16–20, the approved ones 10–12`,
      fix: `Cut to one core, one meta track and one return hook (≤ ${SCOPE_MAX_SCREENS} screens), each screen drawn and animated — merge or drop the rest for a later update (gp explain W_SCOPE).`,
    },
  ];
}

/** Systems, declared screens and how long the game took — the prototype-risk check of the brief */
export function scopeFacts(loc: GameLocation, game: Pick<ResolvedGame, 'story'>): ScopeFacts {
  const code = gameSources(loc.dir).map((f) => stripComments(readFileSync(f, 'utf8'))).join('\n');
  const systems = SYSTEMS.filter(([re]) => re.test(code)).map(([, name]) => name);
  if (game.story && game.story.depth !== 'none' && !systems.includes('a story with dialogue')) systems.push(`a story (${game.story.depth})`);
  // The screens the last gp qa opened (its screen-<name>-<size>.png shots), else the keys of host.qa({ screens: { … } })
  const shots = qaScreens(join(loc.dir, 'qa')) ?? [];
  const screens = new Set<string>(shots.length ? shots : declaredScreens(code));
  let madeHours: number | null = null;
  try {
    const t = execFileSync('git', ['log', '--format=%ct', '--', '.'], { cwd: loc.dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
      .split('\n')
      .filter(Boolean)
      .map(Number);
    if (t.length) madeHours = Math.round(((Math.max(...t) - Math.min(...t)) / 3600) * 10) / 10;
  } catch {
    madeHours = null;
  }
  return { systems, screens: [...screens], madeHours };
}

// --- quality.md: the format and its parser (pure) ---------------------------------------------------------------

export type QualityLevel = 'blocking' | 'nice';

export interface QualityFinding {
  level: QualityLevel;
  /** What is wrong (before the arrow) */
  what: string;
  /** What to change (after the arrow) */
  change: string;
  /** 1-based line of the item in quality.md */
  line: number;
}

/** A score of the review sheet: would this screen sit on CrazyGames' front page next to the approved references? */
export interface QualityScore {
  /** title, play-1, play-2, meta (or another screen the reviewer adds) */
  screen: string;
  /** 1–5; null: `n/a` (only a game without a meta screen) */
  score: number | null;
  reason: string;
  line: number;
}

/** The reviewer's session: where they would have stopped (null: they played the 12 minutes through) and why */
export interface QualitySession {
  stopSec: number | null;
  why: string;
  line: number;
}

/** On CrazyGames a reviewer's stop before this (minutes) must be a [blocking] finding that names the session */
export const SESSION_STOP_MIN = 8;
/** A finding that is about the session's length */
const NAMES_SESSION = /\b(session|playtime|play time|close[sd]? the tab|where I'?d stop|stop(?:ped)? playing|would stop|minutes? of play)\b/i;

export interface QualityReport {
  /** The `# …` heading */
  title: string | null;
  findings: QualityFinding[];
  blocking: QualityFinding[];
  nice: QualityFinding[];
  /** `## Scores` (empty when the section is missing) */
  scores: QualityScore[];
  /** `## Session` (optional): where the reviewer, playing as a new player on desktop, would have closed the tab */
  session: QualitySession | null;
  /** What makes the file malformed, with its line: empty means the format is right */
  problems: { line: number; message: string }[];
  ok: boolean;
}

/** Minutes the reviewer plays as a new player on desktop for the session lens */
export const SESSION_PLAY_MIN = 12;

/**
 * `## Session`: "- Where I'd stop: 4:30 — why" (or "none — why": played through). Placeholders count as not written;
 * a section with no such line is a problem
 */
export function parseSession(lines: string[], problems: { line: number; message: string }[]): QualitySession | null {
  const at = lines.findIndex((l) => /^##\s+session\s*$/i.test(l.trim()));
  if (at < 0) return null;
  let placeholder = false;
  for (let i = at + 1; i < lines.length; i++) {
    const l = lines[i];
    if (/^#{1,2}\s/.test(l)) break;
    if (/<mm:ss/i.test(l)) {
      placeholder = true;
      continue;
    }
    const m = l.match(/^[-*]?\s*where\s+i(?:'|’)?d\s+(?:have\s+)?stop(?:ped)?\s*:\s*(.+)$/i);
    if (!m) continue;
    const v = m[1].trim();
    const t = v.match(/^(\d{1,3}):([0-5]\d)\s*(?:—|–|-|:)?\s*(.*)$/);
    if (t) return { stopSec: Number(t[1]) * 60 + Number(t[2]), why: t[3].trim(), line: i + 1 };
    const none = v.match(/^(none|never|nowhere|didn'?t|did not|played (?:it )?through|past \d)\b\s*(?:—|–|-|:)?\s*(.*)$/i);
    if (none) return { stopSec: null, why: none[2].trim() || v, line: i + 1 };
    problems.push({ line: i + 1, message: `"${v.slice(0, 40)}": write the time as mm:ss ("- Where I'd stop: 4:30 — <why>") or "none — <why>"` });
    return null;
  }
  if (!placeholder) problems.push({ line: at + 1, message: `the Session section has no "- Where I'd stop: mm:ss — <why>" line (or "none — <why>")` });
  return null;
}

/** On CrazyGames: the reviewer's stop before SESSION_STOP_MIN must be a [blocking] finding that names the session */
export function sessionProblems(r: Pick<QualityReport, 'session' | 'blocking'>): { line: number; message: string }[] {
  const s = r.session;
  if (!s || s.stopSec === null || s.stopSec >= SESSION_STOP_MIN * 60) return [];
  if (r.blocking.some((f) => NAMES_SESSION.test(`${f.what} ${f.change}`))) return [];
  const mmss = `${Math.floor(s.stopSec / 60)}:${String(s.stopSec % 60).padStart(2, '0')}`;
  return [{ line: s.line, message: `you would stop at ${mmss}, before ${SESSION_STOP_MIN}:00: write it as a [blocking] finding that names the session (where and why a new player closes the tab → what would pull them on) — every Basic Launch we had stopped on average playtime` }];
}

/** The score a screen needs to pass without a [blocking] finding */
/**
 * A screen scored below this is a [blocking] finding. 3, not 4: in the blind calibration of 2026-10-19
 * (docs/research/qa-calibration-2026-10.md) the games CrazyGames APPROVED (Idle Garage, Hang the Moon) scored 3–4 on
 * their title and play too — at 4 the gate would have refused every game we have shipped. A 2 is what the portal sees.
 */
export const PASS_SCORE = 3;

/** The sample the brief shows the reviewer; the parser accepts it (a test keeps the two in step) */
export function qualityTemplate(title: string): string {
  return [
    `# ${title} — quality review`,
    '',
    'Reviewer: <who> · Date: <YYYY-MM-DD> · Played: <the build and how long, e.g. gp dev, 15 min, 1280×720 first, then 360×800>',
    '',
    '## Scores',
    '',
    `Each of the game's screens on qa/review-sheet.png, 1–5: would it sit on CrazyGames' front page next to the approved references? A reason for each; below ${PASS_SCORE} the screen also gets a [blocking] finding that names it.`,
    '',
    ...SCORED_SCREENS.map((s) => `- ${s}: <1–5>/5 — <why, compared with the references>`),
    '',
    '## Findings',
    '',
    '- [blocking] <what is wrong, where — what a portal reviewer would see> → <what to change>',
    '- [nice] <what would make it better> → <what to change>',
    '',
    '## Session',
    '',
    `<optional, read on CrazyGames: you played ${SESSION_PLAY_MIN} minutes as a new player on desktop; a stop before ${SESSION_STOP_MIN}:00 is also a [blocking] finding that names the session>`,
    '',
    "- Where I'd stop: <mm:ss, or none> — <why: what ended the pull to play on>",
    '',
    '## Checked and fine',
    '',
    '<optional: the checklist items you checked that need nothing — free text, not parsed>',
    '',
  ].join('\n');
}

const ARROW = /\s(?:→|->)\s/;

/** "Play 1", "play_1", "PLAY-1" → "play-1" */
const normScreen = (s: string) => s.trim().toLowerCase().replace(/[\s_]+/g, '-');

/** Whether a finding's text names the screen as the scores do (title also as "first screen", play-1 also as "play 1") */
export function namesScreen(text: string, screen: string): boolean {
  const t = text.toLowerCase().replace(/\bplay[\s_]?(\d)\b/g, 'play-$1');
  const id = normScreen(screen);
  if (id === 'title') return /\btitle\b|\bfirst screen\b/.test(t);
  return new RegExp(`(^|[^\\w-])${id.replace(/[-]/g, '\\-')}(?![\\w-])`).test(t);
}

/** `## Scores`: its lines, and what is wrong with them */
function parseScores(lines: string[], start: number, problems: { line: number; message: string }[]): QualityScore[] {
  const scores: QualityScore[] = [];
  for (let i = start + 1; i < lines.length; i++) {
    const l = lines[i];
    if (/^#{1,2}\s/.test(l)) break;
    const item = l.match(/^[-*]\s+(.*)$/);
    if (!item) continue;
    const body = item[1].trim();
    if (/<1–5>|<why|<n>/.test(body)) {
      problems.push({ line: i + 1, message: 'the template\'s placeholder is still in this score' });
      continue;
    }
    const m = body.match(/^([A-Za-z][\w -]*?)\s*:\s*(n\/a|\d+(?:[.,]\d+)?)\s*(?:\/\s*5)?\s*(?:[—–:-]\s*)?(.*)$/i);
    if (!m) {
      problems.push({ line: i + 1, message: 'a score is "- <screen>: <1–5>/5 — <why>" (title, play-1, play-2, meta)' });
      continue;
    }
    const screen = normScreen(m[1]);
    const na = /^n\/a$/i.test(m[2]);
    const n = na ? null : Number(m[2].replace(',', '.'));
    const reason = m[3].trim();
    if (n !== null && !(Number.isInteger(n) && n >= 1 && n <= 5)) problems.push({ line: i + 1, message: `"${m[2]}" is not a score: a whole number from 1 to 5` });
    else if (na && screen !== 'meta') problems.push({ line: i + 1, message: `"n/a" only for meta (a game without a meta screen): score ${screen} 1–5` });
    else if (!reason) problems.push({ line: i + 1, message: `say why ${screen} scores ${m[2]}: "- ${screen}: ${m[2]}/5 — <why, compared with the references>"` });
    else scores.push({ screen, score: n, reason, line: i + 1 });
  }
  return scores;
}

/**
 * quality.md → its findings, and what is wrong with the file. The format: a `# <title> — quality review` heading, then a
 * `## Findings` section that holds only list items `- [blocking] <what> → <change>` or `- [nice] <what> → <change>`
 * (an item may go on over indented lines); at least one finding. Other sections are free text — except `## Scores`
 * (the review sheet's 1–5 per screen: `- <screen>: <n>/5 — <why>`), required with `scores: true` (CrazyGames): every
 * screen of SCORED_SCREENS scored (meta may be `n/a`), and a score below PASS_SCORE (3) needs a [blocking] finding that names the screen.
 */
export function parseQuality(text: string, opts: { title?: string; scores?: boolean; session?: boolean } = {}): QualityReport {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const problems: { line: number; message: string }[] = [];
  const findings: QualityFinding[] = [];
  const h1 = lines.findIndex((l) => /^#\s+\S/.test(l));
  const title = h1 >= 0 ? lines[h1].replace(/^#\s+/, '').trim() : null;
  if (h1 < 0) problems.push({ line: 1, message: 'no heading: the file starts with "# <game title> — quality review"' });
  else if (opts.title && !title!.toLowerCase().includes(opts.title.toLowerCase()))
    problems.push({ line: h1 + 1, message: `the heading "${title}" doesn't name this game ("${opts.title}"): a review of another game?` });

  const scoresAt = lines.findIndex((l) => /^##\s+scores\s*$/i.test(l.trim()));
  const scores = scoresAt >= 0 ? parseScores(lines, scoresAt, problems) : [];
  const session = parseSession(lines, problems);
  const start = lines.findIndex((l) => /^##\s+findings\s*$/i.test(l.trim()));
  if (start < 0) {
    problems.push({ line: Math.max(1, h1 + 2), message: 'no "## Findings" section' });
    return report(title, findings, problems, scores, session);
  }
  type Item = { line: number; text: string; level: QualityLevel | null };
  const items: Item[] = [];
  for (let i = start + 1; i < lines.length; i++) {
    const l = lines[i];
    if (/^#{1,2}\s/.test(l)) break;
    if (!l.trim()) continue;
    const item = l.match(/^[-*]\s+(.*)$/);
    if (item) {
      const tag = item[1].match(/^\[([^\]]*)\]\s*(.*)$/);
      const level = tag && /^(blocking|nice)$/i.test(tag[1].trim()) ? (tag[1].trim().toLowerCase() as QualityLevel) : null;
      if (!tag) problems.push({ line: i + 1, message: 'a finding without a level: start it with [blocking] or [nice]' });
      else if (!level) problems.push({ line: i + 1, message: `"[${tag[1]}]" is not a level: use [blocking] or [nice]` });
      items.push({ line: i + 1, text: tag ? tag[2] : item[1], level });
    } else if (/^\s+\S/.test(l) && items.length) items[items.length - 1].text += ' ' + l.trim();
    else problems.push({ line: i + 1, message: 'only findings go in this section: "- [blocking] … → …" or "- [nice] … → …" (notes go in another section)' });
  }
  for (const it of items) {
    if (!it.level) continue;
    const text = it.text.replace(/\s+/g, ' ').trim();
    if (/\bTODO\b/.test(text) || /<what (is wrong|would|to change)/.test(text)) {
      problems.push({ line: it.line, message: 'the template\'s placeholder is still in this finding' });
      continue;
    }
    const at = text.search(ARROW);
    const what = at >= 0 ? text.slice(0, at).trim() : text;
    const change = at >= 0 ? text.slice(at).replace(ARROW, '').trim() : '';
    if (!what || !change) {
      problems.push({ line: it.line, message: 'say what is wrong and what to change: "- [' + it.level + '] <what> → <change>"' });
      continue;
    }
    findings.push({ level: it.level, what, change, line: it.line });
  }
  if (!items.length) problems.push({ line: start + 1, message: 'no findings: every review of our games found something (2–16 each) — write at least the [nice] items' });
  if (opts.scores) {
    if (scoresAt < 0) problems.push({ line: Math.max(1, h1 + 2), message: `no "## Scores" section: score ${SCORED_SCREENS.join(', ')} of qa/review-sheet.png 1–5 against the approved references (gp review)` });
    else {
      // A malformed score line is reported as it is, not again as a missing score
      const end = lines.findIndex((l, i) => i > scoresAt && /^#{1,2}\s/.test(l));
      const badLines = problems.some((p) => p.line > scoresAt + 1 && (end < 0 || p.line <= end));
      for (const s of SCORED_SCREENS)
        if (!scores.some((x) => x.screen === s) && !badLines)
          problems.push({ line: scoresAt + 1, message: `no score for ${s}: "- ${s}: <1–5>/5 — <why>"${s === 'meta' ? ' (or "- meta: n/a — <why>" for a game without a meta screen)' : ''}` });
    }
  }
  for (const s of scores) {
    if (s.score === null || s.score >= PASS_SCORE) continue;
    if (!findings.some((f) => f.level === 'blocking' && namesScreen(`${f.what} ${f.change}`, s.screen)))
      problems.push({ line: s.line, message: `${s.screen} scores ${s.score}/5, below ${PASS_SCORE}: write it as a [blocking] finding that names "${s.screen}" — a screen that wouldn't sit on the front page is never [nice]` });
  }
  if (opts.session) problems.push(...sessionProblems({ session, blocking: findings.filter((f) => f.level === 'blocking') }));
  return report(title, findings, problems, scores, session);
}

function report(title: string | null, findings: QualityFinding[], problems: { line: number; message: string }[], scores: QualityScore[] = [], session: QualitySession | null = null): QualityReport {
  return {
    title,
    findings,
    blocking: findings.filter((f) => f.level === 'blocking'),
    nice: findings.filter((f) => f.level === 'nice'),
    scores,
    session,
    problems: problems.sort((a, b) => a.line - b.line),
    ok: !problems.length,
  };
}

/**
 * [nice] findings that read as the look or the layout of the first screen or of play — on CrazyGames those are
 * [blocking] (the brief says so); a hint `gp review` prints, not a refusal: words can't tell a judgement apart
 */
export function niceLookHints(r: QualityReport): QualityFinding[] {
  const where = /\b(first screen|title( screen)?|in play|during play|play screen|play-\d|the play(field)?|playfield|the hud|hud\b|1280|desktop)\b/i;
  const look = /\b(look|looks|layout|empty|font|typograph\w*|small|tiny|cramped|style|art|colou?rs?|palette|spacing|align\w*|contrast|legib\w*|readab\w*|flat|grey|gray|dull|bland|placeholder|prototype|web app|web page)\b/i;
  return r.nice.filter((f) => where.test(f.what) && look.test(f.what));
}

export interface QualityGate {
  file: string;
  exists: boolean;
  report: QualityReport | null;
  /** Ready for the submission: the file exists, is well-formed and has no [blocking] finding */
  ok: boolean;
  /** One line for `gp submission` and `gp review` */
  detail: string;
}

/** The rules the gate checks itself, without the reviewer: on CrazyGames a code game has music */
function mechanicalGate(loc: GameLocation, game: Partial<Pick<ResolvedGame, 'channel' | 'kit' | 'sound'>>): string | null {
  if (game.channel?.id !== 'crazygames' || game.kit?.kit !== 'code') return null;
  if (hasMusic({ sound: game.sound ?? { music: null, why: null } }, codeHasMusic(loc))) return null;
  return `no music: the code calls no createMusic (@gp/core/sound) and game.yaml has no \`sound.music\` saying what plays — CrazyGames code games need music (gp explain E_SOUND_MUSIC)`;
}

/** games/<id>/quality.md, read and judged for the submission (and, on CrazyGames, the music the code shows) */
export function qualityGate(loc: GameLocation, game: Pick<ResolvedGame, 'title'> & Partial<Pick<ResolvedGame, 'channel' | 'kit' | 'sound'>>): QualityGate {
  let gate = reviewerGate(loc, game);
  for (const rule of [firstLookGate(loc, game), mechanicalGate(loc, game)]) if (rule) gate = { ...gate, ok: false, detail: gate.ok ? rule : `${gate.detail}; and ${rule}` };
  return gate;
}

/** On CrazyGames: the blind first look (qa/first-look.md) is there and well-formed */
function firstLookGate(loc: GameLocation, game: Partial<Pick<ResolvedGame, 'channel'>>): string | null {
  if (game.channel?.id !== 'crazygames') return null;
  const { file, look } = readFirstLook(loc);
  if (!look) return `${shown(file)} is missing — run \`gp review ${loc.id} --first-look\` and give qa/${FIRST_LOOK_BRIEF} to an agent who knows nothing about the game (not the maker, not the reviewer)`;
  if (!look.ok) return `${FIRST_LOOK_FILE} is malformed (${look.problems.slice(0, 2).map((p) => `line ${p.line}: ${p.message}`).join('; ')}) — the format is in qa/${FIRST_LOOK_BRIEF}`;
  return null;
}

/**
 * The first look's alarm in quality.md: "keep playing" ≤ FIRST_LOOK_LOW or a goal not told must be a [blocking] finding
 * that names the first look (like a low score must name its screen) — a problem of quality.md otherwise
 */
export function firstLookProblems(look: FirstLook | null, r: QualityReport): { line: number; message: string }[] {
  if (!look?.ok) return [];
  const alarm = firstLookAlarm(look);
  if (!alarm || r.blocking.some((f) => NAMES_FIRST_LOOK.test(`${f.what} ${f.change}`))) return [];
  const at = r.findings[0]?.line ?? 1;
  return [{ line: at, message: `the blind first look (qa/${FIRST_LOOK_FILE}) says ${alarm}: write it as a [blocking] finding that names "first look" — a new player who can't tell the goal or wouldn't go on leaves` }];
}

/** quality.md alone: missing, malformed (on CrazyGames: without the sheet's scores), [blocking] findings, or fine */
function reviewerGate(loc: GameLocation, game: Pick<ResolvedGame, 'title'> & Partial<Pick<ResolvedGame, 'channel'>>): QualityGate {
  const file = join(loc.dir, QUALITY_FILE);
  const id = loc.id;
  if (!existsSync(file))
    return { file, exists: false, report: null, ok: false, detail: `${shown(file)} is missing — run \`gp review ${id}\`, give qa/${BRIEF_FILE} to a second agent (a reviewer), fix what it finds` };
  const r = parseQuality(readFileSync(file, 'utf8'), { title: game.title, scores: game.channel?.id === 'crazygames', session: game.channel?.id === 'crazygames' });
  if (game.channel?.id === 'crazygames') {
    const extra = firstLookProblems(readFirstLook(loc).look, r);
    if (extra.length) Object.assign(r, { problems: [...r.problems, ...extra].sort((a, b) => a.line - b.line), ok: false });
  }
  if (!r.ok) {
    const first = r.problems.slice(0, 3).map((p) => `line ${p.line}: ${p.message}`).join('; ');
    return { file, exists: true, report: r, ok: false, detail: `${QUALITY_FILE} is malformed (${r.problems.length} problem(s): ${first}) — the format is in qa/${BRIEF_FILE} (\`gp review ${id}\`)` };
  }
  if (r.blocking.length) {
    const first = r.blocking[0];
    return {
      file,
      exists: true,
      report: r,
      ok: false,
      detail: `${r.blocking.length} [blocking] finding(s), e.g. line ${first.line}: "${clip(first.what, 90)}" — fix them, then the reviewer checks again and updates ${QUALITY_FILE} (\`gp review ${id}\`)`,
    };
  }
  const scored = r.scores.length ? `; scores ${r.scores.map((x) => `${x.screen} ${x.score ?? 'n/a'}`).join(', ')}` : '';
  return { file, exists: true, report: r, ok: true, detail: `no [blocking] findings, ${r.nice.length} [nice]${scored}` };
}

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

// --- The look: an art-direction checklist (docs/guides/art.md) ----------------------------------------------------------

/**
 * What a reviewer checks of the look. CrazyGames rejected games for "the overall quality" and our covers' click-through
 * was 0.6–1.2 %; a reviewer of Kettlebot spelled it out (brown, dirty palettes, thick black outlines, flat panels, big
 * empty spaces, a toy-like robot). Each item names the rule and how to fix it with @gp/art.
 */
export const ART_CHECKLIST: { check: string; fix: string }[] = [
  { check: 'The art serves the game design and keeps the game\'s identity: at play size the hero, the dangers, the pickups and the telegraphs read first; colour codes hold (danger, loot, rarity); a game that changes technique (pixel art → painted) keeps its palette, its light and its silhouettes — it looks like the same game, finished', fix: 'game.yaml `art.keep`, then `gp art --only <id>`; sizes and contrast at the size the sprite is drawn in play' },
  { check: 'One palette with roles: background, surfaces, the hero, danger and light each have their colour; in grayscale the hero and the danger stand out from the background; no brown-grey "dirty" colours', fix: '@gp/art/palette (PALETTES, checkPalette)' },
  { check: 'One light direction for the whole scene: every sprite is lit from the same side, highlights and shadows agree', fix: '@gp/art/material paint({ light }), LightLayer.dirAt()' },
  { check: 'Volume on the main sprites: at least three values per material (light, base, shadow), hue-shifted shading, a rim or bounce light — not flat fills', fix: '@gp/art/material paint()' },
  { check: 'No pure-black or thick black outlines: edges in a darker shade of the base colour', fix: 'paint({ outline }) (outlineOf)' },
  { check: 'Shadows under everything that stands on the ground (contact shadows); lights cast shadows where it matters', fix: 'contactShadow(), LightLayer occluders' },
  { check: 'Characters are alive when idle: breathing, a blink, secondary motion (antennas, ears), a look toward the action', fix: '@gp/art/rig (breathe, Blinker, Wobble, lookAt)' },
  { check: 'Every player action has feedback: particles, a sound, a light flash, a shake or a squash, a number that pops', fix: '@gp/art/fx, Camera.addTrauma(), Jelly' },
  { check: 'The background has depth: layers in parallax, farther ones lighter and hazier; no large empty or single-colour areas', fix: '@gp/art/scenery (Scenery, fog layers)' },
  { check: 'The HUD is designed, not flat boxes: translucent panels with a light edge, gauges and readouts that read at 360 px', fix: '@gp/art/hud (glass, gauge, bar, readout)' },
  { check: 'One coherent style across the screens, the covers and the video', fix: 'one palette and one light for all of them' },
  { check: 'Cartoon, game-like art, never photorealistic: clean shapes, bold silhouettes, simple shading, a saturated palette. Generated images (gp art) share one style, have clean cut-out edges (no green fringe or halo), no text, letters, watermarks or melted details, and still move: they breathe, squash, cast shadows and sit under the code\'s light', fix: 'game.yaml `art.style` in cartoon words, `gp art --only <id>` to remake one; @gp/art/assets drawImageSprite with rig and material on top (docs/guides/art.md#5-generated-art-gp-art)' },
];

function artSection(look: string[], keep: string[] = []): string[] {
  return [
    '## The look: art direction (docs/guides/art.md)',
    '',
    'Judge the screenshots and a few minutes of play against these. A flat, empty or muddy look is a `[blocking]` finding on a portal: it is what "the overall quality" rejections and a low cover click-through come from. The look serves the game design: beautiful art that hides a danger, a pickup or a telegraph is `[blocking]` too (the owner, 2026-10-10: «Красивая графика и сильный геймплей важнее всего остального»).',
    '',
    ...ART_CHECKLIST.map((a, i) => `${i + 1}. ${a.check} — fix: ${a.fix}`),
    '',
    ...(keep.length ? ['What the art must keep of this game (game.yaml `art.keep`; a new technique may replace the old one, the identity stays):', '', ...keep.map((k) => `- ${k}`), ''] : []),
    ...(look.length ? ['What `gp qa` measured of the play frames (a hint, not a check):', '', ...look.map((l) => `- ${l}`), ''] : []),
  ];
}

/** A pixel game: the craft rules on top of the look, and what `gp pixel` found (qa/pixel.md) */
export function pixelSection(loc: GameLocation): string[] {
  const spec = readFileSync(loc.file, 'utf8');
  if (!/^\s*technique:\s*pixel\b/m.test(spec) && !/^pixel:/m.test(spec)) return [];
  const report = join(loc.dir, 'qa', 'pixel.md');
  const found = existsSync(report) ? readFileSync(report, 'utf8').split('\n') : null;
  const head = found ? found.slice(2, found.indexOf('## Sprites') > 0 ? found.indexOf('## Sprites') : 30).filter((l) => l.trim()) : [];
  return [
    '## Pixel art (docs/guides/pixel-art.md)',
    '',
    'A pixel game is judged as pixel art: a 1-px dark outline is its convention (not the painted look\'s "no black outlines").',
    '',
    '1. One pixel size everywhere: every sprite, tile, effect and the HUD at the same whole-number scale — nothing smoothed, scaled by a fraction or rotated smoothly (mixels read as unfinished)',
    '2. Silhouettes read at play size and in one colour; the hero, the dangers and the pickups differ by shape first',
    '3. One light and one outline rule across the set; ramps of 3–4 hue-shifted steps, shading that follows the form (no pillow shading), clusters not noise',
    '4. The camera and the motion stay on the pixel grid: no shimmer on a slow pan, no sprite jittering a pixel back and forth',
    '',
    ...(found ? [`What \`gp pixel\` found (${shown(report)}; the sheet: qa/pixel-sheet.png):`, '', ...head, ''] : [`\`gp pixel ${loc.id}\` has not run — run it and read qa/pixel.md and qa/pixel-sheet.png.`, '']),
  ];
}

// --- The CrazyGames quality checklist: each item with its source line in the research --------------------------------

export interface ChecklistItem {
  area: string;
  check: string;
  /** Words from the research file that locate the source line (a test checks every one is there) */
  anchor: string;
  /** What `gp validate` / `gp qa` / `gp submission` already check of it — the reviewer judges the rest */
  platform?: string;
}

export const QUALITY_CHECKLIST: ChecklistItem[] = [
  // The first minute: QA plays briefly, players decide in seconds
  { area: 'First minute', check: 'A new player lands in gameplay at once, or after at most one click', anchor: 'land new users in gameplay immediately', platform: 'gp qa (production): gameplayStart after one click' },
  { area: 'First minute', check: 'Onboarding happens in play: visual, the core action only, skippable — no text wall or story before the first action', anchor: 'Prioritize visuals and limit the use of text for onboarding.' },
  { area: 'First minute', check: 'The controls are shown in play (a keyboard overlay or a mouse/touch gesture)', anchor: 'Show the user how to control the game with a keyboard overlay or mouse gestures.' },
  { area: 'First minute', check: 'The goal is clear, and reachable', anchor: 'There are clear goals that the player can reach.' },
  { area: 'First minute', check: 'The game is easy to learn; the language is correct and clear, or the game uses universal graphic prompts', anchor: 'The game is easy to understand' },
  { area: 'First minute', check: 'Buttons are clearly labelled; none is sized or delayed to push the player toward an ad', anchor: 'Buttons are clearly labeled to indicate how to proceed', platform: 'gp qa: "No thanks" at least as big as the offer' },
  // Fun and depth: the reviewers play "to check that it … is fun to play"
  { area: 'Fun and depth', check: 'It is fun to play: the QA team plays every submission for that', anchor: 'is fun to play' },
  { area: 'Fun and depth', check: 'It does not look like a prototype: enough content and polish for a 10-minute first session', anchor: 'This game needs content and polishing' },
  { area: 'Fun and depth', check: 'The game answers every input at once (feedback, juice)', anchor: "The game responds quickly to the player's actions." },
  { area: 'Fun and depth', check: 'Challenge, strategy and story are balanced and well paced', anchor: 'The challenge, strategy, and game story are balanced and well-paced.' },
  { area: 'Fun and depth', check: 'No overly repetitive or boring tasks; no empty stretches (waiting, a long glide)', anchor: "no overly repetitive or 'boring' tasks" },
  { area: 'Fun and depth', check: 'Various player segments can enjoy it (not only an expert or only a beginner)', anchor: 'Various player segments can enjoy the game.' },
  { area: 'Fun and depth', check: 'Smooth flow: the game processes information quickly, no stalls between actions', anchor: 'The game processes information quickly' },
  { area: 'Fun and depth', check: 'The story or scenario is interesting where the game has one', anchor: 'The game story or scenarios are interesting where applicable.' },
  // Look and sound: "fun, unique, visually appealing"
  { area: 'Look and sound', check: 'One consistent, coherent, attractive style; no mixed looks (realistic and cartoony, sharp and blurry)', anchor: 'internally consistent, coherent, and has attractive visuals' },
  { area: 'Look and sound', check: 'High-resolution graphics, consistent resolution, no graphical defects', anchor: 'Quality games have consistent resolution throughout the game.' },
  { area: 'Look and sound', check: 'Audio of good quality at even levels; music that fits; nothing too loud or too quiet', anchor: 'Audio levels are consistent.' },
  { area: 'Look and sound', check: 'The layout is comfortable and intuitive, designed for desktop (and mobile if declared)', anchor: 'The display layout is comfortable and intuitive.' },
  { area: 'Look and sound', check: 'Text and images legible at devicePixelRatio 1 in the small iframes (821×462, 800×450)', anchor: 'Text and images must be legible on devices with a', platform: 'gp qa (production, portal frames): DOM text ≥ 12 px; canvas text only in the production-frame-* screenshots' },
  // Identity and honesty
  { area: 'Identity', check: 'Not a clone or an asset flip: original names, assets and content', anchor: 'Unoriginal content (e.g. clones or asset flips)', platform: 'gp uniqueness (70+ for gp submission), E_CONCEPT, W_CONCEPT_TAKEN' },
  { area: 'Identity', check: 'The game is clear about what it is: the name, covers and description match the game played', anchor: 'The game is clear about what it is.' },
  { area: 'Identity', check: 'The name and icon are not easily confused with another game; not a common word', anchor: 'not easily confused with another that features a similar name or iconography', platform: 'E_TITLE_GENERIC, E_TITLE_LONG' },
  { area: 'Identity', check: 'English is present and correct', anchor: 'English localization' },
  {
    area: 'Identity',
    check: 'Every declared language is correct and complete: switch it with the title\'s picker and play a minute in two of them (the longest, and one you read); names stay as they are; the game starts in the portal\'s language',
    anchor: 'Translations, if any, are good and follow',
    platform: 'gp validate: every key in every language, params and plural forms (E_I18N_*); gp qa [languages]: the longest language on screen at two sizes, no English left, the picker and the saved choice',
  },
  // Technical
  { area: 'Technical', check: 'No bugs or broken mechanics: play several runs, pause and resume, lose, restart, reload', anchor: 'Bugs or broken mechanics', platform: 'gp qa: console errors, the host contract, saves (not a run that ends twice or never)' },
  { area: 'Technical', check: 'Loads quickly and plays without stutter or crashes', anchor: 'The game must load quickly and play seamlessly without errors or crashes.', platform: 'gp build: the size and load budget' },
  { area: 'Technical', check: 'Physics and timing the same at 60, 144 and 165 Hz', anchor: "The game's physics must perform consistently across different monitor refresh rates" },
  { area: 'Technical', check: 'Controls consistent and intuitive; mouse, keyboard and (if mobile is declared) touch', anchor: 'The controls are consistent and intuitive throughout the game.' },
  { area: 'Technical', check: 'Esc and Ctrl+W are not game keys; WASD also works on AZERTY; no custom fullscreen button', anchor: 'Avoid common keys that have other behaviour on web', platform: 'gp qa: no fullscreen button; MoveInput reads physical keys' },
  // Ads: rule failures are "rejected without any feedback"
  { area: 'Ads', check: 'With ads off (Basic Launch, an ad blocker) no rewarded button does nothing, and nothing freezes', anchor: 'There should not be rewarded ad buttons without effect.', platform: 'gp qa [ads fail] and [production, ads blocked] — look at ads-fail-rewarded.png: does the player learn why?' },
  { area: 'Ads', check: 'Midgame ads only at real breaks, never on a navigational button (menu, settings, shop)', anchor: 'Do not show a midgame ad on a', platform: 'E_ADS_LIMITS, gp qa ad checks' },
  { area: 'Ads', check: 'A rewarded offer is a special opportunity, never needed to progress; the player sees what it gave', anchor: 'should be special opportunities that a user looks forward to' },
  { area: 'Ads', check: 'Rewarded ads are not pushed too hard: not on every screen, not on the active gameplay screen', anchor: 'Do not promote the rewarded ads too aggressively.', platform: 'gp qa: no offer during play' },
  // Content rules
  { area: 'Content', check: 'PEGI 12 and not aimed at children', anchor: 'Content is targeted for kids', platform: 'E_CHANNEL_AUDIENCE' },
  { area: 'Content', check: 'No cross-promotion: no store links, no other portal, community links only on the menu', anchor: 'The game should not include cross-promotions', platform: 'gp qa (production): no store or portal links' },
  // The listing
  { area: 'Covers and video', check: 'Covers: the title is the only text; not a plain screenshot; uncluttered; readable at thumbnail size', anchor: "Don't just take a screenshot of the game", platform: 'gp submission checks the sizes; gp covers scores each cover at 200 px (cover-check.md: title size and contrast, hero vs. background, colour, near-black and flat area, clutter, borders) and shows them as players do (cover-preview-200.png); the look is yours' },
  { area: 'Covers and video', check: 'The preview video shows real gameplay, and the first seconds after the opening cover show what makes the game different (the static cover opens every video on purpose: the portal asks for it — not a finding)', anchor: 'You can use animated video as long as it represents the gameplay and is not misleading.', platform: 'gp submission checks length, codec, sound; gp video opens on the cover, as CrazyGames requires' },
  { area: 'Covers and video', check: 'The description and controls say honestly what the game is (genre, the twist) and match the covers', anchor: 'The description and controls text say honestly what the game is' },
];

/** Where an item's anchor sits in the research file: its line, the section above it and the source markers on the line */
export function checklistSource(item: ChecklistItem, research: string[]): { line: number; section: string; markers: string } | null {
  const i = research.findIndex((l) => l.includes(item.anchor));
  if (i < 0) return null;
  let section = '';
  for (let j = i; j >= 0; j--)
    if (/^##\s/.test(research[j])) {
      section = research[j].replace(/^##\s+/, '').replace(/[:(].*$/, '').trim();
      break;
    }
  const markers = [...new Set([...research[i].matchAll(/\[(S|F|3rd(?:-M)?)(?::[^\]]*)?\]/g)].map((m) => m[0]))].join(' ');
  return { line: i + 1, section, markers };
}

// --- The portal's verdicts on our games: traits as data ---------------------------------------------------------------

/** A trait of a game as submitted: true, false, or null (not recorded — say so, don't guess) */
type Trait = boolean | null;

export interface VerdictTraits {
  /** Made with the concept gate (concept in game.yaml, the portal search first) */
  conceptGate: Trait;
  /** The progression screen as submitted was the stock "+stat" level shop (Yeet's list, in its own or mountUpgradeShop's form) */
  stockShop: Trait;
  /** A failed rewarded ad left the player without a word (or the skip was smaller than the offer) when it was submitted */
  rewardedWrong: Trait;
  /** Text or story before the first action */
  textFirst: Trait;
  /** Systems around the core action, as the records list them */
  systems: string;
  /** Where these facts are written */
  source: string;
}

/**
 * The traits of the games the portal answered for by 2026-10-01 (the later answers have no traits recorded yet). Only what
 * our records say; null where they don't.
 * The verdicts themselves come from publisher/results.yaml.
 */
export const VERDICT_TRAITS: Record<string, VerdictTraits> = {
  'petri-panic': { conceptGate: false, stockShop: false, rewardedWrong: false, textFirst: null, systems: 'auto-attack weapons, level-up cards, 3 stages, DNA meta upgrades', source: 'results.yaml; retro-petri-panic.md; retro-portal-games.md (its failed rewarded was fixed before submission)' },
  'spin-brawl': { conceptGate: false, stockShop: false, rewardedWrong: true, textFirst: null, systems: 'online multiplayer with its own server', source: 'results.yaml ("a silent failed revive, 11 px text at 821×462")' },
  'yeet-the-gnome': { conceptGate: false, stockShop: true, rewardedWrong: true, textFirst: null, systems: 'coins, 8 "+stat" upgrades, 9 zones', source: 'results.yaml; upgrades.md (the stock shop is Yeet\'s); retro-portal-games.md ("Collect" ≈ 3× narrower than the ad offer)' },
  'brew-and-banter': { conceptGate: false, stockShop: true, rewardedWrong: true, textFirst: true, systems: 'day runs, visitor orders, upgrades, a 12-chapter story with endings', source: 'results.yaml (the silent "×2 gold tomorrow"); upgrades.md; game-anatomy.md §4 (≈ 110 words before playing)' },
  'germ-bait': { conceptGate: false, stockShop: true, rewardedWrong: true, textFirst: null, systems: '12 dishes, 8 upgrades, an endless mode; the microbe theme of the rejected Petri Panic', source: 'results.yaml (a failed ad without a message, "No thanks" smaller than the offer); retro-games-6-11.md' },
  'hang-the-moon': { conceptGate: true, stockShop: false, rewardedWrong: false, textFirst: null, systems: '30 solver-proven nights', source: 'results.yaml; retro-games-6-11.md (blocks: rewardedButton only)' },
  'nimbus-drift': { conceptGate: true, stockShop: false, rewardedWrong: false, textFirst: null, systems: '39 solver-proven levels', source: 'results.yaml; retro-games-6-11.md (blocks: rewardedButton only)' },
  'dread-throne': { conceptGate: true, stockShop: false, rewardedWrong: false, textFirst: null, systems: 'a 6-chapter story, a pact tree with oaths, trap forks (UpgradeShop math behind its own screen)', source: 'results.yaml ("remade before submission"); retro-games-6-11.md' },
  starsilk: { conceptGate: true, stockShop: false, rewardedWrong: false, textFirst: null, systems: 'a story, two bosses, the Loom (mountUpgradeShop behind its own tiered tree and icons)', source: 'results.yaml ("remade before submission"); retro-games-6-11.md' },
};

const mark = (t: Trait) => (t === null ? 'not recorded' : t ? 'yes' : 'no');

/** The verdicts table and what it does and doesn't show */
export function verdictLessons(results: RecordedResult[]): string {
  const answered = results.filter((r) => r.review && r.review.verdict !== 'pending');
  const L: string[] = [];
  L.push(
    `The portal has answered for ${answered.length} of our games (publisher/results.yaml). These are the traits our records give for each, as submitted. **They are data, not causes:** the portal names no reason beyond the stock sentence, and ${answered.length} games are too few to tell one trait from another.`,
    '',
    '| Game | Verdict | Made with the concept gate | uniqueness | Stock "+stat" shop screen | Failed rewarded silent / skip smaller | Text before the first action | Systems around the core | Source |',
    '|---|---|---|---|---|---|---|---|---|',
  );
  for (const r of answered) {
    const t = VERDICT_TRAITS[r.game];
    const verdict = `${r.review!.verdict}${r.review!.reason ? `: "${r.review!.reason}"` : ''}`;
    L.push(
      `| ${r.title ?? r.game} | ${verdict} | ${t ? mark(t.conceptGate) : 'not recorded'} | ${r.uniqueness ?? '—'} | ${t ? mark(t.stockShop) : 'not recorded'} | ${t ? mark(t.rewardedWrong) : 'not recorded'} | ${t ? mark(t.textFirst) : 'not recorded'} | ${t?.systems ?? 'not recorded'} | ${t?.source ?? 'results.yaml'} |`,
    );
  }
  const quality = answered.filter((r) => r.review!.verdict === 'rejected' && /overall quality/i.test(r.review!.reason ?? ''));
  const approved = answered.filter((r) => r.review!.verdict === 'approved');
  const later = answered.filter((r) => (r.review!.date ?? '') > '2026-10-01');
  const stopped = answered.filter((r) => r.basicLaunch?.verdict === 'stopped');
  // Out of the games whose trait is recorded; the rest are named, not counted as "no"
  const share = (rows: RecordedResult[], k: keyof Omit<VerdictTraits, 'systems' | 'source'>) => {
    const known = rows.filter((r) => typeof VERDICT_TRAITS[r.game]?.[k] === 'boolean');
    const rest = rows.length - known.length;
    return `${known.filter((r) => VERDICT_TRAITS[r.game]![k] === true).length} of ${known.length}${rest ? ` (+${rest} not recorded)` : ''}`;
  };
  L.push(
    '',
    'What the table shows, and what it doesn\'t:',
    '',
    `- **The concept gate.** ${share(quality, 'conceptGate')} quality rejections were made with it; ${share(approved, 'conceptGate')} approved games were. The games of 2026-10-01 made with the gate and \`gp uniqueness\` were all approved; the later ones were not: of ${later.length} answered since, ${later.filter((r) => r.review!.verdict === 'approved').length} approved, and the rest rejected for overall quality or a concept close to existing titles. The gate gets a game past the concept check, not the quality one.`,
    ...(stopped.length
      ? [
          `- **Approval is not the launch.** ${stopped.map((r) => r.title ?? r.game).join(', ')} ${stopped.length === 1 ? 'was' : 'were'} stopped after Basic Launch: "did not reach the performance benchmarks" — ${stopped.map((r) => `${r.title ?? r.game} ${r.basicLaunch!.avgPlaytimeMin ?? '?'} min, D1 ${r.basicLaunch!.d1 !== undefined ? `${(r.basicLaunch!.d1 * 100).toFixed(1)} %` : '?'}, past 1 min ${r.basicLaunch!.conversion1min !== undefined ? `${Math.round(r.basicLaunch!.conversion1min * 100)} %` : '?'}`).join('; ')}. Players judge the first minute and the reason to come back: playtime, D1 and conversion are what decides (the score table: "Basic Launch" below).`,
        ]
      : []),
    `- **The stock "+stat" shop as the screen.** In ${share(quality, 'stockShop')} quality rejections and ${share(approved, 'stockShop')} approved games. But Starsilk was approved with \`mountUpgradeShop\` behind its own tiered Loom, and Dread Throne with \`UpgradeShop\` math behind its own pact tree: the shop code alone doesn't explain a rejection. Judge the screen the player sees: is the progression the game's own shape, or a list of "+stat" cards any game could have?`,
    `- **A failed rewarded ad that says nothing** (or a "No thanks" smaller than the offer). In ${share(quality, 'rewardedWrong')} quality rejections — and in Spin Brawl, which was approved. The portal's ads rule says a rewarded button without effect is rejected; it is a cheap fix, not an explanation.`,
    `- **The first minute.** Brew & Banter put ≈ 110 words of story before the first tap; for the other games our records don't say. The portal's own advice: land in gameplay, onboarding in play, visuals over text.`,
    '- **Extra systems.** The rejected games each carried several systems around the core action (orders, day runs and a story on a clicker; an endless mode and upgrades on a puzzle; zones and upgrades on a launcher). So does Dread Throne (story, pacts, trap forks), which was approved. The question is not how many systems, but whether each one is finished and serves the core action in the first minutes a reviewer plays.',
    '- **The theme.** Germ Line carried the microbe theme of the rejected Petri Panic.',
    '',
    'Use the table as questions to ask of this game, not as rules: where this game shares a trait with the rejected ones, say whether it hurts here, and how much.',
  );
  return L.join('\n');
}

// --- The session: from the first minute to the tenth (qa/session.json) ------------------------------------------------

/** qa/session.json as gp qa writes it (the fields the brief reads; every one may be missing) */
export interface SessionFacts {
  bot?: 'demo' | 'idle';
  playedSec?: number;
  short?: boolean;
  firstStop?: { kind: string; why: string; atSec: number } | null;
  estimate?: { meanMin: number; medianMin: number; at10: number };
  lines?: { stop: string; breaks: string; pulls: string; estimate: string };
}

/** The brief's session lens: play 12 minutes as a new player on desktop, mark where you'd close the tab */
export function sessionSection(game: Pick<ResolvedGame, 'channel'>, s: SessionFacts | null): string[] {
  const cg = game.channel.id === 'crazygames';
  const L: string[] = ['', `### The session: ${SESSION_PLAY_MIN} minutes as a new player (desktop)`, ''];
  L.push(
    `Every Basic Launch we had stopped on CrazyGames' **average playtime**: Hang the Moon 4m50s on desktop (1/5), Potion Logic 3m52s (1/5), Dread Throne 3m18s (1/5) — Candle Crypt's 9m31s scored 4 and 12m13s scores 5 (publisher/results.yaml). After the first minute, **play on for ${SESSION_PLAY_MIN} minutes from a fresh save on desktop (1280×720)**, as someone who chose this game from the portal's front page, and note the moment you would have closed the tab: a results screen with nothing pulling you into the next run, a wait, an offer you have to take to go on, a goal that didn't move, a stretch with nothing new. What pulled you on until then (the next run starting by itself, the next goal on screen, a reward every 2–3 min)?`,
    '',
    `Write it in quality.md under \`## Session\`: \`- Where I'd stop: mm:ss — <why>\` (or \`none — <why>\` when you played the ${SESSION_PLAY_MIN} minutes and would go on).${cg ? ` **On CrazyGames a stop before ${SESSION_STOP_MIN}:00 is a \`[blocking]\` finding** that names the session — \`gp review --check\` refuses quality.md without it.` : ''}`,
  );
  if (s?.lines) {
    L.push('', `From qa/session.json — ${s.short ? `**the first natural stop comes before 10 min of play** (W_SESSION_SHORT${cg ? '' : ', a warning on CrazyGames'})` : 'the first natural stop comes after 10 min of play, or none came'}; ${s.bot === 'idle' ? 'an idle player (no demo bot: a lower bound)' : 'the demo bot'} played ${s.playedSec !== undefined ? `${Math.floor(s.playedSec / 60)}:${String(Math.round(s.playedSec % 60)).padStart(2, '0')}` : '?'}:`, '');
    L.push(`- First natural stop: ${s.lines.stop}`, `- Estimate: ${s.lines.estimate}`, `- What pulls on: ${s.lines.pulls}`, `- The breaks: ${s.lines.breaks}`);
    L.push('', 'Check it in play: the bot taps the big button at once and never reads; you are slower, and a real stop may come earlier. Where you disagree, say so.');
  } else L.push('', '(No qa/session.json yet: it comes with `gp qa` on this platform.)');
  return L;
}

// --- The first minute as pass/fail lines (qa/first-minute.json) ------------------------------------------------------

/** qa/first-minute.json as gp qa writes it; every field may be missing in an older or a newer file */
export interface FirstMinuteFacts {
  playReadyMs?: number | null;
  playToRunMs?: number | null;
  idleEndSec?: number | null;
  words?: number | null;
  firstHighlightSec?: number | null;
  twistSec?: number | null;
  demoEndSec?: number | null;
  [more: string]: unknown;
}

export interface FirstMinuteLine {
  /** true pass, false fail, null measured without a limit here */
  ok: boolean | null;
  text: string;
}

const KNOWN_FIRST_MINUTE = new Set(['at', 'playReadyMs', 'playToRunMs', 'idleEndSec', 'words', 'firstHighlightSec', 'twistSec', 'demoEndSec', 'clicksToGameplay', 'touchControlsVisible', 'touchControls', 'touchBot', 'cpu4xFps', 'fps4x', 'startLoudness']);

/** A field another platform version may write as a number, a boolean, or { value, ok, … } */
function verdictOf(v: unknown): { ok: boolean | null; value: unknown } {
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    const o = v as Record<string, unknown>;
    const ok = [o.ok, o.pass, o.passed, o.visible, o.reached, o.reachedRun].find((x) => typeof x === 'boolean') as boolean | undefined;
    const value = o.value ?? o.fps ?? o.db ?? o.peakDb ?? o.lufs ?? o.clicks ?? o.sec ?? o.ms ?? null;
    return { ok: ok ?? null, value };
  }
  return { ok: typeof v === 'boolean' ? v : null, value: v };
}

const show = (v: unknown) => (v === null || v === undefined ? '—' : typeof v === 'object' ? JSON.stringify(v) : String(v));

/**
 * The first minute's numbers as pass/fail lines, against the limits of docs/research/feedback-and-metrics-2026-10.md §4.1
 * (C1, C3, G3) and the CrazyGames rule (≤ 1 click to gameplay). Missing fields are skipped; unknown ones listed as they are.
 */
export function firstMinuteLines(fm: FirstMinuteFacts, twistWithin: number | null): FirstMinuteLine[] {
  const L: FirstMinuteLine[] = [];
  const sec = (ms: number) => `${(ms / 1000).toFixed(1)} s`;
  const has = (k: string) => k in fm && fm[k] !== undefined;
  if (has('playReadyMs')) L.push(fm.playReadyMs === null ? { ok: false, text: 'Play tappable after opening: never' } : { ok: fm.playReadyMs! <= 3000, text: `Play tappable after opening: ${sec(fm.playReadyMs!)} (limit 3 s, CrazyGames' load budget)` });
  if (has('clicksToGameplay')) {
    const { ok, value } = verdictOf(fm.clicksToGameplay);
    const n = typeof value === 'number' ? value : null;
    L.push({ ok: ok ?? (n === null ? null : n <= 1), text: `Clicks from opening to gameplay: ${show(value)} (CrazyGames: "a maximum of 1 click is allowed"; 0 is best — a first visit lands in play)` });
  }
  if (has('playToRunMs')) L.push(fm.playToRunMs === null ? { ok: false, text: 'Play → the run: no run within 8 s without another tap' } : { ok: true, text: `Play → the run: ${sec(fm.playToRunMs!)} without another tap` });
  if (has('idleEndSec')) L.push(fm.idleEndSec === null ? { ok: true, text: 'A player who touches nothing: still playing after 12 s' } : { ok: false, text: `A player who touches nothing: the run ends after ${fm.idleEndSec} s (limit: none before 12 s)` });
  if (has('words') && typeof fm.words === 'number') L.push({ ok: fm.words <= 25, text: `Words on screen in the first seconds of the run: ${fm.words} (limit 25; onboarding ≤ 2 short lines)` });
  for (const k of ['touchControlsVisible', 'touchControls']) {
    if (!has(k)) continue;
    const { ok, value } = verdictOf(fm[k]);
    L.push({ ok, text: `Touch controls visible at the run's first frame (360×800): ${ok === null ? show(value) : ok ? 'yes' : 'no'}` });
  }
  if (has('touchBot')) {
    const tb = fm.touchBot as Record<string, unknown> | null;
    if (tb && typeof tb === 'object' && 'gameplaySec' in tb && 'playedSec' in tb) {
      // gp qa's own shape: in gameplay, playing (15 s or a run event), and since 2026-10-19 no loss or results meanwhile
      const lost = (tb.failedAt ?? null) as { type: string; sec: number } | null;
      const plays = tb.gameplaySec !== null && (Number(tb.playedSec) >= 15 || Number(tb.events) > 0);
      L.push({
        ok: plays && !lost,
        text: `A naive touch bot (random taps and drags${tb.sec ? ` for ${tb.sec} s` : ''}) keeps playing without a loss: ${plays ? (lost ? `no — ${lost.type === 'fail' ? 'a fail' : 'the results'} after ${lost.sec} s (a new player's first minute must not end)` : 'yes') : 'no — it never played'} (${show(tb)})`,
      });
    } else {
      const { ok, value } = verdictOf(fm.touchBot);
      L.push({ ok, text: `A naive touch bot (random taps and drags) reaches a run: ${ok === null ? show(value) : ok ? 'yes' : 'no'}${ok !== null && fm.touchBot && typeof fm.touchBot === 'object' ? ` (${show(fm.touchBot)})` : ''}` });
    }
  }
  for (const k of ['cpu4xFps', 'fps4x']) {
    if (!has(k)) continue;
    const { ok, value } = verdictOf(fm[k]);
    const n = typeof value === 'number' ? value : null;
    L.push({ ok: ok ?? (n === null ? null : n >= 30), text: `Frame rate at 4× CPU slowdown in the first 30 s (a slow phone): ${n === null ? show(value) : `${Math.round(n)} fps`} (limit 30 fps)` });
  }
  if (has('startLoudness')) {
    const { ok, value } = verdictOf(fm.startLoudness);
    L.push({ ok, text: `Loudness in the first 3 s: ${show(value)}${ok === null ? ' (no limit known to this brief: listen — nothing loud before the player chose anything)' : ''}` });
  }
  if (has('firstHighlightSec')) L.push(fm.firstHighlightSec === null ? { ok: false, text: 'The demo bot\'s first celebrated moment: none in 45 s' } : { ok: fm.firstHighlightSec! <= 15, text: `The demo bot's first celebrated moment: ${fm.firstHighlightSec} s (limit 15 s: a reward inside 15 s)` });
  if (has('twistSec')) L.push(fm.twistSec === null ? { ok: twistWithin === null ? null : false, text: 'The twist: not met by the demo bot' } : { ok: twistWithin === null ? null : fm.twistSec! <= twistWithin, text: `The twist: ${fm.twistSec} s${twistWithin !== null ? ` (concept.twist.within ${twistWithin} s)` : ''}` });
  if (has('demoEndSec') && fm.demoEndSec !== null) L.push({ ok: null, text: `The demo bot's run ended at ${fm.demoEndSec} s` });
  for (const [k, v] of Object.entries(fm)) {
    if (KNOWN_FIRST_MINUTE.has(k) || v === undefined) continue;
    const { ok, value } = verdictOf(v);
    L.push({ ok, text: `${k}: ${show(ok === null ? v : value)}` });
  }
  return L;
}

// --- Basic Launch: how the portal scores the first week ----------------------------------------------------------------

/** The Basic Launch section: the three metrics, how they score, and every score screen in publisher/results.yaml */
export function basicLaunchSection(results: RecordedResult[]): string[] {
  const screens = results.filter((r) => r.basicLaunch?.scores);
  const L: string[] = [
    '## Basic Launch: how the portal scores the first week (docs/research/feedback-and-metrics-2026-10.md §1)',
    '',
    `Approval only starts Basic Launch: 7–21 days without ads, then Full Launch or a stop that is final. CrazyGames scores three metrics, **each 1–${BASIC_LAUNCH.maxScore} per device class** (Desktop; Mobile and Tablet), and **Full Launch needs ≥ ${BASIC_LAUNCH.fullLaunchAt} of ${BASIC_LAUNCH.of} on a device class**. The scores are relative: a game is ranked against its peers (by category and device), so the same 51.5 % conversion scored 4 for our .io game on mobile and 1 for Candle Crypt on desktop. About 70 % of plays are mobile, and mobile converted at about half the desktop rate in all our games — but the dashboard's Evaluation Prognosis counts Mobile and Tablet "only if it passes Desktop" (Candle Crypt, 2026-10-10: desktop 7/15 was the gate), and the portal\'s QA judges a submission on a desktop: **play the desktop (1280×720) first, then the phone**.`,
    '',
    '| Metric | CrazyGames\' definition | Benchmark | What scored what in our games |',
    '|---|---|---|---|',
    '| Average playtime | the average time a player spends in the game in one session | successful titles 10+ min | Candle Crypt desktop 9m31s → 4 (5 starts at 12m13s); mobile 4m19s–5m28s → 2 (three games) |',
    '| D1 retention | the share of players who come back the day after their first session | strong games 10–15 % | Candle desktop 2.96 % → 2 (3 starts at 3.94 %); mobile ≈ 1.7–1.8 % → 1–2 |',
    '| Gameplay conversion | the share of players who play at least one minute after starting the game (no SDK: counted from the portal\'s start, so a title, a Play button and a tutorial are inside that minute) | top titles 80 %+ | Candle desktop 51.25 % → 1 (2 starts at 54 %); Spin Brawl mobile 51.69 % → 4; Hang the Moon mobile 30.96 % → 1 |',
    '',
  ];
  if (screens.length) {
    L.push('Score screens recorded in publisher/results.yaml:', '', '| Game | Category | Screen | Device | Playtime | D1 | Conversion | Total |', '|---|---|---|---|---|---|---|---|');
    for (const r of screens) {
      const sc = r.basicLaunch!.scores!;
      for (const dev of BASIC_LAUNCH.devices) {
        const d = sc[dev];
        if (!d) continue;
        const cell = (m: 'playtime' | 'd1' | 'conversion') => {
          const x = d[m];
          if (!x) return '—';
          const v = x.value === undefined ? '' : m === 'playtime' ? `${x.value} min` : `${(x.value * 100).toFixed(2)} %`;
          const next = x.next === undefined ? '' : ` (next at ${m === 'playtime' ? `${x.next} min` : `${(x.next * 100).toFixed(2)} %`})`;
          return `${v}${v ? ' → ' : ''}**${x.score ?? '?'}**${next}`;
        };
        const t = deviceTotal(d);
        L.push(`| ${r.title ?? r.game} | ${r.category ?? 'not recorded'} | ${sc.date ?? '—'} | ${dev === 'desktop' ? 'Desktop' : 'Mobile and Tablet'} | ${cell('playtime')} | ${cell('d1')} | ${cell('conversion')} | ${t ?? '?'}/${BASIC_LAUNCH.of}${t !== null ? (t >= BASIC_LAUNCH.fullLaunchAt ? ` ✓ (≥ ${BASIC_LAUNCH.fullLaunchAt})` : ` ✗ (< ${BASIC_LAUNCH.fullLaunchAt})`) : ''} |`);
      }
    }
    L.push('');
  }
  L.push(
    'What this means for your review: conversion scored 1/5 in every device score we know outside the .io game — a 1 → 3 there is +2 points on both device classes. Judge the first minute hardest (a gate before play, reading before doing, invisible phone controls, a punishing start), then what keeps a session going (each results screen is an exit) and the reason to come back tomorrow (a daily or a goal left open, visible on the title).',
    '',
  );
  return L;
}

// --- The CrazyGames promotions to [blocking] (docs/research/feedback-and-metrics-2026-10.md §5) -------------------------

export const CRAZYGAMES_BLOCKING: { what: string; look: string }[] = [
  { what: 'No background music (or no way to set the volume)', look: 'listen from the title into a run; settings: music and effects sliders' },
  { what: 'Emoji or the system\'s glyphs (★ ❤ ⚙) as the game\'s icons', look: 'every item, upgrade, currency, button and HUD icon: drawn in the game\'s style?' },
  { what: 'A meta screen that is a plain list, or the stock upgrade shop with no art', look: 'the shop, the upgrade, unlock and level screens: drawn, the game\'s own shape — or rows of text and "+stat" cards?' },
  { what: 'Onboarding longer than 2 short lines of text, or a modal before the first action', look: 'a fresh save: what stands between the first frame and the first action?' },
  { what: 'A first visit that doesn\'t reach gameplay in ≤ 1 click (CrazyGames: "Games should land new users in gameplay immediately. If this is not feasible given the game specifics, a maximum of 1 click is allowed.")', look: 'a private window: count the clicks to control (the portal\'s Play Now not counted)' },
  { what: 'Touch controls not visible at the first frame of the run', look: '360×800, touch only, before touching: is the stick, the drag zone or each button drawn?' },
  { what: 'Half the screen empty at 1280×720 or 360×800 (a playfield in a corner, a dead band, a lone panel)', look: 'the first screen, play, results and the meta screen at both sizes' },
  { what: 'A platform sheet (language picker, dialogue, shop) unlike the game\'s style', look: 'open each: the game\'s palette, font and frame — or the platform\'s default look?' },
  { what: 'A preview video whose first 5 s (after the opening cover) don\'t show the twist', look: 'store/preview-*.mp4: what happens between 0.5 s and 5 s?' },
];

// --- The calibrated look and the last pass ------------------------------------------------------------------------------

/** The reviews that passed what the portal rejected (publisher/results.yaml, the games' REPORT.md and quality.md) */
export const CALIBRATION_MISSES =
  'Swarm Smash 1.2.0 (0 blocking / 0 nice, rejected 2026-10-12), Candle Crypt 1.7.2 (its last round 0 blocking, 6 nice — all fixed; rejected 2026-10-12), Velvet Domino Rogue (0 blocking, 14 nice; rejected 2026-10-18)';

/** One resubmission after a Basic Launch stop, and what the portal said */
export interface Resubmission {
  game: string;
  title: string;
  stopped: string | null;
  verdict: 'approved' | 'rejected';
  date: string | null;
  /** The portal's reason, when it gave one */
  reason?: string;
}

/** Every record that came after a Basic Launch stop of the same game (publisher/results.yaml), with the portal's answer */
export function resubmissions(results: readonly RecordedResult[]): Resubmission[] {
  const out: Resubmission[] = [];
  const byGame = new Map<string, RecordedResult[]>();
  for (const r of results) byGame.set(r.game, [...(byGame.get(r.game) ?? []), r]);
  for (const rows of byGame.values()) {
    const sorted = [...rows].sort((a, b) => (a.review?.date ?? '').localeCompare(b.review?.date ?? ''));
    sorted.forEach((r, i) => {
      const before = sorted.slice(0, i).find((x) => x.basicLaunch?.verdict === 'stopped');
      const v = r.review?.verdict;
      if (!before || (v !== 'approved' && v !== 'rejected')) return;
      out.push({ game: r.game, title: r.title ?? r.game, stopped: before.basicLaunch?.scores?.date ?? null, verdict: v, date: r.review?.date ?? null, ...(r.review?.reason ? { reason: r.review.reason } : {}) });
    });
  }
  return out.sort((a, b) => (a.date ?? '').localeCompare(b.date ?? ''));
}

/** The review sheet in the brief: where it is, what each frame is, the references and how to score */
export function sheetSection(sheet: ReviewSheet | null): string[] {
  const L: string[] = ['## The review sheet: the look against what CrazyGames approved and rejected', ''];
  if (!sheet) {
    L.push(`No review sheet in this brief: \`gp review\` builds qa/${SHEET_FILE} (the game's frames at 1280×720 beside the references in publisher/reference/). Run it again, or open the references there and the QA screenshots yourself.`, '');
  } else {
    L.push(
      sheet.file ? `**${shown(sheet.file)}** — open it full size. The game's own frames, 1280×720 at DPR 1 (the desktop the portal's QA plays first):` : `The sheet could not be composed (${sheet.problems.join('; ')}); compare these files yourself. The game's frames:`,
      '',
      ...sheet.cells.map((c) => `- \`${c.id}\` (${c.label}): ${c.file ? `${shown(c.file)} — ${c.note}` : `**${c.note}**`}`),
      '',
      'Under them, our own games as CrazyGames answered for them (publisher/reference/index.yaml):',
      '',
      ...[...sheet.approved, ...sheet.rejected].map((r) => `- **${r.outcome === 'approved' ? 'Approved' : 'Rejected for overall quality'}** — ${r.title} ${r.version}, ${r.date} (${r.screen}): ${shown(r.path)} — ${r.shows}`),
      '',
    );
    if (sheet.problems.length) L.push('What the sheet is missing or what went wrong:', '', ...sheet.problems.map((p) => `- ${p}`), '');
  }
  L.push(
    `**Score each of the game's screens 1–5: would it sit on CrazyGames' front page next to these?** Compare at full size, screen with screen (the title with the approved titles, play with play), and write the reason as a comparison.`,
    '',
    '- **5** — it would stand out on the front page: a clear focal point, the screen filled with the game, one style, lit and alive, type that belongs to the game.',
    '- **4** — as finished as the approved shots: one style across the frame, the game fills 1280×720, drawn buttons and icons, readable type of its own; nothing reads as a placeholder.',
    `- **3** — a game, but plainer, emptier or smaller than the approved shots; what the rejected ones look like. **[blocking]**`,
    '- **2** — reads as a prototype or a web page: system fonts, grey or flat buttons, a tiny HUD, a big empty area, mixed styles. **[blocking]**',
    '- **1** — placeholder art, or broken at this size. **[blocking]**',
    '',
    'Approval is a low bar, not the goal: every approved game on the sheet was stopped after Basic Launch. A 4 means "at least as finished as these", not "good enough".',
    '',
  );
  return L;
}

/** The last pass before the submission (no new systems) and the record of resubmissions after a stop */
export function lastPassSection(game: Pick<ResolvedGame, 'id' | 'title'>, results: readonly RecordedResult[], lastCommits: readonly string[] = [], key: { loc?: string; repo?: string | null } = {}): string[] {
  const re = resubmissions(results);
  const rejected = re.filter((r) => r.verdict === 'rejected');
  const approved = re.filter((r) => r.verdict === 'approved');
  const quality = rejected.filter((r) => !r.reason || /overall quality/i.test(r.reason));
  const other = rejected.filter((r) => !quality.includes(r));
  const named = (xs: Resubmission[]) => xs.map((r) => `${r.title} ${r.date ?? ''}`.trim()).join(', ');
  const why = [quality.length ? `${named(quality)} for the overall quality` : '', ...other.map((r) => `${named([r])}: "${r.reason}"`)].filter(Boolean).join('; ');
  const L: string[] = [
    '## The last pass before the submission, and resubmissions',
    '',
    '- **No new systems in the last pass before submission — only feel (juice, sound, typography, layout).** A system added in the last day is a screen nobody polished, and our rejected games grew features faster than feel: Swarm Smash went with 78 parts, 16 synergies and 7 bosses, Candle Crypt 1.7.2 with 75 weapons, the light and d20 hits, Velvet Domino Rogue v3 with a 2D network, a kinetic fall, a bet, a bazaar and a workshop — all three rejected for the overall quality (publisher/results.yaml, the games\' REPORT.md). If the last commits add a mechanic, a mode, a shop or a screen, write a `[blocking]` finding: freeze it for the next update, or finish its look first.',
  ];
  if (re.length)
    L.push(
      `- **A resubmission after a stop needs a big visible change.** ${rejected.length} of ${re.length} resubmissions after a Basic Launch stop were rejected (${why})${approved.length ? `; ${approved.map((r) => r.title).join(', ')} came back approved` : ''} — the rejected ones came back without a big change you can see in a screenshot (Starsilk 2.0.1 looks like the build approved ten days before: publisher/reference/rejected/starsilk-1.jpg). A game resubmitted after a stop "as a new game including significant improvements" is judged on what a reviewer sees in the first minutes: new title art, a new look of play, a new first minute — not new numbers.`,
    );
  const own = recordsOf(results, { ids: [game.id, ...(key.loc ? [key.loc] : [])], title: game.title, repo: key.repo });
  const stop = own.find((r) => r.basicLaunch?.verdict === 'stopped');
  const lastRejected = [...own].reverse().find((r) => r.review?.verdict === 'rejected');
  if (stop || lastRejected)
    L.push(
      `- **This game has been answered before**: ${[stop ? `stopped after Basic Launch${stop.basicLaunch?.scores?.date ? ` (${stop.basicLaunch.scores.date})` : ''}` : '', lastRejected ? `rejected on ${lastRejected.review?.date ?? '?'} ("${lastRejected.review?.reason ?? ''}")` : ''].filter(Boolean).join('; ')}. Compare its frames with how it looked then (publisher/reference/ when the sheet has it, the previews' history otherwise): if a player couldn't tell the two apart from a screenshot, that is a \`[blocking]\` finding.`,
    );
  if (lastCommits.length) L.push('', `The game's commits of its last day (git log), to check for new systems:`, '', ...lastCommits.map((c) => `- ${c}`));
  L.push('');
  return L;
}

/** The subjects of the game folder's commits in the 24 hours before its newest one (at most `max`) */
export function lastDayCommits(loc: GameLocation, max = 15): string[] {
  try {
    const rows = execFileSync('git', ['log', '--format=%ct\t%h %s', '-n', '200', '--', '.'], { cwd: loc.dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
      .split('\n')
      .filter(Boolean)
      .map((l) => ({ t: Number(l.split('\t')[0]), s: l.slice(l.indexOf('\t') + 1) }));
    if (!rows.length) return [];
    const newest = rows[0].t;
    return rows.filter((r) => newest - r.t <= 24 * 3600).slice(0, max).map((r) => clip(r.s, 160));
  } catch {
    return [];
  }
}

// --- The brief ------------------------------------------------------------------------------------------------------

export interface ReviewFacts {
  /** gp uniqueness */
  uniqueness: { score: number; verdict: string; gate: string | null; markdownTable: string } | null;
  /** The forecast's one line and its top levers */
  forecast: { line: string; levers: string[] } | { error: string } | null;
  /** The code's rewarded placements and whether it calls adBreak */
  code: { rewarded: string[]; adBreak: boolean } | null;
  /** The progression the code shows (gp uniqueness' signal) */
  progression: string | null;
  /** The upload's size lines (gp build --target crazygames) */
  size: string[] | null;
  qa: { date: string; passed: number; failed: number; failedChecks: string[]; infos: number; report: string; look: string[]; warnings?: string[]; mode?: string; base?: string; quick?: boolean } | null;
  screenshots: string[];
  media: string[];
  /** media older than the game's code (Almus Gate: the reviewer judged stale videos) */
  staleMedia: string[];
  balance: string | null;
  /** qa/first-minute.json: what a new player meets in the first minute (gp qa); newer platforms add fields (read when present) */
  firstMinute?: FirstMinuteFacts | null;
  /** qa/session.json: where a new player's session ends (gp qa's session section) */
  session?: SessionFacts | null;
  /** Music as far as the platform can tell: the code starts it (createMusic), or game.yaml sound.music says what plays */
  music?: { code: boolean; declared: string | false | null } | null;
  /** Emoji in the code and the English strings (a hint: icons that should be drawn) */
  emoji?: { files: string[]; chars: string[] } | null;
  /** The scope check: systems around the core, declared screens, hours from the first to the last commit */
  scope?: ScopeFacts | null;
  /** qa/review-sheet.png and what is on it (gp review builds it; null: not built) */
  sheet?: ReviewSheet | null;
  /** The game folder's commits of its last day: the last pass before the submission */
  lastCommits?: string[];
  /** qa/first-look.md: the blind agent's answers (gp review --first-look); null: not written yet */
  firstLook?: FirstLook | null;
  results: RecordedResult[];
  issues: Issue[];
}

/** What to look for in a QA screenshot, by its name */
function shotHint(name: string): string {
  if (/review-sheet\.png$/.test(name)) return 'the review sheet: score each of the game\'s screens against the approved references (## Scores)';
  if (/review-(title|play-\d)\.png$/.test(name)) return 'a frame of the review sheet at full size, 1280×720 (gp review)';
  if (/production-frame/.test(name)) return 'the portal\'s small iframe at DPR 1: is every text (canvas text too) legible?';
  if (/first-screen/.test(name)) return 'the first screen a new player sees: is the action obvious, how much text?';
  if (/-play\.png$/.test(name)) return 'play: readable, one style, the HUD clear?';
  if (/results/.test(name)) return 'the result screen: a reason to play again?';
  if (/shop/.test(name)) return 'the progression screen: the game\'s own shape, or a list of "+stat" cards?';
  if (/ads-fail-rewarded/.test(name)) return 'a rewarded ad that failed: does the player learn why, is the choice kept?';
  if (/ads-after-rewarded/.test(name)) return 'after a rewarded ad: is it clear what it gave?';
  if (/uniqueness-twist/.test(name)) return 'the twist as QA saw it: does it show what makes the game different?';
  if (/production-ads-blocked/.test(name)) return 'with an ad blocker: still playable, no dead buttons?';
  if (/cover-thumbnail/.test(name)) return 'the cover at the portal\'s size: can you tell the game in half a second?';
  if (/cover-preview/.test(name)) return 'the three covers at 200 px wide, in colour and grayscale: the title readable, the hero standing off the background?';
  if (/cover-/.test(name)) return 'a cover: the title the only text, not a plain screenshot';
  if (/\.mp4$/.test(name)) return 'a preview video: after the half-second cover it opens on (the portal\'s rule, not a finding), do the first seconds show the twist?';
  return '';
}

/** Facts about a game the platform already has on disk (and a few it computes) */
export async function reviewFacts(loc: GameLocation, game: ResolvedGame, issues: Issue[]): Promise<ReviewFacts> {
  const { uniquenessReport, progressionShape } = await import('./uniqueness.ts');
  const { codeFacts, gameForecast, forecastLine, loadResults } = await import('./forecast.ts');
  const { readSize, sizeLines } = await import('./size.ts');
  let uniqueness: ReviewFacts['uniqueness'] = null;
  try {
    const rep = uniquenessReport(loc, game, issues);
    const table = ['| Signal | Points | Detail |', '|---|---|---|', ...rep.signals.map((x) => `| ${x.name} | ${x.points}/${x.max} | ${x.detail.replace(/\|/g, '\\|')} |`)].join('\n');
    uniqueness = { score: rep.score, verdict: rep.verdict, gate: rep.gate, markdownTable: table };
  } catch {
    uniqueness = null;
  }
  let forecast: ReviewFacts['forecast'] = null;
  try {
    const g = await gameForecast(loc, game, issues);
    forecast = { line: forecastLine(g.forecast), levers: g.levers.slice(0, 3).map((l) => `${l.name}: ${l.change}`) };
  } catch (e) {
    forecast = { error: String((e as Error).message).split('\n')[0] };
  }
  const isCode = game.kit.kit === 'code';
  const size = readSize(loc);
  const qaDir = join(loc.dir, 'qa');
  let qa: ReviewFacts['qa'] = null;
  const qaJson = join(qaDir, 'qa-results.json');
  if (existsSync(qaJson)) {
    try {
      const j = JSON.parse(readFileSync(qaJson, 'utf8')) as { date: string; mode?: string; base?: string; quick?: boolean; passed: number; failed: number; checks: { scope: string; name: string; ok: boolean; details: string }[]; infos?: { scope: string; name: string; details: string; warn?: boolean }[] };
      qa = { date: j.date, passed: j.passed, failed: j.failed, failedChecks: j.checks.filter((c) => !c.ok).map((c) => `[${c.scope}] ${c.name}${c.details ? ` — ${clip(c.details, 160)}` : ''}`), infos: j.infos?.length ?? 0, report: join(qaDir, 'report.md'), look: (j.infos ?? []).filter((i) => i.name?.startsWith('look:')).map((i) => `[${i.scope}] ${i.details}`), warnings: (j.infos ?? []).filter((i) => i.warn).map((i) => `[${i.scope}] ${i.name} — ${clip(i.details, 200)}`), mode: j.mode, base: j.base, quick: j.quick };
    } catch {
      qa = null;
    }
  }
  const list = (dir: string, re: RegExp) => (existsSync(dir) ? readdirSync(dir).filter((f) => re.test(f) && statSync(join(dir, f)).isFile()).sort().map((f) => join(dir, f)) : []);
  const screenshots = list(qaDir, /\.png$/);
  const media = [...list(join(loc.dir, 'store'), /^(cover-.*\.png|preview-.*\.mp4)$/)];
  const balanceFile = join(qaDir, 'balance.md');
  let firstMinute: ReviewFacts['firstMinute'] = null;
  try {
    firstMinute = existsSync(join(qaDir, 'first-minute.json')) ? JSON.parse(readFileSync(join(qaDir, 'first-minute.json'), 'utf8')) : null;
  } catch {
    firstMinute = null;
  }
  let session: ReviewFacts['session'] = null;
  try {
    session = existsSync(join(qaDir, 'session.json')) ? JSON.parse(readFileSync(join(qaDir, 'session.json'), 'utf8')) : null;
  } catch {
    session = null;
  }
  const music = isCode ? { code: codeHasMusic(loc), declared: game.sound?.music ?? null } : null;
  const emoji = isCode ? emojiInCode(loc) : null;
  const scope = isCode ? scopeFacts(loc, game) : null;
  return {
    firstMinute,
    session,
    music,
    emoji,
    scope,
    uniqueness,
    forecast,
    code: isCode ? codeFacts(loc) : null,
    progression: isCode ? progressionShape(loc).detail : null,
    size: size ? sizeLines(size).map((l) => l.trim()) : null,
    qa,
    screenshots,
    media,
    staleMedia: staleMedia(media, newestSourceMs(loc.dir)),
    balance: existsSync(balanceFile) ? balanceFile : null,
    lastCommits: lastDayCommits(loc),
    firstLook: readFirstLook(loc).look,
    results: loadResults().results,
    issues,
  };
}

/** The blind first look in the brief: what a stranger made of the first 30 s, beside what the game says it is */
export function firstLookSection(id: string, game: Pick<ResolvedGame, 'concept'>, look: FirstLook | null): string[] {
  const L: string[] = ['## The blind first look: what a stranger made of the first 30 s', ''];
  if (!look) {
    L.push(`No qa/${FIRST_LOOK_FILE} yet. \`gp review ${id} --first-look\` writes qa/first-look.png (six frames of a fresh run, 0–30 s) and qa/${FIRST_LOOK_BRIEF}; give the brief to an agent who knows nothing about the game — not you, you have read this one. \`gp review --check\` refuses on CrazyGames without it.`, '');
    return L;
  }
  if (!look.ok) {
    L.push(`qa/${FIRST_LOOK_FILE} is malformed: ${look.problems.map((p) => `line ${p.line}: ${p.message}`).join('; ')}. Ask its writer to fix it (the format is in qa/${FIRST_LOOK_BRIEF}).`, '');
    return L;
  }
  const c = game.concept;
  L.push(
    '| | The blind player said | The game says (game.yaml concept) |',
    '|---|---|---|',
    `| Goal | ${look.goal.replace(/\|/g, '\\|')} | ${c?.pitch?.replace(/\|/g, '\\|') ?? '—'} |`,
    `| Controls | ${look.controls.replace(/\|/g, '\\|')} | (play it) |`,
    `| Hook | ${look.hook.replace(/\|/g, '\\|')} | ${(c?.twist?.explained ?? c?.different ?? '—').replace(/\|/g, '\\|')} |`,
    `| Keep playing | ${look.keep}/5 — ${look.keepWhy.replace(/\|/g, '\\|')} | |`,
    ...(look.unclear ? [`| Unclear | ${look.unclear.replace(/\|/g, '\\|')} | |`] : []),
    '',
  );
  const alarm = firstLookAlarm(look);
  if (alarm) L.push(`**[blocking] required:** the first look says ${alarm} (≤ ${FIRST_LOOK_LOW}, or the goal not told). Write a \`[blocking]\` finding that names "first look" and what the first 30 s must show; \`gp review --check\` refuses quality.md without it.`, '');
  L.push('**Compare the stated goal and hook with the concept** (yours to judge): a goal that is wrong — not what the pitch says the player does — is a `[blocking]` "first look" finding too: the first 30 s teach another game. A hook that misses the twist means the twist doesn\'t show early enough.', '');
  return L;
}

/** The scope check: more than 3 systems in a game made in under a day reads as a prototype unless every screen is drawn and animated */
export function scopeSection(scope: ScopeFacts | null, progression: string | null): string[] {
  const L: string[] = ['### The scope check: prototype risk', ''];
  L.push('Five of our thirteen quality rejections were broad "systems" games built from long specs in 1–3 hours (a survival sandbox, a tycoon sandbox, a papers-please checkpoint, a 3v3 robot builder, a heat-grid roguelite); CrazyGames\' words: "needs content and polishing… looks like a prototype". Count the screens and systems around the core action as you play (the shop, upgrades, unlocks, levels, a daily, a story, crafting, a map, a builder…).', '');
  if (scope) {
    L.push(`- Systems the code shows (the platform's blocks): ${scope.systems.length ? scope.systems.join(', ') : 'none found'}${progression ? `; declared progression: "${progression}"` : ''} — add the game's own you meet in play`);
    L.push(`- Screens declared to QA (host.qa({ screens })): ${scope.screens.length ? scope.screens.join(', ') : 'none found'}`);
    L.push(`- Made in: ${scope.madeHours === null ? 'unknown (not a git checkout)' : `${scope.madeHours} h between the first and the last commit of the game folder`}`);
    const many = scope.systems.length > 3;
    const fast = scope.madeHours !== null && scope.madeHours < 24;
    if (many && fast) L.push('', `**${scope.systems.length} systems in a game made in under a day: write a \`[blocking]\` "prototype risk" finding unless every screen of each system is drawn and animated** (name the screens that aren't).`);
    if (scope.screens.length > SCOPE_MAX_SCREENS) L.push('', `**${scope.screens.length} screens declared to QA, more than ${SCOPE_MAX_SCREENS} (W_SCOPE_SCREENS)** — W_SCOPE in gp validate on a first submission: the games CrazyGames rejected had 16–20, the approved ones 10–12. Unless every one of them is drawn, animated and needed, write a \`[blocking]\` "prototype risk" finding whatever the hours, naming the screens to merge or cut.`);
  }
  L.push('', `The rule: more than 3 systems in a game made in under a day, or more than ${SCOPE_MAX_SCREENS} declared screens, is \`[blocking]\` "prototype risk" — unless each screen is drawn and animated. Fewer systems, finished, beat more systems, sketched.`, '');
  return L;
}

/** games/<id>/qa/review-brief.md: the reviewer's whole task in one file */
export function reviewBrief(loc: GameLocation, game: ResolvedGame, f: ReviewFacts, date: string): string {
  const id = loc.id;
  const qualityFile = shown(join(loc.dir, QUALITY_FILE));
  const L: string[] = [];
  const c = game.concept;
  const m = game.money;
  const engine = game.kit.kit === 'code' ? game.kit.engine?.name : null;
  L.push(
    `# ${game.title} — quality review brief`,
    '',
    `Written by \`gp review ${id}\` on ${date}, for **a second agent (the reviewer) who did not make this game**.`,
    '',
    '**Why.** CrazyGames rejected three of our games on 2026-10-01 with *"The overall quality of the game does not yet meet the expectations of our platform"*. Their QA team plays every submission "to check that it works smoothly, meets our quality standards, and is fun to play". No automatic check measures that; you do, before the portal does.',
    '',
    `**Why the sheet comes first.** Our reviews then passed games the portal rejected for that same sentence: ${CALIBRATION_MISSES}. Those reviews measured compliance — a checklist ticked — and not whether the game looks like the games the portal takes. So you start from a picture: the game beside what CrazyGames approved and rejected of ours, and a score.`,
    '',
    '## Your task',
    '',
    `1. **Play the game as a portal reviewer would**, for 10–15 minutes from a fresh save: \`gp dev ${id}\` prints the URL (\`?seed=1\` repeats a run, \`?ads=fail\` plays it as Basic Launch with ads off); or open the upload, ${shown(join(loc.dir, 'upload', 'index.html'))} — the upload is better while the maker keeps working: \`gp dev\` reloads the page on every change they save (Sigil Clash's reviewer lost a ritual mid-way), and shows an error page while a strings file doesn't parse. **Play the desktop first — 1280×720, mouse and keyboard, as the portal's QA does — then the phone (360×800, touch only).** The desktop decides: the dashboard counts Mobile and Tablet "only if it passes Desktop" (publisher/results.yaml, Candle Crypt), and our phone-first layouts left the desktop small, empty or cramped. The phone still matters (about 70 % of plays; our games converted half as well there): play it second, as hard. Then **the session lens** (below): ${SESSION_PLAY_MIN} minutes from a fresh save on desktop, and where you would have closed the tab. No browser of your own? The QA screenshots, the review sheet and the preview videos below are your eyes — say so in quality.md.`,
    `2. **Score the review sheet** (${f.sheet?.file ? shown(f.sheet.file) : `qa/${SHEET_FILE}`}, below): each of the game's screens 1–5 for *"would it sit on CrazyGames' front page next to these?"*, with a reason, in \`## Scores\`. **Below ${PASS_SCORE} is a \`[blocking]\` finding** that names the screen and says what would lift it.`,
    '3. **Look at every screenshot, cover and video listed below**, with the question next to it.',
    '4. **Go through the checklist** (the portal\'s requirements, each with its source), **the lessons from our nine verdicts** and **the lessons from the people who judged our games** (reviewers, the owner, a contest jury: what they told off our games for). The "Platform checks" column says what `gp validate` / `gp qa` / `gp submission` already check: judge what they can\'t — whether it is fun, finished and clear.',
    '5. **Read the code where play raises a question** (a timer that outlives a pause, a run that ends twice, input under an ad or a panel — the bugs every review of our games found).',
    `6. **Write ${qualityFile}** in the format below. Be concrete: what you saw, where, and what to change.`,
    '',
    `\`gp submission ${id}\` refuses to complete while ${QUALITY_FILE} is missing, malformed (on CrazyGames: without \`## Scores\`, or with a score below ${PASS_SCORE} that no \`[blocking]\` finding names) or has a \`[blocking]\` finding. When the game maker has fixed them, check again and update the file — the scores too: drop what is fixed (or move it to a free-text section such as \`## Fixed\`), keep what isn't.`,
    '',
    '- **`[blocking]`**: what would get the game rejected or make a new player leave in the first minutes — a broken or confusing first minute, a bug, a prototype look, a screen that isn\'t finished, an ad rule broken, something unreadable, the game not being what its name, covers and description say.',
    `- **The look and the layout of the first screen and of play are never \`[nice]\`.** A finding about how the title or a play frame looks or is laid out (empty space, small or system fonts, grey web-page buttons, a cramped or tiny HUD at 1280×720, a style that doesn't hold together) is \`[blocking]\`: that is what "the overall quality" rejections were made of. So is every screen you scored below ${PASS_SCORE}.`,
    '- **`[nice]`**: what would make it better (play time, D1, polish of the later screens) but would not fail review.',
    '- Don\'t soften a blocking finding into a nice one to let the game through, and don\'t invent findings: say what you saw.',
    '',
    `## The format of ${QUALITY_FILE} (fixed: \`gp submission\` parses it)`,
    '',
    '```markdown',
    qualityTemplate(game.title).trimEnd(),
    '```',
    '',
    `Rules: the heading names the game; \`## Scores\` has one line per screen of the sheet, \`- <screen>: <1–5>/5 — <why>\` for ${SCORED_SCREENS.map((s) => `\`${s}\``).join(', ')} (\`- meta: n/a — <why>\` only for a game without a meta screen; more screens may be added), and a score below ${PASS_SCORE} needs a \`[blocking]\` finding that names its screen (\`title\` or "first screen", \`play-1\`, \`play-2\`, \`meta\`); \`## Findings\` holds only list items, each starting with \`[blocking]\` or \`[nice]\` and saying \`<what> → <what to change>\` (an item may go on over indented lines); at least one finding. Other sections are free text.`,
    '',
    ...sheetSection(f.sheet ?? null),
    ...samenessSection(f.sheet?.sameness),
    ...(game.channel.id === 'crazygames' ? firstLookSection(id, game, f.firstLook ?? null) : []),
    ...lastPassSection(game, f.results, f.lastCommits ?? [], { loc: loc.id, repo: gameRepo(loc.dir) }),
    '## The game: what the platform knows',
    '',
    `- **${game.title}** (\`${id}\`) · ${game.audience.id} · ${game.channel.id} · kit \`${game.kit.kit}\`${engine ? ` · engine ${engine}` : ''} · game.yaml: ${shown(loc.file)}`,
  );
  if (c) {
    L.push(`- **Concept:** ${c.pitch}`, `- **Different from** ${c.closest.join(', ')}: ${c.different}`);
    if (c.twist) L.push(`- **Twist:** \`${c.twist.event}\`, within ${c.twist.within ?? 30} s`);
    if (c.progression) L.push(`- **Progression (as declared):** ${c.progression}`);
  } else L.push('- **Concept:** none in game.yaml');
  if (f.progression) L.push(`- **Progression (as the code shows it):** ${f.progression}`);
  if (m) {
    const s = m.session;
    L.push(`- **Money design:** ${m.genre ?? 'genre not set'}; session ${s?.minutes ?? '?'} min, ${s?.breaks ?? '?'} natural breaks${s?.breaksAt ? ` (${s.breaksAt})` : ''}; returns: ${m.returns?.kind ?? '?'}${m.returns?.what ? ` — ${m.returns.what}` : ''}`);
    for (const r of m.rewarded ?? []) L.push(`  - rewarded \`${r.placement}\` (${r.kind}): ${r.gives}`);
  } else L.push('- **Money design:** none in game.yaml');
  if (f.code) L.push(`- **In the code:** rewarded placements ${f.code.rewarded.length ? f.code.rewarded.map((x) => `\`${x}\``).join(', ') : 'none'}; ${f.code.adBreak ? 'calls host.adBreak()' : 'no midgame ad (host.adBreak) found'}`);
  if (f.forecast) L.push(`- **Forecast:** ${'error' in f.forecast ? `not available (${f.forecast.error})` : `${f.forecast.line}${f.forecast.levers.length ? `; top levers: ${f.forecast.levers.join(' · ')}` : ''}`}`);
  L.push(`- **Story:** ${game.story ? `depth \`${game.story.depth}\`${game.story.premise ? `, premise: "${game.story.premise}"` : ''}${game.story.file ? `, file ${game.story.file}` : ''}` : 'none declared'}`);
  if (f.uniqueness) L.push(`- **Uniqueness:** ${f.uniqueness.score}/100 — ${f.uniqueness.verdict}${f.uniqueness.gate ? ` (gate: ${f.uniqueness.gate})` : ''}`);
  L.push(`- **Size and load:** ${f.size ? f.size.join(' · ') : `no upload yet — \`gp build ${id} --target crazygames\` (gp qa builds it too)`}`);
  const l = game.listing;
  L.push(`- **Listing:** ${l.description ?? '(no description)'}`, `- **Controls:** ${l.controls ?? '(none)'} · orientation ${l.orientation}${l.tags.length ? ` · tags ${l.tags.join(', ')}` : ''}`);
  const warn = f.issues.filter((i) => i.severity !== 'info');
  if (warn.length) L.push(`- **gp validate:** ${warn.map((i) => `${i.code} (${clip(i.message, 100)})`).join('; ')}`);
  if (f.uniqueness) L.push('', '<details><summary>Uniqueness signals</summary>', '', f.uniqueness.markdownTable, '', '</details>');

  L.push('', '### QA', '');
  if (f.qa) {
    L.push(`Last \`gp qa\`: ${f.qa.date} — **${f.qa.passed} passed, ${f.qa.failed} failed**, ${f.qa.infos} hint(s). Report: ${shown(f.qa.report)}${f.balance ? ` · balance: ${shown(f.balance)}` : ''}`);
    if (f.qa.mode === 'quick') L.push('', `**That was a \`--quick\` run** (one screen size), not the gate: the full \`gp qa ${id}\` must be all green too.`);
    else if (f.qa.mode === 'failed') L.push('', `**That was \`--failed\`**: the failed sections re-run on top of the ${f.qa.quick ? '`--quick` run (one screen size)' : 'full run'} of ${f.qa.base}; the gate is a full \`gp qa ${id}\`.`);
    else if (!f.qa.mode) L.push('', '(QA from a platform without run modes: run `gp qa` again if unsure it was a full run.)');
    if (f.qa.failedChecks.length) L.push('', 'Failed checks:', ...f.qa.failedChecks.map((x) => `- ${x}`));
    // QA's warnings (the sound section's: silent actions, effects drowned, exact repeats): listen for each in play
    if (f.qa.warnings?.length) L.push('', 'Warnings (they don\'t fail QA — listen for each as you play: a plain one is a finding):', ...f.qa.warnings.map((x) => `- ${x}`));
  } else L.push(`No QA results yet: a full \`gp qa ${id}\` may still be running — play the game meanwhile (step 1), then run \`gp review ${id}\` again when it ends, so this brief lists its screenshots, and look at them before you write quality.md.`);
  L.push('', '### The first minute (a new player on a phone)', '');
  L.push('Basic Launch, 2026-10-04: only 20–68 % of the players of our six launched games played one minute (CrazyGames wants 80 %+), and 1–4 % came back the next day (10–15 %). Play the first 60 seconds as someone who has never seen the game, on the phone size, and mark [blocking] what makes a player leave: a wait before Play, a screen between Play and the game, a loss before they understand, a wall of text, nothing to do, nothing rewarding in the first 30 s.');
  const fm = f.firstMinute;
  if (fm) {
    const lines = firstMinuteLines(fm, c?.twist ? (c.twist.within ?? 30) : null);
    const failed = lines.filter((x) => x.ok === false).length;
    L.push('', `From qa/first-minute.json — ${failed ? `**${failed} fail**` : 'no fail'}${game.channel.id === 'crazygames' ? ' (on CrazyGames a ✗ here is a `[blocking]` finding unless you played it and the number is wrong — then say so)' : ''}:`, '');
    for (const x of lines) L.push(`- ${x.ok === null ? '·' : x.ok ? '✓' : '✗'} ${x.text}`);
    L.push('- Screenshots: first-minute-1s.png and first-minute-5s.png in the QA folder');
  } else L.push('', '(No qa/first-minute.json yet: it comes with a full `gp qa` on this platform.)');
  L.push(...sessionSection(game, f.session ?? null));
  L.push('', '### Look at these', '');
  const files = [...f.screenshots, ...f.media];
  if (files.length) for (const p of files) L.push(`- ${shown(p)}${shotHint(p) ? ` — ${shotHint(p)}` : ''}`);
  else L.push('- none yet: `gp qa` writes the screenshots, `gp covers` and `gp video` (or `gp submission`) the covers and videos');
  if (!f.media.some((p) => p.endsWith('.mp4'))) L.push(`- no preview videos yet: \`gp video ${id}\` (${shown(join(loc.dir, 'store'))}/)`);
  if (f.staleMedia.length) L.push(`- **older than the game's code** (they show an earlier build): ${f.staleMedia.map((p) => shown(p)).join(', ')} — run \`gp covers ${id}\` and \`gp video ${id}\` before the review, or judge them as stale`);

  if (game.channel.id === 'crazygames') {
    L.push('', '## [blocking] on CrazyGames: what our [nice] findings let through (docs/research/feedback-and-metrics-2026-10.md §5)', '');
    L.push('Thirteen of our 22 portal answers were "overall quality" rejections, and those games carried what our own reviewers had marked `[nice]`. On CrazyGames each of these is **`[blocking]`** when the game has it; write it as such, with where you saw it:', '');
    CRAZYGAMES_BLOCKING.forEach((b, n) => L.push(`${n + 1}. ${b.what} — look: ${b.look}`));
    const facts: string[] = [];
    if (f.music) facts.push(f.music.code ? '✓ music: the code starts it (createMusic from @gp/core/sound) — listen that it plays and fits' : typeof f.music.declared === 'string' ? `· music: game.yaml says "${f.music.declared}" (the game's own) — listen that it plays` : `✗ music: none in the code or in game.yaml${f.music.declared === false ? ' (`sound.music: false`)' : ''} — \`gp review --check\` and \`gp submission\` refuse it`);
    if (f.emoji) facts.push(f.emoji.files.length ? `✗? emoji or symbol glyphs in the code or strings: ${f.emoji.chars.join(' ')} in ${f.emoji.files.map((x) => shown(x)).slice(0, 6).join(', ')}${f.emoji.files.length > 6 ? ` (+${f.emoji.files.length - 6})` : ''} — are they icons on screen? Then \`[blocking]\`` : '✓ no emoji or symbol glyphs in the code or the English strings (gp qa scans the screens too: E_QA_GLYPH_ICON)');
    if (facts.length) L.push('', 'What the platform found (the rest is yours to see):', '', ...facts.map((x) => `- ${x}`));
    L.push('', ...scopeSection(f.scope ?? null, c?.progression ?? null));
  }
  if (L[L.length - 1] !== '') L.push('');
  L.push(...basicLaunchSection(f.results));
  L.push('## The checklist: CrazyGames\' quality requirements', '');
  const research = existsSync(RESEARCH_FILE) ? readFileSync(RESEARCH_FILE, 'utf8').split('\n') : [];
  L.push(`Each item's source is a line of ${shown(RESEARCH_FILE)} (the portal's pages, from verbatim copies and search snippets; [S] a snippet of the official docs, [3rd-M] a verbatim mirror of an official page, [F] a forum report). For each item, write a finding or nothing.`, '');
  L.push('| # | Area | Check | Source | Platform checks |', '|---|---|---|---|---|');
  QUALITY_CHECKLIST.forEach((it, n) => {
    const s = checklistSource(it, research);
    const src = s ? `${s.section ? `${s.section}, ` : ''}line ${s.line}${s.markers ? ` ${s.markers}` : ''}` : `(not found: "${it.anchor}")`;
    L.push(`| ${n + 1} | ${it.area} | ${it.check} | ${src} | ${it.platform ?? '— (yours)'} |`);
  });
  L.push('', '## Lessons from our nine portal verdicts', '', verdictLessons(f.results), '');
  L.push(...lessonsSection());
  L.push(...artSection(f.qa?.look ?? [], artSpec(loc)?.keep ?? []));
  L.push(...pixelSection(loc));
  L.push(
    '## Our own lessons to check (docs/guides/game-anatomy.md §4, docs/team/retro-games-6-11.md)',
    '',
    '- A timer that outlives Pause or Restart (4 of 6 games); a run that ends twice or never (5 of 6): pause in the middle of a death or a win, restart, play again.',
    '- Input under an ad or a panel: tap through an open panel; press keys while an ad is pending.',
    '- A story before the first tap, or a chapter over a result: results first, then the chapter.',
    '- A first QA key press that solves level 1; a shop that doesn\'t fit 360×800 or 800×360.',
    '- The progression: does a purchase change how the game plays, or only a number? (docs/guides/upgrades.md)',
    '- Random rewards (eggs, chests, drops, a wheel): each tier\'s chance is on screen before every roll; a rewarded ad gives a guaranteed thing (a floor, a second item), never a spin; nothing random is sold, no slot-reel or roulette look (PEGI 2026; docs/guides/live-world.md → Fair randomness).',
    '- A shared world (restocks, weather, festival hours, rivals): "the same for every player" only where the clock makes it true; rivals read as characters, never as players; no count of players online, no "Ana just found…" toasts; a missed restock or event is never framed as a loss.',
    '',
  );
  return L.join('\n');
}
