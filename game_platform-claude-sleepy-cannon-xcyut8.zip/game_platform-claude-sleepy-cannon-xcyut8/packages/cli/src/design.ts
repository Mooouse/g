// `gp design`: a game designer for the next version. `gp review` judges (pass/fail, quality.md) and `gp review
// --first-look` asks a stranger; nobody invents. Our games keep stopping at Basic Launch one or two points short (Garage
// Evolution 2026-10-20: desktop 8/15, mobile 6/15; Hang the Moon 5/15 and 6/15 — publisher/results.yaml), and the owner
// had good results giving Gemini a gameplay video and asking it, as a game designer, what to improve. So the platform
// assembles that task for a designer agent who did not make the game: a contact sheet of a new player's run (the demo bot
// on the virtual clock, a frame every 10 s, going on through the breaks as a new player would — gp qa's session section
// does it the same way, with the same helpers), the game's facts (concept, money, genre and what its players expect,
// the blocks that fit it and whether the game uses them, where a new player's session stops, the balance and the
// forecast's levers, the game's own Basic Launch scores, its CHANGELOG, the lessons that bear on each metric), and the
// instructions: play it 15+ minutes as a new player and some as an experienced one, desktop then phone, every feature;
// look at the genre's hits on CrazyGames; write games/<id>/design.md — proposals ranked by expected effect and effort,
// each naming the metric it moves, what was seen, and how to build it (the platform's block, or the game's code).
// `--gemini` asks Gemini the same over a gameplay video (gemini.ts).
//
//   games/<id>/qa/design-brief.md     the designer's task (gp qa keeps it: KEPT_REPORTS)
//   games/<id>/qa/design-sheet.png    the contact sheet of the run
//   games/<id>/qa/design/             the run's frames (frame-<m>m<ss>.jpg) and, with --gemini, gameplay-design.mp4
//   games/<id>/qa/design-gemini.md    Gemini's answer (--gemini)
//   games/<id>/design.md              written by the designer (committed); `gp design --check` parses it

import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Page } from 'playwright';
import { parse as parseYaml } from 'yaml';
import { BASIC_LAUNCH, GENRE_BLOCKS, GENRE_INFO, SUBGENRE_INFO, blocksFor, deviceTotal, expectationHow, expectationsFor, gameGenre, importedBlocks, normRepo, recordsOf, scoresLine, type RecordedResult, type ResolvedGame } from '@gp/spec';
import { LESSONS } from './lessons.ts';
import { gameRepo, ROOT, shown, type GameLocation } from './paths.ts';
import { basicLaunchSection, firstMinuteLines, gameSources, type ReviewFacts } from './review.ts';
import { SHEET_H, SHEET_W } from './review-sheet.ts';

export const DESIGN_FILE = 'design.md';
export const DESIGN_BRIEF = 'design-brief.md';
export const DESIGN_SHEET = 'design-sheet.png';
export const DESIGN_GEMINI = 'design-gemini.md';
/** qa/design/: the run's frames and the gameplay video */
export const DESIGN_DIR = 'design';
/** Minutes of virtual play the capture records by default (`--minutes`, 1–15) */
export const DESIGN_PLAY_MIN = 3;
export const DESIGN_MAX_MIN = 15;
/** A frame every this many seconds of the run */
export const DESIGN_EVERY_SEC = 10;
/** The designer plays at least this long as a new player */
export const DESIGNER_PLAY_MIN = 15;
/** The gameplay cut for Gemini, seconds (`--max`): long enough to see a break and the next run (Forge Night's first stop came at 1:15) */
export const DESIGN_VIDEO_SEC = 90;
/** Its H.264 quality: lighter than a preview's 20 — Gemini samples a frame a second at its own size — so it usually goes inline */
export const DESIGN_VIDEO_CRF = 32;
/** The capture's machine time per minute of play (a heavy game reaches less; the brief says how far it got) */
export const WALL_MS_PER_MIN = 40_000;

// --- The sections of design.md: one per thing that moves a Basic Launch metric -----------------------------------

export type Metric = 'conversion' | 'playtime' | 'D1';

export interface DesignSection {
  id: string;
  /** The `## …` heading in design.md */
  heading: string;
  /** The metrics it moves */
  metrics: Metric[];
  /** What the designer answers in this section, while playing */
  question: string;
  /** The lessons (lessons.ts ids) that bear on it */
  lessons: string[];
  /** The blocks that usually build it (GENRE_BLOCKS names); the brief shows those that fit the genre */
  blocks: string[];
}

export const DESIGN_SECTIONS: DesignSection[] = [
  {
    id: 'first-minute',
    heading: 'First minute',
    metrics: ['conversion'],
    question: 'What stands between the portal\'s Play Now and a minute of play (clicks, a title gate, text, a loss before the rule is clear), and what would make the first 30 s a "one more minute" — a reward inside 15 s, the twist shown, not told?',
    lessons: ['first-visit-gameplay', 'first-minute', 'onboarding', 'start-sound', 'information'],
    blocks: ['hints', 'coachHand', 'inspect', 'cards', 'rewardedOffer'],
  },
  {
    id: 'session',
    heading: 'Session',
    metrics: ['playtime'],
    question: 'Where would a new player close the tab in 15 minutes, and what pulls them past it: the next run starting by itself, the next goal named and moving, a peak every few minutes, a meta reward every 2–3 min, a decision that changes how the next run plays?',
    lessons: ['session-length', 'results-continue', 'visible-progress', 'structure', 'balance', 'dominant-strategy'],
    blocks: ['mountResults', 'RunChoices', 'Roster', 'Tiers', 'PactTree', 'UpgradeShop', 'mountUpgradeShop', 'BossPatterns', 'playtimeGifts', 'goalBanners'],
  },
  {
    id: 'return',
    heading: 'Coming back',
    metrics: ['D1'],
    question: 'Why would this player open the game again tomorrow — what is left open at the end of a session, what is new tomorrow, and is it on the title screen where they see it?',
    lessons: ['retention', 'daily-visible'],
    blocks: ['recordVisit', 'welcomeBack', 'dailyStreak', 'dailyOrder', 'mountStreakCard', 'dailyQuests', 'achievements', 'mountGoals', 'seasonPass', 'weeklyEvent', 'offlineEarnings', 'dailyTable', 'dailyRunSeed', 'recordDaily', 'collection', 'mountAlbum'],
  },
  {
    id: 'phones',
    heading: 'Phones',
    metrics: ['conversion', 'playtime', 'D1'],
    question: 'About 70 % of plays are on phones and they converted half as well: at 360×800, touch only — are the controls drawn from the first frame, do the thumbs cover the action, does every screen fit, does the session hold up?',
    lessons: ['mobile-controls-visible', 'controls', 'ui-layout', 'desktop-decides'],
    blocks: ['MoveInput', 'TwinStick', 'LookInput', 'aimAssist', 'coachHand', 'inspect'],
  },
  {
    id: 'feel',
    heading: 'Juice and feel',
    metrics: ['conversion', 'playtime'],
    question: 'Does every action answer through several channels (a sound, a flash, a shake, a number that pops), do the big moments land, is there music that fits, does it run smoothly?',
    lessons: ['juice', 'animation', 'smooth', 'sound', 'art-direction', 'feel-over-features'],
    blocks: ['Fx', 'Camera', 'createSfx', 'ScoreSequencer', 'callouts', 'DamageNumbers', 'HitArcs', 'readout'],
  },
  {
    id: 'content',
    heading: 'Content and variety',
    metrics: ['playtime', 'D1'],
    question: 'Does something new arrive every 3–5 minutes (an enemy that behaves differently, a tool that plays differently, a place with its own look), and does the content outlast the session — without a new system a reviewer would open unfinished?',
    lessons: ['variety', 'characters-story', 'side-systems-later', 'concept'],
    blocks: ['Roster', 'collection', 'mountAlbum', 'BossPatterns', 'LootTable', 'variants', 'StoryRunner', 'Board', 'Zones'],
  },
];

/** The required section of the genre's hits: what the top CrazyGames games of the genre do that this one doesn't */
export const HITS_HEADING = "The genre's hits";

// --- design.md: the format and its parser (pure) ------------------------------------------------------------------

export type Effect = 'high' | 'mid' | 'low';
export type Effort = 'S' | 'M' | 'L';

export interface DesignItem {
  /** The section's id (DESIGN_SECTIONS), or 'top' */
  section: string;
  effect: Effect;
  /** What to add or change (before the dash) */
  change: string;
  /** Which metric and what the designer saw (between the dash and the arrow) */
  why: string;
  /** How to build it: the platform's block or the game's code (after the arrow) */
  how: string;
  effort: Effort;
  /** The metrics the why names */
  metrics: Metric[];
  /** The platform blocks the how names */
  blocks: string[];
  line: number;
}

export interface DesignHit {
  /** The hit game */
  game: string;
  /** What it does */
  does: string;
  /** What we take */
  take: string;
  line: number;
}

export interface DesignReport {
  title: string | null;
  top: DesignItem[];
  /** Every section's items, in order (Top 3 not included) */
  items: DesignItem[];
  /** Sections the designer marked "[none] — <why>" */
  none: { section: string; why: string; line: number }[];
  hits: DesignHit[];
  problems: { line: number; message: string }[];
  ok: boolean;
}

const METRIC_WORDS: Record<Metric, RegExp> = {
  conversion: /\b(conversion|convert\w*|first[- ]minute|first 60 s|1[- ]min(ute)?|one minute|bounce\w*|first[- ]look|first 30 s)\b/i,
  playtime: /\b(play ?time|session|average play|minutes of play|min of play|close[sd]? the tab|stop(?:s|ped)? playing)\b/i,
  D1: /\b(D1|retention|come back|comes back|coming back|returns?|returning|tomorrow|next day)\b/i,
};

/** The metrics a text names */
export const metricsIn = (text: string): Metric[] => (Object.keys(METRIC_WORDS) as Metric[]).filter((m) => METRIC_WORDS[m].test(text));

/** The platform's blocks a text names (GENRE_BLOCKS, as written: `mountResults`, mountResults({ … }), @gp/core/…) */
export function blocksIn(text: string): string[] {
  return Object.keys(GENRE_BLOCKS).filter((b) => new RegExp(`(^|[^\\w.])${b}(?![\\w])`).test(text));
}

/** The how names the game's own code (a file, game.yaml, its data or tuning) */
const NAMES_CODE = /\b(game code|the game'?s (own )?code|own code|in code|code:|main\.ts|\w+\.(ts|mjs|js)\b|game\.yaml|strings\/|balance\(\)|balanceModel|bot\.ts|data table|tuning|host\.\w+|@gp\/[\w/-]+)/i;
/**
 * …or a code identifier of the game's: a call `dailyCar()` / `spawnBoss(3)`, a `Class.method` or `obj.field`, a path
 * `src/garage/shop.ts` or `games/x/…`, or any `identifier` in backticks (Idle Garage Evolution's designer wrote
 * `dailyCar()` and was refused: the rule knew only catalog blocks and file names)
 */
const NAMES_IDENTIFIER = [/(^|[^\w$])[A-Za-z_$][\w$]*\([^()]*\)/, /\b[A-Za-z_$][\w$]*\.[A-Za-z_$][\w$]*/, /(^|[\s(`'"])(?:\.\/)?(?:src|games?|lib|scenes?|data)\/[\w.@/-]+/, /`[A-Za-z_$][\w$.]*(?:\([^`]*\))?`/];
/** Whether a how names the game's own code: a file, game.yaml, its data, or a code identifier (NAMES_IDENTIFIER) */
export const namesCode = (how: string): boolean => NAMES_CODE.test(how) || NAMES_IDENTIFIER.some((r) => r.test(how.replace(/\b(?:e\.g|i\.e|etc|vs)\./gi, ' ')));

/** A change that names no thing: generic advice, not a buildable change */
const VAGUE = /^(?:improve|polish|enhance|refine|optimi[sz]e|tweak|rework|better|more|add (?:more )?(?:content|juice|polish|variety|features?|depth|fun)|make (?:it|the game) (?:more )?(?:fun|engaging|interesting|polished|juicy|better|addictive|exciting))\b/i;
const words = (s: string) => s.split(/\s+/).filter(Boolean).length;

const DASH = /\s(?:—|–|--)\s/;
const ARROW = /\s(?:→|->)\s/;
const EFFORT = /\s*(?:·|\||;|,|\()?\s*effort\s*[:=]?\s*(S|M|L|small|medium|large)\b\)?\s*\.?\s*$/i;
const EFFORTS: Record<string, Effort> = { s: 'S', small: 'S', m: 'M', medium: 'M', l: 'L', large: 'L' };

/** The part of a proposal a problem is in: its effect tag, the change, the why, the how, the effort, or its shape */
export type ItemPart = 'effect' | 'change' | 'why' | 'how' | 'effort' | 'format';

export interface ItemIssue {
  part: ItemPart;
  message: string;
  /** The part's text, as written (normalized spaces), when it has one: the line it starts on is reported */
  text?: string;
}

/** A part's text for a message: quoted, clipped */
const quote = (s: string, max = 60) => `"${s.length > max ? `${s.slice(0, max - 1)}…` : s}"`;

/** One proposal "[high] <change> — <why> → <how> · effort S", or what is wrong with it — each problem names its part */
export function parseItem(body: string, section: string, line: number): { item: DesignItem | null; problems: string[]; issues: ItemIssue[] } {
  const issues: ItemIssue[] = [];
  const done = (item: DesignItem | null) => ({ item, issues, problems: issues.map((i) => i.message) });
  const tag = body.match(/^\[([^\]]*)\]\s*(.*)$/s);
  if (!tag) {
    issues.push({ part: 'effect', message: 'a proposal starts with its expected effect: [high], [mid] or [low]' });
    return done(null);
  }
  const effect = tag[1].trim().toLowerCase();
  if (!['high', 'mid', 'low'].includes(effect)) {
    issues.push({ part: 'effect', message: `"[${tag[1]}]" is not an effect: [high], [mid] or [low]${section === 'top' ? '' : ' (or "- [none] — <why nothing is needed here>")'}` });
    return done(null);
  }
  let text = tag[2].replace(/\s+/g, ' ').trim();
  const placeholder = text.match(/<[^<>]{2,}>/);
  if (placeholder) {
    issues.push({ part: 'format', message: `the template's placeholder ${quote(placeholder[0])} is still in this proposal`, text: placeholder[0] });
    return done(null);
  }
  const eff = text.match(EFFORT);
  let effort: Effort | null = null;
  if (eff) {
    effort = EFFORTS[eff[1].toLowerCase()];
    text = text.slice(0, eff.index).trim();
  } else issues.push({ part: 'effort', message: `effort: none at the end of ${quote(text.slice(-40))} — end the proposal with "· effort S" (S: hours, M: a day, L: more)`, text: text.slice(-40) });
  // The first dash ends the change; the first arrow after it ends the why (a change may say "×1.0 → ×1.1")
  const d = text.search(DASH);
  const after = d < 0 ? -1 : text.slice(d + 1).search(ARROW);
  const a = after < 0 ? -1 : d + 1 + after;
  if (d < 0 || a < 0) {
    issues.push({ part: 'format', message: `${d < 0 ? 'no " — " after the change' : 'no " → " after the why'}: a proposal is "<change> — <why: the metric and what you saw> → <how: the platform's block or the game's code> · effort S"` });
    return done(null);
  }
  const change = text.slice(0, d).trim();
  const why = text.slice(d, a).replace(DASH, '').trim();
  const how = text.slice(a).replace(ARROW, '').trim();
  if (!change) issues.push({ part: 'change', message: 'change: empty — say what to add or change before the " — "' });
  if (!why) issues.push({ part: 'why', message: 'why: empty — between the " — " and the " → ": the metric it moves and what you saw' });
  if (!how) issues.push({ part: 'how', message: "how: empty — after the \" → \": the platform's block or the game's code" });
  const metrics = metricsIn(why);
  if (why && !metrics.length) issues.push({ part: 'why', message: `why: ${quote(why)} names no metric — say which it moves: conversion (the first minute), playtime (the session) or D1 (coming back), and what you saw`, text: why });
  const blocks = blocksIn(how);
  if (how && !blocks.length && !namesCode(how))
    issues.push({ part: 'how', message: `how: ${quote(how)} names no block and no code — the platform's block (\`mountResults({ autoContinueSec })\`, \`dailyStreak\` …) or the game's code: a file or \`src/…\` path, game.yaml, the balance data, a function \`dailyCar()\`, a \`Class.method\``, text: how });
  if (change && VAGUE.test(change) && words(change) <= 6) issues.push({ part: 'change', message: `change: ${quote(change)} is generic advice — say exactly what to add or change, where, and how much`, text: change });
  if (issues.length || !effort) return done(null);
  return done({ section, effect: effect as Effect, change, why, how, effort, metrics, blocks, line });
}

/** "First minute (conversion)", "## Session — playtime" → the section it is, by its heading's first words */
function sectionOf(heading: string): DesignSection | null {
  const h = heading.toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
  return DESIGN_SECTIONS.find((s) => h.startsWith(s.heading.toLowerCase())) ?? null;
}

/**
 * design.md → its proposals, and what is wrong with the file. The format: a `# <title> …` heading; `## Top 3` with
 * exactly three proposals; a section per DESIGN_SECTIONS heading, each with at least one proposal or `- [none] — <why>`;
 * `## The genre's hits` with at least two hits `- <game>: <what it does> → <what we take>`. A proposal is
 * `- [high|mid|low] <change> — <why: the metric and what you saw> → <how: block or code> · effort S|M|L` (it may go on
 * over indented lines). At least one [high] proposal. Other sections are free text.
 */
export function parseDesign(text: string, opts: { title?: string } = {}): DesignReport {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const problems: { line: number; message: string }[] = [];
  const h1 = lines.findIndex((l) => /^#\s+\S/.test(l));
  const title = h1 >= 0 ? lines[h1].replace(/^#\s+/, '').trim() : null;
  if (h1 < 0) problems.push({ line: 1, message: 'no heading: the file starts with "# <game title> — design proposals"' });
  else if (opts.title && !title!.toLowerCase().includes(opts.title.toLowerCase())) problems.push({ line: h1 + 1, message: `the heading "${title}" doesn't name this game ("${opts.title}"): proposals for another game?` });

  // The sections, by their ## headings
  const heads = lines.map((l, i) => ({ l, i })).filter(({ l }) => /^##\s+\S/.test(l)).map(({ l, i }) => ({ name: l.replace(/^##\s+/, '').trim(), at: i }));
  const body = (at: number) => {
    const end = heads.find((h) => h.at > at)?.at ?? lines.length;
    return { start: at + 1, end };
  };
  /** The list items of a section: text (continuation lines joined) and line */
  type ListItem = { text: string; line: number; numbered: boolean; segs: { text: string; line: number }[] };
  const itemsOf = (at: number): ListItem[] => {
    const { start, end } = body(at);
    const out: ListItem[] = [];
    for (let i = start; i < end; i++) {
      const l = lines[i];
      const m = l.match(/^(?:[-*]|(\d+)[.)])\s+(.*)$/);
      if (m) out.push({ text: m[2], line: i + 1, numbered: !!m[1], segs: [{ text: m[2], line: i + 1 }] });
      else if (/^\s+\S/.test(l) && out.length) {
        out[out.length - 1].text += ' ' + l.trim();
        out[out.length - 1].segs.push({ text: l.trim(), line: i + 1 });
      }
    }
    return out;
  };
  /** The line a part of a proposal starts on (a proposal may go on over indented lines): its text found in the segments */
  const partLine = (it: ListItem, text: string | undefined): number => {
    if (!text || it.segs.length < 2) return it.line;
    const norm = (s: string) => s.replace(/\s+/g, ' ').trim();
    let joined = '';
    const starts: number[] = [];
    for (const s of it.segs) {
      if (joined) joined += ' ';
      starts.push(joined.length);
      joined += norm(s.text);
    }
    const at = joined.indexOf(norm(text));
    if (at < 0) return it.line;
    let k = 0;
    while (k + 1 < starts.length && starts[k + 1] <= at) k++;
    return it.segs[k].line;
  };
  /** A proposal's problems, each on the line its part starts on, prefixed when that is not the proposal's first line */
  const report = (it: ListItem, r: ReturnType<typeof parseItem>) => {
    for (const i of r.issues) {
      const ln = partLine(it, i.text);
      problems.push({ line: ln, message: ln === it.line ? i.message : `${i.message} (the proposal starts on line ${it.line})` });
    }
  };

  const top: DesignItem[] = [];
  const topHead = heads.find((h) => /^top\s*3\b/i.test(h.name));
  if (!topHead) problems.push({ line: Math.max(1, h1 + 2), message: 'no "## Top 3" section: the three changes with the best expected effect for their effort' });
  else {
    const list = itemsOf(topHead.at);
    for (const it of list) {
      const r = parseItem(it.text, 'top', it.line);
      if (r.item) top.push(r.item);
      report(it, r);
    }
    if (list.length !== 3) problems.push({ line: topHead.at + 1, message: `Top 3 has ${list.length} proposal(s): exactly three, the best expected effect for their effort` });
  }

  const items: DesignItem[] = [];
  const none: DesignReport['none'] = [];
  for (const s of DESIGN_SECTIONS) {
    const head = heads.find((h) => sectionOf(h.name)?.id === s.id);
    if (!head) {
      problems.push({ line: Math.max(1, h1 + 2), message: `no "## ${s.heading}" section (${s.metrics.join(', ')}): at least one proposal, or "- [none] — <why nothing is needed>"` });
      continue;
    }
    const list = itemsOf(head.at);
    if (!list.length) problems.push({ line: head.at + 1, message: `"## ${s.heading}" has no proposal: at least one, or "- [none] — <why nothing is needed>"` });
    for (const it of list) {
      const n = it.text.match(/^\[none\]\s*(?:—|–|-|:)?\s*(.*)$/i);
      if (n) {
        if (!n[1].trim() || /<[^<>]{2,}>/.test(n[1])) problems.push({ line: it.line, message: 'say why nothing is needed here: "- [none] — <why>"' });
        else none.push({ section: s.id, why: n[1].trim(), line: it.line });
        continue;
      }
      const r = parseItem(it.text, s.id, it.line);
      if (r.item) items.push(r.item);
      report(it, r);
    }
  }

  const hits: DesignHit[] = [];
  const hitsHead = heads.find((h) => /^the genre'?s hits\b|^genre hits\b|^hits\b/i.test(h.name));
  if (!hitsHead) problems.push({ line: Math.max(1, h1 + 2), message: `no "## ${HITS_HEADING}" section: two or more of the genre's top CrazyGames games, "- <game>: <what it does that ours doesn't> → <what we take>"` });
  else {
    for (const it of itemsOf(hitsHead.at)) {
      const t = it.text.replace(/\s+/g, ' ').trim();
      if (/<[^<>]{2,}>/.test(t)) {
        problems.push({ line: it.line, message: "the template's placeholder is still in this hit" });
        continue;
      }
      const m = t.match(/^\**([^:*]+?)\**\s*[:—–]\s*(.+?)\s(?:→|->)\s(.+)$/);
      if (!m) problems.push({ line: it.line, message: 'a hit is "- <game>: <what it does that ours doesn\'t> → <what we take>"' });
      else hits.push({ game: m[1].trim(), does: m[2].trim(), take: m[3].trim(), line: it.line });
    }
    if (hits.length < 2 && !problems.some((p) => p.line > hitsHead.at && p.line <= body(hitsHead.at).end))
      problems.push({ line: hitsHead.at + 1, message: `${hits.length} hit(s): name at least two of the genre's top CrazyGames games and what each does that this game doesn't` });
  }
  if (!problems.length && ![...top, ...items].some((i) => i.effect === 'high'))
    problems.push({ line: topHead ? topHead.at + 1 : 1, message: 'no [high] proposal: a design pass for the next version needs at least one change you expect to move a score by a point' });
  return { title, top, items, none, hits, problems: problems.sort((a, b) => a.line - b.line), ok: !problems.length };
}

/**
 * What a design.md holds, in one line: "Top 3 + 12 proposals in the sections (3 high), 2 of the genre's hits" — the
 * sections' count without the Top 3, said so ("15 proposals (3 high)" read as if it held the Top 3)
 */
export function designSummary(rep: Pick<DesignReport, 'top' | 'items' | 'hits'>): string {
  const high = rep.items.filter((i) => i.effect === 'high').length;
  return `Top ${rep.top.length} + ${rep.items.length} proposal${rep.items.length === 1 ? '' : 's'} in the sections (${high} high), ${rep.hits.length} of the genre's hits`;
}

/** The template the brief shows; the parser accepts it once filled (a test keeps them in step) */
export function designTemplate(title: string): string {
  const item = '- [high] <what to add or change, exactly> — <the metric it moves and what you saw, with the time> → <how: the platform block, or what to change in the game code> · effort S';
  return [
    `# ${title} — design proposals`,
    '',
    'Designer: <who> · Date: <YYYY-MM-DD> · Played: <the build, how long, at which sizes — e.g. gp dev, 18 min new player at 1280×720, 6 min at 360×800, 5 min with progress>',
    '',
    '## Top 3',
    '',
    '1. [high] <the change with the best expected effect for its effort> — <metric, what you saw> → <how> · effort S',
    '2. [high] <the second> — <metric, what you saw> → <how> · effort M',
    '3. [mid] <the third> — <metric, what you saw> → <how> · effort S',
    '',
    ...DESIGN_SECTIONS.flatMap((s) => [`## ${s.heading}`, '', item, '']),
    `## ${HITS_HEADING}`,
    '',
    "- <a top CrazyGames game of the genre>: <what it does in its first minute, session or return that ours doesn't> → <what we take, in our own shape>",
    "- <another>: <what it does> → <what we take>",
    '',
    '## Not now',
    '',
    '<optional, free text: what you considered and would not do yet — a new system, a mode, a screen — and why>',
    '',
  ].join('\n');
}

// --- The game's facts for the designer ----------------------------------------------------------------------------

/**
 * This game's records in publisher/results.yaml: by its id, its folder's id or its title (as gp review matches them),
 * and by its repository (`repo:`; spec recordsOf) — a record under another id is still this game's
 */
export function ownResults(results: readonly RecordedResult[], game: Pick<ResolvedGame, 'id' | 'title'>, loc: Pick<GameLocation, 'id'>, repo: string | null = null): RecordedResult[] {
  return recordsOf(results, { ids: [game.id, loc.id], title: game.title, repo });
}

/** The newest `max` versions of CHANGELOG.md (each `## …` section, clipped), or null without one */
export function changelogHead(dir: string, max = 2, maxLines = 40): string | null {
  const f = join(dir, 'CHANGELOG.md');
  if (!existsSync(f)) return null;
  const lines = readFileSync(f, 'utf8').split('\n');
  const at = lines.map((l, i) => (/^##\s/.test(l) ? i : -1)).filter((i) => i >= 0);
  if (!at.length) return null;
  const end = at[max] ?? lines.length;
  const out = lines.slice(at[0], end);
  return (out.length > maxLines ? [...out.slice(0, maxLines), `… (${out.length - maxLines} more lines in CHANGELOG.md)`] : out).join('\n').trim();
}

export interface GenreFacts {
  genre: string;
  sub: string | null;
  name: string;
  players: string;
  from: string;
  named: boolean;
  /** The must-haves, and whether the code seems to have each — `own`: game.yaml declares the game's own code for it (money.covers) */
  expects: { id: string; what: string; blocks: string[]; have: boolean; own?: string; later?: string }[];
  /** The blocks that fit the genre (its own first), and whether the code imports each */
  blocks: { name: string; from: string; what: string; used: boolean }[];
}

/** The genre's must-haves and blocks against what the code imports and the money design */
export function genreFacts(game: Pick<ResolvedGame, 'kit' | 'audience' | 'money' | 'listing'>, imported: readonly string[], source: string): GenreFacts {
  const g = gameGenre({ kit: game.kit.kit, audience: game.audience.id, money: game.money, tags: game.listing.tags });
  const info = GENRE_INFO[g.genre];
  const sub = g.sub ? SUBGENRE_INFO[g.sub] : null;
  const o = { imported, source, money: game.money };
  return {
    genre: g.genre,
    sub: g.sub,
    name: sub ? `${sub.name} (${info.name})` : info.name,
    players: sub?.players ?? info.players,
    from: g.from,
    named: g.named,
    expects: expectationsFor(g.genre, g.sub).map((e) => {
      const how = expectationHow(e, o);
      return { id: e.id, what: e.what, blocks: [...e.blocks], have: !!how, ...(how?.by === 'covers' ? { own: how.where } : {}), ...(e.later ? { later: e.later } : {}) };
    }),
    blocks: blocksFor(g.genre, g.sub).map((b) => ({ name: b.name, from: b.from, what: b.what, used: imported.includes(b.name) })),
  };
}

export interface DesignRunFrame {
  /** Seconds of the run (virtual time from the first screen) */
  sec: number;
  file: string;
  /** What was on screen: the first screen, in play, between runs */
  label: string;
}

export interface DesignRunBreak {
  /** Seconds of the run when play stopped */
  atSec: number;
  /** What a new player tapped to go on (session.ts' choice), in order */
  taps: string[];
  /**
   * How play went on: by itself (a results card that auto-continues — mountResults autoContinueSec, its big button
   * marked data-gp-auto — or a screen with no button that moved on within 3 s: not a stop), by the taps, or only by
   * QA's play() (no way on found)
   */
  how: 'auto' | 'tap' | 'qa';
  /** The results card's countdown, seconds, when it had one */
  autoSec?: number;
}

export interface DesignRun {
  frames: DesignRunFrame[];
  breaks: DesignRunBreak[];
  /** Seconds of the run the capture reached */
  reachedSec: number;
  targetSec: number;
  /** The demo bot played (host.qa({ demo })), else the run was left untouched */
  demo: boolean;
  /** The game says where it is (host.qa({ state })): the frames' labels carry it */
  state?: boolean;
  /** qa/design-sheet.png, or null when it could not be composed */
  sheet: string | null;
  problems: string[];
}

export interface DesignFacts {
  review: ReviewFacts;
  genre: GenreFacts;
  imported: string[];
  own: RecordedResult[];
  changelog: string | null;
  run: DesignRun | null;
  /** qa/design-gemini.md, when it is there */
  gemini: string | null;
  /** games/<id>/design.md as it is now (an earlier pass), parsed */
  previous: DesignReport | null;
  /** publisher/updates.yaml: every game's versions, to say which build a score measured (measuredBuild) */
  updates?: UpdateEntry[];
}

// --- Which build a score measured -----------------------------------------------------------------------------------

export const UPDATES_FILE = join(ROOT, 'publisher/updates.yaml');

/** One version of a game in publisher/updates.yaml (the fields the brief reads) */
export interface UpdateEntry {
  game: string;
  repo?: string;
  version: string;
  /** When the version was finished */
  date?: string;
  /** When the owner uploaded it to the portal */
  uploaded?: string;
}

/** publisher/updates.yaml's entries ([] without it, or when it doesn't parse) */
export function loadUpdates(file = UPDATES_FILE): UpdateEntry[] {
  if (!existsSync(file)) return [];
  try {
    const u = (parseYaml(readFileSync(file, 'utf8')) as { updates?: Record<string, unknown>[] } | null)?.updates ?? [];
    return u.filter((x) => typeof x?.game === 'string' && x.version !== undefined).map((x) => ({ game: String(x.game), repo: x.repo ? String(x.repo) : undefined, version: String(x.version), date: x.date ? String(x.date) : undefined, uploaded: x.uploaded ? String(x.uploaded) : undefined }));
  } catch {
    return [];
  }
}

const semver = (v: string) => v.split('.').map((n) => Number(n) || 0);
const bySemver = (a: string, b: string) => {
  const x = semver(a), y = semver(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) - (y[i] ?? 0);
  return 0;
};

/**
 * The build a Basic Launch score screen measured: `basicLaunch.scores.version` in results.yaml when it says so, else
 * inferred from publisher/updates.yaml — the record's versions (by its id, or its repository and an id of this game)
 * uploaded (or, without an upload date, finished) before the screen's date, as a range. null when neither knows
 */
export function measuredBuild(r: RecordedResult, updates: readonly UpdateEntry[], ids: readonly string[] = []): { version: string; inferred: boolean } | null {
  const sc = r.basicLaunch?.scores;
  if (sc?.version) return { version: sc.version, inferred: false };
  if (!sc?.date) return null;
  const repo = normRepo(r.repo);
  const mine = updates.filter((u) => u.game === r.game || (repo && normRepo(u.repo) === repo && ids.includes(u.game)));
  const before = mine.filter((u) => {
    const when = u.uploaded ?? u.date;
    return !!when && when < sc.date!;
  });
  if (!before.length) return null;
  const vs = [...new Set(before.map((u) => u.version))].sort(bySemver);
  return { version: vs.length > 1 ? `${vs[0]}–${vs.at(-1)}` : vs[0], inferred: true };
}

/** "build 1.0.0–1.3.6" / "build 1.0.0–1.4.0? (inferred from publisher/updates.yaml …)" for a score line */
export function buildLabel(b: { version: string; inferred: boolean } | null): string {
  if (!b) return 'build not recorded (basicLaunch.scores.version in publisher/results.yaml says it)';
  return b.inferred ? `build ${b.version}? (inferred: the versions publisher/updates.yaml has finished before the score screen; basicLaunch.scores.version in results.yaml says it exactly)` : `build ${b.version}`;
}

/** Everything the brief says about the game: gp review's facts (one reading of the disk), plus the designer's own */
export async function designFacts(loc: GameLocation, game: ResolvedGame, review: ReviewFacts, run: DesignRun | null): Promise<DesignFacts> {
  const sources = game.kit.kit === 'code' ? gameSources(loc.dir).map((f) => readFileSync(f, 'utf8')) : [];
  const imported = [...new Set(sources.flatMap((s) => importedBlocks(s)))];
  const gem = join(loc.dir, 'qa', DESIGN_GEMINI);
  const prev = join(loc.dir, DESIGN_FILE);
  return {
    review,
    genre: genreFacts(game, imported, sources.join('\n')),
    imported,
    own: ownResults(review.results, game, loc, gameRepo(loc.dir)),
    changelog: changelogHead(loc.dir),
    run,
    gemini: existsSync(gem) ? gem : null,
    previous: existsSync(prev) ? parseDesign(readFileSync(prev, 'utf8'), { title: game.title }) : null,
    updates: loadUpdates(),
  };
}

// --- The brief ------------------------------------------------------------------------------------------------------

/** The buttons tapped at a stop, as their data-gp ids */
const tapsText = (taps: readonly string[]) => taps.map((t) => `\`${t}\``).join(' → ') || 'nothing';
const clock = (sec: number) => `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
const pct = (x: number | undefined) => (x === undefined ? '?' : `${(x * 100).toFixed(x < 0.1 ? 2 : 1)} %`);
const cell = (s: string) => s.replace(/\|/g, '\\|');

/** The Basic Launch stops on record, as one line each: why this tool exists, from the data — each with the build it measured when known */
export function stopsLines(results: readonly RecordedResult[], updates: readonly UpdateEntry[] = []): string[] {
  return results
    .filter((r) => r.basicLaunch?.verdict === 'stopped')
    .map((r) => {
      const s = r.basicLaunch!.scores;
      const line = scoresLine(s);
      const bl = r.basicLaunch!;
      const raw = bl.avgPlaytimeMin !== undefined || bl.d1 !== undefined || bl.conversion1min !== undefined ? `playtime ${bl.avgPlaytimeMin ?? '?'} min, D1 ${pct(bl.d1)}, conversion ${pct(bl.conversion1min)}` : 'stopped (no numbers recorded)';
      const b = measuredBuild(r, updates);
      return `- ${r.title ?? r.game}${s?.date || b ? ` (${[s?.date, b ? `build ${b.version}${b.inferred ? '?' : ''}` : ''].filter(Boolean).join(', ')})` : ''}: ${line ?? raw}`;
    });
}

/**
 * This game's own record: the scores per device and metric, what the next score needs — and which build each score
 * screen measured, against the version in this checkout (Idle Garage Evolution 1.5.0's brief mixed the scores of
 * 1.0–1.4 with the 1.5.0 changes without saying which build a number measured)
 */
export function ownMetricsSection(own: readonly RecordedResult[], o: { updates?: readonly UpdateEntry[]; current?: string | null; ids?: readonly string[] } = {}): string[] {
  const L: string[] = ['### This game on the portal', ''];
  if (!own.length) {
    L.push('No record of this game in publisher/results.yaml yet: the targets are the benchmarks below (Full Launch needs 9 of 15 on a device class).', '');
    return L;
  }
  for (const r of own) {
    const bl = r.basicLaunch;
    L.push(`- ${r.title ?? r.game}${r.review ? ` — review ${r.review.verdict}${r.review.date ? ` ${r.review.date}` : ''}${r.review.reason ? ` ("${r.review.reason}")` : ''}` : ''}${bl?.verdict ? ` · Basic Launch ${bl.verdict}` : ''}${r.category ? ` · category ${r.category}` : ''}`);
    const sc = bl?.scores;
    if (sc) {
      const b = measuredBuild(r, o.updates ?? [], o.ids ?? []);
      const differs = !!(o.current && b && !b.version.split(/\s*[–-]\s*/).includes(o.current));
      L.push('', `**The score screen of ${sc.date ?? '(no date)'} measured ${buildLabel(b)}.**${o.current ? ` This checkout is ${o.current}${differs ? `: what changed since ${b!.version.split(/\s*[–-]\s*/).at(-1)} (the CHANGELOG below) is not in these numbers — judge it in play, not by them` : ''}.` : ''}`);
      L.push('', `| Device (${b ? `build ${b.version}${b.inferred ? '?' : ''}` : 'build ?'}) | Playtime | D1 | Conversion | Total |`, '|---|---|---|---|---|');
      for (const dev of BASIC_LAUNCH.devices) {
        const d = sc[dev];
        if (!d) continue;
        const c = (m: 'playtime' | 'd1' | 'conversion') => {
          const x = d[m];
          if (!x) return '—';
          const v = x.value === undefined ? '' : m === 'playtime' ? `${x.value} min` : pct(x.value);
          const next = x.next === undefined ? '' : ` (next at ${m === 'playtime' ? `${x.next} min` : pct(x.next)})`;
          return `${v}${v ? ' → ' : ''}**${x.score ?? '?'}/5**${next}`;
        };
        const t = deviceTotal(d);
        L.push(`| ${dev === 'desktop' ? 'Desktop' : 'Mobile and Tablet'} | ${c('playtime')} | ${c('d1')} | ${c('conversion')} | ${t ?? '?'}/${BASIC_LAUNCH.of}${t !== null ? ` (${t >= BASIC_LAUNCH.fullLaunchAt ? 'Full Launch' : `${BASIC_LAUNCH.fullLaunchAt - t} short of ${BASIC_LAUNCH.fullLaunchAt}`})` : ''} |`);
      }
      // The weakest metric per device: where a point is cheapest
      const weakest = BASIC_LAUNCH.devices.flatMap((dev) => {
        const d = sc[dev];
        if (!d) return [];
        const ms = BASIC_LAUNCH.metrics.filter((m) => typeof d[m]?.score === 'number').sort((a, b) => d[a]!.score! - d[b]!.score!);
        return ms.length ? [`${dev}: ${BASIC_LAUNCH.labels[ms[0]]} (${d[ms[0]]!.score}/5)`] : [];
      });
      if (weakest.length) L.push('', `Weakest per device — where a point is likely cheapest: ${weakest.join('; ')}.`);
    } else if (bl) L.push(`  - playtime ${bl.avgPlaytimeMin ?? '?'} min, D1 ${pct(bl.d1)}, conversion ${pct(bl.conversion1min)}`);
    if (r.notes) L.push(`  - notes: ${r.notes}`);
  }
  L.push('');
  return L;
}

/** The genre: what its players expect (have / missing) and the blocks that fit it (used / not yet) */
export function genreSection(g: GenreFacts): string[] {
  const L: string[] = [
    `## The genre: ${g.name}`,
    '',
    `${g.players} (from ${g.from}${g.named ? '' : ' — not named in game.yaml `money.genre`: say it, the benchmarks and must-haves depend on it'}).`,
    '',
    "What its players expect (the must-haves, packages/spec/src/genres.ts) and whether the code seems to have each — a missing one is a candidate for a [high] proposal, unless the game has it in a shape the search can't see (then say so, and propose declaring it: game.yaml `money.covers: { <id>: \"<where>\" }`); \"✓ own code\" is the game's own code, as game.yaml declares it — check in play that it is there:",
    '',
  ];
  for (const e of g.expects)
    L.push(`- ${e.have ? '✓' : '✗'}${e.own ? ' own code' : ''} ${e.what} (\`${e.id}\`)${e.later ? ` (${e.later})` : ''}${e.own ? ` — money.covers: ${e.own}` : e.blocks.length ? ` — ${e.blocks.map((b) => `\`${b}\``).join(', ')}` : ''}`);
  const unused = g.blocks.filter((b) => !b.used);
  const used = g.blocks.filter((b) => b.used);
  L.push('', `The platform's blocks that fit this genre (\`gp catalog blocks --genre ${g.sub ?? g.genre}\`): **${used.length} used, ${unused.length} not yet.** Build a proposal from one of these where it fits — it comes tested, in the game's look (\`screenTheme\`), checked by gp qa — and say which in the how:`, '');
  L.push('| Block | From | What it gives the player | In the game |', '|---|---|---|---|');
  for (const b of [...unused, ...used]) L.push(`| \`${b.name}\` | ${b.from} | ${cell(b.what)} | ${b.used ? '✓ used' : '—'} |`);
  L.push('', 'Where no block exists, the game\'s own code builds it — and if another game would need it too, say so in the proposal ("a block request").', '');
  return L;
}

/** The run's contact sheet: where it is, how far it got, its breaks and frames */
export function runSection(id: string, run: DesignRun | null): string[] {
  const L: string[] = ['## The run: a new player, on the virtual clock', ''];
  if (!run) {
    L.push(`No run captured (\`--no-capture\`, or the capture failed): \`gp design ${id}\` without it films one. Play it yourself meanwhile.`, '');
    return L;
  }
  L.push(
    `${run.sheet ? `**${shown(run.sheet)}** — open it full size: ` : 'The sheet could not be composed; the frames: '}a fresh save at 1280×720 (DPR 1, \`?seed=1\`), the first screen, then Play and ${run.demo ? "the game's demo bot (host.qa({ demo }))" : 'nobody touching anything (no demo bot: host.qa({ demo }) — the frames show an idle run)'}, a frame every ${DESIGN_EVERY_SEC} s, ${clock(run.reachedSec)} of the run${run.reachedSec + 1 < run.targetSec ? ` (of ${clock(run.targetSec)} asked: the capture's time ran out — a heavy game reaches less)` : ''}. At a stop it goes on as a new player would (gp qa's session section: the big button that continues — never Menu, never a rewarded offer — up to 3 taps).`,
    '',
  );
  const stops = run.breaks.filter((b) => b.how !== 'auto');
  const autos = run.breaks.filter((b) => b.how === 'auto');
  if (run.breaks.length) {
    L.push(`Where play stopped and how it went on — ${stops.length} stop(s) a player meets${autos.length ? `; ${autos.length} results card(s) that went on by themselves (auto-continue: **not stops** — the bot waited for the countdown, as a new player who lets it run does)` : ''}:`, '');
    for (const b of run.breaks)
      L.push(
        `- ${clock(b.atSec)}: ${
          b.how === 'auto'
            ? `the card went on by itself${b.autoSec ? ` after its ${b.autoSec}-s countdown (mountResults autoContinueSec)` : ' (no button on screen; play resumed within 3 s)'} — not a stop`
            : b.how === 'tap'
              ? `tapped ${tapsText(b.taps)}${b.autoSec ? ` (the card's ${b.autoSec}-s countdown did not go on)` : ''}`
              : `no way on found${b.taps.length ? ` after ${tapsText(b.taps)}` : ''} — QA's play() went on (a dead end for a player?)`
        }`,
      );
    L.push('');
  } else L.push('Play never stopped in the run (one long run, or a game that goes on by itself).', '');
  if (run.state === false) L.push("The game has no `host.qa({ state })`: the frames say only in play / between runs. With it (the screen, the stage, the goal, what to touch now) each frame says where the game is, and you can drive the game from it — docs/guides/code-games.md → What gp qa needs from you; propose it if the game lacks it.", '');
  L.push('The frames:', '', ...run.frames.map((f) => `- ${clock(f.sec)} ${f.label}: ${shown(f.file)}`), '');
  if (run.problems.length) L.push('Capture notes:', '', ...run.problems.map((p) => `- ${p}`), '');
  L.push('The bot taps the big button at once and never reads: you are slower, and the real stops come earlier. Treat the sheet as a map of what to play, not as the play.', '');
  return L;
}

/** One section's lens: the metric, the question, the facts the platform has for it, its blocks and its lessons */
export function sectionLens(s: DesignSection, f: DesignFacts, game: Pick<ResolvedGame, 'concept' | 'money' | 'channel'>): string[] {
  const L: string[] = [`### ${s.heading} — ${s.metrics.map((m) => (m === 'D1' ? 'D1 retention' : m)).join(', ')}`, '', `**Answer:** ${s.question}`, ''];
  const r = f.review;
  if (s.id === 'first-minute') {
    if (r.firstMinute) {
      const lines = firstMinuteLines(r.firstMinute, game.concept?.twist ? (game.concept.twist.within ?? 30) : null);
      L.push('From qa/first-minute.json:', '', ...lines.map((x) => `- ${x.ok === null ? '·' : x.ok ? '✓' : '✗'} ${x.text}`), '');
    } else L.push('(No qa/first-minute.json yet: a full `gp qa` writes it.)', '');
    if (r.firstLook?.ok) L.push(`The blind first look (qa/first-look.md): goal "${r.firstLook.goal}", hook "${r.firstLook.hook}", keep playing ${r.firstLook.keep}/5 — ${r.firstLook.keepWhy}`, '');
  }
  if (s.id === 'session') {
    const ss = r.session;
    if (ss?.lines) L.push(`From qa/session.json (${ss.bot === 'idle' ? 'an idle player — a lower bound' : 'the demo bot'}):`, '', `- First natural stop: ${ss.lines.stop}`, `- Estimate: ${ss.lines.estimate}`, `- What pulls on: ${ss.lines.pulls}`, `- The breaks: ${ss.lines.breaks}`, '');
    else L.push('(No qa/session.json yet: a full `gp qa` writes it — where a new player\'s session stops, by gp qa\'s model.)', '');
    const m = game.money;
    if (m?.session) L.push(`The design says: session ${m.session.minutes ?? '?'} min, ${m.session.breaks ?? '?'} natural breaks${m.session.breaksAt ? ` (${m.session.breaksAt})` : ''}.`, '');
    if (r.balance) L.push(`The balance report: ${shown(r.balance)} — the first purchase, the meta's length, walls and grinds (\`gp balance\`).`, '');
  }
  if (s.id === 'return') {
    const ret = game.money?.returns;
    L.push(`The design says the reason to return is: ${ret ? `${ret.kind}${ret.what ? ` — ${ret.what}` : ''}` : 'nothing (money.returns is empty)'}. Is it visible on the title, and does a session end with something left open?`, '');
  }
  if (s.id === 'phones' && r.firstMinute) {
    const touch = firstMinuteLines(r.firstMinute, null).filter((x) => /touch|4× CPU/i.test(x.text));
    if (touch.length) L.push(...touch.map((x) => `- ${x.ok === null ? '·' : x.ok ? '✓' : '✗'} ${x.text}`), '');
  }
  if (s.id === 'feel' && r.qa?.warnings?.length) {
    const w = r.qa.warnings.filter((x) => /\[(feel|sound)\]/.test(x));
    if (w.length) L.push("gp qa's feel and sound warnings:", '', ...w.slice(0, 8).map((x) => `- ${x}`), '');
  }
  if (s.id === 'content' && r.scope) L.push(`Systems the code shows: ${r.scope.systems.join(', ') || 'none found'}; screens: ${r.scope.screens.join(', ') || 'none found'}. Deepen what is there before a new system (the scope rule: more than 15 screens on a first submission is W_SCOPE; a new screen nobody polished is what the quality rejections were made of).`, '');
  const fit = new Set(f.genre.blocks.map((b) => b.name));
  const blocks = s.blocks.filter((b) => fit.has(b));
  L.push(blocks.length ? `Blocks for it that fit the genre: ${blocks.map((b) => `\`${b}\`${f.imported.includes(b) ? ' ✓' : ''}`).join(', ')} (✓ already in the game).` : "No block of the platform's for it fits this genre: the game's own code.", '');
  const lessons = s.lessons.map((id) => LESSONS.find((l) => l.id === id)).filter((l) => !!l);
  if (lessons.length) {
    L.push('What the people who judged our games said about it (`gp lessons`):', '');
    for (const l of lessons) L.push(`- **${l.flaw}.** Look: ${l.look} Fix: ${l.fix}`);
    L.push('');
  }
  return L;
}

/** The designer's rules and the format: the same words for the agent's brief and for Gemini's prompt */
export function designerRules(game: Pick<ResolvedGame, 'title'>): string[] {
  return [
    '## What makes a proposal count',
    '',
    '- **Concrete and buildable.** Not "improve retention" or "add juice" — "the results screen starts the next run after 3 s, with the next goal and its progress (`mountResults({ autoContinueSec: 3 })`)". A game maker must be able to build it from your line without asking.',
    '- **The metric and what you saw.** Each proposal names the Basic Launch metric it moves — conversion (the share who play a minute), playtime (the session), D1 (who come back tomorrow) — and the moment you saw it, with the time ("at 1:10 the first results screen offers only Play again").',
    '- **The expected effect:** `[high]` you expect it to move a metric by a point on a device class; `[mid]` a visible change in the metric; `[low]` polish. **The effort** at the end: `· effort S` (hours), `M` (a day), `L` (more). The Top 3 are the best effect for their effort, not the three biggest.',
    "- **The platform's block first.** Where a block does it (listed in this brief: what fits the genre, used or not), name it in the how; it comes tested and themed. Where none does, the game's code (a file, game.yaml, the balance data) — and say if it should become a block.",
    "- **What the genre's hits do.** Look up the top CrazyGames games of the genre (the most played and best rated) and say what they do in the first minute, the session and the return that this game doesn't — then take the idea in this game's own shape, never a copy (CrazyGames rejects games \"quite close to existing titles\").",
    '- **Deepen before you widen.** A new system is a screen a reviewer opens unfinished: our rejected games grew features faster than feel (75 weapons, 78 parts, 16 screens). Prefer what makes the core action and the screens that exist better; put a new system under "Not now" unless it is the one thing missing.',
    '- **Not what is there.** Check the code and play before you propose: a block marked used is in the game — propose a better use of it, not adding it.',
    '- Say what you saw. No proposal without an observation behind it; a section with nothing to change gets `- [none] — <why>`.',
    '',
    `## The format of ${DESIGN_FILE} (fixed: \`gp design --check\` parses it)`,
    '',
    '```markdown',
    designTemplate(game.title).trimEnd(),
    '```',
    '',
    `Rules: the heading names the game; \`## Top 3\` has exactly three proposals; each of ${DESIGN_SECTIONS.map((s) => `\`## ${s.heading}\``).join(', ')} has at least one proposal or \`- [none] — <why>\`; \`## ${HITS_HEADING}\` names at least two games, \`- <game>: <what it does> → <what we take>\`. A proposal is \`- [high|mid|low] <change> — <why: the metric and what you saw> → <how: the block or the code> · effort S|M|L\` (it may go on over indented lines); the why names a metric (conversion / first minute, playtime / session, D1 / coming back), the how a block or the game's code; at least one [high]. Other sections (\`## Not now\`, notes) are free text.`,
    '',
  ];
}

/** games/<id>/qa/design-brief.md: the designer's whole task in one file */
export function designBrief(loc: GameLocation, game: ResolvedGame, f: DesignFacts, date: string, o: { url?: string | null } = {}): string {
  const id = loc.id;
  const url = o.url ?? null;
  const hasState = f.run?.state ?? null;
  const r = f.review;
  const c = game.concept;
  const m = game.money;
  const portal = game.channel.id === 'crazygames';
  const L: string[] = [
    `# ${game.title} — game design brief`,
    '',
    `Written by \`gp design ${id}\` on ${date}, for **a game designer agent who did not make this game** (and is not its quality reviewer).`,
    '',
    '**Why.** Approval is not the goal; the Basic Launch score is. Every game we launched on CrazyGames stopped there, most of them a point or two short of Full Launch (9 of 15 on a device class):',
    '',
    ...stopsLines(r.results, f.updates),
    '',
    "`gp review` judges a version (pass/fail); nobody invents the next one. **That is your job: what to add or change so the next version scores more** — on average playtime, D1 retention and the 1-minute conversion, desktop and phone — ranked by expected effect and effort, each built from the platform's blocks where one exists.",
    '',
    '## Your task',
    '',
    `1. **Look at the run first** (below: ${f.run?.sheet ? shown(f.run.sheet) : 'the contact sheet'}): a new player's first minutes as the demo bot plays them, a frame every ${DESIGN_EVERY_SEC} s — a map of what to play.`,
    `2. **Play the game yourself, at least ${DESIGNER_PLAY_MIN} minutes as a new player** — a fresh browser context is a fresh save — **on a frozen build**: ${url ? `**${url}** (\`gp design --serve\` keeps it up: no file watcher, no HMR) — or start your own: ` : ''}\`npm run gp -- dev ${id} --frozen\` (in a game's own repository: \`scripts/gp.sh dev --frozen\`; run it in the background, it prints the URL; \`gp dev ${id} --stop\` stops it). Never the plain \`gp dev\` while you play: its HMR reloads the page when a file changes, and to you (or your bot) that looks like the game jumping to the title — it happened twice in Idle Garage Evolution 1.5.0's first design session. \`?seed=1\` repeats a run, \`?ads=fail\` plays it as Basic Launch with ads off, \`?qa-demo=0\` keeps the game's demo bot off whatever calls it. **Desktop first (1280×720, mouse and keyboard), then the phone (360×800, touch only).** Note the times: the first action, the first reward, the first results screen, the first new thing, and where you would have closed the tab — and why.`,
    '3. **Then play as an experienced player**: keep the same context (the save) and play 5+ minutes more, or let the demo bot play long (`window.__gp.host.qaDriver.demo()` after Play; reload with `?qa-demo=0` to take over again — the bot has no off switch of its own); open every screen and use every feature (the screens: below). What does the game offer someone on their third session?',
    `4. **Look up the genre's hits on CrazyGames**: a web search \`site:crazygames.com ${f.genre.sub ?? f.genre.genre}\` (crazygames.com itself may be closed to a cloud session's network), the most played and best rated of the genre — what do they do in the first minute, the session and the return that this game doesn't?`,
    `5. **Read the facts below** — the metrics, the genre, where the session stops, the lessons — and the code where a proposal depends on it.`,
    `6. **Write ${shown(join(loc.dir, DESIGN_FILE))}** in the format below; \`npm run gp -- design ${id} --check\` checks it.`,
    '',
    'Driving the game with Playwright (no browser of your own? This is your hands; screenshots are your eyes):',
    '',
    '```js',
    "import { chromium } from 'playwright';",
    'const browser = await chromium.launch();',
    "const page = await browser.newPage({ viewport: { width: 1280, height: 720 } }); // phone: { viewport: { width: 360, height: 800 }, hasTouch: true, isMobile: true }",
    `await page.goto(${url ? `'${url}'` : 'URL'} + '?seed=1&qa-demo=0');    // the frozen server; no demo bot behind your back`,
    "await page.click('[data-gp=play]');                  // the title's Play (a first visit may land in play at once)",
    "await page.mouse.click(640, 400); await page.keyboard.press('Space');",
    'await page.waitForTimeout(10_000);                    // real time: the game runs by itself',
    "await page.screenshot({ path: 'shot-0010.png' });",
    'console.log(await page.evaluate(() => ({ playing: window.__gp.host.isPlaying, playedSec: window.__gp.host.playedSec, state: window.__gp.host.qaState() })));',
    '// host.qa({ state }), when the game has it: { screen, stage, goal, touch: [{ x, y, label }] } — what to touch now',
    "const st = await page.evaluate(() => window.__gp.host.qaState());",
    'if (st?.touch?.[0]) await page.mouse.click(st.touch[0].x, st.touch[0].y);',
    '```',
    '',
    hasState === true
      ? "This game says where it is: `window.__gp.host.qaState()` returns `{ screen, stage, goal, touch }` (host.qa({ state })) — the screen on now, the stage, the goal it shows and what to touch next. Drive the game from it instead of reverse-engineering the code; check in play that what it says is what a player sees."
      : hasState === false
        ? "This game has no `host.qa({ state })` (`window.__gp.host.qaState()` returns null): read the screen from screenshots and the code. A state hook — `{ screen, stage?, goal?, touch?: [{ x, y, label }] }` — is a cheap [low] proposal (Content and variety or Phones) that makes the next design pass and gp qa's bots see what a player sees."
        : '`window.__gp.host.qaState()` returns `{ screen, stage, goal, touch }` when the game has host.qa({ state }), else null.',
    '',
    ...designerRules(game),
  ];
  if (f.previous) {
    const p = f.previous;
    L.push('## The last design pass', '', `${shown(join(loc.dir, DESIGN_FILE))} is there${p.ok ? '' : ` (malformed: ${p.problems.length} problem(s))`}: ${designSummary(p)}. Check in play what was built of it and what moved; keep what still holds, drop what is done, and say what the last pass got wrong.`, '');
  }
  L.push(...runSection(id, f.run));
  L.push('## The metrics: where this game stands', '');
  L.push(...ownMetricsSection(f.own, { updates: f.updates, current: game.version?.name ?? null, ids: [game.id, loc.id] }));
  const fc = r.forecast;
  if (fc) L.push(`- **Forecast** (\`gp forecast\`): ${'error' in fc ? `not available (${fc.error})` : `${fc.line}${fc.levers.length ? `; its levers: ${fc.levers.join(' · ')}` : ''}`}`, '');
  if (portal) L.push(...basicLaunchSection(r.results));
  L.push('## The game: what the platform knows', '');
  L.push(`- **${game.title}** (\`${id}\`) · ${game.audience.id} · ${game.channel.id} · kit \`${game.kit.kit}\` · game.yaml: ${shown(loc.file)}`);
  if (c) {
    L.push(`- **Concept:** ${c.pitch}`, `- **Different from** ${c.closest.join(', ')}: ${c.different}`);
    if (c.twist) L.push(`- **Twist:** \`${c.twist.event}\`, within ${c.twist.within ?? 30} s${c.twist.explained ? ` — "${c.twist.explained}"` : ''}`);
    if (c.progression) L.push(`- **Progression (as declared):** ${c.progression}`);
  } else L.push('- **Concept:** none in game.yaml');
  if (r.progression) L.push(`- **Progression (as the code shows it):** ${r.progression}`);
  if (m) {
    const s = m.session;
    L.push(`- **Money design:** ${m.genre ?? 'genre not set'}; session ${s?.minutes ?? '?'} min, ${s?.breaks ?? '?'} natural breaks${s?.breaksAt ? ` (${s.breaksAt})` : ''}; returns: ${m.returns?.kind ?? '?'}${m.returns?.what ? ` — ${m.returns.what}` : ''}`);
    for (const x of m.rewarded ?? []) L.push(`  - rewarded \`${x.placement}\` (${x.kind}): ${x.gives}`);
  } else L.push('- **Money design:** none in game.yaml');
  L.push(`- **Story:** ${game.story ? `depth \`${game.story.depth}\`${game.story.premise ? `, premise: "${game.story.premise}"` : ''}` : 'none declared'}`);
  if (r.scope) L.push(`- **Screens declared to QA:** ${r.scope.screens.join(', ') || 'none found'} · systems: ${r.scope.systems.join(', ') || 'none found'}`);
  const known = f.imported.filter((b) => GENRE_BLOCKS[b]);
  const rest = f.imported.length - known.length;
  L.push(`- **Platform blocks the code imports:** ${known.length ? known.map((b) => `\`${b}\``).join(', ') : 'none of the catalogued ones'}${rest ? ` (and ${rest} more names from @gp/*: drawing, sound and helpers)` : ''}`);
  if (r.qa) L.push(`- **Last gp qa:** ${r.qa.date} — ${r.qa.passed} passed, ${r.qa.failed} failed${r.qa.mode === 'quick' ? ' (a --quick run)' : ''}; report ${shown(r.qa.report)}`);
  else L.push(`- **Last gp qa:** none yet — \`gp qa ${id}\` writes where the session stops (qa/session.json) and the first minute (qa/first-minute.json); run \`gp design\` again after it`);
  if (r.uniqueness) L.push(`- **Uniqueness:** ${r.uniqueness.score}/100 — ${r.uniqueness.verdict}`);
  L.push('');
  if (f.changelog) L.push('### What changed lately (CHANGELOG.md)', '', '```markdown', f.changelog, '```', '', 'Judge the last changes by the metrics: which moved what, and which a player can even see.', '');
  L.push(...genreSection(f.genre));
  L.push('## By section: the metric, what the platform measured, the blocks and the lessons', '', `Each section of ${DESIGN_FILE}, with what to answer while you play.`, '');
  for (const s of DESIGN_SECTIONS) L.push(...sectionLens(s, f, game));
  L.push('## A second opinion from Gemini', '');
  if (f.gemini) L.push(`${shown(f.gemini)} has what Gemini made of a gameplay video (\`gp design ${id} --gemini\`). Read it after you played: take what you agree with **once you have seen it in play**, and say in ${DESIGN_FILE} where you disagree. A video shows the bot, not a person: Gemini can't feel the controls.`, '');
  else L.push(`None yet: \`gp design ${id} --gemini\` (with GEMINI_API_KEY in the environment) records a ${DESIGN_VIDEO_SEC}-second gameplay video and asks Gemini the same as you, into qa/${DESIGN_GEMINI}. Optional.`, '');
  return L.join('\n');
}

/**
 * The prompt Gemini gets with the video: the same rules and format as the agent's brief, and the game's facts in short
 * (it can't open files). It watches a bot play: it says what it sees, and proposes.
 */
export function designerPrompt(game: ResolvedGame, f: DesignFacts, media: { video?: number; frames?: number }): string {
  const c = game.concept;
  const m = game.money;
  const L: string[] = [
    `You are a senior game designer for web games on CrazyGames. Below is ${media.video ? `a ${media.video}-second gameplay video` : `${media.frames ?? 'a few'} frames (one every ${DESIGN_EVERY_SEC} s)`} of "${game.title}", played by a simple bot from a fresh save at 1280×720 (sound off). The game is stopping at Basic Launch: CrazyGames scores average playtime, D1 retention and gameplay conversion (the share who play at least one minute), each 1–5 per device class, and Full Launch needs 9 of 15 on one.`,
    '',
    'Watch it as a game designer and propose what to add or change so the next version scores more. Be concrete: what exactly, where, and how much — never generic advice. Name what you saw, with the time in the video. Rank by expected effect for the effort.',
    '',
    '## The game',
    '',
    `- ${game.title}: ${c?.pitch ?? '(no pitch)'}${c?.different ? ` — different from ${c.closest.join(', ')}: ${c.different}` : ''}`,
    `- Genre: ${f.genre.name} — ${f.genre.players}`,
    ...(m ? [`- Session as designed: ${m.session?.minutes ?? '?'} min, breaks: ${m.session?.breaksAt ?? m.session?.breaks ?? '?'}; reason to return: ${m.returns?.kind ?? '?'}${m.returns?.what ? ` — ${m.returns.what}` : ''}`] : []),
    ...f.own.flatMap((r) => {
      if (!r.basicLaunch?.scores) return [];
      const b = measuredBuild(r, f.updates ?? [], [game.id]);
      return [`- Its Basic Launch${b ? ` (build ${b.version}${b.inferred ? ', inferred' : ''}${game.version?.name && !b.version.includes(game.version.name) ? `; the video shows ${game.version.name}, with changes made since` : ''})` : ''}: ${scoresLine(r.basicLaunch.scores)}`];
    }),
    ...(f.review.session?.lines ? [`- Where an automatic new player's session first stops: ${f.review.session.lines.stop}`] : []),
    `- What the genre's players expect: ${f.genre.expects.map((e) => `${e.what} (${e.own ? `the game's own code: ${e.own}` : e.have ? 'the game has it' : 'missing'})`).join('; ')}`,
    '',
    '## The building blocks the game can use (name one in the how where it fits; otherwise say what to change in the game code)',
    '',
    ...f.genre.blocks.map((b) => `- ${b.name} (${b.from}): ${b.what}${b.used ? ' — already used' : ''}`),
    '',
    ...designerRules(game).filter((l) => !/gp design --check|parses it/.test(l)),
    `Answer with the file only, in exactly that format, starting with "# ${game.title} — design proposals". Under "Designer:" write "Gemini (from the video)". For "${HITS_HEADING}", name top CrazyGames games of the genre you know.`,
  ];
  return L.join('\n');
}

// --- The capture: a new player's run, a frame every 10 s -------------------------------------------------------------

/** Whether the host says the run is in play (true when the game doesn't say) */
const inPlay = (page: Page) => page.evaluate(() => (window as unknown as { __gp?: { host?: { isPlaying?: boolean } } }).__gp?.host?.isPlaying !== false);

/** What host.qa({ state }) says (host.qaState(): checked, null without the hook) */
export interface DesignQaState {
  screen: string;
  stage?: string;
  goal?: string;
  touch?: { x: number; y: number; label: string }[];
}
const qaState = (page: Page): Promise<DesignQaState | null> =>
  page.evaluate(() => {
    const h = (window as unknown as { __gp?: { host?: { qaState?: () => unknown } } }).__gp?.host;
    return (typeof h?.qaState === 'function' ? h.qaState() : null) as DesignQaState | null;
  }).catch(() => null);

/** A frame's label with the game's own word on where it is (host.qa({ state })): "in play — garage 2 · goal: 3/5 cars" */
export function withState(label: string, st: DesignQaState | null): string {
  if (!st) return label;
  const bits = [st.screen && !label.includes(st.screen) ? `screen ${st.screen}` : '', st.stage ?? '', st.goal ? `goal: ${st.goal}` : '', st.touch?.length ? `touch: ${st.touch.map((t) => t.label).slice(0, 3).join(', ')}` : ''].filter(Boolean);
  return bits.length ? `${label} — ${bits.join(' · ')}` : label;
}

/**
 * Past a stop as a new player goes on: gp qa's session section picks the button (the continuing ones first, never Menu,
 * never a rewarded offer: session.ts pickButton), up to 3 taps with a few seconds each; no way on — QA's play()
 */
export async function goOn(page: Page, step: (sec: number) => Promise<void>): Promise<{ taps: string[]; how: 'auto' | 'tap' | 'qa'; autoSec?: number }> {
  const { look, pickButton, tapIdx, MAX_TAPS } = await import('@gp/kit-code/qa/session');
  const taps: string[] = [];
  // A results card that goes on by itself (mountResults autoContinueSec): wait for it as gp qa's session section does —
  // a new player who lets the countdown run meets no stop there (the demo bot tapping "again" every run made the sheet
  // of Idle Garage Evolution 1.5.0 show a stop each ~25 s that no player meets)
  const first = await look(page);
  const auto = first.results?.autoSec ?? null;
  if (auto) {
    for (let s = 0; s < Math.ceil(auto) + 2; s++) {
      await step(1);
      if (await inPlay(page)) return { taps, how: 'auto', autoSec: auto };
    }
  } else if (!first.buttons.length) {
    for (let s = 0; s < 3; s++) {
      await step(1);
      if (await inPlay(page)) return { taps, how: 'auto' };
    }
  }
  for (let i = 0; i < MAX_TAPS; i++) {
    const pick = pickButton((await look(page)).buttons);
    if (!pick) break;
    taps.push(pick.label);
    await tapIdx(page, pick.idx);
    for (let s = 0; s < 8; s++) {
      await step(1);
      if (await inPlay(page)) return { taps, how: 'tap' };
    }
  }
  await page.evaluate(() => (window as unknown as { __gp?: { host?: { qaDriver?: { play?: () => void } } } }).__gp?.host?.qaDriver?.play?.());
  await step(1);
  return { taps, how: 'qa', ...(auto ? { autoSec: auto } : {}) };
}

const demoAgain = (page: Page) =>
  page.evaluate(() => {
    const d = (window as unknown as { __gp?: { host?: { qaDriver?: { demo?: () => void } } } }).__gp?.host?.qaDriver;
    if (typeof d?.demo !== 'function') return false;
    d.demo();
    return true;
  });

export const frameFile = (sec: number) => `frame-${Math.floor(sec / 60)}m${String(Math.floor(sec % 60)).padStart(2, '0')}.jpg`;

/**
 * A new player's run on the dev build (review-sheet.ts freshRun: a fresh save, ?seed=1, the virtual clock, 1280×720,
 * Play tapped, the demo bot on): a frame of the first screen, then one every `every` seconds of the run; at a stop of 2 s
 * it goes on as a new player would (goOn) and turns the demo bot on again. Then the contact sheet, qa/design-sheet.png.
 */
export async function captureDesignRun(loc: GameLocation, game: Pick<ResolvedGame, 'title'>, opts: { minutes?: number; every?: number } = {}): Promise<DesignRun> {
  const minutes = Math.min(DESIGN_MAX_MIN, Math.max(1, opts.minutes ?? DESIGN_PLAY_MIN));
  const every = opts.every ?? DESIGN_EVERY_SEC;
  const target = minutes * 60;
  const dir = join(loc.dir, 'qa', DESIGN_DIR);
  mkdirSync(dir, { recursive: true });
  for (const f of readdirSync(dir)) if (/^frame-.*\.jpg$/.test(f)) rmSync(join(dir, f));
  const frames: DesignRunFrame[] = [];
  const breaks: DesignRunBreak[] = [];
  const problems: string[] = [];
  let reached = 0;
  let demo = false;
  let hasState = false;
  const { freshRun } = await import('./review-sheet.ts');
  const shot = async (page: Page, sec: number, label: string) => {
    const file = join(dir, frameFile(sec));
    await page.screenshot({ path: file, type: 'jpeg', quality: 85 });
    frames.push({ sec, file, label });
  };
  let t0 = 0;
  const run = await freshRun(
    loc,
    async ({ page, now }) => {
      t0 = now();
      await shot(page, 0, withState('the first screen', await qaState(page)));
    },
    async ({ page, now, step }) => {
      demo = await page.evaluate(() => typeof (window as unknown as { __gp?: { host?: { qaDriver?: { demo?: unknown } } } }).__gp?.host?.qaDriver?.demo === 'function');
      hasState = (await qaState(page)) !== null;
      const wall = Date.now() + Math.max(60_000, minutes * WALL_MS_PER_MIN);
      let next = every;
      let stopped = 0;
      let since: DesignRunBreak | null = null;
      const t = () => now() - t0;
      while (t() < target && Date.now() < wall) {
        await step(1);
        if (await inPlay(page)) stopped = 0;
        else if (++stopped >= 2) {
          stopped = 0;
          const at = Math.max(0, Math.round(t() - 2));
          const g = await goOn(page, step);
          since = { atSec: at, ...g };
          breaks.push(since);
          if (demo) await demoAgain(page);
        }
        // One frame when the time passes a mark (a stop gone through may pass several: still one frame, at its time)
        if (t() >= next) {
          const on = await inPlay(page);
          await shot(page, Math.round(t()), withState(on ? (since ? (since.how === 'auto' ? `in play, after the card at ${clock(since.atSec)} went on by itself` : `in play, after the stop at ${clock(since.atSec)} (${since.how === 'tap' ? `tapped ${since.taps.map((x) => `"${x}"`).join(' → ')}` : 'no way on: QA play()'})`) : 'in play') : 'stopped: between runs', await qaState(page)));
          since = null;
          next = (Math.floor(t() / every) + 1) * every;
        }
      }
      reached = Math.min(target, t());
    },
  );
  problems.push(...run.problems);
  if (reached + 1 < target) problems.push(`the capture reached ${clock(reached)} of ${clock(target)} in its time (${Math.round(Math.max(60_000, minutes * WALL_MS_PER_MIN) / 1000)} s of the machine's): a heavy game — the frames stop there`);
  let sheet: string | null = null;
  try {
    const { chromium } = await import('playwright');
    const { contactSheet } = await import('./video.ts');
    const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
    try {
      sheet = await contactSheet(browser, frames.map((f) => ({ file: f.file, sec: f.sec, marks: [], label: f.label })), join(loc.dir, 'qa', DESIGN_SHEET), {
        title: game.title,
        video: "a new player's run",
        width: SHEET_W,
        height: SHEET_H,
        note: `a frame every ${every} s, ${demo ? 'the demo bot playing' : 'nobody touching (no demo bot)'}, going on at each stop as a new player would (gp design)`,
      });
    } finally {
      await browser.close();
    }
  } catch (e) {
    problems.push(`the contact sheet was not composed: ${String((e as Error).message).split('\n')[0]}`);
  }
  return { frames, breaks, reachedSec: Math.round(reached), targetSec: target, demo, state: hasState, sheet, problems };
}

/**
 * The gameplay cut for Gemini (gp video's recorder, `renderVideos`): the title off camera, Play, the demo bot, and on
 * through the stops as a new player goes on (goOn) — not the preview's script, which ends where the first run does
 */
export const designVideoScript: import('./video.ts').VideoScript = async (v) => {
  const { PLAY_SELECTOR } = await import('./video.ts');
  await v.until(PLAY_SELECTOR, 10);
  await v.step(v.sec(0.4), { film: false });
  await v.tap(PLAY_SELECTOR);
  const demo = await v.demo();
  let stopped = 0;
  while (v.filmed() < v.length) {
    const before = v.filmed();
    await v.step(v.sec(1));
    if (v.filmed() === before) break;
    if (await inPlay(v.page)) {
      stopped = 0;
      continue;
    }
    if (++stopped < 2) continue;
    stopped = 0;
    await goOn(v.page, (s) => v.step(v.sec(s)));
    if (demo) await v.demo();
  }
};

/** The page size of the gameplay cut: the portal's desktop at DPR 1 (Gemini samples a frame a second, at its own size) */
export const DESIGN_VIDEO_SIZE = { name: 'design', orientation: 'landscape' as const, width: SHEET_W, height: SHEET_H, dpr: 1 };

/**
 * `--gemini`: a gameplay video (gp video's recorder, designVideoScript), or the run's frames when no video can be made
 * (no ffmpeg), sent to Gemini with designerPrompt; its answer into qa/design-gemini.md. `videoFile`: a video already made
 * (null: none — the frames), else one is recorded; `http`: the transport (the tests' mock). Errors come back, not thrown.
 */
export async function secondOpinion(
  loc: GameLocation,
  game: ResolvedGame,
  facts: DesignFacts,
  o: { key: string; model: string; seconds: number; run: DesignRun | null; date: string; log?: (line: string) => void; http?: import('./gemini.ts').GeminiHttp; sleep?: (ms: number) => Promise<void>; videoFile?: string | null },
): Promise<{ file: string | null; error?: string; media: string; model?: string; notes?: string[] }> {
  const { askGemini, redact, resolveModel } = await import('./gemini.ts');
  const log = o.log ?? (() => {});
  // First the cheap check — does this key reach a model at all (a one-word question; a fallback named or Flash)? —
  // and only then the 90-s video: five tries on Idle Garage Evolution 1.5.0 recorded a video each, for no answer
  let model = o.model;
  let notes: string[] = [];
  try {
    log(`checking ${model} answers this key (a one-word question, before the video)…`);
    const r = await resolveModel({ model, key: o.key, http: o.http, sleep: o.sleep, log });
    model = r.model;
    notes = r.notes;
    log(`${model} answers${notes.length ? ` (asked for ${o.model})` : ''}`);
  } catch (e) {
    return { file: null, error: `${redact(String((e as Error).message), o.key)} — no video was recorded`, media: '' };
  }
  let video = o.videoFile ?? null;
  if (o.videoFile === undefined) {
    try {
      const { renderVideos } = await import('./video.ts');
      log(`a ${o.seconds}-second gameplay video (1280×720, through the stops)…`);
      const v = await renderVideos(loc, game, { outDir: join(loc.dir, 'qa', DESIGN_DIR), size: DESIGN_VIDEO_SIZE, max: o.seconds, play: designVideoScript, crf: DESIGN_VIDEO_CRF });
      for (const p of v.problems) log(p);
      video = v.files[0] ?? null;
    } catch (e) {
      log(`no video (${String((e as Error).message).split('\n')[0]}): Gemini gets the run's frames instead`);
    }
  }
  const frames = o.run?.frames.map((f) => f.file) ?? [];
  const media: import('./gemini.ts').GeminiMedia | null = video ? { kind: 'video', file: video } : frames.length ? { kind: 'frames', files: frames } : null;
  const what = video ? `a ${o.seconds} s video, ${shown(video)}` : `${frames.length} frames of the run, one every ${DESIGN_EVERY_SEC} s`;
  if (!media) return { file: null, error: 'nothing to show Gemini: no video and no frames (run without --no-capture, or install ffmpeg)', media: '' };
  try {
    const answer = await askGemini({ prompt: designerPrompt(game, facts, video ? { video: o.seconds } : { frames: frames.length }), media, model, key: o.key, http: o.http, log, sleep: o.sleep });
    const file = join(loc.dir, 'qa', DESIGN_GEMINI);
    mkdirSync(join(loc.dir, 'qa'), { recursive: true });
    const all = [...notes, ...answer.notes];
    writeFileSync(file, geminiMarkdown(game, { ...answer, notes: all }, o.date, what));
    return { file, media: what, model: answer.model, notes: all };
  } catch (e) {
    return { file: null, error: redact(String((e as Error).message), o.key), media: what, model, notes };
  }
}

/** qa/design-gemini.md: Gemini's answer under a header that says what it saw, and the answer's format check */
export function geminiMarkdown(game: Pick<ResolvedGame, 'title'>, answer: { text: string; model: string; sent: string; notes?: string[] }, date: string, media: string): string {
  const parsed = parseDesign(answer.text, { title: game.title });
  return [
    `<!-- gp design --gemini, ${date}: ${answer.model}, shown ${answer.sent} (${media}).${answer.notes?.length ? ` On the way: ${answer.notes.join('; ')}.` : ''} A second opinion for the designer agent — check every proposal in play before you take it. -->`,
    '',
    answer.text.trim(),
    '',
    '---',
    '',
    `Format check (gp design's parser): ${parsed.ok ? `well-formed — ${designSummary(parsed)}` : `${parsed.problems.length} problem(s): ${parsed.problems.slice(0, 5).map((p) => `line ${p.line}: ${p.message}`).join('; ')}`}.`,
    '',
  ].join('\n');
}
