// gp art <game>: raster art from an image model at build time, bundled with the game (docs/guides/art.md#5-generated-art-gp-art).
// game.yaml `art` names the style and the assets; a style board is made first and every asset is asked for in its style
// (the board goes along as a reference image). Sprites come on a chroma key and are cut out to transparency in the browser
// (Playwright's Chromium: no image library), trimmed, sized and saved as WebP in games/<id>/assets/, with assets/index.ts
// (the imports: ART.<id>) and assets/provenance.yaml (what made each file). Nothing is fetched at runtime.

import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { parse, stringify } from 'yaml';
import { loadYaml, type Issue } from '@gp/spec';
import type { GameLocation } from './paths.ts';

export const ASSETS_DIR = 'assets';
export const PROVENANCE_FILE = 'provenance.yaml';
export const STYLE_FILE = 'style.webp';
export const DEFAULT_IMAGE_MODEL = 'gemini-2.5-flash-image';
/** The key colour sprites are asked on (cut out from the corners' real colour: models drift off it) */
export const CHROMA = '#00FF00';
/** USD per image, for the estimate printed before a run (the Gemini API price list, 2026-10; batch halves it) */
export const IMAGE_PRICE_USD: Record<string, number> = { 'gemini-2.5-flash-image': 0.039, 'gemini-3-pro-image-preview': 0.134 };
const TERMS = 'https://ai.google.dev/gemini-api/terms';

type UpscaleMethodName = import('./upscale.ts').UpscaleMethod;
export type ArtKind = 'sprite' | 'background' | 'tile' | 'ui' | 'icon' | 'keyart';
export interface ArtAsset {
  id: string;
  kind: ArtKind;
  prompt: string;
  size?: number | [number, number];
  /** A sprite's animation: one pose per frame, each painted from the sprite itself (assets/<id>-<n>.webp, FRAMES.<id>) */
  frames?: string[];
  /** An existing image instead of a new one (a file in the game's folder, e.g. assets-src/…, or a URL — `gp assets get`) */
  from?: string;
  /** With `from`: the rectangle of a sheet to take, [x, y, w, h] in its pixels (`gp assets sheet` numbers the cells) */
  cut?: [number, number, number, number];
  /** With `from`: mirrored left to right (an enemy that has to face the other way) */
  flip?: boolean;
  /**
   * With `from`: the image is the design to keep, not the result — the model redraws that same design at the asset's
   * size and technique (a 16 px sprite as a detailed 32 px one, its shapes, colours and character unchanged)
   */
  redraw?: boolean;
  /** With `from`: made bigger with a pixel-art scaler, the design kept (gp assets compare shows them side by side) */
  upscale?: { method: string; factor: number; keepDetails?: boolean };
  /** import: a finished picture the owner supplied, made into this asset by `gp art import` (never generated) */
  source?: 'import';
  /** A part cut from another sprite (a car's wheel, its paint mask): its centre at `at`, in that sprite's pixels */
  part?: { of: string; at: [number, number] };
  /**
   * When it loads: 0 (the default) in the game's script, before Play; 1, 2 … after Play — in the one-file upload as data
   * blocks at the end of index.html, decoded when the game asks (createAssets in @gp/art/assets). A part follows its sprite
   */
  chapter?: number;
}
/** The most frames one sprite may have (each is a paid image) */
export const MAX_FRAMES = 12;
export interface ArtSpec {
  style: string;
  /** painted (default): WebP at the asset's size. pixel: pixel art on a grid of `size` pixels in the game's own palette, PNG */
  technique?: 'painted' | 'pixel';
  /** pixel: the game's palette (CSS hex): every pixel is one of these colours */
  palette?: string[];
  /** What the art keeps of the game: its identity and the rules of play the look serves (the game design leads) */
  keep?: string[];
  model?: string;
  assets: ArtAsset[];
}

/** One generated file as provenance.yaml records it */
export interface ArtRecord {
  kind: ArtKind | 'style';
  model: string;
  prompt: string;
  /** The style board it was made against (its sha256), or null for the board itself */
  style: string | null;
  size: [number, number];
  bytes: number;
  sha256: string;
  date: string;
  /** Set by `gp art --record` when the file was changed by hand after generation */
  edited?: string;
  /** Cut-outs: output px per model px — a sprite's frames are drawn at its scale, so the character keeps its size */
  scale?: number;
  /** A frame: the sprite it was painted from (its sha256) */
  from?: string;
  /** Drawn by hand (the svg provider): the SVG's sha256 — a changed drawing is rendered again. `owner`: imported (gp art import) */
  source?: string;
  /** Imported: the owner's file it came from, and that file's sha256 */
  original?: string;
  originalSha256?: string;
  /** Imported: the settings it was cleaned up with (cleanup.json and the flags, as JSON), so a changed one is imported again */
  cleanup?: string;
  /** Imported paint mask: the body's dominant hue, in degrees */
  hue?: number;
}
export interface Provenance {
  terms: string;
  files: Record<string, ArtRecord>;
}

/** The game's `art` section, as written (null when it has none) */
export function artSpec(loc: GameLocation): ArtSpec | null {
  const spec = (loadYaml(readFileSync(loc.file, 'utf8')).data ?? {}) as { art?: ArtSpec };
  return spec.art?.assets?.length ? spec.art : null;
}

const cutout = (k: ArtKind | 'style') => k === 'sprite' || k === 'ui' || k === 'icon';
const opaqueFill = (k: ArtKind | 'style') => k === 'background' || k === 'tile' || k === 'keyart';
/** An owner's picture (`source: import`): made by gp art import, never by a provider */
export const imported = (a: ArtAsset) => a.source === 'import';
const camel = (id: string) => id.replace(/-([a-z0-9])/g, (_, c: string) => c.toUpperCase());
/** A sprite's frame files, in order: <id>-1.webp, <id>-2.webp … */
export const frameFiles = (a: ArtAsset, ext = 'webp'): string[] => (a.kind === 'sprite' ? (a.frames ?? []) : []).map((_, i) => `${a.id}-${i + 1}.${ext}`);
/** Every file one asset makes */
export const assetFiles = (a: ArtAsset, ext = 'webp'): string[] => [`${a.id}.${ext}`, ...frameFiles(a, ext)];
/** The image format: pixel art is lossless PNG (a lossy WebP smears the pixels), the rest WebP */
export const extOf = (art: Pick<ArtSpec, 'technique'> | null | undefined): string => (art?.technique === 'pixel' ? 'png' : 'webp');
const stem = (f: string) => f.replace(/\.(webp|png)$/, '');
/** The sprite whose look the key art and the frames follow: the first one */
const heroOf = (art: ArtSpec) => art.assets.find((a) => a.kind === 'sprite');
export const sha256 = (b: Buffer) => createHash('sha256').update(b).digest('hex');

/** The size in the game: [w, h] for opaque art, [long side, long side] (a bound) for cut-outs */
export function targetSize(a: ArtAsset): [number, number] {
  if (Array.isArray(a.size)) return a.size;
  if (typeof a.size === 'number') return [a.size, a.size];
  if (a.kind === 'background' || a.kind === 'keyart') return [1280, 720];
  return a.kind === 'icon' ? [128, 128] : [256, 256];
}

const ASPECTS: [string, number][] = [['1:1', 1], ['3:4', 3 / 4], ['4:3', 4 / 3], ['9:16', 9 / 16], ['16:9', 16 / 9], ['2:3', 2 / 3], ['3:2', 3 / 2], ['4:5', 4 / 5], ['5:4', 5 / 4], ['21:9', 21 / 9]];
/** The model's aspect ratio nearest to the asset's (cut-outs are square: they are trimmed afterwards) */
export function aspectFor(a: ArtAsset): string {
  if (cutout(a.kind)) return '1:1';
  const [w, h] = targetSize(a);
  return ASPECTS.reduce((best, x) => (Math.abs(Math.log(x[1] / (w / h))) < Math.abs(Math.log(best[1] / (w / h))) ? x : best))[0];
}

/**
 * The house look, sent with every request: stylized cartoon game art, never photorealism (the owner, 2026-10-10: "not
 * hyper-realistic graphics — cartoon, game-like"). The game's own `style` says which cartoon look
 */
export const HOUSE_STYLE =
  'Stylized cartoon game art, like a polished casual or mobile game: clean simplified shapes, bold readable silhouettes, slightly exaggerated proportions, simple cel or soft-gradient shading, a saturated harmonious palette. Not photorealistic, not hyperrealistic, no photographic textures, no film grain.';
/** The house look of pixel art: a modern, polished pixel-art game, big readable sprites, crisp pixels */
// In sentences that say what to make, not what to avoid (Google's guidance for its image models; docs/research/pixel-art-craft-2026-10.md § 5)
export const PIXEL_STYLE =
  'Polished modern pixel art for a 2D game, like the best pixel-art games of today. Every pixel is a crisp, equal, square block on one grid, with hard edges everywhere. A small palette of flat colours: each material is shaded in 3–4 hue-shifted steps, the shadows turning cool toward violet and the lights warm toward yellow, from one light at the upper left. A clean 1-pixel dark outline runs around the outside of the shape. Big, readable silhouettes with simple shapes; colour areas in clusters, each step a flat fill; dithering only on large soft areas.';
const houseOf = (art: ArtSpec) => (art.technique === 'pixel' ? PIXEL_STYLE : HOUSE_STYLE);
const gridLine = (art: ArtSpec, a: ArtAsset) => {
  if (art.technique !== 'pixel') return [];
  const [w, h] = targetSize(a);
  return [`Drawn on a ${w}×${h} pixel grid (every pixel a large crisp square, the subject filling the grid as it would in the game)${art.palette?.length ? `, only these colours: ${art.palette.join(' ')}` : ''}.`];
};

/** Words that pull a pixel-art request toward painted blends (W_ART_PIXEL_BLEND) */
export const PIXEL_BLEND_WORDS = /\b(smooth(ly)? shad(ed|ing)|soft shad(ed|ing)|gradients?|soft (light|lighting|focus)|depth of field|bokeh|3d render(ed)?|airbrush(ed)?|blurr?(y|ed)?|painterly|anti-?alias(ed|ing)?)\b/i;

/** Words that pull an image model toward photorealism: the style is warned about them (W_ART_REALISTIC) */
export const REALISM_WORDS = /\b(photo-?realistic|photo-?real|hyper-?realistic|hyper-?real|realistic|realism|photograph(ic|y)?|photo|8k|4k|unreal engine|octane|ray-?traced|cinematic lighting|lifelike|true to life|dslr)\b/i;

/** The game design's constraints on the look, sent with every request */
export const keepLine = (art: ArtSpec): string[] => (art.keep?.length ? [`Keep the game's identity and what its play needs from the art: ${art.keep.join('; ')}.`] : []);

/** What the model is asked for one asset */
export function assetPrompt(art: ArtSpec, a: ArtAsset, withStyle: boolean): string {
  const lines = [`Game art for a browser game. ${houseOf(art)}`, `This game's look: ${art.style}.`, ...keepLine(art), ...gridLine(art, a), `Subject: ${a.prompt}.`];
  if (cutout(a.kind))
    lines.push(
      `One single subject, centred and fully in frame with a small margin, on a perfectly flat pure green (${CHROMA}) background.`,
      'No ground, no cast shadow on the background, no border, no text, no watermark. Use no green in the subject itself.',
    );
  else if (a.kind === 'tile') lines.push('A seamless tileable texture, edge to edge, seen from straight above. No text, no border, no watermark.');
  else if (a.kind === 'keyart')
    lines.push(
      'Key art for the game\'s cover: the main character big and close in a moment of the action, one clear focal point, strong contrast and a readable silhouette even as a small thumbnail; full-bleed, no border.',
      'Leave the top third calmer: the title is lettered there later. No text, no letters, no logo, no UI, no watermark.',
    );
  else lines.push('A full-bleed game background that fills the whole frame: no characters in front, no text, no UI, no watermark. Keep the middle calmer, where the play happens.');
  if (withStyle) lines.push('Match the attached style reference exactly: the same rendering, light direction, palette and line quality.');
  const hero = heroOf(art);
  if (a.kind === 'keyart' && hero) lines.push(`The main character is the one in the second reference image (${hero.prompt}): the same design, colours and proportions.`);
  return lines.join('\n');
}

/** What the model is asked to redraw an existing sprite: the same design, at the new size, with more detail */
export function redrawPrompt(art: ArtSpec, a: ArtAsset): string {
  const [w, h] = targetSize(a);
  return [
    `Game art for a browser game. ${houseOf(art)}`,
    `This game's look: ${art.style}.`,
    ...keepLine(art),
    `Redraw the first reference image — ${a.prompt} — as the same design at ${w}×${h} pixels: exactly the same character or object, the same shapes, proportions, pose, colours, outline and facing, the same personality. Only the detail grows: smoother curves, more shading steps, small highlights and textures where the old pixels were too few. Do not change, add or remove anything of the design.`,
    ...(cutout(a.kind) ? [`One single subject, centred and fully in frame with a small margin, on a perfectly flat pure green (${CHROMA}) background. No ground, no shadow on the background, no text, no watermark.`] : ['Edge to edge, seamless if it is a tile. No text, no watermark.']),
  ].join('\n');
}

/** An image enlarged with whole pixels (a 16 px sprite as a reference the model can read) */
async function enlarged(png: Buffer, page: Page, min = 512): Promise<Buffer> {
  const url = await page.evaluate(async ({ src, min }) => {
    const img = new Image();
    img.src = src;
    await img.decode();
    const k = Math.max(1, Math.floor(min / Math.max(img.width, img.height)));
    const c = document.createElement('canvas');
    c.width = img.width * k;
    c.height = img.height * k;
    const g = c.getContext('2d')!;
    g.imageSmoothingEnabled = false;
    g.fillStyle = '#00ff00';
    g.fillRect(0, 0, c.width, c.height);
    g.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/png').split(',')[1]!;
  }, { src: `data:image/png;base64,${png.toString('base64')}`, min });
  return Buffer.from(url, 'base64');
}

/** What the model is asked for one frame of a sprite's animation: the sprite attached, one pose changed */
export function framePrompt(art: ArtSpec, a: ArtAsset, pose: string): string {
  return [
    `Game art for a browser game. ${houseOf(art)}`,
    `This game's look: ${art.style}.`,
    ...keepLine(art),
    ...gridLine(art, a),
    `An animation frame of the character in the first reference image (${a.prompt}): exactly the same character — the same design, colours, proportions, outline and size in the frame, the same view and facing. Only the pose changes: ${pose}.`,
    `One single subject, centred and fully in frame with a small margin, on a perfectly flat pure green (${CHROMA}) background, framed like the reference.`,
    'No ground, no cast shadow on the background, no motion lines, no border, no text, no watermark. Use no green in the subject itself.',
    'Match the attached style reference exactly: the same rendering, light direction, palette and line quality.',
  ].join('\n');
}

/** The style board every asset is made against */
export function stylePrompt(art: ArtSpec): string {
  return [
    `A style board for a browser game. ${houseOf(art)}`,
    `This game's look: ${art.style}.`,
    ...keepLine(art),
    `On one sheet: the main character (${art.assets.find((a) => a.kind === 'sprite')?.prompt ?? 'the hero'}), one prop, one ground tile and a strip of background, side by side.`,
    'Even light on a neutral grey backdrop. No text, no labels, no watermark.',
  ].join('\n');
}

// --- Providers -------------------------------------------------------------------------------------------------------

export interface ImageRequest {
  model: string;
  prompt: string;
  aspect: string;
  /** Reference images (PNG or WebP) sent along: the style board */
  refs: { mime: string; data: Buffer }[];
  /** For the mock: what to draw */
  kind: ArtKind | 'style';
  seed: string;
  /** For the svg provider: the drawing to render (art/<file>.svg next to game.yaml) and the others of the set (the style board) */
  source?: string;
  sources?: string[];
}
type Page = import('playwright').Page;
export type ImageProvider = (req: ImageRequest, page: Page) => Promise<Buffer>;

/**
 * The Gemini API (generateContent with an IMAGE response). The request runs in a child node with NODE_USE_ENV_PROXY=1,
 * so a proxy in HTTPS_PROXY is used. The key: GEMINI_API_KEY (or GOOGLE_API_KEY) in the environment, or none at all when
 * the network adds it (a cloud environment's network secret: header x-goog-api-key for generativelanguage.googleapis.com)
 */
export const geminiProvider: ImageProvider = async (req) => {
  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '';
  const body = JSON.stringify({
    contents: [{ role: 'user', parts: [{ text: req.prompt }, ...req.refs.map((r) => ({ inlineData: { mimeType: r.mime, data: r.data.toString('base64') } }))] }],
    generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio: req.aspect } },
  });
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(req.model)}:generateContent`;
  const script = `let b='';process.stdin.on('data',(d)=>(b+=d)).on('end',async()=>{try{const r=await fetch(${JSON.stringify(url)},{method:'POST',headers:Object.assign({'content-type':'application/json'},process.env.GP_ART_KEY?{'x-goog-api-key':process.env.GP_ART_KEY}:{}),body:b});process.stdout.write(JSON.stringify({status:r.status,text:await r.text()}))}catch(e){process.stdout.write(JSON.stringify({status:0,text:String(e)}))}})`;
  for (let attempt = 0; ; attempt++) {
    const raw = execFileSync(process.execPath, ['-e', script], { input: body, env: { ...process.env, GP_ART_KEY: key, NODE_USE_ENV_PROXY: '1', NODE_NO_WARNINGS: '1' }, maxBuffer: 64 * 1024 * 1024 }).toString();
    const { status, text } = JSON.parse(raw) as { status: number; text: string };
    // A short rate limit is waited out (the server says how long); a quota that is empty for the day, or 0 on the free tier, is not
    const wait = status === 429 ? retryDelaySec(text) : status >= 500 || status === 0 ? 4 * (attempt + 1) : null;
    if (wait !== null && wait <= 60 && !freeTierBlocked(text) && attempt < 2) {
      await new Promise((r) => setTimeout(r, wait * 1000));
      continue;
    }
    let json: { error?: { message?: string }; candidates?: { finishReason?: string; content?: { parts?: { inlineData?: { data: string }; text?: string }[] } }[]; promptFeedback?: { blockReason?: string } } = {};
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error(`Gemini API ${status}: ${text.slice(0, 300)}`);
    }
    if (status === 429) throw new Error(quotaMessage(json.error?.message ?? text, text));
    if (!key && (status === 401 || status === 403))
      throw new Error(`Gemini API ${status}: no key reached it. Add GEMINI_API_KEY to the environment, or a network secret: header x-goog-api-key for generativelanguage.googleapis.com (key from aistudio.google.com → Get API key); a new session picks it up`);
    if (status !== 200) throw new Error(`Gemini API ${status}: ${json.error?.message ?? text.slice(0, 300)}`);
    const parts = json.candidates?.[0]?.content?.parts ?? [];
    const img = parts.find((p) => p.inlineData?.data);
    if (!img) throw new Error(`Gemini API returned no image (${json.promptFeedback?.blockReason ?? json.candidates?.[0]?.finishReason ?? 'no reason'}${parts.find((p) => p.text) ? `: ${parts.find((p) => p.text)!.text!.slice(0, 200)}` : ''})`);
    return Buffer.from(img.inlineData!.data, 'base64');
  }
};

/** The free tier has no image quota (limit 0): only billing on the key's project opens it */
export function freeTierBlocked(body: string): boolean {
  return /free_tier/i.test(body) && /limit:\s*0\b|"quotaValue":\s*"0"/.test(body);
}
/** RetryInfo.retryDelay of a 429 ("17s", "1.5s"), in seconds; 10 s when it gives none */
export function retryDelaySec(body: string): number {
  const m = body.match(/"retryDelay":\s*"([\d.]+)s"/);
  return m ? Math.ceil(Number(m[1])) : 10;
}
/** What a 429 means for the person running gp art */
export function quotaMessage(message: string, body: string): string {
  if (freeTierBlocked(body))
    return 'Gemini API 429: this key is on the free tier, which has no quota for the image models (limit 0). Turn on billing for its project: aistudio.google.com → Get API key → Set up billing (a Google Cloud billing account; the key stays the same). A Gemini app subscription (Gemini Pro, Google AI Pro) does not pay for the API.';
  return `Gemini API 429: ${message.split('\n')[0]} — the quota is used up for now (retry in ${retryDelaySec(body)} s, or see ai.dev/rate-limit for the key's tier).`;
}

/** Several images side by side on a grey sheet (the style board of a set taken from existing images) */
async function sheetOf(pngs: Buffer[], page: Page): Promise<Buffer> {
  const url = await page.evaluate(async (srcs) => {
    const W = 1024, H = 576, c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const g = c.getContext('2d')!;
    g.imageSmoothingEnabled = false;
    g.fillStyle = '#8a8a8a';
    g.fillRect(0, 0, W, H);
    const n = Math.max(1, srcs.length), cols = Math.ceil(Math.sqrt(n * (W / H))), rows = Math.ceil(n / cols), cw = W / cols, ch = H / rows;
    for (const [i, s] of srcs.entries()) {
      const img = new Image();
      img.src = s;
      await img.decode();
      const k = Math.max(1, Math.floor(Math.min((cw * 0.85) / img.width, (ch * 0.85) / img.height)));
      g.drawImage(img, Math.round((i % cols) * cw + (cw - img.width * k) / 2), Math.round(Math.floor(i / cols) * ch + (ch - img.height * k) / 2), img.width * k, img.height * k);
    }
    return c.toDataURL('image/png').split(',')[1]!;
  }, pngs.map((b) => `data:image/png;base64,${b.toString('base64')}`));
  return Buffer.from(url, 'base64');
}

/** No network: a seeded placeholder in the request's layout (a subject on the key colour, or a full-bleed scene) — for tests and dry runs */
export const mockProvider: ImageProvider = async (req, page) => {
  const png = await page.evaluate(
    ({ kind, seed, chroma, aspect }) => {
      let h = 2166136261;
      for (const c of seed) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
      const rnd = () => ((h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0) / 4294967296);
      const [aw, ah] = aspect.split(':').map(Number) as [number, number];
      const W = 512, H = Math.round((512 * ah) / aw);
      const c = document.createElement('canvas');
      c.width = W;
      c.height = H;
      const g = c.getContext('2d')!;
      // Never green: the subject would collide with the key, as the prompt tells a real model
      const hue = (170 + Math.floor(rnd() * 240)) % 360;
      if (kind === 'sprite' || kind === 'ui' || kind === 'icon') {
        g.fillStyle = chroma;
        g.fillRect(0, 0, W, H);
        const r = W * (0.22 + rnd() * 0.12);
        const grad = g.createRadialGradient(W / 2 - r / 3, H / 2 - r / 3, r / 8, W / 2, H / 2, r);
        grad.addColorStop(0, `hsl(${hue} 80% 75%)`);
        grad.addColorStop(1, `hsl(${(hue + 40) % 360} 70% 35%)`);
        g.fillStyle = grad;
        g.beginPath();
        g.ellipse(W / 2, H / 2, r, r * (0.8 + rnd() * 0.3), 0, 0, Math.PI * 2);
        g.fill();
      } else {
        const grad = g.createLinearGradient(0, 0, 0, H);
        grad.addColorStop(0, `hsl(${hue} 50% 20%)`);
        grad.addColorStop(1, `hsl(${(hue + 60) % 360} 60% 45%)`);
        g.fillStyle = grad;
        g.fillRect(0, 0, W, H);
        for (let i = 0; i < 6; i++) {
          g.fillStyle = `hsl(${(hue + i * 25) % 360} 40% ${30 + i * 6}% / 0.6)`;
          g.beginPath();
          g.arc(rnd() * W, H * (0.6 + rnd() * 0.4), W * (0.1 + rnd() * 0.2), 0, Math.PI * 2);
          g.fill();
        }
      }
      return c.toDataURL('image/png').split(',')[1]!;
    },
    { kind: req.kind, seed: req.seed, chroma: CHROMA, aspect: req.aspect },
  );
  return Buffer.from(png, 'base64');
};

/** The folder of the game's own drawings for the svg provider: art/<id>.svg, art/<id>-<n>.svg for frames */
export const ART_SRC_DIR = 'art';
/** Raw size the svg provider renders at (the long side): what a model returns, so frames and scales work the same */
const SVG_RAW = 1024;

/**
 * No key, no model: the game's agent draws each asset as a cartoon SVG (art/<id>.svg — bold outlines, flat cel shading,
 * a rim light; docs/guides/art.md § 5) and this renders it in the browser at the asset's aspect. Sprites keep the SVG's
 * own transparency (no key colour). The style board is the set itself, side by side.
 */
export const svgProvider: ImageProvider = async (req, page) => {
  const read = (f: string) => {
    if (!existsSync(f)) throw new Error(`no drawing ${f.replace(/^.*[\\/](art[\\/])/, '$1')}: the svg provider renders the game's own SVGs — draw it (a cartoon SVG with a viewBox, transparent around a sprite), then run gp art --provider svg again`);
    return readFileSync(f, 'utf8');
  };
  const [aw, ah] = req.aspect.split(':').map(Number) as [number, number];
  const W = aw >= ah ? SVG_RAW : Math.round((SVG_RAW * aw) / ah);
  const H = aw >= ah ? Math.round((SVG_RAW * ah) / aw) : SVG_RAW;
  const svgs = req.kind === 'style' ? (req.sources ?? []).filter(existsSync).map(read) : [read(req.source!)];
  const png = await page.evaluate(
    async ({ svgs, W, H, board }) => {
      const c = document.createElement('canvas');
      c.width = W;
      c.height = H;
      const g = c.getContext('2d')!;
      // The drawing's own size from its viewBox (or width/height), then rasterized at the size it is drawn: crisp vectors
      const parse = (svg: string) => {
        const doc = new DOMParser().parseFromString(svg, 'image/svg+xml');
        const el = doc.documentElement;
        const vb = (el.getAttribute('viewBox') ?? '').split(/[\s,]+/).map(Number);
        const vw = vb.length === 4 && vb[2]! > 0 ? vb[2]! : parseFloat(el.getAttribute('width') ?? '') || 512;
        const vh = vb.length === 4 && vb[3]! > 0 ? vb[3]! : parseFloat(el.getAttribute('height') ?? '') || 512;
        if (!el.getAttribute('viewBox')) el.setAttribute('viewBox', `0 0 ${vw} ${vh}`);
        return { el, vw, vh };
      };
      const draw = async (svg: string, x: number, y: number, bw: number, bh: number) => {
        const { el, vw, vh } = parse(svg);
        const s = Math.min(bw / vw, bh / vh);
        const dw = Math.max(1, Math.round(vw * s)), dh = Math.max(1, Math.round(vh * s));
        el.setAttribute('width', String(dw));
        el.setAttribute('height', String(dh));
        const img = new Image();
        img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(new XMLSerializer().serializeToString(el))}`;
        await img.decode();
        g.drawImage(img, x + (bw - dw) / 2, y + (bh - dh) / 2, dw, dh);
      };
      if (board) {
        g.fillStyle = '#8a8a8a';
        g.fillRect(0, 0, W, H);
        const n = Math.max(1, svgs.length), cols = Math.ceil(Math.sqrt(n * (W / H))), rows = Math.ceil(n / cols);
        const cw = W / cols, ch = H / rows;
        for (const [i, svg] of svgs.entries()) await draw(svg, (i % cols) * cw + cw * 0.05, Math.floor(i / cols) * ch + ch * 0.05, cw * 0.9, ch * 0.9);
      } else {
        // Contained in the frame, as a model frames its subject; an opaque asset's SVG is drawn at the asset's aspect
        await draw(svgs[0]!, 0, 0, W, H);
      }
      return c.toDataURL('image/png').split(',')[1]!;
    },
    { svgs, W, H, board: req.kind === 'style' },
  );
  return Buffer.from(png, 'base64');
};

/** Where `gp assets get` keeps what it downloads, next to game.yaml */
export const ASSETS_SRC_DIR = 'assets-src';

/** An existing image (asset `from`): read, the `cut` taken, mirrored if asked, as PNG — then adapted like a model's image */
async function fromImage(loc: GameLocation, a: ArtAsset, page: Page): Promise<Buffer> {
  const file = await localSource(loc, a.from!);
  const png = await page.evaluate(
    async ({ src, cut, flip }) => {
      const img = new Image();
      img.src = src;
      await img.decode();
      const [x, y, w, h] = cut ?? [0, 0, img.naturalWidth, img.naturalHeight];
      const c = document.createElement('canvas');
      c.width = w;
      c.height = h;
      const g = c.getContext('2d')!;
      g.imageSmoothingEnabled = false;
      if (flip) {
        g.translate(w, 0);
        g.scale(-1, 1);
      }
      g.drawImage(img, x, y, w, h, 0, 0, w, h);
      return c.toDataURL('image/png').split(',')[1]!;
    },
    { src: `data:image/${file.endsWith('.png') ? 'png' : file.endsWith('.gif') ? 'gif' : file.endsWith('.webp') ? 'webp' : 'jpeg'};base64,${readFileSync(file).toString('base64')}`, cut: a.cut ?? null, flip: !!a.flip },
  );
  return Buffer.from(png, 'base64');
}

/** A `from` as a file on disk: a path in the game's folder, or a URL downloaded once into assets-src/ */
export async function localSource(loc: GameLocation, from: string): Promise<string> {
  if (!/^https?:\/\//.test(from)) {
    const f = join(loc.dir, from);
    if (!existsSync(f)) throw new Error(`art: no image ${from} (the asset's \`from\`, relative to game.yaml) — gp assets get <url> downloads one into ${ASSETS_SRC_DIR}/`);
    return f;
  }
  const dir = join(loc.dir, ASSETS_SRC_DIR);
  mkdirSync(dir, { recursive: true });
  const f = join(dir, decodeURIComponent(new URL(from).pathname.split('/').pop() || 'image.png'));
  if (!existsSync(f)) writeFileSync(f, await download(from));
  return f;
}

/** A URL's bytes, through the environment's proxy (a child node with NODE_USE_ENV_PROXY=1, as the Gemini provider) */
export async function download(url: string): Promise<Buffer> {
  const script = `fetch(${JSON.stringify(url)}).then(async (r) => { if (!r.ok) { process.stderr.write('HTTP ' + r.status); process.exit(2); } process.stdout.write(Buffer.from(await r.arrayBuffer())); }).catch((e) => { process.stderr.write(String(e)); process.exit(3); })`;
  try {
    return execFileSync(process.execPath, ['-e', script], { env: { ...process.env, NODE_USE_ENV_PROXY: '1', NODE_NO_WARNINGS: '1' }, maxBuffer: 512 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] });
  } catch (e) {
    const err = String((e as { stderr?: Buffer }).stderr ?? e);
    throw new Error(`can't download ${url}: ${err.slice(0, 200)}${/403|tunnel|ENOTFOUND|EAI_AGAIN/.test(err) ? ` — the environment's network may not allow ${new URL(url).host}: add it to the cloud environment's allowed domains` : ''}`);
  }
}

export const PROVIDERS: Record<string, ImageProvider> = { gemini: geminiProvider, mock: mockProvider, svg: svgProvider };
/** Providers whose images carry their own transparency: sprites are trimmed, not keyed */
const UNKEYED = new Set(['svg']);
/** What provenance.yaml records as the model, per provider */
const madeBy = (provider: string, model: string) => (provider === 'svg' ? 'svg (drawn by the game\'s agent)' : provider === 'mock' ? 'mock' : model);

// --- Post-processing (in the browser) --------------------------------------------------------------------------------

export interface Processed {
  webp: Buffer;
  size: [number, number];
  /** Output px per input px (cut-outs) */
  scale: number;
  /** Cut-outs: the share of the frame cut to transparency, and whether the corners are clear (the key worked) */
  transparent: number;
  cornersClear: boolean;
}

/** Cut out (sprites), trim, fit and encode one image as WebP */
export async function processImage(page: Page, png: Buffer, kind: ArtKind | 'style', size: [number, number], quality = 0.86, fixedScale?: number, keyed = true, pixel?: { palette: string[]; raw?: boolean }): Promise<Processed> {
  // A model's pixel-art sprite: its own block grid read back (depixelize) instead of cells of our size cut across it
  if (pixel && pixel.raw === undefined && !fixedScale && cutout(kind)) {
    const d = await depixelized(page, png, kind, size, keyed, pixel.palette);
    if (d) return d;
    pixel = { ...pixel, raw: false };
  }
  const r = await page.evaluate(
    async ({ src, cut, keyed, opaque, w, h, quality, fixedScale, pixel }) => {
      const img = new Image();
      img.src = src;
      await img.decode();
      let c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      let g = c.getContext('2d', { willReadFrequently: true })!;
      g.drawImage(img, 0, 0);
      let transparent = 0;
      let cornersClear = true;
      if (cut) {
        const d = g.getImageData(0, 0, c.width, c.height);
        const px = d.data;
        // A drawing with its own transparency (an SVG) is only trimmed; a model's image is keyed out first
        if (keyed) {
        // The key is the corners' colour (median of four 6×6 patches): models drift off the asked green
        const samples: number[][] = [];
        for (const [x0, y0] of [[0, 0], [c.width - 6, 0], [0, c.height - 6], [c.width - 6, c.height - 6]] as const)
          for (let y = y0; y < y0 + 6; y++) for (let x = x0; x < x0 + 6; x++) { const i = (y * c.width + x) * 4; samples.push([px[i]!, px[i + 1]!, px[i + 2]!]); }
        const med = (k: number) => samples.map((s) => s[k]!).sort((a, b) => a - b)[samples.length >> 1]!;
        const key = [med(0), med(1), med(2)] as const;
        const lo = 48, hi = 120;
        for (let i = 0; i < px.length; i += 4) {
          const dr = px[i]! - key[0], dg = px[i + 1]! - key[1], db = px[i + 2]! - key[2];
          const dist = Math.sqrt(dr * dr + dg * dg + db * db);
          const t = Math.min(1, Math.max(0, (dist - lo) / (hi - lo)));
          const a = t * t * (3 - 2 * t);
          if (a < 1) {
            // Despill: the key's tint on the soft edge (green fringe) pulled back to the other channels
            const strongest = key[1] >= key[0] && key[1] >= key[2] ? 1 : key[0] >= key[2] ? 0 : 2;
            const others = [0, 1, 2].filter((k) => k !== strongest).map((k) => px[i + k]!);
            px[i + strongest] = Math.min(px[i + strongest]!, Math.max(...others));
          }
          px[i + 3] = Math.round(px[i + 3]! * a);
          if (px[i + 3]! < 8) transparent++;
        }
        transparent /= px.length / 4;
        const alphaAt = (x: number, y: number) => px[(y * c.width + x) * 4 + 3]!;
        cornersClear = [alphaAt(1, 1), alphaAt(c.width - 2, 1), alphaAt(1, c.height - 2), alphaAt(c.width - 2, c.height - 2)].every((a) => a < 8);
        g.putImageData(d, 0, 0);
        } else {
          for (let i = 3; i < px.length; i += 4) if (px[i]! < 8) transparent++;
          transparent /= px.length / 4;
        }
        // Trim to what is left, with a 2 px margin
        let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1;
        for (let y = 0; y < c.height; y++)
          for (let x = 0; x < c.width; x++)
            if (px[(y * c.width + x) * 4 + 3]! >= 16) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
        if (x1 >= 0) {
          const m = pixel ? 0 : 2;
          x0 = Math.max(0, x0 - m); y0 = Math.max(0, y0 - m); x1 = Math.min(c.width - 1, x1 + m); y1 = Math.min(c.height - 1, y1 + m);
          const t = document.createElement('canvas');
          t.width = x1 - x0 + 1;
          t.height = y1 - y0 + 1;
          t.getContext('2d')!.drawImage(c, x0, y0, t.width, t.height, 0, 0, t.width, t.height);
          c = t;
        }
      }
      // Fit: cut-outs into the bound (never enlarged), opaque art cropped to fill w×h
      let ow: number, oh: number, sx = 0, sy = 0, sw = c.width, sh = c.height, scale = 1;
      if (opaque) {
        ow = w;
        oh = h;
        const s = Math.max(w / c.width, h / c.height);
        sw = w / s;
        sh = h / s;
        sx = (c.width - sw) / 2;
        sy = (c.height - sh) / 2;
      } else {
        // A frame keeps its sprite's scale (the character the same size whatever the pose), within twice the bound
        // Pixel art shrinks by a whole factor only (a pack's 32 px sprite stays pixel for pixel; a model's 1024 px picture → its grid)
        const fit = Math.min(1, w / c.width, h / c.height);
        const s = fixedScale ? Math.min(fixedScale, (2 * w) / c.width, (2 * h) / c.height) : pixel && fit < 1 ? 1 / Math.ceil(1 / fit - 1e-9) : fit;
        scale = s;
        ow = Math.max(1, Math.round(c.width * s));
        oh = Math.max(1, Math.round(c.height * s));
      }
      const o = document.createElement('canvas');
      o.width = ow;
      o.height = oh;
      g = o.getContext('2d')!;
      if (pixel && pixel.raw) return { webp: c.toDataURL('image/png').split(',')[1]!, w: c.width, h: c.height, transparent, cornersClear, scale: 1 };
      if (pixel) {
        // Pixel art: each output pixel is the most common colour of its cell in the source, snapped to the game's palette;
        // a cell is opaque when most of it is — no blended edge, no colour the palette doesn't have
        const pal = pixel.palette.map((hex) => { const v = parseInt(hex.replace('#', '').padEnd(6, '0').slice(0, 6), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255] as const; });
        const sd = c.getContext('2d', { willReadFrequently: true })!.getImageData(0, 0, c.width, c.height).data;
        const od = g.createImageData(ow, oh);
        const nearest = (r: number, gg: number, b: number) => {
          let best = 0, bd = Infinity;
          for (let i = 0; i < pal.length; i++) { const [pr, pg, pb] = pal[i]!; const dr = r - pr, dg = gg - pg, db = b - pb; const d = 2 * dr * dr + 4 * dg * dg + 3 * db * db; if (d < bd) { bd = d; best = i; } }
          return best;
        };
        for (let oy = 0; oy < oh; oy++)
          for (let ox = 0; ox < ow; ox++) {
            const x0 = Math.floor(sx + (ox * sw) / ow), x1 = Math.max(x0 + 1, Math.floor(sx + ((ox + 1) * sw) / ow));
            const y0 = Math.floor(sy + (oy * sh) / oh), y1 = Math.max(y0 + 1, Math.floor(sy + ((oy + 1) * sh) / oh));
            const votes = new Map<number, number>();
            let solid = 0, all = 0;
            for (let y = y0; y < y1; y++)
              for (let x = x0; x < x1; x++) {
                if (x < 0 || y < 0 || x >= c.width || y >= c.height) continue;
                const i = (y * c.width + x) * 4;
                all++;
                // A half-transparent pixel (a pack's soft shadow, smoke) is not a pixel of the sprite: the code draws shadows and light
                if (sd[i + 3]! < 200) continue;
                solid++;
                const k = pal.length ? nearest(sd[i]!, sd[i + 1]!, sd[i + 2]!) : ((sd[i]! >> 4) << 8) | ((sd[i + 1]! >> 4) << 4) | (sd[i + 2]! >> 4);
                votes.set(k, (votes.get(k) ?? 0) + 1);
              }
            const j = (oy * ow + ox) * 4;
            if (!all || solid * 2 < all) continue;
            const k = [...votes.entries()].sort((a, b) => b[1] - a[1])[0]![0];
            const [r, gg, b] = pal.length ? pal[k]! : [((k >> 8) & 15) * 17, ((k >> 4) & 15) * 17, (k & 15) * 17];
            od.data[j] = r; od.data[j + 1] = gg; od.data[j + 2] = b; od.data[j + 3] = 255;
          }
        g.putImageData(od, 0, 0);
        return { webp: o.toDataURL('image/png').split(',')[1]!, w: ow, h: oh, transparent, cornersClear, scale };
      }
      g.imageSmoothingQuality = 'high';
      g.drawImage(c, sx, sy, sw, sh, 0, 0, ow, oh);
      return { webp: o.toDataURL('image/webp', quality).split(',')[1]!, w: ow, h: oh, transparent, cornersClear, scale };
    },
    { src: `data:image/png;base64,${png.toString('base64')}`, cut: cutout(kind), keyed, opaque: opaqueFill(kind), w: size[0], h: size[1], quality, fixedScale: fixedScale ?? 0, pixel: pixel ?? null },
  );
  return { webp: Buffer.from(r.webp, 'base64'), size: [r.w, r.h], scale: r.scale, transparent: r.transparent, cornersClear: r.cornersClear };
}

/**
 * A model draws pixel art as blocks of its own pitch (a 1024 px picture of 21.3 px blocks is a 48 px sprite), which
 * cells of the asked size cut across — doubled and lost pixels. Keyed and trimmed in the page as usual, then the block
 * grid is found and each block read from its middle (@gp/art/pixel depixelize), snapped to the palette and cleaned;
 * kept at the model's own grid when it is within a quarter of the asked size, else shrunk by a whole factor. Null when
 * no block grid is found (the caller cuts cells as before).
 */
async function depixelized(page: Page, png: Buffer, kind: ArtKind | 'style', size: [number, number], keyed: boolean, palette: string[]): Promise<(Processed & { pitch: number }) | null> {
  const { decodePng, encodePng } = await import('./pixel.ts');
  const px = await import('../../art/src/pixel.ts');
  const r = await processImage(page, png, kind, size, 0.86, undefined, keyed, { palette, raw: true }).catch(() => null);
  if (!r) return null;
  const im = decodePng(r.webp);
  if (im.w < size[0] * 2 && im.h < size[1] * 2) return null;
  const d = px.depixelize(im, { palette });
  if (!d.found || !d.art.w) return null;
  let a = d.art;
  if (a.w > size[0] * 1.25 || a.h > size[1] * 1.25) a = px.pixelTrim(px.pixelDownscale(a, Math.ceil(Math.max(a.w / size[0], a.h / size[1]) - 1e-9))).art;
  return { webp: encodePng(px.pixelToRgba(a)), size: [a.w, a.h], scale: a.w / im.w, transparent: r.transparent, cornersClear: r.cornersClear, pitch: d.pitch };
}

// --- The run ---------------------------------------------------------------------------------------------------------

export const assetsDir = (loc: GameLocation) => join(loc.dir, ASSETS_DIR);
const rawDir = (loc: GameLocation) => join(loc.dir, 'qa', 'art-raw');

export function loadProvenance(loc: GameLocation): Provenance {
  const f = join(assetsDir(loc), PROVENANCE_FILE);
  if (!existsSync(f)) return { terms: TERMS, files: {} };
  const p = (parse(readFileSync(f, 'utf8')) ?? {}) as Partial<Provenance>;
  return { terms: p.terms ?? TERMS, files: p.files ?? {} };
}

export function writeProvenance(loc: GameLocation, p: Provenance) {
  const head =
    '# Written by gp art: what made each image in this folder (docs/guides/art.md#5-generated-art-gp-art). gp validate checks the\n' +
    '# hashes; after editing a file by hand run `gp art --record`. `source: owner`: the owner\'s picture (gp art import). The model\'s terms: Google claims no ownership of the outputs,\n' +
    '# which are not exclusive (similar images may be made for others), and every image carries an invisible SynthID watermark.\n';
  writeFileSync(join(assetsDir(loc), PROVENANCE_FILE), head + stringify({ terms: p.terms, files: p.files }, { lineWidth: 0 }));
}

/** The later chapters' low-res thumbnails (bundled before Play: a placeholder until the image is decoded) */
export const THUMBS_DIR = 'thumbs';
/** A thumbnail's long side, px */
export const THUMB_PX = 32;
export const thumbFile = (id: string) => `${THUMBS_DIR}/${id}.webp`;

/** An asset's chapter: its own, or its sprite's for a part (a car's wheels load with the car); 0 by default */
export function assetChapter(art: Pick<ArtSpec, 'assets'>, a: ArtAsset, seen = new Set<string>()): number {
  if (typeof a.chapter === 'number') return Math.max(0, Math.floor(a.chapter));
  if (!a.part || seen.has(a.id)) return 0;
  seen.add(a.id);
  const of = art.assets.find((x) => x.id === a.part!.of);
  return of ? assetChapter(art, of, seen) : 0;
}

/** What assets/index.ts says of a later chapter's image besides its import: its size (the placeholder's) and its thumbnail */
export interface IndexInfo {
  size(file: string): readonly [number, number] | undefined;
  thumb(id: string): boolean;
}

/** assets/index.ts as the files on disk make it: sizes from provenance.yaml, the thumbnails that exist */
export function indexFor(loc: GameLocation, art: ArtSpec): string {
  const prov = loadProvenance(loc);
  return indexSource(art, { size: (f) => prov.files[f]?.size, thumb: (id) => existsSync(join(assetsDir(loc), thumbFile(id))) });
}

const obj = (entries: string[]) => (entries.length ? `{ ${entries.join(', ')} }` : '{}');

/** assets/index.ts: the imports, ART.<camelCaseId> → the bundled URL (a data: URI in a one-file portal upload) */
export function indexSource(art: ArtSpec, info?: IndexInfo): string {
  const later = art.assets.filter((a) => assetChapter(art, a) > 0);
  const lines = [
    '// Written by gp art from game.yaml `art` — don\'t edit. The images and what made them: this folder, provenance.yaml.',
    later.length
      ? '// Chapters (art.assets[].chapter): chapter 0 is in the game\'s script, a later chapter loads after Play — `const assets = createAssets(ASSETS)`, `await assets.ready(0)` in start(), `assets.prefetch(1)` after Play, draw with `assets.draw` or `assets.img.<id>` (a placeholder until decoded) (@gp/art/assets).'
      : '// Load them before the first frame: `const img = await loadImages(ART)` (@gp/art/assets).',
    '',
  ];
  const ext = extOf(art);
  for (const a of art.assets) {
    const ch = assetChapter(art, a);
    const q = ch > 0 ? `?gp-chapter=${ch}` : '';
    lines.push(`import ${camel(a.id)} from './${a.id}.${ext}${q}';`);
    frameFiles(a, ext).forEach((f, i) => lines.push(`import ${camel(a.id)}F${i + 1} from './${f}${q}';`));
  }
  const thumbs = later.filter((a) => info?.thumb(a.id));
  for (const a of thumbs) lines.push(`import ${camel(a.id)}_thumb from './${thumbFile(a.id)}';`);
  lines.push('', `export const ART = { ${art.assets.map((a) => camel(a.id)).join(', ')} } as const;`, 'export type ArtId = keyof typeof ART;');
  const animated = art.assets.filter((a) => frameFiles(a).length);
  if (art.technique === 'pixel') lines.splice(2, 0, '// Pixel art at its own size: draw it with drawPixelSprite (@gp/art/assets) — whole-number scale, smoothing off.');
  if (animated.length)
    lines.push(
      '/** Each animated sprite\'s frames, in order: `const frames = await loadFrames(FRAMES)`, then `frameAt(frames.<id>, t, fps)` */',
      `export const FRAMES = { ${animated.map((a) => `${camel(a.id)}: [${frameFiles(a).map((_, i) => `${camel(a.id)}F${i + 1}`).join(', ')}]`).join(', ')} } as const;`,
    );
  const parts = art.assets.filter((a) => a.part);
  if (parts.length)
    lines.push(
      '/** Parts cut from a sprite (gp art import: wheels, paint masks): draw each with its centre at (x, y) of `of`, in that sprite\'s pixels */',
      `export const PARTS = { ${parts.map((a) => `${camel(a.id)}: { of: '${camel(a.part!.of)}', x: ${a.part!.at[0]}, y: ${a.part!.at[1]} }`).join(', ')} } as const;`,
    );
  if (later.length) {
    const sized = later.map((a) => [a, info?.size(`${a.id}.${ext}`)] as const).filter(([, s]) => s);
    lines.push(
      '/** The chapter of each image loaded after Play (the rest: chapter 0, in the game\'s script) */',
      `export const CHAPTERS = { ${later.map((a) => `${camel(a.id)}: ${assetChapter(art, a)}`).join(', ')} } as const;`,
      '/** Each later image\'s size in px: its placeholder\'s, before it is decoded */',
      `export const SIZES = ${obj(sized.map(([a, s]) => `${camel(a.id)}: [${s![0]}, ${s![1]}]`))} as const;`,
      `/** Each later image's ${THUMB_PX} px thumbnail (in the script, before Play): drawn in its place until it is decoded */`,
      `export const THUMBS = ${obj(thumbs.map((a) => `${camel(a.id)}: ${camel(a.id)}_thumb`))} as const;`,
      '/** Everything createAssets (@gp/art/assets) needs */',
      `export const ASSETS = { urls: ART, ${animated.length ? 'frames: FRAMES, ' : ''}chapters: CHAPTERS, sizes: SIZES, thumbs: THUMBS } as const;`,
    );
  }
  lines.push('');
  return lines.join('\n');
}

/**
 * The later chapters' thumbnails (assets/thumbs/<id>.webp, THUMB_PX on the long side): made from each image, again when
 * the image changed (provenance `from`: its sha256), removed when the asset is back in chapter 0 or gone
 */
export async function writeThumbs(loc: GameLocation, art: ArtSpec, page: Page, prov: Provenance, date: string): Promise<string[]> {
  const ext = extOf(art);
  const dir = assetsDir(loc);
  const made: string[] = [];
  const want = new Set<string>();
  for (const a of art.assets.filter((x) => assetChapter(art, x) > 0)) {
    const src = join(dir, `${a.id}.${ext}`);
    if (!existsSync(src)) continue;
    const file = thumbFile(a.id);
    want.add(file);
    const buf = readFileSync(src);
    const from = sha256(buf);
    if (existsSync(join(dir, file)) && prov.files[file]?.from === from) continue;
    const r = await page.evaluate(
      async ({ src, px }) => {
        const img = new Image();
        img.src = src;
        await img.decode();
        const k = Math.min(1, px / Math.max(img.naturalWidth, img.naturalHeight));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.naturalWidth * k));
        c.height = Math.max(1, Math.round(img.naturalHeight * k));
        const g = c.getContext('2d')!;
        g.imageSmoothingQuality = 'high';
        g.drawImage(img, 0, 0, c.width, c.height);
        return { b64: c.toDataURL('image/webp', 0.7).split(',')[1]!, w: c.width, h: c.height };
      },
      { src: `data:image/${ext};base64,${buf.toString('base64')}`, px: THUMB_PX },
    );
    mkdirSync(join(dir, THUMBS_DIR), { recursive: true });
    const out = Buffer.from(r.b64, 'base64');
    writeFileSync(join(dir, file), out);
    prov.files[file] = { kind: a.kind, model: 'thumbnail', prompt: `a ${THUMB_PX} px thumbnail of ${a.id}.${ext}: its placeholder until it is decoded (chapter ${assetChapter(art, a)})`, style: null, from, size: [r.w, r.h], bytes: out.length, sha256: sha256(out), date };
    made.push(file);
  }
  for (const f of Object.keys(prov.files).filter((f) => f.startsWith(`${THUMBS_DIR}/`) && !want.has(f))) {
    rmSync(join(dir, f), { force: true });
    delete prov.files[f];
  }
  return made;
}

/** The later chapters' images whose thumbnail isn't made yet (or was made from an older image) */
export function staleThumbs(loc: GameLocation, art: ArtSpec): string[] {
  const ext = extOf(art);
  const prov = loadProvenance(loc);
  return art.assets
    .filter((a) => assetChapter(art, a) > 0 && existsSync(join(assetsDir(loc), `${a.id}.${ext}`)))
    .filter((a) => !existsSync(join(assetsDir(loc), thumbFile(a.id))) || prov.files[thumbFile(a.id)]?.from !== sha256(readFileSync(join(assetsDir(loc), `${a.id}.${ext}`))))
    .map((a) => a.id);
}

export interface ArtRunOptions {
  provider?: string;
  /** Regenerate these ids even if they exist */
  only?: string[];
  force?: boolean;
  /** Make a new style board (and the assets made against the old one stay until --force) */
  style?: boolean;
  log?: (s: string) => void;
}
export interface ArtRunResult {
  made: string[];
  kept: string[];
  warnings: string[];
  costUSD: number;
}

export async function generateArt(loc: GameLocation, opts: ArtRunOptions = {}): Promise<ArtRunResult> {
  const art = artSpec(loc);
  if (!art) throw new Error('game.yaml has no `art` section with assets (gp explain art)');
  const providerName = opts.provider ?? process.env.GP_ART_PROVIDER ?? 'gemini';
  const provider = PROVIDERS[providerName];
  if (!provider) throw new Error(`Unknown provider "${providerName}": ${Object.keys(PROVIDERS).join(', ')}`);
  const model = art.model ?? DEFAULT_IMAGE_MODEL;
  const log = opts.log ?? (() => {});
  const dir = assetsDir(loc);
  mkdirSync(dir, { recursive: true });
  mkdirSync(rawDir(loc), { recursive: true });
  const prov = loadProvenance(loc);
  const res: ArtRunResult = { made: [], kept: [], warnings: [], costUSD: 0 };
  const price = providerName === 'gemini' ? (IMAGE_PRICE_USD[model] ?? 0.05) : 0;
  const keyed = !UNKEYED.has(providerName);
  const ext = extOf(art);
  const pixel = art.technique === 'pixel' ? { palette: art.palette ?? [] } : undefined;
  const by = madeBy(providerName, model);
  const srcDir = join(loc.dir, ART_SRC_DIR);
  const src = (name: string) => join(srcDir, `${name}.svg`);
  const srcHash = (name: string) => (existsSync(src(name)) ? sha256(readFileSync(src(name))) : undefined);
  // A drawing changed since its image was made is rendered again (the svg provider)
  const changed = (name: string, file: string) => providerName === 'svg' && srcHash(name) !== prov.files[file]?.source;
  const date = new Date().toISOString().slice(0, 10);

  const { chromium } = await import('playwright');
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  try {
    const page = await browser.newPage();
    await page.setContent('<body></body>');
    const stylePath = join(dir, STYLE_FILE);
    // The owner's pictures (source: import) are gp art import's: kept as they are, never sent to a model
    const generated = art.assets.filter((a) => !imported(a));
    for (const a of art.assets.filter(imported)) {
      if (existsSync(join(dir, `${a.id}.${ext}`))) res.kept.push(`${a.id}.${ext}`);
      else res.warnings.push(`${a.id}.${ext}: an imported picture (source: import) that isn't there — gp art import <dir> ${loc.id} makes it from the owner's file`);
    }
    const allFrom = generated.every((a) => a.from && !a.redraw);
    const boardSources = generated.map((a) => src(a.id));
    const boardHash = providerName === 'svg' ? sha256(Buffer.from(boardSources.map((f) => (existsSync(f) ? sha256(readFileSync(f)) : '')).join())) : undefined;
    if (generated.length && (opts.style || !existsSync(stylePath) || (providerName === 'svg' && !allFrom && prov.files[STYLE_FILE]?.source !== boardHash))) {
      const prompt = stylePrompt(art);
      log(`style board (${providerName === "mock" ? "mock" : model}) …`);
      const png = allFrom ? await sheetOf(await Promise.all(generated.map((a) => fromImage(loc, a, page))), page) : await provider({ model, prompt, aspect: '16:9', refs: [], kind: 'style', seed: `${loc.id}:style`, sources: boardSources }, page);
      writeFileSync(join(rawDir(loc), 'style.png'), png);
      const p = await processImage(page, png, 'style', [1024, 576], 0.9);
      writeFileSync(stylePath, p.webp);
      prov.files[STYLE_FILE] = { kind: 'style', model: allFrom ? 'the set itself' : by, prompt: allFrom || providerName === 'svg' ? 'the set itself, side by side' : prompt, style: null, size: p.size, bytes: p.webp.length, sha256: sha256(p.webp), date, ...(boardHash ? { source: boardHash } : {}) };
      res.made.push(STYLE_FILE);
      if (!allFrom) res.costUSD += price;
    }
    if (!generated.length) {
      res.made.push(...(await writeThumbs(loc, art, page, prov, date)));
      writeProvenance(loc, prov);
      writeFileSync(join(dir, 'index.ts'), indexFor(loc, art));
      return res;
    }
    const style = readFileSync(stylePath);
    const styleHash = sha256(style);
    const label = providerName === 'mock' ? 'mock' : model;
    const raw = (id: string): { mime: string; data: Buffer } | null => {
      // The model's own output (the subject on its key) is the better reference; the cut-out WebP when it is gone
      const png = join(rawDir(loc), `${id}.png`);
      if (existsSync(png)) return { mime: 'image/png', data: readFileSync(png) };
      const img = join(dir, `${id}.${ext}`);
      return existsSync(img) ? { mime: `image/${ext}`, data: readFileSync(img) } : null;
    };
    const hero = heroOf(art);
    // The key art last: it follows the hero sprite, made first
    const order = [...generated.filter((a) => a.kind !== 'keyart'), ...generated.filter((a) => a.kind === 'keyart')];
    for (const a of order) {
      const file = `${a.id}.${ext}`;
      const path = join(dir, file);
      const asked = opts.force || opts.only?.includes(a.id);
      let remade = false;
      const fromKey = a.from ? sha256(Buffer.from(JSON.stringify([a.from, a.cut ?? null, !!a.flip, a.upscale ?? null, a.from.startsWith('http') ? '' : existsSync(join(loc.dir, a.from)) ? sha256(readFileSync(join(loc.dir, a.from))) : '']))) : undefined;
      const stale = a.from ? prov.files[file]?.source !== fromKey : changed(a.id, file);
      if (existsSync(path) && !asked && !stale) res.kept.push(file);
      else {
        const prompt = assetPrompt(art, a, true);
        log(`${a.id} (${a.kind}, ${a.from ? `from ${a.from.split('/').pop()}` : label}) …`);
        const refs: { mime: string; data: Buffer }[] = [{ mime: 'image/webp', data: style }];
        const heroRef = a.kind === 'keyart' && hero ? raw(hero.id) : null;
        if (heroRef) refs.push(heroRef);
        const fromPng = async () => {
          const raw = await fromImage(loc, a, page);
          if (!a.upscale) return raw;
          const u = await import('./upscale.ts');
          return u.encodePng(page, await u.upscale(await u.decodePng(page, raw), { method: a.upscale.method as UpscaleMethodName, factor: a.upscale.factor, keepDetails: a.upscale.keepDetails, palette: art.palette }, page));
        };
        const png = a.from && a.redraw
          ? await provider({ model, prompt: redrawPrompt(art, a), aspect: aspectFor(a), refs: [{ mime: 'image/png', data: await enlarged(await fromImage(loc, a, page), page) }, ...refs], kind: a.kind, seed: `${loc.id}:${a.id}` }, page)
          : a.from ? await fromPng() : await provider({ model, prompt, aspect: aspectFor(a), refs, kind: a.kind, seed: `${loc.id}:${a.id}`, source: src(a.id) }, page);
        writeFileSync(join(rawDir(loc), `${a.id}.png`), png);
        const direct = a.from && !a.redraw;
        const p = await processImage(page, png, a.kind, targetSize(a), 0.86, undefined, keyed && !direct, pixel);
        if (keyed && !direct && cutout(a.kind) && (!p.cornersClear || p.transparent < 0.05))
          res.warnings.push(`${file}: the background didn't cut out (${Math.round(p.transparent * 100)} % transparent, corners ${p.cornersClear ? 'clear' : 'opaque'}): the model ignored the flat key — regenerate it (gp art --only ${a.id}) or ask for "a flat pure green background" more firmly in its prompt`);
        writeFileSync(path, p.webp);
        if (direct) {
          prov.files[file] = { kind: a.kind, model: 'from an existing image', prompt: `${a.from}${a.cut ? ` [${a.cut.join(', ')}]` : ''}${a.flip ? ', mirrored' : ''}${a.upscale ? `, ${a.upscale.method} ×${a.upscale.factor}${a.upscale.keepDetails === false ? '' : ', details kept'}` : ''}`, style: null, size: p.size, bytes: p.webp.length, sha256: sha256(p.webp), date, source: fromKey, ...(cutout(a.kind) ? { scale: +p.scale.toFixed(5) } : {}) };
          res.made.push(file);
          remade = true;
          continue;
        }
        prov.files[file] = { kind: a.kind, model: by, prompt: a.redraw ? `${redrawPrompt(art, a)} (from ${a.from})` : providerName === 'svg' ? `${a.prompt} — drawn as ${ART_SRC_DIR}/${a.id}.svg` : prompt, ...(a.redraw ? { source: fromKey } : {}), style: styleHash, size: p.size, bytes: p.webp.length, sha256: sha256(p.webp), date, ...(cutout(a.kind) ? { scale: +p.scale.toFixed(5) } : {}), ...(providerName === 'svg' ? { source: srcHash(a.id) } : {}) };
        res.made.push(file);
        res.costUSD += price;
        remade = true;
      }
      // The animation: every frame painted from the sprite (attached), at the sprite's scale; a new sprite remakes them
      const frames = frameFiles(a, ext);
      if (!frames.length) continue;
      const base = raw(a.id)!;
      const baseHash = prov.files[file]?.sha256 ?? sha256(readFileSync(path));
      for (const [i, f] of frames.entries()) {
        const fp = join(dir, f);
        if (existsSync(fp) && !asked && !remade && prov.files[f]?.from === baseHash && !changed(stem(f), f)) {
          res.kept.push(f);
          continue;
        }
        const pose = a.frames![i]!;
        const prompt = framePrompt(art, a, pose);
        log(`${a.id} frame ${i + 1}/${frames.length} (${label}) …`);
        const png = await provider({ model, prompt, aspect: '1:1', refs: [base, { mime: 'image/webp', data: style }], kind: a.kind, seed: `${loc.id}:${a.id}:${i + 1}`, source: src(`${a.id}-${i + 1}`) }, page);
        writeFileSync(join(rawDir(loc), `${stem(f)}.png`), png);
        const p = await processImage(page, png, a.kind, targetSize(a), 0.86, prov.files[file]?.scale, keyed, pixel);
        if (keyed && (!p.cornersClear || p.transparent < 0.05)) res.warnings.push(`${f}: the background didn't cut out — regenerate it (gp art --only ${a.id})`);
        writeFileSync(fp, p.webp);
        prov.files[f] = { kind: a.kind, model: by, prompt: providerName === 'svg' ? `${pose} — drawn as ${ART_SRC_DIR}/${a.id}-${i + 1}.svg` : prompt, style: styleHash, from: baseHash, size: p.size, bytes: p.webp.length, sha256: sha256(p.webp), date, scale: +p.scale.toFixed(5), ...(providerName === 'svg' ? { source: srcHash(`${a.id}-${i + 1}`) } : {}) };
        res.made.push(f);
        res.costUSD += price;
      }
    }
    // The later chapters' placeholders, from the images as they are now
    res.made.push(...(await writeThumbs(loc, art, page, prov, date)));
  } finally {
    await browser.close();
    // What was made is recorded even when a later request fails (a quota mid-run): the next run keeps it
    writeProvenance(loc, prov);
  }
  writeFileSync(join(dir, 'index.ts'), indexFor(loc, art));
  return res;
}

/** After a hand edit: record the files' new hashes (marked edited) */
export function recordArt(loc: GameLocation): string[] {
  const art = artSpec(loc);
  const prov = loadProvenance(loc);
  const changed: string[] = [];
  const date = new Date().toISOString().slice(0, 10);
  for (const file of [STYLE_FILE, ...(art?.assets ?? []).flatMap((a) => assetFiles(a, extOf(art)))]) {
    const path = join(assetsDir(loc), file);
    const rec = prov.files[file];
    if (!existsSync(path) || !rec) continue;
    const buf = readFileSync(path);
    if (sha256(buf) !== rec.sha256) {
      prov.files[file] = { ...rec, sha256: sha256(buf), bytes: buf.length, edited: date };
      changed.push(file);
    }
  }
  if (changed.length) writeProvenance(loc, prov);
  return changed;
}

/** `gp validate`: every declared asset exists, is listed in provenance.yaml with its hash, and assets/index.ts is current */
export function artChecks(loc: GameLocation): Issue[] {
  const art = artSpec(loc);
  if (!art) return [];
  const issues: Issue[] = [];
  // A frame's file (hero-1) may not be another asset's
  const ext = extOf(art);
  const ids = art.assets.flatMap((a) => assetFiles(a).map(stem));
  const dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  if (dup.length)
    issues.push({ code: 'E_ART_ID', severity: 'error', path: ['art', 'assets'], message: `art asset id${dup.length > 1 ? 's' : ''} ${[...new Set(dup)].join(', ')} used twice`, fix: 'Give every asset its own id: it is the file name (assets/<id>.webp) and the key in ART.' });
  const stills = art.assets.filter((a) => a.frames?.length && a.kind !== 'sprite').map((a) => a.id);
  if (stills.length)
    issues.push({ code: 'E_ART_FRAMES', severity: 'error', path: ['art', 'assets'], message: `frames on ${stills.join(', ')}: only a sprite is animated`, fix: 'Move `frames` to a sprite (kind: sprite), or remove it: a background, tile, ui, icon or keyart is one still image.' });
  const long = art.assets.filter((a) => (a.frames?.length ?? 0) > MAX_FRAMES).map((a) => a.id);
  if (long.length)
    issues.push({ code: 'E_ART_FRAMES', severity: 'error', path: ['art', 'assets'], message: `more than ${MAX_FRAMES} frames on ${long.join(', ')}`, fix: `Keep an animation to ${MAX_FRAMES} poses or fewer (a walk cycle is 4–6, an attack 3–4): each frame is a paid image and bundle size. Squash, bob and sway come free from @gp/art/rig.` });
  const ids0 = new Set(art.assets.map((a) => a.id));
  const orphans = art.assets.filter((a) => a.part && (a.part.of === a.id || !ids0.has(a.part.of)));
  if (orphans.length)
    issues.push({ code: 'E_ART_PART', severity: 'error', path: ['art', 'assets'], message: `${orphans.map((a) => `${a.id} is a part of "${a.part!.of}"`).join(', ')}, which isn't another asset in art.assets`, fix: '`part.of` names the sprite the part was cut from (a wheel of `red-car`: part: { of: red-car, at: [x, y] }); re-run `gp art import` for the picture, or remove the part.' });
  // A part loads with its sprite: a wheel in another chapter than its car would be drawn on a placeholder, or alone
  const split = art.assets.filter((a) => a.part && typeof a.chapter === 'number' && ids0.has(a.part.of) && a.chapter !== assetChapter(art, art.assets.find((x) => x.id === a.part!.of)!));
  if (split.length)
    issues.push({ code: 'E_ART_CHAPTER', severity: 'error', path: ['art', 'assets'], message: `${split.map((a) => `${a.id} (chapter ${a.chapter}) is a part of ${a.part!.of} (chapter ${assetChapter(art, art.assets.find((x) => x.id === a.part!.of)!)})`).join(', ')}`, fix: 'Leave `chapter` off a part: it loads with the sprite it was cut from. Move the sprite instead (its `chapter`, or cleanup.json `chapter` for gp art import).' });
  const realism = [art.style, ...art.assets.flatMap((a) => [a.prompt, ...(a.frames ?? [])])].map((s) => s.match(REALISM_WORDS)?.[0]).filter(Boolean);
  if (realism.length)
    issues.push({
      code: 'W_ART_REALISTIC',
      severity: 'warning',
      path: ['art', 'style'],
      message: `the art direction asks for realism ("${[...new Set(realism)].join('", "')}"): our games are cartoon, game-like art`,
      fix: 'Describe a cartoon look instead: the shapes (chunky, rounded, exaggerated), the shading (cel, soft gradients), the outline, the palette and the light — e.g. "chunky cartoon shapes, soft cel shading, warm rim light, teal and amber palette".',
    });
  const blend = art.technique === 'pixel' ? [art.style, ...art.assets.flatMap((a) => [a.prompt, ...(a.frames ?? [])])].map((s) => s.match(PIXEL_BLEND_WORDS)?.[0]).filter(Boolean) : [];
  if (blend.length)
    issues.push({
      code: 'W_ART_PIXEL_BLEND',
      severity: 'warning',
      path: ['art', 'style'],
      message: `pixel art asked for blends ("${[...new Set(blend)].join('", "')}"): the model paints soft shading, and snapping it to the palette leaves banding and noise`,
      fix: 'Say it in pixel terms: "3–4 hue-shifted steps per material, flat fills, one light from the upper left, a 1-pixel dark outline"; a soft area (sky, fog, a glow) in a 50 % checker dither.',
    });
  if (!art.keep?.length)
    issues.push({
      code: 'W_ART_KEEP',
      severity: 'warning',
      path: ['art'],
      message: 'the art says how it looks but not what of the game it keeps: art.keep is empty',
      fix: 'The game design leads the look (the owner, 2026-10-10). Write art.keep: the identity the new art must keep even if its technique changes (pixel → cartoon) — the palette and the light, the hero\'s silhouette — and what play needs from it: what must stand out at play size, the colour codes (danger, loot, rarity), the telegraphs. E.g. ["a dark crypt lit only by the hero\'s own candle", "danger reads red, loot gold", "enemies readable at 40 px"].',
    });
  if (art.technique === 'pixel' && !art.palette?.length)
    issues.push({ code: 'W_ART_PALETTE', severity: 'warning', path: ['art', 'palette'], message: 'pixel art without a palette: the images keep the model\'s colours, not the game\'s', fix: 'Copy the game\'s palette into art.palette (hex): every pixel of the new art snaps to it, so it sits with the art the game already has.' });
  const missing = art.assets.flatMap((a) => assetFiles(a, ext)).filter((f) => !existsSync(join(assetsDir(loc), f))).map(stem);
  const missingImports = art.assets.filter((a) => imported(a) && missing.includes(a.id)).map((a) => a.id);
  const index = join(assetsDir(loc), 'index.ts');
  const stale = !existsSync(index) || readFileSync(index, 'utf8') !== indexFor(loc, art);
  const thumbs = staleThumbs(loc, art);
  if (missing.length || stale || thumbs.length)
    issues.push({
      code: 'W_ART_MISSING',
      severity: 'warning',
      path: ['art', 'assets'],
      message: missing.length
        ? `${missing.length} art asset(s) not generated yet: ${missing.slice(0, 6).join(', ')}${missing.length > 6 ? ' …' : ''}`
        : thumbs.length
          ? `${thumbs.length} later-chapter image(s) without a current thumbnail (their placeholder): ${thumbs.slice(0, 6).join(', ')}${thumbs.length > 6 ? ' …' : ''}`
          : `${ASSETS_DIR}/index.ts doesn't list game.yaml's art assets`,
      fix: `${missingImports.length ? `The owner's pictures (${missingImports.slice(0, 4).join(', ')}): \`gp art import <dir> <id>\` with the folder of the originals. ` : ''}Run \`gp art <id>\` (it makes the missing ones, the later chapters' thumbnails, and rewrites assets/index.ts); GEMINI_API_KEY in the environment, or a network secret: header x-goog-api-key for generativelanguage.googleapis.com.`,
    });
  const prov = loadProvenance(loc);
  const unlisted: string[] = [];
  for (const file of art.assets.flatMap((a) => assetFiles(a, ext)).filter((f) => existsSync(join(assetsDir(loc), f)))) {
    const rec = prov.files[file];
    const a = art.assets.find((x) => assetFiles(x, ext).includes(file));
    // An imported picture is recorded as the owner's, with the original it came from
    if (!rec || rec.sha256 !== sha256(readFileSync(join(assetsDir(loc), file))) || (a && imported(a) && (rec.source !== 'owner' || !rec.originalSha256))) unlisted.push(file);
  }
  if (unlisted.length)
    issues.push({
      code: 'W_ART_PROVENANCE',
      severity: 'warning',
      path: ['art'],
      message: `${unlisted.length} image(s) in ${ASSETS_DIR}/ not as provenance.yaml records them: ${unlisted.slice(0, 6).join(', ')}`,
      fix: 'An image changed by hand: `gp art --record` records its new hash (marked edited). An owner\'s picture: `gp art import <dir> <id>` (source: owner, the original\'s name and hash). An image from elsewhere: regenerate it with `gp art --only <id>`, or record where it came from.',
    });
  return issues;
}

/** The asset table for the CLI and the review */
export function artSummary(loc: GameLocation): { file: string; kind: string; size: [number, number]; bytes: number }[] {
  const prov = loadProvenance(loc);
  return Object.entries(prov.files).map(([file, r]) => ({ file, kind: r.kind, size: r.size, bytes: r.bytes }));
}
