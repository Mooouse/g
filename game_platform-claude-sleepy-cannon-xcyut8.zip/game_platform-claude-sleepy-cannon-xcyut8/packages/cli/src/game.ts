// Load and check a game (game.yaml + publisher.yaml) the same way for every command.

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { isUpdate, PATCH_NOTES_FILE, PATCH_NOTES_MAX } from './submission.ts';
import { formatPath, gameGenre, genreChecks, importedBlocks, loadYaml, lootChecks, musicIssues, PHYSICS, PHYSICS_PACKAGES_INSTEAD, validateText, type Issue, type Publisher, type ResolvedGame, type ValidateResult } from '@gp/spec';
import { codeHasMusic, gameSources, scopeIssues } from './review.ts';
import { loadResults } from './forecast.ts';
import { gameDependencies, missingDependencies, packageDir } from './deps.ts';
import { PUBLISHER_FILE, shown, type GameLocation } from './paths.ts';
import { i18nChecks } from './i18n.ts';
import { storyFileChecks } from './story.ts';
import { fileChecks } from './uniqueness.ts';
import { artChecks } from './art.ts';

export function loadPublisher(): Publisher {
  if (!existsSync(PUBLISHER_FILE)) return {};
  return (loadYaml(readFileSync(PUBLISHER_FILE, 'utf8')).data ?? {}) as Publisher;
}

/** `draftTexts`: only for `gp dev` — untranslated keys and languages are warnings (the game shows English there), so a
 *  game can be played while its translations are being written; gp qa, build, covers, video and submission refuse them */
export const DRAFT_TEXT_CODES = ['E_I18N_MISSING', 'E_I18N_EMPTY'];

export function checkGame(loc: GameLocation, mode: 'dev' | 'release', opts: { draftTexts?: boolean } = {}): ValidateResult {
  const text = readFileSync(loc.file, 'utf8');
  const r = validateText(text, { mode, publisher: loadPublisher() });
  // The story file, when game.yaml declares one (docs/guides/story.md); reported at the `story:` line
  if (r.game) {
    const line = text.split('\n').findIndex((l) => /^story:/.test(l)) + 1;
    r.issues.push(...storyFileChecks(loc, r.game).map((i) => (line ? { ...i, line } : i)));
    // The texts per language (strings/<code>.yaml), reported at the `languages:` line (docs/guides/i18n.md)
    const langLine = text.split('\n').findIndex((l) => /^languages:/.test(l)) + 1;
    const spec = (loadYaml(text).data ?? {}) as Record<string, unknown>;
    const texts = i18nChecks(loc, r.game, spec).map((i) => (langLine ? { ...i, line: langLine } : i));
    r.issues.push(...(opts.draftTexts ? texts.map((i) => (DRAFT_TEXT_CODES.includes(i.code) ? { ...i, severity: 'warning' as const, message: `${i.message} (gp dev shows English there; gp qa, build and submission refuse it)` } : i)) : texts));
    if (r.issues.some((i) => i.severity === 'error')) {
      r.ok = false;
      r.game = null;
    }
  }
  // A code game made with `gp init` still running the template's placeholder mechanic
  if (r.game?.kit.kit === 'code') {
    r.issues.push(...fileChecks(loc, r.game));
    const left = placeholders(loc);
    if (left.length)
      r.issues.push({ code: 'W_PLACEHOLDER', severity: 'warning', path: ['entry'], message: `the template's PLACEHOLDER is still in ${left.join(', ')}`, fix: 'Replace the placeholder mechanic, texts and art with your game, and remove the PLACEHOLDER markers; `gp submission` refuses them.' });
    // The game's own npm dependencies (an engine): declared in its package.json, installed next to it
    const missing = missingDependencies(loc);
    if (missing.length) {
      const deps = gameDependencies(loc)!;
      r.issues.push({ code: 'W_DEPS_MISSING', severity: 'warning', path: ['entry'], message: `${shown(deps.file)} lists ${missing.join(', ')}, not installed`, fix: `Install them: npm ci (or npm install) in ${shown(deps.dir)} — scripts/setup.sh does it in a gp init repository.` });
    }
    // An update (CHANGELOG.md with 2+ versions) needs its patch notes before gp submission refuses it
    if (isUpdate(loc.dir) && !existsSync(join(loc.dir, PATCH_NOTES_FILE)))
      r.issues.push({ code: 'W_PATCH_NOTES', severity: 'warning', path: ['version'], message: `an update (CHANGELOG.md has 2+ versions) without ${PATCH_NOTES_FILE}: gp submission refuses it`, fix: `Write ${shown(join(loc.dir, PATCH_NOTES_FILE))}: what changed for players, plain English, ≤ ${PATCH_NOTES_MAX} characters.` });
    // Generated art (game.yaml `art`): every asset made, recorded in assets/provenance.yaml, listed in assets/index.ts
    const artLine = text.split('\n').findIndex((l) => /^art:/.test(l)) + 1;
    r.issues.push(...artChecks(loc).map((i) => (artLine ? { ...i, line: artLine } : i)));
    // Music on a portal (E_SOUND_MUSIC): the code starts it, or game.yaml `sound.music` says what plays
    const soundLine = text.split('\n').findIndex((l) => /^sound:/.test(l)) + 1;
    r.issues.push(...musicIssues(r.game, codeHasMusic(loc)).map((i) => (soundLine ? { ...i, line: soundLine } : i)));
    // The genre (money.genre): its must-haves (I_GENRE_EXPECTS) and blocks of another genre (W_GENRE_BLOCK), from the imports
    const genreLine = text.split('\n').findIndex((l) => /^money:/.test(l)) + 1;
    r.issues.push(...genreIssues(loc, r.game).map((i) => (genreLine ? { ...i, line: genreLine } : i)));
    // A first CrazyGames submission with more screens than the approved games had (W_SCOPE), from the last gp qa
    const conceptLine = text.split('\n').findIndex((l) => /^concept:/.test(l)) + 1;
    r.issues.push(...scopeIssues(loc, r.game, loadResults().results).map((i) => (conceptLine ? { ...i, line: conceptLine } : i)));
    const line = text.split('\n').findIndex((l) => /^engine:/.test(l)) + 1;
    r.issues.push(...[...engineChecks(loc, r.game.kit.engine), ...physicsChecks(loc, r.game.kit.physics)].map((i) => (line ? { ...i, line } : i)));
    if (r.issues.some((i) => i.severity === 'error')) {
      r.ok = false;
      r.game = null;
    }
  }
  return r;
}

/**
 * game.yaml `engine` against the game's package.json and node_modules: the engine's package is pinned there at the same
 * exact version, and the installed one is that version (the spec already checked the adapter's range)
 */
export function engineChecks(loc: GameLocation, engine: { name: string; version: string | null; package: string | null } | null): Issue[] {
  if (!engine?.package || !engine.version) return [];
  return pinChecks(loc, { what: `engine ${engine.name}`, pkg: engine.package, version: engine.version, code: 'E_ENGINE_VERSION', path: ['engine', 'version'] });
}

/**
 * game.yaml `engine.physics` against the game's package.json and node_modules, like the engine: its -compat package
 * pinned at the same exact version and installed. Without engine.physics, a Rapier package in package.json is a warning:
 * the game would run Rapier by hand, without the physics block
 */
export function physicsChecks(loc: GameLocation, physics: { name: string; version: string; package: string } | null): Issue[] {
  const deps = gameDependencies(loc);
  if (!physics) {
    const rapier = Object.keys(deps?.dependencies ?? {}).filter((n) => /^@dimforge\/rapier/.test(n));
    if (!rapier.length) return [];
    return [{ code: 'W_PHYSICS_UNDECLARED', severity: 'warning', path: ['engine'], message: `${shown(deps!.file)} lists ${rapier.join(', ')}, but game.yaml has no engine.physics`, fix: `Declare it (engine: { name: canvas, physics: { name: rapier2d, version: ${PHYSICS.rapier2d.tested} } }, with @dimforge/rapier2d-compat pinned) and run the world through createPhysics() from @gp/physics — docs/guides/code-games.md#physics.` }];
  }
  // Another Rapier build pinned instead of the one engine.physics names: say why that one
  const instead = Object.keys(deps?.dependencies ?? {}).find((n) => n !== physics.package && PHYSICS_PACKAGES_INSTEAD[n]);
  const issues = pinChecks(loc, { what: `engine.physics ${physics.name}`, pkg: physics.package, version: physics.version, code: 'E_PHYSICS_VERSION', path: ['engine', 'physics', 'version'] });
  return issues.map((i) => (instead && i.message.includes("doesn't list") ? { ...i, message: `${i.message} (it has ${instead}: ${PHYSICS_PACKAGES_INSTEAD[instead]})` } : i));
}

/** A package game.yaml names at an exact version: pinned at that version in the game's package.json, and installed so */
function pinChecks(loc: GameLocation, o: { what: string; pkg: string; version: string; code: string; path: string[] }): Issue[] {
  const { what, pkg, version } = o;
  const deps = gameDependencies(loc);
  const declared = deps?.dependencies[pkg];
  const where = deps ? shown(deps.file) : `${shown(join(loc.dir, 'package.json'))} (there is none)`;
  const issue = (message: string, fix: string): Issue => ({ code: o.code, severity: 'error', path: o.path, message, fix });
  if (!declared)
    return [issue(`${what} ${version}: ${where} doesn't list "${pkg}"`, `Add "dependencies": { "${pkg}": "${version}" } to games/${loc.id}/package.json, then npm ci there (scripts/setup.sh).`)];
  if (declared.replace(/^=/, '') !== version)
    return [issue(`${what} ${version} in game.yaml, but ${where} has "${pkg}": "${declared}"`, `Pin the same exact version in both: "${pkg}": "${version}" (no ^ or ~), then npm ci in the game folder.`)];
  const dir = packageDir(loc, pkg);
  // Not installed at all: W_DEPS_MISSING says so (a fresh clone before scripts/setup.sh)
  if (!dir) return [];
  let installed = '';
  try {
    installed = (JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as { version?: string }).version ?? '';
  } catch {
    // unreadable: as if not installed
    return [];
  }
  if (installed !== version)
    return [issue(`${what} ${version} is pinned, but ${shown(dir)} is ${pkg} ${installed || '(no version)'}`, `Install the pinned version: npm ci (or npm install) in ${shown(deps!.dir)}.`)];
  return [];
}

/**
 * A code game's genre checks (packages/spec/src/genres.ts): the names it imports from @gp/* and its source text, read
 * once — the genre's must-haves, blocks of another genre (money.hybrid lets a declared layer's blocks in), and the
 * odds of a LootTable it rolls (W_LOOT_ODDS)
 */
export function genreIssues(loc: GameLocation, game: ResolvedGame): Issue[] {
  const files = gameSources(loc.dir).map((f) => readFileSync(f, 'utf8'));
  const g = gameGenre({ kit: game.kit.kit, audience: game.audience.id, money: game.money, tags: game.listing.tags });
  const imported = [...new Set(files.flatMap(importedBlocks))];
  const source = files.join('\n');
  return [...genreChecks({ ...g, imported, source, money: game.money }), ...lootChecks({ imported, source })];
}

/** Files of a code game that still carry the template's PLACEHOLDER marker */
export function placeholders(loc: GameLocation): string[] {
  return readdirSync(loc.dir).filter((f) => /\.(ts|mjs)$/.test(f) && !f.endsWith('.test.ts') && readFileSync(join(loc.dir, f), 'utf8').includes('PLACEHOLDER'));
}

const color = process.stdout.isTTY && !process.env.NO_COLOR;
const paint = (code: string, s: string) => (color ? `\x1b[${code}m${s}\x1b[0m` : s);

/** One issue per block: where, what, how to fix */
export function formatIssues(loc: GameLocation, issues: Issue[]): string {
  const file = shown(loc.file);
  return issues
    .map((i) => {
      const where = i.path[0] === '(publisher.yaml)' ? 'publisher/publisher.yaml' : `${file}${i.line ? `:${i.line}` : ''}`;
      const sev = i.severity === 'error' ? paint('31', 'error') : i.severity === 'warning' ? paint('33', 'warning') : paint('36', 'info');
      return `${where}  ${sev} ${paint('1', i.code)}  ${i.message}\n    fix: ${i.fix}\n    path: ${formatPath(i.path)} · more: gp explain ${i.code}`;
    })
    .join('\n');
}
