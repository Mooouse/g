// `gp submission`: everything the portal's submission form asks for, built, checked and put in one folder — what a game
// maker hands over at the end: games/<id>/submission/
//
//   CrazyGames form field        file                                   requirement
//   Upload files                 index.html                              files, not archives; index.html at the root; < 50 MB (< 20 MB: mobile homepage)
//   Cover landscape 16:9         cover-landscape-1920x1080.png           mandatory
//   Cover portrait 2:3           cover-portrait-800x1200.png             mandatory
//   Cover square 1:1             cover-square-800x800.png                mandatory
//   Preview video landscape      preview-landscape-1920x1080.mp4         mandatory: 15 s, H.264, no sound, ≤ 50 MB
//   Preview video portrait       preview-portrait-1080x1920.mp4          mandatory
//   Description, controls        listing.md (+ the form's other answers) from game.yaml `listing`
//   Patch notes (an update)      patch-notes.md from games/<id>/patch-notes.md, at most 2000 characters
//   (the store page, not the form) listing-translations.md                the listing in the game's other languages (strings/<code>.yaml)
//   Marketing creatives, stores  —                                       optional
//   (for the owner, not the form) uniqueness.md, forecast.md             the originality score; what the game can earn (gp forecast)
//   (for the owner, not the form) quality.md                             the second agent's quality review (gp review): no [blocking] finding
//   (for the owner, not the form) cover-check.md, cover-preview-200.png  the covers' click-through check at 200 px (gp covers): a note, never a refusal
//
// The handover zip: a new game → the whole folder; an update (CHANGELOG.md with 2+ versions) → index.html, listing.md and
// patch-notes.md (the update form). `--full`: a game with an update history submitted anew (a rejected game resubmitted)
// → the whole folder, no patch notes; with `--reuse-media` its covers and videos are kept as they are, never rendered again.

import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import type { ResolvedGame } from '@gp/spec';
import { newestSourceMs, type GameLocation } from './paths.ts';
import { COVER_THRESHOLDS } from './cover-check.ts';
import { QUALITY_FILE, qualityGate } from './review.ts';

const COVER_WARN = COVER_THRESHOLDS.score;

export interface SubmissionFile {
  field: string;
  file: string | null;
  detail: string;
  ok: boolean;
}

export interface SubmissionResult {
  dir: string;
  files: SubmissionFile[];
  ok: boolean;
  /** The one zip to send the owner (written when the folder is complete): an update's three files, or the whole folder */
  handover?: { file: string; names: string[] };
}

export interface SubmissionOptions {
  /** Keep the covers and videos in games/<id>/store/ (while they are newer than the code; with `full`, whatever their age) */
  reuseMedia?: boolean;
  /** Submitted anew though the game has an update history (a rejected game resubmitted): the full folder, no patch notes */
  full?: boolean;
}

/** What gp submission renders: the covers (all three at once), the videos (both, one orientation, or none), and a note */
export interface MediaPlan {
  covers: boolean;
  videos: 'all' | 'landscape' | 'portrait' | null;
  note: string | null;
}

/**
 * Which media to render, from what store/ holds. Without --reuse-media: everything. With it: what is missing or older
 * than the game's code (Kettlebot 1.1.0 handed over a redesigned game with the old covers: only the quality reviewer
 * caught it). With --full too: only what is missing — a resubmission keeps its media as they are (a note names the old
 * ones, to look at: store/<video>-frames.png, the covers)
 */
export function mediaPlan(store: string, sourceMs: number, opts: SubmissionOptions): MediaPlan {
  const there = (f: string) => existsSync(join(store, f));
  const fresh = (f: string) => there(f) && statSync(join(store, f)).mtimeMs >= sourceMs;
  if (!opts.reuseMedia) return { covers: true, videos: 'all', note: null };
  const keep = opts.full ? there : fresh;
  const old = [...COVERS, ...VIDEOS].filter((m) => there(m.from) && !fresh(m.from)).map((m) => m.from);
  const videos = VIDEOS.filter((v) => !keep(v.from));
  const note = !old.length
    ? null
    : opts.full
      ? `kept as they are (--full --reuse-media), though older than the game code: ${old.join(', ')} — look at them (the covers, store/<video>-frames.png) before sending`
      : 'older than the game code — rendered again despite --reuse-media';
  return {
    covers: !COVERS.every((c) => keep(c.from)),
    // With --full only the missing orientation; otherwise both (as before)
    videos: !videos.length ? null : opts.full && videos.length === 1 ? (videos[0].width > videos[0].height ? 'landscape' : 'portrait') : 'all',
    note,
  };
}

/**
 * What the owner gets, in one zip (Жаслан, 2026-10-10: «почему при выдаче ZIP не выдаётся md-файл со списком
 * изменений» — a chat zipped index.html alone and the patch notes were lost): an update → index.html, listing.md and
 * patch-notes.md (the portal's update form); a new game → every file of the folder. Written next to the folder as
 * games/<id>/<id>-<version>-<update|submission>.zip, so a chat sends exactly this file.
 */
export async function handoverZip(loc: GameLocation, dir: string, version: string, update: boolean): Promise<{ file: string; names: string[] }> {
  const { zip } = await import('./zip.ts');
  const names = update
    ? ['index.html', 'listing.md', PATCH_NOTES_FILE].filter((n) => existsSync(join(dir, n)))
    : readdirSync(dir).filter((n) => statSync(join(dir, n)).isFile()).sort();
  const file = join(loc.dir, `${loc.id}-${version}-${update ? 'update' : 'submission'}.zip`);
  writeFileSync(file, zip(names.map((n) => ({ name: n, data: readFileSync(join(dir, n)) }))));
  return { file, names };
}

/** Width and height of a PNG from its header */
export function pngSize(file: string): { width: number; height: number } | null {
  const b = readFileSync(file);
  if (b.length < 24 || b.toString('ascii', 1, 4) !== 'PNG') return null;
  return { width: b.readUInt32BE(16), height: b.readUInt32BE(20) };
}

/** Duration (s), size and codec of a video, read from ffmpeg's banner */
export function probeVideo(ffmpeg: string, file: string): { sec: number | null; width: number; height: number; codec: string; audio: boolean } {
  let text = '';
  try {
    execFileSync(ffmpeg, ['-hide_banner', '-i', file], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
  } catch (e) {
    text = String((e as { stderr?: string }).stderr ?? '');
  }
  const d = text.match(/Duration: (\d+):(\d+):([\d.]+)/);
  const v = text.match(/Video: (\w+)[^\n]*?, (\d{2,5})x(\d{2,5})/);
  return {
    sec: d ? Number(d[1]) * 3600 + Number(d[2]) * 60 + Number(d[3]) : null,
    width: v ? Number(v[2]) : 0,
    height: v ? Number(v[3]) : 0,
    codec: v?.[1] ?? '?',
    audio: /Audio:/.test(text),
  };
}

const COVERS = [
  { field: 'Cover landscape 16:9', from: 'cover-1920x1080.png', to: 'cover-landscape-1920x1080.png', width: 1920, height: 1080 },
  { field: 'Cover portrait 2:3', from: 'cover-800x1200.png', to: 'cover-portrait-800x1200.png', width: 800, height: 1200 },
  { field: 'Cover square 1:1', from: 'cover-800x800.png', to: 'cover-square-800x800.png', width: 800, height: 800 },
];
const VIDEOS = [
  { field: 'Preview video landscape', from: 'preview-1920x1080.mp4', to: 'preview-landscape-1920x1080.mp4', width: 1920, height: 1080 },
  { field: 'Preview video portrait', from: 'preview-1080x1920.mp4', to: 'preview-portrait-1080x1920.mp4', width: 1080, height: 1920 },
];

export function listingMarkdown(game: ResolvedGame): string {
  const l = game.listing;
  const orient = { both: 'Both (portrait and landscape)', landscape: 'Landscape', portrait: 'Portrait' }[l.orientation];
  return `# ${game.title} — CrazyGames submission

Everything below is for the form at developer.crazygames.com → Submit a game. Written by \`gp submission\` from game.yaml.

## Files (this folder)

| Form field | File |
|---|---|
| Upload files (drag the file itself: no archives) | \`index.html\` |
| Cover landscape 16:9 | \`cover-landscape-1920x1080.png\` |
| Cover portrait 2:3 | \`cover-portrait-800x1200.png\` |
| Cover square 1:1 | \`cover-square-800x800.png\` |
| Preview video landscape | \`preview-landscape-1920x1080.mp4\` |
| Preview video portrait | \`preview-portrait-1080x1920.mp4\` |
| Marketing creatives, store links | — (optional) |

## Form answers

| Question | Answer |
|---|---|
| Game name (≤ 35 characters, the same as in the game) | ${game.title} |
| Engine | HTML5 |
| Orientation | ${orient} |
| Mobile support | ${/\b(touch|tap|swipe|drag)\b/i.test(l.controls ?? '') ? 'Yes (touch controls)' : 'Check: the controls name no touch input — answer No, or add touch controls'} |
| Does your game save progress? | Yes — CrazyGames Data Module |
| The game supports CrazyGames muting audio through SDK | Yes |
| In-game purchases | No |
| Online multiplayer | No (Yes only if your game plays online with a server) |
${l.tags.length ? `| Genre / tags | ${l.tags.join(' · ')} |\n` : ''}
## Description

${l.description ?? '(missing: add listing.description to game.yaml)'}

## Controls

${l.controls ?? '(missing: add listing.controls to game.yaml)'}

## Before you press Submit

- Open the Preview on the developer portal (desktop, and the QR code on a phone): the SDK checker, the demo ads, cloud save, mute.
${game.languages.length > 1 ? `- The game is in ${game.languages.length} languages (${game.languages.join(', ')}): it starts in the player's (CrazyGames' systemInfo.locale) and the title's picker changes it. The form takes the English texts above; listing-translations.md has the others for the store page and other portals.
` : ''}
- The covers and the video show the same game the description describes; the name on the covers is the game's name.
- cover-preview-200.png (this folder) shows the covers at the size players see them; cover-check.md scores them. Alternatives for an A/B test: \`gp covers --variants 3\` (docs/guides/covers.md).
- First submissions go to Basic Launch (7–21 days, ads off): watch 1-minute conversion (80%+), average play time (10+ min) and D1 (10–15%).
- quality.md (this folder) is the second agent's quality review (\`gp review\`): no [blocking] finding is left; its [nice] findings are the next update.
- forecast.md (this folder) says what the game can earn and how sure that is; when the portal answers, record the outcome in the platform's publisher/results.yaml (forecast.md has the lines).
`;
}

/** listing-translations.md: the description and controls in every language of the game but English, from strings/<code>.yaml */
export function listingTranslations(game: Pick<ResolvedGame, 'title' | 'languages'>, listing: Record<string, { description?: string; controls?: string }>): { markdown: string; done: string[]; missing: string[] } {
  const others = game.languages.filter((l) => l !== 'en');
  const done = others.filter((l) => listing[l]?.description?.trim() && listing[l]?.controls?.trim());
  const missing = others.filter((l) => !done.includes(l));
  const md = [
    `# ${game.title} — the listing in its other languages`,
    '',
    "Written by `gp submission` from strings/<code>.yaml (`listing:`). CrazyGames' submission form takes the English description and controls (listing.md); these are for the store page's localisation, other portals and the game's own site.",
    '',
    ...others.flatMap((l) => {
      const x = listing[l];
      return [`## ${l}`, '', `**Description.** ${x?.description?.trim() || '(missing: gp translate)'}`, '', `**Controls.** ${x?.controls?.trim() || '(missing: gp translate)'}`, ''];
    }),
  ].join('\n');
  return { markdown: md, done, missing };
}

/** games/<id>/quality.md into the submission folder when it passes; the ✗ line says what to do when it doesn't */
/** Patch notes for an update (Жаслан, 2026-10-03): what changed, for players, at most PATCH_NOTES_MAX characters */
export const PATCH_NOTES_MAX = 2000;
export const PATCH_NOTES_FILE = 'patch-notes.md';

/** An update is a game whose CHANGELOG.md has more than one version (`## 1.2.0 …`); a first version needs no patch notes */
export function isUpdate(dir: string): boolean {
  const log = join(dir, 'CHANGELOG.md');
  return existsSync(log) && (readFileSync(log, 'utf8').match(/^## +v?\d+\.\d+/gm) ?? []).length > 1;
}

export function patchNotesStep(loc: GameLocation, dir: string): SubmissionFile | null {
  const src = join(loc.dir, PATCH_NOTES_FILE);
  const field = 'Patch notes';
  if (!existsSync(src)) {
    if (!isUpdate(loc.dir)) return null;
    return { field, file: null, detail: `an update needs games/${loc.id}/${PATCH_NOTES_FILE}: what changed for players, in plain words, at most ${PATCH_NOTES_MAX} characters (not the CHANGELOG)`, ok: false };
  }
  const text = readFileSync(src, 'utf8').trim();
  const n = [...text].length;
  if (!n) return { field, file: null, detail: `${PATCH_NOTES_FILE} is empty`, ok: false };
  if (n > PATCH_NOTES_MAX) return { field, file: null, detail: `${n} characters — at most ${PATCH_NOTES_MAX}: shorten ${PATCH_NOTES_FILE}`, ok: false };
  writeFileSync(join(dir, PATCH_NOTES_FILE), text + '\n');
  return { field, file: PATCH_NOTES_FILE, detail: `${n}/${PATCH_NOTES_MAX} characters`, ok: true };
}

export function qualityStep(loc: GameLocation, game: Pick<ResolvedGame, 'title'>, dir: string): SubmissionFile {
  const gate = qualityGate(loc, game);
  if (gate.ok) copyFileSync(gate.file, join(dir, QUALITY_FILE));
  return { field: 'Quality review', file: gate.ok ? QUALITY_FILE : null, detail: gate.detail, ok: gate.ok };
}

/**
 * The GDLC gates a submission enforces (docs/guides/gdlc.md): phase 0 — the ТЗ review loop closed, when the game has a
 * ТЗ (docs/gdd.md); phase 2 — on CrazyGames, the blind first look "keep playing" ≥ 4/5 with the goal told (an update to a
 * live game, not --full: a warning). The other phases' gates are reported (gp stage), not enforced
 */
export async function gdlcStep(loc: GameLocation, game: ResolvedGame, o: { update: boolean }): Promise<SubmissionFile> {
  const { checkGame } = await import('./game.ts');
  const { stageReport, submissionGates } = await import('./stage.ts');
  const rep = await stageReport({ loc, issues: checkGame(loc, 'dev').issues, game });
  const g = submissionGates(rep, o);
  return { field: 'Design gates (gp stage)', file: null, detail: g.detail, ok: g.ok };
}

export async function buildSubmission(loc: GameLocation, game: ResolvedGame, opts: SubmissionOptions = {}): Promise<SubmissionResult> {
  const dir = join(loc.dir, 'submission');
  const store = join(loc.dir, 'store');
  const files: SubmissionFile[] = [];
  rmSync(dir, { recursive: true, force: true });
  mkdirSync(dir, { recursive: true });

  const { buildPortal } = await import('./portal-build.ts');
  const pkg = await buildPortal(loc, game);
  if (pkg.problems.length) files.push({ field: 'Upload files', file: null, detail: pkg.problems.join('; '), ok: false });
  else {
    copyFileSync(pkg.file, join(dir, 'index.html'));
    const kb = pkg.bytes / 1024;
    // The size and load budget (gp build's size report): over it is a warning here too, not a refusal
    const s = pkg.size;
    const budget = `${Math.round(s.gzipBytes / 1024).toLocaleString('en-US')} KB gzipped, ≈ ${(s.load.tappableMs / 1000).toFixed(1)} s to a tappable Play on a slow phone${s.over.length ? ` — over budget: ${s.over.join('; ')}` : ''}`;
    files.push({ field: 'Upload files', file: 'index.html', detail: `one file, ${kb < 1024 ? `${kb.toFixed(0)} KB` : `${(kb / 1024).toFixed(1)} MB`} (${budget})${pkg.bytes > 20 * 1048576 ? ' — over 20 MB: not on the mobile homepage' : ''}`, ok: true });
  }

  // --reuse-media keeps covers and videos only while they are newer than the game's code; with --full, as they are
  const plan = mediaPlan(store, newestSourceMs(loc.dir), opts);
  if (plan.note) files.push({ field: 'Covers and videos (note)', file: null, detail: plan.note, ok: true });
  // The click-through check (gp covers --check): a warning under 70, never a refusal; its report goes to the owner
  const { CHECK_FILE, PREVIEW_FILE, checkCovers, renderCovers } = await import('./covers.ts');
  let coverScores: Awaited<ReturnType<typeof checkCovers>>['scores'] = [];
  if (plan.covers) coverScores = (await renderCovers(loc, game, store)).scores;
  else coverScores = (await checkCovers(store).catch(() => ({ scores: [] }))).scores;
  for (const c of COVERS) {
    const src = join(store, c.from);
    const size = existsSync(src) ? pngSize(src) : null;
    const ok = !!size && size.width === c.width && size.height === c.height;
    if (ok) copyFileSync(src, join(dir, c.to));
    files.push({ field: c.field, file: ok ? c.to : null, detail: size ? `${size.width}×${size.height} PNG` : 'missing', ok });
  }
  const main = coverScores.filter((c) => COVERS.some((m) => join(store, m.from) === c.file));
  if (main.length) {
    for (const f of [CHECK_FILE, PREVIEW_FILE]) if (existsSync(join(store, f))) copyFileSync(join(store, f), join(dir, f));
    const weak = main.filter((c) => c.verdict.score < COVER_WARN || c.verdict.partial);
    files.push({
      field: 'Covers: click-through check (note)',
      file: existsSync(join(dir, CHECK_FILE)) ? CHECK_FILE : null,
      detail: `${main.map((c) => `${c.verdict.score}`).join(' / ')} of 100${main.some((c) => c.verdict.partial) ? ' (the picture only: no cover hook, so the title and the hero were not measured)' : ''}${weak.length ? ` — ${CHECK_FILE} says what to change (docs/guides/covers.md)` : ''}`,
      ok: true,
    });
  }

  const { findFfmpeg, renderVideos } = await import('./video.ts');
  const ffmpeg = findFfmpeg();
  if (!ffmpeg) for (const v of VIDEOS) files.push({ field: v.field, file: null, detail: 'ffmpeg with libx264 not found (FFMPEG=…, or pip install imageio-ffmpeg)', ok: false });
  else {
    if (plan.videos) {
      try {
        const res = await renderVideos(loc, game, { outDir: store, ...(plan.videos === 'all' ? {} : { only: plan.videos }) });
        for (const p of res.problems) files.push({ field: 'Preview video (note)', file: null, detail: p, ok: true });
      } catch (e) {
        files.push({ field: 'Preview videos', file: null, detail: `gp video failed: ${(e as Error).message.split('\n')[0]}`, ok: false });
      }
    }
    for (const v of VIDEOS) {
      const src = join(store, v.from);
      if (!existsSync(src)) {
        files.push({ field: v.field, file: null, detail: 'missing', ok: false });
        continue;
      }
      const p = probeVideo(ffmpeg, src);
      const mb = statSync(src).size / 1048576;
      const problems = [
        p.codec !== 'h264' && `codec ${p.codec}, not H.264`,
        (p.width !== v.width || p.height !== v.height) && `${p.width}×${p.height}, not ${v.width}×${v.height}`,
        (p.sec === null || p.sec < 14.9 || p.sec > 20.1) && `${p.sec?.toFixed(1) ?? '?'} s (15–20 s)`,
        p.audio && 'has sound',
        mb > 50 && `${mb.toFixed(1)} MB > 50 MB`,
      ].filter(Boolean);
      if (!problems.length) copyFileSync(src, join(dir, v.to));
      files.push({ field: v.field, file: problems.length ? null : v.to, detail: problems.length ? problems.join(', ') : `H.264 ${p.width}×${p.height}, ${p.sec!.toFixed(0)} s, no sound, ${mb.toFixed(1)} MB`, ok: !problems.length });
    }
  }

  const { placeholders } = await import('./game.ts');
  const left = game.kit.kit === 'code' ? placeholders(loc) : [];
  files.push({ field: 'The game itself', file: null, detail: left.length ? `the template's PLACEHOLDER is still in ${left.join(', ')} — this is the template, not a game` : 'no template placeholders left', ok: !left.length });
  // Uniqueness: the gate the portal applies first (a concept "quite close to existing titles" is rejected)
  if (game.portal) {
    const { checkGame } = await import('./game.ts');
    const { uniquenessReport, UNIQUE_ENOUGH } = await import('./uniqueness.ts');
    const rep = uniquenessReport(loc, game, checkGame(loc, 'dev').issues);
    writeFileSync(join(dir, 'uniqueness.md'), rep.markdown);
    files.push({ field: 'Uniqueness', file: 'uniqueness.md', detail: `${rep.score}/100 — ${rep.verdict}${rep.score < UNIQUE_ENOUGH ? ` (needs ${UNIQUE_ENOUGH}: gp uniqueness says what to change)` : ''}`, ok: rep.score >= UNIQUE_ENOUGH && !rep.gate });
  }
  // The quality review by a second agent (gp review): CrazyGames rejected three games for "the overall quality"
  if (game.portal) files.push(qualityStep(loc, game, dir));
  // The design lifecycle's gates (gp stage): the ТЗ review loop, and the blind first look ≥ 4/5 on CrazyGames
  if (game.portal) files.push(await gdlcStep(loc, game, { update: !opts.full && isUpdate(loc.dir) }));
  // An update's patch notes for the owner (the portal's update form and the players); --full: a new submission, none
  const notes = opts.full ? null : patchNotesStep(loc, dir);
  if (notes) files.push(notes);
  if (opts.full) files.push({ field: 'Submitted anew (note)', file: null, detail: `--full: ${isUpdate(loc.dir) ? 'the game has an update history, but ' : ''}the whole folder goes to the new-game form — no patch notes`, ok: true });
  // The money forecast for the owner: what the game can earn, with the confidence of every input (docs/guides/game-design.md → Design for money)
  {
    const { checkGame } = await import('./game.ts');
    const { gameForecast, forecastMarkdown, forecastLine, loadResults, resubmissionWarning } = await import('./forecast.ts');
    const issues = checkGame(loc, 'dev').issues;
    const g = await gameForecast(loc, game, issues);
    // Sent anew: what the history says about it (a warning, never a refusal)
    if (opts.full || g.design.resubmission)
      files.push({ field: 'Resubmission (warning)', file: null, detail: resubmissionWarning(loadResults().results, g.design, g.forecast, game.channel.id), ok: true });
    writeFileSync(join(dir, 'forecast.md'), forecastMarkdown(game.title, g.design, g.forecast, g.levers, g.calibration, { balance: g.balance, id: loc.id, playtime: g.playtime }));
    const missing = !game.money && game.kit.kit === 'code';
    files.push({
      field: 'Money forecast',
      file: 'forecast.md',
      detail: missing ? 'game.yaml has no `money` section: write the money design (W_MONEY_MISSING) — the forecast guessed it' : forecastLine(g.forecast).replace(/ — gp forecast$/, ''),
      ok: !missing,
    });
  }
  const l = game.listing;
  writeFileSync(join(dir, 'listing.md'), listingMarkdown(game));
  // The listing in the game's other languages: the CrazyGames form takes English only (as read 2026-09-07); these are for
  // the store page's localisation, other portals and the game's own site
  if (game.languages.length > 1) {
    const { loadStrings } = await import('./i18n.ts');
    const t = listingTranslations(game, loadStrings(loc).listing);
    writeFileSync(join(dir, 'listing-translations.md'), t.markdown);
    files.push({
      field: 'Listing translations',
      file: 'listing-translations.md',
      detail: `${t.done.length}/${game.languages.length - 1} languages${t.missing.length ? ` — missing: ${t.missing.join(', ')} (gp translate)` : ''} — for the store page, not the CrazyGames form (it takes English)`,
      ok: true,
    });
  }
  const todo = (x: string | null) => !x || /^\s*TODO\b/i.test(x);
  const missing = [todo(l.description) && 'listing.description', todo(l.controls) && 'listing.controls', l.tags.some((t) => /^\s*TODO/i.test(t)) && 'listing.tags'].filter(Boolean);
  files.push({ field: 'Description, controls', file: 'listing.md', detail: missing.length ? `missing in game.yaml: ${missing.join(', ')}` : `${l.description!.length} + ${l.controls!.length} characters`, ok: !missing.length });

  const ok = files.every((f) => f.ok);
  // --full: the whole folder, whatever the CHANGELOG says
  const handover = ok ? await handoverZip(loc, dir, game.version.name, !opts.full && !!notes) : undefined;
  return { dir, files, ok, handover };
}

export { newestSourceMs } from './paths.ts';
