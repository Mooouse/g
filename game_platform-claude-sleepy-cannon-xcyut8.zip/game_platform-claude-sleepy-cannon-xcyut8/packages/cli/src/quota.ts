// gp quota: the external generators' monthly quotas (the owner's ТЗ 2026-10-27, § 6). The limits are in the platform's
// publisher/quota.yaml; every generation is recorded in the repository that spent it (art/quota-log.json, committed with
// the game; the platform's own in publisher/quota-log.json), so a fresh container still knows the month's spend. `check`
// exits 1 once a service is down to its reserve: the pixel-artist checks before every generation. Where the service can
// tell its own balance, that is asked too and the lower of the two wins.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { parse } from 'yaml';
import { ROOT } from './paths.ts';

export interface ServiceQuota {
  plan?: string;
  monthly: number;
  reserve: number;
  resetDay: number;
  enabled: boolean;
}

export interface QuotaEntry {
  at: string;
  service: string;
  n: number;
  note?: string;
}

export const QUOTA_FILE = join(ROOT, 'publisher', 'quota.yaml');

export function loadQuotas(file = QUOTA_FILE): Record<string, ServiceQuota> {
  const raw = existsSync(file) ? ((parse(readFileSync(file, 'utf8')) ?? {}) as { services?: Record<string, Partial<ServiceQuota>> }).services ?? {} : {};
  return Object.fromEntries(
    Object.entries(raw).map(([k, v]) => [k, { plan: v.plan, monthly: Number(v.monthly ?? 0), reserve: Number(v.reserve ?? 0), resetDay: Math.min(28, Math.max(1, Number(v.resetDay ?? 1))), enabled: v.enabled !== false }]),
  );
}

/** Where a repository keeps its log: a game's art/quota-log.json, the platform's publisher/quota-log.json */
export const logFile = (repoRoot: string): string => (repoRoot === ROOT ? join(ROOT, 'publisher', 'quota-log.json') : join(repoRoot, 'art', 'quota-log.json'));

export function readLog(file: string): QuotaEntry[] {
  if (!existsSync(file)) return [];
  try {
    const j = JSON.parse(readFileSync(file, 'utf8')) as { entries?: QuotaEntry[] };
    return Array.isArray(j.entries) ? j.entries : [];
  } catch {
    return [];
  }
}

/** The start of the current quota month: the last reset day at 00:00 UTC on or before `now` */
export function periodStart(now: Date, resetDay: number): Date {
  const y = now.getUTCFullYear(), m = now.getUTCMonth();
  const thisMonth = new Date(Date.UTC(y, m, resetDay));
  return thisMonth.getTime() <= now.getTime() ? thisMonth : new Date(Date.UTC(y, m - 1, resetDay));
}

export interface QuotaState {
  service: string;
  enabled: boolean;
  monthly: number;
  reserve: number;
  used: number;
  /** What the service itself says is left (null: it doesn't say, or wasn't asked) */
  remote: number | null;
  left: number;
  ok: boolean;
  since: string;
  plan?: string;
}

export function quotaState(service: string, q: ServiceQuota | undefined, log: QuotaEntry[], now = new Date(), remote: number | null = null): QuotaState {
  if (!q) return { service, enabled: false, monthly: 0, reserve: 0, used: 0, remote, left: 0, ok: false, since: '' };
  const since = periodStart(now, q.resetDay);
  const used = log.filter((e) => e.service === service && Date.parse(e.at) >= since.getTime()).reduce((s, e) => s + e.n, 0);
  const local = q.monthly - used;
  const left = remote === null ? local : Math.min(local, remote);
  return { service, enabled: q.enabled, monthly: q.monthly, reserve: q.reserve, used, remote, left, ok: q.enabled && left > q.reserve, since: since.toISOString().slice(0, 10), plan: q.plan };
}

export function record(file: string, service: string, n: number, note?: string, now = new Date()): QuotaEntry {
  if (!Number.isInteger(n) || n < 0) throw new Error(`gp quota record: the count must be a whole number ≥ 0, not "${n}"`);
  const entries = readLog(file);
  const e: QuotaEntry = { at: now.toISOString(), service, n, ...(note ? { note } : {}) };
  entries.push(e);
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, JSON.stringify({ entries }, null, 1) + '\n');
  return e;
}

export const describe = (s: QuotaState): string =>
  !s.enabled
    ? `${s.service}: off${s.plan ? ` (${s.plan})` : ''}`
    : `${s.service}: ${s.left} of ${s.monthly} left this month (since ${s.since}; ${s.used} recorded${s.remote !== null ? `, the service says ${s.remote}` : ''}; reserve ${s.reserve})${s.plan ? ` — ${s.plan}` : ''}`;
