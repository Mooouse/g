// `gp video`: the portal's preview videos, filmed from the game itself in the dev build.
// Petri Panic, Spin Brawl, Yeet the Gnome and Brew & Banter (QmaCyber/game2 … game5) each wrote this by hand; the recipe
// they converged on is here: the page runs on a virtual clock (requestAnimationFrame, timers, performance.now and CSS
// animations move only when the recorder says so), every frame is a screenshot, ffmpeg makes an H.264 MP4 — smooth 30 fps
// on any machine, the same video every run.
//
// CrazyGames (requirements/game-covers): 15–20 s, ≤ 50 MB, no sound, landscape 1080p mandatory, portrait too; open on the
// static cover; no intro, black bars, cursor, "Play now" text, icons or fast-forward. So: the cover frame first, then play.
//
// What is filmed: the game's own script (games/<id>/video.mjs, or --script), else a default — tap Play and let the
// game's `host.qa({ demo })` bot play (a code game without demo() only shows its first seconds).
//
// Every run also writes a contact sheet beside each video (store/<video>-frames.png: a frame a second, each with its
// time), composed in the browser from the recorder's own frames — no ffmpeg — so an agent can look at what the video
// shows; `gp video --frames` writes the sheets only, in a container without ffmpeg or H.264.
//
// Not for the portal: `--sound` records the page's audio on the same clock (audio-tap.ts) and `--max <s>` films longer —
// a gameplay video for the owner (Frankengun mixed its soundtrack by hand). Such a video is named gameplay-…, never
// preview-…, so `gp submission` can't take it for a preview (the portal wants 15–20 s and no sound).

import { execFileSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import type { Browser, Page } from 'playwright';
import { CHANNELS, type ResolvedGame } from '@gp/spec';
import { audioTap, fadeOut, runAudio, takeAudio } from './audio-tap.ts';
import { advanceClock, virtualClock } from './clock.ts';
import type { GameLocation } from './paths.ts';

export const FPS = 30;
const DT = 1000 / FPS;
/** A portal preview's length: the default, and what CrazyGames takes (15–20 s) */
export const PREVIEW_SEC = 15;
export const PREVIEW_MAX_SEC = 20;

/** The file a video is written to: the channel's preview name, or gameplay-… when it can't be a preview (sound, length) */
export function videoName(preview: string, opts: { sound?: boolean; seconds?: number } = {}): string {
  const sec = opts.seconds ?? PREVIEW_SEC;
  if (!opts.sound && sec >= PREVIEW_SEC && sec <= PREVIEW_MAX_SEC) return preview;
  return preview.startsWith('preview-') ? preview.replace(/^preview-/, 'gameplay-') : `gameplay-${preview}`;
}

/** What a game's video script gets */
export interface VideoApi {
  page: Page;
  /** 'landscape' or 'portrait': a script may frame the two differently */
  orientation: 'landscape' | 'portrait';
  /** Frames in `s` seconds */
  sec(s: number): number;
  /** Move the clock by `frames` frames and film each one (film: false — fast-forward off camera) */
  step(frames: number, opts?: { film?: boolean }): Promise<void>;
  /** Tap an element (pointer events at its centre; the clock doesn't move) */
  tap(selector: string): Promise<boolean>;
  /** The element is on screen */
  visible(selector: string): Promise<boolean>;
  /** Fast-forward off camera until the element is visible (at most `maxSec` of game time) */
  until(selector: string, maxSec?: number): Promise<boolean>;
  /** Let the game's own bot play the run that just started (`host.qa({ demo })`); false when the game has none */
  demo(): Promise<boolean>;
  /** Seconds filmed so far (the video is cut at `length`) */
  filmed(): number;
  /** The video's length in seconds: 15 for a preview, or `gp video --max` */
  length: number;
}

export type VideoScript = (v: VideoApi) => Promise<void>;

/** An ffmpeg that can encode H.264 (libx264): FFMPEG, then PATH, then the one `pip install imageio-ffmpeg` brings */
export function findFfmpeg(): string | null {
  const x264 = (f: string) => {
    try {
      return execFileSync(f, ['-hide_banner', '-encoders'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).includes('libx264');
    } catch {
      return false;
    }
  };
  for (const f of [process.env.FFMPEG, 'ffmpeg'].filter(Boolean) as string[]) if (x264(f)) return f;
  try {
    const p = execFileSync('python3', ['-c', 'import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())'], { encoding: 'utf8' }).trim();
    if (p && existsSync(p) && x264(p)) return p;
  } catch {}
  return null;
}

/** The title's Play button: CrazyGames wants no "Play" text in a preview, so frames that show it are reported */
export const PLAY_SELECTOR = '[data-gp=play]';

export const DEFAULT_SCRIPT: VideoScript = async (v) => {
  await v.until(PLAY_SELECTOR, 10);
  // The title stays off camera (Echoflies' video, made from this recipe, opened on 0.2 s of its Play button)
  await v.step(v.sec(0.4), { film: false });
  await v.tap(PLAY_SELECTOR);
  if (!(await v.demo())) console.warn('  no demo() in host.qa: the video shows the first seconds only — add a bot (host.qa({ demo })) or games/<id>/video.mjs');
  await v.step(v.sec(v.length));
};

export interface VideoResult {
  /** The videos (none with `frames`) */
  files: string[];
  /** The contact sheets, one per video: store/<video>-frames.png */
  sheets: string[];
  problems: string[];
  scripted: boolean;
}

/** The contact sheet of a video: store/<video name>-frames.png */
export const sheetName = (video: string): string => `${video}-frames.png`;

/** One frame of a contact sheet: the recorder's file, its time and what it is */
export interface SheetFrame {
  file: string;
  sec: number;
  /** cover (the opening still), end (the end card's padding), play (the title's Play button is on it) */
  marks: ('cover' | 'end' | 'play')[];
  /** A caption after the time (gp design: what the player was doing then) */
  label?: string;
}

/**
 * The frames a sheet shows: one a second (from 0 to 14 s of a preview) and the last — a longer video one every few
 * seconds, at most 30; `filmed` frames were filmed, the rest is the end card
 */
export function sheetFrames(total: number, filmed: number, opts: { cover: number; play: ReadonlySet<number>; file: (i: number) => string }): SheetFrame[] {
  const every = Math.max(1, Math.ceil(total / FPS / 30)) * FPS;
  const picks = [...new Set([...Array.from({ length: Math.ceil(total / every) }, (_, k) => k * every), total - 1])].filter((i) => i >= 0 && i < total).sort((a, b) => a - b);
  return picks.map((i) => ({
    file: opts.file(i),
    sec: Math.round((i / FPS) * 10) / 10,
    marks: [...(i < opts.cover ? (['cover'] as const) : []), ...(i >= filmed ? (['end'] as const) : []), ...(opts.play.has(i) ? (['play'] as const) : [])],
  }));
}

/**
 * Compose a contact sheet: the frames as thumbnails in a grid, each captioned with its time and marks, a header with the
 * game and the video — drawn in a browser page and saved as a PNG (Playwright only: no ffmpeg, no image library)
 */
export async function contactSheet(browser: Browser, frames: readonly SheetFrame[], out: string, opts: { title: string; video: string; width: number; height: number; note?: string }): Promise<string> {
  const landscape = opts.width >= opts.height;
  const thumbW = landscape ? 480 : 240;
  const thumbH = Math.round((thumbW * opts.height) / opts.width);
  const cols = landscape ? 4 : 8;
  const gap = 12;
  const page = await browser.newPage({ viewport: { width: cols * thumbW + (cols + 1) * gap, height: 400 }, deviceScaleFactor: 1 });
  try {
    const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const label = { cover: 'cover', end: 'end card', play: '⚠ Play button' } as const;
    // A sheet of a minute or more (a gameplay cut, gp design's run) reads its times as m:ss
    const long = frames.some((f) => f.sec >= 60);
    const every = frames.length > 2 ? Math.round(frames[1].sec - frames[0].sec) : 1;
    const cells = frames
      .map((f) => {
        const src = `data:image/jpeg;base64,${readFileSync(f.file).toString('base64')}`;
        const marks = f.marks.map((m) => `<b class="${m}">${label[m]}</b>`).join(' ');
        const at = long ? `${Math.floor(f.sec / 60)}:${String(Math.floor(f.sec % 60)).padStart(2, '0')}` : `${f.sec.toFixed(1)} s`;
        return `<figure><img src="${src}" width="${thumbW}" height="${thumbH}"><figcaption>${at} ${marks}${f.label ? ` <span>${esc(f.label)}</span>` : ''}</figcaption></figure>`;
      })
      .join('');
    await page.setContent(`<!doctype html><meta charset="utf-8"><style>
      body { margin: 0; padding: ${gap}px; background: #16181d; color: #e8e8ea; font: 15px/1.3 system-ui, sans-serif; }
      h1 { font-size: 18px; margin: 0 0 ${gap}px; font-weight: 600; } h1 span { color: #9aa0aa; font-weight: 400; }
      main { display: grid; grid-template-columns: repeat(${cols}, ${thumbW}px); gap: ${gap}px; }
      figure { margin: 0; } img { display: block; background: #000; object-fit: contain; outline: 1px solid #333; }
      figcaption { padding: 4px 2px 0; } b { font-weight: 600; padding: 0 4px; border-radius: 3px; font-size: 13px; }
      .cover { background: #2f5d9e; } .end { background: #555; } .play { background: #b3261e; } figcaption span { color: #9aa0aa; }
    </style><h1>${esc(opts.title)} — ${esc(opts.video)} <span>${opts.width}×${opts.height}, ${frames.length} frames: ${esc(opts.note ?? `one ${every > 1 ? `every ${every} s` : 'a second'} (gp video's contact sheet)`)}</span></h1><main>${cells}</main>`);
    await page.waitForFunction(() => [...document.images].every((i) => i.complete && i.naturalWidth > 0), null, { timeout: 30000 });
    await page.screenshot({ path: out, fullPage: true });
    return out;
  } finally {
    await page.close();
  }
}

/** A video's page size: a channel's preview size, or another (gp design's gameplay cut at 1280×720) */
export type VideoSize = NonNullable<(typeof CHANNELS)[string]['videos']>[number];

export async function renderVideos(
  loc: GameLocation,
  game: ResolvedGame,
  opts: { outDir?: string; script?: string; only?: 'landscape' | 'portrait'; frames?: boolean; sound?: boolean; max?: number; size?: VideoSize; play?: VideoScript; crf?: number } = {},
): Promise<VideoResult> {
  const seconds = opts.max ?? PREVIEW_SEC;
  if (!(seconds >= 1 && seconds <= 600)) throw new Error(`--max ${opts.max}: a length from 1 to 600 seconds`);
  const sound = !!opts.sound && !opts.frames;
  // `size`: one size of the caller's (it is never a preview: videoName makes it gameplay-…), else the channel's
  const sizes = opts.size ? [opts.size] : (CHANNELS[game.channel.id]?.videos ?? []).filter((s) => !opts.only || s.orientation === opts.only);
  if (!sizes.length) throw new Error(`channel ${game.channel.id} has no preview videos`);
  // --frames: the contact sheets only, without ffmpeg
  const ffmpeg = opts.frames ? null : findFfmpeg();
  if (!opts.frames && !ffmpeg) throw new Error('ffmpeg with libx264 not found: install it, set FFMPEG=/path/to/ffmpeg, or `pip install imageio-ffmpeg` — or `gp video --frames` for the contact sheets alone (what the video shows, as PNGs)');
  // `play`: the caller's own script (gp design plays through the breaks), before the game's video.mjs (a preview's)
  const scriptFile = opts.script ? resolve(opts.script) : join(loc.dir, 'video.mjs');
  const scripted = !opts.play && existsSync(scriptFile);
  const script: VideoScript = opts.play ?? (scripted ? ((await import(pathToFileURL(scriptFile).href)) as { default: VideoScript }).default : DEFAULT_SCRIPT);
  const outDir = opts.outDir ?? join(loc.dir, 'store');
  mkdirSync(outDir, { recursive: true });
  const { chromium } = await import('playwright');
  const { startDev } = await import('./vite.ts');
  const server = await startDev(loc, undefined, { frozen: true });
  const url = server.resolvedUrls?.local[0] ?? 'http://localhost:5173/';
  // --sound: the recorder resumes the game's AudioContext itself, frame by frame (no user gesture behind it)
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined, args: sound ? ['--autoplay-policy=no-user-gesture-required'] : [] });
  const files: string[] = [];
  const sheets: string[] = [];
  const problems: string[] = [];
  const total = Math.round(seconds * FPS);
  try {
    for (const s of sizes) {
      const frames = mkdtempSync(join(tmpdir(), 'gp-video-'));
      try {
      let n = 0;
      let titleFrames = 0;
      const playFrames = new Set<number>();
      let coverFrames = 0;
      const frame = (i: number) => join(frames, `f${String(i).padStart(5, '0')}.jpg`);
      const ctxOpts = { viewport: { width: s.width, height: s.height }, deviceScaleFactor: s.dpr };
      // 1. The static cover opens the video (the portal's rule): half a second
      // (with a cover hook, the platform's composed cover — the same picture as the cover PNGs: docs/guides/covers.md)
      const cover = await browser.newPage(ctxOpts);
      await cover.goto(`${url}?seed=1&cover=1`);
      const { stageCover } = await import('./covers.ts');
      const st = await stageCover(cover, { pw: Math.round(s.width * s.dpr), ph: Math.round(s.height * s.dpr), variant: 'hero', title: game.title });
      const staged = st.mode !== 'first-screen';
      if (st.readyProblem) problems.push(`${s.name}: ${st.readyProblem}`);
      const coverFile = join(frames, 'cover.jpg');
      if (staged) {
        await cover.screenshot({ path: coverFile, type: 'jpeg', quality: 92 });
        for (let i = 0; i < FPS / 2; i++) copyFileSync(coverFile, frame(n++));
        coverFrames = n;
      }
      await cover.close();
      // 2. Play, on the virtual clock
      const page = await browser.newPage(ctxOpts);
      // The audio tap first: it keeps the real setTimeout to wait on the audio thread
      if (sound) await page.addInitScript(audioTap);
      await page.addInitScript(virtualClock);
      await page.goto(`${url}?seed=1`);
      const advance = () => advanceClock(page, DT);
      const visible = (sel: string) =>
        page.evaluate((q) => {
          const e = document.querySelector<HTMLElement>(q);
          if (!e) return false;
          const r = e.getBoundingClientRect();
          return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden' && getComputedStyle(e).display !== 'none';
        }, sel);
      const api: VideoApi = {
        page,
        orientation: s.orientation,
        sec: (x) => Math.round(x * FPS),
        async step(count, o = {}) {
          for (let i = 0; i < count && n < total; i++) {
            await advance();
            if (sound) await runAudio(page, DT, o.film !== false);
            if (o.film === false) continue;
            if (await visible(PLAY_SELECTOR)) {
              titleFrames++;
              playFrames.add(n);
            }
            await page.screenshot({ path: frame(n++), type: 'jpeg', quality: 92 });
          }
        },
        async tap(sel) {
          const box = await page.locator(sel).first().boundingBox().catch(() => null);
          if (!box) return false;
          await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
          return true;
        },
        visible,
        async until(sel, maxSec = 30) {
          for (let i = 0; i < maxSec * FPS; i++) {
            if (await visible(sel)) return true;
            await advance();
            if (sound) await runAudio(page, DT, false);
          }
          return false;
        },
        demo: () =>
          page.evaluate(() => {
            const d = (window as unknown as { __gp?: { host?: { qaDriver?: { demo?: () => void } } } }).__gp?.host?.qaDriver;
            if (typeof d?.demo !== 'function') return false;
            d.demo();
            return true;
          }),
        filmed: () => n / FPS,
        length: seconds,
      };
      await script(api);
      const audio = sound ? await takeAudio(page) : null;
      await page.close();
      if (titleFrames) problems.push(`${s.name}: ${titleFrames} filmed frame(s) show the Play button (${PLAY_SELECTOR}) — CrazyGames wants no "Play" text in a preview: fast-forward the title with step(n, { film: false })`);
      // 3. Up to 15 s: the cover again as the end card (or the last frame)
      const last = staged ? coverFile : n > 0 ? frame(n - 1) : null;
      if (!last) {
        problems.push(`${s.name}: nothing was filmed`);
        continue;
      }
      const filmed = n;
      while (n < total) copyFileSync(last, frame(n++));
      // The contact sheet, from the frames themselves (no ffmpeg): what an agent looks at
      const name = videoName(s.name, { sound, seconds });
      const sheet = join(outDir, sheetName(name));
      await contactSheet(browser, sheetFrames(total, filmed, { cover: coverFrames, play: playFrames, file: frame }), sheet, { title: game.title, video: `${name}.mp4`, width: Math.round(s.width * s.dpr), height: Math.round(s.height * s.dpr) });
      sheets.push(sheet);
      if (!staged) problems.push(`${s.name}: no ?cover frame (body[data-cover=ready]) — the video should open on the cover`);
      if (!ffmpeg) continue;
      const out = join(outDir, `${name}.mp4`);
      // The soundtrack: silence under the cover, the filmed frames' sound, silence under the end card
      let audioIn: string[] = [];
      let audioOut = ['-an'];
      if (audio) {
        if (audio.error || !audio.rate) problems.push(`${name}: no sound recorded (${audio.error || 'the page made no AudioContext'})`);
        const rate = audio.rate || 48000;
        const per = Math.round(rate / FPS) * 4;
        const track = Buffer.alloc(total * per);
        fadeOut(audio.pcm, rate, 0.25).copy(track, coverFrames * per, 0, Math.min(audio.pcm.length, (total - coverFrames) * per));
        const pcmFile = join(frames, 'audio.pcm');
        writeFileSync(pcmFile, track);
        audioIn = ['-f', 's16le', '-ar', String(rate), '-ac', '2', '-i', pcmFile];
        audioOut = ['-c:a', 'aac', '-b:a', '160k'];
      }
      execFileSync(ffmpeg, ['-y', '-loglevel', 'error', '-framerate', String(FPS), '-i', join(frames, 'f%05d.jpg'), ...audioIn, '-frames:v', String(total),
        '-c:v', 'libx264', '-preset', 'slow', '-crf', String(opts.crf ?? 20), '-pix_fmt', 'yuv420p', ...audioOut, '-movflags', '+faststart', out], { stdio: 'inherit' });
      const mb = statSync(out).size / 1048576;
      if (mb > 50 && name === s.name) problems.push(`${name}.mp4 is ${mb.toFixed(1)} MB; the portal takes ≤ 50 MB`);
      files.push(out);
      } finally {
        rmSync(frames, { recursive: true, force: true });
      }
    }
  } finally {
    await browser.close();
    await server.close();
  }
  return { files, sheets, problems, scripted };
}
