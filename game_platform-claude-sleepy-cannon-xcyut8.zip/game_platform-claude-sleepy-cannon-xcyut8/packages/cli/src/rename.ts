// `gp rename <game> <new-id>`: a game renamed (a remake, a new title) gets an id that says its current name, so its
// folder, its preview link and its submission zip stop carrying the old game's name (Firefly Rush was still
// `echoflies`, Scrap Royale `petri-panic`: the owner was sent zips and links with the old names). The players' saves stay:
// game.yaml pins `saveKey` to the old default. appId is never touched (the store would see a new app).

import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';

export const ID_PATTERN = /^[a-z0-9][a-z0-9-]*$/;

export interface RenameResult {
  ok: boolean;
  problems: string[];
  /** The game's new folder */
  dir?: string;
  /** saveKey pinned to the old default (it had none) */
  pinnedSaveKey?: string;
  /** Files outside the game folder that still name games/<old> or the old id: the maker updates them */
  mentions: string[];
  git: boolean;
}

const SKIP = new Set(['node_modules', '.git', 'dist', 'qa', 'upload', 'submission', 'store', 'platform']);

/** The new game.yaml text: `id:` set, `saveKey` pinned to the old default when it had none */
export function renamedYaml(text: string, oldId: string, newId: string): { text: string; pinned?: string; ok: boolean } {
  const idLine = new RegExp(`^id:[ \\t]*["']?${oldId.replace(/[-]/g, '\\-')}["']?[ \\t]*(#.*)?$`, 'm');
  if (!idLine.test(text)) return { text, ok: false };
  let out = text.replace(idLine, `id: ${newId}`);
  let pinned: string | undefined;
  if (!/^saveKey:/m.test(out)) {
    pinned = `${oldId}.save.v1`;
    out = out.replace(/^id: .*$/m, (l) => `${l}\nsaveKey: ${pinned}   # the players' saves from before \`gp rename\` (it was "${oldId}"): never change it`);
  }
  return { text: out, pinned, ok: true };
}

/** Text files under `root` (not the game's own folder, not outputs) that still name the old id as a word */
export function findMentions(root: string, oldId: string, skipDir: string): string[] {
  const word = new RegExp(`(^|[^a-z0-9-])${oldId.replace(/[-]/g, '\\-')}([^a-z0-9-]|$)`);
  const hits: string[] = [];
  const walk = (d: string) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      const p = join(d, e.name);
      if (e.isDirectory()) {
        if (!SKIP.has(e.name) && p !== skipDir) walk(p);
        continue;
      }
      if (!/\.(ts|js|mjs|json|ya?ml|md|sh|html|css)$/.test(e.name) || statSync(p).size > 512 * 1024) continue;
      readFileSync(p, 'utf8')
        .split('\n')
        .forEach((line, i) => {
          if (word.test(line)) hits.push(`${relative(root, p)}:${i + 1}`);
        });
    }
  };
  walk(root);
  return hits;
}

export function renameGame(dir: string, newId: string): RenameResult {
  const oldId = dir.split(/[\\/]/).pop()!;
  const problems: string[] = [];
  const res = (extra: Partial<RenameResult> = {}): RenameResult => ({ ok: problems.length === 0, problems, mentions: [], git: false, ...extra });
  if (!ID_PATTERN.test(newId)) problems.push(`"${newId}" is not an id: lowercase letters, digits and dashes`);
  if (newId === oldId) problems.push(`the game is already "${oldId}"`);
  const target = join(dirname(dir), newId);
  if (existsSync(target)) problems.push(`${target} exists already`);
  const file = join(dir, 'game.yaml');
  const y = renamedYaml(readFileSync(file, 'utf8'), oldId, newId);
  if (!y.ok) problems.push(`game.yaml has no "id: ${oldId}" line (the folder and the id must match)`);
  if (problems.length) return res();
  let git = false;
  let root = dirname(dirname(dir));
  try {
    root = execFileSync('git', ['-C', dir, 'rev-parse', '--show-toplevel'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    git = true;
  } catch {
    // not a checkout: a plain move
  }
  if (git) {
    const dirty = execFileSync('git', ['-C', dir, 'status', '--porcelain', '--', '.'], { encoding: 'utf8' }).trim();
    if (dirty) {
      problems.push(`uncommitted changes in ${oldId}/ — commit them first:\n${dirty}`);
      return res();
    }
  }
  writeFileSync(file, y.text);
  if (git) execFileSync('git', ['-C', dirname(dir), 'mv', oldId, newId], { stdio: 'ignore' });
  else renameSync(dir, target);
  return res({ dir: target, pinnedSaveKey: y.pinned, mentions: findMentions(root, oldId, target), git });
}
