// Vite plugin: turns games/<id>/game.yaml into the `virtual:gp/game` module the player imports.
// Invalid game.yaml → the build fails (and the dev server shows the issues in its error overlay).
// Editing game.yaml reloads the page.
//
// The game's own files live outside Vite's root (packages/player): Vite watches each of them one by one once served,
// and chokidar drops such a single-file watch for good when the file is replaced (written to a temporary file and
// renamed over it, or deleted and written again, as editors and agents' tools do) — the dev server then served the old
// file forever while the others reloaded. So a code game's whole folder is watched (a folder watch survives a replaced
// file), and every page load re-reads a served game file whose mtime changed since it was served (devFreshness).
//
// `frozen` (gp qa, gp covers, gp video): none of that — no watcher, no HMR, no re-read on a page load. A file written
// while QA ran (the game maker's next edit) reloaded the page under test and failed sections (Frankengun, 2026-10-18):
// a frozen server keeps serving what it first served, and QA's own reloads get the same game.

import { existsSync, readdirSync, statSync } from 'node:fs';
import { join, relative, resolve, sep } from 'node:path';
import type { Plugin, ViteDevServer } from 'vite';
import { SKY_BALLOONS_META, THEME_METAS } from '@gp/blocks/meta';
import { checkGame, formatIssues } from './game.ts';
import { runtimeStrings, stringsDir } from './i18n.ts';
import { PLAYER_DIR, type GameLocation } from './paths.ts';

const ID = 'virtual:gp/game';
const RESOLVED = '\0' + ID;
/** kit: code — the game's own module; `export default null` for the other kits */
const ENTRY = 'virtual:gp/entry';
const NO_ENTRY = '\0' + ENTRY;
/** The game's texts per language (strings/<code>.yaml, its declared languages; docs/guides/i18n.md) */
const STRINGS = 'virtual:gp/strings';
const RESOLVED_STRINGS = '\0' + STRINGS;
/** The native plugins (Capacitor, AdMob, TTS, Play Billing): bundled only for an Android channel */
// (the whole id matches: an alias replaces only the matched part)
export const NATIVE_PACKAGES = /^@(?:capacitor|capacitor-community|capgo)\/.+$/;
export const WEB_NATIVE_STUB = join(PLAYER_DIR, 'src/web-native.ts');
/**
 * The browsers a build is for (Vite's build.target), by the channel's platform.
 * - web (portals, own site): the first versions with top-level await in modules — Chrome and Edge 89, Firefox 89,
 *   Safari 15 (2021). A WebAssembly package imported as a module (Rapier, box2d-wasm) compiles to a top-level
 *   `await initWasm(…)` that no transform can lower: with an older target (es2020) the bundler left it in and warned
 *   (backlog item 4). CrazyGames asks for Chrome and Edge, and disables a game on Safari only if it doesn't work there
 *   (docs/research/crazygames-requirements-2026-09.md → Devices and browsers); every browser that runs the portal's
 *   own SDK and pages is newer than this floor.
 * - android: the Capacitor WebView, es2020 as before (no game there awaits at the top level: kit: code is web only).
 */
export const BUILD_TARGETS = {
  web: ['chrome89', 'edge89', 'firefox89', 'safari15'],
  android: 'es2020',
} as const satisfies Record<string, string | readonly string[]>;

/**
 * The interstitial pacing of a Playgama build. Playgama's certification plays a short session and fails a game whose
 * interstitial never fires ("The interstitial ad was not triggered"); its checklist asks for interstitials at natural
 * pauses (level transitions, game over), and the Bridge keeps its own minimum delay between them. So: from the first
 * natural break, at most one a minute — still only at breaks, never in play.
 */
export const PLAYGAMA_AD_POLICY = { noAdsAfterLaunchSec: 0, firstAdAfterRound: 1, firstAdAfterSec: 0, everyRounds: 1, minIntervalSec: 180 } as const;

/** What a game folder holds besides its sources: the outputs gp writes (never watched: a new upload/index.html would reload the page under test) */
export const GAME_OUTPUT_DIRS = ['qa', 'dist', 'upload', 'submission', 'store', 'node_modules'] as const;

/** A path in one of the game folder's outputs (or one of those folders) */
export function isGameOutput(loc: GameLocation, path: string): boolean {
  const rel = relative(loc.dir, path);
  return !!rel && !rel.startsWith('..') && (GAME_OUTPUT_DIRS as readonly string[]).includes(rel.split(sep)[0]);
}

/** A file of the game's own (its code and data in its folder; not its outputs or its npm packages) */
export function isGameSource(loc: GameLocation, file: string): boolean {
  const rel = relative(loc.dir, file);
  if (!rel || rel.startsWith('..') || resolve(loc.dir, rel) !== file) return false;
  const top = rel.split(sep)[0];
  return !(GAME_OUTPUT_DIRS as readonly string[]).includes(top) && !rel.split(sep).includes('node_modules');
}

/**
 * The served game files and their mtime when served; on a page load, the ones changed since are invalidated (and
 * watched again), so the page gets them fresh even when the watcher missed the change
 */
export function devFreshness(loc: GameLocation) {
  const served = new Map<string, number>();
  const mtime = (f: string) => {
    try {
      return statSync(f).mtimeMs;
    } catch {
      return null;
    }
  };
  return {
    /** A module was loaded from this file (the transform hook): remember its mtime */
    served(id: string) {
      const file = id.split('?')[0];
      if (!isGameSource(loc, file)) return;
      const ms = mtime(file);
      if (ms !== null) served.set(file, ms);
    },
    /** The files changed on disk since they were served (a missing file is the watcher's: it reports the delete) */
    changed(): string[] {
      return [...served].filter(([f, ms]) => {
        const now = mtime(f);
        return now !== null && now !== ms;
      }).map(([f]) => f);
    },
    /** Invalidate the changed files' modules and watch them again; returns them */
    refresh(server: Pick<ViteDevServer, 'moduleGraph' | 'watcher'>): string[] {
      const files = this.changed();
      for (const f of files) {
        served.delete(f);
        for (const mod of server.moduleGraph.getModulesByFile(f) ?? []) server.moduleGraph.invalidateModule(mod);
        server.watcher.add(f);
      }
      return files;
    },
  };
}

/** Another portal than the channel's: `gp build --target playgama | idos` */
export type BuildPortal = 'playgama' | 'idos';

export function gpGame(loc: GameLocation, mode: 'dev' | 'release', opts: { draftTexts?: boolean; portal?: BuildPortal; frozen?: boolean } = {}): Plugin {
  let title = '';
  let bg: string = SKY_BALLOONS_META.background;
  let lang = 'en';
  let entry: string | null = null;
  let resolved: ReturnType<typeof checkGame>['game'] = null;
  let serve = false;
  const fresh = devFreshness(loc);
  // game.yaml and the strings files, with their mtime when the modules made from them were last loaded
  const yamlSeen = new Map<string, number>();
  const yamlFiles = () => {
    const dir = stringsDir(loc);
    return [loc.file, ...(existsSync(dir) ? readdirSync(dir).filter((f) => /\.ya?ml$/.test(f)).map((f) => join(dir, f)) : [])];
  };
  const noteYaml = () => {
    for (const f of yamlFiles()) {
      try {
        yamlSeen.set(f, statSync(f).mtimeMs);
      } catch {
        yamlSeen.delete(f);
      }
    }
  };
  const yamlChanged = () =>
    yamlFiles().some((f) => {
      try {
        return statSync(f).mtimeMs !== yamlSeen.get(f);
      } catch {
        return false;
      }
    });
  const invalidateGame = (server: Pick<ViteDevServer, 'moduleGraph'>) => {
    resolved = null;
    for (const id of [RESOLVED, RESOLVED_STRINGS]) {
      const mod = server.moduleGraph.getModuleById(id);
      if (mod) server.moduleGraph.invalidateModule(mod);
    }
  };
  const load = () => {
    const r = checkGame(loc, mode, opts);
    if (!r.ok || !r.game) throw new Error(`game.yaml has errors:\n${formatIssues(loc, r.issues.filter((i) => i.severity === 'error'))}`);
    title = r.game.title;
    bg = r.game.kit.kit === 'code' ? r.game.kit.background : (THEME_METAS[r.game.theme as keyof typeof THEME_METAS]?.background ?? bg);
    lang = r.game.locale.slice(0, 2);
    // A build for another portal than the channel's (gp build --target playgama): the same game, that portal's SDK.
    // iDos Games hosts the game itself and lets it reach only its own hosts: no portal SDK, a plain web build without ads
    if (opts.portal) r.game.portal = opts.portal === 'idos' ? null : opts.portal;
    if (opts.portal === 'playgama' && r.game.ads) r.game.ads.policy = { ...r.game.ads.policy, ...PLAYGAMA_AD_POLICY };
    resolved = r.game;
    entry = null;
    if (r.game.kit.kit === 'code') {
      const file = resolve(loc.dir, r.game.kit.entry);
      if (relative(loc.dir, file).startsWith('..')) throw new Error(`game.yaml entry "${r.game.kit.entry}" must be inside the game folder`);
      if (!existsSync(file)) throw new Error(`game.yaml entry "${r.game.kit.entry}" not found: ${file}`);
      entry = file;
    }
    return r.game;
  };
  return {
    name: 'gp-game',
    // The game's kit and platform as build-time constants: the player's other branch (block kits or a code game) is
    // dropped, and a web channel's build gets the empty native plugins (web-native.ts) instead of Capacitor and AdMob
    config() {
      const game = load();
      const platform = game.channel.platform;
      return {
        define: { 'import.meta.env.GP_KIT': JSON.stringify(game.kit.kit), 'import.meta.env.GP_PLATFORM': JSON.stringify(platform) },
        build: { target: platform === 'android' ? BUILD_TARGETS.android : [...BUILD_TARGETS.web] },
        resolve: platform === 'android' ? {} : { alias: [{ find: NATIVE_PACKAGES, replacement: WEB_NATIVE_STUB }] },
        // The game folder's outputs are never watched (configureServer watches the whole folder of a code game); a
        // frozen server watches nothing (its server.watch: null is in startDev's config: this would override it)
        ...(opts.frozen ? {} : { server: { watch: { ignored: [(p: string) => isGameOutput(loc, p)] } } }),
      };
    },
    configResolved(c) {
      serve = c.command === 'serve';
    },
    configureServer(server) {
      if (opts.frozen) return;
      // A code game's folder, whole: a replaced file is still seen (single-file watches are dropped: see the top)
      if (entry !== null) server.watcher.add(loc.dir);
      // Every page load: a game file changed since it was served is read again, whatever the watcher saw
      server.middlewares.use((req, _res, next) => {
        const path = (req.url ?? '/').split('?')[0];
        if (path === '/' || path.endsWith('.html')) {
          fresh.refresh(server);
          if (yamlChanged()) invalidateGame(server);
        }
        next();
      });
    },
    transform(_code, id) {
      if (serve && !opts.frozen) fresh.served(id);
      return null;
    },
    resolveId(id) {
      if (id === ID) return RESOLVED;
      if (id === STRINGS) return RESOLVED_STRINGS;
      if (id === ENTRY) {
        load();
        return entry ?? NO_ENTRY;
      }
      return null;
    },
    load(id) {
      if (id === NO_ENTRY) return 'export default null;';
      if (id === RESOLVED_STRINGS) {
        const game = resolved ?? load();
        const dir = stringsDir(loc);
        if (existsSync(dir)) for (const f of readdirSync(dir)) if (/\.ya?ml$/.test(f)) this.addWatchFile(join(dir, f));
        noteYaml();
        return `export default ${JSON.stringify(runtimeStrings(loc, game))};`;
      }
      if (id !== RESOLVED) return null;
      this.addWatchFile(loc.file);
      noteYaml();
      return `export default ${JSON.stringify(load())};`;
    },
    transformIndexHtml(html) {
      if (!title) load();
      const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
      return html.replaceAll('%GP_TITLE%', esc(title)).replaceAll('%GP_BG%', bg).replaceAll('%GP_LANG%', lang);
    },
    handleHotUpdate(ctx) {
      if (opts.frozen) return [];
      // game.yaml, or a strings file (a translation changed): both modules again, and a full reload
      const strings = !relative(stringsDir(loc), ctx.file).startsWith('..') && /\.ya?ml$/.test(ctx.file);
      if (ctx.file === loc.file || strings) {
        invalidateGame(ctx.server);
        ctx.server.ws.send({ type: 'full-reload' });
        return [];
      }
      return undefined;
    },
  };
}
