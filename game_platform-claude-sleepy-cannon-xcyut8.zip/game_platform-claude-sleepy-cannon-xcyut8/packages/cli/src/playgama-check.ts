// gp playgama-check <game>: Playgama's certification, run before the owner runs it. The game plays as its Playgama build
// (the Bridge portal) against a recording fake Bridge served in place of the CDN script; the demo bot plays and the check
// reads what Playgama's QA Tool reads: initialize, game_ready, storage through the Bridge in one call, no localStorage,
// an interstitial at a natural break, a rewarded ad closed early that gives nothing, what the QA Tool's recorder films,
// the pause and audio events obeyed, sign-in offered and hidden once signed in.

import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Page } from 'playwright';
import type { GameLocation } from './paths.ts';

/** How long the demo bot plays waiting for the first interstitial: Playgama's QA plays a short session */
export const PLAYGAMA_CHECK_SEC = 90;

export interface PlaygamaCheckResult {
  checks: { name: string; ok: boolean; detail: string }[];
  file: string;
}

/** The fake Bridge: records every call in window.__pg; ads answer as a player closing them at once */
const FAKE_BRIDGE = `(() => {
  const log = [];
  const handlers = {};
  const on = (k) => (e, f) => ((handlers[k + e] ||= []).push(f));
  const fire = (k, e, v) => (handlers[k + e] || []).forEach((f) => f(v));
  const store = {};
  window.__pg = { log, fire, store };
  window.bridge = {
    initialize: () => (log.push(['initialize']), Promise.resolve()),
    platform: {
      id: 'playgama', language: 'es', isAudioEnabled: true, isPaused: false,
      sendMessage: (m) => (log.push(['message', m]), Promise.resolve()),
      on: on('platform:'), off() {},
    },
    // Sign-in (the QA Tool's Authorization step): signed in survives the page's reload in window.name, as an account would
    player: {
      isAuthorizationSupported: true,
      get isAuthorized() { return window.name === 'gp-signed-in'; },
      name: null,
      authorize: () => (log.push(['authorize']), (window.name = 'gp-signed-in'), Promise.resolve()),
    },
    storage: {
      get: (keys) => (log.push(['storage.get', keys]), Promise.resolve(keys.map((k) => store[k] ?? null))),
      set: (keys, values) => (log.push(['storage.set', keys]), keys.forEach((k, i) => (store[k] = values[i])), Promise.resolve()),
    },
    advertisement: {
      isInterstitialSupported: true, isRewardedSupported: true,
      on: on('ad:'), off() {},
      showInterstitial() {
        log.push(['interstitial']);
        const s = (v, t) => setTimeout(() => fire('ad:', 'interstitial_state_changed', v), t);
        // window.__pg.nofill: Bridge loads for 4 s and finds no fill ('failed'): nothing is ever on screen
        if (window.__pg.nofill) { s('loading', 10); s('failed', 4000); return; }
        s('loading', 10); s('opened', 30); s('closed', 300);
      },
      showRewarded(placement) {
        log.push(['rewarded', placement ?? null]);
        // Closed before completion: never 'rewarded'
        const s = (v, t) => setTimeout(() => fire('ad:', 'rewarded_state_changed', v), t);
        // window.__pg.defer: the Bridge defers or skips the ad after 'loading' and never reports its end (its minimum
        // delay, an ad blocker, no fill) — the game must not wait for it (2026-10-22: frozen until a reload)
        if (window.__pg.defer) { s('loading', 10); return; }
        // window.__pg.adPause: the sandbox's rewarded ad — pause true when it opens, watched, closed, and no pause false
        // ever (2026-10-25: Candle Crypt frozen for good after "Relight (ad)")
        if (window.__pg.adPause) { s('loading', 10); s('opened', 30); setTimeout(() => fire('platform:', 'pause_state_changed', true), 40); s('rewarded', 200); s('closed', 300); return; }
        s('loading', 10); s('opened', 30); s('closed', 300);
      },
    },
  };
})();`;

/** How long the game's start() may take before the check reads what it sets up */
export const START_TIMEOUT_MS = 30000;

/**
 * The game's start() is done: host.loaded() has run (the player calls it when start() resolves), so game_ready has gone
 * out and the host's sign-in button is on its way. host.qaDriver alone isn't that: a game registers it in start() and
 * may then `await` more (its pictures, a font) — reading game_ready then failed the check and the sign-in check with it
 * (Idle Garage Evolution 1.5.1). False when it didn't finish in time
 */
export async function waitStarted(page: Page): Promise<boolean> {
  return page
    .waitForFunction(() => (window as any).__gp?.host?.qaDriver && (window as any).__gp.host.isLoaded === true, null, { timeout: START_TIMEOUT_MS })
    .then(() => true)
    .catch(() => false);
}

export async function playgamaCheck(loc: GameLocation): Promise<PlaygamaCheckResult> {
  const { chromium } = await import('playwright');
  const { buildWeb, servePreview } = await import('./vite.ts');
  // The Playgama build with the test hooks (the demo bot, the host) and the real Bridge portal
  const dist = await buildWeb(loc, 'dev', true, join(loc.dir, 'qa', 'dist-playgama-check'), { portal: 'playgama', realPortal: true });
  const server = await servePreview(loc, dist);
  const url = server.resolvedUrls?.local[0] ?? 'http://127.0.0.1:4173/';
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const checks: PlaygamaCheckResult['checks'] = [];
  const check = (name: string, ok: boolean, detail = '') => checks.push({ name, ok, detail });
  try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
    await page.route('https://bridge.playgama.com/**', (r) => r.fulfill({ contentType: 'text/javascript', body: FAKE_BRIDGE }));
    // Any other host is an external resource Playgama forbids (only the Bridge comes from its CDN)
    const external = new Set<string>();
    const local = new URL(url).host;
    page.on('request', (r) => {
      const h = new URL(r.url()).host;
      if (h && h !== local && h !== 'bridge.playgama.com' && !r.url().startsWith('data:')) external.add(h);
    });
    await page.addInitScript(() => {
      const set = Storage.prototype.setItem;
      (window as unknown as { __ls: string[] }).__ls = [];
      Storage.prototype.setItem = function (k: string, v: string) {
        (window as unknown as { __ls: string[] }).__ls.push(k);
        return set.call(this, k, v);
      };
    });
    await page.goto(`${url}?seed=1`);
    const started = await waitStarted(page);
    const log = () => page.evaluate(() => (window as any).__pg.log as [string, unknown?][]);
    // game_ready follows loadingStop, which follows start(): a moment after it, through the portal's queue
    await page.waitForFunction(() => ((window as any).__pg.log as [string, unknown?][]).some((e) => e[0] === 'message' && e[1] === 'game_ready'), null, { timeout: 3000 }).catch(() => {});

    let l = await log();
    check('Bridge initialized before anything else', l[0]?.[0] === 'initialize', l[0]?.[0] ?? 'no call');
    const gets = l.filter((e) => e[0] === 'storage.get');
    check('Saves load through Bridge storage, all keys in one call', gets.length === 1 && Array.isArray(gets[0]![1]) && (gets[0]![1] as unknown[]).length >= 1, `${gets.length} storage.get call(s)`);
    // The platform's language (the fake Bridge says Spanish, as Playgama's QA Tool sets it): the host must take it once
    // the SDK is up, unless the player picked one in this game (2026-10-24: the QA Tool's Spanish run stayed in English)
    const lang = await page.evaluate(() => ({ lang: (window as any).__gp.host.lang as string, offered: [...(((window as any).__gp.host.i18n?.languages ?? []) as string[])] }));
    if (lang.offered.includes('es')) check('The platform\'s language wins at the first start (Bridge says es)', lang.lang === 'es', `host.lang: ${lang.lang}`);
    else check('The platform\'s language wins at the first start (Bridge says es)', true, `the game has no Spanish (${lang.offered.join(', ') || 'en'}): Playgama's form must not list it`);
    check("game_ready sent once the game can be played", l.some((e) => e[0] === 'message' && e[1] === 'game_ready'), started ? '' : `the game's start() hadn't finished after ${START_TIMEOUT_MS / 1000} s (host.loaded never ran): game_ready follows it`);

    // Play: the player's own tap, then the demo bot
    const play = page.locator('[data-gp=play]').first();
    if (await play.isVisible().catch(() => false)) await play.click();
    else await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
    const demo = await page.evaluate(() => {
      const d = (window as any).__gp.host.qaDriver;
      if (typeof d.demo !== 'function') return false;
      d.demo();
      return true;
    });
    check('The demo bot can play (host.qa({ demo })): the check needs it to reach a natural break', demo);
    const t0 = Date.now();
    let interstitialSec: number | null = null;
    while (Date.now() - t0 < PLAYGAMA_CHECK_SEC * 1000) {
      await page.waitForTimeout(1000);
      if ((await log()).some((e) => e[0] === 'interstitial')) {
        interstitialSec = Math.round((Date.now() - t0) / 1000);
        break;
      }
    }
    const ends = await page.evaluate(() => (window as any).__gp.events.count('round:end') as number);
    check(
      `An interstitial shows at a natural break within ${PLAYGAMA_CHECK_SEC} s of play`,
      interstitialSec !== null,
      interstitialSec !== null
        ? `after ${interstitialSec} s`
        : ends
          ? `none after ${ends} round end(s): the game doesn't call host.adBreak() there, or its own rule holds it back (Playgama's QA fails this)`
          : `the demo bot reached no round end in ${PLAYGAMA_CHECK_SEC} s: Playgama's tester must reach a break as fast — make the first one come sooner`,
    );
    l = await log();
    check('gameplay_started / gameplay_stopped sent', l.some((e) => e[1] === 'gameplay_started') && l.some((e) => e[1] === 'gameplay_stopped'));

    // A rewarded ad closed before the end gives nothing (the player's tap first: rewarded ads follow one)
    // After the interstitial: the host refuses a rewarded ad while another one is on screen
    await page.waitForFunction(() => !(window as any).__gp.host.adPending, null, { timeout: 15000 }).catch(() => {});
    await page.mouse.click(5, 5);
    const rewarded = await page.evaluate(() => (window as any).__gp.host.rewarded('playgama-check'));
    await page.waitForTimeout(1500);
    const after = await log();
    const at = after.findIndex((e) => e[0] === 'rewarded');
    const asked = at >= 0;
    // What the game told the Bridge after the early close: Playgama's QA reads a save or a resumed run there as a reward
    const then = asked ? after.slice(at + 1).map((e) => (e[0] === 'message' ? String(e[1]) : e[0])) : [];
    // The placement reaches the Bridge (bridge.advertisement.rewardedPlacement: the QA Tool logs each request by it)
    const placement = asked ? after[at]![1] : null;
    check('A rewarded ad closed before the end gives no reward (and no gameplay_started right after it); the request names its placement', asked && rewarded === false && !then.includes('gameplay_started') && placement === 'playgama-check', asked ? `host.rewarded → ${rewarded}; placement ${placement === null ? 'none (the Bridge gets null)' : `"${placement}"`}; then: ${then.join(', ') || 'nothing'}` : 'the Bridge was never asked for a rewarded ad');

    // Playgama's QA Tool films the first <canvas> only: after its recorder message that is the mirror (recorder.ts), and
    // it shows the DOM screens too. Without it the result screen above, with its "no reward", is invisible to the QA Tool
    await page.evaluate(() => window.postMessage({ type: 'recorder', action: 'take_screenshot', id: 'playgama-check' }, '*'));
    await page.waitForTimeout(300);
    const shot = await page.evaluate(() => {
      const c = document.querySelector('canvas');
      return c ? { id: c.id, url: c.toDataURL('image/png') } : null;
    });
    const recorderPng = join(loc.dir, 'qa', 'playgama-recorder.png');
    if (shot?.url.startsWith('data:image/png;base64,')) {
      mkdirSync(join(loc.dir, 'qa'), { recursive: true });
      writeFileSync(recorderPng, Buffer.from(shot.url.slice(22), 'base64'));
    }
    check("The QA Tool's recorder films the page, DOM screens included (the first <canvas> is the mirror)", shot?.id === 'gp-recorder' && shot.url.length > 1000, shot ? `first canvas: #${shot.id || '(no id)'}; what it films: qa/playgama-recorder.png` : 'no canvas on the page');

    // Pause and audio from the platform
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'pause_state_changed', true));
    await page.waitForTimeout(200);
    const during = await page.evaluate(() => ({ paused: (window as any).__gp.host.paused as boolean, reasons: [...((window as any).__gp.host.pauseReasons as Set<string>)] }));
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'pause_state_changed', false));
    const paused = during.paused;
    check('pause_state_changed pauses the game', paused);
    // Bridge sends pause_state_changed with every ad it shows: the platform's break ('ad'), not the player leaving
    // ('hidden', which games answer with their pause menu) — as 'hidden' every game stood on its pause menu after each ad
    await page.waitForTimeout(400);
    const afterPause = await page.evaluate(() => ({ paused: (window as any).__gp.host.paused as boolean, playing: (window as any).__gp.host.isPlaying as boolean }));
    check(
      "A platform pause is the platform's break: the game keeps still under it and goes on by itself after it (no pause menu)",
      during.reasons.includes('ad') && !during.reasons.includes('hidden') && !afterPause.paused,
      `reasons during it: ${during.reasons.join(', ') || 'none'}; after it: ${afterPause.paused ? 'still paused' : 'going on'}`,
    );
    // A platform pause holds as long as Bridge keeps it (Playgama's QA Tool opens a system overlay and checks the game
    // stands still: "Platform pause signal ignored" failed a build that let a pause go after 3 s, 2026-10-24)
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'pause_state_changed', true));
    await page.waitForTimeout(10000);
    const stillPaused = await page.evaluate(() => (window as any).__gp.host.paused as boolean);
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'pause_state_changed', false));
    check('A platform pause holds while Bridge keeps it (10 s of a system overlay: the game stands still)', stillPaused, stillPaused ? '' : 'the game went on under the overlay: let a Bridge pause hold until pause_state_changed false (and the game\'s own loop must not wake itself)');
    // An interstitial that loads for 4 s and finds no fill: nothing is on screen, so the game is never held (a tester on
    // the Candle Crypt sandbox, 2026-10-24: "Choose a feat" dead for 5–7 s and silent, "ROOM CLEARED" frozen 2–3 s)
    const nofill = await page.evaluate(async () => {
      const h = (window as any).__gp.host;
      const st = h.ads?.state;
      if (!st) return null;
      st.lastAdSec = null;
      st.roundsSinceAd = 99;
      st.roundsThisSession = 99;
      (window as any).__pg.nofill = true;
      const done = h.adBreak();
      await new Promise((r) => setTimeout(r, 1500));
      const during = { paused: h.paused as boolean, inert: document.querySelectorAll('[inert]').length };
      await done;
      (window as any).__pg.nofill = false;
      return during;
    });
    if (nofill) check("An interstitial still loading (then no fill) doesn't hold the game: not paused, nothing inert", !nofill.paused && nofill.inert === 0, `1.5 s into the load: ${nofill.paused ? 'paused' : 'not paused'}, ${nofill.inert} inert element(s)`);
    // A rewarded ad that pauses the game through Bridge and never lifts the pause: the game goes on after the ad (before
    // the deferred ad below: a rewarded that fails turns rewarded ads off for the session)
    await page.waitForFunction(() => !(window as any).__gp.host.adPending, null, { timeout: 15000 }).catch(() => {});
    await page.mouse.click(5, 5);
    const adPause = await page.evaluate(async () => {
      (window as any).__pg.adPause = true;
      try {
        const r = await Promise.race([(window as any).__gp.host.rewarded('playgama-check-pause'), new Promise((res) => setTimeout(() => res('timeout'), 20000))]);
        await new Promise((res) => setTimeout(res, 500));
        return { r, paused: (window as any).__gp.host.paused as boolean, reasons: [...((window as any).__gp.host.pauseReasons as Set<string>)] };
      } finally {
        (window as any).__pg.adPause = false;
      }
    });
    check("A rewarded ad whose Bridge pause is never lifted (pause true on open, no false after close) doesn't freeze the game", adPause.r === true && !adPause.paused, `host.rewarded → ${String(adPause.r)}; after it: ${adPause.paused ? `still paused (${adPause.reasons.join(', ')}) — build on the current platform (the Playgama adapter ends an ad's pause with the ad)` : 'going on'}`);
    // An ad the Bridge defers after 'loading' and never ends: the game goes on by itself
    await page.waitForFunction(() => !(window as any).__gp.host.adPending, null, { timeout: 15000 }).catch(() => {});
    await page.mouse.click(5, 5);
    const deferredAt = Date.now();
    const deferred = await page.evaluate(async () => {
      (window as any).__pg.defer = true;
      try {
        return await Promise.race([(window as any).__gp.host.rewarded('playgama-check-deferred'), new Promise((r) => setTimeout(() => r('timeout'), 20000))]);
      } finally {
        (window as any).__pg.defer = false;
      }
    });
    const deferredSec = Math.round((Date.now() - deferredAt) / 1000);
    const freed = await page.evaluate(() => !(window as any).__gp.host.adPending && !(window as any).__gp.host.paused);
    check("An ad the Bridge defers after 'loading' (no 'opened', no 'closed') frees the game within ~10 s", deferred === false && freed, deferred === 'timeout' ? 'still waiting after 20 s: build on the current platform (the Playgama adapter gives an ad 10 s to open)' : `host.rewarded → ${String(deferred)} after ${deferredSec} s${freed ? '' : '; the game is still paused or the ad pending'}`);
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'audio_state_changed', false));
    await page.waitForTimeout(200);
    const muted = await page.evaluate(() => (window as any).__gp.host.portalMuted as boolean);
    check('audio_state_changed mutes the game', muted);

    const ls = await page.evaluate(() => (window as any).__ls as string[]);
    check('Nothing written to localStorage (Playgama: storage only)', ls.length === 0, ls.length ? `keys: ${[...new Set(ls)].join(', ')}` : '');
    check('No external resources (only the Bridge from its CDN)', external.size === 0, [...external].join(', '));

    // Sign-in (the QA Tool's Authorization step): a menu offers it where the platform has it, and it is gone once signed in
    // (2026-10-10: "No sign-in option found", "Login button visible for an authorized user")
    await page.evaluate(() => (window as any).__gp.host.gameplay(false));
    const signIn = page.locator('[data-gp="sign-in"]').first();
    await signIn.waitFor({ state: 'visible', timeout: 4000 }).catch(() => {});
    const offered = await signIn.isVisible().catch(() => false);
    // It never lies on the game's own controls, on a phone or a desktop, on any screen the game declares in
    // host.qa({ screens }) (2026-10-10, Rivet Clash at 360×800: it covered "Build & fight" on the robot screen); with no
    // free corner it hides on that screen
    const covered: string[] = [];
    const overText: string[] = [];
    let screens = 0;
    if (offered) {
      const names = await page.evaluate(() => {
        const s = (window as any).__gp.host.qaDriver?.screens;
        return s && typeof s === 'object' ? Object.keys(s).filter((k) => typeof s[k] === 'function') : [];
      });
      const hitTest = () =>
        page.evaluate(() => {
          const b = document.querySelector<HTMLElement>('[data-gp="sign-in"]');
          if (!b || getComputedStyle(b).display === 'none') return null;
          const r = b.getBoundingClientRect();
          for (const el of document.querySelectorAll<HTMLElement>('button,a[href],[role="button"],input,select,textarea')) {
            if (el === b || b.contains(el) || el.contains(b)) continue;
            const o = el.getBoundingClientRect();
            const cs = getComputedStyle(el);
            if (o.width < 1 || o.height < 1 || cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0 || cs.pointerEvents === 'none') continue;
            if (o.width * o.height > innerWidth * innerHeight * 0.5) continue;
            if (r.left < o.right && r.right > o.left && r.top < o.bottom && r.bottom > o.top) return (el.textContent || el.tagName).trim().slice(0, 40);
          }
          // Text it lies on (a HUD counter): reported, not failed — a corner with no free text is allowed
          const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
          const range = document.createRange();
          for (let n = walk.nextNode(); n; n = walk.nextNode()) {
            if (!n.nodeValue?.trim() || b.contains(n)) continue;
            range.selectNodeContents(n);
            const o = range.getBoundingClientRect();
            if (o.width >= 1 && r.left < o.right && r.right > o.left && r.top < o.bottom && r.bottom > o.top) return `text:${n.nodeValue.trim().slice(0, 30)}`;
          }
          return null;
        });
      screens = names.length;
      for (const [w, h] of [[360, 800], [1280, 720]] as const) {
        await page.setViewportSize({ width: w, height: h });
        await page.waitForTimeout(700);
        const hit = await hitTest();
        if (hit) (hit.startsWith('text:') ? overText : covered).push(`${w}×${h} menu: "${hit.replace(/^text:/, '')}"`);
        for (const n of names) {
          const failed = await page
            .evaluate(async (k) => {
              try {
                await (window as any).__gp.host.qaDriver.screens[k]();
                return false;
              } catch {
                return true;
              }
            }, n)
            .catch(() => true);
          if (failed) continue; // gp qa reports a screen that doesn't open
          await page.waitForTimeout(700);
          const on = await hitTest();
          if (on) (on.startsWith('text:') ? overText : covered).push(`${w}×${h} "${n}": "${on.replace(/^text:/, '')}"`);
        }
      }
      // Back to a fresh menu for the sign-in itself: the last declared screen may be one with no free corner (Sigil Clash),
      // where the button rightly hides
      await page.setViewportSize({ width: 1280, height: 720 });
      await page.reload();
      await waitStarted(page);
      await page.evaluate(() => (window as any).__gp.host.gameplay(false)).catch(() => {});
      await signIn.waitFor({ state: 'visible', timeout: 6000 }).catch(() => {});
    }
    check('Sign-in lies on none of the game\'s controls (every declared screen, 360×800 and 1280×720)', covered.length === 0, covered.length ? `covers ${[...new Set(covered)].slice(0, 6).join('; ')} — place your own with signInButton() in the menu` : `the menu and ${screens} declared screen(s)${overText.length ? `; over text (no corner free of it): ${[...new Set(overText)].slice(0, 4).join('; ')}` : ''}`);
    let hidden = false;
    let clicked = false;
    if (offered && (await signIn.isVisible().catch(() => false))) {
      clicked = true;
      await Promise.all([page.waitForEvent('load', { timeout: 15000 }).catch(() => null), signIn.click({ timeout: 10000 }).catch(() => (clicked = false))]);
      await waitStarted(page);
      await page.waitForTimeout(2500);
      hidden = !(await page.locator('[data-gp="sign-in"]').first().isVisible().catch(() => false));
    }
    check('Sign-in offered on the menus and hidden once signed in (the QA Tool\'s Authorization; never required to play)', offered && clicked && hidden, !offered ? 'no [data-gp="sign-in"] on the menu: the host adds one on Playgama builds (autoSignIn) unless the game placed its own with signInButton()' : !clicked ? 'offered, but not visible on the menu after a reload to click it' : hidden ? 'signed in: the button is gone after the reload' : 'still shown after signing in');
  } finally {
    await browser.close();
    await server.close();
  }
  const dir = join(loc.dir, 'qa');
  mkdirSync(dir, { recursive: true });
  const file = join(dir, 'playgama-check.md');
  const lines = checks.map((c) => `- ${c.ok ? '✓' : '✗'} ${c.name}${c.detail ? ` — ${c.detail}` : ''}`);
  writeFileSync(file, `# Playgama certification, checked before the owner runs it\n\n${lines.join('\n')}\n\nNot checked here: the layout at every size and the controls (gp qa does those), and what only a person in Playgama's QA Tool sees.\n`);
  return { checks, file };
}
