// gp art import <dir> [game]: finished pictures the owner supplies (painted cars, side view, on a plain studio background)
// made into game assets the way gp art makes generated ones (docs/guides/art.md § 5.1): the plain background flooded away
// from the borders with a colour tolerance and a soft alpha edge, trimmed, fitted into the asset's size, WebP in
// games/<id>/assets/, the asset in game.yaml `art.assets` (`source: import`) and in provenance.yaml (`source: owner`, the
// original's name and sha256, the date), so gp validate checks it like a generated one. cleanup.json next to the pictures
// overrides per image: a tolerance, a crop box, rectangles to erase or patch (an emblem), wheels to split off as their own
// sprites, a paint mask for colour variants. No key, no network, no image library: the pixels are worked on here in plain
// TypeScript, and decoding, resizing and WebP encoding happen in Playwright's Chromium, as in gp art.

import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { basename, extname, join, resolve } from 'node:path';
import { isMap, isSeq, parseDocument, type YAMLSeq } from 'yaml';
import { artSpec, assetsDir, indexFor, loadProvenance, processImage, sha256, targetSize, writeProvenance, writeThumbs, type ArtAsset, type ArtKind, type ArtRecord } from './art.ts';
import type { Rgba } from './upscale.ts';
import type { GameLocation } from './paths.ts';

type Page = import('playwright').Page;
export type Box = [number, number, number, number];
export type Circle = [number, number, number];

/** One picture's cleanup (cleanup.json: per file name or id, over `defaults`, over the command's flags) */
export interface ImportSettings {
  /** The asset id (default: the file name, slugified) */
  id?: string;
  /** sprite (default), ui, icon: cut out. background, tile, keyart: kept opaque, cropped to fill */
  kind?: ArtKind;
  /** The longest side (cut-outs, never enlarged) or [w, h] (opaque art), in px; default 512 for a sprite */
  size?: number | [number, number];
  /** How far a background pixel may differ from its neighbour, as RGB distance (default 28): raise it for a noisy photo */
  tolerance?: number;
  /** How far the background may drift from the border's colour in all (a gradient, a soft floor shadow): default 4 × tolerance */
  drift?: number;
  /** The background colour (#rrggbb), when the border's median is the wrong one */
  key?: string;
  /** [x, y, w, h] of the picture to keep, in the original's pixels: everything else goes first */
  crop?: Box;
  /** Rectangles made transparent after the cut-out ([x, y, w, h], original pixels): a logo on the backdrop, a stand */
  erase?: Box[];
  /** Rectangles painted over from their surroundings before the cut-out: an emblem or a badge on the body */
  patch?: Box[];
  /** Vehicles: the wheels cut out as sprites of their own, [cx, cy, r] in the original's pixels — the body keeps the arches */
  split?: { wheels: Circle[] };
  /** A paint mask of the body's dominant hue (<id>-paint), to tint for colour variants; `tolerance` in degrees (default 18) */
  recolor?: boolean | { tolerance?: number };
  /** What game.yaml says the image shows (default: the owner's file name) */
  prompt?: string;
  /** When it loads (game.yaml art.assets[].chapter): 0 before Play, 1, 2 … after it; its wheels and paint mask follow it */
  chapter?: number;
}
const SETTING_KEYS = ['id', 'kind', 'size', 'tolerance', 'drift', 'key', 'crop', 'erase', 'patch', 'split', 'recolor', 'prompt', 'chapter'];

export const CLEANUP_FILE = 'cleanup.json';
export const DEFAULT_TOLERANCE = 28;
/** The default bound of an imported sprite: an owner's finished picture is usually drawn big */
export const IMPORT_SIZE = 512;
/** The long side the pixels are worked on at (a 6000 px photo is brought down to it first) */
export const WORK_MAX = 2048;
const HUE_TOLERANCE = 18;
const IMAGE = /\.(png|jpe?g|webp)$/i;
/** game.yaml `art.style` when import makes the section: the look the owner's pictures set */
export const IMPORT_STYLE = "the owner's own finished pictures (gp art import): every new asset matches their look";
const IMPORTED_BY = "the owner's picture (gp art import)";

// --- Pixels (pure, on RGBA) ------------------------------------------------------------------------------------------

const rgba = (w: number, h: number): Rgba => ({ w, h, d: new Uint8ClampedArray(w * h * 4) });
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const dist3 = (r: number, g: number, b: number, k: ArrayLike<number>, o = 0) => Math.sqrt((r - k[o]!) ** 2 + (g - k[o + 1]!) ** 2 + (b - k[o + 2]!) ** 2);

export function hexColor(hex: string): [number, number, number] {
  const v = parseInt(hex.replace('#', '').padEnd(6, '0').slice(0, 6), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}

export interface Cutout {
  im: Rgba;
  /** The background colour found (the border's median) */
  key: [number, number, number];
  /** The share of the picture made transparent */
  removed: number;
  /** The share of the border that is the background: low means the backdrop isn't plain, or the subject touches the edge */
  borderPlain: number;
}

/**
 * The plain background flooded away from the borders: a pixel joins it when it is within `tolerance` of the background
 * it was reached from (a running average, so a gradient or a soft shadow is followed but an edge stops it) and within
 * `drift` of the border's colour; already-transparent pixels are background. The subject's pixels touching it get a soft alpha
 * (how much of the local background they are mixed with), and that colour taken out of them (no light halo). The backdrop inside
 * the subject (not reached from the border) stays.
 */
export function removeBackground(src: Rgba, o: { tolerance?: number; drift?: number; key?: [number, number, number] } = {}): Cutout {
  const { w, h, d } = src;
  const n = w * h;
  const tol = o.tolerance ?? DEFAULT_TOLERANCE;
  const drift = o.drift ?? tol * 4;
  const border: number[] = [];
  for (let x = 0; x < w; x++) border.push(x, (h - 1) * w + x);
  for (let y = 1; y < h - 1; y++) border.push(y * w, y * w + w - 1);
  const opaqueBorder = border.filter((i) => d[i * 4 + 3]! >= 8);
  const med = (c: number) => {
    const v = opaqueBorder.map((i) => d[i * 4 + c]!).sort((a, b) => a - b);
    return v.length ? v[v.length >> 1]! : 255;
  };
  const key: [number, number, number] = o.key ?? [med(0), med(1), med(2)];
  const isKey = (p: number) => d[p + 3]! < 8 || dist3(d[p]!, d[p + 1]!, d[p + 2]!, key) <= drift;
  const borderPlain = border.length ? border.filter((i) => isKey(i * 4)).length / border.length : 0;

  const bg = new Uint8Array(n);
  const ref = new Float32Array(n * 3);
  const q = new Int32Array(n);
  let qt = 0;
  for (const i of border) {
    const p = i * 4;
    if (bg[i] || !isKey(p)) continue;
    bg[i] = 1;
    if (d[p + 3]! < 8) ref.set(key, i * 3);
    else ref.set([d[p]!, d[p + 1]!, d[p + 2]!], i * 3);
    q[qt++] = i;
  }
  for (let qh = 0; qh < qt; qh++) {
    const i = q[qh]!;
    const x = i % w, y = (i / w) | 0;
    const r0 = ref[i * 3]!, g0 = ref[i * 3 + 1]!, b0 = ref[i * 3 + 2]!;
    for (const j of [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1]) {
      if (j < 0 || bg[j]) continue;
      const p = j * 4;
      if (d[p + 3]! < 8) {
        ref[j * 3] = r0; ref[j * 3 + 1] = g0; ref[j * 3 + 2] = b0;
      } else {
        const r = d[p]!, g = d[p + 1]!, b = d[p + 2]!;
        if (Math.sqrt((r - r0) ** 2 + (g - g0) ** 2 + (b - b0) ** 2) > tol || dist3(r, g, b, key) > drift) continue;
        ref[j * 3] = r0 + 0.25 * (r - r0); ref[j * 3 + 1] = g0 + 0.25 * (g - g0); ref[j * 3 + 2] = b0 + 0.25 * (b - b0);
      }
      bg[j] = 1;
      q[qt++] = j;
    }
  }

  // The edge: subject pixels touching the background. Each is read as a mix of the local background B and the nearest
  // inner subject colour F (P = a·F + (1 − a)·B, a by projection) when it lies between them; a low-contrast edge by its
  // distance from B. Then B is taken out of its colour, so a light backdrop leaves no halo
  const out = new Uint8ClampedArray(d);
  const edge = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    if (bg[i]) continue;
    const x = i % w, y = (i / w) | 0;
    for (let yy = Math.max(0, y - 1); yy <= Math.min(h - 1, y + 1) && !edge[i]; yy++)
      for (let xx = Math.max(0, x - 1); xx <= Math.min(w - 1, x + 1); xx++) if (bg[yy * w + xx]) { edge[i] = 1; break; }
  }
  const lo = tol * 0.5, hi = tol * 2.5;
  for (let i = 0; i < n; i++) {
    if (bg[i]) {
      out[i * 4 + 3] = 0;
      continue;
    }
    if (!edge[i]) continue;
    const x = i % w, y = (i / w) | 0;
    const p = i * 4;
    let br = 0, bgc = 0, bb = 0, k = 0;
    for (let yy = Math.max(0, y - 1); yy <= Math.min(h - 1, y + 1); yy++)
      for (let xx = Math.max(0, x - 1); xx <= Math.min(w - 1, x + 1); xx++) {
        const j = yy * w + xx;
        if (!bg[j]) continue;
        br += ref[j * 3]!; bgc += ref[j * 3 + 1]!; bb += ref[j * 3 + 2]!; k++;
      }
    const B = [br / k, bgc / k, bb / k];
    // F: the inner subject pixel within 2 px farthest from the background
    let F: number[] | null = null, fd = -1;
    for (let yy = Math.max(0, y - 2); yy <= Math.min(h - 1, y + 2); yy++)
      for (let xx = Math.max(0, x - 2); xx <= Math.min(w - 1, x + 2); xx++) {
        const j = yy * w + xx;
        if (bg[j] || edge[j]) continue;
        const dj = dist3(d[j * 4]!, d[j * 4 + 1]!, d[j * 4 + 2]!, B);
        if (dj > fd) { fd = dj; F = [d[j * 4]!, d[j * 4 + 1]!, d[j * 4 + 2]!]; }
      }
    let a: number;
    const fb = F ? [F[0]! - B[0]!, F[1]! - B[1]!, F[2]! - B[2]!] : null;
    const l2 = fb ? fb[0]! ** 2 + fb[1]! ** 2 + fb[2]! ** 2 : 0;
    if (fb && l2 >= (2 * tol) ** 2) {
      const pb = [d[p]! - B[0]!, d[p + 1]! - B[1]!, d[p + 2]! - B[2]!];
      a = clamp01((pb[0]! * fb[0]! + pb[1]! * fb[1]! + pb[2]! * fb[2]!) / l2);
      const res = Math.sqrt((pb[0]! - a * fb[0]!) ** 2 + (pb[1]! - a * fb[1]!) ** 2 + (pb[2]! - a * fb[2]!) ** 2);
      // Not on the line from B to F: a colour of its own (an outline, a highlight), kept
      if (res > Math.max(tol, 0.25 * Math.sqrt(l2))) a = 1;
    } else {
      const t = clamp01((dist3(d[p]!, d[p + 1]!, d[p + 2]!, B) - lo) / (hi - lo));
      a = t * t * (3 - 2 * t);
    }
    if (a >= 1) continue;
    out[p + 3] = Math.round(d[p + 3]! * a);
    if (a > 0.05) for (let c = 0; c < 3; c++) out[p + c] = (d[p + c]! - (1 - a) * B[c]!) / a;
  }
  let removed = 0;
  for (let i = 0; i < n; i++) if (out[i * 4 + 3]! < 8) removed++;
  return { im: { w, h, d: out }, key, removed: removed / n, borderPlain };
}

const clipBox = (im: Rgba, [x, y, bw, bh]: Box): [number, number, number, number] => {
  const x0 = Math.max(0, Math.round(x)), y0 = Math.max(0, Math.round(y));
  return [x0, y0, Math.min(im.w, Math.round(x + bw)), Math.min(im.h, Math.round(y + bh))];
};

/** Rectangles made transparent (in place) */
export function eraseRects(im: Rgba, boxes: Box[]): void {
  for (const b of boxes) {
    const [x0, y0, x1, y1] = clipBox(im, b);
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) im.d[(y * im.w + x) * 4 + 3] = 0;
  }
}

/**
 * Rectangles painted over from the pixels around them (in place): each pixel blends the row's left and right neighbours
 * and the column's top and bottom ones, the nearer weighing more — an emblem on a flat or softly shaded body disappears
 */
export function patchRects(im: Rgba, boxes: Box[]): void {
  const { w, d } = im;
  for (const b of boxes) {
    const [bx0, by0, bx1, by1] = clipBox(im, b);
    // The surrounding ring must exist: keep one pixel of the picture on every side
    const x0 = Math.max(1, bx0), y0 = Math.max(1, by0), x1 = Math.min(im.w - 1, bx1), y1 = Math.min(im.h - 1, by1);
    if (x1 <= x0 || y1 <= y0) continue;
    const src = d.slice();
    const at = (x: number, y: number, c: number) => src[(y * w + x) * 4 + c]!;
    for (let y = y0; y < y1; y++)
      for (let x = x0; x < x1; x++) {
        const fx = (x - x0 + 1) / (x1 - x0 + 1), fy = (y - y0 + 1) / (y1 - y0 + 1);
        const wh = 1 / Math.min(x - x0 + 1, x1 - x), wv = 1 / Math.min(y - y0 + 1, y1 - y);
        for (let c = 0; c < 4; c++) {
          const hz = at(x0 - 1, y, c) * (1 - fx) + at(x1, y, c) * fx;
          const vt = at(x, y0 - 1, c) * (1 - fy) + at(x, y1, c) * fy;
          d[(y * w + x) * 4 + c] = (hz * wh + vt * wv) / (wh + wv);
        }
      }
  }
}

/** The box around what is visible (alpha ≥ 16, as gp art trims), with a margin; null when nothing is */
export function trimBox(im: Rgba, margin = 2): Box | null {
  let x0 = im.w, y0 = im.h, x1 = -1, y1 = -1;
  for (let y = 0; y < im.h; y++)
    for (let x = 0; x < im.w; x++)
      if (im.d[(y * im.w + x) * 4 + 3]! >= 16) {
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
  if (x1 < 0) return null;
  x0 = Math.max(0, x0 - margin); y0 = Math.max(0, y0 - margin); x1 = Math.min(im.w - 1, x1 + margin); y1 = Math.min(im.h - 1, y1 + margin);
  return [x0, y0, x1 - x0 + 1, y1 - y0 + 1];
}

/** A rectangle of a picture (outside it: transparent) */
export function subImage(im: Rgba, [x0, y0, bw, bh]: Box): Rgba {
  const o = rgba(bw, bh);
  for (let y = 0; y < bh; y++)
    for (let x = 0; x < bw; x++) {
      const sx = x0 + x, sy = y0 + y;
      if (sx < 0 || sy < 0 || sx >= im.w || sy >= im.h) continue;
      o.d.set(im.d.subarray((sy * im.w + sx) * 4, (sy * im.w + sx) * 4 + 4), (y * bw + x) * 4);
    }
  return o;
}

/**
 * A circle cut out of a picture: returned as a square sprite with the circle's centre at its centre (so it turns on the
 * spot), and taken out of the picture (in place) with the same soft edge — the wheel and its arch fit back together
 */
export function cutCircle(im: Rgba, [cx, cy, r]: Circle): { part: Rgba; centre: [number, number] } {
  const R = Math.ceil(r) + 1, icx = Math.round(cx), icy = Math.round(cy), side = 2 * R + 1;
  const part = rgba(side, side);
  for (let y = 0; y < side; y++)
    for (let x = 0; x < side; x++) {
      const sx = icx - R + x, sy = icy - R + y;
      if (sx < 0 || sy < 0 || sx >= im.w || sy >= im.h) continue;
      const cov = clamp01(r + 0.5 - Math.hypot(sx - cx, sy - cy));
      if (!cov) continue;
      const p = (sy * im.w + sx) * 4, o = (y * side + x) * 4;
      part.d.set(im.d.subarray(p, p + 3), o);
      part.d[o + 3] = im.d[p + 3]! * cov;
      im.d[p + 3] = im.d[p + 3]! * (1 - cov);
    }
  return { part, centre: [icx, icy] };
}

function hsv(r: number, g: number, b: number): [number, number, number] {
  const max = Math.max(r, g, b), min = Math.min(r, g, b), c = max - min;
  let h = 0;
  if (c) h = max === r ? ((g - b) / c + 6) % 6 : max === g ? (b - r) / c + 2 : (r - g) / c + 4;
  return [h * 60, max ? c / max : 0, max / 255];
}
const hueDist = (a: number, b: number) => Math.abs(((a - b + 540) % 360) - 180);

/**
 * The paint mask: the body's dominant hue (the peak of a 10° histogram of its saturated pixels), and every pixel of that
 * hue as grey (its brightness) with the alpha of how much it is that hue. Tinted by multiplying with a colour and drawn
 * over the body, it repaints the car and keeps its shading; the glass, tyres, chrome and outlines stay.
 */
export function paintMask(im: Rgba, tolerance = HUE_TOLERANCE): { mask: Rgba; hue: number | null; share: number } {
  const n = im.w * im.h;
  const hist = new Float64Array(36);
  let opaque = 0;
  const hs = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const p = i * 4;
    const [hh, s, v] = hsv(im.d[p]!, im.d[p + 1]!, im.d[p + 2]!);
    hs[i * 3] = hh; hs[i * 3 + 1] = s; hs[i * 3 + 2] = v;
    if (im.d[p + 3]! < 200) continue;
    opaque++;
    if (s >= 0.25 && v >= 0.2) hist[Math.floor(hh / 10) % 36] += 1;
  }
  const mask = rgba(im.w, im.h);
  const peak = hist.indexOf(Math.max(...hist));
  if (!hist[peak]) return { mask, hue: null, share: 0 };
  // The circular mean of the hues near the peak
  let sx = 0, sy = 0;
  for (let i = 0; i < n; i++) {
    if (im.d[i * 4 + 3]! < 200 || hs[i * 3 + 1]! < 0.25 || hs[i * 3 + 2]! < 0.2 || hueDist(hs[i * 3]!, peak * 10 + 5) > 15) continue;
    sx += Math.cos((hs[i * 3]! * Math.PI) / 180);
    sy += Math.sin((hs[i * 3]! * Math.PI) / 180);
  }
  const hue = ((Math.atan2(sy, sx) * 180) / Math.PI + 360) % 360;
  let inMask = 0;
  for (let i = 0; i < n; i++) {
    const p = i * 4;
    const m = clamp01((tolerance + 8 - hueDist(hs[i * 3]!, hue)) / 8) * clamp01((hs[i * 3 + 1]! - 0.12) / 0.13);
    const a = im.d[p + 3]! * m;
    if (!a) continue;
    const grey = Math.round(hs[i * 3 + 2]! * 255);
    mask.d[p] = grey; mask.d[p + 1] = grey; mask.d[p + 2] = grey; mask.d[p + 3] = a;
    if (a >= 128) inMask++;
  }
  return { mask, hue: Math.round(hue), share: opaque ? inMask / opaque : 0 };
}

/** A file name as an asset id: "Red Car (final).PNG" → red-car-final (room left for -wheel-N and -paint) */
export function slugId(file: string): string {
  let s = basename(file, extname(file)).normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  if (!/^[a-z]/.test(s)) s = `img-${s}`;
  s = s.slice(0, 31).replace(/-+$/, '');
  return s.length >= 2 ? s : `${s}-img`;
}

// --- The browser: decode, resize, encode -----------------------------------------------------------------------------

const MIME: Record<string, string> = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp' };

/** A picture as RGBA: cropped in its own pixels, then brought down to `max` on the long side (`scale`: working px per original px) */
export async function decodeImage(page: Page, file: string, crop: Box | undefined, max = WORK_MAX): Promise<{ im: Rgba; scale: number; size: [number, number] }> {
  const r = await page.evaluate(
    async ({ src, crop, max }) => {
      const img = new Image();
      img.src = src;
      await img.decode();
      const W = img.naturalWidth, H = img.naturalHeight;
      const [x, y, w, h] = crop ? [Math.max(0, crop[0]), Math.max(0, crop[1]), Math.min(crop[2], W - Math.max(0, crop[0])), Math.min(crop[3], H - Math.max(0, crop[1]))] : [0, 0, W, H];
      const s = Math.min(1, max / Math.max(w, h));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(w * s));
      c.height = Math.max(1, Math.round(h * s));
      const g = c.getContext('2d', { willReadFrequently: true })!;
      g.imageSmoothingQuality = 'high';
      g.drawImage(img, x, y, w, h, 0, 0, c.width, c.height);
      const bytes = new Uint8Array(g.getImageData(0, 0, c.width, c.height).data.buffer);
      let bin = '';
      for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      return { w: c.width, h: c.height, b64: btoa(bin), s, W, H };
    },
    { src: `data:${MIME[extname(file).toLowerCase()] ?? 'image/png'};base64,${readFileSync(file).toString('base64')}`, crop: crop ?? null, max },
  );
  return { im: { w: r.w, h: r.h, d: new Uint8ClampedArray(Buffer.from(r.b64, 'base64')) }, scale: r.s, size: [r.W, r.H] };
}

/** RGBA resized to ow × oh (high-quality smoothing) and encoded: WebP at `quality`, or PNG */
export async function encodeImage(page: Page, im: Rgba, ow: number, oh: number, type: 'image/webp' | 'image/png' = 'image/webp', quality = 0.86): Promise<Buffer> {
  const b64 = await page.evaluate(
    ({ w, h, b64, ow, oh, type, quality }) => {
      const bin = atob(b64);
      const px = new Uint8ClampedArray(bin.length);
      for (let i = 0; i < bin.length; i++) px[i] = bin.charCodeAt(i);
      const c = document.createElement('canvas');
      c.width = w;
      c.height = h;
      c.getContext('2d')!.putImageData(new ImageData(px, w, h), 0, 0);
      const o = document.createElement('canvas');
      o.width = ow;
      o.height = oh;
      const g = o.getContext('2d')!;
      g.imageSmoothingQuality = 'high';
      g.drawImage(c, 0, 0, ow, oh);
      return o.toDataURL(type, quality).split(',')[1]!;
    },
    { w: im.w, h: im.h, b64: Buffer.from(im.d.buffer, im.d.byteOffset, im.d.byteLength).toString('base64'), ow, oh, type, quality },
  );
  return Buffer.from(b64, 'base64');
}

// --- The run ---------------------------------------------------------------------------------------------------------

export interface ImportOptions {
  /** cleanup.json (default: <dir>/cleanup.json when it exists) */
  cleanup?: string;
  /** Flags under cleanup.json: size, kind, tolerance, recolor for every picture */
  size?: number;
  kind?: ArtKind;
  tolerance?: number;
  recolor?: boolean;
  /** Every picture's chapter (under cleanup.json's): 0 before Play, 1, 2 … after it */
  chapter?: number;
  /** Import again even when nothing changed */
  force?: boolean;
  log?: (s: string) => void;
}
export interface ImportResult {
  made: string[];
  kept: string[];
  removed: string[];
  warnings: string[];
  /** qa/art-import.png: every cut-out on a checkerboard, with its parts put back and its paint mask tinted */
  preview: string | null;
}

/** cleanup.json: `defaults` and one entry per picture (its file name or its id) */
export function loadCleanup(file: string | undefined): { defaults: ImportSettings; images: Record<string, ImportSettings> } {
  if (!file || !existsSync(file)) return { defaults: {}, images: {} };
  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(file, 'utf8'));
  } catch (e) {
    throw new Error(`${basename(file)}: not JSON (${(e as Error).message})`);
  }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error(`${basename(file)}: an object of pictures, e.g. { "defaults": { "tolerance": 30 }, "red-car.png": { "crop": [0, 0, 1800, 900] } }`);
  const { defaults = {}, ...images } = raw as Record<string, ImportSettings>;
  for (const [k, v] of Object.entries({ defaults, ...images })) {
    const bad = Object.keys(v ?? {}).filter((x) => !SETTING_KEYS.includes(x));
    if (bad.length) throw new Error(`${basename(file)}: "${k}" has unknown setting(s) ${bad.join(', ')} — the settings are ${SETTING_KEYS.join(', ')}`);
    const boxes = [...(v.crop ? [v.crop] : []), ...(v.erase ?? []), ...(v.patch ?? [])];
    if (boxes.some((b) => !Array.isArray(b) || b.length !== 4 || b.some((n) => typeof n !== 'number')) || (v.crop && (v.crop[2] <= 0 || v.crop[3] <= 0)))
      throw new Error(`${basename(file)}: "${k}": crop, erase and patch are [x, y, w, h] in the original's pixels`);
    if (v.split && (!Array.isArray(v.split.wheels) || v.split.wheels.some((c) => !Array.isArray(c) || c.length !== 3 || c.some((n) => typeof n !== 'number') || c[2] <= 0)))
      throw new Error(`${basename(file)}: "${k}": split.wheels is a list of [cx, cy, r] in the original's pixels`);
    if (v.id !== undefined && !/^[a-z][a-z0-9-]{1,39}$/.test(v.id)) throw new Error(`${basename(file)}: "${k}": id "${v.id}" — lowercase letters, digits and dashes, starting with a letter`);
    if (v.chapter !== undefined && !(Number.isInteger(v.chapter) && v.chapter >= 0 && v.chapter <= 9)) throw new Error(`${basename(file)}: "${k}": chapter is a whole number 0–9 (0: before Play)`);
  }
  return { defaults, images };
}

const OPAQUE = new Set<ArtKind>(['background', 'tile', 'keyart']);
const cropAt = (crop: Box | undefined, i: 0 | 1) => Math.max(0, crop?.[i] ?? 0);
const scaleBox = (b: Box, crop: Box | undefined, s: number): Box => [(b[0] - cropAt(crop, 0)) * s, (b[1] - cropAt(crop, 1)) * s, b[2] * s, b[3] * s];
const r1 = (v: number) => Math.round(v * 10) / 10;

export async function importArt(loc: GameLocation, dir: string, opts: ImportOptions = {}): Promise<ImportResult> {
  const src = resolve(dir);
  if (!existsSync(src) || !statSync(src).isDirectory()) throw new Error(`art import: no folder ${dir} — the owner's pictures go in a folder (PNG, JPEG or WebP), with an optional ${CLEANUP_FILE}`);
  const files = readdirSync(src).filter((f) => IMAGE.test(f)).sort();
  if (!files.length) throw new Error(`art import: no PNG, JPEG or WebP pictures in ${dir}`);
  const spec0 = artSpec(loc);
  if (spec0?.technique === 'pixel') throw new Error("art import makes painted WebP sprites; this game's art is `technique: pixel` — take pixel art with an asset's `from` (gp art), which snaps it to the palette");
  const cleanupFile = opts.cleanup ? resolve(opts.cleanup) : join(src, CLEANUP_FILE);
  if (opts.cleanup && !existsSync(cleanupFile)) throw new Error(`art import: no ${opts.cleanup}`);
  const cleanup = loadCleanup(cleanupFile);
  const log = opts.log ?? (() => {});
  const res: ImportResult = { made: [], kept: [], removed: [], warnings: [], preview: null };
  const known = new Set(files.flatMap((f) => [f, slugId(f)]));
  for (const k of Object.keys(cleanup.images)) if (!known.has(k)) res.warnings.push(`${CLEANUP_FILE}: "${k}" is none of the pictures (by file name or id): ${files.join(', ')}`);

  const text = readFileSync(loc.file, 'utf8');
  const seq0 = parseDocument(text).getIn(['art', 'assets']);
  const before = (isSeq(seq0) ? seq0.items : []).map((it) => (isMap(it) ? (it.toJSON() as ArtAsset) : null));
  const entries = () => before;
  const upserts = new Map<string, ArtAsset>();
  const removals: string[] = [];
  const prov = loadProvenance(loc);
  const out = assetsDir(loc);
  mkdirSync(out, { recursive: true });
  const date = new Date().toISOString().slice(0, 10);
  const flags: ImportSettings = { ...(opts.size ? { size: opts.size } : {}), ...(opts.kind ? { kind: opts.kind } : {}), ...(opts.tolerance ? { tolerance: opts.tolerance } : {}), ...(opts.recolor ? { recolor: true } : {}), ...(opts.chapter !== undefined ? { chapter: opts.chapter } : {}) };

  // Every picture's id first: two pictures may not become one asset, and a generated asset is never overwritten
  const plan = files.map((f) => {
    const s: ImportSettings = { ...cleanup.defaults, ...flags, ...(cleanup.images[f] ?? cleanup.images[slugId(f)] ?? {}) };
    return { file: f, s, id: s.id ?? slugId(f) };
  });
  const seen = new Map<string, string>();
  for (const p of plan) {
    if (seen.has(p.id)) throw new Error(`art import: ${seen.get(p.id)} and ${p.file} both become "${p.id}" — give one an "id" in ${CLEANUP_FILE}`);
    seen.set(p.id, p.file);
    const other = entries().find((a) => a?.id === p.id && a.source !== 'import');
    if (other) throw new Error(`art import: game.yaml already has an art asset "${p.id}" that isn't imported (kind ${other.kind}) — give the picture another "id" in ${CLEANUP_FILE}, or remove that asset`);
  }

  const { chromium } = await import('playwright');
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const shown: { body: Buffer; parts: { img: Buffer; at: [number, number] }[]; mask: Buffer | null; hue: number | null; id: string }[] = [];
  let written = false;
  try {
    const page = await browser.newPage();
    await page.setContent('<body></body>');
    for (const { file, s, id } of plan) {
      const path = join(src, file);
      const original = readFileSync(path);
      const originalSha256 = sha256(original);
      const existing = entries().find((a) => a?.id === id) ?? undefined;
      const kind: ArtKind = s.kind ?? existing?.kind ?? 'sprite';
      const opaque = OPAQUE.has(kind);
      const size = s.size ?? existing?.size ?? (kind === 'sprite' ? IMPORT_SIZE : undefined);
      const bound = targetSize({ id, kind, prompt: '', size });
      const recolor = !!s.recolor && !opaque;
      const hueTol = typeof s.recolor === 'object' ? (s.recolor.tolerance ?? HUE_TOLERANCE) : HUE_TOLERANCE;
      const settings = JSON.stringify({ kind, size: size ?? bound, tolerance: s.tolerance ?? DEFAULT_TOLERANCE, ...Object.fromEntries(['drift', 'key', 'crop', 'erase', 'patch', 'split', 'recolor'].filter((k) => s[k as keyof ImportSettings] !== undefined).map((k) => [k, s[k as keyof ImportSettings]])) });
      const wheels = opaque ? [] : (s.split?.wheels ?? []);
      if (opaque && (s.split || s.recolor)) res.warnings.push(`${file}: split and recolor are for cut-out sprites, not a ${kind} — ignored`);
      const partIds = [...wheels.map((_, i) => `${id}-wheel-${i + 1}`), ...(recolor ? [`${id}-paint`] : [])];
      const bodyFile = `${id}.webp`;
      const rec = prov.files[bodyFile];
      const current = (f: string) => existsSync(join(out, f)) && prov.files[f]?.sha256 === sha256(readFileSync(join(out, f)));
      const staleParts = entries().filter((a) => a?.source === 'import' && a.part?.of === id && !partIds.includes(a.id)).map((a) => a!.id);
      // The chapter is game.yaml's, not the picture's: a new one is written without importing the picture again
      const chapter = s.chapter === undefined ? {} : { chapter: s.chapter || undefined };
      if (!opts.force && rec?.source === 'owner' && rec.originalSha256 === originalSha256 && rec.cleanup === settings && [bodyFile, ...partIds.map((p) => `${p}.webp`)].every(current) && !staleParts.length) {
        res.kept.push(bodyFile, ...partIds.map((p) => `${p}.webp`));
        if (existing && 'chapter' in chapter && existing.chapter !== chapter.chapter) upserts.set(id, { ...existing, ...chapter });
        continue;
      }
      log(`${file} → ${id} (${kind}) …`);
      const { im: work, scale: ws, size: [W, H] } = await decodeImage(page, path, s.crop);
      const toWork = (b: Box) => scaleBox(b, s.crop, ws);
      if (s.patch?.length) patchRects(work, s.patch.map(toWork));
      const base = { kind, model: IMPORTED_BY, style: null, date, source: 'owner', original: file, originalSha256, cleanup: settings } as const;
      const record = (f: string, buf: Buffer, sz: [number, number], prompt: string, extra: Partial<ArtRecord> = {}) => {
        writeFileSync(join(out, f), buf);
        prov.files[f] = { ...base, prompt, size: sz, bytes: buf.length, sha256: sha256(buf), ...extra };
        res.made.push(f);
      };
      const prompt = s.prompt ?? existing?.prompt ?? `the owner's picture ${file}`;
      // An entry already in game.yaml keeps its other fields and its prompt (unless cleanup.json gives one)
      const upsert = (entry: ArtAsset) => {
        const old = before.find((a) => a?.id === entry.id);
        upserts.set(entry.id, { ...old, ...entry, ...(old?.prompt && !s.prompt ? { prompt: old.prompt } : {}) });
      };
      if (opaque) {
        const png = await encodeImage(page, work, work.w, work.h, 'image/png');
        const p = await processImage(page, png, kind, bound, 0.86, undefined, false);
        record(bodyFile, p.webp, p.size, prompt);
        upsert({ id, kind, source: 'import', prompt, ...(size !== undefined ? { size } : {}), ...chapter });
      } else {
        const cut = removeBackground(work, { tolerance: s.tolerance, drift: s.drift, key: s.key ? hexColor(s.key) : undefined });
        if (cut.borderPlain < 0.6) res.warnings.push(`${file}: only ${Math.round(cut.borderPlain * 100)} % of the border is the background colour — a backdrop that isn't plain, or the subject touching the edge: check the cut-out, raise "tolerance", give "key" or a "crop" in ${CLEANUP_FILE}`);
        if (cut.removed < 0.05) res.warnings.push(`${file}: almost nothing was removed (${Math.round(cut.removed * 100)} %) — is the background plain? raise "tolerance" or give its colour as "key" in ${CLEANUP_FILE}`);
        const im = cut.im;
        if (s.erase?.length) eraseRects(im, s.erase.map(toWork));
        const parts = wheels.map(([cx, cy, r]) => cutCircle(im, [(cx - cropAt(s.crop, 0)) * ws, (cy - cropAt(s.crop, 1)) * ws, r * ws]));
        const box = trimBox(im);
        if (!box) throw new Error(`${file}: nothing left after the cut-out — the subject is as light as the backdrop: lower "tolerance" or give "key" in ${CLEANUP_FILE}`);
        const body = subImage(im, box);
        const k = Math.min(1, bound[0] / body.w, bound[1] / body.h);
        const ow = Math.max(1, Math.round(body.w * k)), oh = Math.max(1, Math.round(body.h * k));
        const scale = +(k * ws).toFixed(5);
        record(bodyFile, await encodeImage(page, body, ow, oh), [ow, oh], prompt, { scale });
        upsert({ id, kind, source: 'import', prompt, ...(size !== undefined ? { size } : {}), ...chapter });
        const view = { body: readFileSync(join(out, bodyFile)), parts: [] as { img: Buffer; at: [number, number] }[], mask: null as Buffer | null, hue: null as number | null, id };
        for (const [i, { part, centre }] of parts.entries()) {
          const pid = `${id}-wheel-${i + 1}`;
          const side = Math.max(1, Math.round(part.w * k));
          const at: [number, number] = [r1(((centre[0] + 0.5 - box[0]) * ow) / body.w), r1(((centre[1] + 0.5 - box[1]) * oh) / body.h)];
          const pprompt = `wheel ${i + 1} of ${id}, cut from ${file}`;
          const buf = await encodeImage(page, part, side, side);
          record(`${pid}.webp`, buf, [side, side], pprompt, { scale });
          upsert({ id: pid, kind: 'sprite', source: 'import', prompt: pprompt, part: { of: id, at } });
          view.parts.push({ img: buf, at });
        }
        if (recolor) {
          const m = paintMask(body, hueTol);
          if (m.hue === null || m.share < 0.05) res.warnings.push(`${file}: no dominant paint colour (${Math.round(m.share * 100)} % of the body) — the mask is ${m.hue === null ? 'empty' : 'thin'}; a grey or black car has no hue to shift`);
          const mprompt = `the paint mask of ${id}${m.hue === null ? '' : ` (hue ${m.hue}°)`}: tint it and draw it over ${id} for a paint variant`;
          const buf = await encodeImage(page, m.mask, ow, oh);
          record(`${id}-paint.webp`, buf, [ow, oh], mprompt, { scale, ...(m.hue === null ? {} : { hue: m.hue }) });
          upsert({ id: `${id}-paint`, kind: 'sprite', source: 'import', prompt: mprompt, part: { of: id, at: [r1(ow / 2), r1(oh / 2)] } });
          view.mask = buf;
          view.hue = m.hue;
        }
        shown.push(view);
        log(`  ${W}×${H} → ${ow}×${oh}, background ${'#' + cut.key.map((c) => c.toString(16).padStart(2, '0')).join('')} (${Math.round(cut.removed * 100)} % removed)${parts.length ? `, ${parts.length} wheel(s)` : ''}${recolor ? ', paint mask' : ''}`);
      }
      // Parts this picture no longer has (a wheel taken out of cleanup.json): gone from game.yaml, assets and provenance
      for (const pid of staleParts) {
        removals.push(pid);
        rmSync(join(out, `${pid}.webp`), { force: true });
        delete prov.files[`${pid}.webp`];
        res.removed.push(`${pid}.webp`);
      }
    }
    if (shown.length) res.preview = await previewSheet(loc, page, shown);
    // game.yaml first: the later chapters' thumbnails (their placeholders) follow its chapters
    if (upserts.size || removals.length) writeFileSync(loc.file, writeAssets(text, [...upserts.values()], removals));
    written = true;
    const art = artSpec(loc);
    if (art) res.made.push(...(await writeThumbs(loc, art, page, prov, date)));
  } finally {
    await browser.close();
    // What was made is recorded even when a later picture fails: game.yaml, provenance and the index agree
    writeProvenance(loc, prov);
    if (!written && (upserts.size || removals.length)) writeFileSync(loc.file, writeAssets(text, [...upserts.values()], removals));
    const art = artSpec(loc);
    if (art) writeFileSync(join(out, 'index.ts'), indexFor(loc, art));
  }
  return res;
}

/** A value as one line of YAML flow, the way game.yaml writes assets: { id: a, size: [1, 2] } */
export function flowYaml(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(flowYaml).join(', ')}]`;
  if (v && typeof v === 'object') return `{ ${Object.entries(v).filter(([, x]) => x !== undefined).map(([k, x]) => `${k}: ${flowYaml(x)}`).join(', ')} }`;
  if (typeof v === 'string') return /^[a-z][a-z0-9-]*$/.test(v) && !['true', 'false', 'null', 'yes', 'no', 'on', 'off'].includes(v) ? v : JSON.stringify(v);
  return String(v);
}

/**
 * game.yaml with these assets written into `art.assets` and those ids taken out, the rest of the file as it was: a
 * one-line entry is replaced in place, a new one goes after the last, `art` is added at the end when there is none.
 * A list this can't edit line by line (an entry over several lines, a flow list) is rewritten through the YAML document.
 */
export function writeAssets(text: string, upserts: ArtAsset[], removals: string[]): string {
  const doc = parseDocument(text);
  const art = doc.get('art', true);
  const seq = doc.getIn(['art', 'assets'], true);
  if (!art && upserts.length) {
    const lines = upserts.map((a) => `    - ${flowYaml(a)}`);
    return `${text.replace(/\n*$/, '\n')}\nart:\n  style: ${JSON.stringify(IMPORT_STYLE)}\n  assets:\n${lines.join('\n')}\n`;
  }
  const items = isSeq(seq) && !seq.flow ? (seq as YAMLSeq).items : null;
  const idOf = (it: unknown) => (isMap(it) ? String(it.get('id')) : '');
  const oneLine = (it: unknown) => isMap(it) && !!it.range && !text.slice(it.range[0], it.range[1]).includes('\n');
  const touched = items?.filter((it) => upserts.some((a) => a.id === idOf(it)) || removals.includes(idOf(it))) ?? [];
  if (items?.length && touched.every(oneLine)) {
    type Edit = { at: number; end: number; with: string };
    const edits: Edit[] = [];
    const lineOf = (it: { range?: [number, number, number] | null }) => {
      const start = text.lastIndexOf('\n', it.range![0] - 1) + 1;
      const nl = text.indexOf('\n', it.range![1] - 1);
      return { start, end: nl < 0 ? text.length : nl, prefix: text.slice(start, it.range![0]) };
    };
    const fresh: ArtAsset[] = [];
    for (const a of upserts) {
      const it = items.find((x) => idOf(x) === a.id) as { range?: [number, number, number] | null } | undefined;
      if (!it) {
        fresh.push(a);
        continue;
      }
      edits.push({ at: it.range![0], end: it.range![1], with: flowYaml(a) });
    }
    for (const id of removals) {
      const it = items.find((x) => idOf(x) === id) as { range?: [number, number, number] | null } | undefined;
      if (!it) continue;
      const l = lineOf(it);
      edits.push({ at: l.start, end: Math.min(text.length, l.end + 1), with: '' });
    }
    if (fresh.length) {
      const last = lineOf(items[items.length - 1] as { range?: [number, number, number] | null });
      edits.push({ at: last.end, end: last.end, with: fresh.map((a) => `\n${last.prefix}${flowYaml(a)}`).join('') });
    }
    let out = text;
    for (const e of edits.sort((x, y) => y.at - x.at)) out = out.slice(0, e.at) + e.with + out.slice(e.end);
    return out;
  }
  // The document way: the file is re-printed (comments kept, the layout may change)
  if (!isSeq(seq)) doc.setIn(['art', 'assets'], doc.createNode([]));
  const list = doc.getIn(['art', 'assets'], true) as YAMLSeq;
  list.items = list.items.filter((it) => !removals.includes(idOf(it)));
  for (const a of upserts) {
    const i = list.items.findIndex((it) => idOf(it) === a.id);
    const node = doc.createNode(a, { flow: true });
    if (i >= 0) list.items[i] = node;
    else list.items.push(node);
  }
  return doc.toString({ lineWidth: 0, flowCollectionPadding: true });
}

/** qa/art-import.png: each cut-out on a checkerboard, then put back together — its wheels at their places and its paint mask tinted another colour */
async function previewSheet(loc: GameLocation, page: Page, views: { body: Buffer; parts: { img: Buffer; at: [number, number] }[]; mask: Buffer | null; hue: number | null; id: string }[]): Promise<string> {
  const b64 = await page.evaluate(
    async (views) => {
      const load = async (s: string) => {
        const i = new Image();
        i.src = `data:image/webp;base64,${s}`;
        await i.decode();
        return i;
      };
      const CELL = 360, PAD = 12;
      const c = document.createElement('canvas');
      c.width = CELL * 2 + PAD * 3;
      c.height = views.length * (CELL + PAD) + PAD;
      const g = c.getContext('2d')!;
      for (let y = 0; y < c.height; y += 12) for (let x = 0; x < c.width; x += 12) { g.fillStyle = ((x + y) / 12) % 2 ? '#cfd3d8' : '#f2f4f6'; g.fillRect(x, y, 12, 12); }
      for (const [row, v] of views.entries()) {
        const body = await load(v.body);
        const k = Math.min(3, (CELL - 20) / body.width, (CELL - 40) / body.height);
        const w = body.width * k, h = body.height * k, y = PAD + row * (CELL + PAD) + (CELL - h) / 2;
        g.drawImage(body, PAD + (CELL - w) / 2, y, w, h);
        // Put back together: the body, the wheels at `at`, the paint mask tinted (multiply) a third of the wheel away
        const x0 = PAD * 2 + CELL + (CELL - w) / 2;
        g.drawImage(body, x0, y, w, h);
        if (v.mask) {
          const m = await load(v.mask);
          const t = document.createElement('canvas');
          t.width = m.width;
          t.height = m.height;
          const tg = t.getContext('2d')!;
          tg.drawImage(m, 0, 0);
          tg.globalCompositeOperation = 'multiply';
          tg.fillStyle = `hsl(${((v.hue ?? 0) + 120) % 360} 75% 50%)`;
          tg.fillRect(0, 0, t.width, t.height);
          tg.globalCompositeOperation = 'destination-in';
          tg.drawImage(m, 0, 0);
          g.drawImage(t, x0, y, w, h);
        }
        for (const p of v.parts) {
          const im = await load(p.img);
          g.drawImage(im, x0 + p.at[0] * k - (im.width * k) / 2, y + p.at[1] * k - (im.height * k) / 2, im.width * k, im.height * k);
        }
        g.fillStyle = '#1b1f24';
        g.font = '600 14px sans-serif';
        g.fillText(v.id, PAD + 6, PAD + row * (CELL + PAD) + 18);
      }
      return c.toDataURL('image/png').split(',')[1]!;
    },
    views.map((v) => ({ id: v.id, hue: v.hue, body: v.body.toString('base64'), mask: v.mask?.toString('base64') ?? null, parts: v.parts.map((p) => ({ img: p.img.toString('base64'), at: p.at })) })),
  );
  const dir = join(loc.dir, 'qa');
  mkdirSync(dir, { recursive: true });
  const f = join(dir, 'art-import.png');
  writeFileSync(f, Buffer.from(b64, 'base64'));
  return f;
}

