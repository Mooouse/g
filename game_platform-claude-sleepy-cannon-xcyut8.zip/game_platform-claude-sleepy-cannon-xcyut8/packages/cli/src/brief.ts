// `gp brief`: harden a game's ТЗ (the owner's brief, a GDD) before anything is built. The owner (Жаслан, 2026-10-23):
// «На платформе мне нужен функционал дописывания ТЗ. Условно есть ТЗ. Задай вопрос о критике ТЗ. Ответь на него. Так до
// тех пор пока все вопросы и споры не будут закрыты. Это должен быть базовый функционал».
//
// The same pattern as gp review and gp design — a brief for an agent → its file → `--check` — but a loop of two agents:
// a critic who did not write the ТЗ asks pointed questions grounded in the platform's facts (the genre's must-haves,
// gp lessons, publisher/results.yaml, the forecast model, the channel's rules and budget); the game's maker answers each
// one (keep the ТЗ, with a reason; change the ТЗ in place; or `owner` — a product decision only the owner makes, with
// options, a recommendation and the question in Russian); the critic closes or disputes each answer; and so on until no
// item is open or disputed and the critic has no further questions, or the round cap is reached (a dispute still open
// at the cap goes to the owner). `gp brief <ТЗ>` says whose turn it is and writes that agent's brief.
//
//   docs/gdd.md                         the ТЗ: edited in place by the maker (git keeps the old text)
//   docs/gdd-review.md                  the record: every item, its history and state (committed); `--check` parses it
//   games/<id>/qa/brief-critic.md       the critic's brief for this round (gp qa keeps it: KEPT_REPORTS)
//   games/<id>/qa/brief-answer.md       the maker's brief for this round
//   games/<id>/qa/brief-owner.md        the questions for the owner, in Russian, when the loop is done
//   games/<id>/qa/brief/gdd-r<N>.md     the ТЗ as the critic read it in round N: `--check` sees whether a change is new

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { basename, dirname, extname, join, relative, resolve } from 'node:path';
import { parse as parseYaml } from 'yaml';
import {
  AUDIENCES,
  BASIC_LAUNCH,
  CHANNELS,
  ENGINES,
  GENRE_INFO,
  MONEY_TABLE,
  PHYSICS,
  SCOPE_MAX_SCREENS,
  UNSUPPORTED_ENGINES,
  blocksFor,
  borrowedVocabulary,
  brandsIn,
  budgetFor,
  expectationsFor,
  genreTopic,
  takenConceptsFor,
  type GenreInfo,
  type RecordedResult,
  type SubGenreInfo,
} from '@gp/spec';
import { blocksIn } from './design.ts';
import { LESSONS } from './lessons.ts';
import { ROOT, locateGame, shown } from './paths.ts';

export const BRIEF_CRITIC = 'brief-critic.md';
export const BRIEF_ANSWER = 'brief-answer.md';
export const BRIEF_OWNER = 'brief-owner.md';
/** qa/brief/: the ТЗ as the critic read it, one file per round */
export const BRIEF_DIR = 'brief';
/** Rounds at most: a round is the critic's turn and the maker's; at the cap a dispute still open goes to the owner */
export const BRIEF_CAP = 5;
/** New questions a critic may ask in one round: the ones that matter most, not every nit */
export const QUESTIONS_PER_ROUND = 12;
/** The file the owner's ТЗ lives in, in a game's repository (the game chats save it there) */
export const GDD_FILE = 'docs/gdd.md';

// --- The categories: what a critic asks about ---------------------------------------------------------------------

export type BriefCategory = 'scope' | 'contradiction' | 'feasibility' | 'portal' | 'money' | 'originality' | 'ambiguity' | 'first-30s' | 'first-10min';

export interface CategoryInfo {
  id: BriefCategory;
  name: string;
  /** In Russian, for the owner's list */
  ru: string;
  /** What to ask */
  ask: string;
  /** Where the facts are: the brief's sections and the platform's files */
  facts: string;
  /** The lessons (lessons.ts ids) that bear on it */
  lessons: string[];
  aliases: string[];
}

export const BRIEF_CATEGORIES: CategoryInfo[] = [
  {
    id: 'scope',
    name: 'Scope',
    ru: 'объём',
    ask: 'What to cut for a first version: the vertical slice vs. the full game — which content, systems and screens the first submission holds, and what waits for an update. Count them: screens, kinds of enemies or tools, levels, story scenes',
    facts: `the scope rule (more than ${SCOPE_MAX_SCREENS} screens on a first submission: W_SCOPE), the lessons on features over feel; our rejected games grew 75 weapons and 16 screens`,
    lessons: ['feel-over-features', 'side-systems-later', 'variety'],
    aliases: ['cut', 'slice', 'vertical-slice'],
  },
  {
    id: 'contradiction',
    name: 'Contradictions',
    ru: 'противоречие',
    ask: 'Two rules, numbers or promises in the ТЗ that clash — a story-heavy opening and a 1-click first minute; permadeath and a 15-minute session; "simple" and 9 systems; a size budget and 300 painted frames. Quote both',
    facts: 'the ТЗ itself, against the channel rules and the genre below',
    lessons: [],
    aliases: ['contradictions', 'conflict', 'clash'],
  },
  {
    id: 'feasibility',
    name: 'Feasibility in the platform',
    ru: 'реализуемость',
    ask: 'Can the platform build it: a web portal game in one index.html, the size and load budget, phones and touch, the engines and blocks that exist (`gp catalog blocks --genre <g>`), and what is a known gap the game would write itself',
    facts: 'the channel and budget, the engines, the genre\'s blocks and the known gaps below',
    lessons: ['controls', 'mobile-controls-visible', 'smooth', 'desktop-decides'],
    aliases: ['platform', 'tech', 'technical', 'feasible'],
  },
  {
    id: 'portal',
    name: 'Portal fit',
    ru: 'портал',
    ask: "CrazyGames' rules and its review: 13+ (PEGI 12), what it rejected our games for (\"the overall quality\", \"quite close to existing titles\"), the first visit in gameplay, ten languages, music with a volume, drawn icons",
    facts: 'the channel rules, what CrazyGames rejected, the CrazyGames promotions to [blocking] below',
    lessons: ['first-visit-gameplay', 'review-calibration', 'languages', 'sound', 'drawn-icons', 'art-direction'],
    aliases: ['crazygames', 'store', 'rules'],
  },
  {
    id: 'money',
    name: 'Money design',
    ru: 'монетизация',
    ask: 'Where it earns: the session, the natural breaks and where they fall, the rewarded offers and what each gives, the reason to come back tomorrow (D1), a meta that outlasts the first session',
    facts: 'Basic Launch and the forecast model below; `gp forecast --idea` for a candidate',
    lessons: ['retention', 'daily-visible', 'session-length', 'results-continue'],
    aliases: ['monetization', 'monetisation', 'd1', 'retention'],
  },
  {
    id: 'originality',
    name: 'Originality and trademarks',
    ru: 'оригинальность',
    ask: 'What the player does that the 3 closest games on the portal don\'t; the reference games, characters and brands the ТЗ names — they must not reach the title, the texts, the art or the listing',
    facts: 'the names found in the ТЗ and the taken concepts below (packages/spec/src/taken.ts, vocabulary.ts)',
    lessons: ['concept'],
    aliases: ['trademarks', 'trademark', 'uniqueness', 'originality-and-trademarks', 'ip'],
  },
  {
    id: 'ambiguity',
    name: 'Ambiguity',
    ru: 'неясность',
    ask: 'Numbers missing (how many, how long, how much, how fast), terms the ТЗ uses and never defines, lists that end in "etc.", a rule with no case for failure',
    facts: 'the ТЗ itself; the balance model needs the numbers (docs/guides/upgrades.md)',
    lessons: ['balance', 'information'],
    aliases: ['ambiguous', 'unclear', 'numbers'],
  },
  {
    id: 'first-30s',
    name: 'The first 30 s',
    ru: 'первые 30 секунд',
    ask: 'What a new player sees, does and understands in the first 30 s: clicks from the portal\'s Play Now to control, words before the first action, the first reward, the twist shown and not told',
    facts: 'the first minute rules below (docs/guides/first-minute.md)',
    lessons: ['first-minute', 'first-visit-gameplay', 'onboarding', 'start-sound', 'mobile-controls-visible'],
    aliases: ['first-30-s', 'first30s', 'first-minute', 'onboarding'],
  },
  {
    id: 'first-10min',
    name: 'The first 10 min',
    ru: 'первые 10 минут',
    ask: 'Where a new player stops in the first 10 minutes and what pulls them on: the first natural break, the results screen\'s big button, the first meta reward, something new every 3–5 minutes',
    facts: 'the session rules and Basic Launch below (W_SESSION_SHORT, docs/guides/first-minute.md → The session)',
    lessons: ['session-length', 'results-continue', 'structure', 'visible-progress', 'variety'],
    aliases: ['first-10-min', 'first10min', 'session', 'first-session'],
  },
];

/** A category by its id or an alias ("trademarks" → originality) */
export function categoryOf(s: string): CategoryInfo | null {
  const k = s.trim().toLowerCase().replace(/\s+/g, '-');
  return BRIEF_CATEGORIES.find((c) => c.id === k || c.aliases.includes(k)) ?? null;
}

// --- The record: its format and its parser (pure) -------------------------------------------------------------------

export const BRIEF_STATES = ['open', 'answered', 'disputed', 'closed', 'owner'] as const;
export type BriefState = (typeof BRIEF_STATES)[number];
export type AnswerKind = 'keep' | 'change' | 'owner';
type Who = 'critic' | 'maker' | 'any';

/** A turn of the history: the critic's question, dispute or close; the maker's answer; the owner's word; gp brief's escalation */
export type MainKind = 'question' | 'answer' | 'dispute' | 'close' | 'ownerSaid' | 'escalated';
/** What a turn carries: the question's ground; the answer's ТЗ change, or its options, recommendation and owner question */
export type AttachKind = 'ground' | 'tz' | 'options' | 'recommend' | 'ownerQuestion';

export interface Attachment {
  kind: AttachKind;
  text: string;
  line: number;
}

export interface MainEntry {
  kind: MainKind;
  round: number | null;
  /** An answer's kind */
  answer?: AnswerKind;
  /** The owner's word: its date */
  date?: string;
  text: string;
  line: number;
  attach: Attachment[];
}

export interface TzChange {
  /** The section it names, as written ("§8 Vertical slice") */
  where: string;
  /** The quoted text: the new text, or for a removal the text that was taken out */
  quotes: string[];
  removed: boolean;
  /** "(superseded by Q7)": a later item rewrote it */
  superseded: string | null;
  line: number;
  /** The round of the answer it belongs to (null: the owner's word) */
  round: number | null;
}

export interface BriefItem {
  id: string;
  n: number;
  category: BriefCategory | null;
  /** The state the heading says */
  declared: string;
  /** The state the history says */
  state: BriefState;
  entries: MainEntry[];
  line: number;
}

export interface BriefProblem {
  line: number;
  message: string;
  /** Whose to fix: the critic's, the maker's, or whoever edits the file next */
  who: Who;
  item?: string;
}

export interface LogLine {
  round: number;
  actor: string;
  text: string;
  line: number;
}

export interface BriefRecord {
  title: string | null;
  /** The ТЗ the header names */
  tz: string | null;
  /** The round the header says (gp brief sets it when it starts a critic's round) */
  round: number;
  cap: number;
  items: BriefItem[];
  log: LogLine[];
  /** The latest round the critic wrote anything in (an entry or a log line); 0 before the first */
  criticRound: number;
  /** The latest round whose critic log line says «no further questions» (null: none) */
  noFurther: number | null;
  problems: BriefProblem[];
}

const LABELS: Record<string, MainKind | AttachKind> = {
  q: 'question',
  question: 'question',
  вопрос: 'question',
  ground: 'ground',
  основание: 'ground',
  a: 'answer',
  answer: 'answer',
  ответ: 'answer',
  тз: 'tz',
  tz: 'tz',
  gdd: 'tz',
  changed: 'tz',
  options: 'options',
  варианты: 'options',
  recommend: 'recommend',
  recommendation: 'recommend',
  рекомендация: 'recommend',
  владельцу: 'ownerQuestion',
  'owner question': 'ownerQuestion',
  'вопрос владельцу': 'ownerQuestion',
  dispute: 'dispute',
  спор: 'dispute',
  close: 'close',
  closed: 'close',
  закрыто: 'close',
  owner: 'ownerSaid',
  владелец: 'ownerSaid',
  escalated: 'escalated',
};
const MAIN: ReadonlySet<string> = new Set<MainKind>(['question', 'answer', 'dispute', 'close', 'ownerSaid', 'escalated']);
const ENTRY = /^\s*(?:[-*]\s+)?\*{0,2}([A-Za-zА-Яа-яЁё]+(?: [A-Za-zА-Яа-яЁё]+)?)\*{0,2}\s*(?:\(([^)]*)\))?\s*\*{0,2}:\*{0,2}\s*(.*)$/;
const HEADING_ITEM = /^##\s+Q(\d+)\b\s*(.*)$/;
const LOG_LINE = /^\s*[-*]\s*r(\d+)\s+(critic|maker|owner|gp brief)\s*:\s*(.*)$/i;
const NO_FURTHER = /\bno further questions\b|вопросов больше нет|больше вопросов нет/i;
const PLACEHOLDER = /<[^<>\n]{2,}>/;
const CYRILLIC = /[А-Яа-яЁё]/;
const words = (s: string) => s.split(/\s+/).filter(Boolean).length;

/** The kind of an answer from its tag: "r1, change" → change ("decide"/"keep" → keep, "cut" → change) */
function answerKind(tag: string): AnswerKind | null {
  const t = tag.toLowerCase();
  if (/\bowner\b|владел/.test(t)) return 'owner';
  if (/\b(change[sd]?|cut|edit(ed)?)\b|измен/.test(t)) return 'change';
  if (/\b(keep|kept|decided?|stands?)\b|оставл|решен/.test(t)) return 'keep';
  return null;
}

/** The quoted strings of a text: «…», "…", “…” (6 characters or more) */
export function quotesIn(text: string): string[] {
  // "…" may hold «…» (a Russian ТЗ quotes its button names), and «…» one level of «…»
  return [...text.matchAll(/"([^"\n]{6,}?)"|“([^”\n]{6,}?)”|„([^“”\n]{6,}?)[“”]|«((?:[^«»\n]|«[^«»\n]*»){6,}?)»/g)].map((m) => (m[1] ?? m[2] ?? m[3] ?? m[4]).trim());
}

/** A ТЗ line: "§8 Vertical slice — "the new text"", "§3 — removed "12 districts"", "… (superseded by Q7)" */
export function parseTzChange(a: Attachment, round: number | null): TzChange {
  const quotes = quotesIn(a.text);
  const firstQuote = a.text.search(/[«"“„]/);
  const before = firstQuote < 0 ? a.text : a.text.slice(0, firstQuote);
  const sup = a.text.match(/\(superseded by (Q\d+)\)|\(заменено в (Q\d+)\)/i);
  return {
    where: before.replace(/\s*(?:—|–|-|:)\s*(?:removed|deleted|cut|удалено|убрано)?\s*$/i, '').trim(),
    quotes,
    removed: /\b(removed|deleted|cut)\b|удален|убран/i.test(before),
    superseded: sup ? (sup[1] ?? sup[2]) : null,
    line: a.line,
    round,
  };
}

/** How many options an Options line gives: "1) … 2) …", "а) … б) …" */
export function optionCount(text: string): number {
  return [...text.matchAll(/(?:^|[\s;])(?:[1-4][.)]|[абвгabcd]\))\s/gi)].length;
}

/**
 * docs/gdd-review.md → its items, each with its history and state, and what is wrong with the file. The format (see
 * recordTemplate): a `# <title> — ТЗ review` heading; a header line `ТЗ: <path> · Round: N of 5`; an item per question,
 * `## Q<n> · <category> · <state>`, then its history — `Q (r1): …` with `Ground: …` under it, the maker's `A (r1, keep |
 * change | owner): …` with `ТЗ: §… — "…"` for a change or `Options:` / `Recommend:` / `Владельцу:` for the owner, the
 * critic's `Dispute (r2): …` or `Close (r2): …`, the owner's `Owner (2026-10-24): …`, gp brief's `Escalated (r5): …`; a
 * line that is no entry goes on the one before it. `## Log`: `- r1 critic: …`, `- r1 maker: …`; the critic's «no
 * further questions» there ends the loop. HTML comments are skipped.
 */
export function parseRecord(text: string, opts: { cap?: number } = {}): BriefRecord {
  const raw = text.replace(/\r\n?/g, '\n');
  const clean = raw.replace(/<!--[\s\S]*?-->/g, (m) => m.replace(/[^\n]/g, ''));
  const lines = clean.split('\n');
  const problems: BriefProblem[] = [];
  const h1 = lines.findIndex((l) => /^#\s+\S/.test(l));
  const title = h1 >= 0 ? lines[h1].replace(/^#\s+/, '').replace(/\s*[—–-]\s*(?:ТЗ|GDD|brief)(?=$|[\s.,:;()]).*$/i, '').trim() : null;
  if (h1 < 0) problems.push({ line: 1, message: 'no heading: the file starts with "# <game title> — ТЗ review"', who: 'any' });
  const headLine = lines.findIndex((l) => /\bRound:\s*\d+/i.test(l) && !/^#/.test(l));
  const head = headLine >= 0 ? lines[headLine].match(/\bRound:\s*(\d+)(?:\s*(?:of|из)\s*(\d+))?/i) : null;
  const round = head ? Number(head[1]) : 0;
  const cap = head?.[2] ? Number(head[2]) : (opts.cap ?? BRIEF_CAP);
  const tzm = headLine >= 0 ? lines[headLine].match(/(?:ТЗ|TZ|GDD):\s*([^\s·]+)/) : null;
  const items: BriefItem[] = [];
  const log: LogLine[] = [];
  let section: 'item' | 'log' | 'other' = 'other';
  let cur: BriefItem | null = null;
  let last: { text: string } | null = null;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    const ln = i + 1;
    if (/^##\s/.test(l)) {
      last = null;
      const m = l.match(HEADING_ITEM);
      if (m) {
        section = 'item';
        const parts = m[2].split(/\s+[·•|]\s+|^[·•|]\s+/).map((p) => p.trim()).filter(Boolean);
        const catRaw = parts[0] ?? '';
        const stateRaw = (parts[1] ?? '').split(/\s+(?:—|–)\s+|\s/)[0].toLowerCase();
        const cat = categoryOf(catRaw);
        cur = { id: `Q${m[1]}`, n: Number(m[1]), category: cat?.id ?? null, declared: stateRaw, state: 'open', entries: [], line: ln };
        if (!cat) problems.push({ line: ln, message: `Q${m[1]}: "${catRaw || '(none)'}" is not a category — one of ${BRIEF_CATEGORIES.map((c) => c.id).join(', ')}: "## Q${m[1]} · scope · open"`, who: 'critic', item: cur.id });
        if (items.some((x) => x.n === cur!.n)) problems.push({ line: ln, message: `Q${m[1]} is there twice: a new question takes the next free number`, who: 'critic', item: cur.id });
        items.push(cur);
      } else if (/^##\s+(log|журнал)\b/i.test(l)) {
        section = 'log';
        cur = null;
      } else {
        section = 'other';
        cur = null;
      }
      continue;
    }
    if (section === 'log') {
      const m = l.match(LOG_LINE);
      if (m) log.push({ round: Number(m[1]), actor: m[2].toLowerCase(), text: m[3].trim(), line: ln });
      continue;
    }
    if (section !== 'item' || !cur) continue;
    if (!l.trim()) continue;
    const e = l.match(ENTRY);
    const kind = e ? LABELS[e[1].trim().toLowerCase()] : undefined;
    if (e && kind) {
      const tag = e[2] ?? '';
      const r = tag.match(/\br(?:ound)?\s*(\d+)\b|раунд\s*(\d+)/i);
      const rr = r ? Number(r[1] ?? r[2]) : null;
      if (MAIN.has(kind)) {
        const entry: MainEntry = { kind: kind as MainKind, round: rr, text: e[3].trim(), line: ln, attach: [] };
        if (kind === 'answer') {
          const k = answerKind(tag);
          if (k) entry.answer = k;
        }
        const d = tag.match(/\d{4}-\d{2}-\d{2}/);
        if (d) entry.date = d[0];
        cur.entries.push(entry);
        last = entry;
      } else {
        const host = cur.entries.at(-1);
        const a: Attachment = { kind: kind as AttachKind, text: e[3].trim(), line: ln };
        if (!host) problems.push({ line: ln, message: `${cur.id}: "${e[1]}:" before the question — an item starts with "Q (r1): …"`, who: 'any', item: cur.id });
        else host.attach.push(a);
        last = a;
      }
      continue;
    }
    // A line that is no entry goes on the one before it (a long question or answer over several lines)
    if (last) last.text = `${last.text} ${l.trim()}`.trim();
  }

  for (const it of items) checkItem(it, round, problems);
  const criticRounds = [
    ...items.flatMap((it) => it.entries.filter((e) => e.kind === 'question' || e.kind === 'dispute' || e.kind === 'close').map((e) => e.round ?? 0)),
    ...log.filter((x) => x.actor === 'critic').map((x) => x.round),
  ];
  const criticRound = criticRounds.length ? Math.max(...criticRounds) : 0;
  const nf = log.filter((x) => x.actor === 'critic' && NO_FURTHER.test(x.text)).map((x) => x.round);
  const noFurther = nf.length ? Math.max(...nf) : null;
  // A round's new questions: QUESTIONS_PER_ROUND at most
  const byRound = new Map<number, BriefItem[]>();
  for (const it of items) {
    const q = it.entries[0];
    if (q?.kind === 'question' && q.round) byRound.set(q.round, [...(byRound.get(q.round) ?? []), it]);
  }
  for (const [r, its] of byRound)
    if (its.length > QUESTIONS_PER_ROUND) problems.push({ line: its[QUESTIONS_PER_ROUND].line, message: `round ${r} asks ${its.length} new questions: ${QUESTIONS_PER_ROUND} at most — keep the ones that would change the build or the review, drop the nits`, who: 'critic' });
  if (noFurther !== null && byRound.get(noFurther)?.length)
    problems.push({ line: log.find((x) => x.round === noFurther && x.actor === 'critic' && NO_FURTHER.test(x.text))!.line, message: `round ${noFurther}: the critic says «no further questions» and asks ${byRound.get(noFurther)!.length} new one(s) in the same round — one or the other`, who: 'critic' });
  return { title, tz: tzm?.[1] ?? null, round, cap, items, log, criticRound, noFurther, problems: problems.sort((a, b) => a.line - b.line) };
}

/** The platform facts a ground line names: a rule code, a must-have, a lesson, a recorded game, a money row, a block, a budget, a doc */
export function groundsIn(text: string, o: { games?: readonly string[] } = {}): string[] {
  const found: string[] = [];
  const t = text;
  for (const m of t.matchAll(/\b[EWI]_[A-Z0-9_]{3,}\b/g)) found.push(m[0]);
  for (const id of Object.keys(MONEY_TABLE)) if (t.includes(id)) found.push(id);
  for (const l of LESSONS) if (new RegExp(`(?:lessons?|урок)[^\\n]{0,24}\\b${l.id}\\b|\`${l.id}\``, 'i').test(t)) found.push(`lesson ${l.id}`);
  const mustHave = t.match(/\bmust-?haves?\b[^.;]{0,40}|\bgenres\.ts\b|\bgenre\.[a-z-]+\b|\bI_GENRE_EXPECTS\b/i);
  if (mustHave) found.push('must-have');
  if (/\bresults\.yaml\b|\bBasic Launch\b|\b\d+\s*\/\s*15\b|\b9 of 15\b/i.test(t)) found.push('results');
  for (const g of o.games ?? []) if (g.length > 3 && t.toLowerCase().includes(g.toLowerCase())) found.push(g);
  found.push(...blocksIn(t));
  if (/\b\d+(?:[.,]\d+)?\s?(?:KB|MB|КБ|МБ)\b|\bbudget\b|\bбюджет/i.test(t)) found.push('budget');
  for (const m of t.matchAll(/\b(?:docs|packages|publisher)\/[\w./-]+|\bAGENTS\.md\b/g)) found.push(m[0]);
  for (const m of t.matchAll(/\bgp (?:qa|forecast|catalog|lessons|validate|uniqueness|build|explain|review|design|balance|name|story)\b/g)) found.push(m[0]);
  if (/\bcrazygames\b[^.]{0,40}\b(rule|requirement|guideline|reject|PEGI|first visit|1 click|one click)/i.test(t) || /\bPEGI\b|\bfirst[- ]minute\b|\bW_SESSION_SHORT\b/i.test(t)) found.push('channel rules');
  return [...new Set(found)];
}

function checkItem(it: BriefItem, round: number, problems: BriefProblem[]) {
  const P = (line: number, message: string, who: Who) => problems.push({ line, message: `${it.id}: ${message}`, who, item: it.id });
  const es = it.entries;
  if (!es.length) {
    P(it.line, 'no question — "Q (r1): …" and "Ground: …" under the heading', 'critic');
    return;
  }
  if (es[0].kind !== 'question') P(es[0].line, 'the history starts with the critic\'s question: "Q (r1): …"', 'any');
  let state = 'open' as BriefState;
  let ownerAt = -1;
  let prevRound = 0;
  es.forEach((e, i) => {
    const has = (k: AttachKind) => e.attach.filter((a) => a.kind === k);
    const left = [e.text, ...e.attach.map((a) => a.text)].map((t) => t.match(PLACEHOLDER)?.[0]).find((x) => !!x);
    if (left) P(e.line, `the template's placeholder ${quote(left)} is still in it`, whoOf(e.kind) === 'critic' ? 'critic' : 'maker');
    if (e.kind !== 'ownerSaid' && e.round === null) P(e.line, `"${labelOf(e.kind)}" has no round: "${labelOf(e.kind)} (r${Math.max(1, round)}${e.kind === 'answer' ? ', keep' : ''}): …"`, whoOf(e.kind));
    if (e.round !== null) {
      if (round && e.round > round) P(e.line, `round ${e.round} is past the record's round (${round}): gp brief sets the round when it starts the critic's turn`, whoOf(e.kind));
      if (e.round < prevRound) P(e.line, `round ${e.round} after round ${prevRound}: the history goes forward`, whoOf(e.kind));
      prevRound = Math.max(prevRound, e.round);
    }
    switch (e.kind) {
      case 'question': {
        if (i > 0) P(e.line, 'a second question in one item: a new question is a new item (the next free Q number)', 'critic');
        if (words(e.text) < 6) P(e.line, `the question ${quote(e.text)} is too short to answer: quote the ТЗ, say what clashes or is missing, and what a good answer looks like`, 'critic');
        const g = has('ground');
        if (!g.length) P(e.line, 'no "Ground: …" under the question: the platform fact it rests on (a must-have, a lesson, a results.yaml game, a MONEY_TABLE row, a rule code, the budget, a doc)', 'critic');
        else if (!g.some((x) => groundsIn(x.text).length)) P(g[0].line, `ground: ${quote(g[0].text)} names no platform fact — a must-have id (genres.ts), a lesson id (\`gp lessons\`), a game in publisher/results.yaml, a MONEY_TABLE row (cg.full.gateMin), a rule code (W_SESSION_SHORT), the budget (400 KB), a block (\`mountResults\`), a doc path`, 'critic');
        state = 'open';
        break;
      }
      case 'answer': {
        if (state !== 'open' && state !== 'disputed' && state !== 'owner') P(e.line, `an answer to nothing: the item was ${state} (answer a question or a dispute)`, 'maker');
        if (!e.answer) P(e.line, 'the answer has no kind: "A (rN, keep): …" (the ТЗ stands, and why), "A (rN, change): …" with a "ТЗ:" line, or "A (rN, owner): …" with Options, Recommend and Владельцу', 'maker');
        if (words(e.text) < 4) P(e.line, `the answer ${quote(e.text)} says too little: the decision and its reason`, 'maker');
        if (e.answer === 'change' && !has('tz').length) P(e.line, 'a change with no "ТЗ:" line: edit the ТЗ in place, then "ТЗ: §<section> — "<the new text, copied exactly>"" (a cut: — removed "<the old text>")', 'maker');
        for (const t of has('tz')) if (!quotesIn(t.text).length) P(t.line, `ТЗ: ${quote(t.text)} quotes nothing — the new text as it now stands in the ТЗ, in quotes ("…" or «…», 6 characters or more)`, 'maker');
        if (e.answer === 'owner') {
          ownerAt = i;
          state = 'owner';
        } else state = 'answered';
        break;
      }
      case 'dispute':
        if (state !== 'answered' && state !== 'owner') P(e.line, `a dispute of nothing: the item was ${state} — dispute an answer`, 'critic');
        if (words(e.text) < 5) P(e.line, `the dispute ${quote(e.text)} says too little: what is still wrong with the answer, and what would close it`, 'critic');
        state = 'disputed';
        break;
      case 'close':
        if (state !== 'answered') P(e.line, `a close of ${state === 'owner' ? 'an owner item (the owner\'s word closes it: "Owner (YYYY-MM-DD): …")' : `nothing: the item was ${state}`}`, 'critic');
        if (!e.text) P(e.line, 'say why it holds: "Close (rN): <why the answer settles it>"', 'critic');
        state = 'closed';
        break;
      case 'ownerSaid':
        if (state !== 'owner') P(e.line, `the owner's word on an item that was ${state}: only an owner item waits for it`, 'maker');
        if (!e.date && e.round === null) P(e.line, 'the owner\'s word has no date: "Owner (2026-10-24): …"', 'maker');
        state = 'closed';
        break;
      case 'escalated':
        ownerAt = i;
        state = 'owner';
        break;
    }
  });
  // An owner item: its options, recommendation and the question in Russian, after the turn that made it one
  if ((state as BriefState) === 'owner' && ownerAt >= 0) {
    const after = es.slice(ownerAt).flatMap((e) => e.attach);
    const at = es[ownerAt].line;
    const opt = after.find((a) => a.kind === 'options');
    const rec = after.find((a) => a.kind === 'recommend');
    const ask = after.find((a) => a.kind === 'ownerQuestion');
    if (!opt) P(at, 'an owner item needs "Options: 1) … 2) … (3) …)" — 2 or 3, in Russian', 'maker');
    else if (optionCount(opt.text) < 2 || optionCount(opt.text) > 3) P(opt.line, `Options: ${optionCount(opt.text)} option(s) — 2 or 3, numbered "1) … 2) …" (or "а) … б) …")`, 'maker');
    if (!rec) P(at, 'an owner item needs "Recommend: <which option and why>" — in Russian', 'maker');
    if (!ask) P(at, 'an owner item needs "Владельцу: <the question as you would send it>" — in Russian, one or two sentences', 'maker');
    for (const a of [opt, rec, ask]) if (a && !CYRILLIC.test(a.text)) P(a.line, `${labelOfAttach(a.kind)}: ${quote(a.text)} is not in Russian — the owner reads these`, 'maker');
  }
  it.state = state;
  const declared = it.declared;
  if (!(BRIEF_STATES as readonly string[]).includes(declared)) P(it.line, `"${declared || '(none)'}" is not a state — ${BRIEF_STATES.join(', ')}; its history says ${state}: "## ${it.id} · ${it.category ?? 'scope'} · ${state}"`, 'any');
  else if (declared !== state) P(it.line, `the heading says ${declared}, its history says ${state} (the last turn: ${labelOf(es.at(-1)!.kind)} on line ${es.at(-1)!.line}) — set the heading to ${state}, or add the turn that makes it ${declared}`, 'any');
}

const quote = (s: string, max = 60) => `"${s.length > max ? `${s.slice(0, max - 1)}…` : s}"`;
const labelOf = (k: MainKind) => ({ question: 'Q', answer: 'A', dispute: 'Dispute', close: 'Close', ownerSaid: 'Owner', escalated: 'Escalated' })[k];
const labelOfAttach = (k: AttachKind) => ({ ground: 'Ground', tz: 'ТЗ', options: 'Options', recommend: 'Recommend', ownerQuestion: 'Владельцу' })[k];
const whoOf = (k: MainKind): Who => (k === 'question' || k === 'dispute' || k === 'close' ? 'critic' : k === 'escalated' ? 'any' : 'maker');

/** A text for a search in the ТЗ: lower case, spaces collapsed, markdown emphasis off, ё as е, typographic quotes plain */
export const normTz = (s: string) => s.toLowerCase().replace(/ё/g, 'е').replace(/[*_`~]/g, '').replace(/[«»“”„"]/g, '"').replace(/[‐‑–—]/g, '-').replace(/\s+/g, ' ').trim();

/**
 * Was the ТЗ changed where the answers say it was? For each item, its last ТЗ line (the earlier ones are its history; a
 * line marked "(superseded by Qn)" is skipped): every quote is in the ТЗ now — or, for a removal, is not — and, when the
 * ТЗ as the critic read it in that round is at hand (qa/brief/<name>-r<N>.md), the text is new since then (a removal:
 * it was there). Problems are the maker's.
 */
export function verifyTz(rec: Pick<BriefRecord, 'items'>, tz: string, snapshots: Readonly<Record<number, string>> = {}): BriefProblem[] {
  const now = normTz(tz);
  const out: BriefProblem[] = [];
  for (const it of rec.items) {
    const changes = it.entries.flatMap((e) => e.attach.filter((a) => a.kind === 'tz').map((a) => parseTzChange(a, e.kind === 'answer' ? e.round : null)));
    const c = changes.at(-1);
    if (!c || c.superseded || !c.quotes.length) continue;
    const snap = c.round !== null && snapshots[c.round] !== undefined ? normTz(snapshots[c.round]) : null;
    const P = (message: string) => out.push({ line: c.line, message: `${it.id}: ${message}`, who: 'maker', item: it.id });
    if (c.removed) {
      for (const q of c.quotes) {
        if (now.includes(normTz(q))) P(`the answer says ${quote(q)} was removed from the ТЗ, and it is still there — take it out, or correct the ТЗ line`);
        else if (snap !== null && !snap.includes(normTz(q))) P(`the answer says ${quote(q)} was removed, but the ТЗ the critic read in round ${c.round} didn't have it either — quote the text that was taken out`);
      }
      continue;
    }
    const missing = c.quotes.filter((q) => !now.includes(normTz(q)));
    for (const q of missing) P(`the answer says the ТЗ now reads ${quote(q)}${c.where ? ` (${c.where})` : ''}, and the ТЗ doesn't — edit the ТЗ, or quote it exactly as it stands (a later item rewrote it? mark this line "(superseded by Qn)")`);
    if (!missing.length && snap !== null && c.quotes.every((q) => snap.includes(normTz(q))))
      P(`${c.quotes.length > 1 ? 'the quoted texts were' : `${quote(c.quotes[0])} was`} already in the ТЗ the critic read in round ${c.round}: the ТЗ was not changed — quote the new text, or answer "keep" if the ТЗ already said it`);
  }
  return out;
}

/** The record, the ТЗ checked against it, and the problems of both */
export function checkRecord(text: string, o: { tz?: string | null; snapshots?: Readonly<Record<number, string>>; cap?: number } = {}): BriefRecord {
  const rec = parseRecord(text, { cap: o.cap });
  if (o.tz != null) rec.problems = [...rec.problems, ...verifyTz(rec, o.tz, o.snapshots)].sort((a, b) => a.line - b.line);
  return rec;
}

// --- Whose turn -----------------------------------------------------------------------------------------------------

export interface Turn {
  who: 'critic' | 'maker' | 'done';
  round: number;
  /** Why, in one line */
  why: string;
  /** The items the turn is about */
  items: string[];
  /** The problems that turn fixes first */
  fix: BriefProblem[];
}

/**
 * Whose turn it is. The critic first (round 1). Then the maker while an item is open or disputed or an owner item lacks
 * its options, or the maker's ТЗ lines don't hold. Then the critic again (the next round) to rule on every answer —
 * close or dispute — and to ask new questions or say «no further questions». Done when nothing is open, disputed or
 * unruled and the critic's latest round says «no further questions», or when the critic has had its last round (the cap).
 * The critic's own problems (a question with no ground) come back to it first, in its round.
 */
export function nextTurn(rec: BriefRecord | null, capIn?: number): Turn {
  const cap = capIn ?? rec?.cap ?? BRIEF_CAP;
  if (!rec || (rec.criticRound === 0 && !rec.items.length)) return { who: 'critic', round: 1, why: 'the first round: read the ТЗ whole, then ask', items: [], fix: [] };
  const r = Math.max(1, rec.criticRound);
  // A problem that is whoever's (a heading's state that its history contradicts) goes with the next turn
  const anyFix = rec.problems.filter((p) => p.who === 'any');
  const criticFix = rec.problems.filter((p) => p.who === 'critic');
  if (criticFix.length) return { who: 'critic', round: r, why: `round ${r} has ${criticFix.length} problem(s) in the critic's entries: fix them first`, items: [...new Set(criticFix.map((p) => p.item).filter((x): x is string => !!x))], fix: [...criticFix, ...anyFix] };
  const toAnswer = rec.items.filter((i) => i.state === 'open' || i.state === 'disputed');
  const makerFix = rec.problems.filter((p) => p.who === 'maker');
  if (toAnswer.length || makerFix.length) {
    const ids = [...new Set([...toAnswer.map((i) => i.id), ...makerFix.map((p) => p.item).filter((x): x is string => !!x)])];
    return { who: 'maker', round: r, why: `${toAnswer.length} item(s) to answer${makerFix.length ? `, ${makerFix.length} problem(s) in the answers` : ''}`, items: ids, fix: [...makerFix, ...anyFix] };
  }
  const unruled = rec.items.filter((i) => i.state === 'answered');
  if (r >= cap) return { who: 'done', round: r, why: `the round cap (${cap}): the critic had its last round${unruled.length ? `; ${unruled.map((i) => i.id).join(', ')} answered and never ruled on` : ''}`, items: unruled.map((i) => i.id), fix: anyFix };
  if (unruled.length || rec.noFurther !== r)
    return { who: 'critic', round: r + 1, why: unruled.length ? `${unruled.length} answer(s) to rule on (close or dispute)` : `round ${r} did not say «no further questions»: ask more, or say so`, items: unruled.map((i) => i.id), fix: anyFix };
  return { who: 'done', round: r, why: `the critic has no further questions (round ${r}) and nothing is open or disputed`, items: [], fix: anyFix };
}

/** The counts by state: "9 items: 6 closed, 2 owner, 1 answered" */
export function stateSummary(rec: Pick<BriefRecord, 'items'>): string {
  const n = (s: BriefState) => rec.items.filter((i) => i.state === s).length;
  const parts = BRIEF_STATES.map((s) => [s, n(s)] as const).filter(([, k]) => k).map(([s, k]) => `${k} ${s}`);
  return `${rec.items.length} item${rec.items.length === 1 ? '' : 's'}${parts.length ? `: ${parts.join(', ')}` : ''}`;
}

// --- Editing the record (gp brief's own turns) ----------------------------------------------------------------------

/** A new record */
export function recordTemplate(title: string, tz: string, cap = BRIEF_CAP): string {
  return [
    `# ${title} — ТЗ review`,
    '',
    `ТЗ: ${tz} · Round: 1 of ${cap}`,
    '',
    '<!-- The record of the ТЗ review (docs/guides/brief.md). `gp brief <ТЗ>` says whose turn it is and writes that',
    "agent's brief; `gp brief <ТЗ> --check` checks this file and the ТЗ. One item per question:",
    '',
    '## Q<n> · <category> · <state>',
    'Q (r1): <the question: quote the ТЗ, say what clashes or is missing, what a good answer looks like>',
    'Ground: <the platform fact: a must-have, a lesson, a results.yaml game, a MONEY_TABLE row, a rule code, the budget>',
    'A (r1, change): <the decision and why>',
    'ТЗ: §<section> — "<the new text, as it now stands in the ТЗ>"',
    '',
    'Answers: A (rN, keep) — the ТЗ stands, and why; A (rN, change) + a ТЗ: line; A (rN, owner) + Options: 1) … 2) …,',
    'Recommend: …, Владельцу: … (in Russian). The critic: Close (rN): … or Dispute (rN): …. The owner: Owner (YYYY-MM-DD): ….',
    'States: open, answered, disputed, closed, owner. Categories: ' + BRIEF_CATEGORIES.map((c) => c.id).join(', ') + '. -->',
    '',
    '## Log',
    '',
  ].join('\n');
}

/** The header's round set to `round` (and the cap), the line added after the title when it is missing */
export function setRound(text: string, round: number, cap: number): string {
  const lines = text.split('\n');
  const at = lines.findIndex((l) => /\bRound:\s*\d+/i.test(l) && !/^#/.test(l));
  if (at >= 0) {
    lines[at] = lines[at].replace(/\bRound:\s*\d+(?:\s*(?:of|из)\s*\d+)?/i, `Round: ${round} of ${cap}`);
    return lines.join('\n');
  }
  const h1 = lines.findIndex((l) => /^#\s+\S/.test(l));
  lines.splice(h1 + 1, 0, '', `Round: ${round} of ${cap}`);
  return lines.join('\n');
}

/** A line added to `## Log` (the section made at the end when missing) */
export function appendLog(text: string, line: string): string {
  const lines = text.replace(/\s+$/, '').split('\n');
  if (!lines.some((l) => /^##\s+(log|журнал)\b/i.test(l))) lines.push('', '## Log', '');
  const at = lines.findIndex((l) => /^##\s+(log|журнал)\b/i.test(l));
  let end = lines.findIndex((l, i) => i > at && /^##\s/.test(l));
  if (end < 0) end = lines.length;
  let last = end - 1;
  while (last > at && !lines[last].trim()) last--;
  // An empty log gets a blank line under its heading; otherwise the line goes after the last one
  if (last === at) lines.splice(at + 1, 0, '', line);
  else lines.splice(last + 1, 0, line);
  return `${lines.join('\n').replace(/\n{3,}/g, '\n\n').replace(/\s+$/, '')}\n`;
}

/**
 * At the cap: a dispute the critic raised in its last round goes to the owner — the heading set to `owner`, an
 * `Escalated (rN): …` turn with both sides, a log line; the maker then writes its options, recommendation and the question
 * in Russian. Returns the text unchanged when there is nothing to escalate.
 */
export function escalateAtCap(text: string, rec: BriefRecord): { text: string; escalated: string[] } {
  if (rec.criticRound < rec.cap) return { text, escalated: [] };
  const due = rec.items.filter((i) => i.state === 'disputed');
  if (!due.length) return { text, escalated: [] };
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  // From the last item up, so the line numbers above stay right
  for (const it of [...due].sort((a, b) => b.line - a.line)) {
    const h = it.line - 1;
    lines[h] = lines[h].replace(/([·•|]\s*)(disputed)\b/i, '$1owner');
    let end = lines.findIndex((l, i) => i > h && /^##\s/.test(l));
    if (end < 0) end = lines.length;
    while (end > h + 1 && !lines[end - 1].trim()) end--;
    const dispute = [...it.entries].reverse().find((e) => e.kind === 'dispute');
    const answer = [...it.entries].reverse().find((e) => e.kind === 'answer');
    lines.splice(end, 0, `Escalated (r${rec.criticRound}): the round cap (${rec.cap}) — the critic disputes (${quote(dispute?.text ?? '', 120)}) what the maker answered (${quote(answer?.text ?? '', 120)}); the owner decides. Maker: write Options, Recommend and Владельцу under this line.`);
  }
  let out = lines.join('\n');
  out = appendLog(out, `- r${rec.criticRound} gp brief: the round cap — ${due.map((i) => i.id).join(', ')} disputed at the last round → owner`);
  return { text: out, escalated: due.map((i) => i.id) };
}

// --- Where the ТЗ, its record and the briefs are ----------------------------------------------------------------------

export interface BriefGame {
  id: string;
  dir: string;
  title: string | null;
  channel: string | null;
  genre: string | null;
}

export interface BriefPaths {
  /** The ТЗ */
  tz: string;
  /** Its record: <name>-review.md next to it */
  record: string;
  /** Where the briefs and the round snapshots go */
  work: string;
  game: BriefGame | null;
}

/** game.yaml read loosely — at step 1 its concept and money are still TODO, and it needn't validate */
export function readGameLoosely(dir: string): BriefGame | null {
  const f = join(dir, 'game.yaml');
  if (!existsSync(f)) return null;
  let d: Record<string, unknown> = {};
  try {
    d = (parseYaml(readFileSync(f, 'utf8')) ?? {}) as Record<string, unknown>;
  } catch {
    /* a game.yaml that doesn't parse: its folder name is still the id */
  }
  const s = (v: unknown) => (typeof v === 'string' && v.trim() && !/^TODO\b|__[A-Z]+__/.test(v) ? v.trim() : null);
  const money = (d.money ?? {}) as Record<string, unknown>;
  return { id: s(d.id) ?? basename(dir), dir, title: s(d.title), channel: s(d.channel), genre: s(money.genre) };
}

/** The game a ТЗ belongs to: a game.yaml beside it, or the one game of the repository it is in (games/<id>/game.yaml) */
export function gameOfFile(file: string): BriefGame | null {
  let d = dirname(resolve(file));
  for (let k = 0; k < 4 && d !== dirname(d); k++, d = dirname(d)) {
    const own = readGameLoosely(d);
    if (own) return own;
    const games = join(d, 'games');
    if (existsSync(games) && statSync(games).isDirectory()) {
      const ids = readdirSync(games).filter((x) => existsSync(join(games, x, 'game.yaml')));
      if (ids.length === 1) return readGameLoosely(join(games, ids[0]));
      if (ids.length > 1) return null;
    }
  }
  return null;
}

/** The record of a ТЗ: docs/gdd.md → docs/gdd-review.md */
export const recordOf = (tz: string) => join(dirname(tz), `${basename(tz, extname(tz))}-review${extname(tz) || '.md'}`);

/**
 * `gp brief <arg>`: a ТЗ file (any .md or .txt), or a game — its repository's docs/gdd.md (a gp init repository keeps the
 * owner's ТЗ there), else gdd.md in the game's folder. The briefs go to `out`, else the game's qa/, else qa/ beside the ТЗ.
 */
export function locateBrief(arg: string | undefined, o: { out?: string } = {}): BriefPaths {
  let tz: string | null = null;
  let game: BriefGame | null = null;
  if (arg && existsSync(arg) && statSync(arg).isFile() && !/\.ya?ml$/i.test(arg)) {
    tz = resolve(arg);
    game = gameOfFile(tz);
  } else {
    const loc = locateGame(arg);
    game = readGameLoosely(loc.dir);
    const repo = basename(dirname(loc.dir)) === 'games' ? dirname(dirname(loc.dir)) : null;
    const tried = [...(repo ? [join(repo, GDD_FILE)] : []), join(loc.dir, 'gdd.md'), join(loc.dir, GDD_FILE)];
    tz = tried.find((f) => existsSync(f)) ?? null;
    if (!tz) throw new Error(`No ТЗ for ${loc.id}: looked at ${tried.map(shown).join(', ')}. Save the owner's ТЗ as ${GDD_FILE} in the game's repository, or pass the file: gp brief <path/to/gdd.md>`);
  }
  return { tz, record: recordOf(tz), work: o.out ? resolve(o.out) : game ? join(game.dir, 'qa') : join(dirname(tz), 'qa'), game };
}

/** The ТЗ as the critic read it in round N: qa/brief/<name>-r<N>.md */
export const snapshotFile = (p: Pick<BriefPaths, 'tz' | 'work'>, round: number) => join(p.work, BRIEF_DIR, `${basename(p.tz, extname(p.tz))}-r${round}${extname(p.tz) || '.md'}`);

/** Every round's snapshot that is on disk */
export function loadSnapshots(p: Pick<BriefPaths, 'tz' | 'work'>): Record<number, string> {
  const dir = join(p.work, BRIEF_DIR);
  if (!existsSync(dir)) return {};
  const name = basename(p.tz, extname(p.tz));
  const out: Record<number, string> = {};
  for (const f of readdirSync(dir)) {
    const m = f.match(new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}-r(\\d+)\\.\\w+$`));
    if (m) out[Number(m[1])] = readFileSync(join(dir, f), 'utf8');
  }
  return out;
}

// --- The platform's facts for the critic ----------------------------------------------------------------------------

/** The genres a ТЗ reads as, by its words (English and Russian), the strongest first */
const GENRE_WORDS: [string, RegExp][] = [
  ['roguelite', /rogue-?lite|rogue-?like|рогалик|роглайт|рогалайк|roguelite|перманентн\w* смерт|permadeath/gi],
  ['survivors', /survivors?-?like|\bsurvivors\b|вампир\w* сурвайвор|орды врагов|hordes? of/gi],
  ['platformer', /platformer|платформер/gi],
  ['deckbuilder', /deck-?build\w*|колод\w*|deckbuilder/gi],
  ['tower-defense', /tower defen[cs]e|товер-?дефенс|защит\w* башн/gi],
  ['tycoon', /tycoon|тайкун/gi],
  ['merge', /\bmerge\b|мерж|слиян/gi],
  ['clicker', /clicker|кликер/gi],
  ['idle', /\bidle\b|incremental|айдл|инкрементал/gi],
  ['puzzle', /puzzle|головоломк|пазл|sokoban|match-?3/gi],
  ['shooting', /shooter|shoot ['’]?em|шутер|стрелялк/gi],
  ['driving', /racing|driving|гонк|дрифт/gi],
  ['io', /\.io\b/gi],
  ['strategy', /strategy|стратеги/gi],
  ['action', /\baction\b|slasher|слэшер|слешер|экшен|экшн|beat ['’]?em|hack.?and.?slash|бой|сражен|combat/gi],
];

export function genresOfText(text: string): string[] {
  return GENRE_WORDS.map(([id, re]) => [id, (text.match(re) ?? []).length] as const)
    .filter(([, n]) => n > 0)
    .sort((a, b) => b[1] - a[1])
    .map(([id]) => id);
}

/**
 * The names a ТЗ borrows: the protected names and brands (vocabulary.ts), a hit's signature words, the taken concepts
 * (taken.ts), and the names it points at — "like X", "как в X", "в духе X", "inspired by X", "референс: X"
 */
export function referencesIn(text: string): { brands: string[]; vocabulary: string[]; taken: string[]; named: string[] } {
  const named = new Set<string>();
  const NAME = String.raw`([A-Z][\w'’:&.-]*(?:\s+(?:[A-Z0-9][\w'’:&.-]*|of|the|and))*)`;
  // Not \b: it knows only ASCII letters, and «как в» starts with a Cyrillic one
  const POINT = new RegExp(String.raw`(?:^|[^\p{L}])(?:like|à la|as in|inspired by|references?:?|как в|в духе|в стиле|вдохновл\p{L}* (?:игрой )?|референс\p{L}*:?|похож\p{L}* на|наподобие|как у)\s+["«]?${NAME}`, 'gu');
  for (const m of text.matchAll(POINT)) {
    const n = m[1].replace(/[.,:;'’-]+$/, '').trim();
    if (n.length > 2 && !/^(The|A|An|It|This|That|In|On|And|Or|We|I)$/.test(n)) named.add(n);
  }
  // A list after a "References"/"Референсы" label: "Katana Zero, Hotline Miami, Hades"
  for (const m of text.matchAll(/^\s*(?:[-*]\s*)?\**(?:references?|референсы?|reference games|похожие игры|аналоги)\**\s*[:—-]\s*(.+)$/gim))
    for (const part of m[1].split(/\s*[,;/]\s*|\s+и\s+|\s+and\s+/)) {
      const n = part.replace(/[*_"«»()]/g, '').split(/\s+[—–-]\s+/)[0].replace(/[.,:;]+$/, '').trim();
      if (/^[A-Z0-9]/.test(n) && n.length > 2) named.add(n);
    }
  return {
    brands: brandsIn(text),
    vocabulary: borrowedVocabulary([text]).map((v) => `${v.hit} (${v.terms.join(', ')})`),
    taken: takenConceptsFor(text).map((t) => `${t.what}: ${t.titles.slice(0, 3).join(', ')}`),
    named: [...named],
  };
}

/** The "Known gaps" list of AGENTS.md §5, as written (what the platform can't do yet) */
export function knownGaps(agents = join(ROOT, 'AGENTS.md')): string[] {
  if (!existsSync(agents)) return [];
  const lines = readFileSync(agents, 'utf8').split('\n');
  const at = lines.findIndex((l) => /^Known gaps\b/.test(l));
  if (at < 0) return [];
  const out: string[] = [];
  for (let i = at + 1; i < lines.length && /^- /.test(lines[i]); i++) out.push(lines[i].replace(/^- /, '').trim());
  return out;
}

const rowText = (id: string) => {
  const r = MONEY_TABLE[id];
  if (!r) return `${id}: (not in MONEY_TABLE)`;
  const v = r.low === r.high ? `${r.mid}` : `${r.low} / ${r.mid} / ${r.high}`;
  return `\`${id}\` — ${r.what}: ${v} ${r.unit} (${r.confidence})`;
};
const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);
const cell = (s: string) => s.replace(/\|/g, '\\|');

export interface BriefContext {
  paths: BriefPaths;
  /** The game's title, else the ТЗ's first heading, else its file name */
  title: string;
  channel: string;
  /** The genre named (game.yaml money.genre, --genre) or read from the ТЗ's words */
  genre: { id: string; from: string } | null;
  tzText: string;
  results: RecordedResult[];
  date: string;
  cap: number;
  /** The command that runs gp brief for this ТЗ, as the agents should type it */
  command: string;
}

/**
 * How the agents run gp brief on this ТЗ: in a game's own repository `scripts/gp.sh brief docs/gdd.md` (gp runs from the
 * platform there), else `npm run gp -- brief <path>` from the platform
 */
export function briefCommand(p: Pick<BriefPaths, 'tz' | 'game'>): string {
  const repo = p.game && basename(dirname(p.game.dir)) === 'games' ? dirname(dirname(p.game.dir)) : null;
  if (repo && existsSync(join(repo, 'scripts/gp.sh')) && !relative(repo, p.tz).startsWith('..')) return `scripts/gp.sh brief ${relative(repo, p.tz)}`;
  return `npm run gp -- brief ${shown(p.tz)}`;
}

/** The title of a ТЗ for the briefs: the game's, else the ТЗ's first heading, else its file name */
export function titleOf(p: BriefPaths, tzText: string): string {
  const h = tzText.match(/^#\s+(.+)$/m)?.[1]?.replace(/\s*[—–-]\s*(?:ТЗ|GDD|game design document|техническое задание|дизайн-документ)(?=$|[\s.,:;()]).*$/i, '').replace(/^(ТЗ|GDD)\s*[:—–-]\s*/i, '').trim();
  return p.game?.title ?? (h || basename(p.tz, extname(p.tz)));
}

/** The genre for the facts: --genre, else game.yaml money.genre, else the ТЗ's words */
export function briefGenre(flag: string | undefined, game: BriefGame | null, tzText: string): { id: string; from: string } | null {
  if (flag && genreTopic(flag)) return { id: flag, from: '--genre' };
  if (game?.genre && genreTopic(game.genre)) return { id: game.genre, from: 'game.yaml money.genre' };
  const g = genresOfText(tzText);
  if (!g.length) return null;
  // A sub-genre first when the text names it with its genre ("an action roguelite" is a roguelite): its genre comes with it
  const sub = g.find((id) => {
    const t = genreTopic(id);
    return !!t?.sub && (g[0] === id || g[0] === t.genre.id);
  });
  return { id: sub ?? g[0], from: `the ТЗ's words (${g.slice(0, 3).join(', ')}) — name it with --genre if this is wrong` };
}

function genreFacts(g: { id: string; from: string } | null): string[] {
  const L: string[] = [];
  const t = g ? genreTopic(g.id) : null;
  if (!t) {
    L.push('No genre named or read from the ТЗ: ask which (`ambiguity`) — the benchmarks and the must-haves depend on it. The genres and what their players expect:', '');
    for (const gi of Object.values(GENRE_INFO).filter((x) => x.id !== 'kids')) L.push(`- **${gi.id}** — ${gi.players}; must-haves: ${expectationsFor(gi.id).map((e) => `\`${e.id}\``).join(', ') || 'none checked'}`);
    L.push('');
    return L;
  }
  const { genre, sub } = t as { genre: GenreInfo; sub: SubGenreInfo | null };
  L.push(`**${sub ? `${sub.name} (${genre.name})` : genre.name}** — from ${g!.from}. Players come for: ${sub?.players ?? genre.players}.`, '');
  L.push(`Benchmarks on CrazyGames (MONEY_TABLE): ${[genre.money.minutes, genre.money.d1, genre.money.breakEvery].map(rowText).join('; ')}.`, '');
  L.push(`What its players expect — the must-haves (packages/spec/src/genres.ts; \`gp explain genre.${sub?.id ?? genre.id}\`). A ТЗ that lacks one, or cuts one from the first version, is a question:`, '');
  for (const e of expectationsFor(genre.id, sub?.id ?? null)) L.push(`- \`${e.id}\`: ${e.what}${e.later ? ` (${e.later})` : ''}${e.blocks.length ? ` — ${e.blocks.map((b) => `\`${b}\``).join(', ')}` : ''}${e.rewarded ? ` — or a rewarded offer (${e.rewarded.join('/')})` : ''}`);
  const blocks = blocksFor(genre.id, sub?.id ?? null);
  L.push('', `The platform's blocks that fit it (\`gp catalog blocks --genre ${sub?.id ?? genre.id}\`) — what the ТЗ can have without new code:`, '');
  L.push(blocks.map((b) => `\`${b.name}\` (${clip(b.what, 70)})`).join(' · '), '');
  return L;
}

/** What CrazyGames said about our games: each reason, how often, and to whom */
function verdictLines(results: readonly RecordedResult[]): string[] {
  const by = new Map<string, string[]>();
  for (const r of results) if (r.review?.verdict === 'rejected') by.set(r.review.reason ?? '(no reason recorded)', [...(by.get(r.review.reason ?? '(no reason recorded)') ?? []), r.title ?? r.game]);
  const approved = results.filter((r) => r.review?.verdict === 'approved').map((r) => r.title ?? r.game);
  const L = [...by].sort((a, b) => b[1].length - a[1].length).map(([reason, games]) => `- Rejected ${games.length}× "${reason}": ${[...new Set(games)].join(', ')}`);
  if (approved.length) L.push(`- Approved ${approved.length}×: ${[...new Set(approved)].join(', ')}`);
  return L;
}

/** The facts a question is grounded in: the channel and its budget, the first minute and the session, the verdicts, Basic Launch, the money model, the genre, the engines and gaps, the names the ТЗ borrows, the lessons */
export async function platformFacts(c: BriefContext): Promise<string[]> {
  const ch = CHANNELS[c.channel];
  const bud = budgetFor(c.channel);
  const { stopsLines } = await import('./design.ts');
  const refs = referencesIn(c.tzText);
  const gaps = knownGaps();
  const L: string[] = ['## The platform\'s facts (ground every question in one of these)', ''];
  L.push(`### The channel: ${ch?.title ?? c.channel}`, '');
  if (ch) for (const r of [...ch.rules, ...(AUDIENCES[ch.audiences?.[0] ?? 'general']?.rules ?? [])]) L.push(`- ${r}`);
  if (bud) L.push(`- **Size and load budget:** the upload is one \`index.html\` (the portal's form takes files, not archives); ${bud.gzipKB} KB gzipped ≈ ${bud.warnLoadSec} s to a tappable Play on a slow phone (1.6 Mbps, 4× CPU); over ${bud.hardMB} MB fails. A painted game counts its pictures: what Play doesn't need goes in asset chapters (docs/guides/art.md § 5.2). Raised only on purpose in game.yaml \`budget\`.`);
  L.push(`- **Scope:** more than ${SCOPE_MAX_SCREENS} screens on a first submission is W_SCOPE; a screen a reviewer opens unfinished is what our quality rejections were made of.`, '');
  L.push('### The first minute and the session (docs/guides/first-minute.md; `gp qa` measures each)', '');
  L.push(
    '- At most **1 click** from loading to gameplay on CrazyGames ("land new users in gameplay immediately… a maximum of 1 click"): a first visit boots straight into a safe first run (`host.firstVisit`).',
    '- **No loss in the first 12 s** untouched; **≤ 25 words** before the first action; touch controls **visible at once**; a quiet start; **≥ 30 fps at 4× CPU**.',
    `- A new player's session: the first natural stop before **10 min** of play is W_SESSION_SHORT (${rowText('cg.full.gateMin')}). The results screen's big button continues (\`mountResults\`), never Menu.`,
    '- Ten languages on a portal (`languages: [en, es, pt-BR, fr, de, ru, tr, it, pl, id]`): every text through `host.t()` — a ТЗ full of dialogue is ten times the text.',
    '',
  );
  L.push('### What CrazyGames said about our games (publisher/results.yaml)', '', ...verdictLines(c.results), '');
  const { CRAZYGAMES_BLOCKING } = await import('./review.ts');
  if (c.channel === 'crazygames') L.push('What our quality review marks `[blocking]` on CrazyGames (gp review): ' + CRAZYGAMES_BLOCKING.map((b) => clip(b.what, 90)).join('; ') + '.', '');
  L.push(`### Basic Launch: where approved games stopped (Full Launch needs ${BASIC_LAUNCH.fullLaunchAt} of ${BASIC_LAUNCH.of} on a device class)`, '');
  L.push(...stopsLines(c.results), '');
  L.push('### The forecast model (MONEY_TABLE in packages/spec/src/money.ts; `gp forecast --idea` for a candidate)', '');
  for (const id of ['cg.review.pass', 'cg.full.gateMin', 'cg.platform.d1', 'cg.full.returnNone', 'cg.full.returnDaily', 'cg.full.metaShort', 'cg.full.slowLoad', 'cg.resubmit.afterStop']) L.push(`- ${rowText(id)}`);
  L.push('');
  L.push('### The genre', '', ...genreFacts(c.genre));
  L.push('### The engines, physics and the known gaps', '');
  L.push(`- Engines: ${Object.values(ENGINES).map((e) => `\`${e.id}\` (${clip(e.when, 80)})`).join('; ')}.`);
  L.push(`- Physics: ${Object.values(PHYSICS).map((p) => `\`${p.id}\` ≈ ${p.gzipKB} KB gzipped`).join(', ')} through @gp/physics. Not supported: ${Object.keys(UNSUPPORTED_ENGINES).filter((k) => !k.startsWith('rapier')).join(', ')}.`);
  if (gaps.length) L.push('- Known gaps (AGENTS.md §5 — a game that needs one writes it in its own code and files a block request):', ...gaps.map((g) => `  - ${g}`));
  L.push('');
  L.push('### The names the ТЗ borrows (originality and trademarks)', '');
  const any = refs.named.length || refs.brands.length || refs.vocabulary.length || refs.taken.length;
  if (refs.named.length) L.push(`- Games or works it points at: ${refs.named.map((n) => `**${n}**`).join(', ')} — a reference for the team, never in the title, the texts, the art or the listing (W_TRADEMARK_TEXT; CrazyGames rejects "quite close to existing titles").`);
  if (refs.brands.length) L.push(`- Protected names and brands (packages/spec/src/vocabulary.ts): ${refs.brands.join(', ')}.`);
  if (refs.vocabulary.length) L.push(`- A hit's signature words: ${refs.vocabulary.join('; ')} — \`gp uniqueness\` takes points off for them.`);
  if (refs.taken.length) L.push(`- Taken concepts it reads like (packages/spec/src/taken.ts, W_CONCEPT_TAKEN): ${refs.taken.join('; ')}.`);
  if (!any) L.push('- None found by the platform\'s lists — read for them yourself (a reference the ТЗ calls by another word, a character, a famous mechanic\'s name).');
  L.push('');
  L.push('### The lessons: what the people who judged our games told them off for (`gp lessons`)', '');
  L.push('| Lesson | The flaw | The usual fix |', '|---|---|---|');
  for (const l of LESSONS) L.push(`| \`${l.id}\` | ${cell(l.flaw)} | ${cell(clip(l.fix, 180))} |`);
  L.push('');
  return L;
}

// --- The briefs -----------------------------------------------------------------------------------------------------

/** An item as the briefs quote it: its heading and its history */
export function itemText(it: BriefItem): string[] {
  const L = [`**${it.id} · ${it.category ?? '?'} · ${it.state}**`];
  for (const e of it.entries) {
    const tag = e.kind === 'ownerSaid' ? (e.date ?? '') : `r${e.round ?? '?'}${e.answer ? `, ${e.answer}` : ''}`;
    L.push(`- ${labelOf(e.kind)} (${tag}): ${e.text}`);
    for (const a of e.attach) L.push(`  - ${labelOfAttach(a.kind)}: ${a.text}`);
  }
  return L;
}

const OWNER_WORDS = '«На платформе мне нужен функционал дописывания ТЗ. Условно есть ТЗ. Задай вопрос о критике ТЗ. Ответь на него. Так до тех пор пока все вопросы и споры не будут закрыты.» (Жаслан, the owner, 2026-10-23)';

/** The categories as a table for the critic */
function categoriesTable(): string[] {
  const L = ['| Category | Ask | The facts | Lessons |', '|---|---|---|---|'];
  for (const c of BRIEF_CATEGORIES) L.push(`| \`${c.id}\` | ${cell(c.ask)} | ${cell(c.facts)} | ${c.lessons.map((l) => `\`${l}\``).join(', ') || '—'} |`);
  return L;
}

/** The item format, filled for the round */
function formatExample(next: number, round: number): string[] {
  return [
    '```markdown',
    `## Q${next} · scope · open`,
    `Q (r${round}): §8 promises 6 districts, 40 weapons and 12 bosses in the first version, and §2 a release in four weeks. Which district, how many weapons and which boss are the vertical slice, and what waits for an update?`,
    'Ground: lesson `feel-over-features` (our rejected games grew 75 weapons and 16 screens); W_SCOPE at more than 15 screens',
    '```',
  ];
}

/** qa/brief-critic.md: the critic's whole task for this round */
export async function criticBrief(c: BriefContext, rec: BriefRecord | null, turn: Turn): Promise<string> {
  const r = turn.round;
  const next = rec?.items.length ? Math.max(...rec.items.map((i) => i.n)) + 1 : 1;
  const unruled = rec?.items.filter((i) => i.state === 'answered') ?? [];
  const owners = rec?.items.filter((i) => i.state === 'owner') ?? [];
  const last = r >= c.cap;
  const L: string[] = [
    `# ${c.title} — the ТЗ critic's brief, round ${r} of ${c.cap}`,
    '',
    `Written by \`${c.command}\` on ${c.date}, for **a critic agent who did not write this ТЗ and will not build the game**.`,
    '',
    `**Why.** ${OWNER_WORDS} A ТЗ is cheapest to fix before code exists: every game we built from a brief and sent to CrazyGames met its problems at the review or at Basic Launch instead (below). Your job is to find what would make this game fail to be built in the platform, fail the portal's review, or stop at Basic Launch — and ask about it, pointedly, before anything is built. The game's maker answers each question; you then close or dispute each answer; the loop runs until nothing is open or disputed and you have no further questions, ${c.cap} rounds at most.`,
    '',
    '## Your task',
    '',
    `- **The ТЗ:** ${shown(c.paths.tz)} — read it whole${r > 1 ? ' (it has changed since the last round: the maker edits it in place)' : ''}.`,
    `- **The record:** ${shown(c.paths.record)} — you write your questions and rulings there, in its format (below); \`${c.command} --check\` checks it.`,
    '',
  ];
  if (turn.fix.length) L.push('**First fix these in your entries** (`--check` found them):', '', ...turn.fix.map((p) => `- line ${p.line}: ${p.message}`), '');
  if (r > 1) {
    L.push(`### 1. Rule on every answer (${unruled.length})`, '');
    if (unruled.length) {
      L.push(`For each item below write under its history either \`Close (r${r}): <why the answer settles it>\` and set its heading to \`closed\`, or \`Dispute (r${r}): <what is still wrong, and what would close it>\` and set it to \`disputed\`. Dispute only what still matters: a change that holds is closed even if you'd have worded it otherwise. A change says what it changed in the ТЗ (\`ТЗ: …\`): check the ТЗ says it.${last ? ` **This is the last round:** a dispute you raise now goes to the owner (gp brief marks it \`owner\`) — dispute only what you'd put to him.` : ''}`, '');
      for (const it of unruled) L.push(...itemText(it), '');
    } else L.push('None: every answer is ruled on.', '');
    if (owners.length) {
      L.push(`The maker sent ${owners.length} item(s) to the owner: ${owners.map((i) => i.id).join(', ')}. The owner said «Не спрашивай — делай» (2026-10-03): only a product decision only he can make goes to him. If the maker could decide one itself, dispute it (\`Dispute (r${r}): …\`, heading \`disputed\`).`, '');
    }
    L.push(`### 2. New questions, or «no further questions»`, '');
  } else L.push('### Ask', '');
  L.push(
    `Ask what the earlier rounds didn't — at most ${QUESTIONS_PER_ROUND} new questions, the ones that would change the build or the review first. Each question is a new item, numbered from **Q${next}**, state \`open\`, round **r${r}**. When you have nothing more that matters, write the log line \`- r${r} critic: no further questions\` instead (that ends the loop once every item is closed or with the owner).`,
    '',
    '**A question that counts:**',
    '',
    '- **One decision.** Not "the economy is unclear" — "§5 gives no price for the second weapon and no income per run: how many runs to the first purchase?"',
    '- **Pointed at the ТЗ.** Quote it or name its section; say what clashes, what is missing or what can\'t be built — and what a good answer looks like (a number, a cut, a choice between two).',
    '- **Grounded.** A `Ground:` line under it names the platform fact it rests on (the facts below): a must-have id, a lesson id, a game in publisher/results.yaml, a MONEY_TABLE row, a rule code (W_SESSION_SHORT), the budget, a block, a doc. `--check` refuses a ground that names none.',
    '- **Not a nit.** No wording, no style, nothing the ТЗ answers clearly. No question the platform answers by itself (it brings the SDK, ads, saves, languages, QA): ask what the ТЗ must decide.',
    `- **Every category looked at** in round 1 — ${BRIEF_CATEGORIES.map((x) => `\`${x.id}\``).join(', ')} — a category with nothing to ask is fine; one you skipped is not.`,
    '',
    ...categoriesTable(),
    '',
    'An item:',
    '',
    ...formatExample(next, r),
    '',
    `End your turn with a log line under \`## Log\`: \`- r${r} critic: <n> new questions, <n> closed, <n> disputed\`, or \`- r${r} critic: no further questions\`. Then the maker runs \`${c.command}\` for its turn.`,
    '',
  );
  if (rec?.items.length) {
    const closed = rec.items.filter((i) => i.state === 'closed' || i.state === 'owner');
    if (closed.length) L.push('### Settled so far (don\'t ask these again)', '', ...closed.map((i) => `- ${i.id} · ${i.category} · ${i.state}: ${clip(i.entries[0]?.text ?? '', 140)}`), '');
  }
  L.push(...(await platformFacts(c)));
  return L.join('\n');
}

/** qa/brief-answer.md: the maker's whole task for this round */
export function answerBrief(c: BriefContext, rec: BriefRecord, turn: Turn): string {
  const r = turn.round;
  const items = rec.items.filter((i) => turn.items.includes(i.id));
  const L: string[] = [
    `# ${c.title} — the ТЗ maker's brief, round ${r} of ${c.cap}`,
    '',
    `Written by \`${c.command}\` on ${c.date}, for **the game's maker** — the agent who will build this game. The owner wrote the ТЗ; you answer for it.`,
    '',
    `**Why.** ${OWNER_WORDS} A critic who did not write the ТЗ asked the questions below. Answer each one so that the ТЗ you build from is one the platform can build and the portal will take.`,
    '',
    '## Your task',
    '',
    `- **The ТЗ:** ${shown(c.paths.tz)} — you edit it in place (git keeps the owner's text; the record says what changed and why).`,
    `- **The record:** ${shown(c.paths.record)} — write your answer under each item's history, set its heading's state, and add your log line.`,
    '',
    'For each item, one answer, `A (r' + r + ', <kind>): <the decision and why>`:',
    '',
    '- **keep** — the ТЗ stands as written: say why (the critic misread it — quote where the ТЗ says it; or the risk is accepted, and why). Heading: `answered`.',
    '- **change** — **edit the ТЗ first**, in its own language and section (a Russian ТЗ gets Russian text), then add under the answer `ТЗ: §<section> — "<the new text, copied exactly as it now stands>"`; a cut: `ТЗ: §<section> — removed "<the text taken out>"`. `--check` looks for the quote in the ТЗ and checks it is new since the critic read it. Heading: `answered`.',
    '- **owner** — only a product decision only the owner can make: what the game is, its audience, cutting a feature he asked for by name, the title or the brand, money he would stake, a date. The owner said «Не спрашивай — делай» (2026-10-03): decide everything else yourself. Under it, in Russian: `Options: 1) … 2) … (3) …)` (2 or 3), `Recommend: <which and why>`, `Владельцу: <the question as you would send it, one or two sentences>`. Heading: `owner`.',
    '- **A dispute** is answered the same way: a better change, a keep with a better reason, or owner. Don\'t repeat the answer the critic disputed.',
    '',
    'A decision the ТЗ needs (a number, a cut, a rule) is a **change**, not a keep: the build reads the ТЗ, not this record. Ground your reasons in the same facts the critic has (its brief: qa/' + BRIEF_CRITIC + ').',
    '',
  ];
  if (turn.fix.length) L.push('**Fix these first** (`--check` found them):', '', ...turn.fix.map((p) => `- line ${p.line}: ${p.message}`), '');
  L.push(`## The items (${items.length})`, '');
  for (const it of items) L.push(...itemText(it), '');
  L.push(
    'An answer with a change:',
    '',
    '```markdown',
    `A (r${r}, change): The first version is the Docks district only, 6 weapons and its boss; the other five districts go to the updates list.`,
    'ТЗ: §8 Vertical slice — "Первая версия: только район Доки, 6 видов оружия и босс района"',
    '```',
    '',
    'An owner item:',
    '',
    '```markdown',
    `A (r${r}, owner): Whether the game keeps the story mode is the owner's call: he asked for it by name.`,
    'Options: 1) оставить сюжет в первой версии (3 сцены); 2) сюжет в обновлении, первая версия — аркада; 3) только интро и финал',
    'Recommend: 3) — интро и финал дают мотивацию, не задерживая первую минуту',
    'Владельцу: Сюжетный режим в первой версии — оставить целиком, перенести в обновление или только интро и финал? Рекомендую интро и финал.',
    '```',
    '',
    `End your turn with a log line under \`## Log\`: \`- r${r} maker: <n> keep, <n> change, <n> owner\`, then run \`${c.command}\`: it checks your ТЗ lines and writes the critic's next brief.`,
    '',
  );
  return L.join('\n');
}

/** The owner's questions: the `owner` items, as he reads them — in Russian */
export function ownerQuestions(rec: Pick<BriefRecord, 'items'>): { id: string; category: string; ask: string; options: string; recommend: string }[] {
  return rec.items
    .filter((i) => i.state === 'owner')
    .map((i) => {
      const at = i.entries.map((e, k) => (e.kind === 'escalated' || (e.kind === 'answer' && e.answer === 'owner') ? k : -1)).filter((k) => k >= 0).at(-1) ?? 0;
      const after = i.entries.slice(at).flatMap((e) => e.attach);
      const get = (k: AttachKind) => after.filter((a) => a.kind === k).at(-1)?.text ?? '';
      return { id: i.id, category: BRIEF_CATEGORIES.find((x) => x.id === i.category)?.ru ?? i.category ?? '', ask: get('ownerQuestion') || i.entries[0]?.text || '', options: get('options'), recommend: get('recommend') };
    });
}

/** qa/brief-owner.md: the questions to send the owner, in Russian */
export function ownerMarkdown(title: string, tz: string, record: string, rec: Pick<BriefRecord, 'items'>, date: string): string {
  const qs = ownerQuestions(rec);
  const L = [`# Вопросы владельцу по ТЗ «${title}»`, '', `${date} · ТЗ: ${tz} · ревью: ${record} · ${stateSummary(rec)}`, ''];
  if (!qs.length) L.push('Вопросов к владельцу нет: всё решено в ревью.', '');
  else {
    L.push(`Решить может только владелец — ${qs.length} ${qs.length === 1 ? 'вопрос' : qs.length < 5 ? 'вопроса' : 'вопросов'}:`, '');
    qs.forEach((q, k) => {
      L.push(`${k + 1}. **${q.ask}** (${q.id}, ${q.category})`);
      if (q.options) L.push(`   Варианты: ${q.options}`);
      if (q.recommend) L.push(`   Рекомендация: ${q.recommend}`);
    });
    L.push('', 'Когда владелец ответит: под пунктом в ревью — `Owner (ГГГГ-ММ-ДД): <ответ>`, заголовок — `closed`, и правка ТЗ с `ТЗ: §… — "…"`, если ответ её требует.', '');
  }
  return L.join('\n');
}
