// Gemini as a reader of a gameplay video (or of frames): `gp design --gemini`'s second opinion.
//
// The owner had good results giving Gemini a gameplay video and asking it, as a game designer, what to improve. This is
// that call, from the platform: the video goes inline when it is small, else through the Files API (a resumable upload,
// then a wait until the file is ACTIVE), then generateContent with the designer's prompt; the answer is text.
//
// The key: GEMINI_API_KEY (or GOOGLE_API_KEY) in the environment — the same as `gp art` (art.ts). It is handed to the
// transport only, which puts it in the x-goog-api-key header of a child process's request (never in a URL, an argument,
// a file or a message: every error text is passed through redact() first). With GEMINI_VIA_NETWORK=1 and no key, the
// request goes without one, for a cloud environment whose network adds the header (a network secret).
//
// The model: a new key may not reach the one asked for (Idle Garage Evolution 1.5.0, 2026-10-20: five tries, no
// answer — the old Pro default 404 "no longer available to new users", the Pro preview 429 "free tier, no quota", an
// older Flash 404 "use <a newer one>", the newer Flash 502 with 2.4 MB inline). So the default is a Flash model a free
// key can use, and resolveModel() asks the model a one-word question first — cheap, BEFORE the 90-s video is recorded —
// and follows the answer: a 404 that names a replacement goes to it (one that names none: the newest Flash the key
// lists), a 429 "no quota" goes to Flash and says so plainly. A 5xx is retried once; an inline video that still fails
// goes again through the Files API.
//
// The transport is a parameter: the tests run the whole exchange against a mock, never the network.

import { execFile } from 'node:child_process';
import { readFileSync, statSync } from 'node:fs';
import { freeTierBlocked, quotaMessage, retryDelaySec } from './art.ts';

export const GEMINI_API = 'https://generativelanguage.googleapis.com';
/**
 * The default model for a designer's reading of a video (`--model` or GP_DESIGN_MODEL another): a Flash model, which a
 * new key on the free tier can use (Pro needs billing). When it is retired, its 404 names the replacement and
 * resolveModel() follows it
 */
export const DEFAULT_DESIGN_MODEL = 'gemini-3.8-flash';
/** Where a model without quota (a 429 "free tier, limit 0") falls back to */
export const FLASH_MODEL = DEFAULT_DESIGN_MODEL;
/** At most this many models are tried in one resolveModel() (a chain of 404s that loops stops here) */
export const MAX_MODEL_HOPS = 4;
/** A request carries at most 20 MB, base64 inflates by 4/3: a video up to this goes inline, a bigger one through the Files API */
export const INLINE_MAX_BYTES = 14 * 1024 * 1024;
/** How long an uploaded video may take to become ACTIVE, and how often to ask */
export const FILE_WAIT_MS = 180_000;
export const FILE_POLL_MS = 4000;

export interface HttpRequest {
  method: 'GET' | 'POST';
  url: string;
  headers?: Record<string, string>;
  body?: string | Buffer;
}
export interface HttpResponse {
  status: number;
  /** Lower-case names */
  headers: Record<string, string>;
  text: string;
}
/** One HTTP exchange; `key` goes into the x-goog-api-key header (empty: none — the network adds it) */
export type GeminiHttp = (req: HttpRequest, key: string) => Promise<HttpResponse>;

/** The key from the environment, or null. GEMINI_VIA_NETWORK=1 with no key: '' (the request goes without one) */
export function geminiKey(env: NodeJS.ProcessEnv = process.env): string | null {
  const key = env.GEMINI_API_KEY || env.GOOGLE_API_KEY || '';
  if (key) return key;
  return env.GEMINI_VIA_NETWORK === '1' ? '' : null;
}

/** How to set the key, for the message when there is none (never the key itself) */
export const GEMINI_KEY_HELP = [
  'No Gemini API key: set GEMINI_API_KEY in the environment (a key from aistudio.google.com → Get API key; GOOGLE_API_KEY works too), e.g.',
  '  GEMINI_API_KEY=<your key> npm run gp -- design <game> --gemini',
  "In a cloud session: add it to the environment's secrets (a new session picks it up), or as a network secret — header x-goog-api-key for generativelanguage.googleapis.com — and run with GEMINI_VIA_NETWORK=1.",
  'Never write the key into a file of the repository. Everything else gp design makes was made without it.',
].join('\n');

/** Every occurrence of the key in a text, masked: errors and answers pass through this before they are shown or written */
export function redact(text: string, key: string): string {
  return key && key.length >= 4 ? text.split(key).join('***') : text;
}

/**
 * The default transport: Node's fetch in a child process with NODE_USE_ENV_PROXY=1 (so HTTPS_PROXY is used, as gp art
 * does). The request goes on stdin as JSON, the key in the child's environment — never in its arguments.
 */
export const nodeHttp: GeminiHttp = (req, key) =>
  new Promise((resolve, reject) => {
    const script = `let b='';process.stdin.setEncoding('utf8');process.stdin.on('data',(d)=>(b+=d)).on('end',async()=>{const q=JSON.parse(b);try{const h=Object.assign({},q.headers);if(process.env.GP_GEMINI_KEY)h['x-goog-api-key']=process.env.GP_GEMINI_KEY;const r=await fetch(q.url,{method:q.method,headers:h,body:q.body64==null?undefined:Buffer.from(q.body64,'base64')});const hs={};r.headers.forEach((v,k)=>{hs[k]=v});process.stdout.write(JSON.stringify({status:r.status,headers:hs,text:await r.text()}))}catch(e){process.stdout.write(JSON.stringify({status:0,headers:{},text:String(e&&e.message||e)}))}})`;
    const body = req.body === undefined ? null : Buffer.isBuffer(req.body) ? req.body.toString('base64') : Buffer.from(req.body).toString('base64');
    const child = execFile(process.execPath, ['-e', script], { env: { ...process.env, GP_GEMINI_KEY: key, NODE_USE_ENV_PROXY: '1', NODE_NO_WARNINGS: '1' }, maxBuffer: 64 * 1024 * 1024, encoding: 'utf8' }, (err, stdout) => {
      if (err && !stdout) return reject(new Error(redact(String(err.message).split('\n')[0], key)));
      try {
        resolve(JSON.parse(stdout) as HttpResponse);
      } catch {
        reject(new Error(`no answer from the request (${redact(stdout.slice(0, 200), key)})`));
      }
    });
    child.stdin!.end(JSON.stringify({ method: req.method, url: req.url, headers: req.headers ?? {}, body64: body }));
  });

/** What Gemini is shown: a video file, or still frames (no ffmpeg) */
export type GeminiMedia = { kind: 'video'; file: string; mime?: string } | { kind: 'frames'; files: string[] };

export interface GeminiAsk {
  prompt: string;
  media: GeminiMedia;
  model: string;
  key: string;
  http?: GeminiHttp;
  /** Progress lines (never the key) */
  log?: (line: string) => void;
  /** For the tests: no real waiting */
  sleep?: (ms: number) => Promise<void>;
  /** A video up to this size goes inline (INLINE_MAX_BYTES; the tests make it small) */
  inlineMax?: number;
}

export interface GeminiAnswer {
  text: string;
  /** The model that answered (another than asked when a fallback was taken: `notes` says why) */
  model: string;
  /** How the media went: inline, uploaded (the file's name), or frames */
  sent: string;
  /** What happened on the way, in plain sentences: a model fallback, the Files API after a failed inline request */
  notes: string[];
}

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** A failed request: the status and the (redacted) body, so a caller can pick a fallback (another model, the Files API) */
export class GeminiError extends Error {
  readonly status: number;
  readonly body: string;
  constructor(message: string, status: number, body: string) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

/** The API's error message in a body ({ error: { message } }), else the body's start */
export function apiMessage(text: string): string {
  try {
    const m = (JSON.parse(text) as { error?: { message?: string } }).error?.message;
    if (m) return m;
  } catch {
    /* not JSON */
  }
  return text.slice(0, 300);
}

/** A 429 that no waiting cures: the key's tier has no quota for this model (the free tier and Pro: "limit: 0") */
export function noQuota(status: number, text: string): boolean {
  return status === 429 && (freeTierBlocked(text) || /\bno quota\b|limit:\s*0\b|"quotaValue":\s*"0"/i.test(text));
}

/** The model a 404 names in its place ("… no longer available to new users. Please use gemini-x instead"), or null */
export function replacementModel(text: string, current: string): string | null {
  const msg = apiMessage(text);
  for (const m of msg.matchAll(/\b(?:use|try|switch to|migrate to|update to|upgrade to|move to|replaced by)\s+(?:the\s+)?(?:(?:latest|newer|new)\s+)?(?:model\s*,?\s+)?[`'"“]?(?:models\/)?(gemini-[a-z0-9][\w.-]*[a-z0-9])/gi)) {
    if (m[1].toLowerCase() !== current.toLowerCase()) return m[1];
  }
  // No verb before it, but one other model named: that one
  const others = [...new Set([...msg.matchAll(/(?:models\/)?(gemini-[a-z0-9][\w.-]*[a-z0-9])/gi)].map((m) => m[1]).filter((n) => n.toLowerCase() !== current.toLowerCase()))];
  return others.length === 1 ? others[0] : null;
}

/** A Flash model (the free tier's): its name says so */
export const isFlash = (model: string) => /flash/i.test(model);

/**
 * The newest Flash model a key lists (models.list: names with generateContent) — never a lite, image, audio or live one;
 * a stable one before a preview of the same version — or null
 */
export function newestFlash(models: readonly { name: string; supportedGenerationMethods?: string[] }[]): string | null {
  const ok = models
    .filter((m) => !m.supportedGenerationMethods || m.supportedGenerationMethods.includes('generateContent'))
    .map((m) => m.name.replace(/^models\//, ''))
    .map((n) => ({ n, m: n.match(/^gemini-(\d+(?:\.\d+)?)-flash(-preview(?:-[\w-]+)?)?$/) }))
    .filter((x) => x.m && !/lite|image|tts|audio|live|thinking|exp/i.test(x.n));
  ok.sort((a, b) => Number(b.m![1]) - Number(a.m![1]) || Number(!!a.m![2]) - Number(!!b.m![2]));
  return ok[0]?.n ?? null;
}

/** A request with one retry for a short rate limit or a server error; errors say the status and the message, never the key */
async function call(http: GeminiHttp, req: HttpRequest, key: string, sleep: (ms: number) => Promise<void>): Promise<HttpResponse> {
  for (let attempt = 0; ; attempt++) {
    let res: HttpResponse;
    try {
      res = await http(req, key);
    } catch (e) {
      throw new GeminiError(`Gemini API: ${redact(String((e as Error).message), key)}`, 0, '');
    }
    const retry = res.status === 429 ? retryDelaySec(res.text) : res.status >= 500 || res.status === 0 ? 4 * (attempt + 1) : null;
    if (retry !== null && retry <= 60 && attempt < 1 && !noQuota(res.status, res.text)) {
      await sleep(retry * 1000);
      continue;
    }
    if (res.status >= 200 && res.status < 300) return res;
    const message = apiMessage(res.text);
    const body = redact(res.text, key);
    if (res.status === 429)
      throw new GeminiError(
        redact(
          noQuota(res.status, res.text)
            ? `Gemini API 429: this key has no quota for this model (${/free[_ ]tier/i.test(res.text) ? 'the free tier' : 'its tier'} gives it none: limit 0) — use a Flash model (--model ${FLASH_MODEL}), or turn on billing for the key's project (aistudio.google.com → Get API key → Set up billing; a Gemini app subscription does not pay for the API)`
            : quotaMessage(message, res.text).replace('the image models', 'this model'),
          key,
        ),
        429,
        body,
      );
    if (res.status === 401 || res.status === 403)
      throw new GeminiError(redact(`Gemini API ${res.status}: the key was refused (${message.split('\n')[0]}) — check GEMINI_API_KEY (aistudio.google.com → Get API key)${key ? '' : '; no key was sent: set GEMINI_API_KEY, or a network secret for generativelanguage.googleapis.com'}`, key), res.status, body);
    throw new GeminiError(redact(`Gemini API ${res.status}: ${message.split('\n')[0]}`, key), res.status, body);
  }
}

const generateUrl = (model: string) => `${GEMINI_API}/v1beta/models/${encodeURIComponent(model)}:generateContent`;

/**
 * The model to ask instead after a refusal, and why (a plain sentence for the log), or null when no other model helps:
 * a 404 that names its replacement → that one; a 429 with no quota (the free tier and a Pro model) → Flash
 */
export function nextModel(model: string, e: unknown): { model: string; why: string } | null {
  if (!(e instanceof GeminiError)) return null;
  if (e.status === 404) {
    const r = replacementModel(e.body, model);
    return r ? { model: r, why: `${model} is not available to this key (404); the API names ${r} in its place — asking it` } : null;
  }
  if (noQuota(e.status, e.body) && !isFlash(model) && FLASH_MODEL !== model)
    return { model: FLASH_MODEL, why: `${model} has no quota on this key — ${/free[_ ]tier/i.test(e.body) ? 'the free tier' : 'its tier'} gives ${/pro/i.test(model) ? 'Pro' : 'this model'} none (429, limit 0); asking ${FLASH_MODEL} instead (for ${model}, turn on billing for the key's project)` };
  return null;
}

/** The key's models (models.list), for a 404 that names no replacement */
async function listModels(http: GeminiHttp, key: string, sleep: (ms: number) => Promise<void>): Promise<{ name: string; supportedGenerationMethods?: string[] }[]> {
  const res = await call(http, { method: 'GET', url: `${GEMINI_API}/v1beta/models?pageSize=1000` }, key, sleep);
  return (JSON.parse(res.text) as { models?: { name: string; supportedGenerationMethods?: string[] }[] }).models ?? [];
}

/** The one-word question that checks a model answers this key (a few tokens: no video, no image) */
export const PROBE_TEXT = 'Reply with the word OK.';

/**
 * Before anything costly (the video): ask the model a one-word question and follow its answer to a model this key can
 * use — a 404's replacement, else the newest Flash the key lists; Flash for a model without quota. Returns the model and
 * what happened on the way (plain sentences: "gemini-x-pro has no quota on this key …"); throws a GeminiError when no
 * model answers (a refused key, no quota even for Flash, the network)
 */
export async function resolveModel(o: { model: string; key: string; http?: GeminiHttp; sleep?: (ms: number) => Promise<void>; log?: (line: string) => void }): Promise<{ model: string; notes: string[] }> {
  const http = o.http ?? nodeHttp;
  const sleep = o.sleep ?? wait;
  const notes: string[] = [];
  const tried = new Set<string>();
  let model = o.model;
  for (let hop = 0; hop < MAX_MODEL_HOPS; hop++) {
    tried.add(model.toLowerCase());
    try {
      await call(http, { method: 'POST', url: generateUrl(model), headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: PROBE_TEXT }] }], generationConfig: { maxOutputTokens: 16 } }) }, o.key, sleep);
      return { model, notes };
    } catch (e) {
      let next = nextModel(model, e);
      if (!next && e instanceof GeminiError && e.status === 404) {
        const flash = newestFlash(await listModels(http, o.key, sleep).catch(() => []));
        if (flash && !tried.has(flash.toLowerCase())) next = { model: flash, why: `${model} is not available to this key (404) and the API names no replacement; the newest Flash model the key lists is ${flash} — asking it` };
      }
      if (!next || tried.has(next.model.toLowerCase())) {
        const msg = (e as Error).message;
        throw new GeminiError(notes.length ? `${msg} (after: ${notes.join('; ')})` : msg, e instanceof GeminiError ? e.status : 0, e instanceof GeminiError ? e.body : '');
      }
      notes.push(next.why);
      o.log?.(next.why);
      model = next.model;
    }
  }
  throw new GeminiError(`Gemini API: no model answered in ${MAX_MODEL_HOPS} tries (${[...tried].join(', ')})`, 0, '');
}

/** Upload a file through the Files API (resumable: start, then upload and finalize), and wait until it is ACTIVE */
export async function uploadFile(http: GeminiHttp, key: string, file: string, mime: string, opts: { sleep?: (ms: number) => Promise<void>; log?: (l: string) => void; waitMs?: number } = {}): Promise<{ name: string; uri: string; mimeType: string }> {
  const sleep = opts.sleep ?? wait;
  const data = readFileSync(file);
  const start = await call(
    http,
    {
      method: 'POST',
      url: `${GEMINI_API}/upload/v1beta/files`,
      headers: { 'X-Goog-Upload-Protocol': 'resumable', 'X-Goog-Upload-Command': 'start', 'X-Goog-Upload-Header-Content-Length': String(data.length), 'X-Goog-Upload-Header-Content-Type': mime, 'Content-Type': 'application/json' },
      body: JSON.stringify({ file: { display_name: 'gp design gameplay' } }),
    },
    key,
    sleep,
  );
  const uploadUrl = start.headers['x-goog-upload-url'];
  if (!uploadUrl) throw new Error('Gemini Files API: the upload did not start (no x-goog-upload-url in the answer)');
  const done = await call(http, { method: 'POST', url: uploadUrl, headers: { 'Content-Length': String(data.length), 'X-Goog-Upload-Offset': '0', 'X-Goog-Upload-Command': 'upload, finalize' }, body: data }, key, sleep);
  type FileInfo = { name?: string; uri?: string; mimeType?: string; state?: string; error?: { message?: string } };
  let info = (JSON.parse(done.text) as { file?: FileInfo }).file ?? {};
  if (!info.name || !info.uri) throw new Error('Gemini Files API: the upload finished without a file name');
  opts.log?.(`uploaded the video (${(data.length / 1048576).toFixed(1)} MB) as ${info.name}`);
  const until = Date.now() + (opts.waitMs ?? FILE_WAIT_MS);
  let polls = 0;
  while (info.state !== 'ACTIVE') {
    if (info.state === 'FAILED') throw new Error(`Gemini Files API: ${info.name} could not be processed (${info.error?.message ?? 'FAILED'})`);
    // A mocked clock moves by the polls, not by the wall
    if (Date.now() > until || polls * FILE_POLL_MS > (opts.waitMs ?? FILE_WAIT_MS)) throw new Error(`Gemini Files API: ${info.name} is still ${info.state ?? 'processing'} after ${Math.round((opts.waitMs ?? FILE_WAIT_MS) / 1000)} s`);
    await sleep(FILE_POLL_MS);
    polls++;
    info = JSON.parse((await call(http, { method: 'GET', url: `${GEMINI_API}/v1beta/${info.name}` }, key, sleep)).text) as FileInfo;
  }
  return { name: info.name!, uri: info.uri!, mimeType: info.mimeType ?? mime };
}

/** A video through the Files API, as a request part */
async function uploadedPart(a: GeminiAsk, http: GeminiHttp, sleep: (ms: number) => Promise<void>, file: string, mime: string): Promise<{ parts: unknown[]; sent: string }> {
  const size = statSync(file).size;
  const f = await uploadFile(http, a.key, file, mime, { sleep, log: a.log });
  return { parts: [{ fileData: { mimeType: f.mimeType, fileUri: f.uri } }], sent: `the video through the Files API (${(size / 1048576).toFixed(1)} MB, ${f.name})` };
}

/** The media as request parts: a small video inline, a big one uploaded, frames as JPEG/PNG images */
async function mediaParts(a: GeminiAsk, http: GeminiHttp, sleep: (ms: number) => Promise<void>): Promise<{ parts: unknown[]; sent: string; inline: boolean }> {
  const m = a.media;
  if (m.kind === 'frames') {
    const parts = m.files.map((f) => ({ inlineData: { mimeType: /\.png$/i.test(f) ? 'image/png' : 'image/jpeg', data: readFileSync(f).toString('base64') } }));
    return { parts, sent: `${m.files.length} frames`, inline: false };
  }
  const mime = m.mime ?? 'video/mp4';
  const size = statSync(m.file).size;
  if (size <= (a.inlineMax ?? INLINE_MAX_BYTES)) return { parts: [{ inlineData: { mimeType: mime, data: readFileSync(m.file).toString('base64') } }], sent: `the video inline (${(size / 1048576).toFixed(1)} MB)`, inline: true };
  return { ...(await uploadedPart(a, http, sleep, m.file, mime)), inline: false };
}

/** A server error or no answer at all (a proxy's "upstream request failed"): worth another route, not another model */
const serverSide = (e: unknown) => e instanceof GeminiError && (e.status >= 500 || e.status === 0);

/**
 * Ask Gemini about the media with the prompt (the media first: Google's advice for video), and return its text. A model
 * that refuses with a 404 naming its replacement, or a 429 without quota, is swapped once (nextModel); an inline video
 * whose request still fails on the server's side after the retry goes again through the Files API
 */
export async function askGemini(a: GeminiAsk): Promise<GeminiAnswer> {
  const http = a.http ?? nodeHttp;
  const sleep = a.sleep ?? wait;
  const notes: string[] = [];
  let media = await mediaParts(a, http, sleep);
  let model = a.model;
  let swapped = false;
  let rerouted = false;
  for (;;) {
    a.log?.(`asking ${model} (${media.sent})`);
    try {
      const res = await call(
        http,
        { method: 'POST', url: generateUrl(model), headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ role: 'user', parts: [...media.parts, { text: a.prompt }] }], generationConfig: { temperature: 0.6 } }) },
        a.key,
        sleep,
      );
      const json = JSON.parse(res.text) as { candidates?: { finishReason?: string; content?: { parts?: { text?: string; thought?: boolean }[] } }[]; promptFeedback?: { blockReason?: string } };
      const text = (json.candidates?.[0]?.content?.parts ?? [])
        .filter((p) => p.text && !p.thought)
        .map((p) => p.text!)
        .join('')
        .trim();
      if (!text) throw new Error(`Gemini API returned no text (${json.promptFeedback?.blockReason ?? json.candidates?.[0]?.finishReason ?? 'no reason given'})`);
      return { text: redact(text, a.key), model, sent: media.sent, notes };
    } catch (e) {
      const next = swapped ? null : nextModel(model, e);
      if (next) {
        swapped = true;
        notes.push(next.why);
        a.log?.(next.why);
        model = next.model;
        continue;
      }
      if (serverSide(e) && media.inline && !rerouted && a.media.kind === 'video') {
        rerouted = true;
        const why = `${(e as Error).message} with the video inline, after a retry: sending it through the Files API instead`;
        notes.push(why);
        a.log?.(why);
        media = { ...(await uploadedPart(a, http, sleep, a.media.file, a.media.mime ?? 'video/mp4')), inline: false };
        continue;
      }
      throw e;
    }
  }
}
