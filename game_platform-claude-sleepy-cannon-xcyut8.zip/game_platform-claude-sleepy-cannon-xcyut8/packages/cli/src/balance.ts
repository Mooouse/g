// The balance check from the game's own bot: `gp balance`, and a section of `gp qa` for code games.
// The game exports `balance()` (a BalanceReport, docs/guides/upgrades.md → the balance report) from bot.ts or balance.ts;
// the platform loads that module the way the game's tests do (Vite: `@gp/*` to the platform's sources, extensionless
// imports), runs it once and reads the numbers against the channel's targets (@gp/core/balance).

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { Worker } from 'node:worker_threads';
import { BOT_SKILLS, evaluateBalance, type BalanceReport, type BalanceVerdict, type DifficultyTarget } from '@gp/core/balance';
import { compareToBot, solveModel, type BalanceModel, type ModelDesign, type ModelResult } from '@gp/core/balance-model';
import type { BalanceRow } from '@gp/core/balance';
import type { ResolvedGame } from '@gp/spec';
import type { GameLocation } from './paths.ts';

/** `export function balance` / `balanceModel`, async too, or `export const …` */
const EXPORTS_BALANCE = /export\s+(?:async\s+)?function\s+balance(?:Model)?\s*\(|export\s+const\s+balance(?:Model)?\s*[=:]/;

/** The game's module that exports balance(): balance.ts, then bot.ts, then any other of its files; null if none */
export function balanceModule(loc: GameLocation): string | null {
  if (!existsSync(loc.dir)) return null;
  const own = readdirSync(loc.dir).filter((f) => /\.(ts|mjs|js)$/.test(f) && !/\.(test|d)\.ts$/.test(f));
  const order = [...own.filter((f) => /^balance\./.test(f)), ...own.filter((f) => /^bot\./.test(f)), ...own.filter((f) => !/^(balance|bot)\./.test(f))];
  return order.map((f) => join(loc.dir, f)).find((f) => EXPORTS_BALANCE.test(readFileSync(f, 'utf8'))) ?? null;
}

export interface BalanceRun {
  file: string;
  report: BalanceReport;
  verdict: BalanceVerdict;
  seconds: number;
  /** The game's balance model, solved (when it exports balanceModel()): its tables and checks */
  model?: ModelResult;
  /** Where the report came from: the bot's balance(), or the model alone */
  source: 'bot' | 'model';
  /** Both ran: the model against the bot (a launch calibrates the model that patches then run alone) */
  compare?: BalanceRow[];
}

export interface BalanceOptions {
  /** Run the bot's balance() too (default true). False: the model alone when the game has one — gp qa in a patch */
  bot?: boolean;
  /** What game.yaml says about the balance: the anchor (strict model checks), the session's and the meta's minutes */
  design?: ModelDesign;
}

const minutes = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : null);

/**
 * The balance design of a game: from the resolved game, or (gp balance on a game.yaml with errors) from game.yaml as
 * written — the anchor counts only when it is filled in, as the validator reads it
 */
export function balanceDesign(game: ResolvedGame | null, raw?: { balance?: { anchor?: { name?: string; unit?: string; says?: string; shape?: string }; difficulty?: unknown }; money?: { session?: { minutes?: unknown }; meta?: { minutes?: unknown } } } | null): ModelDesign {
  if (game) {
    const kit = game.kit.kit === 'code' ? game.kit : null;
    return { anchor: kit?.anchor ?? null, sessionMin: minutes(game.money?.session?.minutes), metaMin: minutes(game.money?.meta?.minutes), difficulty: kit?.difficulty ?? null };
  }
  const a = raw?.balance?.anchor;
  const filled = !!a && [a.name, a.unit].every((x) => typeof x === 'string' && x.trim() && !/^\s*TODO\b/i.test(x));
  return { anchor: filled ? { name: a!.name!, unit: a!.unit!, says: a!.says ?? '', shape: a!.shape === 'run' ? 'run' : 'campaign' } : null, sessionMin: minutes(raw?.money?.session?.minutes), metaMin: minutes(raw?.money?.meta?.minutes), difficulty: rawDifficulty(raw?.balance?.difficulty) };
}

/** game.yaml balance.difficulty as written (a game.yaml with errors): the numbers that are numbers */
function rawDifficulty(d: unknown): DifficultyTarget | null {
  if (!d || typeof d !== 'object') return null;
  const o = d as Record<string, unknown>;
  const out: { -readonly [K in keyof DifficultyTarget]: DifficultyTarget[K] } = {};
  for (const k of BOT_SKILLS) {
    const s = o[k] as { winRate?: unknown; tolerance?: unknown } | undefined;
    const w = minutes(s?.winRate);
    if (w !== null) out[k] = { winRate: w, ...(minutes(s?.tolerance) !== null ? { tolerance: s!.tolerance as number } : {}) };
  }
  const r = o.winningRunMin;
  if (Array.isArray(r) && r.length === 2 && r.every((x) => minutes(x) !== null)) out.winningRunMin = [Math.min(r[0], r[1]), Math.max(r[0], r[1])];
  return Object.keys(out).length ? out : null;
}

/** Load a module with the platform's aliases (a game in its own repository resolves `@gp/*` too) and call balance() */
export async function runBalanceFile(file: string, channel: string, opts: BalanceOptions = {}): Promise<BalanceRun> {
  const { runnerImport } = await import('vite');
  const { gpAliases } = await import('./vite.ts');
  const t0 = performance.now();
  const { module } = await runnerImport<{ balance?: () => BalanceReport | Promise<BalanceReport>; balanceModel?: () => BalanceModel | Promise<BalanceModel> }>(file, {
    configFile: false,
    logLevel: 'error',
    resolve: { alias: gpAliases() },
  });
  if (typeof module.balance !== 'function' && typeof module.balanceModel !== 'function') throw new Error(`${file} has no balance() or balanceModel() export`);
  // The model first (milliseconds): the designer's tables; then the bot, which plays the real game
  const model = typeof module.balanceModel === 'function' ? solveModel(await module.balanceModel(), opts.design ?? {}) : undefined;
  const useBot = typeof module.balance === 'function' && (opts.bot !== false || !model);
  const report = useBot ? await module.balance!() : model!.report;
  if (!report || typeof report !== 'object') throw new Error(`balance() in ${file} returned ${String(report)}, not a BalanceReport`);
  const compare = useBot && model ? compareToBot(model.report, report) : undefined;
  const verdict = evaluateBalance(report, channel, { difficulty: opts.design?.difficulty ?? null, from: useBot ? 'bot' : 'model' });
  return { file, report, verdict, seconds: (performance.now() - t0) / 1000, ...(model ? { model } : {}), source: useBot ? 'bot' : 'model', ...(compare ? { compare } : {}) };
}

/** runBalanceFile in a worker thread (balance-worker.ts), so the event loop stays free while the bot simulates */
export function runBalanceFileInWorker(file: string, channel: string, opts: BalanceOptions = {}): Promise<BalanceRun> {
  return new Promise((resolve, reject) => {
    const w = new Worker(new URL('./balance-worker.ts', import.meta.url), { workerData: { file, channel, opts } });
    w.once('message', (m: { ok: true; run: BalanceRun } | { ok: false; message: string }) => {
      void w.terminate();
      if (m.ok) resolve(m.run);
      else reject(new Error(m.message));
    });
    w.once('error', reject);
    w.once('exit', (code) => code !== 0 && code !== 1 && reject(new Error(`the balance worker exited with ${code}`)));
  });
}

/** The game's balance, or null when it exports none; `worker`: off the main thread (gp qa runs it beside the browser) */
export async function runBalance(loc: GameLocation, channel: string, opts: { worker?: boolean } & BalanceOptions = {}): Promise<BalanceRun | null> {
  const file = balanceModule(loc);
  if (!file) return null;
  return opts.worker ? runBalanceFileInWorker(file, channel, opts) : runBalanceFile(file, channel, opts);
}

/** A row the bot measured but game.yaml gives no target for (balance.difficulty): information, not "not reported" */
const undeclared = (r: BalanceRow) => r.target.startsWith('no target declared');

/**
 * The QA section: a check per failed row, an info per warning, a pass per ok row; no export → a warning, not a failure.
 * Returns the run (null: no export; an Error: it failed) so gp qa's forecast line reads the same report.
 */
export async function balanceQa(
  loc: GameLocation,
  channel: string,
  qa: {
    check(scope: string, name: string, ok: boolean, details?: string): void;
    info(scope: string, name: string, details: string): void;
    /** gp qa's board between sections: the first minute's first celebrated moment, the model's first reward */
    notes?: { modelFirstRewardSec?: number | null; firstHighlightSec?: number | null };
  },
  opts: { worker?: boolean; patch?: boolean; design?: ModelDesign } = {},
): Promise<BalanceRun | Error | null> {
  const S = 'balance';
  let run: BalanceRun | null;
  try {
    // A launch runs the bot and the model and compares them; a patch trusts the model alone (when the game has one)
    run = await runBalance(loc, channel, { worker: opts.worker, bot: !opts.patch, design: opts.design });
  } catch (e) {
    qa.check(S, 'balance(): the game\'s balance report runs', false, String((e as Error).message ?? e).split('\n')[0]);
    return e instanceof Error ? e : new Error(String(e));
  }
  if (!run) {
    qa.info(S, '⚠ balance', 'the game exports no balance() (bot.ts): its progression curve is not checked — docs/guides/upgrades.md#3-the-balance-report');
    return null;
  }
  // The curve (the bot's, or the model's when there is no bot), then the model's own checks: walls, grind, dead buys
  for (const r of [...run.verdict.rows, ...(run.model?.checks ?? [])]) {
    // Measured, with no target in game.yaml (the skill ladder's win rate, the winning run): said, not checked
    if (r.status === 'skip' && undeclared(r)) qa.info(S, r.name, `${r.detail} · ${r.target}`);
    if (r.status === 'skip') continue;
    if (r.status === 'warn') qa.info(S, `⚠ ${r.name}`, `${r.detail} · target: ${r.target}`);
    else qa.check(S, r.name, r.status === 'ok', `${r.detail} · target: ${r.target}`);
  }
  // The launch calibrates the model the patches will run alone
  for (const r of run.compare ?? []) {
    if (r.status === 'skip') continue;
    if (r.status === 'warn') qa.info(S, `⚠ ${r.name}`, `${r.detail} · target: ${r.target} — calibrate the model before a patch relies on it (docs/guides/upgrades.md → the model)`);
    else qa.check(S, r.name, true, `${r.detail} · target: ${r.target}`);
  }
  if (!opts.patch && !run.model) qa.info(S, '⚠ balance model', 'no balanceModel(): every patch will run the bot too — export one from bot.ts (docs/guides/upgrades.md → the balance model) and this launch compares the two');
  if (!run.model && opts.design?.anchor) qa.info(S, '⚠ balance model', `game.yaml declares the anchor (${opts.design.anchor.name}, ${opts.design.anchor.unit}), but there is no balanceModel() built in it: the first-session checks (first reward, early gaps, big rewards, the session-end hook) are not made`);
  // The model's first reward beside the first minute's first celebrated moment (whichever section ends second says both)
  if (run.model) {
    const sec = run.model.firstRewardSec;
    if (qa.notes) qa.notes.modelFirstRewardSec = sec;
    const hl = qa.notes?.firstHighlightSec;
    qa.info(S, 'the first reward (balance model)', `${sec === null ? 'none' : `${Math.round(sec)} s of play`}${hl !== undefined ? ` — the first minute's demo bot: the first celebrated moment ${hl === null ? 'not within its run' : `${hl} s after Play`}` : ''}`);
  }
  const skipped = run.verdict.rows.filter((r) => r.status === 'skip' && !undeclared(r)).map((r) => r.name);
  qa.info(S, 'balance report', `${run.file.split(/[\\/]/).pop()}: ${run.source === 'model' ? (opts.patch ? 'a patch: balanceModel() alone (the bot is skipped; gp balance runs both)' : 'balanceModel() alone (no bot)') : run.model ? 'balance() and balanceModel(), compared' : 'balance()'} in ${run.seconds.toFixed(1)} s${run.report.note ? ` — ${run.report.note}` : ''}${skipped.length ? `; not reported: ${skipped.join(', ')}` : ''}`);
  return run;
}
