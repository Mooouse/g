// Command registry: usage and description are also the CLI reference (docs/reference/cli.md).

export interface Command {
  name: string;
  usage: string;
  description: string;
  run(args: string[], flags: Record<string, string | boolean>): Promise<number>;
}
