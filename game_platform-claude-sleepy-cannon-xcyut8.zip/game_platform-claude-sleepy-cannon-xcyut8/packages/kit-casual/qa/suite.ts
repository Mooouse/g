// QA suite of the casual kit: any casual game (title → timed round → score screen) gets these checks.
// Scenes by `app.current.id`, counts from `app.events`, portal calls from the dev portal stub (window.__portal),
// every number (round length, penalties, combo steps, ad limits, save key, texts) from the resolved game.

import type { Browser, Page } from 'playwright';
import type { QaContext, QaSuite } from '@gp/qa';
import type { TapScoreConfig } from '@gp/blocks/meta';
import type { CasualConfig } from '@gp/kit-casual/meta';

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  interface Window {
    __app: any;
    __gp: any;
    __portal: { calls: { fn: string; t: number }[] };
    __adShows: { start: number; end: number | null }[];
    __perf: { frames: number[]; cost: number[] };
    __home: { x: number; y: number };
  }
}

const VIEWPORTS = [
  { name: 'phone-portrait-360x800', width: 360, height: 800 },
  { name: 'phone-landscape-800x360', width: 800, height: 360 },
  { name: 'desktop-1280x720', width: 1280, height: 720 },
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const scene = (page: Page) => page.evaluate(() => window.__app.current.id as string);
const waitScene = (page: Page, id: string, timeout = 15000) => page.waitForFunction((n) => window.__app.current.id === n, id, { timeout });

async function instrument(page: Page): Promise<void> {
  await page.evaluate(() => {
    window.__adShows = [];
    new MutationObserver((list) => {
      for (const m of list) {
        for (const n of m.addedNodes) if ((n as HTMLElement).dataset?.testAd !== undefined) window.__adShows.push({ start: performance.now(), end: null });
        for (const n of m.removedNodes) if ((n as HTMLElement).dataset?.testAd !== undefined) window.__adShows.at(-1)!.end = performance.now();
      }
    }).observe(document.body, { childList: true });
  });
}

/** Tap a rect or circle property of the current scene (play, sound, again, home) */
async function tapProp(page: Page, prop: string): Promise<void> {
  const r = await page.evaluate((p) => {
    const s = window.__app.current;
    s.layout?.();
    const v = s[p];
    return v.r !== undefined ? { x: v.x, y: v.y } : { x: v.x + v.w / 2, y: v.y + v.h / 2 };
  }, prop);
  await page.touchscreen.tap(r.x, r.y);
}

/** A good (non-spiky) visible target of the round */
async function goodTarget(page: Page): Promise<{ x: number; y: number } | null> {
  return page.evaluate(() => {
    const app = window.__app;
    const f = app.current.field;
    const r0 = f.baseRadius();
    const b = f.items.find((x: any) => x.kind !== 'spiky' && x.y > r0 * 2.5 && x.y < app.h - r0 * 1.5 && f.drawX(x) > r0 && f.drawX(x) < app.w - r0);
    return b ? { x: f.drawX(b), y: b.y } : null;
  });
}

async function startRound(page: Page): Promise<void> {
  await tapProp(page, 'play');
  await waitScene(page, 'round');
  await page.waitForFunction(() => window.__app.current.state === 'play', null, { timeout: 8000 });
}

/** End the round now: run the clock out */
async function endRound(page: Page): Promise<void> {
  await page.evaluate(() => (window.__app.current.timeLeft = 0.05));
  await waitScene(page, 'result', 10000);
}

/** Make the score screen's buttons active (they ignore taps for a moment after it opens) */
async function activate(page: Page): Promise<void> {
  await page.evaluate(() => (window.__app.current.t = 1));
}

async function probeCheck(ctx: QaContext, page: Page, V: string, name: string): Promise<void> {
  const p = await page.evaluate(() => ({ targets: window.__app.current.probe?.() ?? [], w: window.__app.w, h: window.__app.h }));
  const min = ctx.game.minTouchPx;
  const off = p.targets.filter((t: any) => t.x < -0.5 || t.y < -0.5 || t.x + t.w > p.w + 0.5 || t.y + t.h > p.h + 0.5);
  const small = p.targets.filter((t: any) => Math.min(t.w, t.h) < min - 0.5);
  ctx.check(
    V,
    `platform: ${name}: all ${p.targets.length} tappable elements on screen and ≥ ${min} px`,
    p.targets.length > 0 && !off.length && !small.length,
    [off.length ? `off screen: ${off.map((t: any) => t.id).join(', ')}` : '', small.length ? `too small: ${small.map((t: any) => `${t.id} ${Math.min(t.w, t.h).toFixed(0)}px`).join(', ')}` : ''].filter(Boolean).join('; '),
  );
}

async function newPage(browser: Browser, vp: { width: number; height: number }, dpr = 1) {
  const context = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: dpr, hasTouch: true, isMobile: vp.width < 1000 });
  return { context, page: await context.newPage() };
}

async function runViewport(ctx: QaContext, vp: (typeof VIEWPORTS)[number]): Promise<void> {
  const { game, outDir: OUT, check } = ctx;
  const round = game.round as TapScoreConfig;
  const casual = game.kit as CasualConfig;
  const V = vp.name;
  const { context, page } = await newPage(ctx.browser, vp);
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => {
    if (m.type() === 'error' && !m.text().includes('favicon')) errors.push(m.text());
  });
  await page.goto(ctx.url);
  await page.waitForFunction(() => window.__app?.current);
  await instrument(page);
  await sleep(700);
  check(V, 'title: the game starts on the title screen', (await scene(page)) === 'title');
  await page.screenshot({ path: `${OUT}/${V}-title.png` });
  await probeCheck(ctx, page, V, 'title');

  // Sound toggle flips and is saved
  const before = await page.evaluate(() => window.__app.save.sound);
  await tapProp(page, 'sound');
  const after = await page.evaluate((k) => ({ sound: window.__app.save.sound, saved: JSON.parse(localStorage.getItem(k)!).sound }), game.saveKey);
  await tapProp(page, 'sound');
  check(V, 'title: Sound toggles and is saved', before === true && after.sound === false && after.saved === false);

  // Round: countdown, then the clock runs
  await tapProp(page, 'play');
  await waitScene(page, 'round');
  const st0 = await page.evaluate(() => window.__app.current.state);
  await page.waitForFunction(() => window.__app.current.state === 'play', null, { timeout: 8000 });
  const t1 = await page.evaluate(() => window.__app.current.timeLeft);
  await sleep(1200);
  const t2 = await page.evaluate(() => window.__app.current.timeLeft);
  check(V, `round: "${casual.strings.go}" first, then the clock runs down`, (round.countdown > 0 ? st0 === 'countdown' : true) && t2 < t1 - 0.8 && t1 <= round.goal.time, `${t1.toFixed(1)} → ${t2.toFixed(1)} s`);
  await probeCheck(ctx, page, V, 'round');

  // Pops add points; empty taps cost nothing
  for (let i = 0; i < 40; i++) {
    if ((await page.evaluate(() => window.__app.current.pops)) >= 6) break;
    const t = await goodTarget(page);
    if (t) await page.touchscreen.tap(t.x, t.y);
    await sleep(120);
  }
  const sc = await page.evaluate(() => ({ score: window.__app.current.score, pops: window.__app.current.pops }));
  const minScore = Math.min(...round.targets.filter((k) => k.kind !== 'spiky').map((k) => k.score));
  check(V, 'round: popping targets scores points', sc.pops >= 3 && sc.score >= sc.pops * minScore, `pops ${sc.pops}, score ${sc.score}`);
  await page.screenshot({ path: `${OUT}/${V}-round.png` });
  const empty = await page.evaluate(() => {
    const s = window.__app.current;
    const app = window.__app;
    const r0 = s.field.baseRadius();
    for (let y = app.h * 0.3; y < app.h * 0.9; y += 20)
      for (let x = r0; x < app.w - r0; x += 20) if (!s.field.items.some((b: any) => Math.hypot(s.field.drawX(b) - x, b.y - y) < r0 * 2.5)) return { x, y, score: s.score, time: s.timeLeft };
    return null;
  });
  if (empty) {
    await page.touchscreen.tap(empty.x, empty.y);
    const e2 = await page.evaluate(() => ({ score: window.__app.current.score, time: window.__app.current.timeLeft }));
    check(V, 'round: a tap on empty space costs nothing', e2.score === empty.score && e2.time > empty.time - 0.5, `score ${empty.score} → ${e2.score}`);
  }

  // Spiky: time off, combo reset
  const spiky = round.targets.find((k) => k.kind === 'spiky');
  if (spiky?.penalty) {
    const sp = await page.evaluate(() => {
      const s = window.__app.current;
      s.field.spawn(window.__app.h * 0.55);
      const b = s.field.items.at(-1);
      b.kind = 'spiky';
      b.speed = 0;
      return { x: s.field.drawX(b), y: b.y, time: s.timeLeft };
    });
    await page.touchscreen.tap(sp.x, sp.y);
    const after2 = await page.evaluate(() => ({ time: window.__app.current.timeLeft, combo: window.__app.current.combo }));
    const lost = sp.time - after2.time;
    check(
      V,
      `round: a spiky target takes ${spiky.penalty.time} s off${spiky.penalty.combo ? ' and resets the combo' : ''}`,
      lost >= spiky.penalty.time - 0.2 && lost <= spiky.penalty.time + 0.6 && (!spiky.penalty.combo || after2.combo === 0),
      `lost ${lost.toFixed(2)} s, combo ${after2.combo}`,
    );
  }

  // The clock runs out → "Time!" → the score screen, exactly once
  const scoreAtEnd = await page.evaluate(() => window.__app.current.score);
  await endRound(page);
  const ends = await page.evaluate(() => ({ calls: window.__gp.events.count('round:end'), results: window.__gp.events.count('scene', (d: { id: string }) => d.id === 'result') }));
  check(V, 'round: the clock ends the round, one score screen', ends.calls === 1 && ends.results === 1, `round:end ${ends.calls}, result ${ends.results}`);
  const r1 = await page.evaluate(() => ({ score: window.__app.current.result.score, newBest: window.__app.current.newBest, best: window.__app.save.best }));
  check(V, 'result: shows the round score; the first score is a new best', r1.score === scoreAtEnd && r1.newBest === scoreAtEnd > 0 && r1.best === scoreAtEnd, `score ${r1.score}, best ${r1.best}, newBest ${r1.newBest}`);
  await sleep(900);
  await page.screenshot({ path: `${OUT}/${V}-result.png` });
  await probeCheck(ctx, page, V, 'result');

  // Play again: ignored for the first moment, then a new round; a lower score is not a new best
  await page.evaluate(() => (window.__app.current.t = 0.1));
  await tapProp(page, 'again');
  const still = await scene(page);
  await activate(page);
  await tapProp(page, 'again');
  await waitScene(page, 'round', 20000);
  check(V, 'result: an early tap on Play again does nothing, then it starts a new round', still === 'result');
  await page.waitForFunction(() => window.__app.current.state === 'play', null, { timeout: 8000 });
  await endRound(page);
  const r2 = await page.evaluate(() => ({ score: window.__app.current.result.score, newBest: window.__app.current.newBest, best: window.__app.save.best }));
  check(V, 'result: a lower score is not a new best, the best stays', r2.score < r1.score && !r2.newBest && r2.best === r1.best, `second ${r2.score}, best ${r2.best}`);

  // The best score survives a reload
  await page.reload();
  await page.waitForFunction(() => window.__app?.current);
  const best = await page.evaluate(() => window.__app.save.best);
  check(V, 'save: the best score persists after reload', best === r1.best, `best ${best}`);
  check(V, 'console: no errors', errors.length === 0, errors.join('; '));
  await context.close();
}

async function runSpecial(ctx: QaContext): Promise<void> {
  const { game, check, info, outDir: OUT } = ctx;
  const round = game.round as TapScoreConfig;
  const V = 'special';
  const { context, page } = await newPage(ctx.browser, { width: 360, height: 800 }, 2);
  await page.goto(ctx.url);
  await page.waitForFunction(() => window.__app?.current);
  await instrument(page);

  // No browser context menu (portals ask for it)
  const prevented = await page.evaluate(() => {
    const e = new MouseEvent('contextmenu', { bubbles: true, cancelable: true });
    window.__app.canvas.dispatchEvent(e);
    const e2 = new MouseEvent('contextmenu', { bubbles: true, cancelable: true });
    document.body.dispatchEvent(e2);
    return e.defaultPrevented && e2.defaultPrevented;
  });
  check(V, 'platform: no browser context menu (canvas and page)', prevented);

  // Multitouch: 5 fingers on one target = 1 pop
  await startRound(page);
  let ok = true;
  let tried = 0;
  for (let n = 0; n < 12 && tried < 4; n++) {
    const t = await goodTarget(page);
    if (!t) {
      await sleep(250);
      continue;
    }
    tried++;
    const d = await page.evaluate((b) => {
      const s = window.__app.current;
      const before = s.pops;
      for (let id = 1; id <= 5; id++) window.__app.canvas.dispatchEvent(new PointerEvent('pointerdown', { pointerId: id, pointerType: 'touch', clientX: b.x, clientY: b.y, bubbles: true, cancelable: true }));
      return s.pops - before;
    }, t);
    if (d !== 1) ok = false;
  }
  check(V, 'multitouch: 5 fingers on one target = 1 pop', ok && tried > 0, `${tried} targets`);

  // Combo: quick pops reach ×2 after the first step
  const step = round.combo.steps[0];
  if (step) {
    const mult = await page.evaluate((n) => {
      const s = window.__app.current;
      const app = window.__app;
      let best = 1;
      for (let i = 0; i < n; i++) {
        s.field.spawn(app.h * 0.6);
        const b = s.field.items.at(-1);
        b.kind = 'normal';
        b.speed = 0;
        app.canvas.dispatchEvent(new PointerEvent('pointerdown', { pointerId: 100 + i, pointerType: 'touch', clientX: s.field.drawX(b), clientY: b.y, bubbles: true, cancelable: true }));
        best = Math.max(best, s.multiplier);
      }
      return best;
    }, step);
    check(V, `combo: ${step} quick pops in a row give ×2`, mult >= 2, `×${mult}`);
  }

  // Rotation mid-round keeps targets on screen
  await page.setViewportSize({ width: 800, height: 360 });
  await sleep(600);
  const rot = await page.evaluate(() => {
    const app = window.__app;
    const f = app.current.field;
    const r0 = f.baseRadius();
    return f.items.every((b: any) => f.drawX(b) - r0 * b.k >= 0 && f.drawX(b) + r0 * b.k <= app.w);
  });
  check(V, 'rotate: targets stay on screen after rotation', rot);
  await page.setViewportSize({ width: 360, height: 800 });
  await sleep(300);

  // Hidden tab: the clock stops, the portal hears gameplayStop / gameplayStart
  const hidden = await page.evaluate(async () => {
    const s = window.__app.current;
    const set = (v: boolean) => {
      Object.defineProperty(document, 'hidden', { value: v, configurable: true });
      document.dispatchEvent(new Event('visibilitychange'));
    };
    const n0 = window.__portal?.calls.length ?? 0;
    set(true);
    const t0 = s.timeLeft;
    await new Promise((r) => setTimeout(r, 1200));
    const t1 = s.timeLeft;
    set(false);
    const calls = (window.__portal?.calls ?? []).slice(n0).map((c) => c.fn);
    return { stopped: t0 - t1 < 0.25, calls, lost: t0 - t1 };
  });
  check(V, 'pause: the clock stops while the tab is hidden', hidden.stopped, `lost ${hidden.lost.toFixed(2)} s`);
  if (game.portal) check(V, 'portal: hidden tab → gameplayStop, back → gameplayStart', hidden.calls.join(',') === 'gameplayStop,gameplayStart', hidden.calls.join(','));

  // Performance with a full screen of targets
  await page.evaluate(() => {
    const s = window.__app.current;
    window.__perf = { frames: [], cost: [] };
    let last = performance.now();
    const tick = (t: number) => {
      window.__perf.frames.push(t - last);
      last = t;
      if (window.__perf.frames.length < 300) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    const u = s.update.bind(s);
    const d = s.draw.bind(s);
    let t0 = 0;
    s.update = (dt: number) => {
      t0 = performance.now();
      u(dt);
    };
    s.draw = (c: CanvasRenderingContext2D) => {
      d(c);
      window.__perf.cost.push(performance.now() - t0);
    };
  });
  const end = Date.now() + 4000;
  while (Date.now() < end) {
    await page.evaluate((mx) => {
      const s = window.__app.current;
      if (s.id !== 'round') return;
      s.timeLeft = Math.max(s.timeLeft, 20);
      if (s.field.items.length < mx) s.field.spawn(window.__app.h * (0.3 + Math.random() * 0.6));
      const b = s.field.items[0];
      if (b) s.field.particles.confetti(s.field.drawX(b), b.y, ['#f00', '#0f0', '#00f'], 26, 120);
    }, round.maxOnScreen);
    await sleep(100);
  }
  const perf = await page.evaluate(() => {
    const f = window.__perf.frames.slice(10).sort((a, b) => a - b);
    const c = window.__perf.cost.slice(10).sort((a, b) => a - b);
    const avg = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;
    return { fps: 1000 / avg(f), p95: c[Math.floor(c.length * 0.95)] };
  });
  check(V, `perf: 60 fps with ${round.maxOnScreen} targets and confetti`, perf.fps > 55 && perf.p95 < 8, `fps≈${perf.fps.toFixed(1)}, frame work p95 ${perf.p95.toFixed(2)} ms`);

  // Ads over a few rounds
  await endRound(page);
  const p = game.ads?.policy;
  if (!p) info(V, 'ads', 'the game has no ads — skipped');
  else {
    // Still the first minute: Play again shows no ad
    await activate(page);
    await tapProp(page, 'again');
    await waitScene(page, 'round', 15000);
    const adEarly = await page.evaluate(() => window.__adShows.length);
    check(V, `ads: none in the first ${p.noAdsAfterLaunchSec} s`, adEarly === 0);
    // The no-ads time is over, but it's still too early in the session: no ad before the end of round N — nor before
    // firstAdAfterSec, when the channel has that time path (CrazyGames: round 3 or 5 min, whichever comes first), so
    // the session is put just past the no-ads time, well inside the window
    const bySec = p.firstAdAfterSec;
    const windowOk = bySec === undefined || bySec - p.noAdsAfterLaunchSec >= 60;
    if (p.firstAdAfterRound > 1 && windowOk) {
      await page.evaluate((ago) => Object.assign(window.__app.ads.state, { sessionStartSec: performance.now() / 1000 - ago, roundsThisSession: 0 }), bySec === undefined ? 1000 : p.noAdsAfterLaunchSec + 5);
      await page.waitForFunction(() => window.__app.current.state === 'play', null, { timeout: 8000 });
      await endRound(page);
      await activate(page);
      await tapProp(page, 'again');
      await waitScene(page, 'round', 15000);
      const early = await page.evaluate(() => window.__adShows.length);
      check(V, `ads: none before the end of round ${p.firstAdAfterRound}${bySec === undefined ? '' : ` while the session is under ${bySec} s`}`, early === 0, `ads shown: ${early}`);
    }
    // Pretend the no-ads time has passed and enough rounds were played: the next break (it counts a round) may show one.
    // With a time path the rounds stay as they are (fewer than N): the session's length alone lets the first ad through
    await page.evaluate(
      ([first, timePath]) => {
        const st = window.__app.ads.state;
        Object.assign(st, { sessionStartSec: -1000, roundsThisSession: timePath ? Math.min(st.roundsThisSession, first - 2) : Math.max(st.roundsThisSession, first - 1) });
      },
      [p.firstAdAfterRound, bySec !== undefined && p.firstAdAfterRound > 1] as const,
    );
    await page.waitForFunction(() => window.__app.current.state === 'play', null, { timeout: 8000 });
    await endRound(page);
    const atEnd = await page.evaluate(() => ({ ads: window.__adShows.length, scene: window.__app.current.id }));
    check(V, 'ads: never between the round and the score screen (the score shows first)', atEnd.ads === 0 && atEnd.scene === 'result');
    await activate(page);
    await tapProp(page, 'again');
    await page.waitForFunction(() => !!document.querySelector('[data-test-ad]'), null, { timeout: 5000 }).catch(() => {});
    const during = await page.evaluate(() => ({ ad: !!document.querySelector('[data-test-ad]'), scene: window.__app.current.id }));
    if (during.ad) await page.screenshot({ path: `${OUT}/test-ad-stub.png` });
    check(V, `ads: Play again → an ad (within the limits${bySec !== undefined && p.firstAdAfterRound > 1 ? `: the session is past ${bySec} s, before round ${p.firstAdAfterRound}` : ''}) → then the new round`, during.ad && during.scene === 'result', `ad ${during.ad}, scene ${during.scene}`);
    await waitScene(page, 'round', 20000);
    await page.waitForFunction(() => window.__app.current.state === 'play', null, { timeout: 8000 });
    await endRound(page);
    await activate(page);
    await tapProp(page, 'again');
    await sleep(800);
    const again = await page.evaluate(() => window.__adShows.length);
    check(V, `ads: at most one per ${p.minIntervalSec} s`, again === 1, `ads shown: ${again}`);
    await waitScene(page, 'round', 15000);
  }
  if (game.portal) {
    const calls = await page.evaluate(() => window.__portal.calls.map((c) => c.fn));
    const firstPlay = calls.indexOf('gameplayStart');
    check(
      V,
      'portal: init → loadingStart → loadingStop before the first gameplayStart',
      calls[0] === 'init' && calls[1] === 'loadingStart' && calls.indexOf('loadingStop') > 1 && calls.indexOf('loadingStop') < firstPlay,
      calls.slice(0, 5).join(','),
    );
    const gp = calls.filter((c) => c === 'gameplayStart' || c === 'gameplayStop');
    let alternates = gp[0] === 'gameplayStart';
    for (let i = 1; i < gp.length; i++) if (gp[i] === gp[i - 1]) alternates = false;
    check(V, 'portal: gameplayStart / gameplayStop alternate (never twice in a row)', alternates && gp.length >= 4, `${gp.length} calls`);
    check(V, 'portal: happytime on a new best score', calls.includes('happytime'));
    const n0 = calls.length;
    await page.waitForFunction(() => window.__app.current.state === 'play', null, { timeout: 8000 });
    const h = await page.evaluate(() => {
      const t = window.__app.current.probe().find((x: any) => x.id === 'home');
      return { x: t.x + t.w / 2, y: t.y + t.h / 2 };
    });
    await page.touchscreen.tap(h.x, h.y);
    await waitScene(page, 'title');
    const tail = await page.evaluate((n) => window.__portal.calls.slice(n).map((c) => c.fn), n0);
    check(V, 'portal: Home from a round → gameplayStop', tail.includes('gameplayStop'), tail.join(','));
  }
  await context.close();
}

export const suite: QaSuite = {
  kit: 'casual',
  // The production build has no test hooks: real taps only. Play sits in the middle, 58% down (scenes/title.ts).
  prod: {
    async play(page) {
      const vp = page.viewportSize()!;
      await page.touchscreen.tap(vp.width / 2, vp.height * 0.58);
    },
    async finish(page) {
      // The round runs out by itself (countdown + round time): wait for the gameplayStop that follows it
      await page.waitForFunction(() => window.__sdk.calls.filter((x) => x.startsWith('gameplay')).at(-1) === 'gameplayStop', null, { timeout: 120000 });
      await sleep(1000);
    },
  },
  async run(ctx) {
    const warm = await ctx.browser.newPage();
    await warm.goto(ctx.url);
    await sleep(3000);
    await warm.close();
    for (const vp of ctx.quick ? VIEWPORTS.slice(0, 1) : VIEWPORTS) await runViewport(ctx, vp);
    await runSpecial(ctx);
  },
};
