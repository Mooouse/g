// Title: the game's name, a big Play button, the best score, a sound toggle. Targets float behind — tap them for fun.

import { drawText, easeOutBack, fitTextSize, hitRect, margin, type ProbeTarget, type Rect, type Scene } from '@gp/core';
import { rise, TargetField } from '@gp/blocks';
import type { CasualContext } from '../context.ts';
import { drawPill } from '../ui.ts';

export class TitleScene implements Scene {
  readonly id = 'title';
  readonly isHome = true;
  private readonly field: TargetField;
  play: Rect = { x: 0, y: 0, w: 0, h: 0 };
  sound: Rect = { x: 0, y: 0, w: 0, h: 0 };
  private t = 0;

  constructor(private readonly ctx: CasualContext) {
    const { round, casual } = ctx;
    this.field = new TargetField(ctx.app, { maxOnScreen: casual.title.backgroundTargets, spawnEvery: round.spawnEvery, target: round.target }, ctx.theme, rise(round.trajectory));
  }

  enter(): void {
    this.field.prefill(Math.max(0, this.ctx.casual.title.backgroundTargets - 1));
  }

  layout(): void {
    const app = this.ctx.app;
    const { w, h, u, inset } = app;
    const m = margin(app);
    const bw = Math.min(w * 0.7, u * 0.9, 420);
    const bh = Math.max(app.minTouchPx, u * 0.16);
    this.play = { x: (w - bw) / 2, y: h * 0.58 - bh / 2, w: bw, h: bh };
    const sw = Math.max(120, u * 0.3);
    const sh = Math.max(app.minTouchPx, u * 0.09);
    this.sound = { x: w - inset.right - m - sw, y: inset.top + m, w: sw, h: sh };
  }

  probe(): ProbeTarget[] {
    this.layout();
    return [
      { id: 'play', ...this.play },
      { id: 'sound', ...this.sound },
    ];
  }

  pointer(x: number, y: number): void {
    this.layout();
    const { app } = this.ctx;
    if (hitRect(this.play, x, y)) {
      app.audio.tap();
      app.go(this.ctx.play());
      return;
    }
    if (hitRect(this.sound, x, y)) {
      app.save.sound = !app.save.sound;
      app.persist();
      app.audio.tap();
      return;
    }
    const b = this.field.hit(x, y);
    if (b) this.field.pop(b);
  }

  update(dt: number): void {
    this.t += dt;
    this.field.update(dt, true);
  }

  draw(g: CanvasRenderingContext2D): void {
    this.layout();
    const { app, theme, casual, title } = this.ctx;
    const { w, h, u } = app;
    theme.drawBackground(g, w, h, app.time);
    this.field.draw(g);
    const k = easeOutBack(this.t / 0.5);
    const ts = fitTextSize(g, title, u * 0.16, w * 0.88) * k;
    if (ts > 1) drawText(g, title, w / 2, h * 0.3, ts, '#ffffff', theme.ui.textOutline);
    if (casual.title.subtitle) drawText(g, casual.title.subtitle, w / 2, h * 0.3 + u * 0.14, fitTextSize(g, casual.title.subtitle, u * 0.05, w * 0.85, 700), '#ffffff', theme.ui.textOutline, 700);
    const s = casual.strings;
    drawPill(g, this.play, s.play, '#ffffff', theme.ui.icon, theme.ui.buttonShadow, 1 + Math.sin(app.time * 2.4) * 0.03);
    const best = app.save.best as number;
    if (best > 0) drawText(g, `${s.best}: ${best}`, w / 2, this.play.y + this.play.h + u * 0.09, u * 0.055, '#ffffff', theme.ui.textOutline, 700);
    drawPill(g, this.sound, `${s.sound}: ${app.save.sound ? s.on : s.off}`, 'rgba(255,255,255,0.85)', theme.ui.icon, theme.ui.buttonShadow);
  }
}
