// Score screen: the score, "New best!" (only when strictly beaten), best score, stats, Play again (big), Home.
// The ad break happens when the player chooses to go on (Play again / Home), within the channel's limits.

import { drawIconButton, drawText, easeOutBack, fitTextSize, hitCircle, hitRect, Particles, topLeftButton, type Circle, type ProbeTarget, type Rect, type Scene } from '@gp/core';
import type { ScoreResult } from '@gp/blocks';
import type { CasualContext } from '../context.ts';
import { drawPill } from '../ui.ts';

/** Buttons become active after this delay so taps from the round don't skip the screen */
const ACTIVE_AT = 0.6;

export class ResultScene implements Scene {
  readonly id = 'result';
  private t = 0;
  private busy = false;
  again: Rect = { x: 0, y: 0, w: 0, h: 0 };
  home: Circle = { x: 0, y: 0, r: 0 };
  private readonly particles = new Particles();

  constructor(
    private readonly ctx: CasualContext,
    readonly result: ScoreResult,
    readonly newBest: boolean,
  ) {}

  enter(): void {
    if (this.newBest) this.particles.rain(this.ctx.app.w, this.ctx.theme.palette, 60, this.ctx.app.u * 0.025);
  }

  layout(): void {
    const app = this.ctx.app;
    const { w, h, u } = app;
    const bw = Math.min(w * 0.75, u * 0.95, 440);
    const bh = Math.max(app.minTouchPx, u * 0.17);
    this.again = { x: (w - bw) / 2, y: h * 0.78 - bh / 2, w: bw, h: bh };
    this.home = topLeftButton(app);
  }

  probe(): ProbeTarget[] {
    this.layout();
    return [
      { id: 'again', ...this.again },
      { id: 'home', x: this.home.x - this.home.r, y: this.home.y - this.home.r, w: this.home.r * 2, h: this.home.r * 2 },
    ];
  }

  pointer(x: number, y: number): void {
    if (this.t < ACTIVE_AT || this.busy) return;
    this.layout();
    const { app } = this.ctx;
    // The break comes only on the way into the next round: CrazyGames forbids a midgame ad on a navigational button
    // (main menu, settings, shop), so Home goes straight home
    if (hitRect(this.again, x, y)) {
      this.busy = true;
      app.audio.tap();
      void app.adBreak().finally(() => app.go(this.ctx.play()));
    } else if (hitCircle(this.home, x, y)) {
      this.busy = true;
      app.audio.tap();
      app.home();
    }
  }

  update(dt: number): void {
    this.t += dt;
    this.particles.update(dt, this.ctx.app.h);
  }

  private stats(): string {
    const r = this.result;
    const s = this.ctx.casual.strings;
    const parts: string[] = [];
    for (const k of this.ctx.casual.result.stats) {
      if (k === 'pops') parts.push(`${s.pops}: ${r.pops}`);
      else if (k === 'combo') parts.push(`${s.combo}: ${r.bestCombo}`);
      else if (k === 'accuracy') parts.push(`${s.accuracy}: ${r.taps ? Math.round((r.pops / r.taps) * 100) : 0}%`);
    }
    return parts.join('  ·  ');
  }

  draw(g: CanvasRenderingContext2D): void {
    this.layout();
    const { app, theme, casual } = this.ctx;
    const { w, h, u } = app;
    const s = casual.strings;
    theme.drawBackground(g, w, h, app.time);
    this.particles.draw(g);
    drawText(g, s.score, w / 2, h * 0.2, u * 0.06, '#ffffff', theme.ui.textOutline, 700);
    const k = easeOutBack(this.t / 0.45);
    const text = String(this.result.score);
    const size = fitTextSize(g, text, u * 0.24, w * 0.85) * k;
    if (size > 1) drawText(g, text, w / 2, h * 0.34, size, '#ffffff', theme.ui.textOutline);
    if (this.newBest) {
      const b = easeOutBack((this.t - 0.4) / 0.35);
      if (b > 0.01) drawText(g, s.newBest, w / 2, h * 0.47, u * 0.08 * b, '#ffd21f', theme.ui.textOutline);
    } else drawText(g, `${s.best}: ${app.save.best}`, w / 2, h * 0.47, u * 0.06, '#ffffff', theme.ui.textOutline, 700);
    const st = this.stats();
    if (st) drawText(g, st, w / 2, h * 0.58, fitTextSize(g, st, u * 0.045, w * 0.9, 700), 'rgba(255,255,255,0.9)', theme.ui.textOutline, 700);
    const active = this.t >= ACTIVE_AT ? 1 : 0.6;
    g.globalAlpha = active;
    drawPill(g, this.again, s.playAgain, '#ffffff', theme.ui.icon, theme.ui.buttonShadow);
    drawIconButton(g, this.home.x, this.home.y, this.home.r, 'home', { icon: theme.ui.icon });
    g.globalAlpha = 1;
  }
}
