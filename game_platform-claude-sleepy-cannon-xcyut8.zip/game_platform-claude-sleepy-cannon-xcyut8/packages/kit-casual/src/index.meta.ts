// Catalog entry for the "casual" kit (pure data): the game.yaml sections it adds, their schema, defaults, types.
// The kit: title (Play, best score, sound) → round → score screen (New best!, stats) → Play again.
// No parent gate, no stickers: for general audiences (13+). Ad breaks when the player chooses to go on.

import type { JsonSchema } from '@gp/core/schema';

export { CASUAL_STRINGS } from './strings.meta.ts';

export const CASUAL_STRINGS_EN = {
  play: 'Play',
  playAgain: 'Play again',
  best: 'Best',
  newBest: 'New best!',
  score: 'Score',
  go: 'Go!',
  timeUp: 'Time!',
  sound: 'Sound',
  on: 'on',
  off: 'off',
  pops: 'Pops',
  combo: 'Best combo',
  accuracy: 'Accuracy',
};

export type CasualStrings = typeof CASUAL_STRINGS_EN;

export type ResultStat = 'pops' | 'combo' | 'accuracy';

/** The kit's part of a resolved game */
export interface CasualConfig {
  kit: 'casual';
  title: { subtitle: string | null; backgroundTargets: number };
  result: { stats: ResultStat[] };
  strings: CasualStrings;
}

export const CASUAL_SAVE_DEFAULTS = { best: 0, plays: 0 };

export const CASUAL_KIT_META = {
  id: 'casual',
  kind: 'kit',
  mechanics: ['tap-score'],
  description:
    'Title screen (big Play, best score, sound) → timed round → score screen (score, "New best!" only when strictly beaten, stats) → Play again in one tap. Ad breaks when the player taps Play again (never on Home — a navigational button — and never during play). No parent gate or stickers: for teens and adults.',
  sections: {
    titleScreen: {
      type: 'object',
      description: 'The title screen',
      properties: {
        subtitle: { type: 'string', minLength: 1, maxLength: 40, description: 'One line under the title, e.g. "Pop as many as you can in 45 s"' },
        backgroundTargets: { type: 'integer', minimum: 0, maximum: 10, default: 5, description: 'Targets floating behind the title (they can be popped for fun)' },
      },
      additionalProperties: false,
    } satisfies JsonSchema,
    result: {
      type: 'object',
      description: 'The score screen',
      properties: {
        stats: { type: 'array', items: { enum: ['pops', 'combo', 'accuracy'] }, maxItems: 3, default: ['pops', 'combo', 'accuracy'], description: 'Stats under the score' },
      },
      additionalProperties: false,
    } satisfies JsonSchema,
    strings: {
      type: 'object',
      description: 'UI texts of the kit (defaults: English)',
      properties: Object.fromEntries(Object.entries(CASUAL_STRINGS_EN).map(([k, v]) => [k, { type: 'string', minLength: 1, default: v } satisfies JsonSchema])),
      additionalProperties: false,
    } satisfies JsonSchema,
  },
  required: [] as string[],
  example: 'kit: casual\ntheme: neon-pop\nround: { mechanic: tap-score, goal: { time: 45 } }\ntitleScreen: { subtitle: "Pop as many as you can!" }',
} as const;
