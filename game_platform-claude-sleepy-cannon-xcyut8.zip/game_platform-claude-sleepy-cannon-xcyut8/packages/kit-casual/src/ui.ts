// A pill button: the kit's main call to action.

import { drawPanel, drawText, fitTextSize, type Rect } from '@gp/core';

export function drawPill(g: CanvasRenderingContext2D, r: Rect, label: string, fill: string, color: string, shadow: string, scale = 1): void {
  if (scale <= 0.01) return;
  const w = r.w * scale;
  const h = r.h * scale;
  const x = r.x + (r.w - w) / 2;
  const y = r.y + (r.h - h) / 2;
  drawPanel(g, x, y, w, h, h / 2, fill, shadow);
  drawText(g, label, x + w / 2, y + h / 2, fitTextSize(g, label, h * 0.45, w * 0.8), color, null);
}
