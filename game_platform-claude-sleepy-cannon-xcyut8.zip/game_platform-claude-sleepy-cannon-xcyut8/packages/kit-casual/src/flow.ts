// The casual kit flow: title → round → score screen → round again or title. Ad breaks: on Play again only (never on Home: a navigational button).

import type { App, Flow, RoundResult, Theme } from '@gp/core';
import { TapScoreRound, type ScoreResult, type TapScoreConfig } from '@gp/blocks';
import type { CasualContext } from './context.ts';
import type { CasualConfig } from './index.meta.ts';
import { ResultScene } from './scenes/result.ts';
import { TitleScene } from './scenes/title.ts';

export function createCasualFlow(app: App, theme: Theme, title: string, casual: CasualConfig, round: TapScoreConfig): Flow {
  const ctx: CasualContext = {
    app,
    theme,
    title,
    casual,
    round,
    titleScene: () => new TitleScene(ctx),
    // The hand hint only in the player's very first round
    play: () => new TapScoreRound(app, theme, round, { go: casual.strings.go, timeUp: casual.strings.timeUp }, 'classic', (app.save.plays as number) === 0),
    result: (r, newBest) => new ResultScene(ctx, r, newBest),
  };
  return {
    adBreak: 'manual',
    home: () => ctx.titleScene(),
    roundEnded(result: RoundResult) {
      const r = result as ScoreResult;
      const best = app.save.best as number;
      const newBest = r.score > best;
      if (newBest) {
        app.save.best = r.score;
        app.events.emit('highlight', { reason: 'new-best', score: r.score });
      }
      app.save.plays = (app.save.plays as number) + 1;
      return () => ctx.result(r, newBest);
    },
  };
}
