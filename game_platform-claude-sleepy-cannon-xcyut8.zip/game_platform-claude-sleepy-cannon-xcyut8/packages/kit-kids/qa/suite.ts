// QA suite of the kids kit — a port of "Pop the balloon!" tools/qa.mjs (74 checks) to the platform:
// scenes are found by `app.current.id`, counts come from `app.events`, and every number
// (goal, stickers, ad limits, save key, texts) comes from the resolved game instead of being hard-coded.
// So any kids-kit game gets the same checks. Check names are kept as in the original for 1:1 comparison;
// checks the original didn't have start with "platform:".

import type { Browser, Page } from 'playwright';
import type { QaContext, QaSuite } from '@gp/qa';
import type { TapCollectConfig } from '@gp/blocks/meta';
import type { KidsConfig } from '@gp/kit-kids/meta';

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  interface Window {
    __app: any;
    __gp: any;
    __adShows: { start: number; end: number | null }[];
    __perf: { frames: number[]; cost: number[] };
  }
}

const VIEWPORTS = [
  { name: 'phone-portrait-360x800', width: 360, height: 800 },
  { name: 'phone-landscape-800x360', width: 800, height: 360 },
  { name: 'tablet-768x1024', width: 768, height: 1024 },
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function sceneName(page: Page): Promise<string> {
  return page.evaluate(() => window.__app.current.id);
}

async function waitScene(page: Page, name: string, timeout = 15000): Promise<void> {
  await page.waitForFunction((n) => window.__app.current.id === n, name, { timeout });
}

/** Watch the dev ad stub appear/disappear. Round and scene counts come from app.events. */
async function instrument(page: Page): Promise<void> {
  await page.evaluate(() => {
    window.__adShows = [];
    new MutationObserver((list) => {
      for (const m of list) {
        for (const n of m.addedNodes) if ((n as HTMLElement).dataset?.testAd !== undefined) window.__adShows.push({ start: performance.now(), end: null });
        for (const n of m.removedNodes) if ((n as HTMLElement).dataset?.testAd !== undefined) window.__adShows.at(-1)!.end = performance.now();
      }
    }).observe(document.body, { childList: true });
  });
}

/** finishRound calls and result screens since the page loaded */
async function roundCounts(page: Page): Promise<{ calls: number; ends: number }> {
  return page.evaluate(() => ({
    calls: window.__gp.events.count('round:end'),
    ends: window.__gp.events.count('scene', (d: { id: string }) => d.id === 'reward'),
  }));
}

/** Visible targets of the current scene: center, radius */
async function visibleTargets(page: Page): Promise<{ x: number; y: number; r: number }[]> {
  return page.evaluate(() => {
    const app = window.__app;
    const f = app.current.field;
    const r0 = f.baseRadius();
    return f.items
      .map((b: any) => ({ x: f.drawX(b), y: b.y, r: r0 * b.k }))
      .filter((b: any) => b.y > b.r * 1.3 && b.y < app.h - b.r * 1.3 && b.x > 0 && b.x < app.w);
  });
}

/** Pop targets until `target` is reached. Also checks targets stay within the screen edges. */
async function popUntil(page: Page, target: number, boundsLog: unknown[]): Promise<void> {
  for (let guard = 0; guard < 400; guard++) {
    const st = await page.evaluate(() => ({ popped: window.__app.current.popped, state: window.__app.current.state }));
    if (st.popped >= target || st.state !== 'play') return;
    const bounds = await page.evaluate(() => {
      const app = window.__app;
      const f = app.current.field;
      const r0 = f.baseRadius();
      return f.items.map((b: any) => ({ l: f.drawX(b) - r0 * b.k, r: f.drawX(b) + r0 * b.k, w: app.w }));
    });
    for (const b of bounds) if (b.l < 0 || b.r > b.w) boundsLog.push(b);
    const list = await visibleTargets(page);
    if (list.length) await page.touchscreen.tap(list[0].x, list[0].y);
    else await sleep(120);
  }
  throw new Error('the round did not finish');
}

async function tapCard(page: Page, mode: string): Promise<void> {
  const p = await page.evaluate((m) => {
    const s = window.__app.current;
    s.layout();
    const c = s.cards.find((c: any) => c.mode === m);
    return { x: c.x + c.w / 2, y: c.y + c.h / 2 };
  }, mode);
  await page.touchscreen.tap(p.x, p.y);
  await waitScene(page, 'round');
}

/** Tap a round button of the current scene (property: album, lock, home, next) */
async function tapCircle(page: Page, prop: string): Promise<void> {
  const c = await page.evaluate((p) => {
    const s = window.__app.current;
    s.layout?.(); // layout is computed while drawing — the scene may not have drawn yet
    return s[p];
  }, prop);
  await page.touchscreen.tap(c.x, c.y);
}

async function enterCode(page: Page): Promise<number[]> {
  const code: number[] = await page.evaluate(() => window.__app.current.code);
  for (const d of code) {
    const key = await page.evaluate((dd) => {
      const s = window.__app.current;
      s.layout();
      const k = s.keys[dd - 1];
      return { x: k.x + k.w / 2, y: k.y + k.h / 2 };
    }, d);
    await page.touchscreen.tap(key.x, key.y);
  }
  return code;
}

/** Parent gate (if the game has one) → settings */
async function openSettings(page: Page, gate: boolean): Promise<void> {
  await page.evaluate(() => window.__app.home());
  await waitScene(page, 'menu');
  await tapCircle(page, 'lock');
  if (gate) {
    await waitScene(page, 'gate');
    await enterCode(page);
  }
  await waitScene(page, 'settings');
}

/** Tap the settings row whose label starts with prefix */
async function tapRow(page: Page, prefix: string): Promise<string> {
  const r = await page.evaluate((p) => {
    const s = window.__app.current;
    s.layout();
    const row = s.rows.find((x: any) => x.label.startsWith(p) || x.label.startsWith('✓ ' + p));
    return row ? { x: row.x + row.w / 2, y: row.y + row.h / 2, label: row.label as string } : null;
  }, prefix);
  if (!r) throw new Error(`no row "${prefix}"`);
  await page.touchscreen.tap(r.x, r.y);
  return r.label;
}

interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}
const rectsOverlap = (a: Box, b: Box) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
const circleRect = (c: { x: number; y: number; r: number }): Box => ({ x: c.x - c.r, y: c.y - c.r, w: c.r * 2, h: c.r * 2 });

/** platform: every tappable element of the scene is on screen and big enough for who taps it */
async function probeCheck(ctx: QaContext, page: Page, V: string, scene: string): Promise<void> {
  const p = await page.evaluate(() => ({ targets: window.__app.current.probe?.() ?? [], w: window.__app.w, h: window.__app.h }));
  const min = ctx.game.minTouchPx;
  const off = p.targets.filter((t: any) => t.x < -0.5 || t.y < -0.5 || t.x + t.w > p.w + 0.5 || t.y + t.h > p.h + 0.5);
  const small = p.targets.filter((t: any) => Math.min(t.w, t.h) < (t.audience === 'grown-up' ? 44 : min) - 0.5);
  ctx.check(
    V,
    `platform: ${scene}: all ${p.targets.length} tappable elements on screen and ≥ ${min} px (grown-up ≥ 44)`,
    p.targets.length > 0 && off.length === 0 && small.length === 0,
    [off.length ? `off screen: ${off.map((t: any) => t.id).join(', ')}` : '', small.length ? `too small: ${small.map((t: any) => `${t.id} ${Math.min(t.w, t.h).toFixed(0)}px`).join(', ')}` : ''].filter(Boolean).join('; '),
  );
}

async function playRound(page: Page, V: string, mode: string, goal: number, out: string, opts: { shot?: boolean; boundsLog: unknown[] }): Promise<void> {
  await tapCard(page, mode);
  await sleep(600);
  if (opts.shot) await page.screenshot({ path: `${out}/${V}-play-${mode}-start.png` });
  // A few pops so the shot shows a word above a burst target
  await popUntil(page, Math.min(3, goal - 1), opts.boundsLog);
  if (opts.shot) {
    await sleep(150);
    await page.screenshot({ path: `${out}/${V}-play-${mode}.png` });
  }
  await popUntil(page, goal, opts.boundsLog);
}

async function newPage(browser: Browser, vp: { width: number; height: number }, dpr = 1) {
  const context = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: dpr, hasTouch: true, isMobile: true, locale: 'ru-RU' });
  return { context, page: await context.newPage() };
}

async function runViewport(ctx: QaContext, vp: (typeof VIEWPORTS)[number]): Promise<void> {
  const { game, outDir: OUT, check } = ctx;
  const kids = game.kit as KidsConfig;
  const modes = kids.modes.map((m) => m.id);
  const goal = (game.round as TapCollectConfig).goal;
  const { context, page } = await newPage(ctx.browser, vp);
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => {
    if (m.type() === 'error' && !m.text().includes('favicon')) errors.push(m.text());
  });
  await page.goto(ctx.url); // a new browser context has a clean localStorage
  await page.waitForFunction(() => window.__app);
  await instrument(page);
  const V = vp.name;

  // --- Sound: no AudioContext before the first touch, a running one after it
  const before = await page.evaluate(() => window.__app.audio.ctx === null);
  await sleep(800);
  await page.screenshot({ path: `${OUT}/${V}-menu.png` });

  // --- Menu layout: everything on screen, nothing overlaps, targets ≥ the audience minimum
  const menu = await page.evaluate(() => {
    const s = window.__app.current;
    s.layout();
    return { cards: s.cards.map((c: any) => ({ x: c.x, y: c.y, w: c.w, h: c.h })), album: s.album, lock: s.lock, w: window.__app.w, h: window.__app.h };
  });
  const boxes: Box[] = [...menu.cards, circleRect(menu.album), circleRect(menu.lock)];
  const inside = boxes.every((b) => b.x >= 0 && b.y >= 0 && b.x + b.w <= menu.w && b.y + b.h <= menu.h);
  let overlaps = 0;
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) if (rectsOverlap(boxes[i], boxes[j])) overlaps++;
  const minTarget = Math.min(...menu.cards.map((c: Box) => c.w), menu.album.r * 2);
  check(V, 'menu: elements within the screen', inside);
  check(V, 'menu: elements do not overlap', overlaps === 0, `overlaps: ${overlaps}`);
  check(V, `menu: child targets ≥ ${game.minTouchPx} px`, minTarget >= game.minTouchPx, `min ${minTarget.toFixed(0)} px`);
  await probeCheck(ctx, page, V, 'menu');

  // Pop a menu target just for fun (must not break anything)
  const mb = await visibleTargets(page);
  // Only a balloon clear of every button: a tap on the album or the lock would leave the menu (a random CI failure once)
  const onButton = (t: { x: number; y: number }) =>
    menu.cards.some((c: Box) => t.x > c.x - 8 && t.x < c.x + c.w + 8 && t.y > c.y - 8 && t.y < c.y + c.h + 8) ||
    [menu.album, menu.lock].some((b: { x: number; y: number; r: number }) => Math.hypot(t.x - b.x, t.y - b.y) < b.r + 8);
  const free = mb.find((t) => !onButton(t));
  if (free) await page.touchscreen.tap(free.x, free.y);

  const boundsLog: unknown[] = [];
  for (const [i, mode] of modes.entries()) {
    const t0 = Date.now();
    await playRound(page, V, mode, goal, OUT, { shot: true, boundsLog });
    if (i === 0) await probeCheck(ctx, page, V, 'round');
    await waitScene(page, 'reward', 20000);
    const roundSec = (Date.now() - t0) / 1000;
    // Early taps on Next are ignored
    await tapCircle(page, 'next');
    const still = await sceneName(page);
    check(V, `round ${mode}: an early tap on Next does not skip the screen`, still === 'reward');
    await sleep(2800);
    if (i === 0) {
      await page.screenshot({ path: `${OUT}/${V}-round-end.png` });
      await probeCheck(ctx, page, V, 'reward');
    }
    const fin = await roundCounts(page);
    check(V, `round ${mode}: finishRound called once, one "Well done!" screen`, fin.calls === i + 1 && fin.ends === i + 1, `calls=${fin.calls} ends=${fin.ends}, round ${roundSec.toFixed(1)} s`);
    await tapCircle(page, 'home');
    await waitScene(page, 'menu');
  }
  const audioState = await page.evaluate(() => (window.__app.audio.ctx ? window.__app.audio.ctx.state : 'none'));
  check(V, 'audio: context is created only after the first touch and runs', before && audioState === 'running', `ctx=null before touch: ${before}, after: ${audioState}`);
  check(V, 'play: balloons stay within the left/right edges', boundsLog.length === 0, `violations: ${boundsLog.length}`);

  // --- Album
  const total = kids.rewards.stickers.length;
  await tapCircle(page, 'album');
  await waitScene(page, 'album');
  await sleep(400);
  await page.screenshot({ path: `${OUT}/${V}-album.png` });
  const album = await page.evaluate(() => {
    const s = window.__app.current;
    s.layout();
    const app = window.__app;
    return { ok: s.cells.every((c: Box) => c.x >= 0 && c.y >= 0 && c.x + c.w <= app.w && c.y + c.h <= app.h), min: Math.min(...s.cells.map((c: Box) => c.w)), n: s.cells.length };
  });
  check(V, `album: ${total} cells within the screen`, album.ok && album.n === total, `cell ${album.min.toFixed(0)} px`);
  await probeCheck(ctx, page, V, 'album');
  {
    const a = await page.evaluate(() => {
      const t = window.__app.current.probe().find((p: any) => p.id === 'home');
      return { x: t.x + t.w / 2, y: t.y + t.h / 2 };
    });
    await page.touchscreen.tap(a.x, a.y);
  }
  await waitScene(page, 'menu');

  // --- Stickers survive a reload
  const expected = Math.min(modes.length, total);
  const stickers = await page.evaluate(() => window.__app.save.stickers);
  await page.reload();
  await page.waitForFunction(() => window.__app);
  await instrument(page);
  const stickers2 = await page.evaluate(() => window.__app.save.stickers);
  check(V, 'save: stickers persist after reload', stickers === expected && stickers2 === expected, `before ${stickers}, after ${stickers2}`);

  if (kids.parentGate) {
    // --- Parent gate: random taps
    await tapCircle(page, 'lock');
    await waitScene(page, 'gate');
    await sleep(300);
    await page.screenshot({ path: `${OUT}/${V}-parent-gate.png` });
    await probeCheck(ctx, page, V, 'gate');
    let opened = 0;
    const attempts = 40;
    // Repeatable "random" taps. A guess that happens to equal the code is re-rolled: the check is
    // that wrong codes never open the gate, and a lucky 1/729 guess must not make CI flaky.
    let seed = 0x9e3779b9 ^ V.length;
    const rand = (): number => {
      seed = (seed + 0x6d2b79f5) >>> 0;
      let t = seed;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    for (let a = 0; a < attempts; a++) {
      const gate = await page.evaluate(() => {
        const s = window.__app.current;
        if (!s.keys) return null;
        s.layout();
        return { code: s.code as number[], keys: s.keys.map((k: Box) => ({ x: k.x + k.w / 2, y: k.y + k.h / 2 })) };
      });
      if (!gate) break;
      let guess: number[];
      do guess = [0, 1, 2].map(() => (rand() * 9) | 0);
      while (guess.every((i, n) => i + 1 === gate.code[n]));
      for (const i of guess) await page.touchscreen.tap(gate.keys[i].x, gate.keys[i].y);
      await sleep(500); // shake and a new task
      if ((await sceneName(page)) === 'settings') {
        opened++;
        break;
      }
    }
    check(V, 'parent: random taps do not open the gate', opened === 0, `${attempts} attempts × 3 digits, opened: ${opened} (guesses equal to the code are re-rolled)`);
    if ((await sceneName(page)) !== 'gate') {
      await page.evaluate(() => window.__app.home());
      await tapCircle(page, 'lock');
      await waitScene(page, 'gate');
    }
    // The right code opens settings
    const code = await enterCode(page);
    await waitScene(page, 'settings');
    check(V, 'parent: the right code opens settings', true, `code ${code.join('')}`);
  } else {
    ctx.info(V, 'parent gate', 'the game has no parent gate (parentGate: false)');
    await tapCircle(page, 'lock');
    await waitScene(page, 'settings');
  }
  await sleep(300);
  await page.screenshot({ path: `${OUT}/${V}-settings.png` });
  const rowsOk = await page.evaluate(() => {
    const s = window.__app.current;
    s.layout();
    const a = window.__app;
    return s.rows.every((r: Box) => r.y >= 0 && r.y + r.h <= a.h && r.x >= 0 && r.x + r.w <= a.w && r.h >= 44);
  });
  check(V, 'settings: all buttons on screen and ≥ 44 px', rowsOk);

  // --- Settings: the Sounds toggle flips and is saved
  const tapSound = async () => {
    const row = await page.evaluate(() => {
      const s = window.__app.current;
      s.layout();
      const r = s.rows[0];
      return { x: r.x + r.w / 2, y: r.y + r.h / 2 };
    });
    await page.touchscreen.tap(row.x, row.y);
    return page.evaluate((k) => ({ sound: window.__app.save.sound, saved: JSON.parse(localStorage.getItem(k)!).sound, label: window.__app.current.rows[0].label }), game.saveKey);
  };
  const off = await tapSound();
  const on = await tapSound();
  check(V, 'settings: Sounds toggles and is saved', !off.sound && !off.saved && on.sound && on.saved, `${off.label} → ${on.label}`);

  check(V, 'console: no errors', errors.length === 0, errors.join('; '));
  await context.close();
}

/** Ad limits, multitouch, rotation, performance — on a phone in portrait */
async function runSpecial(ctx: QaContext): Promise<void> {
  const { game, outDir: OUT, check, info } = ctx;
  const V = 'special';
  const kids = game.kit as KidsConfig;
  const modes = kids.modes.map((m) => m.id);
  const goal = (game.round as TapCollectConfig).goal;
  const { context, page } = await newPage(ctx.browser, { width: 360, height: 800 }, 2);
  await page.goto(ctx.url); // a new browser context has a clean localStorage
  await page.waitForFunction(() => window.__app);
  await instrument(page);
  const boundsLog: unknown[] = [];
  const pick = (i: number) => modes[i % modes.length];

  // Multitouch: five fingers on one target at once count as one pop
  await tapCard(page, pick(0));
  await page.waitForFunction(() => window.__app.current.field.items.some((b: any) => b.y < window.__app.h - 80));
  let ok = true;
  for (let n = 0; n < 5; n++) {
    const list = await visibleTargets(page);
    if (!list.length) {
      await sleep(300);
      continue;
    }
    const res = await page.evaluate((b) => {
      const s = window.__app.current;
      const before = s.popped;
      const c = window.__app.canvas;
      for (let id = 1; id <= 5; id++) {
        c.dispatchEvent(new PointerEvent('pointerdown', { pointerId: id, pointerType: 'touch', clientX: b.x, clientY: b.y, isPrimary: id === 1, bubbles: true, cancelable: true }));
      }
      return s.popped - before;
    }, list[0]);
    if (res !== 1) ok = false;
  }
  check(V, 'multitouch: 5 fingers on one balloon = 1 pop', ok);
  // The last targets with several fingers at once: the count never exceeds the goal, one round end
  await popUntil(page, goal - 3, boundsLog);
  await page.waitForFunction(() => {
    const s = window.__app.current;
    return s.field.items.filter((b: any) => b.y > 60 && b.y < window.__app.h - 60).length >= 4;
  });
  const multi = await page.evaluate(() => {
    const app = window.__app;
    const s = app.current;
    const f = s.field;
    const list = f.items.filter((b: any) => b.y > 60 && b.y < app.h - 60).map((b: any) => ({ x: f.drawX(b), y: b.y }));
    for (const [i, b] of list.entries()) {
      for (let k = 0; k < 2; k++) app.canvas.dispatchEvent(new PointerEvent('pointerdown', { pointerId: 10 + i * 2 + k, pointerType: 'touch', clientX: b.x, clientY: b.y, bubbles: true, cancelable: true }));
    }
    return { popped: s.popped, state: s.state, fingers: list.length * 2 };
  });
  await waitScene(page, 'reward', 20000);
  const fin = await roundCounts(page);
  check(V, `multitouch: count at most ${goal}, one round end`, multi.popped === goal && fin.calls === 1 && fin.ends === 1, `popped=${multi.popped}, fingers=${multi.fingers}, finishRound=${fin.calls}, "Well done!"=${fin.ends}`);
  await sleep(2700); // reward buttons become active after 2.5 s

  const p = game.ads?.policy;
  const familiesLike = p && p.firstAdAfterRound === 2 && p.everyRounds === 2;
  if (!p) info(V, 'ads', 'the game has no ads — ad checks skipped');
  else if (!familiesLike) info(V, 'ads', `ad sequence check is written for firstAdAfterRound=2, everyRounds=2 (this game: ${p.firstAdAfterRound}, ${p.everyRounds}) — skipped`);
  else {
    // Ads. Round 1 (above) — no ad. From here on we drive the limit state; the limits themselves stay untouched.
    const adFirst = await page.evaluate(() => window.__adShows.length);
    check(V, 'ads: no ad after round 1', adFirst === 0);
    const plan = [
      // round 2 of the session, but still the first minute after launch — no ad
      { name: 'B: round 2, first minute', pre: async () => {} },
      // the no-ads time "has passed"; pretend 1 round was played → this is round 2 → ad
      { name: 'C: round 2 after a minute', pre: () => page.evaluate(() => Object.assign(window.__app.ads.state, { sessionStartSec: -1000, roundsThisSession: 1, roundsSinceAd: 1 })) },
      { name: 'D: next round', pre: async () => {} },
      { name: 'E: 2 rounds later, but < min interval', pre: async () => {} },
      { name: 'F: after the min interval', pre: () => page.evaluate((sec) => (window.__app.ads.state.lastAdSec -= sec + 10), p.minIntervalSec) },
    ];
    const adAfter: { name: string; ad: boolean; sceneDuringAd: string; elapsed: number }[] = [];
    for (const [si, step] of plan.entries()) {
      await tapCircle(page, 'home');
      await waitScene(page, 'menu');
      await step.pre();
      await playRound(page, V, pick(si + 1), goal, OUT, { boundsLog });
      const elapsed = await page.evaluate(() => performance.now() / 1000 - window.__app.ads.state.sessionStartSec);
      // After the fireworks — either an ad or the result right away. With an ad, the result waits for it to close.
      await page.waitForFunction(() => !!document.querySelector('[data-test-ad]') || window.__app.current.id === 'reward', null, { timeout: 10000 });
      const adVisible = await page.evaluate(() => !!document.querySelector('[data-test-ad]'));
      const sceneDuringAd = await sceneName(page);
      if (adVisible && !adAfter.some((a) => a.ad)) await page.screenshot({ path: `${OUT}/test-ad-stub.png` });
      await waitScene(page, 'reward', 20000);
      adAfter.push({ name: step.name, ad: adVisible, sceneDuringAd, elapsed });
      await sleep(2700);
    }
    check(V, 'ads: no ads in the first minute after launch', !adAfter[0].ad && adAfter[0].elapsed < p.noAdsAfterLaunchSec, `${adAfter[0].elapsed.toFixed(0)} s elapsed`);
    const pattern = adAfter.slice(1).map((a) => (a.ad ? 'A' : '-')).join('');
    check(V, `ads: first after round 2, then at most once per 2 rounds and per ${p.minIntervalSec} s`, pattern === 'A--A', `C..F: ${pattern}`);
    check(V, 'ads: "Well done!" is not shown yet while the ad is up', adAfter.filter((a) => a.ad).every((a) => a.sceneDuringAd === 'round'));
    const shows = await page.evaluate(() => window.__adShows.map((a) => +(((a.end ?? 0) - a.start) / 1000).toFixed(1)));
    const closeSec = p.testAdCloseSec;
    check(V, `ads: the stub closes after ${closeSec} s`, shows.length === 2 && shows.every((s) => s >= closeSec - 0.2 && s <= closeSec + 0.6), `duration: ${shows.join(', ')} s`);
    const fin2 = await roundCounts(page);
    check(V, 'ads: "round → ad → Well done!" never fires twice', fin2.calls === 6 && fin2.ends === 6, `finishRound=${fin2.calls}, "Well done!"=${fin2.ends}`);

    // noAds turns ads off
    await page.evaluate(() => {
      const a = window.__app;
      a.save.noAds = true;
      a.ads.state.lastAdSec = -1000;
      a.ads.state.roundsSinceAd = 10;
    });
    await tapCircle(page, 'home');
    await waitScene(page, 'menu');
    await playRound(page, V, pick(2), goal, OUT, { boundsLog });
    await page.waitForFunction(() => !!document.querySelector('[data-test-ad]') || window.__app.current.id === 'reward', null, { timeout: 10000 });
    const adWithNoAds = await page.evaluate(() => !!document.querySelector('[data-test-ad]'));
    check(V, 'ads: no ads after "Remove ads"', !adWithNoAds);
    await waitScene(page, 'reward', 20000);
    await sleep(2700);
    await page.evaluate(() => (window.__app.save.noAds = false));
  }

  if (!game.billing) info(V, 'billing', 'the game has no "Remove ads" purchase — billing checks skipped');
  else {
    // "Remove ads" purchase (dev stub instead of Google Play): cancel, buy, restore
    await openSettings(page, kids.parentGate);
    // The texts as the page shows them: the kit's are in the device's language when the game declares more (languages)
    const ui: KidsConfig['strings'] = await page.evaluate(() => window.__gp.game.kit.strings);
    const label = await page.evaluate(() => {
      window.__app.current.layout();
      return window.__app.current.rows.map((r: any) => r.label).join(' | ');
    });
    page.once('dialog', (d) => d.dismiss());
    await tapRow(page, ui.removeAds);
    await sleep(300);
    const afterCancel = await page.evaluate(() => window.__app.save.noAds);
    page.once('dialog', (d) => d.accept());
    await tapRow(page, ui.removeAds);
    await page.waitForFunction(() => window.__app.save.noAds === true, null, { timeout: 5000 });
    const toast1 = await page.evaluate(() => window.__app.current.toast?.text);
    await page.screenshot({ path: `${OUT}/settings-purchased.png` });
    check(V, 'billing: cancel changes nothing, buying removes ads', !afterCancel && toast1 === ui.adsRemoved, `rows: ${label}; message: ${toast1}`);
    await tapRow(page, ui.adsRemoved); // in dev a second tap brings ads back
    await page.waitForFunction(() => window.__app.save.noAds === false);
    await tapRow(page, ui.restore);
    await page.waitForFunction(() => window.__app.save.noAds === true, null, { timeout: 7000 });
    const toast2 = await page.evaluate(() => window.__app.current.toast?.text);
    check(V, 'billing: "Restore purchases" removes ads again', toast2 === ui.restored, `message: ${toast2}`);
    const persisted = await page.evaluate((k) => JSON.parse(localStorage.getItem(k)!).noAds, game.saveKey);
    check(V, 'billing: the flag is saved on the device', persisted === true);
    await page.evaluate(() => {
      window.__app.save.noAds = false;
      window.__app.persist();
      window.__app.home();
    });
    await waitScene(page, 'menu');
  }

  // Rotation in the middle of a round
  await page.evaluate(() => window.__app.home());
  await waitScene(page, 'menu');
  await tapCard(page, pick(3));
  await sleep(2500);
  await page.setViewportSize({ width: 800, height: 360 });
  await sleep(600);
  const rot = await page.evaluate(() => {
    const app = window.__app;
    const f = app.current.field;
    const r0 = f.baseRadius();
    return f.items.every((b: any) => f.drawX(b) - r0 * b.k >= 0 && f.drawX(b) + r0 * b.k <= app.w);
  });
  check(V, 'rotate: balloons stay on screen after rotation', rot);
  await page.setViewportSize({ width: 360, height: 800 });
  await sleep(300);

  // Performance: a full screen of targets + confetti, 5 s
  const maxOn = game.round!.maxOnScreen;
  await page.evaluate(() => {
    const app = window.__app;
    const s = app.current;
    window.__perf = { frames: [], cost: [] };
    let last = performance.now();
    const tick = (t: number) => {
      window.__perf.frames.push(t - last);
      last = t;
      if (window.__perf.frames.length < 400) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    const u = s.update.bind(s);
    const d = s.draw.bind(s);
    let t0 = 0;
    s.update = (dt: number) => {
      t0 = performance.now();
      u(dt);
    };
    s.draw = (c: CanvasRenderingContext2D) => {
      d(c);
      window.__perf.cost.push(performance.now() - t0);
    };
  });
  const end = Date.now() + 5000;
  let maxParticles = 0;
  let maxTargets = 0;
  while (Date.now() < end) {
    const st = await page.evaluate(
      ([mx, g]) => {
        const s = window.__app.current;
        // keep the screen busy: pop confetti, refill targets
        if (s.field.items.length < mx) s.field.spawn(window.__app.h * (0.3 + Math.random() * 0.6));
        const b = s.field.items[0];
        if (b && s.state === 'play' && s.popped < g - 2) s.field.particles.confetti(s.field.drawX(b), b.y, ['#f00', '#0f0', '#00f'], 26, 120);
        return { p: s.field.particles.count, b: s.field.items.length };
      },
      [maxOn, goal],
    );
    maxParticles = Math.max(maxParticles, st.p);
    maxTargets = Math.max(maxTargets, st.b);
    await sleep(100);
  }
  const perf = await page.evaluate(() => {
    const f = window.__perf.frames.slice(10).sort((a, b) => a - b);
    const c = window.__perf.cost.slice(10).sort((a, b) => a - b);
    const avg = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;
    return { fps: 1000 / avg(f), p95frame: f[Math.floor(f.length * 0.95)], avgCost: avg(c), p95cost: c[Math.floor(c.length * 0.95)], maxCost: c.at(-1)! };
  });
  check(
    V,
    `perf: 60 fps with ${maxOn} balloons and confetti`,
    perf.fps > 55 && perf.p95cost < 8,
    `fps≈${perf.fps.toFixed(1)}, frame p95 ${perf.p95frame.toFixed(1)} ms; frame work avg ${perf.avgCost.toFixed(2)} ms, p95 ${perf.p95cost.toFixed(2)} ms, max ${perf.maxCost.toFixed(2)} ms; up to ${maxTargets} targets, ${maxParticles} particles`,
  );
  await context.close();
}

export const suite: QaSuite = {
  kit: 'kids',
  async run(ctx) {
    // Warm up the dev server: on the first visit Vite may optimize deps and reload the page
    const warm = await ctx.browser.newPage();
    await warm.goto(ctx.url);
    await sleep(3000);
    await warm.close();
    for (const vp of ctx.quick ? VIEWPORTS.slice(0, 1) : VIEWPORTS) await runViewport(ctx, vp);
    await runSpecial(ctx);
  },
};
