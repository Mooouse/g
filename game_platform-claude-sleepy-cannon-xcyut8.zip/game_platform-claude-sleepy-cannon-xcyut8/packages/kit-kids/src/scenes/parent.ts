// Parent gate and settings. Everything grown-up — purchases, external links, settings — lives only here.
// Gate: three numbers written as words ("seven, two, five") → tap those digits. A child who can't read won't pass.

import { drawIconButton, drawPanel, drawText, fitTextSize, hitCircle, hitRect, margin, openExternal, rng, topLeftButton, type ProbeTarget, type Rect, type Scene } from '@gp/core';
import type { KidsContext } from '../context.ts';

const CODE_LEN = 3;
const SHAKE_SEC = 0.45;

interface Key extends Rect {
  digit: number;
}

function randomCode(): number[] {
  return Array.from({ length: CODE_LEN }, () => 1 + rng.int(9));
}

export class ParentGateScene implements Scene {
  readonly id = 'gate';
  code = randomCode();
  private entered: number[] = [];
  private shakeT = -1;
  keys: Key[] = [];
  private textArea: Rect = { x: 0, y: 0, w: 0, h: 0 };

  constructor(private readonly ctx: KidsContext) {}

  private get app() {
    return this.ctx.app;
  }

  probe(): ProbeTarget[] {
    this.layout();
    const h = topLeftButton(this.app);
    return [{ id: 'home', x: h.x - h.r, y: h.y - h.r, w: h.r * 2, h: h.r * 2 }, ...this.keys.map((k) => ({ id: `key:${k.digit}`, x: k.x, y: k.y, w: k.w, h: k.h, audience: 'grown-up' as const }))];
  }

  layout(): void {
    const { w, h, inset } = this.app;
    const m = margin(this.app);
    const home = topLeftButton(this.app);
    const top = home.y + home.r + m * 0.5;
    const bottom = h - inset.bottom - m;
    const left = inset.left + m;
    const right = w - inset.right - m;
    const landscape = w > h;
    let pad: Rect;
    if (landscape) {
      const mid = left + (right - left) * 0.5;
      this.textArea = { x: left, y: top, w: mid - left - m, h: bottom - top };
      pad = { x: mid, y: inset.top + m, w: right - mid, h: bottom - inset.top - m };
    } else {
      const textH = Math.min((bottom - top) * 0.36, this.app.u * 0.5);
      this.textArea = { x: left, y: top, w: right - left, h: textH };
      pad = { x: left, y: top + textH, w: right - left, h: bottom - top - textH };
    }
    const gap = m * 0.6;
    const key = Math.min((pad.w - gap * 2) / 3, (pad.h - gap * 2) / 3, 120);
    const x0 = pad.x + (pad.w - key * 3 - gap * 2) / 2;
    const y0 = pad.y + (pad.h - key * 3 - gap * 2) / 2;
    this.keys = Array.from({ length: 9 }, (_, i) => ({
      digit: i + 1,
      x: x0 + (i % 3) * (key + gap),
      y: y0 + Math.floor(i / 3) * (key + gap),
      w: key,
      h: key,
    }));
  }

  pointer(x: number, y: number): void {
    if (hitCircle(topLeftButton(this.app), x, y)) {
      this.app.audio.tap();
      this.app.home();
      return;
    }
    if (this.shakeT >= 0) return;
    this.layout();
    const key = this.keys.find((k) => hitRect(k, x, y));
    if (!key) return;
    this.app.audio.tap();
    this.entered.push(key.digit);
    if (this.entered.length < CODE_LEN) return;
    if (this.entered.every((d, i) => d === this.code[i])) {
      this.app.go(this.ctx.settings());
    } else {
      this.app.audio.nope();
      this.shakeT = 0;
    }
  }

  update(dt: number): void {
    if (this.shakeT < 0) return;
    this.shakeT += dt;
    if (this.shakeT >= SHAKE_SEC) {
      // Wrong: reset and a new task
      this.shakeT = -1;
      this.entered = [];
      this.code = randomCode();
    }
  }

  draw(g: CanvasRenderingContext2D): void {
    const { w, h, u, time } = this.app;
    this.ctx.theme.drawBackground(g, w, h, time);
    g.fillStyle = 'rgba(20, 50, 90, 0.35)';
    g.fillRect(0, 0, w, h);
    this.layout();
    const home = topLeftButton(this.app);
    drawIconButton(g, home.x, home.y, home.r, 'home', { icon: this.ctx.theme.ui.icon });

    const shake = this.shakeT >= 0 ? Math.sin(this.shakeT * 45) * u * 0.02 * (1 - this.shakeT / SHAKE_SEC) : 0;
    const a = this.textArea;
    const cx = a.x + a.w / 2 + shake;
    const prompt = this.ctx.kids.strings.gatePrompt;
    const words = this.code.map((d) => this.ctx.kids.numberWords[d]).join(', ');
    const ps = fitTextSize(g, prompt, u * 0.055, a.w, 700);
    const ws = fitTextSize(g, words, u * 0.085, a.w);
    const dotR = u * 0.025;
    const blockH = ps + ws * 1.6 + dotR * 4;
    let y = a.y + (a.h - blockH) / 2 + ps / 2;
    drawText(g, prompt, cx, y, ps, '#ffffff', null, 700);
    y += ps / 2 + ws * 0.9;
    drawText(g, words, cx, y, ws, '#ffffff', this.ctx.theme.ui.textOutline);
    y += ws * 0.6 + dotR * 2.5;
    for (let i = 0; i < CODE_LEN; i++) {
      g.beginPath();
      g.arc(cx + (i - 1) * dotR * 3.2, y, dotR, 0, Math.PI * 2);
      g.fillStyle = i < this.entered.length ? '#ffd21f' : 'rgba(255, 255, 255, 0.4)';
      g.fill();
    }

    for (const k of this.keys) {
      drawPanel(g, k.x + shake, k.y, k.w, k.h, k.w * 0.2, '#ffffff', this.ctx.theme.ui.buttonShadow);
      drawText(g, String(k.digit), k.x + k.w / 2 + shake, k.y + k.h / 2, k.h * 0.5, this.ctx.theme.ui.icon, null);
    }
  }
}

interface Row extends Rect {
  label: string;
  action: () => void;
}

/** Parent settings — opened only after the gate */
export class SettingsScene implements Scene {
  readonly id = 'settings';
  rows: Row[] = [];
  toast: { text: string; t: number } | null = null;
  private price: string | null = null;
  /** A purchase or restore is running — ignore other taps */
  private busy = false;

  constructor(private readonly ctx: KidsContext) {}

  private get app() {
    return this.ctx.app;
  }

  probe(): ProbeTarget[] {
    this.layout();
    return this.rows.map((r) => ({ id: `row:${r.label}`, x: r.x, y: r.y, w: r.w, h: r.h, audience: 'grown-up' as const }));
  }

  enter(): void {
    if (this.app.billing.available && !this.app.save.noAds) {
      void this.app.billing.price().then((p) => (this.price = p));
    }
  }

  private async buy(): Promise<void> {
    const { app } = this;
    const UI = this.ctx.kids.strings;
    app.audio.tap();
    this.busy = true;
    try {
      const result = await app.billing.purchase();
      app.events.emit('purchase', { result });
      if (result === 'purchased') {
        app.save.noAds = true;
        app.persist();
        this.showToast(UI.adsRemoved);
      } else if (result === 'pending') this.showToast(UI.purchasePending);
      else if (result === 'error') this.showToast(UI.purchaseFailed);
    } finally {
      this.busy = false;
    }
  }

  private async restore(): Promise<void> {
    const { app } = this;
    const UI = this.ctx.kids.strings;
    app.audio.tap();
    this.busy = true;
    try {
      const owned = await app.checkPurchase();
      this.showToast(owned === null ? UI.storeUnavailable : owned ? UI.restored : UI.nothingToRestore);
    } finally {
      this.busy = false;
    }
  }

  private items(): { label: string; action: () => void }[] {
    const app = this.app;
    const UI = this.ctx.kids.strings;
    const s = app.save;
    const onOff = (v: boolean) => (v ? UI.on : UI.off);
    const change = (fn: () => void) => () => {
      fn();
      app.persist();
      app.audio.tap();
    };
    const list = [
      { label: `${UI.sound}: ${onOff(s.sound)}`, action: change(() => (s.sound = !s.sound)) },
      {
        label: `${UI.voice}: ${onOff(s.voice)}`,
        action: change(() => {
          s.voice = !s.voice;
          if (!s.voice) app.audio.stopSpeech();
        }),
      },
    ];
    const billing = app.billing;
    if (billing.available) {
      const test = billing.isTest ? ` (${UI.testOnly})` : '';
      if (!s.noAds) {
        list.push({ label: `${UI.removeAds}${this.price ? ` — ${this.price}` : ''}${test}`, action: () => this.buy() });
      } else {
        // In the dev build a second tap brings ads back — to test both states
        list.push({
          label: `✓ ${UI.adsRemoved}${test}`,
          action: billing.isTest ? change(() => (s.noAds = false)) : () => {},
        });
      }
      list.push({ label: UI.restore, action: () => this.restore() });
    }
    const url = this.ctx.kids.privacyPolicyUrl;
    if (url) list.push({ label: UI.privacy, action: () => openExternal(url) });
    list.push({ label: UI.back, action: () => app.home() });
    return list;
  }

  layout(): number {
    const { w, h, u, inset } = this.app;
    const m = margin(this.app);
    const items = this.items();
    const titleH = Math.max(48, u * 0.16);
    const top = inset.top + m + titleH;
    const bottom = h - inset.bottom - m;
    const left = inset.left + m;
    const right = w - inset.right - m;
    const gap = m * 0.6;
    const rowH = Math.min(76, Math.max(48, u * 0.14));
    const oneColumnH = items.length * rowH + (items.length - 1) * gap;
    const cols = oneColumnH > bottom - top && right - left > 560 ? 2 : 1;
    const perCol = Math.ceil(items.length / cols);
    const rh = Math.min(rowH, (bottom - top - gap * (perCol - 1)) / perCol);
    const colW = Math.min(520, (right - left - gap * (cols - 1)) / cols);
    const totalW = colW * cols + gap * (cols - 1);
    const x0 = left + (right - left - totalW) / 2;
    const y0 = top + Math.max(0, (bottom - top - (perCol * rh + (perCol - 1) * gap)) / 2);
    this.rows = items.map((it, i) => ({
      ...it,
      x: x0 + Math.floor(i / perCol) * (colW + gap),
      y: y0 + (i % perCol) * (rh + gap),
      w: colW,
      h: rh,
    }));
    return inset.top + m + titleH / 2;
  }

  pointer(x: number, y: number): void {
    if (this.busy) return;
    this.layout();
    const row = this.rows.find((r) => hitRect(r, x, y));
    row?.action();
  }

  /** Short message at the bottom (purchase result etc.) */
  showToast(text: string): void {
    this.toast = { text, t: 0 };
  }

  update(dt: number): void {
    if (this.toast && (this.toast.t += dt) > 2.5) this.toast = null;
  }

  draw(g: CanvasRenderingContext2D): void {
    const { w, h, u, time } = this.app;
    this.ctx.theme.drawBackground(g, w, h, time);
    g.fillStyle = 'rgba(20, 50, 90, 0.35)';
    g.fillRect(0, 0, w, h);
    const titleY = this.layout();
    const title = this.ctx.kids.strings.parents;
    drawText(g, title, w / 2, titleY, fitTextSize(g, title, u * 0.08, w * 0.8), '#ffffff', this.ctx.theme.ui.textOutline);
    for (const r of this.rows) {
      drawPanel(g, r.x, r.y, r.w, r.h, r.h * 0.3, '#ffffff', this.ctx.theme.ui.buttonShadow);
      const size = fitTextSize(g, r.label, r.h * 0.38, r.w * 0.88, 700);
      drawText(g, r.label, r.x + r.w / 2, r.y + r.h / 2, size, '#1f4f8a', null, 700);
    }
    if (this.toast) {
      const s = fitTextSize(g, this.toast.text, u * 0.05, w * 0.85, 700);
      drawText(g, this.toast.text, w / 2, h - this.app.inset.bottom - u * 0.06, s, '#ffffff', this.ctx.theme.ui.textOutline, 700);
    }
  }
}
