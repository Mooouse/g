// Catalog entry for the "kids" kit (pure data): the game.yaml sections it adds, their schema, defaults and types.
// The kit: a menu of mode cards → round → (break) → reward screen with stars and a sticker → album.
// Grown-up things (settings, purchases, links) sit behind a parent gate.

import type { JsonSchema } from '@gp/core/schema';
import type { ContentItem, ResolvedMode } from '@gp/blocks/meta';

export { KIDS_STRINGS, KIDS_NUMBER_WORDS } from './strings.meta.ts';

export const KIDS_STRINGS_EN = {
  gatePrompt: 'For grown-ups. Tap the numbers:',
  parents: 'For parents',
  sound: 'Sounds',
  voice: 'Voice',
  on: 'on',
  off: 'off',
  removeAds: 'Remove ads',
  adsRemoved: 'Ads removed',
  restore: 'Restore purchases',
  restored: 'Purchase restored',
  nothingToRestore: 'No purchases found',
  purchaseFailed: 'Purchase failed',
  purchasePending: 'Payment is pending',
  storeUnavailable: "Can't reach Google Play",
  privacy: 'Privacy policy',
  back: 'Back',
  testOnly: 'test',
};

export type KidsStrings = typeof KIDS_STRINGS_EN;

export const KIDS_PRAISE_EN = ['Well done!', 'Great job!', 'Super!'];

/** A picture on a menu card: a small target with content */
export interface CardPreviewItem {
  color: string;
  label?: string;
  emoji?: string;
}

export interface KidsMode extends ResolvedMode {
  card: { fill: string; preview: CardPreviewItem[] };
}

/** The kit's part of a resolved game */
export interface KidsConfig {
  kit: 'kids';
  modes: KidsMode[];
  menu: { backgroundTargets: number };
  rewards: { stickers: string[]; praise: string[] };
  parentGate: boolean;
  strings: KidsStrings;
  /** Number words 0–10 in the game's language — the parent gate task */
  numberWords: string[];
  privacyPolicyUrl: string | null;
}

export const KIDS_SAVE_DEFAULTS = { stickers: 0 };

const contentItem: JsonSchema = {
  type: 'object',
  properties: {
    label: { type: 'string', description: 'Text on the target' },
    emoji: { type: 'string', description: 'Emoji on the target' },
    word: { type: 'string', description: 'Pop-up word, spoken' },
    color: { type: 'string', pattern: '^#[0-9a-fA-F]{6}$', description: 'For color-bound lists: the target color it names' },
  },
  additionalProperties: false,
};

const modeSchema: JsonSchema = {
  type: 'object',
  description: 'A mode = one menu card = one kind of round. Content comes from a pack (`content`) or an inline list (`items`).',
  properties: {
    id: { type: 'string', pattern: '^[a-z][a-z0-9-]*$', description: 'Mode id (kebab-case)' },
    content: { type: 'string', description: 'Content pack id', 'x-gp-ref': 'content' },
    items: { type: 'array', items: contentItem, minItems: 2, description: 'Inline content instead of a pack' },
    show: { enum: ['none', 'label', 'emoji'], description: 'What is drawn on the target. Default: from the pack' },
    pop: { enum: ['none', 'label', 'emoji', 'word'], description: 'What pops up where the target burst. Default: from the pack' },
    popColored: { type: 'boolean', description: "Pop-up text in the target's color. Default: from the pack" },
    say: { type: 'boolean', description: "Speak the item's word", default: true },
    card: {
      type: 'object',
      description: 'The menu card. Default: fill from the theme, a preview of the first three items',
      properties: {
        fill: { type: 'string', pattern: '^#[0-9a-fA-F]{6}$', description: 'Card color' },
        preview: {
          type: 'array',
          maxItems: 3,
          description: 'Up to 3 small targets drawn on the card',
          items: {
            type: 'object',
            properties: {
              color: {
                oneOf: [
                  { type: 'integer', minimum: 0, description: 'Index in the theme palette' },
                  { type: 'string', pattern: '^#[0-9a-fA-F]{6}$' },
                ],
              },
              label: { type: 'string' },
              emoji: { type: 'string' },
            },
            additionalProperties: false,
          },
        },
      },
      additionalProperties: false,
    },
  },
  required: ['id'],
  additionalProperties: false,
};

const stringProps: Record<string, JsonSchema> = Object.fromEntries(
  Object.entries(KIDS_STRINGS_EN).map(([k, v]) => [k, { type: 'string', minLength: 1, default: v } satisfies JsonSchema]),
);

export const KIDS_KIT_META = {
  id: 'kids',
  kind: 'kit',
  /** Round mechanics the kit's scenes work with */
  mechanics: ['tap-collect'],
  description:
    'Mode cards menu → round → break (ad, within the limits) → reward screen (3 stars, a sticker) → album. Settings, purchases and links behind a parent gate. Built from "Pop the balloon!".',
  /** game.yaml sections this kit adds */
  sections: {
    modes: { type: 'array', minItems: 1, maxItems: 8, items: modeSchema, description: 'Game modes (menu cards), 1–8' } satisfies JsonSchema,
    menu: {
      type: 'object',
      properties: { backgroundTargets: { type: 'integer', minimum: 0, maximum: 8, default: 4, description: 'Targets floating in the menu background (they can be popped for fun)' } },
      additionalProperties: false,
    } satisfies JsonSchema,
    rewards: {
      type: 'object',
      description: 'Reward screen and album',
      properties: {
        stickers: {
          oneOf: [
            { type: 'string', description: 'Sticker pack id', 'x-gp-ref': 'stickers' },
            { type: 'array', items: { type: 'string', minLength: 1 }, minItems: 1, maxItems: 60, description: 'Inline emoji list' },
          ],
          default: 'stickers-24',
          description: 'Album stickers, one unlocked per round',
        },
        praise: { type: 'array', items: { type: 'string', minLength: 1, maxLength: 24 }, minItems: 1, description: 'Title of the reward screen, picked at random and spoken', default: KIDS_PRAISE_EN },
      },
      additionalProperties: false,
    } satisfies JsonSchema,
    parentGate: {
      type: 'boolean',
      default: true,
      description: 'Settings, purchases and external links behind a grown-up task. Required for child audiences.',
    } satisfies JsonSchema,
    strings: {
      type: 'object',
      description: 'UI texts of the kit (defaults: English)',
      properties: stringProps,
      additionalProperties: false,
    } satisfies JsonSchema,
  },
  required: ['modes'] as string[],
  example: 'kit: kids\nmodes:\n  - { id: numbers, content: numbers-1-10-en }\n  - { id: animals, content: animals-en }',
} as const;

export type { ContentItem };
