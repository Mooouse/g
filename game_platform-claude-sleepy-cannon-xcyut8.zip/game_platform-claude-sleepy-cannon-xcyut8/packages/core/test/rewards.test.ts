import { describe, expect, it } from 'vitest';
import { offlineEarnings } from '../src/offline.ts';
import { dailyOffers, loadWheel, luckyWheel, playtimeGifts, timedBoost } from '../src/rewards.ts';
import { Sites } from '../src/sites.ts';
import { UpgradeShop } from '../src/upgrades.ts';

const at = (day: number, hour = 12) => new Date(2026, 9, day, hour).getTime();
const clock = (day: number) => {
  const c = { t: at(day), now: () => c.t, go: (d: number, h = 12) => void (c.t = at(d, h)) };
  return c;
};

describe('playtimeGifts', () => {
  const GIFTS = [
    { min: 1, reward: 'a' },
    { min: 3, reward: 'b' },
    { min: 10, reward: 'c' },
  ];
  it("counts today's play in memory, saves when a gift is reached, keeps the minutes across sessions (the save)", () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    let saves = 0;
    const g = playtimeGifts(save, { gifts: GIFTS, now: c.now, persist: () => saves++ });
    const base = saves;
    expect(g.tick(30)).toEqual([]);
    expect(saves).toBe(base);
    expect(g.tick(40)).toEqual([0]);
    expect(saves).toBe(base + 1);
    expect(g.state().next).toEqual({ index: 1, inSec: 110 });
    // A new session: the same save, the minutes go on
    const again = playtimeGifts(save, { gifts: GIFTS, now: c.now });
    expect(again.state().played).toBe(70);
    expect(again.tick(110)).toEqual([1]);
    expect(again.take(0)).toBe('a');
    expect(again.take(0)).toBeNull();
    expect(again.take(2)).toBeNull();
    expect(again.state().gifts.map((x) => x.state)).toEqual(['taken', 'ready', 'locked']);
  });

  it('a new day starts the ladder again and keeps a reached, untaken gift (D56); reset: never is one ladder', () => {
    const c = clock(1);
    const g = playtimeGifts({}, { gifts: GIFTS, now: c.now });
    g.tick(200);
    g.take(0);
    c.go(2);
    const s = g.state();
    expect(s.played).toBe(0);
    expect(s.carried).toEqual([{ index: 1, reward: 'b' }]);
    expect(s.ready).toBe(1);
    expect(g.takeAll()).toEqual([{ index: 1, reward: 'b' }]);
    const forever = playtimeGifts({}, { gifts: GIFTS, now: c.now, reset: 'never' });
    forever.tick(100);
    c.go(5);
    expect(forever.state().played).toBe(100);
  });
});

describe('luckyWheel', () => {
  const SLICES = [{ reward: 10, weight: 3 }, { reward: 50, weight: 1 }, { reward: 200, weight: 0 }, { reward: 5 }];
  it('the prize is decided and saved at the spin; collect() pays it once; a reload mid-spin keeps it', () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    let saves = 0;
    const w = luckyWheel(save, { slices: SLICES, now: c.now, persist: () => saves++ });
    const before = saves;
    const spun = w.spin('free', () => 0.8);
    expect(spun).toEqual({ slice: 3, reward: 5 });
    expect(saves).toBe(before + 1);
    expect(w.spin('free')).toBeNull(); // one pending at a time
    // The page reloads before the wheel stops
    const reloaded = luckyWheel(JSON.parse(JSON.stringify(save)), { slices: SLICES, now: c.now });
    expect(reloaded.state().pending).toEqual({ slice: 3, reward: 5, how: 'free' });
    expect(reloaded.collect()).toEqual({ slice: 3, reward: 5, how: 'free' });
    expect(reloaded.collect()).toBeNull();
  });

  it('the ad spin only after the free one; a new day brings both back; weights decide (0 never)', () => {
    const c = clock(1);
    const w = luckyWheel({}, { slices: SLICES, free: 1, ad: 1, now: c.now });
    expect(w.state()).toMatchObject({ canFree: true, canAd: false });
    expect(w.spin('ad')).toBeNull();
    w.spin('free', () => 0);
    w.collect();
    expect(w.state()).toMatchObject({ canFree: false, canAd: true, freeLeft: 0, adLeft: 1 });
    w.spin('ad', () => 0.5);
    w.collect();
    expect(w.state()).toMatchObject({ canFree: false, canAd: false });
    c.go(2);
    expect(w.state()).toMatchObject({ canFree: true, canAd: false, adLeft: 1 });
    const hits = new Map<number, number>();
    const many = luckyWheel({}, { slices: SLICES, free: 100, now: c.now });
    for (let i = 0; i < 100; i++) {
      const r = many.spin('free', () => i / 100)!;
      many.collect();
      hits.set(r.slice, (hits.get(r.slice) ?? 0) + 1);
    }
    expect(hits.get(2) ?? 0).toBe(0);
    expect(hits.get(0)).toBe(60);
    expect(hits.get(1)).toBe(20);
  });

  it("a paid spin takes the game's currency through pay(); refused when it can't pay", () => {
    let gems = 15;
    const pay = (p: number) => (gems >= p ? ((gems -= p), true) : false);
    const w = luckyWheel({}, { slices: SLICES, free: 0, ad: 0, paid: { price: 10, pay } });
    expect(w.spin('paid', () => 0)).toEqual({ slice: 0, reward: 10 });
    expect(gems).toBe(5);
    w.collect();
    expect(w.spin('paid')).toBeNull();
    expect(gems).toBe(5);
    expect(loadWheel({ pending: { slice: 9, how: 'free' } }, 4).pending).toBeNull();
  });
});

describe('dailyOffers', () => {
  const POOL = ['a', 'b', 'c', 'd', 'e'].map((id, i) => ({ id, price: 10 + i, reward: id.toUpperCase() }));
  it("the day's offers by the seed, the first one free once, each bought once a day; fixed ones any time", () => {
    const c = clock(1);
    let gems = 100;
    const pay = (p: number) => (gems >= p ? ((gems -= p), true) : false);
    const o = dailyOffers({}, { pool: POOL, perDay: 3, fixed: [{ id: 'boost', price: 25, reward: 'BOOST' }], salt: 'g', now: c.now });
    const s = o.state();
    expect(s.offers).toHaveLength(4);
    const [fixed, first, second] = s.offers;
    expect(fixed).toMatchObject({ id: 'boost', daily: false, price: 25 });
    expect(first).toMatchObject({ daily: true, price: 0, free: true });
    expect(second.free).toBe(false);
    expect(o.buy(first.id, () => { throw new Error('the free one never pays'); })).toBe(first.id.toUpperCase());
    expect(o.buy(first.id, pay)).toBeNull();
    expect(o.buy(second.id, pay)).toBe(second.id.toUpperCase());
    expect(gems).toBe(100 - second.price);
    expect(o.buy('boost', pay)).toBe('BOOST');
    expect(o.buy('boost', pay)).toBe('BOOST');
    expect(o.buy('zzz', pay)).toBeNull();
    gems = 0;
    expect(o.buy(o.state().offers[3].id, pay)).toBeNull();
    c.go(2);
    expect(o.state().offers.filter((x) => x.bought)).toEqual([]);
    expect(o.state().offers[1].free).toBe(true);
  });

  it('currency for a rewarded ad, perDay times', () => {
    const o = dailyOffers({}, { pool: POOL, ad: { reward: 'GEMS', perDay: 2 }, now: clock(1).now });
    expect(o.state().ad).toEqual({ reward: 'GEMS', left: 2 });
    expect(o.adClaim()).toBe('GEMS');
    expect(o.adClaim()).toBe('GEMS');
    expect(o.adClaim()).toBeNull();
  });
});

describe('timedBoost', () => {
  it('×factor while it runs on the play clock (tick), stacked up to maxSec; ×1 when over', () => {
    const b = timedBoost({}, { factor: 2, maxSec: 100 });
    expect(b.factor()).toBe(1);
    b.add(60);
    b.add(60);
    expect(b.left).toBe(100);
    expect(b.apply(10)).toBe(20);
    b.tick(99);
    expect(b.active).toBe(true);
    b.tick(5);
    expect(b.factor()).toBe(1);
  });

  it('the wall clock runs by itself', () => {
    let t = 0;
    const b = timedBoost({}, { clock: 'wall', now: () => t });
    b.add(30);
    t = 29_000;
    expect(b.active).toBe(true);
    t = 31_000;
    expect(b.active).toBe(false);
  });

  it('never multiplies the offline earnings: offlineEarnings() and Sites.offline() measure it ×1', () => {
    const save: Record<string, unknown> = { offline: { at: 1, pending: null } };
    const b = timedBoost(save, { factor: 2 });
    b.add(3600);
    const income = () => b.apply(10); // the game's income with the boost in it
    expect(income()).toBe(20);
    const away = offlineEarnings(save, { share: 1, minSec: 0, maxHours: 1 }, income, () => 1 + 100_000)!;
    expect(away.rate).toBe(10);
    expect(away.amount).toBe(1000);
    const shop = new UpgradeShop<'robots'>([{ id: 'robots', max: 5, baseCost: 1, growth: 2 }]);
    const sites = new Sites<'a', 'robots'>([{ id: 'a', price: 0 }], { shop: () => shop, rate: () => b.apply(5), offline: { share: 1, minSec: 0, maxHours: 1 } });
    expect(sites.rate('a')).toBe(10); // in play: ×2
    sites.save(1000);
    expect(sites.offline(1000 + 3_600_000)!.coins).toBeCloseTo(5 * 3600); // away: ×1
  });
});
