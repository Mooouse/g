import { describe, expect, it } from 'vitest';
import { SITES_GENRES, Sites, type SiteDef } from '../src/sites.ts';
import { layoutMapPins, MapCamera, MAP_PIN_EDGE } from '../src/sites-map.ts';
import { UpgradeShop, type Levels } from '../src/upgrades.ts';

// A small network of an idle game: a free shed, a corner shop that needs it, a tuning garage of tier 2 and a moon base
// the game locks behind a prestige (its own condition)
type S = 'shed' | 'corner' | 'tuning' | 'moon';
type U = 'tools' | 'robots';
const DEFS: SiteDef<S>[] = [
  { id: 'shed', price: 0 },
  { id: 'corner', price: 300, requires: 'shed' },
  { id: 'tuning', price: 1500, tier: 2, requires: 'corner' },
  { id: 'moon', price: 50_000, tier: 3 },
];
const shopFor = (tier: number) =>
  new UpgradeShop<U>([
    { id: 'tools', max: 10 * tier, baseCost: 10 * tier, growth: 1.5 },
    { id: 'robots', max: 5, baseCost: 50 * tier, growth: 2 },
  ]);
/** $ a second: each robot earns 2 × the tier, tools add 10 % each */
const perSec = (tier: number, l: Levels<U>) => l.robots * 2 * tier * (1 + 0.1 * l.tools);

function network(opts: { scenePays?: boolean; prestige?: () => number } = {}) {
  const prestige = opts.prestige ?? (() => 0);
  return new Sites<S, U, { cars: number }>(DEFS, {
    shop: (s) => shopFor(s.tier ?? 1),
    rate: (s, levels) => perSec(s.tier ?? 1, levels),
    start: (s) => ({ tools: ((s.tier ?? 1) - 1) * 5 }),
    data: { cars: 0 },
    lock: (s) => (s.id === 'moon' && prestige() < 1 ? 'Sell the chain once' : null),
    ...(opts.scenePays ? { scenePays: true } : {}),
    offline: { maxHours: 8, share: 0.5, minSec: 60 },
  });
}

describe('Sites', () => {
  it('is a block for idle games', () => {
    expect(SITES_GENRES).toEqual(['idle']);
  });

  it('a new game: the free site open and the player in it, the rest closed; the first site must be free', () => {
    const s = network();
    expect(s.openIds()).toEqual(['shed']);
    expect(s.at).toBe('shed');
    expect(s.coins).toBe(0);
    expect(s.levels('shed')).toEqual({ tools: 0, robots: 0 });
    expect(() => new Sites([{ id: 'a', price: 5 }], { shop: shopFor(1), rate: () => 0 })).toThrow(/first site/);
    expect(() => new Sites([{ id: 'a', price: 0 }, { id: 'a', price: 1 }], { shop: shopFor(1), rate: () => 0 })).toThrow(/twice/);
    expect(() => new Sites([{ id: 'a', price: 0, requires: 'x' }], { shop: shopFor(1), rate: () => 0 })).toThrow(/unknown x/);
  });

  it('each site has its own levels; the wallet is shared', () => {
    const s = network();
    s.coins = 10_000;
    expect(s.unlock('corner')).toBe(true);
    expect(s.coins).toBe(9_700);
    expect(s.buy('robots', 1, 'shed')).toBe(1);
    expect(s.buy('robots', 1, 'shed')).toBe(1);
    expect(s.buy('tools', 10, 'corner')).toBe(10);
    expect(s.levels('shed')).toEqual({ tools: 0, robots: 2 });
    expect(s.levels('corner')).toEqual({ tools: 10, robots: 0 });
    // The same prices in each site (tier 1): the second shop's levels didn't move the first's
    expect(s.shop('shed').nextCost('tools', s.levels('shed'))).toBe(10);
    expect(s.coins).toBe(9_700 - 50 - 100 - s.shop('corner').costOf('tools', 0, 10)!);
    // The game's own record is per site too
    s.data('shed')!.cars = 7;
    expect(s.data('corner')!.cars).toBe(0);
    // A closed site has no levels to buy and no data
    expect(s.buy('robots', 1, 'tuning')).toBe(0);
    expect(s.data('tuning')).toBeNull();
    // A tier's own shop and its starting kit
    s.coins = 2_000;
    expect(s.unlock('tuning')).toBe(true);
    expect(s.levels('tuning')).toEqual({ tools: 5, robots: 0 });
    expect(s.shop('tuning').defs[0].max).toBe(20);
    // A refund gives back exactly
    const before = s.coins;
    s.coins += 1000;
    s.buy('robots', 1, 'tuning');
    expect(s.refund('robots', 1, 'tuning')).toBe(true);
    expect(s.coins).toBe(before + 1000);
  });

  it('opening: requirements, the price, the game\'s own lock, and the next goal', () => {
    let prestige = 0;
    const s = network({ prestige: () => prestige });
    expect(s.siteState('corner')).toBe('too-expensive');
    expect(s.siteState('tuning')).toBe('locked');
    expect(s.lockReason('tuning')).toEqual({ needs: 'corner' });
    expect(s.lockReason('moon')).toEqual({ reason: 'Sell the chain once' });
    expect(s.next()).toBe('corner');
    expect(s.unlock('corner')).toBe(false);
    s.coins = 300;
    expect(s.siteState('corner')).toBe('affordable');
    expect(s.unlock('corner')).toBe(true);
    expect(s.next()).toBe('tuning');
    prestige = 1;
    expect(s.siteState('moon')).toBe('too-expensive');
    const rows = s.rows();
    expect(rows.map((r) => [r.id, r.state, r.next])).toEqual([
      ['shed', 'open', false],
      ['corner', 'open', false],
      ['tuning', 'too-expensive', true],
      ['moon', 'too-expensive', false],
    ]);
    expect(rows[0].here).toBe(true);
    // Travel only to an open site
    expect(s.travel('tuning')).toBe(false);
    expect(s.travel('corner')).toBe(true);
    expect(s.at).toBe('corner');
  });

  it('income per second from the numbers: rate(id), totalRate(); tick() pays every open site without its scene', () => {
    const s = network();
    s.coins = 10_000;
    s.unlock('corner');
    s.buy('robots', 1, 'shed'); // 2 $/s
    s.buy('robots', 1, 'corner');
    s.buy('robots', 1, 'corner');
    s.buy('tools', 10, 'corner'); // 2 robots × 2 × 2.0 = 8 $/s
    expect(s.rate('shed')).toBeCloseTo(2);
    expect(s.rate('corner')).toBeCloseTo(8);
    expect(s.rate('tuning')).toBe(0);
    expect(s.totalRate()).toBeCloseTo(10);
    const c0 = s.coins;
    // A minute in frames of 1/60 s
    let paid = 0;
    for (let i = 0; i < 3600; i++) paid += s.tick(1 / 60);
    expect(paid).toBeCloseTo(600, 6);
    expect(s.coins).toBeCloseTo(c0 + 600, 6);
    expect(s.earned('shed')).toBeCloseTo(120, 6);
    expect(s.earned('corner')).toBeCloseTo(480, 6);
    // Bad dt pays nothing
    expect(s.tick(-1)).toBe(0);
    expect(s.tick(Number.NaN)).toBe(0);
  });

  it('scenePays: the site the player is in earns through its scene (earn()), tick() pays only the others', () => {
    const s = network({ scenePays: true });
    s.coins = 10_000;
    s.unlock('corner');
    s.buy('robots', 1, 'shed');
    s.buy('robots', 1, 'corner');
    expect(s.backgroundRate()).toBeCloseTo(2); // the corner shop; the player is in the shed
    const c0 = s.coins;
    s.tick(10);
    expect(s.coins).toBeCloseTo(c0 + 20);
    expect(s.earned('shed')).toBe(0);
    s.earn(55); // a car restored in the shed's scene
    expect(s.earned('shed')).toBe(55);
    expect(s.coins).toBeCloseTo(c0 + 75);
    s.travel('corner');
    expect(s.backgroundRate()).toBeCloseTo(2); // now the shed pays in the background
  });

  it('a non-finite or negative rate counts as 0', () => {
    const s = new Sites([{ id: 'a', price: 0 }, { id: 'b', price: 0 }], { shop: shopFor(1), rate: (d) => (d.id === 'a' ? Number.NaN : -5) });
    expect(s.totalRate()).toBe(0);
    expect(s.tick(5)).toBe(0);
  });

  it('offline: every open site at the share of its rate, clamped hours, nothing under minSec or with the clock gone back; collect once', () => {
    const s = network();
    s.coins = 10_000;
    s.unlock('corner');
    s.buy('robots', 1, 'shed'); // 2 $/s
    s.buy('robots', 1, 'corner');
    s.buy('robots', 1, 'corner'); // 4 $/s (2 robots, no tools)
    const t0 = 1_700_000_000_000;
    expect(s.offline(t0)).toBeNull(); // never saved
    const saved = s.save(t0);
    const c0 = s.coins;
    expect(s.offline(t0 + 30_000)).toBeNull(); // under a minute
    expect(s.offline(t0 - 3_600_000)).toBeNull(); // the clock went back
    const hour = s.offline(t0 + 3_600_000)!;
    expect(hour.sec).toBe(3600);
    expect(hour.coins).toBeCloseTo(6 * 3600 * 0.5);
    expect(hour.bySite).toEqual({ shed: 3600, corner: 7200 });
    // A week away counts 8 hours
    const week = s.offline(t0 + 7 * 24 * 3_600_000)!;
    expect(week.sec).toBe(8 * 3600);
    expect(week.awaySec).toBe(7 * 24 * 3600);
    expect(week.coins).toBeCloseTo(6 * 8 * 3600 * 0.5);
    // ×2 for a rewarded ad; then it can't be collected again
    expect(s.collect(hour, 2)).toBeCloseTo(2 * 10_800);
    expect(s.coins).toBeCloseTo(c0 + 21_600);
    expect(s.earned('corner')).toBeCloseTo(14_400);
    expect(s.collect(hour)).toBe(0);
    expect(s.offline(t0 + 3_600_000)).toBeNull();
    // The same from a loaded save
    const back = network().load(saved);
    expect(back.offline(t0 + 3_600_000)!.coins).toBeCloseTo(10_800);
    // No robots anywhere: nothing to show
    const idle = network();
    idle.save(t0);
    expect(idle.offline(t0 + 3_600_000)).toBeNull();
  });

  it('save → load round-trips every site; a tampered save is sanitised', () => {
    const s = network();
    s.coins = 10_000;
    s.unlock('corner');
    for (let i = 0; i < 3; i++) s.buy('tools', 1, 'corner');
    s.data('corner')!.cars = 4;
    s.travel('corner');
    s.tick(1);
    const json = JSON.parse(JSON.stringify(s.save(123)));
    const back = network().load(json);
    expect(back.openIds()).toEqual(['shed', 'corner']);
    expect(back.at).toBe('corner');
    expect(back.levels('corner')).toEqual({ tools: 3, robots: 0 });
    expect(back.data('corner')).toEqual({ cars: 4 });
    expect(back.coins).toBeCloseTo(s.coins);
    expect(back.save(123)).toEqual(s.save(123));
    // Tampered: an unknown site, levels past max and negative, a wrong type, the player in a closed site, coins NaN
    const bad = network().load({
      v: 1,
      coins: 'lots',
      at: 'moon',
      seen: -5,
      sites: { corner: { levels: { tools: 999, robots: -3, laser: 5 }, earned: 'x', data: { cars: 'many', extra: 1 } }, mars: { levels: {} }, tuning: 7 },
    });
    expect(bad.openIds()).toEqual(['shed', 'corner']); // the free shed always open; tuning's 7 isn't a site
    expect(bad.levels('corner')).toEqual({ tools: 10, robots: 0 });
    expect(bad.data('corner')).toEqual({ cars: 0 });
    expect(bad.earned('corner')).toBe(0);
    expect(bad.at).toBe('shed');
    expect(bad.coins).toBe(0);
    for (const junk of [null, undefined, 42, 'x', [], { sites: [] }]) expect(network().load(junk).openIds()).toEqual(['shed']);
  });

  it('migrate(): a one-place save moves into site 0, its wallet and levels kept; load() does it through `legacy`', () => {
    const old = { coins: 1234, levels: { tools: 4, robots: 2 }, data: { cars: 9 }, seen: 1_700_000_000_000 };
    const s = network().migrate(old);
    expect(s.openIds()).toEqual(['shed']);
    expect(s.at).toBe('shed');
    expect(s.coins).toBe(1234);
    expect(s.levels('shed')).toEqual({ tools: 4, robots: 2 });
    expect(s.data('shed')).toEqual({ cars: 9 });
    // Its robots keep earning, and the time away since the old save counts
    expect(s.rate('shed')).toBeCloseTo(2 * 2 * 1.4);
    expect(s.offline(old.seen + 3_600_000)!.coins).toBeCloseTo(5.6 * 3600 * 0.5);
    // An update's first load: the old shape has no `sites` record
    const legacy = (raw: unknown) => {
      const r = raw as { money: number; tools: number; robots: number };
      return { coins: r.money, levels: { tools: r.tools, robots: r.robots } };
    };
    const up = network().load({ money: 50, tools: 3, robots: 1 }, { legacy });
    expect(up.coins).toBe(50);
    expect(up.levels('shed')).toEqual({ tools: 3, robots: 1 });
    // The usual call: the old save has no `sites` field at all, so `raw` is undefined — legacy reads the old fields
    const save13 = { money: 70, tools: 2, robots: 2 } as { money: number; tools: number; robots: number; sites?: unknown };
    const s13 = network().load(save13.sites, { legacy: () => ({ coins: save13.money, levels: { tools: save13.tools, robots: save13.robots } }) });
    expect([s13.coins, s13.levels('shed')]).toEqual([70, { tools: 2, robots: 2 }]);
    expect(network().load(undefined, { legacy: () => null }).openIds()).toEqual(['shed']);
    // A save already in the new shape doesn't go through legacy
    const cur = network();
    cur.coins = 999;
    expect(network().load(cur.save(1), { legacy }).coins).toBe(999);
    expect(Sites.isSave(cur.save(1))).toBe(true);
    expect(Sites.isSave({ money: 1 })).toBe(false);
    // A broken old save still gives a playable game
    expect(network().migrate({ coins: -5, levels: { tools: 'x' } as never }).levels('shed')).toEqual({ tools: 0, robots: 0 });
  });

  it('reset(): a prestige closes every bought site, keeps the timestamp', () => {
    const s = network();
    s.coins = 10_000;
    s.unlock('corner');
    s.buy('robots', 1);
    s.save(77);
    s.reset(5);
    expect(s.openIds()).toEqual(['shed']);
    expect(s.levels('shed')).toEqual({ tools: 0, robots: 0 });
    expect(s.coins).toBe(5);
    expect(s.save(0).seen).toBe(77);
  });

  it('shopFor(): one site\'s levels wired to the shared wallet, for mountUpgradeShop', () => {
    const s = network();
    s.coins = 1_000;
    s.unlock('corner');
    let saves = 0;
    const b = s.shopFor('corner', () => saves++);
    const { levels, coins } = b.get();
    const r = b.shop.buy('robots', levels, coins)!;
    b.set(r.levels, r.coins);
    expect(s.levels('corner').robots).toBe(1);
    expect(s.levels('shed').robots).toBe(0);
    expect(s.coins).toBe(700 - 50);
    expect(saves).toBe(1);
  });

  it('the level shown on the map: the levels bought, or the game\'s own', () => {
    const s = network();
    s.coins = 1_000;
    for (let i = 0; i < 3; i++) s.buy('tools');
    s.buy('robots', 1);
    expect(s.level('shed')).toBe(4);
    expect(s.level('corner')).toBe(0);
    const own = new Sites(DEFS, { shop: shopFor(1), rate: () => 0, level: (_d, l) => l.robots });
    own.coins = 1_000;
    own.buy('robots', 1);
    expect(own.level('shed')).toBe(1);
  });
});

describe('MapCamera (the sites map)', () => {
  it('zoom 1 fits the whole view in the stage less its padding, at the view\'s aspect, centred', () => {
    const c = new MapCamera({ aspect: 2, pad: 20 });
    c.resize(400, 800);
    expect(c.base()).toEqual({ w: 360, h: 180 });
    expect(c.toScreen({ x: 0, y: 0 })).toEqual([20, 310]);
    expect(c.toScreen({ x: 1, y: 1 })).toEqual([380, 490]);
    // Without an aspect, the view fills the stage
    const f = new MapCamera({ pad: 0 });
    f.resize(300, 200);
    expect(f.toScreen({ x: 1, y: 1 })).toEqual([300, 200]);
  });

  it('zooms about a point that stays under the finger, within min..max; pans but never leaves a gap', () => {
    const c = new MapCamera({ pad: 0, maxZoom: 4 });
    c.resize(400, 400);
    const p = c.toView(100, 100);
    c.zoomAt(2, 100, 100);
    const [x, y] = c.toScreen(p);
    expect(x).toBeCloseTo(100);
    expect(y).toBeCloseTo(100);
    c.zoomAt(100);
    expect(c.zoom).toBe(4);
    c.zoomAt(0.0001);
    expect(c.zoom).toBe(1);
    expect([c.x, c.y]).toEqual([0.5, 0.5]); // at zoom 1 the view fits: centred, no pan
    c.pan(500, 0);
    expect(c.x).toBe(0.5);
    c.zoomAt(2);
    c.pan(10_000, 10_000); // far past the top-left corner
    expect(c.toScreen({ x: 0, y: 0 })).toEqual([0, 0]);
    c.pan(-100_000, -100_000);
    const [rx, ry] = c.toScreen({ x: 1, y: 1 });
    expect(rx).toBeCloseTo(400);
    expect(ry).toBeCloseTo(400);
  });

  it('the canvas transform agrees with toScreen; visible() is the part on screen in view px', () => {
    const c = new MapCamera({ aspect: 1, pad: 10 });
    c.resize(300, 200);
    c.zoomAt(3, 150, 100);
    c.pan(-40, 25);
    const [a, , , d, e, f] = c.transform();
    const b = c.base();
    const [sx, sy] = c.toScreen({ x: 0.3, y: 0.7 });
    expect(a * 0.3 * b.w + e).toBeCloseTo(sx);
    expect(d * 0.7 * b.h + f).toBeCloseTo(sy);
    const v = c.visible();
    expect(v.w).toBeCloseTo(300 / c.zoom);
    expect(a * v.x + e).toBeCloseTo(0);
  });

  it('center() puts a point in the middle when the view is big enough to move', () => {
    const c = new MapCamera({ pad: 0 });
    c.resize(400, 400);
    c.center({ x: 0.6, y: 0.4 }, 3);
    expect(c.toScreen({ x: 0.6, y: 0.4 })).toEqual([200, 200]);
    c.center({ x: 0, y: 0 }, 3); // a corner can't come to the middle: it stops at the edge
    const [x, y] = c.toScreen({ x: 0, y: 0 });
    expect(x).toBeCloseTo(0);
    expect(y).toBeCloseTo(0);
  });
});

describe('layoutMapPins (the sites map: no cut pin, no caption over another)', () => {
  type Box = [number, number, number, number];
  const hit = (a: Box, b: Box) => a[0] < b[0] + b[2] && b[0] < a[0] + a[2] && a[1] < b[1] + b[3] && b[1] < a[1] + a[3];
  it('a pin at the edge is pulled inside by the edge room; a point off the stage hides it', () => {
    const out = layoutMapPins([{ x: 0, y: 300, cw: 0, ch: 0, prio: 3 }, { x: 1280, y: 720, cw: 0, ch: 0, prio: 3 }, { x: -30, y: 300, cw: 0, ch: 0, prio: 3 }], 1280, 720, 48);
    expect(out[0].head).toEqual([MAP_PIN_EDGE, 276]);
    expect(out[1].head).toEqual([1280 - 48 - MAP_PIN_EDGE, 720 - 48 - MAP_PIN_EDGE]);
    expect(out[2].head).toBeNull();
  });
  it('crowded pins (Le Mans and Monaco): captions go below, above, right or left, never on each other or a head; no room: hidden', () => {
    const pins = [
      { x: 600, y: 300, cw: 90, ch: 34, prio: 3 },
      { x: 620, y: 310, cw: 90, ch: 34, prio: 3 },
      { x: 640, y: 300, cw: 90, ch: 34, prio: 3 },
      { x: 610, y: 330, cw: 90, ch: 34, prio: 4 },
    ];
    const out = layoutMapPins(pins, 1280, 720, 48);
    const heads = out.map((o) => [...o.head!, 48, 48] as Box);
    const caps = out.flatMap((o, i) => (o.cap ? [{ i, r: [...o.cap, pins[i].cw, pins[i].ch] as Box }] : []));
    // The player's site (prio 4) always keeps its caption
    expect(out[3].cap).not.toBeNull();
    expect(caps.length).toBeGreaterThanOrEqual(2);
    for (const a of caps) {
      for (const b of caps) if (a !== b) expect(hit(a.r, b.r)).toBe(false);
      for (const h of heads) expect(hit(a.r, h)).toBe(false);
    }
    // A caption keeps its place while it stays free (no flicker as pins move)
    const again = layoutMapPins(pins.map((p, i) => ({ ...p, last: out[i].slot })), 1280, 720, 48);
    expect(again.map((o) => o.slot)).toEqual(out.map((o) => o.slot));
  });
});
