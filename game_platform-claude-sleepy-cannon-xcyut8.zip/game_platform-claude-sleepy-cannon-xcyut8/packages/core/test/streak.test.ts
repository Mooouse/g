import { describe, expect, it } from 'vitest';
import { daySeed } from '../src/daily.ts';
import { dailyOrder, dailyStreak, loadOrder, loadStreak } from '../src/streak.ts';

// A local clock at noon of a day in October 2026 (local: the streak turns over at the player's midnight, in any TZ)
const at = (day: number, hour = 12) => new Date(2026, 9, day, hour).getTime();
const clock = (day: number) => {
  const c = { t: at(day), now: () => c.t, go: (d: number, h = 12) => void (c.t = at(d, h)) };
  return c;
};
const reward = (d: number) => 10 * d;

describe('dailyStreak', () => {
  it("a new player's first day is day 1; never shown before the first play; one claim a day", () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    let saves = 0;
    const s = dailyStreak(save, { reward, now: c.now, persist: () => saves++ });
    expect(saves).toBe(1); // the visit is recorded at once
    let st = s.state();
    expect(st.day).toBe(1);
    expect(st.canClaim).toBe(true);
    expect(st.show).toBe(false); // not before the first play
    s.played();
    st = s.state();
    expect(st.show).toBe(true);
    expect(st.reward).toBe(10);
    expect(st.tomorrow).toEqual({ day: 2, reward: 20 });
    expect(st.dots.map((d) => d.state)).toEqual(['today', 'later', 'later', 'later', 'later', 'later', 'later']);
    expect(s.claim()).toBe(10);
    expect(s.claim()).toBeNull();
    st = s.state();
    expect(st).toMatchObject({ day: 1, claimedToday: true, canClaim: false, show: false, tomorrow: { day: 2, reward: 20 } });
    expect(st.dots[0]).toEqual({ day: 1, reward: 10, state: 'claimed', current: true });
    expect(save.streak).toMatchObject({ count: 1, played: true, total: 1 });
  });

  it('consecutive days walk the week; after day 7 a new week starts at day 1', () => {
    const c = clock(1);
    const save = {};
    const s = dailyStreak(save, { reward, now: c.now });
    s.played();
    const paid: number[] = [];
    for (let d = 1; d <= 8; d++) {
      c.go(d, d % 2 ? 9 : 23); // any hour of the day
      paid.push(s.claim()!);
    }
    expect(paid).toEqual([10, 20, 30, 40, 50, 60, 70, 10]);
    expect(s.state().weeks).toBe(1);
    expect(s.log.total).toBe(8);
  });

  it('with miss: restart a day without a visit starts the week again — claimed rewards are never taken back', () => {
    const c = clock(1);
    const save = {};
    const s = dailyStreak(save, { reward, now: c.now, miss: 'restart' });
    s.played();
    s.claim();
    c.go(2);
    s.claim();
    c.go(3);
    expect(s.state().day).toBe(3);
    c.go(5); // the 4th missed
    const st = s.state();
    expect(st.day).toBe(1);
    expect(st.dots.every((d) => d.state !== 'claimed')).toBe(true);
    expect(s.claim()).toBe(10);
    expect(s.log.total).toBe(3);
  });

  it("a visit without a claim keeps the week (the day's reward waits); miss: 'pause' keeps it over a gap too", () => {
    const c = clock(1);
    const s = dailyStreak({}, { reward, now: c.now });
    s.played();
    s.claim();
    c.go(2);
    s.state(); // opened, not claimed
    c.go(3);
    expect(s.state().day).toBe(2);
    const p = clock(1);
    const q = dailyStreak({}, { reward, now: p.now, miss: 'pause' });
    q.played();
    q.claim();
    p.go(9);
    expect(q.state().day).toBe(2);
    expect(q.claim()).toBe(20);
  });

  it('survives a reload: the saved field resumes the streak, a second claim the same day is refused', () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    const s = dailyStreak(save, { reward, now: c.now });
    s.played();
    s.claim();
    const reloaded = JSON.parse(JSON.stringify(save));
    const again = dailyStreak(reloaded, { reward, now: c.now });
    expect(again.claim()).toBeNull();
    c.go(2);
    const next = dailyStreak(JSON.parse(JSON.stringify(reloaded)), { reward, now: c.now });
    expect(next.state()).toMatchObject({ day: 2, show: true });
  });

  it('a clock set back never pays twice; a broken save loads clean', () => {
    const c = clock(10);
    const s = dailyStreak({}, { reward, now: c.now });
    s.played();
    expect(s.claim()).toBe(10);
    c.go(9);
    expect(s.claim()).toBeNull();
    expect(s.state().canClaim).toBe(false);
    expect(loadStreak({ count: 99, claimed: 'x', visit: 3, played: 'yes', weeks: -2 })).toEqual({ count: 7, claimed: '', visit: '', played: false, weeks: 0, total: 0 });
  });

  it('days: 3 and a custom key', () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    const s = dailyStreak(save, { days: 3, reward: (d) => (d === 3 ? 100 : 5), now: c.now, key: 'gift' });
    s.played();
    expect(s.state().dots.map((d) => d.reward)).toEqual([5, 5, 100]);
    expect(save.gift).toBeDefined();
  });
});

describe('dailyOrder', () => {
  const need = [
    { id: 'sell', amount: 20 },
    { id: 'paint', amount: 8 },
    { id: 'tune', amount: 5 },
  ] as const;
  const seed = (key: string) => daySeed(key, 'garage');

  it("from: 'secondVisit' — not on the first day; the day's goal comes from its seed", () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    const o = dailyOrder(save, { need, reward: 300, seed, now: c.now });
    expect(o.state().available).toBe(false);
    expect(o.add(o.state().goal.id)).toBe(false);
    c.go(2);
    const st = o.state();
    expect(st.available).toBe(true);
    const key = st.day;
    expect(st.goal).toEqual(need[seed(key) % need.length]);
    // The same day gives every save the same goal
    expect(dailyOrder({}, { need, reward: 300, seed, now: c.now }).state().goal).toEqual(st.goal);
  });

  it('progress, done, claimed once; another goal does not count; a new day a new order', () => {
    const c = clock(2);
    const save: Record<string, unknown> = {};
    const o = dailyOrder(save, { need, reward: (g) => g.amount * 10, from: 'firstVisit', seed, now: c.now });
    const { goal } = o.state();
    const other = need.find((g) => g.id !== goal.id)!.id;
    expect(o.add(other, 100)).toBe(false);
    expect(o.state().progress).toBe(0);
    expect(o.claim()).toBeNull();
    expect(o.add(goal.id, goal.amount - 1)).toBe(false);
    expect(o.state().share).toBeCloseTo((goal.amount - 1) / goal.amount);
    expect(o.add(goal.id)).toBe(true);
    expect(o.add(goal.id)).toBe(false);
    expect(o.state()).toMatchObject({ done: true, claimed: false, share: 1 });
    expect(o.claim()).toBe(goal.amount * 10);
    expect(o.claim()).toBeNull();
    // A reload keeps it claimed
    expect(dailyOrder(JSON.parse(JSON.stringify(save)), { need, reward: 1, from: 'firstVisit', seed, now: c.now }).claim()).toBeNull();
    c.go(3);
    expect(o.state()).toMatchObject({ progress: 0, done: false, claimed: false });
    expect(o.log.total).toBe(1);
  });

  it('a broken save loads clean; an empty list is an error', () => {
    expect(loadOrder({ day: 5, progress: -3, amount: 'x', claimed: 1 })).toEqual({ day: '', id: '', amount: 1, progress: 0, claimed: false, first: '', total: 0 });
    expect(() => dailyOrder({}, { need: [], reward: 1 })).toThrow(/no goal/);
  });
});
