// The progression shapes (progression.ts), each against the game it came from.
import { describe, expect, it } from 'vitest';
import { countsOf, PactTree, Roster, RunChoices, Tiers } from '../src/progression.ts';
import { UpgradeShop } from '../src/upgrades.ts';

/** mulberry32, as host.rng seeds it */
function seeded(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Candle Crypt's candles (QmaCyber/game9, data.ts HEROES): Wick is free, gems buy the others
const CANDLES = [
  { id: 'wick', price: 0 },
  { id: 'lithium', price: 150 },
  { id: 'copper', price: 300 },
  { id: 'potassium', price: 450 },
  { id: 'strontium', price: 650 },
  { id: 'ash', price: 900, requires: 'potassium' },
] as const;
type Candle = (typeof CANDLES)[number]['id'];

describe('Roster (unlocks that change how you play)', () => {
  const roster = new Roster<Candle>(CANDLES);
  it('a new save owns the free entry and plays it', () => {
    expect(roster.initial()).toEqual({ owned: ['wick'], selected: 'wick' });
    expect(roster.state('wick', roster.initial(), 0)).toBe('selected');
  });
  it('buying spends the exact price and selects the new one (Candle Crypt); undo gives it back', () => {
    const b = roster.buy('lithium', roster.initial(), 200)!;
    expect(b).toEqual({ save: { owned: ['wick', 'lithium'], selected: 'lithium' }, coins: 50 });
    expect(roster.buy('lithium', b.save, 1000)).toBeNull(); // owned already
    expect(roster.state('copper', b.save, 50)).toBe('too-expensive');
    const u = roster.refund('lithium', b.save, b.coins)!;
    expect(u).toEqual({ save: { owned: ['wick'], selected: 'wick' }, coins: 200 });
    expect(roster.refund('wick', b.save, 0)).toBeNull();
    expect(roster.buy('copper', roster.initial(), 1000, { select: false })!.save.selected).toBe('wick');
  });
  it('requirements and the game\'s own locks keep an entry visible but locked, with the reason', () => {
    const r = new Roster<Candle>(CANDLES, { lock: (id) => (id === 'strontium' ? 'Reach the Ember Halls' : null) });
    const rows = r.view(r.initial(), 5000);
    expect(rows.find((x) => x.id === 'ash')).toMatchObject({ state: 'locked', needs: 'potassium', canBuy: false });
    expect(rows.find((x) => x.id === 'strontium')).toMatchObject({ state: 'locked', lockReason: 'Reach the Ember Halls' });
    expect(rows.find((x) => x.id === 'copper')).toMatchObject({ state: 'affordable', canBuy: true, progress: 1 });
    expect(r.next(r.initial())!.id).toBe('lithium');
    // Refund can't break a requirement
    let s = r.buy('potassium', r.initial(), 1e4)!;
    s = r.buy('ash', s.save, s.coins)!;
    expect(r.refund('potassium', s.save, s.coins)).toBeNull();
  });
  it('a tampered or old save: unknown ids, duplicates and a selection not owned are fixed', () => {
    expect(roster.sanitize({ owned: ['copper', 'copper', 'ghost', 3], selected: 'ash' })).toEqual({ owned: ['wick', 'copper'], selected: 'wick' });
    expect(roster.sanitize(null)).toEqual(roster.initial());
    expect(roster.sanitize({ owned: 'lithium', selected: 'lithium' })).toEqual(roster.initial());
  });
  it('balance bots: cheapest first, and best value by the bot\'s power (which also picks the strongest to play)', () => {
    const cheap = roster.spendCheapest(roster.initial(), 460);
    expect(cheap.bought).toEqual(['lithium', 'copper']);
    expect(cheap.coins).toBe(10);
    const power: Record<Candle, number> = { wick: 3, lithium: 3, copper: 5, potassium: 4, strontium: 4, ash: 9 };
    const best = roster.spendBest(roster.initial(), 460, (id) => power[id]);
    expect(best.bought[0]).toBe('copper'); // the only gain; lithium (a sidegrade) after it, cheapest first
    expect(best.save.selected).toBe('copper');
    expect(roster.totalCost()).toBe(2450);
    expect(roster.progress(best.save)).toBeCloseTo(2 / 5);
  });
  it('bad definitions fail fast', () => {
    expect(() => new Roster([{ id: 'a', price: 5 }])).toThrow(/free/);
    expect(() => new Roster([{ id: 'a', price: 0 }, { id: 'a', price: 1 }])).toThrow(/twice/);
    expect(() => new Roster([{ id: 'a', price: 0 }, { id: 'b', price: 1.5 }])).toThrow(/price/);
    expect(() => new Roster([{ id: 'a', price: 0, requires: 'z' }])).toThrow(/unknown/);
  });
});

// Starsilk's Loom (QmaCyber/game11) in tiers: the Way and the Light open first, the Snare after four levels, Mira after eight
const LOOM = [
  { id: 'spool', max: 5, baseCost: 16, growth: 1.6 },
  { id: 'lamp', max: 5, baseCost: 18, growth: 1.6 },
  { id: 'knot', max: 4, baseCost: 22, growth: 1.6 },
  { id: 'thorn', max: 3, baseCost: 45, growth: 1.8, requires: 'knot' },
  { id: 'hearts', max: 3, baseCost: 40, growth: 2 },
] as const;
type Loom = (typeof LOOM)[number]['id'];

describe('Tiers (a tier opens the next set)', () => {
  const depth = { cleared: 0 };
  const tiers = new Tiers<Loom>(
    [
      { name: 'The Way', items: ['spool', 'lamp'] },
      { name: 'The Snare', items: ['knot', 'thorn'], opensAt: 4 },
      { name: 'Mira', items: ['hearts'], opensAt: 8 },
    ],
    { gate: (t) => (t === 2 && depth.cleared < 3 ? 'Clear depth 3 first' : null) },
  );
  const shop = new UpgradeShop<Loom>(LOOM, { lock: (id, levels) => tiers.lock(id, levels) });
  it('the first tier is open; the next opens with levels bought below it', () => {
    const none = shop.noLevels();
    expect(shop.state('spool', none, 1e6)).toBe('affordable');
    expect(shop.state('knot', none, 1e6)).toBe('locked');
    expect(shop.view(none, 1e6).find((r) => r.id === 'knot')!.lockReason).toBe('4 more to open The Snare');
    const four = { ...none, spool: 3, lamp: 1 };
    expect(shop.state('knot', four, 1e6)).toBe('affordable');
    expect(tiers.openCount(four)).toBe(2);
    expect(tiers.view(four).map((v) => [v.name, v.open, v.bought, v.need])).toEqual([['The Way', true, 4, 0], ['The Snare', true, 0, 0], ['Mira', false, 0, 4]]);
  });
  it('a tier also waits for the one below it and for the game\'s gate (a depth cleared)', () => {
    const lv = { ...shop.noLevels(), spool: 5, lamp: 5 }; // 10 below Mira, but the Snare… is open, and the gate is closed
    expect(tiers.lock('hearts', lv)).toBe('Clear depth 3 first');
    depth.cleared = 3;
    expect(tiers.lock('hearts', lv)).toBeNull();
    expect(tiers.lock('hearts', { spool: 2 })).toBe('Open The Snare first');
    depth.cleared = 0;
  });
  it('an undo that would close a tier with things bought in it is refused', () => {
    const lv = { ...shop.noLevels(), spool: 3, lamp: 1, knot: 1 };
    expect(shop.refund('spool', lv, 0)).toBeNull();
    expect(shop.refund('knot', lv, 0)).not.toBeNull();
    expect(shop.refund('spool', { ...lv, knot: 0 }, 0)).not.toBeNull();
  });
  it('works for things bought once too (a roster\'s owned list)', () => {
    const t = new Tiers<'a' | 'b' | 'c'>([{ items: ['a', 'b'] }, { items: ['c'] }]);
    expect(t.lock('c', countsOf(['a']))).toBe('1 more to open Tier 2');
    expect(t.lock('c', countsOf(['a', 'b']))).toBeNull();
    expect(t.tierOf('a')).toBe(0);
  });
  it('by default each tier waits for one of each item in all the tiers below (3 tiers)', () => {
    const t = new Tiers<'a' | 'b' | 'c' | 'd' | 'e' | 'f' | 'g' | 'h'>([{ items: ['a', 'b', 'c'] }, { items: ['d', 'e', 'f'] }, { items: ['g', 'h'] }]);
    const first = countsOf(['a', 'b', 'c'] as const);
    expect(t.view(first).map((v) => [v.open, v.need])).toEqual([[true, 0], [true, 0], [false, 3]]);
    expect(t.lock('d', first)).toBeNull();
    expect(t.lock('g', first)).toBe('3 more to open Tier 3');
    expect(t.openCount(first)).toBe(2);
    expect(t.lock('g', countsOf(['a', 'b', 'c', 'd', 'e'] as const))).toBe('1 more to open Tier 3');
    expect(t.lock('g', countsOf(['a', 'b', 'c', 'd', 'e', 'f'] as const))).toBeNull();
  });
  it('a roster or pact undo that would close a tier with things bought in it is refused too', () => {
    const t = new Tiers<'free' | 'a' | 'b' | 'c'>([{ items: ['free', 'a', 'b'] }, { items: ['c'], opensAt: 2 }]);
    const roster = new Roster<'free' | 'a' | 'b' | 'c'>(
      [{ id: 'free', price: 0 }, { id: 'a', price: 10 }, { id: 'b', price: 10 }, { id: 'c', price: 50 }],
      { lock: (id, s) => t.lock(id, countsOf(s.owned)) },
    );
    let r = roster.buy('a', roster.initial(), 100)!; // free + a: 2 below, the second tier opens
    r = roster.buy('c', r.save, r.coins)!;
    expect(roster.refund('a', r.save, r.coins)).toBeNull(); // c would be in a closed tier
    const withB = roster.buy('b', r.save, 100)!;
    expect(roster.refund('a', withB.save, withB.coins)).not.toBeNull(); // b keeps it open
    expect(roster.refund('c', r.save, r.coins)!.coins).toBe(r.coins + 50);

    const pacts = new PactTree<'free' | 'a' | 'b' | 'c'>(
      [{ id: 'free', price: 0 }, { id: 'a', price: 10 }, { id: 'b', price: 10 }, { id: 'c', price: 50 }],
      { lock: (id, s) => t.lock(id, countsOf(s.taken)) },
    );
    let p = pacts.take('free', pacts.initial(), 100)!;
    p = pacts.take('a', p.save, p.coins)!;
    p = pacts.take('c', p.save, p.coins)!;
    expect(pacts.release('a', p.save, p.coins)).toBeNull();
    expect(pacts.release('c', p.save, p.coins)).not.toBeNull();
    expect(pacts.releaseAll(p.save, p.coins)).toEqual({ save: pacts.initial(), coins: 100 }); // a full respec clears it all
  });
  it('bad definitions fail fast', () => {
    expect(() => new Tiers([])).toThrow();
    expect(() => new Tiers([{ items: ['a'] }, { items: ['a'] }])).toThrow(/twice/);
    expect(() => new Tiers([{ items: ['a'] }, { items: [] }])).toThrow(/no items/);
  });
});

// Dread Throne's Dark Pacts (QmaCyber/game10): a path of pacts with an Oath sworn one of two ways, and a level-3 fork
type Pact = 'vigor' | 'mantle' | 'wrath' | 'grinder' | 'pit' | 'glass';
type Side = 'thorns' | 'tyrant' | 'roar' | 'blood';
const PACTS = [
  { id: 'vigor', price: 25, path: 'throne', mods: { kingHp: 25, souls: -10 } },
  { id: 'mantle', price: 120, path: 'throne', requires: 'vigor', sides: [{ id: 'thorns', mods: { thorns: 1.5 } }, { id: 'tyrant', mods: { gaze: 2 } }] },
  { id: 'wrath', price: 220, path: 'throne', requires: ['vigor', 'mantle'], sides: [{ id: 'roar' }, { id: 'blood', mods: { turnHp: -4 } }] },
  { id: 'grinder', price: 60, path: 'spikes', excludes: ['pit'], mods: { rearm: -0.5 } },
  { id: 'pit', price: 60, path: 'spikes', mods: { fear: 20 } },
  { id: 'glass', price: 40, path: 'curses', mods: { damage: 0.5, wax: -12 } },
] as const;

describe('PactTree (gains with a cost, Oaths, forks)', () => {
  const stage = { cleared: 0 };
  const tree = new PactTree<Pact, Side>(PACTS, { lock: (id) => (id === 'wrath' && stage.cleared < 3 ? 'Clear stage 4 first' : null) });
  it('paths: each pact needs the one before; a fork excludes the other side', () => {
    let s = tree.initial();
    expect(tree.state('mantle', s, 1e6)).toBe('locked');
    expect(tree.view(s, 1e6).find((r) => r.id === 'mantle')).toMatchObject({ state: 'locked', needs: 'vigor' });
    s = tree.take('vigor', s, 1000)!.save;
    expect(tree.state('mantle', s, 1e6)).toBe('affordable');
    s = tree.take('grinder', s, 1000)!.save;
    expect(tree.state('pit', s, 1e6)).toBe('excluded');
    expect(tree.view(s, 1e6).find((r) => r.id === 'pit')).toMatchObject({ state: 'excluded', excludedBy: 'grinder', canBuy: false });
    expect(tree.take('pit', s, 1e6)).toBeNull();
    expect(tree.paths().map((p) => p.path)).toEqual(['throne', 'spikes', 'curses']);
  });
  it('an Oath is sworn one way (the first by default) and re-sworn for free; mods sum gains and costs', () => {
    let r = tree.take('vigor', tree.initial(), 1000)!;
    r = tree.take('mantle', r.save, r.coins)!;
    expect(r.coins).toBe(1000 - 25 - 120);
    expect(tree.side('mantle', r.save)).toBe('thorns');
    expect(tree.mods(r.save)).toEqual({ kingHp: 25, souls: -10, thorns: 1.5 });
    const sw = tree.swear('mantle', 'tyrant', r.save)!;
    expect([...tree.sides(sw)]).toEqual(['tyrant']);
    expect(tree.mods(sw)).toEqual({ kingHp: 25, souls: -10, gaze: 2 });
    expect(tree.swear('mantle', 'roar', r.save)).toBeNull(); // not one of its sides
    expect(tree.swear('wrath', 'roar', r.save)).toBeNull(); // not taken
    expect(tree.take('glass', r.save, r.coins, 'roar' as Side)).toBeNull(); // not an Oath
  });
  it("the game's lock (a stage cleared), undo along the path, break all", () => {
    let r = tree.take('vigor', tree.initial(), 1000)!;
    r = tree.take('mantle', r.save, r.coins, 'tyrant')!;
    expect(tree.view(r.save, 1000).find((x) => x.id === 'wrath')).toMatchObject({ state: 'locked', lockReason: 'Clear stage 4 first' });
    stage.cleared = 3;
    expect(tree.state('wrath', r.save, 1000)).toBe('affordable');
    stage.cleared = 0;
    expect(tree.release('vigor', r.save, r.coins)).toBeNull(); // the Mantle needs it
    const back = tree.release('mantle', r.save, r.coins)!;
    expect(back.coins).toBe(r.coins + 120);
    expect(back.save.sworn).toEqual({});
    expect(tree.releaseAll(r.save, 5)).toEqual({ save: { taken: [], sworn: {} }, coins: 5 + 145 });
  });
  it('a tampered save: unknown pacts, both sides of a fork, a side the Oath lacks', () => {
    const s = tree.sanitize({ taken: ['pit', 'grinder', 'nope', 'vigor', 'vigor'], sworn: { vigor: 'thorns', mantle: 'roar', ghost: 'x' } });
    expect(s).toEqual({ taken: ['vigor', 'pit'], sworn: {} });
    expect(tree.sanitize({ taken: ['vigor', 'mantle'], sworn: { mantle: 'tyrant' } }).sworn).toEqual({ mantle: 'tyrant' });
    expect(tree.sanitize('junk')).toEqual(tree.initial());
  });
  it('balance bots: cheapest first vs best value by the game\'s score', () => {
    expect(tree.spendCheapest(tree.initial(), 150).bought).toEqual(['vigor', 'glass', 'grinder']);
    const score = (s: { taken: Pact[] }) => (s.taken.includes('pit') ? 10 : 0) + s.taken.length;
    expect(tree.spendBest(tree.initial(), 100, score).bought[0]).toBe('pit');
    expect(tree.progress(tree.take('pit', tree.initial(), 100)!.save)).toBeCloseTo(1 / 5); // the fork counts once
  });
  it('bad definitions fail fast', () => {
    expect(() => new PactTree([{ id: 'a', price: 1, requires: 'b' }, { id: 'b', price: 1, requires: 'a' }])).toThrow(/loop/);
    expect(() => new PactTree([{ id: 'a', price: 1, sides: [{ id: 'x' }] }])).toThrow(/two sides/);
    expect(() => new PactTree([{ id: 'a', price: 1, excludes: ['a'] }])).toThrow(/unknown/);
    expect(() => new PactTree([{ id: 'a', price: 1, mods: { hp: NaN } }])).toThrow(/finite/);
  });
});

// Candle Crypt's feats at a level-up: three cards, no duplicates, stacks up to max, one reroll for an ad
type Feat = 'bless' | 'haste' | 'tough' | 'glass' | 'pierce' | 'phoenix' | 'twin';
const FEATS = [
  { id: 'bless', max: 3 },
  { id: 'haste', max: 3 },
  { id: 'tough', max: 3 },
  { id: 'glass', excludes: ['tough'] },
  { id: 'pierce' },
  { id: 'phoenix', weight: 0.2 },
  { id: 'twin', requires: 'pierce' },
] as const;

describe('RunChoices (pick 1 of N in a run)', () => {
  const feats = new RunChoices<Feat>(FEATS, { size: 3, rerolls: 1 });
  it('an offer of distinct eligible cards; the same seed draws the same cards', () => {
    const s = feats.offer(feats.start(), seeded(7));
    expect(s.offer).toHaveLength(3);
    expect(new Set(s.offer).size).toBe(3);
    expect(s.offer).not.toContain('twin'); // needs pierce first
    expect(feats.offer(feats.start(), seeded(7)).offer).toEqual(s.offer);
    expect(feats.offer(feats.start(), { random: seeded(7) }).offer).toEqual(s.offer); // host.rng works as well
  });
  it('picking stacks up to max, opens what requires it and closes what it excludes', () => {
    let s = feats.grant(feats.start(), 'pierce')!;
    expect(feats.pool(s)).toContain('twin');
    expect(feats.grant(s, 'pierce')).toBeNull(); // max 1
    s = feats.grant(s, 'tough')!;
    expect(feats.pool(s)).not.toContain('glass');
    for (let i = 0; i < 2; i++) s = feats.grant(s, 'tough')!;
    expect(feats.count(s, 'tough')).toBe(3);
    expect(feats.pool(s)).not.toContain('tough');
    const o = feats.offer(s, seeded(1));
    const p = feats.pick(o, o.offer[1])!;
    expect(p.offer).toEqual([]);
    expect(feats.count(p, o.offer[1])).toBe(feats.count(o, o.offer[1]) + 1);
    expect(feats.pick(o, 'glass')).toBeNull(); // not on offer
  });
  it('a card granted or excluded while an offer is open leaves the offer and can\'t be picked', () => {
    const three = new RunChoices<'a' | 'b' | 'c'>([{ id: 'a' }, { id: 'b', excludes: ['c'] }, { id: 'c' }]);
    const open = { ...three.start(), offer: ['a', 'b', 'c'] as ('a' | 'b' | 'c')[] };
    const granted = three.grant(open, 'a')!;
    expect(granted.offer).toEqual(['b', 'c']);
    expect(three.pick({ ...granted, offer: ['a', 'b', 'c'] }, 'a')).toBeNull(); // max 1, already granted
    const forked = three.grant(open, 'b')!;
    expect(forked.offer).toEqual(['a']);
    expect(three.pick({ ...forked, offer: ['a', 'b', 'c'] }, 'c')).toBeNull(); // b excludes c
    expect(three.sanitize({ picked: { b: 1 }, offer: ['a', 'b', 'c'] }).offer).toEqual(['a']);
  });
  it('a reroll spends one and shows other cards while there are any', () => {
    const s = feats.offer(feats.start(), seeded(3));
    const r = feats.reroll(s, seeded(4))!;
    expect(r.rerolls).toBe(0);
    expect(r.offer.filter((id) => s.offer.includes(id))).toEqual([]); // 6 eligible: three new ones
    expect(feats.reroll(r, seeded(5))).toBeNull();
    expect(feats.addRerolls(r).rerolls).toBe(1); // a rewarded ad
  });
  it('weights: a rare card comes up rarely, over many seeded offers', () => {
    const seen: Record<string, number> = {};
    const rand = seeded(11);
    for (let i = 0; i < 2000; i++) for (const id of feats.draw(feats.start(), rand, 1)) seen[id] = (seen[id] ?? 0) + 1;
    expect(seen.phoenix / 2000).toBeGreaterThan(0.02);
    expect(seen.phoenix / 2000).toBeLessThan(0.07); // 0.2 / 5.2 ≈ 3.8%
    expect(seen.bless).toBeGreaterThan(seen.phoenix * 3);
  });
  it('the game\'s own condition; a tampered mid-run save', () => {
    const lowWax = new RunChoices<Feat>(FEATS, { eligible: (id) => id !== 'glass' });
    expect(lowWax.pool(lowWax.start())).not.toContain('glass');
    expect(feats.sanitize({ picked: { bless: 9, haste: 1.7, ghost: 2, tough: -1 }, offer: ['bless', 'bless', 'x', 'haste', 'pierce', 'glass'], rerolls: -2 })).toEqual({ picked: { bless: 3, haste: 1 }, offer: ['haste', 'pierce', 'glass'], rerolls: 0 }); // bless is maxed: off the table
  });
  it('bad definitions fail fast', () => {
    expect(() => new RunChoices([{ id: 'a', weight: 0 }])).toThrow(/weight/);
    expect(() => new RunChoices([{ id: 'a', max: 0 }])).toThrow(/max/);
    expect(() => new RunChoices([{ id: 'a', requires: 'b' }])).toThrow(/unknown/);
    expect(() => new RunChoices([{ id: 'a' }], { recent: { offers: 2, weight: 0 } })).toThrow(/recent/);
    expect(() => new RunChoices([{ id: 'a', fill: true }])).toThrow(/filler/);
  });
  it('recent memory: the last offers\' cards come up less often (off by default), never banned', () => {
    type C = 'a' | 'b' | 'c' | 'd' | 'e' | 'f';
    const defs = (['a', 'b', 'c', 'd', 'e', 'f'] as C[]).map((id) => ({ id, max: 99 }));
    const plain = new RunChoices<C>(defs);
    const fresh = new RunChoices<C>(defs, { recent: { offers: 1, weight: 0.1 } });
    // Off by default: no memory in the state, the same draws as before
    expect(plain.offer(plain.start(), seeded(5)).recent).toBeUndefined();
    let repeatsPlain = 0;
    let repeatsFresh = 0;
    let p = plain.start();
    let f = fresh.start();
    const rp = seeded(21);
    const rf = seeded(21);
    for (let i = 0; i < 400; i++) {
      const lastP = p.offer;
      const lastF = f.offer;
      p = plain.offer(p, rp);
      f = fresh.offer(f, rf);
      repeatsPlain += p.offer.filter((id) => lastP.includes(id)).length;
      repeatsFresh += f.offer.filter((id) => lastF.includes(id)).length;
      expect(f.recent!.length).toBe(1);
    }
    // 6 cards, 3 a time: half the cards repeat at random; with the memory far fewer
    expect(repeatsFresh).toBeLessThan(repeatsPlain * 0.5);
    // A short pool still fills (rarer, not banned); a mid-run save keeps the memory, cut to its length
    const two = new RunChoices<'x' | 'y' | 'z'>([{ id: 'x', max: 9 }, { id: 'y', max: 9 }, { id: 'z', max: 9 }], { recent: { offers: 1 } });
    const o = two.offer({ ...two.start(), recent: [['x', 'y', 'z']] }, seeded(2));
    expect([...o.offer].sort()).toEqual(['x', 'y', 'z']);
    expect(two.sanitize({ picked: {}, offer: [], rerolls: 0, recent: [['x', 'q'], ['y']] }).recent).toEqual([['y']]);
  });
  it('fillers top up a short offer (most cards maxed: Frankengun\'s boss bench showed 1 card), never instead of a real one', () => {
    type C = 'pierce' | 'haste' | 'heal' | 'coins';
    const c = new RunChoices<C>([{ id: 'pierce' }, { id: 'haste', max: 2 }, { id: 'heal', fill: true }, { id: 'coins', fill: true }], { size: 3 });
    const first = c.offer(c.start(), seeded(9));
    expect(first.offer.slice(0, 2).sort()).toEqual(['haste', 'pierce']); // the real cards first
    expect(first.offer.filter((id) => id === 'heal' || id === 'coins')).toHaveLength(1);
    expect(c.pool(c.start())).toEqual(['pierce', 'haste']);
    // Everything real maxed: the offer is the fillers, picked any number of times
    let s = c.grant(c.grant(c.grant(c.start(), 'pierce')!, 'haste')!, 'haste')!;
    expect(c.pool(s)).toEqual([]);
    s = c.offer(s, seeded(1));
    expect([...s.offer].sort()).toEqual(['coins', 'heal']);
    for (let i = 0; i < 5; i++) s = c.offer(c.pick(s, 'heal')!, seeded(i));
    expect(c.count(s, 'heal')).toBe(5);
  });
});
