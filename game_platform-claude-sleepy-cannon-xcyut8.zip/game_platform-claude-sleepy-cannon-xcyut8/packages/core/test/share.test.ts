import { describe, expect, it } from 'vitest';
import { shareCode } from '../src/share.ts';

const TREASURES = ['bottlecap', 'spoon', 'marble', 'key', 'button', 'bell', 'thimble', 'coin'] as const;
const V1 = { tree: { type: 'int', min: 0, max: 7 }, shelf: { type: 'list', max: 6, of: { type: 'enum', values: TREASURES.slice(0, 4) } } } as const;
const V2 = {
  tree: { type: 'int', min: 0, max: 15 },
  shelf: { type: 'list', max: 8, of: { type: 'enum', values: TREASURES } },
  lock: { type: 'bool' },
  guard: { type: 'object', fields: { kind: { type: 'enum', values: ['owl', 'cat'] }, level: { type: 'int', min: 1, max: 5 } } },
} as const;
type Den = { tree: number; shelf: string[]; lock: boolean; guard: { kind: string; level: number } };
const DEN = shareCode<Den>({
  salt: 'raccoon-rummage',
  version: 2,
  fields: V2,
  older: { 1: V1 },
  upgrade: (old) => ({ lock: false, guard: { kind: 'owl', level: 1 }, ...(old as { tree: number; shelf: string[] }) }),
});
const den: Den = { tree: 5, shelf: ['bottlecap', 'spoon', 'coin'], lock: true, guard: { kind: 'cat', level: 3 } };

describe('shareCode', () => {
  it('round-trips a snapshot through a short code in groups of four', () => {
    const code = DEN.encode(den);
    expect(code).toMatch(/^[0-9A-HJKMNP-TV-Z]{1,4}(-[0-9A-HJKMNP-TV-Z]{1,4})*$/);
    expect(code.replace(/-/g, '').length).toBeLessThanOrEqual(Math.ceil(DEN.bits / 5));
    expect(code.replace(/-/g, '').length).toBeLessThan(14);
    expect(DEN.decode(code)).toEqual({ ok: true, value: den, version: 2 });
    // Forgiving: lower case, spaces, no dashes, O for 0, I/L for 1
    expect(DEN.decode(` ${code.toLowerCase().replace(/-/g, ' ')} `)).toMatchObject({ ok: true, value: den });
    expect(DEN.decode(code.replace(/0/g, 'O').replace(/1/g, 'I'))).toMatchObject({ ok: true });
  });

  it('refuses a typo, another game\'s code and a newer version, without misreading', () => {
    const code = DEN.encode(den).replace(/-/g, '');
    let refused = 0;
    for (let i = 0; i < code.length; i++) {
      const c = code[i] === 'A' ? 'B' : 'A';
      const r = DEN.decode(code.slice(0, i) + c + code.slice(i + 1));
      if (!r.ok) refused++;
      else expect(r.value).not.toEqual(den);
    }
    expect(refused).toBe(code.length);
    const other = shareCode<Den>({ salt: 'another-game', version: 2, fields: V2 });
    expect(other.decode(DEN.encode(den))).toEqual({ ok: false, reason: 'checksum' });
    const v3 = shareCode<Den & { extra: boolean }>({ salt: 'raccoon-rummage', version: 3, fields: { ...V2, extra: { type: 'bool' } } });
    expect(DEN.decode(v3.encode({ ...den, extra: true }))).toEqual({ ok: false, reason: 'version' });
    expect(DEN.decode('')).toEqual({ ok: false, reason: 'format' });
    expect(DEN.decode('hello world!')).toEqual({ ok: false, reason: 'format' });
    expect(DEN.decode(DEN.encode(den) + 'ZZ')).toMatchObject({ ok: false });
  });

  it('an old version still reads, upgraded', () => {
    const v1 = shareCode<{ tree: number; shelf: string[] }>({ salt: 'raccoon-rummage', version: 1, fields: V1 });
    const old = v1.encode({ tree: 3, shelf: ['key', 'marble'] });
    expect(DEN.decode(old)).toEqual({ ok: true, version: 1, value: { tree: 3, shelf: ['key', 'marble'], lock: false, guard: { kind: 'owl', level: 1 } } });
  });

  it('refuses a value outside the layout (no free text: only numbers, choices, yes/no)', () => {
    expect(() => DEN.encode({ ...den, tree: 16 })).toThrow(/tree/);
    expect(() => DEN.encode({ ...den, shelf: ['diamond'] })).toThrow(/shelf\[0\]/);
    expect(() => DEN.encode({ ...den, shelf: Array(9).fill('key') })).toThrow(/at most 8/);
    expect(() => DEN.encode({ ...den, guard: { kind: 'cat', level: 0 } })).toThrow(/guard.level/);
    expect(() => shareCode({ salt: 'x', version: 0, fields: V2 })).toThrow(/version/);
    expect(() => shareCode({ salt: 'x', version: 1, fields: { e: { type: 'enum', values: [] } } })).toThrow(/distinct/);
  });

  it('in a link: #share=…, read back from the address', () => {
    const url = DEN.url(den, 'https://example.org/play?x=1');
    expect(url).toMatch(/^https:\/\/example\.org\/play\?x=1#share=[0-9A-Z]+$/);
    expect(DEN.fromUrl(url)).toMatchObject({ ok: true, value: den });
    expect(DEN.fromUrl('https://example.org/play')).toBeNull();
  });
});
