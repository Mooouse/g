import { describe, expect, it } from 'vitest';
import { worldClock } from '../src/clock.ts';
import { seededRng } from '../src/rng.ts';
import { variants } from '../src/variants.ts';

type Ctx = { weather: string };
const MUT = variants<Ctx>({
  list: [
    { id: 'wet', mult: 2, chance: 0.5, when: (c) => c.weather === 'rain' },
    { id: 'frozen', mult: 3, chance: 0.2, when: (c) => c.weather === 'snow' || c.weather === 'storm' },
    { id: 'shocked', mult: 50, chance: 0.1, when: (c) => c.weather === 'storm' },
    { id: 'burning', mult: 4, chance: 0.3, when: (c) => c.weather === 'heat', excludes: ['frozen'] },
    { id: 'frost-shock', mult: 120, combo: ['frozen', 'shocked'] },
  ],
  max: 2,
});

describe('variants', () => {
  it('only what the world allows can land; the odds say so', () => {
    expect(MUT.odds({ weather: 'clear' })).toEqual([]);
    expect(MUT.odds({ weather: 'storm' })).toEqual([
      { id: 'frozen', chance: 0.2 },
      { id: 'shocked', chance: 0.1 },
    ]);
    const r = seededRng(1);
    for (let i = 0; i < 200; i++) expect(MUT.roll({ weather: 'clear' }, r)).toEqual([]);
    expect(MUT.odds({ weather: 'storm' }, { luck: 2 })[1].chance).toBeCloseTo(0.2);
  });

  it('combos form, exclusions hold, the cap keeps the most valuable', () => {
    expect(MUT.resolve(['shocked', 'frozen'])).toEqual(['frost-shock']);
    expect(MUT.multiplier(['frozen', 'shocked'])).toBe(120);
    expect(MUT.resolve(['frozen', 'burning'])).toEqual(['frozen']); // the earlier in the list wins
    expect(MUT.resolve(['wet', 'frozen', 'burning', 'shocked'])).toEqual(['wet', 'frost-shock']);
    expect(MUT.resolve(['wet', 'frozen', 'burning'])).toEqual(['wet', 'frozen']);
    const many = variants({ list: [{ id: 'a', mult: 2 }, { id: 'b', mult: 5 }, { id: 'c', mult: 3 }], max: 2 });
    expect(many.resolve(['a', 'b', 'c'])).toEqual(['b', 'c']);
    expect(many.multiplier(['a', 'b', 'c'])).toBe(15);
  });

  it('stacking: multiply, add or the highest', () => {
    const list = [{ id: 'a', mult: 2 }, { id: 'b', mult: 3 }];
    expect(variants({ list }).multiplier(['a', 'b'])).toBe(6);
    expect(variants({ list, stack: 'add' }).multiplier(['a', 'b'])).toBe(4);
    expect(variants({ list, stack: 'highest' }).multiplier(['a', 'b'])).toBe(3);
    expect(variants({ list }).multiplier([])).toBe(1);
  });

  it('apply and value and label: plain data, a new object', () => {
    const item = { base: 'crystal', variants: ['frozen'] };
    const r = seededRng(4);
    let got = item;
    for (let i = 0; i < 50 && !got.variants.includes('frost-shock'); i++) got = MUT.apply(got, { weather: 'storm' }, r);
    expect(got.variants).toEqual(['frost-shock']);
    expect(item.variants).toEqual(['frozen']);
    expect(MUT.value(got, 40)).toBe(4800);
    expect(MUT.label({ base: 'crystal', variants: ['wet', 'frozen'] })).toBe('Wet Frozen Crystal');
    expect(MUT.label(got, (id) => ({ 'frost-shock': 'Frostshock', crystal: 'Kristall' })[id] ?? id)).toBe('Frostshock Kristall');
    expect(JSON.parse(JSON.stringify(got))).toEqual(got);
  });

  it('the expected multiplier is exact (the balance model reads it) and matches a long roll', () => {
    // storm: frozen 0.2, shocked 0.1 → both 0.02 (×120), frozen only 0.18 (×3), shocked only 0.08 (×50), none 0.72
    expect(MUT.expected({ weather: 'storm' })).toBeCloseTo(0.72 + 0.18 * 3 + 0.08 * 50 + 0.02 * 120);
    const r = seededRng(11);
    let sum = 0;
    for (let i = 0; i < 40000; i++) sum += MUT.multiplier(MUT.roll({ weather: 'storm' }, r));
    expect(sum / 40000).toBeGreaterThan(7.2);
    expect(sum / 40000).toBeLessThan(8.1);
    expect(MUT.expected({ weather: 'clear' })).toBe(1);
  });

  it('fed by the world clock: the same weather, the same odds for everyone', () => {
    const t = Date.UTC(2026, 9, 19, 18);
    const sky = worldClock({ salt: 'g', now: () => t }).weather({ states: [{ id: 'rain', weight: 1, lasts: '10m' }, { id: 'storm', weight: 1, lasts: '5m' }] });
    const odds = MUT.odds({ weather: sky.state().id });
    expect(odds.length).toBeGreaterThan(0);
    expect(() => variants({ list: [{ id: 'x', combo: ['y', 'z'] }] })).toThrow(/unknown/);
    expect(() => variants({ list: [{ id: 'x' }, { id: 'x' }] })).toThrow(/twice/);
  });
});
