import { describe, expect, it } from 'vitest';
import { checkSeasons, loadSeason, loadWeek, seasonPass, weekKey, weeklyEvent, type SeasonDef } from '../src/season';

const at = (day: string, hour = 12) => () => Date.parse(`${day}T${String(hour).padStart(2, '0')}:00:00Z`);
const SEASONS: SeasonDef[] = [
  { id: 's1', from: '2026-10-01', to: '2027-01-31', tiers: 30, xp: 200 },
  { id: 's2', from: '2027-02-01', to: '2027-05-31', tiers: 20, xp: (t) => 100 + 10 * t },
];
type Reward = { kind: 'coins'; n: number } | { kind: 'skin'; id: string };
const reward = (t: number): Reward => (t % 3 === 0 ? { kind: 'skin', id: `skin-${t / 3}` } : { kind: 'coins', n: 30 + 5 * t });

function make(save: Record<string, unknown>, day: string, more: Partial<Parameters<typeof seasonPass<Reward>>[1]> = {}) {
  let saves = 0;
  const clock = { now: at(day) };
  const pass = seasonPass<Reward>(save, { seasons: SEASONS, reward, rewardEvery: 3, now: () => clock.now(), persist: () => saves++, ...more });
  return { pass, setDay: (d: string) => (clock.now = at(d)), saves: () => saves };
}

describe('seasonPass', () => {
  it('climbs tiers with XP; a reached tier waits on the track until it is claimed, once', () => {
    const save: Record<string, unknown> = {};
    const { pass } = make(save, '2026-10-18');
    expect(pass.state()).toMatchObject({ phase: 'running', tier: 0, tiers: 30, need: 200, share: 0, claimable: 0 });
    const g = pass.add(650);
    expect(g.reached).toEqual([1, 2, 3]);
    expect(g.paid).toEqual([]);
    const s = pass.state();
    expect(s).toMatchObject({ tier: 3, into: 50, need: 200, claimable: 3 });
    expect(s.share).toBeCloseTo(0.25);
    expect(s.track[2]).toMatchObject({ tier: 3, major: true, state: 'ready', reward: { kind: 'skin', id: 'skin-1' } });
    expect(s.track[3]).toMatchObject({ state: 'locked', next: true, major: false });
    expect(pass.claim(4)).toBeNull();
    expect(pass.claim(2)).toEqual({ kind: 'coins', n: 40 });
    expect(pass.claim(2)).toBeNull();
    expect(pass.claimAll().map((c) => c.tier)).toEqual([1, 3]);
    expect(pass.state().claimable).toBe(0);
    expect((save.season as { claimed: number[] }).claimed).toEqual([1, 2, 3]);
  });

  it("claim: 'auto' pays every tier reached at once, in order", () => {
    const { pass } = make({}, '2026-10-18', { claim: 'auto' });
    const g = pass.add(1e6);
    expect(g.tier).toBe(30);
    expect(g.paid.map((p) => p.tier)).toEqual(Array.from({ length: 30 }, (_, i) => i + 1));
    expect(pass.state()).toMatchObject({ done: true, share: 1, need: 0, claimable: 0 });
    expect(pass.add(500).paid).toEqual([]);
  });

  it('days and weeks missed take nothing away: XP never decays, the tiers wait', () => {
    const save: Record<string, unknown> = {};
    const { pass, setDay } = make(save, '2026-10-02');
    pass.add(450);
    setDay('2026-12-20');
    expect(pass.state()).toMatchObject({ tier: 2, xp: 450, claimable: 2 });
  });

  it('a new season starts at tier 0; the old one\'s unclaimed tiers carry over and stay claimable', () => {
    const save: Record<string, unknown> = {};
    const { pass, setDay } = make(save, '2026-12-01');
    pass.add(1000); // 5 tiers of s1
    pass.claim(1);
    setDay('2027-02-02');
    const s = pass.state();
    expect(s.season.id).toBe('s2');
    expect(s).toMatchObject({ tier: 0, xp: 0, carried: 4, claimable: 4, need: 110 });
    expect(pass.log.life).toBe(1000);
    pass.add(110);
    const all = pass.claimAll();
    expect(all.map((c) => `${c.season}:${c.tier}`)).toEqual(['s1:2', 's1:3', 's1:4', 's1:5', 's2:1']);
    expect(pass.claimAll()).toEqual([]);
    // A reload of the save sees the same
    const again = seasonPass<Reward>(save, { seasons: SEASONS, reward, now: at('2027-02-02') });
    expect(again.state()).toMatchObject({ tier: 1, claimable: 0, carried: 0 });
  });

  it('an ended season keeps its track open until the next; before the first, it is upcoming', () => {
    const one = [SEASONS[0]];
    const ended = seasonPass<Reward>({}, { seasons: one, reward, now: at('2027-03-01') });
    expect(ended.state()).toMatchObject({ phase: 'ended', daysLeft: 0, next: null });
    expect(ended.add(200).reached).toEqual([1]);
    const early = seasonPass<Reward>({}, { seasons: one, reward, now: at('2026-09-25') });
    expect(early.state()).toMatchObject({ phase: 'upcoming', startsIn: 6 });
    const running = seasonPass<Reward>({}, { seasons: SEASONS, reward, now: at('2027-01-31') });
    expect(running.state()).toMatchObject({ phase: 'running', daysLeft: 1, next: { id: 's2' } });
  });

  it('days are UTC by default: the season turns over at 00:00 UTC for everyone', () => {
    const p = seasonPass<Reward>({}, { seasons: SEASONS, reward, now: () => Date.parse('2027-02-01T00:30:00Z') });
    expect(p.state().season.id).toBe('s2');
  });

  it('XP per tier can grow by the tier; null rewards are tiers with nothing', () => {
    const p = seasonPass<Reward | null>({}, { seasons: [SEASONS[1]], reward: (t) => (t === 2 ? null : reward(t)), now: at('2027-03-01') });
    p.add(110 + 120 + 130);
    const s = p.state();
    expect(s.tier).toBe(3);
    expect(s.track.map((x) => x.state).slice(0, 4)).toEqual(['ready', 'claimed', 'ready', 'locked']);
    expect(s.claimable).toBe(2);
    expect(p.claim(2)).toBeNull();
    expect(p.claimAll().map((c) => c.tier)).toEqual([1, 3]);
  });

  it('refuses a bad season list; a broken save comes back safe', () => {
    expect(checkSeasons([])).toEqual(['no season']);
    expect(checkSeasons([SEASONS[1], SEASONS[0]]).join()).toMatch(/before s2 ends/);
    expect(checkSeasons([{ id: 'a', from: '2026-10-05', to: '2026-10-01', tiers: 0, xp: 0 }]).length).toBe(3);
    expect(() => seasonPass({}, { seasons: [], reward })).toThrow(/no season/);
    expect(loadSeason({ xp: -5, claimed: [3, 'x', 3, 999, 2], carry: [{ season: 's1', tier: 2 }, { season: 's1', tier: 2 }, 'junk'], life: 'a' })).toEqual({
      season: '',
      xp: 0,
      claimed: [2, 3, 200],
      carry: [{ season: 's1', tier: 2 }],
      life: 0,
      played: [],
    });
  });
});

describe('weeklyEvent', () => {
  it('weeks run Monday to Sunday', () => {
    expect(weekKey('2026-10-18')).toBe('2026-10-12'); // a Sunday
    expect(weekKey('2026-10-19')).toBe('2026-10-19'); // a Monday
    expect(weekKey('2027-01-01')).toBe('2026-12-28');
    expect(() => weekKey('soon')).toThrow();
  });

  it('one rule a week for everyone, its prize once for reaching the goal', () => {
    const clock = { now: at('2026-10-13') };
    const save: Record<string, unknown> = {};
    const ev = weeklyEvent(save, { rules: ['swarm', 'glass', 'speed', 'giants'], goal: 8, reward: 200, salt: 'test', now: () => clock.now() });
    const s = ev.state();
    expect(s).toMatchObject({ week: '2026-10-12', daysLeft: 6, best: 0, claimable: 0 });
    clock.now = at('2026-10-18');
    expect(ev.state().rule).toBe(s.rule);
    expect(ev.state().daysLeft).toBe(1);
    expect(ev.record(5)).toBe(false);
    expect(ev.record(9)).toBe(true);
    expect(ev.record(12)).toBe(false);
    expect(ev.state()).toMatchObject({ best: 12, reached: true, claimable: 200 });
    expect(ev.claim()).toBe(200);
    expect(ev.claim()).toBeNull();
    // Another player, the same week: the same rule
    expect(weeklyEvent({}, { rules: ['swarm', 'glass', 'speed', 'giants'], goal: 8, reward: 200, salt: 'test', now: at('2026-10-14') }).state().rule).toBe(s.rule);
  });

  it('a prize reached but not claimed survives the week turning (D56); a missed week costs nothing', () => {
    const clock = { now: at('2026-10-14') };
    const ev = weeklyEvent({}, { rules: ['a', 'b'], goal: 3, reward: 50, now: () => clock.now() });
    ev.record(4);
    clock.now = at('2026-11-02');
    expect(ev.state()).toMatchObject({ week: '2026-11-02', best: 0, reached: false, claimable: 50 });
    ev.record(3);
    expect(ev.claim()).toBe(100);
    expect(ev.log.total).toBe(2);
  });

  it('goal null: an event for the best alone; a broken save comes back safe', () => {
    const ev = weeklyEvent({}, { rules: ['a'], goal: null, reward: 50, now: at('2026-10-14') });
    expect(ev.record(99)).toBe(false);
    expect(ev.claim()).toBeNull();
    expect(loadWeek({ week: 'x', best: -3, owed: 'a', reached: 1 })).toEqual({ week: '', best: 0, reached: false, claimed: false, owed: 0, total: 0 });
    expect(() => weeklyEvent({}, { rules: [], goal: 1, reward: 1 })).toThrow(/no rule/);
  });
});
