import { describe, expect, it } from 'vitest';
import { OFFLINE_GENRES, loadOffline, offlineEarnings, stampOffline } from '../src/offline.ts';

const H = 3600_000;
const T0 = Date.UTC(2026, 9, 1, 12);
const clock = (t = T0) => {
  const c = { t, now: () => c.t };
  return c;
};
const OPTS = { share: 0.6, maxHours: 8, minSec: 60 };

describe('offlineEarnings', () => {
  it('a fresh save only sets the stamp', () => {
    const c = clock();
    const save: Record<string, unknown> = {};
    expect(offlineEarnings(save, OPTS, () => 10, c.now)).toBeNull();
    expect(save.offline).toEqual({ at: T0, pending: null });
  });

  it('share × rate × seconds away, paid once; null under minSec', () => {
    const c = clock();
    const save: Record<string, unknown> = {};
    offlineEarnings(save, OPTS, () => 10, c.now);
    c.t += 59_000;
    expect(offlineEarnings(save, OPTS, () => 10, c.now)).toBeNull();
    c.t += 2 * H;
    const away = offlineEarnings(save, OPTS, () => 10, c.now)!;
    expect(away).toMatchObject({ amount: Math.floor(0.6 * 10 * 7200), seconds: 7200, capped: false, rate: 6 });
    expect(away.collect()).toBe(43200);
    expect(away.collect()).toBe(0);
    expect(offlineEarnings(save, OPTS, () => 10, c.now)).toBeNull();
  });

  it('time away is clamped to maxHours; a clock set back pays nothing', () => {
    const c = clock();
    const save: Record<string, unknown> = {};
    offlineEarnings(save, OPTS, () => 1, c.now);
    c.t += 30 * H;
    const away = offlineEarnings(save, OPTS, () => 1, c.now)!;
    expect(away).toMatchObject({ seconds: 8 * 3600, capped: true, amount: Math.floor(0.6 * 8 * 3600) });
    away.collect();
    c.t -= 5 * H;
    expect(offlineEarnings(save, OPTS, () => 1, c.now)).toBeNull();
    expect((save.offline as { at: number }).at).toBe(c.t); // the stamp follows the clock back
  });

  it('survives a reload: the stamp is written with the pending pay-out before it is shown, never paid twice or lost', () => {
    const c = clock();
    let disk = '';
    const save: Record<string, unknown> = {};
    const persist = () => (disk = JSON.stringify(save));
    offlineEarnings(save, { ...OPTS, persist }, () => 10, c.now);
    c.t += H;
    const away = offlineEarnings(save, { ...OPTS, persist }, () => 10, c.now)!;
    expect(away.amount).toBe(21600);
    // The page reloads before the player collects: the same pay-out again, not a second one on top
    const reloaded = JSON.parse(disk);
    const again = offlineEarnings(reloaded, OPTS, () => 10, c.now)!;
    expect(again.amount).toBe(21600);
    expect(again.collect(2)).toBe(43200); // a rewarded ×2
    expect(offlineEarnings(reloaded, OPTS, () => 10, c.now)).toBeNull();
    // More time away on top of a pending pay-out adds to it
    const s2: Record<string, unknown> = {};
    offlineEarnings(s2, OPTS, () => 1, c.now);
    c.t += H;
    offlineEarnings(s2, OPTS, () => 1, c.now);
    c.t += H;
    expect(offlineEarnings(s2, OPTS, () => 1, c.now)!.amount).toBe(2 * 2160);
  });

  it('stampOffline moves the start of the time away (the game was running); a dead rate earns nothing', () => {
    const c = clock();
    const save: Record<string, unknown> = {};
    offlineEarnings(save, OPTS, () => 10, c.now);
    c.t += 3 * H;
    stampOffline(save, { now: c.now }); // played for three hours
    c.t += 10 * 60_000;
    const away = offlineEarnings(save, OPTS, () => 10, c.now)!;
    expect(away.seconds).toBe(600);
    away.collect();
    c.t += H;
    expect(offlineEarnings(save, OPTS, () => NaN, c.now)).toBeNull();
    expect(loadOffline({ at: 'x', pending: { amount: -1 } })).toEqual({ at: 0, pending: null });
    expect(OFFLINE_GENRES).toEqual(['idle']);
  });
});
