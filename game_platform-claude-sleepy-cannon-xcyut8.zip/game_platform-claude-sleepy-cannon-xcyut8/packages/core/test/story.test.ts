import { describe, expect, it } from 'vitest';
import { createI18n } from '../src/i18n.ts';
import {
  barkText,
  commitScene,
  dueScene,
  loadStory,
  nextChapter,
  parseCondition,
  parseLine,
  storyProgress,
  storyState,
  storyStrings,
  StoryRunner,
  validateStory,
  type StoryDef,
  type StoryIssue,
} from '../src/story.ts';

// A Brew & Banter-shaped story (QmaCyber/game5, story.ts): a cat who came with the shop, a villager, the villain, a
// postcard, a side scene, and a finale that joins its branches with goto/label instead of copying lines
const BREW: StoryDef = {
  cast: {
    pip: { name: 'Pip', color: '#e0a526', voice: 660, moods: ['neutral', 'happy', 'sad', 'smug', 'surprised', 'worried', 'angry'] },
    tom: { name: 'Old Tom', color: '#5e9a36' },
    vex: { name: 'Master Vex', color: '#7b44b8' },
    wren: { name: 'Grandma Wren', color: '#a45fc0' },
  },
  moods: ['neutral', 'happy', 'sad', 'worried', 'smug', 'angry', 'surprised'],
  vars: { story: { trust: 0 }, game: ['day', 'lifetime', 'rep'] },
  rewards: ['gold', 'rep'],
  events: ['unlock-golems'],
  cues: ['point-cauldron'],
  chapters: ['cat', 'tom', 'guild', 'finale'],
  scenes: {
    cat: {
      title: 'The Bubbling Kettle',
      at: 'run-end',
      lines: [
        'The key is under the pot of dead basil.',
        {
          who: 'pip',
          text: "I'm Pip. I came with the shop. Like the damp.",
          choose: [
            { id: 'shock', text: 'A talking cat?!', then: ['pip/smug: A talking cat who knows where the gold is.'] },
            { id: 'polite', text: 'Nice to meet you, Pip.', do: { set: 'politePip', add: { trust: 1 } }, then: ["pip/surprised: Manners. Huh."] },
          ],
        },
        { who: 'pip', mood: 'happy', text: 'Wren said you would be the nice one.', if: 'politePip' },
        { who: 'pip', text: 'Tap the cauldron. Every tap bottles a potion.', cue: 'point-cauldron' },
      ],
    },
    tom: {
      title: 'Goats and Gratitude',
      when: 'day >= 2',
      lines: [
        'tom/happy: Well I will be! Wren has a grandkid!',
        {
          who: 'tom',
          mood: 'worried',
          text: 'My Duchess ate the fence again. A Goat Calmer?',
          choose: [
            { id: 'free', text: 'On the house, Tom.', do: { give: { rep: 2 }, set: 'tomFriend', add: { trust: 1 } }, then: ['tom/happy: You have her heart, too.'] },
            { id: 'paid', text: "That'll be 20 gold.", do: { give: { gold: 20 } }, then: ["tom/smug: Fair's fair."] },
          ],
        },
      ],
    },
    guild: {
      title: 'The Man in the Tall Hat',
      when: 'day >= 3 and lifetime >= 600',
      lines: [
        'vex/smug: The Guild will buy this cottage. Five hundred gold.',
        {
          who: 'vex',
          text: 'Well?',
          choose: [
            { id: 'no', text: 'Not for sale.', do: { set: 'defiant' } },
            { id: 'think', text: "I'll think about it.", do: { set: 'wavering' } },
          ],
        },
        { who: 'pip', mood: 'worried', text: 'We need friends at the Moonfair.', if: 'not tomFriend' },
      ],
    },
    finale: {
      title: 'The Moonfair',
      when: 'lifetime >= 4500000 and rep >= 55',
      lines: [
        { who: 'pip', mood: 'sad', text: 'Hello, Vex. It has been a while.', if: 'trust >= 2', goto: 'apology' },
        { who: 'pip', text: 'Vex.' },
        { label: 'apology' },
        {
          who: 'vex',
          mood: 'sad',
          text: 'I have been angry at a shop for thirty years.',
          choose: [
            { id: 'seat', text: "There's always a seat at the Kettle.", do: { set: 'vexFriend', give: { rep: 5 } } },
            { id: 'sorry', text: 'Say sorry to the valley.', do: { give: { rep: 3 } } },
          ],
        },
        { who: 'wren', mood: 'happy', text: 'Coming home for tea on Sunday. Love, Gran.', do: { set: 'won', fire: 'unlock-golems' }, ending: 'won' },
      ],
    },
    'tom-goat-again': {
      at: 'run-end',
      when: 'seen(tom) and day >= 6',
      priority: 1,
      lines: ["tom/worried: Duchess ate the church bell rope. Don't ask."],
    },
    'pip-bored': {
      at: 'run-end',
      when: 'day >= 4',
      once: false,
      lines: ['pip/smug: Another day, another potion.'],
    },
  },
};

const story = loadStory(BREW);
const fresh = () => storyState(story);

/** Play a scene with a list of choice ids, tapping Next everywhere else */
function play(scene: string, state = fresh(), picks: string[] = [], progress = {}) {
  const run = new StoryRunner(story, scene, state, progress);
  const shown: string[] = [];
  const queue = [...picks];
  while (!run.done) {
    shown.push(run.line!.text);
    if (run.choices().length) expect(run.choose(queue.shift()!)).toBe(true);
    else expect(run.next()).toBe(true);
  }
  return { run, shown, result: run.result };
}

const codes = (issues: StoryIssue[], severity?: 'error' | 'warning') => issues.filter((i) => !severity || i.severity === severity).map((i) => i.code);

describe('lines and conditions', () => {
  it('reads "speaker/mood: text", plain narrator text, objects and the YAML form', () => {
    expect(parseLine('pip/smug: You are late.')).toEqual({ who: 'pip', mood: 'smug', text: 'You are late.' });
    expect(parseLine('pip: Hi.')).toEqual({ who: 'pip', mood: undefined, text: 'Hi.' });
    expect(parseLine('The door creaks.')).toEqual({ text: 'The door creaks.' });
    expect(parseLine({ who: 'tom', text: 'Hey' })).toEqual({ who: 'tom', text: 'Hey' });
    expect(parseLine({ 'pip/sad': 'Hello, Vex.', if: 'cure' } as never)).toEqual({ who: 'pip', mood: 'sad', text: 'Hello, Vex.', if: 'cure' });
  });

  it('parses the condition language (never eval) with the usual precedence, and rejects the rest', () => {
    expect(parseCondition('a or b and not c')).toEqual({ k: 'or', a: { k: 'var', name: 'a' }, b: { k: 'and', a: { k: 'var', name: 'b' }, b: { k: 'not', e: { k: 'var', name: 'c' } } } });
    expect(parseCondition('seen(tom-goat) && chose(cat.polite) || day >= -1').k).toBe('or');
    expect(parseCondition('(rep > 50)')).toEqual({ k: 'cmp', op: '>', a: { k: 'var', name: 'rep' }, b: { k: 'lit', v: 50 } });
    for (const bad of ['day >=', 'a b', 'alert("x")', 'a; b', 'chose(cat)', '(a', 'a == = b']) expect(() => parseCondition(bad), bad).toThrow();
  });

  it('checks conditions on game progress and story state', () => {
    const s = fresh();
    expect(dueScene(story, s, 'run-start', { day: 1 })).toBeNull();
    const done = commitScene(story, s, play('cat', s, ['polite']).result);
    expect(dueScene(story, done, 'run-start', { day: 1 })).toBeNull();
    expect(dueScene(story, done, 'run-start', { day: 2 })).toBe('tom');
  });
});

describe('StoryRunner', () => {
  it('plays lines in order; a choice made earlier in the scene counts at once; cues are reported', () => {
    const polite = play('cat', fresh(), ['polite']);
    expect(polite.shown).toEqual([
      'The key is under the pot of dead basil.',
      "I'm Pip. I came with the shop. Like the damp.",
      'Manners. Huh.',
      'Wren said you would be the nice one.',
      'Tap the cauldron. Every tap bottles a potion.',
    ]);
    expect(polite.result).toMatchObject({ completed: true, skipped: false, choices: ['polite'], cues: ['point-cauldron'] });
    const shock = play('cat', fresh(), ['shock']);
    expect(shock.shown).not.toContain('Wren said you would be the nice one.');
  });

  it('gives lines their speaker, mood (neutral by default) and a stable id', () => {
    const run = new StoryRunner(story, 'cat', fresh());
    expect(run.line).toEqual({ id: 'cat.1', who: 'narrator', mood: 'neutral', text: 'The key is under the pot of dead basil.' });
    run.next();
    expect(run.line).toMatchObject({ id: 'cat.2', who: 'pip', mood: 'neutral' });
    expect(run.choices()).toEqual([
      { id: 'shock', text: 'A talking cat?!' },
      { id: 'polite', text: 'Nice to meet you, Pip.' },
    ]);
    expect(run.next()).toBe(false); // a choice is due
    expect(run.choose('nope')).toBe(false);
    run.choose('shock');
    expect(run.line).toMatchObject({ id: 'cat.2.shock.1', who: 'pip', mood: 'smug' });
  });

  it('goto/label joins branches without copying lines', () => {
    const s = { ...fresh(), vars: { ...fresh().vars, trust: 2 } };
    expect(play('finale', s, ['seat']).shown.slice(0, 2)).toEqual(['Hello, Vex. It has been a while.', 'I have been angry at a shop for thirty years.']);
    expect(play('finale', fresh(), ['seat']).shown.slice(0, 2)).toEqual(['Vex.', 'I have been angry at a shop for thirty years.']);
  });

  it('a line whose choices are all hidden plays as a plain line', () => {
    const s = loadStory({ cast: {}, scenes: { a: { lines: [{ text: 'Hm.', choose: [{ id: 'x', text: 'X', if: 'never', do: { set: 'y' } }] }, 'Bye.'] } }, vars: { story: { never: false } } });
    const run = new StoryRunner(s, 'a', storyState(s));
    expect(run.choices()).toEqual([]);
    expect(run.next()).toBe(true);
    expect(run.line?.text).toBe('Bye.');
  });

  it('commits effects only when the scene ends: an interrupted scene pays nothing and replays clean', () => {
    const s = fresh();
    const run = new StoryRunner(story, 'tom', s, { day: 2 });
    run.next();
    run.choose('free');
    expect(run.result).toMatchObject({ completed: false, give: { rep: 2 } });
    // The game closes the dialogue here (QA end(), a reload): nothing is written
    expect(commitScene(story, s, run.result)).toBe(s);
    expect(s).toEqual(fresh());
    // Replays from the top with the same choices
    const again = new StoryRunner(story, 'tom', s, { day: 2 });
    expect(again.line?.text).toBe('Well I will be! Wren has a grandkid!');
    run.next();
    const done = commitScene(story, s, run.result);
    expect(done.seen).toEqual({ tom: 1 });
    expect(done.chose).toEqual({ tom: ['free'] });
    expect(done.vars).toMatchObject({ tomFriend: true, trust: 1 });
    expect(run.result.give).toEqual({ rep: 2 });
    // A second commit of the same result changes nothing (never pays twice)
    expect(commitScene(story, done, run.result)).toBe(done);
    expect(s.seen).toEqual({}); // the old state is untouched
  });

  it('commit replays var changes onto the current state (add counts, set/clear flags)', () => {
    let s = fresh();
    s = commitScene(story, s, play('cat', s, ['polite']).result);
    s = commitScene(story, s, play('tom', s, ['free'], { day: 2 }).result);
    expect(s.vars).toMatchObject({ politePip: true, trust: 2, tomFriend: true });
    const f = play('finale', s, ['sorry']);
    expect(f.result).toMatchObject({ give: { rep: 3 }, fire: ['unlock-golems'], ending: 'won' });
    s = commitScene(story, s, f.result);
    expect(s.vars.won).toBe(true);
    expect(s.chose.finale).toEqual(['sorry']);
  });

  it('skip goes to the next choice point (choices stay the player\'s), then to the end, keeping effects', () => {
    const run = new StoryRunner(story, 'finale', fresh());
    run.skip();
    expect(run.line?.text).toBe('I have been angry at a shop for thirty years.');
    expect(run.choices().map((c) => c.id)).toEqual(['seat', 'sorry']);
    run.choose('seat');
    run.skip();
    expect(run.done).toBe(true);
    expect(run.result).toMatchObject({ completed: true, skipped: true, give: { rep: 5 }, fire: ['unlock-golems'], ending: 'won' });
    expect(commitScene(story, fresh(), run.result).vars).toMatchObject({ vexFriend: true, won: true });
  });

  it('refuses a goto loop with nothing to show instead of hanging', () => {
    const s = loadStory({ cast: {}, scenes: { a: { lines: [{ label: 'x' }, { goto: 'x' }] } } });
    expect(() => new StoryRunner(s, 'a', storyState(s))).toThrow(/loops/);
  });

  it('loadStory throws when a story can\'t run', () => {
    expect(() => loadStory({ cast: {}, scenes: { a: { lines: [{ text: 'x', goto: 'nowhere' }] } } })).toThrow(/no such label/);
    expect(() => loadStory({ cast: {}, scenes: { a: { when: 'day >', lines: ['x'] } } })).toThrow(/scenes\.a\.when/);
    expect(() => loadStory({ cast: {}, chapters: ['b'], scenes: { a: { lines: ['x'] } } })).toThrow(/chapter "b"/);
  });
});

describe('state, due scenes, progress', () => {
  it('the state is plain JSON; a saved one is cleaned (unknown scenes and vars, wrong types)', () => {
    const s = fresh();
    expect(s).toEqual({ v: 1, seen: {}, chose: {}, vars: { trust: 0, politePip: false, tomFriend: false, defiant: false, wavering: false, vexFriend: false, won: false } });
    expect(JSON.parse(JSON.stringify(s))).toEqual(s);
    const saved = storyState(story, { seen: { cat: 1, gone: 2, tom: -1 }, chose: { cat: ['polite', 3], gone: ['x'] }, vars: { trust: 'lots', won: true, hacked: 9 } });
    expect(saved).toMatchObject({ seen: { cat: 1 }, chose: { cat: ['polite'] } });
    expect(saved.vars).toMatchObject({ trust: 0, won: true });
    expect(saved.vars).not.toHaveProperty('hacked');
    expect(storyState(story, 'garbage')).toEqual(fresh());
  });

  it('main chapters come in order, each at its moment when its condition holds; side scenes by priority', () => {
    let s = fresh();
    const tell = (id: string, picks: string[], progress = {}) => {
      s = commitScene(story, s, play(id, s, picks, progress).result);
    };
    expect(dueScene(story, s, 'run-start', { day: 1 })).toBeNull(); // the first chapter plays after a run, not before
    expect(dueScene(story, s, 'run-end', { day: 1 })).toBe('cat');
    tell('cat', ['shock']);
    expect(nextChapter(story, s)).toBe('tom');
    expect(dueScene(story, s, 'run-start', { day: 2 })).toBe('tom');
    tell('tom', ['paid'], { day: 2 });
    expect(dueScene(story, s, 'run-start', { day: 3, lifetime: 100 })).toBeNull();
    expect(dueScene(story, s, 'run-start', { day: 3, lifetime: 600 })).toBe('guild');
    // Side scenes at the end of a run: the goat scene (priority 1) beats Pip's repeatable line, and plays once
    expect(dueScene(story, s, 'run-end', { day: 6 })).toBe('tom-goat-again');
    tell('tom-goat-again', []);
    expect(dueScene(story, s, 'run-end', { day: 6 })).toBe('pip-bored');
    tell('pip-bored', []);
    expect(dueScene(story, s, 'run-end', { day: 6 })).toBe('pip-bored'); // once: false
    expect(storyProgress(story, s)).toBe(50);
    tell('guild', ['no']);
    tell('finale', ['seat']);
    expect(storyProgress(story, s)).toBe(100);
    expect(nextChapter(story, s)).toBeNull();
  });
});

describe('validateStory', () => {
  it('the Brew & Banter-shaped story has no errors and no warnings', () => {
    expect(validateStory(BREW)).toEqual([]);
  });

  const one = (lines: StoryDef['scenes'][string]['lines'], extra: Partial<StoryDef> = {}, scene: Partial<StoryDef['scenes'][string]> = {}) =>
    validateStory({ cast: { pip: { name: 'Pip', moods: ['neutral', 'happy'] } }, rewards: ['gold'], events: ['boom'], cues: ['arrow'], ...extra, scenes: { a: { ...scene, lines }, ...extra.scenes } });

  it('catches speakers and moods that do not exist', () => {
    expect(codes(one(['bob: Hi.']))).toContain('E_STORY_SPEAKER');
    expect(codes(one(['pip/angry: Hi.']))).toContain('E_STORY_MOOD');
    expect(codes(one(['narrator/sad: Hi.']))).toContain('E_STORY_MOOD');
    expect(codes(one(['pip/happy: Hi.', 'pip: Plain.', 'Just the narrator.']), 'error')).toEqual([]);
  });

  it('catches broken references: goto, labels, vars, seen(), chose(), chapters', () => {
    expect(codes(one([{ text: 'x', goto: 'nowhere' }]))).toContain('E_STORY_REF');
    expect(codes(one(['x'], {}, { when: 'mystery > 2' }))).toContain('E_STORY_REF');
    expect(codes(one(['x'], {}, { when: 'seen(ghost)' }))).toContain('E_STORY_REF');
    expect(codes(one(['x'], {}, { when: 'chose(a.nope)' }))).toContain('E_STORY_REF');
    expect(codes(one(['x'], { chapters: ['a', 'zzz'] }))).toContain('E_STORY_REF');
    expect(codes(one(['x'], {}, { at: 'lunch' as never }))).toContain('E_STORY_REF');
    expect(codes(one([{ text: 'x', choose: [{ id: 'y', text: 'Y', then: [{ label: 'in' }, 'z'] }] }]))).toContain('E_STORY_REF');
    expect(codes(one(['x'], {}, { when: 'day >=' }))).toContain('E_STORY_CONDITION');
    expect(codes(one(['x'], { vars: { game: ['day'] } }, { when: 'day >= 2' }), 'error')).toEqual([]);
  });

  it('catches effects on undeclared rewards, events, cues and the wrong kind of var', () => {
    expect(codes(one([{ text: 'x', do: { give: { gems: 5 } } }]))).toContain('E_STORY_EFFECT');
    expect(codes(one([{ text: 'x', do: { fire: 'nope' } }]))).toContain('E_STORY_EFFECT');
    expect(codes(one([{ text: 'x', cue: 'nope' }]))).toContain('E_STORY_EFFECT');
    expect(codes(one([{ text: 'x', do: { set: 'f' } }, { text: 'y', do: { add: { f: 1 } } }]))).toContain('E_STORY_EFFECT');
    expect(codes(one([{ text: 'x', do: { set: 'day' } }], { vars: { game: ['day'] } }))).toContain('E_STORY_EFFECT');
    expect(codes(one([{ text: 'x', do: { give: { gold: 5 }, fire: 'boom' }, cue: 'arrow' }]), 'error')).toEqual([]);
  });

  it('catches dead ends: a goto loop with no way out, or with no line at all', () => {
    const loop = one([{ label: 'top' }, { text: 'Again?', choose: [{ id: 'y', text: 'Yes', then: [{ goto: 'top' }] }, { id: 'n', text: 'No', then: [{ goto: 'top' }] }] }]);
    expect(codes(loop)).toContain('E_STORY_DEAD_END');
    expect(codes(one([{ label: 'top' }, { goto: 'top' }]))).toContain('E_STORY_DEAD_END');
    // A loop with an exit is fine
    const exit = one([{ label: 'top' }, { text: 'Again?', choose: [{ id: 'y', text: 'Yes', then: [{ goto: 'top' }] }, { id: 'n', text: 'No', then: ['Bye.'] }] }]);
    expect(codes(exit, 'error')).toEqual([]);
  });

  it('catches unreachable scenes and warns about lines no path shows', () => {
    const r = one(['x'], { vars: { story: { never: false } }, chapters: ['a'] }, { when: 'never' });
    expect(codes(r)).toContain('E_STORY_UNREACHABLE');
    // Set somewhere: reachable
    expect(codes(one(['x'], { chapters: ['a'], scenes: { b: { lines: [{ text: 'y', do: { set: 'never' } }] } } }, { when: 'never' }))).not.toContain('E_STORY_UNREACHABLE');
    expect(codes(one([{ text: 'x', if: 'never' }, 'y'], { vars: { story: { never: false } } }))).toContain('W_STORY_LINE_UNREACHABLE');
  });

  it('catches 0 or more than 3 choices, duplicate or empty choices, and warns about choices without payoff', () => {
    const c = (n: number) => Array.from({ length: n }, (_, i) => ({ id: `c${i}`, text: `Choice ${i}`, then: ['ok'] }));
    expect(codes(one([{ text: 'x', choose: c(4) }]))).toContain('E_STORY_CHOICES');
    expect(codes(one([{ text: 'x', choose: [] }]))).toContain('E_STORY_CHOICES');
    expect(codes(one([{ text: 'x', choose: c(3) }]), 'error')).toEqual([]);
    expect(codes(one([{ text: 'x', choose: c(1) }]), 'error')).toEqual([]);
    expect(codes(one([{ text: 'x', choose: [{ id: 'a', text: 'Same', then: ['1'] }, { id: 'b', text: 'Same', then: ['2'] }] }]))).toContain('E_STORY_CHOICES');
    expect(codes(one([{ text: 'x', choose: [{ id: 'a', text: '', then: ['1'] }] }]))).toContain('E_STORY_CHOICES');
    expect(codes(one([{ text: 'x', choose: [{ id: 'a', text: 'A' }] }]))).toContain('W_STORY_NO_PAYOFF');
  });

  it('catches duplicate ids: choices in a scene, explicit line ids, labels, chapters; and bad id patterns', () => {
    expect(codes(one([{ text: 'x', choose: [{ id: 'a', text: 'A', then: ['1'] }] }, { text: 'y', choose: [{ id: 'a', text: 'B', then: ['2'] }] }]))).toContain('E_STORY_IDS');
    expect(codes(one([{ id: 'l1', text: 'x' }, { id: 'l1', text: 'y' }]))).toContain('E_STORY_IDS');
    expect(codes(one([{ label: 'k' }, 'x', { label: 'k' }]))).toContain('E_STORY_IDS');
    expect(codes(one(['x'], { chapters: ['a', 'a'] }))).toContain('E_STORY_IDS');
    expect(codes(one([{ text: 'x', choose: [{ id: 'has space', text: 'A', then: ['1'] }] }]))).toContain('E_STORY_IDS');
  });

  it('checks lengths: a line over 140 characters is an error, over 100 a warning; scene words on the longest path', () => {
    expect(codes(one(['pip: ' + 'a'.repeat(141)]))).toContain('E_STORY_LINE_LONG');
    expect(codes(one(['pip: ' + 'a'.repeat(101)]))).toEqual(['W_STORY_LINE_LONG']);
    const lines = (n: number) => Array.from({ length: n }, () => 'pip: one two three four five six seven eight nine ten');
    expect(codes(one(lines(13)))).toContain('W_STORY_SCENE_LONG'); // 130 words
    expect(codes(one(lines(21)))).toContain('E_STORY_SCENE_LONG'); // 210 words
    expect(codes(one(lines(21), {}, { long: 'the finale, reviewed' }))).toEqual([]);
    // The longest path counts, not the sum of every branch
    const branches = one([{ text: 'Pick', choose: [{ id: 'a', text: 'A', then: lines(7) }, { id: 'b', text: 'B', then: lines(7) }] }]);
    expect(codes(branches)).toEqual([]); // 71 words on either path, 141 in all
  });

  it('keeps the first chapter ≤ 60 words and a first-action scene ≤ 20 words', () => {
    const w = (n: number) => 'pip: ' + Array.from({ length: n }, () => 'word').join(' ');
    expect(codes(one([w(40), w(30)], { chapters: ['a'] }))).toContain('E_STORY_FIRST_SCENE');
    expect(codes(one([w(40), w(20)], { chapters: ['a'] }))).not.toContain('E_STORY_FIRST_SCENE');
    expect(codes(one([w(21)], {}, { at: 'first-action' }))).toContain('E_STORY_FIRST_ACTION');
    expect(codes(one([w(20)], {}, { at: 'first-action' }))).toEqual([]);
  });

  it('warns about choice points that can all be hidden and about narrator walls', () => {
    expect(codes(one([{ text: 'x', choose: [{ id: 'a', text: 'A', if: 'day > 3', then: ['1'] }] }], { vars: { game: ['day'] } }))).toContain('W_STORY_ALL_HIDDEN');
    expect(codes(one(['One.', 'Two.', 'Three.']))).toContain('W_STORY_NARRATOR_WALL');
  });

  it('limits can be tightened for an audience', () => {
    expect(codes(one([{ text: 'x', choose: [{ id: 'a', text: 'A', then: ['1'] }, { id: 'b', text: 'B', then: ['2'] }, { id: 'c', text: 'C', then: ['3'] }] }], {}), 'error')).toEqual([]);
    const kids = validateStory({ cast: {}, scenes: { a: { lines: [{ text: 'x', choose: [{ id: 'a', text: 'A', then: ['1'] }, { id: 'b', text: 'B', then: ['2'] }, { id: 'c', text: 'C', then: ['3'] }] }] } } }, { choices: 2 });
    expect(codes(kids)).toContain('E_STORY_CHOICES');
  });

  it('issues say where and how to fix', () => {
    const [i] = one(['bob: Hi.']);
    expect(i).toMatchObject({ code: 'E_STORY_SPEAKER', severity: 'error', path: ['scenes', 'a', 'lines', 0] });
    expect(i.fix).toMatch(/cast/);
  });
  it('a save or a condition naming Object internals (__proto__, constructor) changes nothing and is reported', () => {
    const s = loadStory({ cast: {}, scenes: { a: { lines: ['Hi.'] } }, vars: { story: { trust: 0 } } });
    const st = storyState(s, JSON.parse('{"v":1,"vars":{"__proto__":{"polluted":true},"trust":2}}'));
    expect(Object.getPrototypeOf(st.vars)).toBe(Object.prototype);
    expect(st.vars.trust).toBe(2);
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
    const issues = validateStory({ cast: {}, scenes: { a: { lines: [{ text: 'x', if: 'constructor' }, 'y'] } } });
    expect(issues.map((i) => i.code)).toContain('E_STORY_REF');
  });
});

describe('the story in the player\'s language (strings keys; Swarm Smash\'s block request)', () => {
  const DEF: StoryDef = {
    cast: { mira: { name: 'Mira' } },
    scenes: {
      dock: {
        lines: [
          'mira: The swarm is back.',
          { who: 'mira', text: 'Ready?', choose: [{ id: 'yes', text: 'Always.', then: ['mira: Good.'] }, { id: 'no', text: 'Not yet.' }] },
          { id: 'farewell', text: 'Fly safe.' },
        ],
      },
    },
  };
  it('storyStrings: every line, choice and bark as a key with its English', () => {
    expect(storyStrings(DEF, { 'run-start': ['Go!', 'Again!'] })).toEqual({
      'story.dock.1': 'The swarm is back.',
      'story.dock.2': 'Ready?',
      'story.dock.2.yes': 'Always.',
      'story.dock.2.yes.1': 'Good.',
      'story.dock.2.no': 'Not yet.',
      'story.farewell': 'Fly safe.',
      'bark.run-start.1': 'Go!',
      'bark.run-start.2': 'Again!',
    });
  });
  it('StoryRunner with host.i18n shows the player\'s language; a key strings/en.yaml lacks stays the file\'s English', () => {
    const en = storyStrings(DEF, { hit: ['Ouch!'] });
    delete en['story.farewell'];
    const ru = { 'story.dock.1': 'Рой вернулся.', 'story.dock.2': 'Готов?', 'story.dock.2.yes': 'Всегда.', 'bark.hit.1': 'Ай!' };
    const i18n = createI18n({ strings: { en, ru }, languages: ['en', 'ru'], lang: 'ru' });
    const run = new StoryRunner(loadStory(DEF), 'dock', storyState(loadStory(DEF)), {}, { i18n });
    expect(run.line!.text).toBe('Рой вернулся.');
    run.next();
    expect(run.choices()).toEqual([{ id: 'yes', text: 'Всегда.' }, { id: 'no', text: 'Not yet.' }]); // no ru text: English
    run.choose('no');
    expect(run.line!.text).toBe('Fly safe.'); // not in strings: the file's English
    expect(barkText(i18n, 'hit', 0, 'Ouch!')).toBe('Ай!');
    expect(barkText(null, 'hit', 0, 'Ouch!')).toBe('Ouch!');
    // Without i18n, as before
    expect(new StoryRunner(loadStory(DEF), 'dock', storyState(loadStory(DEF))).line!.text).toBe('The swarm is back.');
  });
});
