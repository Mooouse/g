// A degenerate box must not throw: arcTo rejects a negative radius, and a throw kills the frame.
// (Seen on the Android emulator when the WebView collapses for a frame during an activity switch.)

import { describe, expect, it } from 'vitest';
import { drawPanel, roundRect } from '../src/draw.ts';

function fakeCtx() {
  const calls: string[] = [];
  const ctx = {
    fillStyle: '',
    beginPath: () => calls.push('beginPath'),
    moveTo: () => calls.push('moveTo'),
    closePath: () => calls.push('closePath'),
    fill: () => calls.push('fill'),
    arcTo: (_x1: number, _y1: number, _x2: number, _y2: number, r: number) => {
      if (r < 0) throw new Error(`IndexSizeError: negative radius ${r}`);
      calls.push('arcTo');
    },
  };
  return { ctx: ctx as unknown as CanvasRenderingContext2D, calls };
}

describe('roundRect / drawPanel', () => {
  it('a normal box is drawn', () => {
    const { ctx, calls } = fakeCtx();
    roundRect(ctx, 0, 0, 100, 50, 10);
    expect(calls.filter((c) => c === 'arcTo')).toHaveLength(4);
  });
  it('negative or zero sizes draw nothing and do not throw', () => {
    const { ctx, calls } = fakeCtx();
    expect(() => roundRect(ctx, 0, 0, -51.5, 40, 10)).not.toThrow();
    expect(() => roundRect(ctx, 0, 0, 40, 0, 10)).not.toThrow();
    expect(() => drawPanel(ctx, 0, 0, -10, -10, 5, '#fff')).not.toThrow();
    expect(calls.includes('arcTo')).toBe(false);
    expect(calls.includes('fill')).toBe(false);
  });
});
