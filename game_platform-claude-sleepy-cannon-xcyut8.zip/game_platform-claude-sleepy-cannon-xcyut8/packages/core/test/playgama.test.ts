import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { PlaygamaPortal, type PlaygamaBridge } from '../src/portal';

/** A fake Bridge: records messages, plays ad states the test chooses */
function fakeBridge(opts: { rewarded?: boolean; interstitial?: boolean; plays?: (kind: string, emit: (s: string) => void) => void } = {}) {
  const listeners = new Map<string, Set<(s: unknown) => void>>();
  const on = (e: string, fn: (s: unknown) => void) => {
    if (!listeners.has(e)) listeners.set(e, new Set());
    listeners.get(e)!.add(fn);
  };
  const off = (e: string, fn?: (s: unknown) => void) => (fn ? listeners.get(e)?.delete(fn) : listeners.delete(e));
  const emit = (e: string, s: unknown) => [...(listeners.get(e) ?? [])].forEach((f) => f(s));
  const messages: string[] = [];
  const stored = new Map<string, string>([['game.save.v1', '{"best":7}']]);
  const placements: (string | null | undefined)[] = [];
  const bridge: PlaygamaBridge = {
    storage: {
      get: async (keys: string[]) => keys.map((k) => stored.get(k) ?? null),
      set: async (keys: string[], values: string[]) => void keys.forEach((k, i) => stored.set(k, values[i])),
    },
    initialize: async () => {},
    platform: { id: 'playgama', language: 'pt', isAudioEnabled: true, isPaused: false, sendMessage: async (m: string) => void messages.push(m), on, off },
    advertisement: {
      isInterstitialSupported: opts.interstitial ?? true,
      isRewardedSupported: opts.rewarded ?? true,
      showInterstitial: () => opts.plays?.('interstitial', (s) => emit('interstitial_state_changed', s)),
      showRewarded: (placement) => (placements.push(placement), opts.plays?.('rewarded', (s) => emit('rewarded_state_changed', s))),
      on,
      off,
    },
  };
  return { bridge, messages, emit, listeners, stored, placements };
}

beforeEach(() => vi.useFakeTimers());
afterEach(() => vi.useRealTimers());

describe('Playgama Bridge portal', () => {
  it('reports the lifecycle: game_ready once, gameplay started and stopped', async () => {
    const f = fakeBridge();
    const p = new PlaygamaPortal(f.bridge);
    await p.init();
    p.loadingStop();
    p.loadingStop();
    p.gameplayStart();
    p.gameplayStop();
    await Promise.resolve();
    expect(f.messages).toEqual(['game_ready', 'gameplay_started', 'gameplay_stopped']);
    expect(p.locale()).toBe('pt');
  });

  it('a rewarded ad pays only when the platform says rewarded, then closed', async () => {
    const f = fakeBridge({ plays: (_, emit) => ['loading', 'opened', 'rewarded', 'closed'].forEach((s) => emit(s)) });
    const p = new PlaygamaPortal(f.bridge);
    await p.init();
    await expect(p.adProvider()!.showRewarded!()).resolves.toBe(true);
    const skipped = fakeBridge({ plays: (_, emit) => ['loading', 'opened', 'closed'].forEach((s) => emit(s)) });
    const q = new PlaygamaPortal(skipped.bridge);
    await q.init();
    await expect(q.adProvider()!.showRewarded!()).resolves.toBe(false);
    expect([...(skipped.listeners.get('rewarded_state_changed') ?? [])]).toHaveLength(0);
  });

  it("passes the game's placement on to the Bridge (Playgama's QA Tool logs each request by it)", async () => {
    const f = fakeBridge({ plays: (_, emit) => ['loading', 'opened', 'closed'].forEach((s) => emit(s)) });
    const p = new PlaygamaPortal(f.bridge);
    await p.init();
    await p.adProvider()!.showRewarded!('revive');
    expect(f.placements).toEqual(['revive']);
  });

  it('no rewarded ads on the platform: off; a failed or never-starting interstitial: false', async () => {
    const none = new PlaygamaPortal(fakeBridge({ rewarded: false }).bridge);
    await none.init();
    await expect(none.adProvider()!.showRewarded!()).resolves.toBe('off');
    const failed = new PlaygamaPortal(fakeBridge({ plays: (_, emit) => emit('failed') }).bridge);
    await failed.init();
    await expect(failed.adProvider()!.show()).resolves.toBe(false);
    const silent = new PlaygamaPortal(fakeBridge({ plays: () => {} }).bridge);
    await silent.init();
    const r = silent.adProvider()!.show();
    vi.advanceTimersByTime(6000);
    await expect(r).resolves.toBe(false);
    const shown = new PlaygamaPortal(fakeBridge({ plays: (_, emit) => ['opened', 'closed'].forEach((s) => emit(s)) }).bridge);
    await shown.init();
    await expect(shown.adProvider()!.show()).resolves.toBe(true);
  });

  it("an ad Bridge defers or skips after 'loading' (no 'opened', no 'closed') frees the game in 10 s; an opened one that never closes in 45 s", async () => {
    const deferred = new PlaygamaPortal(fakeBridge({ plays: (_, emit) => emit('loading') }).bridge);
    await deferred.init();
    let r: boolean | undefined;
    void deferred.adProvider()!.show().then((x) => (r = x));
    await vi.advanceTimersByTimeAsync(9000);
    expect(r).toBeUndefined();
    await vi.advanceTimersByTimeAsync(1500);
    expect(r).toBe(false);
    const stuck = new PlaygamaPortal(fakeBridge({ plays: (_, emit) => ['loading', 'opened'].forEach((s) => emit(s)) }).bridge);
    await stuck.init();
    let q: boolean | 'off' | undefined;
    void stuck.adProvider()!.showRewarded!().then((x) => (q = x));
    await vi.advanceTimersByTimeAsync(44000);
    expect(q).toBeUndefined();
    await vi.advanceTimersByTimeAsync(1500);
    expect(q).toBe(false);
  });

  it("a platform pause holds until Bridge lifts it (Playgama's QA Tool: a system overlay — the game stands still the whole time)", async () => {
    const f = fakeBridge({ plays: () => {} });
    const p = new PlaygamaPortal(f.bridge);
    await p.init();
    const paused: boolean[] = [];
    p.onPause!((x) => paused.push(x));
    f.emit('pause_state_changed', true);
    await vi.advanceTimersByTimeAsync(120000);
    expect(paused).toEqual([true]);
    f.emit('pause_state_changed', false);
    expect(paused).toEqual([true, false]);
  });

  it("an ad Bridge still reports 'opened' (a cross-promo waiting for its Close) holds the game past 45 s, and its pause is never stale", async () => {
    const f = fakeBridge({ plays: (_, emit) => ['loading', 'opened'].forEach((s) => emit(s)) });
    (f.bridge.advertisement as { interstitialState?: string }).interstitialState = 'opened';
    const p = new PlaygamaPortal(f.bridge);
    await p.init();
    const paused: boolean[] = [];
    p.onPause!((x) => paused.push(x));
    let r: boolean | undefined;
    void p.adProvider()!.show().then((x) => (r = x));
    f.emit('pause_state_changed', true);
    await vi.advanceTimersByTimeAsync(90000);
    expect(r).toBeUndefined();
    expect(paused).toEqual([true]);
    // The player taps Close: Bridge says closed and lifts its pause
    (f.bridge.advertisement as { interstitialState?: string }).interstitialState = 'closed';
    f.emit('interstitial_state_changed', 'closed');
    f.emit('pause_state_changed', false);
    await vi.advanceTimersByTimeAsync(100);
    expect(r).toBe(true);
    expect(paused).toEqual([true, false]);
  });

  it("a rewarded ad's pause ends with the ad when Bridge never lifts it (the sandbox: pause true on open, no false after close)", async () => {
    const f = fakeBridge({ plays: (_, emit) => { emit('loading'); emit('opened'); f.emit('pause_state_changed', true); emit('rewarded'); emit('closed'); } });
    const p = new PlaygamaPortal(f.bridge);
    await p.init();
    const paused: boolean[] = [];
    p.onPause!((x) => paused.push(x));
    await expect(p.adProvider()!.showRewarded!('revive')).resolves.toBe(true);
    expect(paused).toEqual([true, false]);
    // Bridge's own false coming late is no second resume; a pause with no ad of ours (the QA Tool's overlay) still holds
    f.emit('pause_state_changed', false);
    expect(paused).toEqual([true, false]);
    f.emit('pause_state_changed', true);
    await vi.advanceTimersByTimeAsync(60000);
    expect(paused).toEqual([true, false, true]);
  });

  it("an interstitial calls onOpen on 'opened' only: a load that ends in no fill never does", async () => {
    const filled = new PlaygamaPortal(fakeBridge({ plays: (_, emit) => ['loading', 'opened', 'closed'].forEach((s) => emit(s)) }).bridge);
    await filled.init();
    const opens: number[] = [];
    expect(filled.adProvider()!.startsOnOpen).toBe(true);
    await expect(filled.adProvider()!.show(() => opens.push(1))).resolves.toBe(true);
    expect(opens).toEqual([1]);
    const nofill = new PlaygamaPortal(fakeBridge({ plays: (_, emit) => ['loading', 'failed'].forEach((s) => emit(s)) }).bridge);
    await nofill.init();
    await expect(nofill.adProvider()!.show(() => opens.push(2))).resolves.toBe(false);
    expect(opens).toEqual([1]);
  });

  it('saves through Bridge storage: loaded in one call at init, written through', async () => {
    const f = fakeBridge();
    const p = new PlaygamaPortal(f.bridge);
    await p.init(['game.save.v1', 'game.save.v1.lang']);
    const st = p.storage()!;
    expect(st.getItem('game.save.v1')).toBe('{"best":7}');
    expect(st.getItem('game.save.v1.lang')).toBeNull();
    st.setItem('game.save.v1', '{"best":9}');
    await Promise.resolve();
    expect(f.stored.get('game.save.v1')).toBe('{"best":9}');
  });

  it('follows the platform audio and pause', async () => {
    const f = fakeBridge();
    const p = new PlaygamaPortal(f.bridge);
    await p.init();
    const muted: boolean[] = [];
    const paused: boolean[] = [];
    p.onMuteChange((m) => muted.push(m));
    p.onPause!((x) => paused.push(x));
    f.emit('audio_state_changed', false);
    f.emit('pause_state_changed', true);
    f.emit('pause_state_changed', false);
    expect(muted).toEqual([true]);
    expect(paused).toEqual([true, false]);
  });
});
