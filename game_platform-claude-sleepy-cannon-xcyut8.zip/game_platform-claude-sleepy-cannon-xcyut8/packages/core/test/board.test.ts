// Board: square and hex geometry, polyominoes that turn and flip, a backpack with rotation, star cells and adjacency
// synergies (Swarm Smash's ship, Frankengun's part grid), tile laying with matching edges (Dorfromantik), regions,
// full lines and the pattern matcher.

import { describe, expect, it } from 'vitest';
import { Board, OFF, POLYOMINOES, orientations, polyomino, posKey, type Pos } from '../src/board.ts';
import { UndoHistory } from '../src/undo.ts';

const sorted = (cells: readonly Pos[]) => cells.map(posKey).sort();

describe('Board: geometry', () => {
  it('square: 4 neighbours (8 with diagonals), Manhattan or Chebyshev distance, rings and lines', () => {
    const b = new Board({ size: [5, 5] });
    expect(b.neighbours([2, 2])).toEqual([[2, 1], [3, 2], [2, 3], [1, 2]]);
    expect(new Board({ size: [5, 5], diagonal: true }).neighbours([2, 2])).toHaveLength(8);
    expect(b.distance([0, 0], [2, 3])).toBe(5);
    expect(new Board({ diagonal: true }).distance([0, 0], [2, 3])).toBe(3);
    expect(b.ring([2, 2], 1)).toHaveLength(4);
    expect(b.line([0, 0], 1, 3)).toEqual([[1, 0], [2, 0], [3, 0]]);
    expect(b.cells(b.start())).toHaveLength(25);
  });

  it('hex: 6 neighbours, axial distance, a ring of radius r has 6r cells, a board of radius 2 has 19', () => {
    const b = new Board({ grid: 'hex', radius: 2 });
    expect(b.neighbours([0, 0])).toHaveLength(6);
    expect(b.distance([0, 0], [2, -1])).toBe(2);
    expect(b.distance([0, 0], [1, 1])).toBe(2);
    for (const r of [1, 2, 3]) expect(b.ring([0, 0], r)).toHaveLength(6 * r);
    expect(b.cells(b.start())).toHaveLength(19);
    expect(b.inside(b.start(), [2, 1])).toBe(false);
  });

  it('a cell tagged off is not on the board; untagging grows the board', () => {
    const b = new Board({ size: [3, 1] });
    let s = b.start({ '2,0': [OFF] });
    expect(b.cells(s)).toHaveLength(2);
    expect(b.whyNot(s, 'x', [2, 0])).toBe('outside');
    s = b.tag(s, [2, 0], []);
    expect(b.canPlace(s, 'x', [2, 0])).toBe(true);
  });
});

describe('Board: polyominoes', () => {
  it('distinct orientations: O 1, I 2, T 4, L 4 (8 mirrored), S 2 (4 mirrored: S and Z)', () => {
    const n = (name: string, flip = false) => orientations(polyomino(name), { flip }).length;
    expect([n('O4'), n('I4'), n('T4'), n('L4'), n('L4', true), n('S4'), n('S4', true), n('X5', true)]).toEqual([1, 2, 4, 4, 8, 2, 4, 1]);
    // a turned shape sits in its corner
    for (const t of orientations(polyomino('L4'), { flip: true })) {
      expect(Math.min(...t.cells.map((c) => c[0]))).toBe(0);
      expect(Math.min(...t.cells.map((c) => c[1]))).toBe(0);
    }
    // mirrored, S is Z
    expect(orientations(polyomino('S4'), { flip: true }).map((t) => sorted(t.cells))).toContainEqual(sorted(POLYOMINOES.Z4));
  });

  it('hex shapes turn by sixths: a straight three has 3 orientations, a bent one 6', () => {
    expect(orientations({ cells: [[0, 0], [1, 0], [2, 0]] }, { grid: 'hex' })).toHaveLength(3);
    expect(orientations({ cells: [[0, 0], [1, 0], [1, 1]] }, { grid: 'hex' })).toHaveLength(6);
  });

  it('a block puzzle: every placement of a piece, full rows and columns', () => {
    const b = new Board<string>({ size: [4, 4], shapeOf: (id) => polyomino(id) });
    let s = b.start();
    expect(b.placements(s, 'O4')).toHaveLength(9);
    expect(b.placements(s, 'I4')).toHaveLength(8); // 4 rows + 4 columns
    s = b.place(s, 'I4', [0, 3])!;
    expect(b.fullLines(s)).toEqual({ rows: [3], cols: [] });
    expect(b.place(s, 'I4', [0, 0], 1)).toBeNull(); // upright it would cross the full row
    s = b.place(s, 'I3', [0, 0], 1)!; // turned upright: column 0 is full with the row's first cell
    expect(sorted(b.cellsOf(s.pieces[1]))).toEqual(['0,0', '0,1', '0,2']);
    expect(b.fullLines(s)).toEqual({ rows: [3], cols: [0] });
  });
});

// --- A backpack (Backpack Hero, Swarm Smash's ship, Frankengun's part grid) --------------------------------------------

type Item = { id: 'sword' | 'whetstone' | 'shield' | 'chip' | 'barrel' | 'gem' };
const SHAPES: Record<Item['id'], { cells: Pos[]; stars?: Pos[] }> = {
  sword: { cells: [[0, 0], [0, 1], [0, 2]] },
  // the whetstone's star sits just right of it: a blade lying there is sharpened
  whetstone: { cells: [[0, 0]], stars: [[1, 0]] },
  shield: { cells: [[0, 0], [1, 0], [0, 1], [1, 1]] },
  chip: { cells: [[0, 0]] },
  barrel: { cells: [[0, 0], [1, 0]] },
  gem: { cells: [[0, 0]] },
};
/** A 5×4 bag with its corner cut off; gems only on the cells tagged 'socket' */
const backpack = () =>
  new Board<Item>({
    size: [5, 4],
    shapeOf: (it) => SHAPES[it.id],
    accepts: (it, _p, tags) => (it.id === 'gem' ? tags.includes('socket') : !tags.includes('socket')),
  });

/** The pack's stats: base damage, +2 a sharpened sword, +50% a chip beside a barrel (Frankengun's adjacency boost) */
function packStats(b: Board<Item>, s: ReturnType<Board<Item>['start']>): { damage: number; synergies: string[] } {
  let damage = s.pieces.filter((p) => p.item.id === 'sword').length * 3 + s.pieces.filter((p) => p.item.id === 'barrel').length * 2;
  const synergies: string[] = [];
  for (const w of s.pieces.filter((p) => p.item.id === 'whetstone'))
    for (const st of b.starred(s, w.uid))
      if (st.piece?.item.id === 'sword') {
        damage += 2;
        synergies.push('sharp');
      }
  for (const [chip] of b.pairs(s, (a, c) => a.item.id === 'chip' && c.item.id === 'barrel')) {
    damage += 1;
    synergies.push(`boost${chip.uid}`);
  }
  return { damage, synergies };
}

describe('Board: a backpack with rotation, stars and synergies', () => {
  it('place, turn, move, take out — with the reason a drop is refused', () => {
    const b = backpack();
    let s = b.start({ '4,3': [OFF], '4,0': ['socket'] });
    s = b.place(s, { id: 'sword' }, [0, 0], 1)!; // lying flat: (0,0)…(2,0)
    expect(sorted(b.cellsOf(s.pieces[0]))).toEqual(['0,0', '1,0', '2,0']);
    expect(b.whyNot(s, { id: 'shield' }, [1, 0])).toBe('taken');
    expect(b.whyNot(s, { id: 'shield' }, [4, 2])).toBe('outside');
    expect(b.whyNot(s, { id: 'shield' }, [3, 2])).toBe('outside'); // the cut corner
    expect(b.whyNot(s, { id: 'chip' }, [4, 0])).toBe('refused'); // a socket is for gems
    expect(b.canPlace(s, { id: 'gem' }, [4, 0])).toBe(true);
    s = b.place(s, { id: 'shield' }, [0, 1])!;
    // turning the sword upright now hits the shield; moving it to the right column first works
    expect(b.turn(s, 1)).toBeNull();
    s = b.move(s, 1, [3, 0], 0)!;
    expect(b.cellsOf(b.piece(s, 1)!)).toEqual([[3, 0], [3, 1], [3, 2]]);
    s = b.remove(s, 2)!;
    expect(b.pieceAt(s, [0, 1])).toBeNull();
    expect(b.remove(s, 99)).toBeNull();
  });

  it('a whetstone whose star touches the sword sharpens it; a chip beside a barrel boosts it', () => {
    const b = backpack();
    let s = b.start();
    s = b.place(s, { id: 'sword' }, [2, 0])!; // upright in column 2
    s = b.place(s, { id: 'whetstone' }, [1, 1])!; // its star at (2,1): on the sword
    expect(packStats(b, s)).toEqual({ damage: 5, synergies: ['sharp'] });
    // turned half round, the star points away (0,1): the synergy goes out
    const away = b.turn(s, 2, 2)!;
    expect(b.starred(away, 2)).toEqual([{ pos: [0, 1], piece: null }]);
    expect(packStats(b, away).synergies).toEqual([]);
    s = b.place(s, { id: 'barrel' }, [3, 3])!;
    s = b.place(s, { id: 'chip' }, [3, 2])!; // above the barrel, beside the sword
    expect(b.touching(s, 4).map((p) => p.item.id).sort()).toEqual(['barrel', 'sword']);
    expect(packStats(b, s)).toEqual({ damage: 8, synergies: ['sharp', 'boost4'] });
  });

  it('the bot asks where an item could go; undo is an UndoHistory of states; a save loads safe', () => {
    const b = backpack();
    const h = new UndoHistory(b.start());
    const spots = b.placements(h.current, { id: 'barrel' });
    expect(spots).toHaveLength(16 + 15); // flat: 4 a row × 4 rows; upright: 3 a column × 5 columns
    h.push(b.place(h.current, { id: 'barrel' }, spots[0].at, spots[0].o)!);
    h.push(b.place(h.current, { id: 'shield' }, [3, 2])!);
    h.undo();
    expect(h.current.pieces.map((p) => p.item.id)).toEqual(['barrel']);
    const saved = JSON.parse(JSON.stringify(h.current));
    expect(b.sanitize(saved)).toEqual(h.current);
    // an overlapping, an outside and a duplicated piece are dropped
    const broken = { pieces: [...saved.pieces, { uid: 7, item: { id: 'chip' }, at: [0, 0], o: 0 }, { uid: 8, item: { id: 'shield' }, at: [4, 3], o: 0 }, { ...saved.pieces[0] }], tags: { bad: ['x'] }, uid: 'q' };
    const clean = b.sanitize(broken);
    expect(clean.pieces).toHaveLength(1);
    expect(clean.uid).toBe(2);
    expect(clean.tags).toEqual({});
  });
});

// --- Tile laying (Dorfromantik) ---------------------------------------------------------------------------------------

type Tile = { e: string[] }; // hex edges E SE SW W NW NE
const F = 'forest';
const G = 'grass';
const W = 'water';

describe('Board: tile laying with matching edges', () => {
  it('an open hex map: the first tile anywhere, the next ones touching; perfect fits counted, forests closed', () => {
    const map = new Board<Tile>({ grid: 'hex', edgesOf: (t) => t.e, touch: true, strictEdges: false });
    let s = map.start();
    expect(map.placements(s, { e: [F, F, F, F, F, F] })).toEqual([{ at: [0, 0], o: 0 }]);
    s = map.place(s, { e: [F, G, G, G, G, G] }, [0, 0])!; // a forest edge pointing east
    expect(map.whyNot(s, { e: [G, G, G, G, G, G] }, [5, 5])).toBe('alone');
    // all six spots around it, each in the tile's distinct turns
    const half = { e: [F, F, F, G, G, G] };
    expect(map.placements(s, half)).toHaveLength(6 * 6);
    // east of it, a tile whose west edge is forest closes nothing yet: its other forest edges are open
    expect(map.fit(s, half, [1, 0], 3)).toEqual({ matched: 1, mismatched: 0, open: 5 });
    expect(map.fit(s, half, [1, 0], 0)).toEqual({ matched: 0, mismatched: 1, open: 5 }); // west edge is grass: allowed, not perfect
    s = map.place(s, { e: [G, G, G, F, G, G] }, [1, 0])!; // forest facing back west
    expect(map.edgeRegions(s, F)).toEqual([{ cells: [[0, 0], [1, 0]], open: 0, closed: true }]);
    expect(map.edgeRegions(s, W)).toEqual([]);
  });

  it('a square map with strict edges (Carcassonne): a mismatch is refused', () => {
    const map = new Board<Tile>({ edgesOf: (t) => t.e, touch: true });
    let s = map.place(map.start(), { e: [G, W, G, G] }, [0, 0])!; // river flowing east
    expect(map.whyNot(s, { e: [G, G, G, G] }, [1, 0])).toBe('edge');
    expect(map.canPlace(s, { e: [G, G, G, W] }, [1, 0])).toBe(true);
    // a river bend W→S fits east of it only in turns that keep water on its west side
    const bend = { e: [G, G, W, W] };
    expect(map.placements(s, bend).filter((p) => p.at[0] === 1 && p.at[1] === 0).map((p) => p.o)).toEqual([0, 1]);
    s = map.place(s, bend, [1, 0])!;
    expect(map.edgeRegions(s, W)[0]).toMatchObject({ cells: [[0, 0], [1, 0]], open: 1, closed: false });
  });
});

describe('Board: regions and patterns', () => {
  const garden = () => new Board<string>({ size: [4, 3] });
  const plant = (s: ReturnType<Board<string>['start']>, b: Board<string>, cells: [number, number, string][]) => cells.reduce((t, [x, y, k]) => b.place(t, k, [x, y])!, s);

  it('flood fill by a test: the forests, the biggest first', () => {
    const b = garden();
    const s = plant(b.start(), b, [[0, 0, 'tree'], [1, 0, 'tree'], [1, 1, 'tree'], [3, 2, 'tree'], [3, 0, 'bear']]);
    const forests = b.regions(s, (c) => c.piece?.item === 'tree');
    expect(forests.map((r) => r.length)).toEqual([3, 1]);
    expect(b.regions(s, (c) => !c.piece).map((r) => r.length)).toEqual([7]);
    expect(b.empty(s)).toHaveLength(7);
  });

  it('a pattern (three bears in an L, any turn): complete matches, and the ones a bear short for the hint', () => {
    const b = garden();
    const L = { cells: [[0, 0], [0, 1], [1, 1]] as Pos[], test: (c: { piece: { item: string } | null }) => c.piece?.item === 'bear' };
    let s = plant(b.start(), b, [[0, 0, 'bear'], [0, 1, 'bear'], [3, 0, 'tree']]);
    expect(b.find(s, L)).toEqual([]);
    const near = b.progress(s, L, 2);
    expect(near.length).toBeGreaterThan(0);
    expect(near.every((m) => m.matched === 2 && m.missing.length === 1)).toBe(true);
    expect(near.map((m) => posKey(m.missing[0])).sort()).toEqual(['1,0', '1,1']);
    s = b.place(s, 'bear', [1, 1])!;
    const found = b.find(s, L);
    expect(found).toHaveLength(1);
    expect(sorted(found[0].cells)).toEqual(['0,0', '0,1', '1,1']);
  });
});
