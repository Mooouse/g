import { describe, expect, it } from 'vitest';
import { DAILY_KEEP, dailyDone, dayKey, daySeed, loadDaily, recordDaily } from '../src/daily.ts';
import { seededRng } from '../src/rng.ts';

describe('dayKey', () => {
  it('UTC by default: the same key for everyone at one moment', () => {
    expect(dayKey(new Date('2026-10-01T23:30:00Z'))).toBe('2026-10-01');
    expect(dayKey(new Date('2026-10-02T00:00:00Z'))).toBe('2026-10-02');
    expect(dayKey(new Date('2026-01-05T12:00:00Z'))).toBe('2026-01-05');
  });
  it("local: the player's own calendar date", () => {
    const d = new Date(2026, 9, 1, 23, 59); // 1 October, 23:59 local
    expect(dayKey(d, { local: true })).toBe('2026-10-01');
  });
});

describe('daySeed', () => {
  it('the same for a key and a salt; different for neighbouring days and for other games', () => {
    expect(daySeed('2026-10-01', 'echoflies')).toBe(daySeed('2026-10-01', 'echoflies'));
    expect(daySeed('2026-10-01', 'echoflies')).not.toBe(daySeed('2026-10-02', 'echoflies'));
    expect(daySeed('2026-10-01', 'echoflies')).not.toBe(daySeed('2026-10-01', 'candle-crypt'));
    const s = daySeed('2026-10-01');
    expect(Number.isInteger(s) && s >= 0 && s < 2 ** 32).toBe(true);
  });
  it("a day's level is the same for every player: the seed drives seededRng", () => {
    const a = seededRng(daySeed('2026-10-01', 'g'));
    const b = seededRng(daySeed('2026-10-01', 'g'));
    expect([a(), a(), a.int(100)]).toEqual([b(), b(), b.int(100)]);
  });
});

describe('the daily log', () => {
  it("a broken or old save loads clean; Echoflies' plain string array is read as the days", () => {
    expect(loadDaily(undefined)).toEqual({ days: [], count: 0 });
    expect(loadDaily({ days: 'x', count: 'y' })).toEqual({ days: [], count: 0 });
    expect(loadDaily({ days: ['2026-10-02', 'junk', 7, '2026-10-01', '2026-10-02'], count: 1 })).toEqual({ days: ['2026-10-01', '2026-10-02'], count: 2 });
    expect(loadDaily(['2026-09-30', '2026-10-01'])).toEqual({ days: ['2026-09-30', '2026-10-01'], count: 2 });
  });
  it('a clear counts once; a replay of a cleared day changes nothing', () => {
    const log = loadDaily(null);
    expect(dailyDone(log, '2026-10-01')).toBe(false);
    expect(recordDaily(log, '2026-10-01')).toBe(true);
    expect(dailyDone(log, '2026-10-01')).toBe(true);
    expect(recordDaily(log, '2026-10-01')).toBe(false);
    expect(log).toEqual({ days: ['2026-10-01'], count: 1 });
    expect(recordDaily(log, 'not a day')).toBe(false);
  });
  it('the list is trimmed to the newest days, the count goes on', () => {
    const log = loadDaily(null);
    const start = Date.UTC(2026, 0, 1);
    for (let i = 0; i < DAILY_KEEP + 15; i++) recordDaily(log, dayKey(new Date(start + i * 86400000)));
    expect(log.days.length).toBe(DAILY_KEEP);
    expect(log.count).toBe(DAILY_KEEP + 15);
    expect(log.days[0]).toBe(dayKey(new Date(start + 15 * 86400000)));
    // A reload keeps the count above the trimmed list
    expect(loadDaily(JSON.parse(JSON.stringify(log)))).toEqual(log);
  });
});
