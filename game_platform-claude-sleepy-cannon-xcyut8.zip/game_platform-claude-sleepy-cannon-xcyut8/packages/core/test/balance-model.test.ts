// The balance model: tables walked in expected values, the checks it makes, the report gp balance reads

import { describe, expect, it } from 'vitest';
import { evaluateBalance } from '../src/balance.ts';
import { atMinute, atMinuteWindow, curve, fitWinCurve, modelCsv, snapshotText, solveModel, walkModel, winChance, type BalanceModel } from '../src/balance-model.ts';

/** A campaign that works: difficulty ×1.3 a stage, rewards ×1.25, five upgrades of 4 levels each */
function sane(): BalanceModel {
  const d = curve.geometric(10, 10, 1.3);
  const r = curve.geometric(10, 20, 1.25);
  const items = ['blade', 'armour', 'boots', 'ring', 'tome'].flatMap((u, k) =>
    curve.geometric(4, 15 + 10 * k, 1.8).map((cost, l) => ({ id: `${u}-${l + 1}`, cost, mult: 1.18, ...(l ? { requires: `${u}-${l}` } : {}) })),
  );
  return { start: { power: 11 }, stages: d.map((difficulty, i) => ({ id: `s${i + 1}`, difficulty, reward: r[i], minutes: 1.2 })), items, measure: 'DPS × HP' };
}

describe('curves', () => {
  it('builds tables and reads their growth', () => {
    expect(curve.linear(4, 10, 5)).toEqual([10, 15, 20, 25]);
    expect(curve.geometric(4, 100, 1.5)).toEqual([100, 150, 225, 338]);
    expect(curve.power(3, 10, 2)).toEqual([10, 40, 90]);
    expect(curve.rate([100, 150, 225])).toBeCloseTo(1.5);
    expect(curve.rate([5])).toBeNull();
  });
});

describe('the win curve', () => {
  it('wins half at even power, more with more', () => {
    expect(winChance(1)).toBeCloseTo(0.5);
    expect(winChance(1.5)).toBeCloseTo(0.835, 2);
    expect(winChance(0.7)).toBeCloseTo(0.194, 2);
    expect(winChance(0)).toBe(0);
  });
  it("fits the steepness to a bot's points", () => {
    const pts = [0.5, 0.8, 1.25, 2].map((ratio) => ({ ratio, win: winChance(ratio, 3) }));
    expect(fitWinCurve(pts)).toBeCloseTo(3, 1);
  });
});

describe('solveModel', () => {
  it('a sane campaign: both buyers finish, no failures, the report reads ok', () => {
    const r = solveModel(sane());
    expect(r.cheap.stuck).toBeNull();
    expect(r.cheap.finishMin).toBeGreaterThan(5);
    expect(r.careful.finishMin).not.toBeNull();
    expect(r.failed).toBe(0);
    expect(r.checks.find((c) => c.name === 'model: No purchase dominates')?.status).toBe('ok');
    expect(r.checks.find((c) => c.name === 'model: No grind')?.status).toBe('ok');
    expect(r.cheap.stages.every((s) => s.clearedMin !== null)).toBe(true);
    expect(r.cheap.firstPurchaseMin).not.toBeNull();
    expect(r.report.full!).toBeGreaterThan(r.report.fresh!);
    const v = evaluateBalance(r.report, 'crazygames');
    expect(v.rows.find((x) => x.name === 'Every purchase changes something')?.status).toBe('ok');
    expect(r.markdown).toContain('| s10 |');
  });
  it('a stage 6× harder is a grind (replaying for every upgrade); 60× is a wall nothing can buy past', () => {
    const m = sane();
    const at = (k: number) => m.stages.map((s, i) => (i === 6 ? { ...s, difficulty: s.difficulty * k } : s));
    const grind = solveModel({ ...m, stages: at(6) });
    expect(grind.checks.find((c) => c.name === 'model: No grind')?.status).toBe('warn');
    expect(grind.cheap.stages[6].farmMin).toBeGreaterThan(10);
    const wall = solveModel({ ...m, stages: at(60), maxMinutes: 120 });
    expect(wall.cheap.stuck).toMatch(/s7/);
    expect(wall.checks.find((c) => c.name === 'model: No wall')?.status).toBe('fail');
  });
  it('replays the last stage for coins when the next is out of reach, and calls a lot of it grind', () => {
    const m = sane();
    const stages = m.stages.map((s, i) => (i === 3 ? { ...s, difficulty: s.difficulty * 1.8 } : s));
    const r = walkModel({ ...m, stages }, 'cheapest');
    expect(r.stages[3].farmMin).toBeGreaterThan(0);
    expect(r.farmMin).toBeGreaterThan(0);
  });
  it('a dead item fails, a dominant one warns, a falling difficulty warns', () => {
    const m = sane();
    const items = [...m.items, { id: 'hat', cost: 10 }, { id: 'cheat', cost: 12, mult: 3 }];
    const stages = m.stages.map((s, i) => (i === 5 ? { ...s, difficulty: m.stages[4].difficulty * 0.8 } : s));
    const r = solveModel({ ...m, items, stages });
    expect(r.checks.find((c) => c.name === 'model: Every purchase adds power')?.status).toBe('fail');
    expect(r.checks.find((c) => c.name === 'model: No purchase dominates')?.status).toBe('warn');
    expect(r.checks.find((c) => c.name === 'model: Difficulty and reward rise stage by stage')?.status).toBe('warn');
  });
  it('an entry is paid before the stage, farming the one before until it is affordable; out of reach at the start is stuck', () => {
    const m = sane();
    const stages = m.stages.map((st, i) => (i === 4 ? { ...st, entry: 400 } : st));
    const r = walkModel({ ...m, stages }, 'cheapest');
    expect(r.stuck).toBeNull();
    expect(r.stages[4].farmMin).toBeGreaterThan(0);
    const first = walkModel({ ...m, stages: m.stages.map((st, i) => (i === 0 ? { ...st, entry: 5 } : st)) }, 'cheapest');
    expect(first.stuck).toMatch(/s1: its entry/);
  });
  it('items unlock after their stage; finish "all" waits for every item', () => {
    const m = sane();
    const items = [...m.items, { id: 'dragon', cost: 400, mult: 1.5, after: 's8', goal: true }];
    const r = solveModel({ ...m, items, finish: 'all' });
    const dragon = r.cheap.items.find((i) => i.id === 'dragon')!;
    const s8 = r.cheap.stages.find((s) => s.id === 's8')!;
    expect(dragon.boughtMin).not.toBeNull();
    expect(dragon.boughtMin!).toBeGreaterThanOrEqual(s8.clearedMin!);
    expect(r.cheap.finishMin!).toBeGreaterThanOrEqual(dragon.boughtMin!);
    expect(r.cheap.goalsMin).toContain(dragon.boughtMin);
  });
  it('writes the tables as CSV', () => {
    const { stages, items } = modelCsv(solveModel(sane()));
    expect(stages.split('\n')[0]).toBe('stage,difficulty,reward,arrive_min,arrive_power,ratio,win_on_arrival,attempts,farm_min,cleared_min,coins_earned');
    expect(stages.trim().split('\n')).toHaveLength(11);
    expect(items.trim().split('\n')).toHaveLength(21);
  });
});

// Why the model is worth it (2026-10-03): it orders candidate economies the way a stochastic bot does, so a designer
// tunes on the model and runs the bot once. The bot here plays a different win curve (k = 3 vs the model's 4), noisy
// rewards and minutes and a ±20 % skill spread
describe('the model against a stochastic bot', () => {
  const rng = (seed: number) => {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  const econ = (priceMul: number, rewardRate: number, diffRate: number): BalanceModel => {
    const d = curve.geometric(12, 10, diffRate);
    const r = curve.geometric(12, 20, rewardRate);
    const items = ['a', 'b', 'c', 'd', 'e', 'f'].flatMap((u, k) => curve.geometric(4, (15 + 10 * k) * priceMul, 1.8).map((cost, l) => ({ id: `${u}${l}`, cost, mult: 1.15, ...(l ? { requires: `${u}${l - 1}` } : {}) })));
    return { start: { power: 11 }, stages: d.map((difficulty, i) => ({ id: `s${i}`, difficulty, reward: r[i], minutes: 1.3 })), items };
  };
  const bot = (m: BalanceModel, seed: number): number => {
    const R = rng(seed);
    let power = m.start.power * (0.8 + 0.4 * R());
    let coins = 0;
    let t = 0;
    const bought = new Set<string>();
    const shop = () => {
      for (;;) {
        const open = m.items.filter((i) => !bought.has(i.id) && (!i.requires || bought.has(i.requires)) && i.cost <= coins);
        if (!open.length) return;
        const p = open.reduce((x, y) => (y.cost < x.cost ? y : x));
        coins -= p.cost;
        power *= p.mult ?? 1;
        bought.add(p.id);
      }
    };
    for (const s of m.stages)
      for (;;) {
        if (t > 300) return 300;
        const x = Math.pow(power / s.difficulty, 3);
        const won = R() < x / (1 + x);
        coins += s.reward * (won ? 1 : 0.3) * (0.7 + 0.6 * R());
        t += s.minutes * (0.6 + 0.8 * R()) + 0.25;
        shop();
        if (won) break;
      }
    return t;
  };
  it('orders 36 economies like the bot (Spearman ≥ 0.9) and predicts their length within 25 % (median)', () => {
    const grid: [number, number, number][] = [];
    for (const pm of [0.6, 1, 1.5, 2.2]) for (const rr of [1.15, 1.22, 1.3]) for (const dr of [1.2, 1.27, 1.34]) grid.push([pm, rr, dr]);
    const pairs = grid.map((p) => {
      const m = econ(...p);
      const runs = Array.from({ length: 15 }, (_, i) => bot(m, 50 + i)).sort((a, b) => a - b);
      return [walkModel(m, 'cheapest').finishMin ?? 300, runs[7]] as const;
    });
    const rank = (xs: number[]) => {
      const r = new Array<number>(xs.length);
      xs.map((v, i) => [v, i] as const).sort((a, b) => a[0] - b[0]).forEach(([, i], k) => (r[i] = k));
      return r;
    };
    const ra = rank(pairs.map((x) => x[0]));
    const rb = rank(pairs.map((x) => x[1]));
    const n = ra.length;
    const spearman = 1 - (6 * ra.reduce((acc, v, i) => acc + (v - rb[i]) ** 2, 0)) / (n * (n * n - 1));
    expect(spearman).toBeGreaterThanOrEqual(0.9);
    const errs = pairs.filter(([m, b]) => m < 300 && b < 300).map(([m, b]) => Math.abs(m - b) / b).sort((a, b) => a - b);
    expect(errs[Math.floor(errs.length / 2)]).toBeLessThan(0.25);
  });
});

/**
 * Paced for the first session (the owner's method): a short first stage, small purchases often, an unlock after stage 3
 * and one after stage 7, a boss at stages 6 and 12, a 15-min session. It passes the strict checks
 */
function paced(): BalanceModel {
  const d = curve.geometric(12, 8, 1.28, true);
  const r = curve.geometric(12, 12, 1.3);
  const boss = (i: number) => i === 5 || i === 11;
  const stages = d.map((difficulty, i) => ({
    id: `s${i + 1}`,
    difficulty: boss(i) ? difficulty * 1.15 : difficulty,
    reward: boss(i) ? r[i] * 2 : r[i],
    minutes: Math.round((0.6 + 0.12 * i) * 100) / 100,
    ...(boss(i) ? { kind: 'boss' as const } : {}),
  }));
  const items = [
    ...['blade', 'armour', 'boots'].flatMap((u, k) => curve.geometric(5, 8 + 6 * k, 1.9).map((cost, l) => ({ id: `${u}-${l + 1}`, cost, mult: 1.15, ...(l ? { requires: `${u}-${l}` } : {}) }))),
    { id: 'hero-ash', cost: 40, mult: 1.25, after: 's3', news: { kind: 'unlock' as const } },
    { id: 'hero-flint', cost: 400, mult: 1.25, after: 's7', news: { kind: 'unlock' as const } },
  ];
  return { start: { power: 10 }, stages, items, measure: 'clear time (s) against the stage', sessionMin: 15 };
}
const ANCHOR = { name: 'clear time', unit: 's', says: 'how long one stage takes a fresh hero' };
const status = (r: ReturnType<typeof solveModel>, name: string) => r.checks.find((c) => c.name === `model: ${name}`)?.status;

describe('the first session, the difficulty shape and the session end (with the anchor)', () => {
  it('a paced campaign passes the strict checks; the markdown has the reward timeline and the session-end hook', () => {
    const r = solveModel(paced(), { anchor: ANCHOR });
    expect(r.strict).toBe(true);
    expect(r.failed).toBe(0);
    for (const n of ['The first reward within a minute', 'A new thing every few minutes at first', 'No two big rewards in the same minute', 'No hard streak', 'Stage time grows steadily', 'The session ends with a goal in reach', 'The meta outlasts the session', 'The power is measured in the anchor'])
      expect(status(r, n), n).toBe('ok');
    expect(r.firstRewardSec).toBeLessThanOrEqual(60);
    expect(r.session).toMatchObject({ minute: 15, from: "the model's sessionMin", cleared: 6, stages: 12, over: false });
    expect(r.markdown).toContain('### The first session');
    expect(r.markdown).toMatch(/\| 12 \| ★ hero-ash \(unlock\) \|/);
    expect(r.markdown).toContain('★ s6 cleared (boss)');
    expect(r.markdown).toMatch(/at minute 15: \S+ \d+ % paid, 6 of 12 stages/);
  });
  it('without the anchor the new checks only warn: a game made before them keeps passing', () => {
    // At minute 12 of this campaign the nearest goal is under 60 % on average over minutes 11–13
    const lenient = solveModel(sane(), { sessionMin: 12 });
    const strict = solveModel(sane(), { sessionMin: 12, anchor: ANCHOR });
    expect(lenient.failed).toBe(0);
    for (const n of ['The first reward within a minute', 'A new thing every few minutes at first', 'No hard streak', 'The session ends with a goal in reach']) {
      expect(status(lenient, n), n).toBe('warn');
      expect(status(strict, n), n).toBe('fail');
    }
    expect(lenient.checks.find((c) => c.name === 'model: No hard streak')!.target).toContain('a warning until game.yaml declares balance.anchor');
    expect(lenient.markdown).toContain('declares no `balance.anchor`');
  });
  it('the first reward: a first stage of 3 minutes is too long', () => {
    const m = paced();
    const r = solveModel({ ...m, start: { power: 10, coins: 0 }, stages: m.stages.map((s, i) => (i === 0 ? { ...s, minutes: 3 } : s)), items: m.items.map((i) => ({ ...i, cost: i.cost * 4 })) }, { anchor: ANCHOR });
    expect(r.firstRewardSec).toBeGreaterThan(60);
    expect(status(r, 'The first reward within a minute')).toBe('fail');
  });
  it('early gaps: a 4-minute stage among the first ten minutes leaves a stretch with nothing new', () => {
    const m = paced();
    const r = solveModel({ ...m, stages: m.stages.map((s, i) => (i === 2 ? { ...s, minutes: 3 } : s)) }, { anchor: ANCHOR });
    expect(status(r, 'A new thing every few minutes at first')).toBe('fail');
    expect(r.checks.find((c) => c.name === 'model: A new thing every few minutes at first')!.detail).toMatch(/from minute 2\.\d/);
  });
  it('two big rewards in the same minute: an unlock bought with the boss\'s coins', () => {
    const m = paced();
    const r = solveModel({ ...m, items: [...m.items, { id: 'hero-coal', cost: 10, mult: 1.2, after: 's6', news: { kind: 'unlock' } }] }, { anchor: ANCHOR });
    expect(status(r, 'No two big rewards in the same minute')).toBe('fail');
    expect(r.checks.find((c) => c.name === 'model: No two big rewards in the same minute')!.detail).toMatch(/s6 \(boss\).*hero-coal \(unlock\)/);
    // A light one is no big reward
    const light = solveModel({ ...m, items: [...m.items, { id: 'hero-coal', cost: 10, mult: 1.2, after: 's6', news: { kind: 'item' } }] }, { anchor: ANCHOR });
    expect(light.checks.find((c) => c.name === 'model: No two big rewards in the same minute')!.detail).not.toContain('hero-coal');
  });
  it("a boss or a breather is a planned peak or dip: the 'rises' check takes it", () => {
    const m = sane();
    const dip = m.stages.map((s, i) => (i === 5 ? { ...s, difficulty: m.stages[4].difficulty * 0.8 } : s));
    expect(status(solveModel({ ...m, stages: dip }), 'Difficulty and reward rise stage by stage')).toBe('warn');
    expect(status(solveModel({ ...m, stages: dip.map((s, i) => (i === 5 ? { ...s, kind: 'breather' as const } : s)) }), 'Difficulty and reward rise stage by stage')).toBe('ok');
    expect(status(solveModel({ ...m, stages: dip.map((s, i) => (i === 4 ? { ...s, kind: 'boss' as const } : s)) }), 'Difficulty and reward rise stage by stage')).toBe('ok');
  });
  it('a hard streak: three stages in a row over 2.5 attempts; a boss among them is left out', () => {
    const m = paced();
    const hard = m.stages.map((s, i) => (i >= 6 && i <= 8 ? { ...s, difficulty: s.difficulty * 1.35 } : s));
    const r = solveModel({ ...m, stages: hard }, { anchor: ANCHOR });
    expect(status(r, 'No hard streak')).toBe('fail');
    expect(r.cheap.stages.slice(6, 9).every((s) => s.attempts! > 2.5)).toBe(true);
    // The same streak broken by a boss in the middle is two stages, not three
    const two = solveModel({ ...m, stages: hard.map((s, i) => (i === 7 ? { ...s, difficulty: m.stages[7].difficulty } : s)) }, { anchor: ANCHOR });
    expect(status(two, 'No hard streak')).toBe('ok');
  });
  it('stage time: a stage that takes over 1.5× the one before fails; a boss may', () => {
    const m = paced();
    const long = m.stages.map((s, i) => (i === 7 ? { ...s, minutes: s.minutes * 2.5 } : s));
    expect(status(solveModel({ ...m, stages: long }, { anchor: ANCHOR }), 'Stage time grows steadily')).toBe('fail');
    expect(status(solveModel({ ...m, stages: long.map((s, i) => (i === 7 ? { ...s, kind: 'boss' as const } : s)) }, { anchor: ANCHOR }), 'Stage time grows steadily')).toBe('ok');
  });
  it('atMinute: what the player has at a minute, and how far the next goal is', () => {
    const s = atMinute(paced(), 15);
    expect(s).toMatchObject({ minute: 15, cleared: 6, stages: 12, stage: 's7', items: 17, over: false });
    expect(s.walkMin).toBeLessThanOrEqual(15);
    expect(s.goal!.share).toBeGreaterThanOrEqual(s.purchase!.share);
    expect(snapshotText(s)).toMatch(/^at minute 15: /);
    expect(atMinute(paced(), 0)).toMatchObject({ cleared: 0, stage: 's1', bought: 0 });
    const end = atMinute(paced(), 999);
    expect(end).toMatchObject({ over: true, cleared: 12, stage: null });
    expect(snapshotText(end)).toContain('the campaign was over');
  });
  it('the session end: goals far off around it fail; money.session.minutes wins over the model; no length skips', () => {
    const m = paced();
    // Every price ×6: around minute 15 the nearest goal is a third of the way
    const far = solveModel({ ...m, items: m.items.map((i) => ({ ...i, cost: i.cost * 6 })) }, { anchor: ANCHOR });
    expect(far.session!.window.mean).toBeLessThan(0.6);
    expect(status(far, 'The session ends with a goal in reach')).toBe('fail');
    expect(far.checks.find((c) => c.name === 'model: The session ends with a goal in reach')!.detail).toMatch(/over minutes 14–16 the nearest goal is \d+ % reached on average/);
    // A goal at half at the very minute, bought a minute later, is a goal in reach: the window sees it coming
    const half = solveModel({ ...m, items: m.items.map((i) => (i.id === 'hero-ash' ? { ...i, cost: 60 } : i)) }, { anchor: ANCHOR });
    expect(half.session!.goal).toMatchObject({ id: 'hero-ash' });
    expect(half.session!.goal!.share).toBeLessThan(0.6);
    expect(half.session!.window.mean).toBeGreaterThanOrEqual(0.6);
    expect(status(half, 'The session ends with a goal in reach')).toBe('ok');
    const yaml = solveModel(m, { anchor: ANCHOR, sessionMin: 12 });
    expect(yaml.session).toMatchObject({ minute: 12, from: 'money.session.minutes' });
    const none = solveModel({ ...m, sessionMin: undefined }, { anchor: ANCHOR });
    expect(status(none, 'The session ends with a goal in reach')).toBe('skip');
    expect(none.session).toBeNull();
  });
  it("the session end reads a window, not an instant: a 0.05-min change of an attempt's length doesn't flip it", () => {
    // Every stage the same length: the instant at minute 15 lands just before or just after a clear or a purchase
    const flat = (len: number): BalanceModel => ({
      start: { power: 10 },
      stages: curve.geometric(30, 10, 1.2, true).map((difficulty, i, d) => ({ id: `s${i + 1}`, difficulty, reward: d[i], minutes: len })),
      items: curve.geometric(12, 30, 1.7).map((cost, l) => ({ id: `w-${l + 1}`, cost, mult: 1.3, ...(l ? { requires: `w-${l}` } : {}) })),
      sessionMin: 15,
    });
    const lens = Array.from({ length: 11 }, (_, k) => 0.8 + k * 0.01);
    const instant = lens.map((len) => atMinute(flat(len), 15).goal!.share);
    // The one instant flips: from about a third to nearly all and back
    expect(Math.min(...instant)).toBeLessThan(0.35);
    expect(Math.max(...instant)).toBeGreaterThan(0.9);
    const means = lens.map((len) => solveModel(flat(len)).session!.window.mean);
    for (let k = 1; k < means.length; k++) expect(Math.abs(means[k] - means[k - 1]), `${lens[k]} min`).toBeLessThan(0.04);
    // The window: from minute 14 to 16, its average between its worst and its best moment
    const w = atMinuteWindow(flat(0.85), 15);
    expect(w).toMatchObject({ from: 14, to: 16 });
    expect(w.worst.goal!.share).toBeLessThanOrEqual(w.mean);
    expect(w.best.goal!.share).toBeGreaterThanOrEqual(w.mean);
    // A narrower window is the target's to set
    expect(solveModel(flat(0.85), { targets: { sessionWindowMin: 0.5 } }).session!.window).toMatchObject({ from: 14.5, to: 15.5 });
  });
  it('the meta lasts 2 sessions; the model and money.meta.minutes more than 25 % apart is a warning', () => {
    const m = paced();
    expect(status(solveModel(m, { anchor: ANCHOR, sessionMin: 30 }), 'The meta outlasts the session')).toBe('fail');
    const off = solveModel(m, { anchor: ANCHOR, metaMin: 30 });
    expect(status(off, "The meta's length agrees with money.meta")).toBe('warn');
    expect(off.failed).toBe(0);
    expect(status(solveModel(m, { anchor: ANCHOR, metaMin: 50 }), "The meta's length agrees with money.meta")).toBe('ok');
  });
  it("the model's measure names the anchor (a word, not a letter of one)", () => {
    expect(status(solveModel(sane(), { anchor: { name: 'clear time', unit: 's' } }), 'The power is measured in the anchor')).toBe('warn');
    expect(status(solveModel(sane(), { anchor: { name: 'damage', unit: 'HP' } }), 'The power is measured in the anchor')).toBe('ok');
    expect(status(solveModel(sane()), 'The power is measured in the anchor')).toBeUndefined();
  });
});
