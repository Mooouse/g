// Dice: seeded rolls, rerolls as a resource, faces forged, slots with rules, exact odds for the hints — and a dice
// placement turn (a Sky Team-style landing) played the way a game would.

import { describe, expect, it } from 'vitest';
import { D6, Dice, EXACT_ODDS_MAX, oddsOf, slotRules, sumIs, sumOdds, type DiceState } from '../src/dice.ts';
import { UndoHistory } from '../src/undo.ts';

describe('Dice: rolls', () => {
  it('seeded: the same seed rolls the same faces; placed and held dice stay', () => {
    const tray = new Dice({ slots: [{ id: 'a' }] });
    const s = tray.roll(tray.start([D6, D6, D6, D6], 12));
    expect(tray.roll(tray.start([D6, D6, D6, D6], 12))).toEqual(s);
    expect(tray.values(s).every((v) => v !== null && v >= 1 && v <= 6)).toBe(true);
    const placed = tray.hold(tray.place(s, 0, 'a')!, 1);
    const again = tray.roll(placed);
    expect(tray.value(again, 0)).toBe(tray.value(s, 0));
    expect(tray.value(again, 1)).toBe(tray.value(s, 1));
    expect(again.rng).not.toBe(placed.rng);
  });

  it('rerolls are a limited resource; a rewarded ad adds one', () => {
    const tray = new Dice();
    let s = tray.roll(tray.start([D6, D6], 3, { rerolls: 1 }));
    const r1 = tray.reroll(s, [0])!;
    expect(r1.rerolls).toBe(0);
    expect(tray.value(r1, 1)).toBe(tray.value(s, 1));
    expect(tray.reroll(r1, [0])).toBeNull();
    s = tray.addRerolls(r1);
    expect(tray.reroll(s, [0, 1])).not.toBeNull();
    expect(tray.reroll(s, [])).toBeNull();
  });

  it('faces can be rewritten for good (forge) or turned (a bump card)', () => {
    const tray = new Dice();
    let s = tray.start([D6], 1);
    s = tray.forge(s, 0, 0, 6)!; // the 1 becomes a second 6
    expect(s.dice[0].faces).toEqual([6, 2, 3, 4, 5, 6]);
    expect(tray.chance(s, 0, (f) => f === 6)).toBeCloseTo(2 / 6, 10);
    s = tray.setFace(s, 0, 3)!;
    expect(tray.value(s, 0)).toBe(4);
    expect(tray.forge(s, 0, 9, 1)).toBeNull();
    // faces may be words: a Dicey Dungeons sword die
    const words = new Dice<string>();
    const w = words.roll(words.start([['sword', 'sword', 'shield', 'skull']], 5));
    expect(['sword', 'shield', 'skull']).toContain(words.value(w, 0));
  });
});

describe('Dice: odds for the hints', () => {
  it('the sum of 2d6 exactly; a pair in 2d6 is 1/6', () => {
    const d = sumOdds([D6, D6]);
    expect(d.get(7)).toBeCloseTo(6 / 36, 12);
    expect(d.get(2)).toBeCloseTo(1 / 36, 12);
    expect([...d.values()].reduce((a, b) => a + b, 0)).toBeCloseTo(1, 12);
    expect(oddsOf([D6, D6], ([a, b]) => a === b)).toBeCloseTo(1 / 6, 12);
  });

  it('after a reroll: keep the 6 and reroll the 1 — 1/6 for a pair of sixes, what the reroll button says', () => {
    const tray = new Dice();
    let s = tray.start([D6, D6], 1);
    s = tray.setFace(tray.setFace(s, 0, 5)!, 1, 0)!; // a 6 and a 1
    expect(tray.chanceAfterReroll(s, [1], (v) => v[0] === 6 && v[1] === 6)).toBeCloseTo(1 / 6, 12);
    expect(tray.chanceAfterReroll(s, [0, 1], (v) => v[0] === 6 && v[1] === 6)).toBeCloseTo(1 / 36, 12);
    expect(tray.chanceAfterReroll(s, [], (v) => v[0] + v[1] === 7)).toBe(1);
  });

  it('big pools are sampled (seeded: the same number every time) and land near the exact answer', () => {
    const pools = Array.from({ length: 8 }, () => D6);
    expect(6 ** 8).toBeGreaterThan(EXACT_ODDS_MAX);
    const exact = [...sumOdds(pools)].filter(([s]) => s >= 30).reduce((a, [, p]) => a + p, 0);
    const sampled = oddsOf(pools, (v) => v.reduce((a, b) => a + b, 0) >= 30);
    expect(oddsOf(pools, (v) => v.reduce((a, b) => a + b, 0) >= 30)).toBe(sampled);
    expect(Math.abs(sampled - exact)).toBeLessThan(0.015);
  });
});

// --- A landing turn (Sky Team, solo): four dice, the slots of the cockpit ----------------------------------------------

const cockpit = () =>
  new Dice({
    slots: [
      // the engines take two dice whose sum is the speed: exactly 8 to keep the approach
      { id: 'engines', size: 2, accepts: slotRules.sum(8), done: sumIs(8) },
      { id: 'gear', accepts: slotRules.atMost(2) },
      { id: 'flaps', accepts: slotRules.atLeast(4) },
      { id: 'brakes', size: 2, accepts: slotRules.same() },
    ],
  });

describe('Dice: a placement turn', () => {
  it('slots take dice by their rules; the legal moves feed the hint; undo is an UndoHistory', () => {
    const tray = cockpit();
    let s = tray.start([D6, D6, D6, D6], 1, { rerolls: 1 });
    // set the roll by hand: 5, 3, 2, 5
    for (const [i, f] of [[0, 4], [1, 2], [2, 1], [3, 4]] as const) s = tray.setFace(s, i, f)!;
    expect(tray.values(s)).toEqual([5, 3, 2, 5]);
    expect(tray.canPlace(s, 0, 'gear')).toBe(false);
    expect(tray.canPlace(s, 2, 'gear')).toBe(true);
    const h = new UndoHistory<DiceState>(s);
    h.push(tray.place(h.current, 0, 'engines')!);
    expect(tray.done(h.current, 'engines')).toBe(false);
    expect(tray.canPlace(h.current, 3, 'engines')).toBe(false); // 5 + 5 > 8
    h.push(tray.place(h.current, 1, 'engines')!);
    expect(tray.done(h.current, 'engines')).toBe(true);
    expect(tray.placements(h.current)).toEqual([
      { die: 2, slot: 'gear' },
      { die: 2, slot: 'brakes' },
      { die: 3, slot: 'flaps' },
      { die: 3, slot: 'brakes' },
    ]);
    h.push(tray.place(h.current, 3, 'brakes')!);
    expect(tray.canPlace(h.current, 2, 'brakes')).toBe(false); // a pair: 5 and 2 aren't one
    h.undo();
    expect(tray.inSlot(h.current, 'brakes')).toEqual([]);
    expect(tray.free(h.current)).toEqual([2, 3]);
    // placed dice don't reroll
    const rr = tray.reroll(h.current, [0, 2])!;
    expect(tray.values(rr).slice(0, 2)).toEqual([5, 3]);
    expect(tray.unplace(rr, 0)!.dice[0].slot).toBeNull();
  });

  it("a bot's turn: roll, place the best legal die, reroll when stuck — the same seed lands the same way", () => {
    const tray = cockpit();
    const turn = (seed: number): string => {
      let s = tray.roll(tray.start([D6, D6, D6, D6], seed, { rerolls: 2 }));
      for (let step = 0; step < 12; step++) {
        const moves = tray.placements(s);
        if (moves.length) {
          // the engines first (the approach), then whatever fits
          const m = moves.find((x) => x.slot === 'engines') ?? moves[0];
          s = tray.place(s, m.die, m.slot)!;
          continue;
        }
        const free = tray.free(s);
        const next = free.length ? tray.reroll(s, free) : null;
        if (!next) break;
        s = next;
      }
      return tray.slots.map((sl) => `${sl.id}:${tray.inSlot(s, sl.id).map((i) => tray.value(s, i)).join('+')}${tray.done(s, sl.id) ? '✓' : ''}`).join(' ');
    };
    expect(turn(2026)).toBe(turn(2026));
    const runs = new Set(Array.from({ length: 20 }, (_, i) => turn(i)));
    expect(runs.size).toBeGreaterThan(5);
  });

  it('a save (JSON) loads safe and rolls on the same', () => {
    const tray = cockpit();
    const s = tray.place(tray.roll(tray.start([D6, D6, D6], 8, { rerolls: 2 })), 0, 'brakes')!;
    const loaded = tray.sanitize(JSON.parse(JSON.stringify(s)));
    expect(loaded).toEqual(s);
    expect(tray.roll(loaded)).toEqual(tray.roll(s));
    const junk = tray.sanitize({ dice: [{ faces: [], up: 0 }, { faces: [1, 2, 'x', null], up: 7, slot: 'nowhere' }, { faces: D6, up: 2, slot: 'gear' }, { faces: D6, up: 1, slot: 'gear' }], rerolls: -1, rng: 'q' }, undefined, 4);
    expect(junk).toEqual({
      dice: [
        { faces: [1, 2, 'x'], up: null, slot: null, held: false },
        { faces: D6, up: 2, slot: 'gear', held: false },
        { faces: D6, up: 1, slot: null, held: false },
      ],
      rerolls: 0,
      rng: 4,
    });
  });

  it('rejects broken slots', () => {
    expect(() => new Dice({ slots: [{ id: 'a' }, { id: 'a' }] })).toThrow();
    expect(() => new Dice({ slots: [{ id: 'a', size: 0 }] })).toThrow();
    expect(() => new Dice().start([[]], 1)).toThrow();
  });
});
