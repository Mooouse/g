import { describe, expect, it } from 'vitest';
import { GOLDEN_ANGLE, add, around, arrive, avoid, flank, flee, integrate, predict, pursue, seek, separation, slot, truncate, type Mover } from '../src/steer.ts';

const m = (x: number, y: number, vx = 0, vy = 0, r = 0.5): Mover => ({ x, y, vx, vy, r });
const len = (v: { x: number; y: number }) => Math.hypot(v.x, v.y);

/** Run a mover for `sec` at 60 steps a second under a force function */
function run(a: Mover, sec: number, force: (a: Mover) => { x: number; y: number }, speed: number, maxForce = speed * 6): Mover {
  for (let i = 0; i < sec * 60; i++) {
    integrate(a, force(a), 1 / 60, speed, maxForce);
    a.x += a.vx / 60;
    a.y += a.vy / 60;
  }
  return a;
}

describe('@gp/core/steer', () => {
  it('seek points at the target at full speed; flee away, and nothing past its panic distance', () => {
    const f = seek(m(0, 0), { x: 10, y: 0 }, 4);
    expect(f).toEqual({ x: 4, y: 0 });
    expect(flee(m(0, 0), { x: 10, y: 0 }, 4)).toEqual({ x: -4, y: 0 });
    expect(flee(m(0, 0), { x: 10, y: 0 }, 4, 5)).toEqual({ x: 0, y: 0 });
    // On top of the threat: away along the heading, never NaN
    const o = flee(m(1, 1, 0, 2), { x: 1, y: 1 }, 3);
    expect(Number.isFinite(o.x) && Number.isFinite(o.y)).toBe(true);
    expect(o.y).toBeCloseTo(1);
  });

  it('arrive, weighted ≈ 4 × maxSpeed / slow, stops on the point instead of swaying round it', () => {
    const w = (4 * 4) / 2.2;
    const a = run(m(0, 0), 6, (a) => add({ x: 0, y: 0 }, arrive(a, { x: 8, y: 3 }, 4, 2.2), w), 4, 60);
    expect(Math.hypot(a.x - 8, a.y - 3)).toBeLessThan(0.05);
    expect(Math.hypot(a.vx, a.vy)).toBeLessThan(0.1);
  });

  it('pursuit leads a moving prey: it aims where the prey will be and catches it sooner than seek', () => {
    const prey = m(10, 0, 0, 2);
    const p = predict(m(0, 0), prey, 4, 1);
    expect(p.y).toBeGreaterThan(0);
    expect(p.x).toBe(10);
    // The lead is capped (default 2 s)
    expect(predict(m(0, 0), m(1000, 0, 0, 1), 1, 1).y).toBe(2);
    const catchTime = (lead: boolean) => {
      const a = m(0, 0);
      const b = m(10, 0, 0, 2);
      for (let i = 0; i < 600; i++) {
        integrate(a, lead ? pursue(a, b, 4, 1) : seek(a, b, 4), 1 / 60, 4, 24);
        a.x += a.vx / 60;
        a.y += a.vy / 60;
        b.y += b.vy / 60;
        if (Math.hypot(a.x - b.x, a.y - b.y) < 0.5) return i;
      }
      return Infinity;
    };
    expect(catchTime(true)).toBeLessThan(catchTime(false));
  });

  it('separation pushes away from close neighbours only, harder the closer; two on one spot part by id', () => {
    const me = m(0, 0);
    expect(separation(me, [me, m(5, 0)], 2)).toEqual({ x: 0, y: 0 });
    const near = separation(me, [m(0.5, 0)], 2);
    const far = separation(me, [m(1.5, 0)], 2);
    expect(near.x).toBeLessThan(far.x);
    expect(far.x).toBeLessThan(0);
    const a = { ...m(1, 1), id: 1 };
    const b = { ...m(1, 1), id: 2 };
    expect(separation(a, [b], 1).x).toBeLessThan(0);
    expect(separation(b, [a], 1).x).toBeGreaterThan(0);
  });

  it('avoid steers round a pillar in the way and never touches it; ignores what is behind or off to the side', () => {
    const pillar = { x: 6, y: 0.2, r: 1 };
    expect(len(avoid(m(0, 0, 3, 0), [{ x: -5, y: 0, r: 1 }, { x: 4, y: 6, r: 1 }], 2.5, 3))).toBe(0);
    expect(len(avoid(m(0, 0), [pillar], 2.5, 3))).toBe(0);
    const f = avoid(m(0, 0, 3, 0), [pillar], 2.5, 3);
    // The pillar is a little to the left (+y): pushed right (−y), and braked
    expect(f.y).toBeLessThan(0);
    expect(f.x).toBeLessThan(0);
    // Seek a goal behind the pillar with avoidance, Frankengun's weights (3 to 1): it goes round without touching it
    let minGap = Infinity;
    const a = run(m(0, 0, 3, 0), 6, (a) => {
      minGap = Math.min(minGap, Math.hypot(a.x - pillar.x, a.y - pillar.y) - pillar.r - (a.r ?? 0));
      return add(add({ x: 0, y: 0 }, avoid(a, [pillar], 2.5, 3), 3), seek(a, { x: 30, y: 0 }, 3));
    }, 3, 18);
    expect(a.x).toBeGreaterThan(12);
    expect(minGap).toBeGreaterThan(0);
  });

  it('slots spread ids round a target by the golden angle; around() puts them on it', () => {
    const s0 = slot(0, 2);
    expect(s0.x).toBeCloseTo(2);
    const s1 = slot(1, 2);
    expect(Math.atan2(s1.y, s1.x)).toBeCloseTo(GOLDEN_ANGLE);
    // 12 ids: no two closer than a sixth of the circle's spacing
    const pts = Array.from({ length: 12 }, (_, i) => slot(i, 2));
    for (let i = 0; i < 12; i++) for (let j = i + 1; j < 12; j++) expect(Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y)).toBeGreaterThan(0.3);
    expect(around({ x: 5, y: 5 }, s0)).toEqual({ x: 7, y: 5 });
  });

  it('flank is beside the target on the side it is not looking at', () => {
    // Facing +x: the left side is +y
    const l = flank({ x: 0, y: 0 }, 0, 5, 1, 0);
    expect(l.x).toBeCloseTo(0);
    expect(l.y).toBeCloseTo(5);
    const r = flank({ x: 0, y: 0 }, 0, 5, -1, 0.5);
    expect(r.y).toBeLessThan(0);
    expect(r.x).toBeLessThan(0); // half way behind
    expect(Math.hypot(r.x, r.y)).toBeCloseTo(5);
  });

  it('integrate cuts the force and the speed; truncate cuts a vector; everything is deterministic', () => {
    const a = m(0, 0);
    integrate(a, { x: 1000, y: 0 }, 1, 3, 10);
    expect(a.vx).toBe(3);
    expect(truncate({ x: 3, y: 4 }, 1)).toEqual({ x: 0.6, y: 0.8 });
    const once = () => run(m(0, 0, 1, 1), 3, (a) => add(pursue(a, m(5, 5, -1, 0), 3, 0.6), separation(a, [m(1, 1)], 2), 1.6), 3);
    expect(once()).toEqual(once());
  });
});
