import { describe, expect, it } from 'vitest';
import { collection, loadCollection, type CollectionEntry } from '../src/collection.ts';

const MATS = ['wood', 'stone', 'iron'];
const ENTRIES: CollectionEntry[] = MATS.flatMap((m, i) =>
  [1, 2, 3, 4].map((l) => ({ id: `${m}:${l}`, group: 'picks', row: m, rarity: l === 4 ? ('epic' as const) : ('common' as const), bonus: 0.01 * (i + 1) })),
);

describe('collection', () => {
  it('finds once (true when new), saves at once, counts by group and row, adds up the permanent bonus', () => {
    const save: Record<string, unknown> = {};
    let saves = 0;
    const c = collection(save, { entries: [...ENTRIES, { id: 'gold-crown', group: 'secrets', secret: true, bonus: 0.1 }], now: () => 5, persist: () => saves++ });
    expect(c.find('wood:1')).toBe(true);
    expect(c.find('wood:1')).toBe(false);
    expect(c.find('nope')).toBe(false);
    expect(saves).toBe(1);
    expect(c.findAll(['stone:2', 'wood:1', 'iron:4'])).toEqual(['stone:2', 'iron:4']);
    expect(saves).toBe(2);
    const st = c.state();
    expect(st).toMatchObject({ found: 3, total: 13, newCount: 3 });
    expect(st.groups.map((g) => [g.id, g.found, g.total])).toEqual([
      ['picks', 3, 12],
      ['secrets', 0, 1],
    ]);
    expect(st.groups[0].rows.map((r) => [r.id, r.found, r.cells.length])).toEqual([
      ['wood', 1, 4],
      ['stone', 1, 4],
      ['iron', 1, 4],
    ]);
    expect(st.groups[1].rows[0].cells[0]).toMatchObject({ id: 'gold-crown', found: false, secret: true });
    expect(c.bonus()).toBeCloseTo(0.01 + 0.02 + 0.03);
    expect(save.collection).toMatchObject({ found: { 'wood:1': 5, 'stone:2': 5, 'iron:4': 5 }, seen: [] });
  });

  it('a "new" mark stays until seen; markSeen() with no ids clears every one', () => {
    const c = collection({}, { entries: ENTRIES });
    c.findAll(['wood:1', 'wood:2']);
    expect(c.isNew('wood:1')).toBe(true);
    c.markSeen(['wood:1', 'iron:3']);
    expect(c.isNew('wood:1')).toBe(false);
    expect(c.isNew('wood:2')).toBe(true);
    c.markSeen();
    expect(c.state().newCount).toBe(0);
  });

  it('groups and rows keep the order the game gives; an old plain list loads as found and seen', () => {
    const c = collection({ collection: ['iron:1', 'bogus'] }, { entries: ENTRIES, groups: [{ id: 'picks', rows: ['iron', 'wood', 'stone'] }] });
    expect(c.state().groups[0].rows.map((r) => r.id)).toEqual(['iron', 'wood', 'stone']);
    expect(c.has('iron:1')).toBe(true);
    expect(c.isNew('iron:1')).toBe(false);
    // An id the game no longer has stays in the save, out of the count
    expect(c.state().found).toBe(1);
    expect(c.log.found).toHaveProperty('bogus');
    expect(loadCollection({ found: { a: 'x' }, seen: ['a', 'b', 3] })).toEqual({ found: { a: 0 }, seen: ['a'] });
    expect(() => collection({}, { entries: [ENTRIES[0], ENTRIES[0]] })).toThrow(/twice/);
  });
});
