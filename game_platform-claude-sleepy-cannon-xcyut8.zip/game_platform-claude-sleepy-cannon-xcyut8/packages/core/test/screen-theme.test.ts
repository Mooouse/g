import { describe, expect, it } from 'vitest';
import { FONT_FALLBACK } from '../src/i18n.ts';
import { SCREEN_THEME_VARS, screenThemeCss, screenThemeVars } from '../src/screen-theme.ts';

/** The runtime's sources as text (Vite's ?raw) */
const SOURCES = import.meta.glob('../src/*.ts', { query: '?raw', import: 'default', eager: true }) as Record<string, string>;

describe('screenTheme', () => {
  it('maps the fields to --gp-theme-*: px for a number radius, the fallbacks after a family, nothing for what is left out', () => {
    const v = screenThemeVars({ bg: '#140c2a', accentInk: '#fff', radius: 16, font: '"Nunito Black"', display: `"Dela Gothic One", ${FONT_FALLBACK}` });
    expect(v).toEqual({
      '--gp-theme-bg': '#140c2a',
      '--gp-theme-accent-ink': '#fff',
      '--gp-theme-radius': '16px',
      '--gp-theme-font': `"Nunito Black", ${FONT_FALLBACK}`,
      // a stack that has the fallbacks already keeps them once
      '--gp-theme-display': `"Dela Gothic One", ${FONT_FALLBACK}`,
    });
    expect(screenThemeCss({ accent: '#ff4fd8' })).toBe(':root { --gp-theme-accent: #ff4fd8; }');
    expect(screenThemeCss({ ink: '#eee' }, '#ui')).toBe('#ui { --gp-theme-ink: #eee; }');
  });

  // Every platform screen falls back to the theme: each default of its own variables reads a --gp-theme-* first, so
  // one screenTheme() call dresses them all (a screen added later must do the same)
  const SCREENS: Record<string, string> = {
    'results-ui.ts': 'results',
    'welcome.ts': 'welcome',
    'lang-picker.ts': 'lang',
    'streak-ui.ts': 'streak',
    'dialogue-ui.ts': 'dlg',
    'season-ui.ts': 'season',
    'shop-ui.ts': 'shop',
    'sites-map.ts': 'sites',
    'hints.ts': 'hint',
  };
  /** Variables that keep their own look on purpose: a locked pin's grey, the hint's pill shape */
  const OWN = new Set(['--gp-sites-locked', '--gp-hint-radius']);
  const theme = new Set(Object.values(SCREEN_THEME_VARS));

  for (const [file, ns] of Object.entries(SCREENS)) {
    it(`${file}: every --gp-${ns}-* default falls back to a --gp-theme-* variable`, () => {
      // The screen's style sheet: the CSS template literal
      const src = SOURCES[`../src/${file}`].match(/const CSS = `([\s\S]*?)`;/)?.[1] ?? '';
      const decl = [...src.matchAll(new RegExp(`(--gp-${ns}-[a-z0-9-]+):\\s*([^;]+);`, 'g'))];
      expect(decl.length, file).toBeGreaterThan(3);
      for (const [, name, value] of decl) {
        if (OWN.has(name)) continue;
        const used = [...value.matchAll(/var\((--gp-theme-[a-z0-9-]+)/g)].map((m) => m[1]);
        expect(used.length, `${name}: ${value}`).toBeGreaterThan(0);
        for (const u of used) expect(theme.has(u), `${name} → ${u}`).toBe(true);
      }
    });
  }
});
