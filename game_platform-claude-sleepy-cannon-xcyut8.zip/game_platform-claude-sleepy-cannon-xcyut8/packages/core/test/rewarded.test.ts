import { describe, expect, it, vi } from 'vitest';
import { AdManager, REWARDED_INPUT_WINDOW_SEC, type AdProvider } from '../src/ads.ts';
import type { AdPolicy } from '../src/ads-policy.ts';

const POLICY: AdPolicy = { noAdsAfterLaunchSec: 60, firstAdAfterRound: 1, everyRounds: 1, minIntervalSec: 180, maxAdWaitSec: 60, testAdCloseSec: 3 };

function setup(opts: { rewarded?: boolean; result?: boolean | 'off'; hasRewarded?: boolean } = {}) {
  let now = 100;
  const shown: string[] = [];
  const provider: AdProvider = {
    name: 'fake',
    init: async () => {},
    preload: () => {},
    show: async () => (shown.push('midgame'), true),
    ...(opts.hasRewarded === false ? {} : { showRewarded: async () => (shown.push('rewarded'), opts.result ?? true) }),
  };
  const hooks = { onStart: vi.fn(), onEnd: vi.fn() };
  const ads = new AdManager(provider, POLICY, () => false, hooks, () => now, opts.rewarded ?? true);
  return { ads, shown, hooks, setNow: (t: number) => (now = t) };
}

describe('rewarded ads', () => {
  it('shows right after the player tapped and reports the result', async () => {
    const { ads, shown, hooks } = setup();
    expect(await ads.rewarded(99.5)).toBe(true);
    expect(shown).toEqual(['rewarded']);
    expect(hooks.onStart).toHaveBeenCalledOnce();
    expect(hooks.onEnd).toHaveBeenCalledWith(true);
  });

  it('an ad that is off for the session (Basic Launch, ad blocker) stops the offers at once', async () => {
    const { ads, shown } = setup({ result: 'off' });
    expect(ads.rewardedAvailable).toBe(true);
    expect(await ads.rewarded(100)).toBe(false);
    expect(ads.rewardedAvailable).toBe(false);
    expect(await ads.rewarded(100)).toBe(false);
    expect(shown).toEqual(['rewarded']); // the second request never reached the provider
  });

  it('one skipped or unfilled ad keeps the offers; two failures in a row stop them; a watched one resets', async () => {
    const { ads } = setup({ result: false });
    expect(await ads.rewarded(100)).toBe(false);
    expect(ads.rewardedAvailable).toBe(true);
    expect(await ads.rewarded(100)).toBe(false);
    expect(ads.rewardedAvailable).toBe(false);
  });

  it('a refused request (no tap) does not count as a failed ad', async () => {
    const err = vi.spyOn(console, 'error').mockImplementation(() => {});
    const { ads } = setup();
    expect(await ads.rewarded(null)).toBe(false);
    expect(ads.rewardedAvailable).toBe(true);
    err.mockRestore();
  });

  it('refuses without a recent player input', async () => {
    const err = vi.spyOn(console, 'error').mockImplementation(() => {});
    const { ads, shown } = setup();
    expect(await ads.rewarded(null)).toBe(false);
    expect(await ads.rewarded(100 - REWARDED_INPUT_WINDOW_SEC - 0.1)).toBe(false);
    expect(shown).toEqual([]);
    expect(err).toHaveBeenCalled();
    err.mockRestore();
  });

  it('is off when the channel does not allow it or the provider has none', async () => {
    expect(setup({ rewarded: false }).ads.rewardedEnabled).toBe(false);
    expect(await setup({ rewarded: false }).ads.rewarded(100)).toBe(false);
    expect(setup({ hasRewarded: false }).ads.rewardedEnabled).toBe(false);
  });

  it('does not touch the midgame limits', async () => {
    const { ads } = setup();
    await ads.rewarded(100);
    expect(ads.state.lastAdSec).toBeNull();
    expect(ads.state.roundsSinceAd).toBe(0);
  });
});

describe('one ad at a time (a double click must not start a second ad)', () => {
  function slow() {
    let now = 1000;
    const shown: string[] = [];
    let release: () => void = () => {};
    const gate = () => new Promise<boolean>((r) => (release = () => r(true)));
    const provider: AdProvider = {
      name: 'slow',
      init: async () => {},
      preload: () => {},
      show: () => (shown.push('midgame'), gate()),
      showRewarded: () => (shown.push('rewarded'), gate()),
    };
    const hooks = { onStart: vi.fn(), onEnd: vi.fn() };
    const ads = new AdManager(provider, { ...POLICY, noAdsAfterLaunchSec: 0, firstAdAfterRound: 0 }, () => false, hooks, () => now, true);
    return { ads, shown, hooks, release: () => release(), setNow: (t: number) => (now = t) };
  }

  it('a second rewarded request while one plays is refused at once', async () => {
    const { ads, shown, hooks, release } = slow();
    const first = ads.rewarded(1000);
    await Promise.resolve();
    expect(await ads.rewarded(1000)).toBe(false);
    expect(ads.adPending).toBe(true);
    release();
    expect(await first).toBe(true);
    expect(shown).toEqual(['rewarded']);
    expect(hooks.onStart).toHaveBeenCalledOnce();
    expect(hooks.onEnd).toHaveBeenCalledOnce();
    expect(ads.adPending).toBe(false);
  });

  it('no midgame ad while a rewarded one plays, and no second midgame during the first', async () => {
    const { ads, shown, release } = slow();
    const r = ads.rewarded(1000);
    await Promise.resolve();
    await ads.naturalBreak();
    expect(shown).toEqual(['rewarded']);
    release();
    await r;
    ads.countRound();
    const m1 = ads.naturalBreak();
    await Promise.resolve();
    await ads.naturalBreak();
    release();
    await m1;
    expect(shown).toEqual(['rewarded', 'midgame']);
  });
});

// Engine lab (game12 REPORT, "Friction"): adPending cleared only after onEnd, so a game that re-enabled its buttons on the
// host's resume (which onEnd triggers) still saw an ad pending and kept them locked for good after a failed ad
describe('the ad is over before onEnd runs', () => {
  function seen(result: boolean | 'off', fail = false) {
    const at: { pending: boolean; available?: boolean; lastAdSec?: number | null }[] = [];
    const provider: AdProvider = {
      name: 'fake',
      init: async () => {},
      preload: () => {},
      show: async () => {
        if (fail) throw new Error('no fill');
        return result === true;
      },
      showRewarded: async () => {
        if (fail) throw new Error('no fill');
        return result;
      },
    };
    let ads: AdManager | null = null;
    const hooks = { onStart: () => {}, onEnd: () => at.push({ pending: ads!.adPending, available: ads!.rewardedAvailable, lastAdSec: ads!.state.lastAdSec }) };
    ads = new AdManager(provider, { ...POLICY, noAdsAfterLaunchSec: 0, firstAdAfterRound: 0 }, () => false, hooks, () => 1000, true);
    return { ads, at };
  }

  it('rewarded: adPending is false in onEnd, also after a failed ad, and rewardedAvailable is already updated', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    for (const [result, fail] of [[true, false], [false, false], [false, true]] as const) {
      const { ads, at } = seen(result, fail);
      await ads.rewarded(1000);
      expect(at).toEqual([{ pending: false, available: true, lastAdSec: null }]);
    }
    const off = seen('off');
    await off.ads.rewarded(1000);
    expect(off.at[0]).toMatchObject({ pending: false, available: false });
    warn.mockRestore();
  });

  it('midgame: adPending is false in onEnd and the shown ad already counts for the limits; a resume can start the next break', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const { ads, at } = seen(true);
    ads.countRound();
    await ads.naturalBreak();
    expect(at).toEqual([{ pending: false, available: true, lastAdSec: 1000 }]);
    const failed = seen(true, true);
    failed.ads.countRound();
    await failed.ads.naturalBreak();
    expect(failed.at).toEqual([{ pending: false, available: true, lastAdSec: null }]);
    warn.mockRestore();
  });
});

describe('onPending: the request to the end (the code host makes the UI inert meanwhile)', () => {
  it('true at the request (synchronously, before the provider loads), false before onEnd; never for a refused one', async () => {
    const order: string[] = [];
    const provider: AdProvider = { name: 'fake', init: async () => {}, preload: () => {}, show: async () => true, showRewarded: async () => true };
    const hooks = { onStart: () => order.push('start'), onEnd: () => order.push('end'), onPending: (p: boolean) => order.push(`pending:${p}`) };
    let now = 1000;
    const ads = new AdManager(provider, POLICY, () => false, hooks, () => now, true);
    const r = ads.rewarded(999.5);
    expect(order).toEqual(['pending:true']);
    await r;
    expect(order).toEqual(['pending:true', 'start', 'pending:false', 'end']);
    order.length = 0;
    const err = vi.spyOn(console, 'error').mockImplementation(() => {});
    await ads.rewarded(null);
    err.mockRestore();
    expect(order).toEqual([]);
    now += 3600;
    ads.countRound();
    await ads.naturalBreak();
    expect(order).toEqual(['pending:true', 'start', 'pending:false', 'end']);
  });
});
