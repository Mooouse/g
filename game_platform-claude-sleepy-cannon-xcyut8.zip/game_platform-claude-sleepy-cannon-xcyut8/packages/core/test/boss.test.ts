import { describe, expect, it } from 'vitest';
import { BossPatterns, aimAt, aimed, fan, intercept, ring, spiral, wave, type BossEvent } from '../src/boss.ts';
import { seededRng } from '../src/rng.ts';

const ATTACKS = {
  fan: { telegraph: 0.6, duration: 2.4 },
  ring: { telegraph: 0.8, duration: 2.4 },
  summon: { telegraph: 0.3, duration: 1.6, weight: 2 },
  charge: { telegraph: 0.55, duration: 1.2, recover: 1 },
  slam: { telegraph: 1, duration: 0.5 },
};
const PHASES = [
  { at: 1, attacks: ['fan', 'ring', 'summon'] },
  { at: 0.5, attacks: ['fan', 'ring', 'summon', 'charge'], speed: 1.25, opener: 'slam' },
  { at: 0.25, attacks: ['fan', 'charge'], speed: 1.5 },
];

/** Fight for `sec` at 60 steps, health from `hp(t)`; every event with its time */
function fight(seed: number, sec: number, hp: (t: number) => number = () => 1) {
  const b = new BossPatterns({ attacks: ATTACKS, phases: PHASES, rng: seededRng(seed), intro: 1 });
  const log: (BossEvent & { at: number })[] = [];
  for (let i = 0; i < sec * 60; i++) for (const e of b.step(1 / 60, hp(i / 60))) log.push({ ...e, at: i / 60 });
  return { b, log };
}

describe('BossPatterns', () => {
  it('waits out the intro, then telegraph → attack → recover, with the attack\'s durations', () => {
    const { log } = fight(3, 8);
    const first = log[0];
    expect(first.type).toBe('telegraph');
    expect(first.at).toBeCloseTo(1, 1);
    const a = ATTACKS[(first as { attack: keyof typeof ATTACKS }).attack];
    expect(log[1]).toMatchObject({ type: 'attack', attack: (first as { attack: string }).attack });
    expect(log[1].at - first.at).toBeCloseTo(a.telegraph, 1);
    expect(log[2].type).toBe('recover');
    expect(log[2].at - log[1].at).toBeCloseTo(a.duration, 1);
  });

  it('never plays the same attack twice in a row, over many seeds (a weight-2 attack included)', () => {
    for (let seed = 1; seed <= 40; seed++) {
      const { b } = fight(seed, 120, (t) => (t < 50 ? 1 : t < 90 ? 0.4 : 0.2));
      expect(b.history.length).toBeGreaterThan(20);
      for (let i = 1; i < b.history.length; i++) expect(b.history[i], `seed ${seed} #${i}: ${b.history.slice(i - 2, i + 1)}`).not.toBe(b.history[i - 1]);
    }
  });

  it('the deck plays every attack of the phase before any comes round again, weights counted', () => {
    const { b } = fight(9, 60);
    // Rounds of the deck: fan, ring, summon ×2 → 4 draws a round
    const round = b.history.slice(0, 4).sort();
    expect(round).toEqual(['fan', 'ring', 'summon', 'summon']);
  });

  it('a health threshold starts the next phase at once: the attack is cut, a rest, then the phase\'s opener and its tempo', () => {
    const { b, log } = fight(5, 20, (t) => (t < 6 ? 1 : 0.45));
    const ph = log.findIndex((e) => e.type === 'phase');
    expect(log[ph]).toMatchObject({ type: 'phase', phase: 1, from: 0 });
    expect(log[ph].at).toBeCloseTo(6, 1);
    expect(log[ph + 1]).toMatchObject({ type: 'recover', attack: null, sec: 0.8 });
    expect(log[ph + 2]).toMatchObject({ type: 'telegraph', attack: 'slam' });
    // Phase 2's tempo: the slam's telegraph 1 s / 1.25
    expect((log[ph + 2] as { sec: number }).sec).toBeCloseTo(0.8);
    expect(b.speed).toBe(1.25);
    expect(b.history.slice(b.history.indexOf('slam') + 1)).toContain('charge');
  });

  it('a big hit past two thresholds reports both phases, in order', () => {
    const { log } = fight(5, 5, (t) => (t < 2 ? 1 : 0.1));
    expect(log.filter((e) => e.type === 'phase').map((e) => (e as { phase: number }).phase)).toEqual([1, 2]);
  });

  it('every() is true once per period of the state\'s time; is() names the landing attack', () => {
    const b = new BossPatterns({ attacks: { fan: { telegraph: 0, duration: 3 } }, phases: [{ at: 1, attacks: ['fan'] }], rng: () => 0.5, intro: 0 });
    let shots = 0;
    for (let i = 0; i < 180; i++) {
      b.step(1 / 60, 1);
      if (b.is('fan') && b.every(0.5)) shots++;
    }
    expect(shots).toBe(5); // at 0.5, 1 … 2.5 s of the 3-s attack (3.0 is its end)
    // One attack in the phase: it repeats (there is nothing else)
    expect(new Set(b.history)).toEqual(new Set(['fan']));
  });

  it('the same seed and health give the same fight; a bad definition throws a readable error', () => {
    const a = fight(11, 60, (t) => 1 - t / 60).log;
    const b = fight(11, 60, (t) => 1 - t / 60).log;
    expect(a).toEqual(b);
    expect(() => new BossPatterns({ attacks: {}, phases: [{ at: 1, attacks: ['nope'] }], rng: () => 0 })).toThrow(/unknown attack "nope"/);
  });
});

describe('bullet patterns', () => {
  const O = { x: 0, y: 0 };
  it('fan spreads count bullets over the arc round the aim; one bullet goes straight', () => {
    const f = fan(O, 0, 5, 1, 100);
    expect(f.map((s) => s.angle)).toEqual([-0.5, -0.25, 0, 0.25, 0.5]);
    expect(f[2].vx).toBe(100);
    expect(fan(O, 1, 1, 2, 10)[0].angle).toBe(1);
  });

  it('ring goes all round from its offset; spiral turns each shot', () => {
    const r = ring(O, 4, 50, 0.1);
    expect(r.map((s) => s.angle)).toEqual([0.1, 0.1 + Math.PI / 2, 0.1 + Math.PI, 0.1 + (3 * Math.PI) / 2]);
    expect(spiral(O, 3, { arms: 2, turn: 0.25, speed: 1 }).map((s) => s.angle)).toEqual([0.75, 0.75 + Math.PI]);
  });

  it('intercept leads a moving target so the bullet meets it; lead 0 aims where it is; too fast to catch: straight at it', () => {
    const target = { x: 10, y: 0, vx: 0, vy: 5 };
    const a = intercept(O, target, 20);
    // Fly both and check they meet
    const t = 10 / (Math.cos(a) * 20);
    expect(Math.sin(a) * 20 * t).toBeCloseTo(target.vy * t, 5);
    expect(intercept(O, target, 20, 0)).toBeCloseTo(0);
    expect(intercept(O, { x: 10, y: 0, vx: 100, vy: 0 }, 5)).toBe(0);
    expect(aimed(O, target, 20, { count: 3, spread: 0.2 })[1].angle).toBeCloseTo(a);
    expect(aimAt(O, { x: 0, y: 3 })).toBeCloseTo(Math.PI / 2);
  });

  it('wave sweeps across its arc and back over its period', () => {
    expect(wave(O, 0, 0, { arc: 1, period: 2, speed: 1 })[0].angle).toBeCloseTo(0);
    expect(wave(O, 0, 0.5, { arc: 1, period: 2, speed: 1 })[0].angle).toBeCloseTo(0.5);
    expect(wave(O, 0, 1.5, { arc: 1, period: 2, speed: 1 })[0].angle).toBeCloseTo(-0.5);
  });
});
