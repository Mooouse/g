// Automa: a rival run by an ordered list of priority rules — its intent telegraphed with ≤ 6 words before it acts,
// difficulty levels, a deck of priority cards, deterministic by seed. Played as a crate-market race against the player.

import { describe, expect, it } from 'vitest';
import { AUTOMA_MAX_WORDS, Automa, best, type AutomaState } from '../src/automa.ts';
import { HINT_MAX_WORDS } from '../src/hints.ts';
import { seededRng, type SeededRng } from '../src/rng.ts';

type Crate = { id: string; price: number; gold?: boolean; color: 'red' | 'blue' };
type Market = { crates: Crate[]; rivalCoins: number; rivalReds: number };
type Take = { take: string };

/** What the rival can pay for */
const affordable = (m: Market) => m.crates.filter((c) => c.price <= m.rivalCoins);
const take = (c: Crate | null | undefined): Take | null => (c ? { take: c.id } : null);
const rules = [
  // a harder rival (level 1+) also knows to grab gold
  { id: 'gold', say: 'grabs any gold crate', from: 1, move: (m: Market) => take(affordable(m).find((c) => c.gold)) },
  { id: 'set', say: (mv: Take) => `completes its reds: ${mv.take}`, move: (m: Market) => (m.rivalReds >= 2 ? take(affordable(m).find((c) => c.color === 'red')) : null) },
  { id: 'cheap', say: 'takes the cheapest crate', move: (m: Market, r: SeededRng) => take(best(affordable(m), (c) => -c.price, r)) },
];
const market = (): Market => ({
  crates: [
    { id: 'a', price: 2, color: 'blue' },
    { id: 'b', price: 1, color: 'blue' },
    { id: 'c', price: 1, color: 'red' },
    { id: 'd', price: 4, color: 'red', gold: true },
  ],
  rivalCoins: 5,
  rivalReds: 0,
});
const rival = () => new Automa<Market, Take>({ rules, levels: [{ name: 'Rookie', slip: 0.4 }, { name: 'Pro' }] });

describe('Automa', () => {
  it('the first rule that can act, acts; with its explanation (≤ 6 words, the hint budget)', () => {
    expect(AUTOMA_MAX_WORDS).toBe(HINT_MAX_WORDS);
    const a = rival();
    const pro = a.start(1, 1);
    const i = a.next(market(), pro)!;
    expect(i).toMatchObject({ move: { take: 'd' }, rule: 'gold', say: 'grabs any gold crate', slipped: false, card: null });
    expect(i.state.turn).toBe(1);
    // the Rookie doesn't know the gold rule (from: 1): it takes a cheapest crate, a tie broken by its seed
    const rookieMove = a.next(market(), a.start(1, 0));
    expect(['b', 'c']).toContain(rookieMove!.move.take);
    expect(a.levelName(0)).toBe('Rookie');
    expect(a.order(pro)).toEqual(['gold', 'set', 'cheap']);
  });

  it('next() is pure: it telegraphs; after the player moves, the same automa state fits its move to the new board', () => {
    const a = rival();
    const s = a.start(7, 1);
    const m = market();
    const shown = a.next(m, s)!;
    expect(a.next(m, s)).toEqual(shown);
    expect(s).toEqual(a.start(7, 1));
    // the player snatches the gold crate it announced: on its turn it falls back to its next rule
    const after = { ...m, crates: m.crates.filter((c) => c.id !== 'd') };
    const acted = a.next(after, s)!;
    expect(acted.rule).toBe('cheap');
    expect(acted.say).toBe('takes the cheapest crate');
  });

  it('a dynamic explanation is checked too; a long one is refused', () => {
    const a = rival();
    const i = a.next({ ...market(), rivalReds: 2 }, a.start(1, 0))!;
    expect(i).toMatchObject({ rule: 'set', say: 'completes its reds: c' });
    expect(() => new Automa({ rules: [{ id: 'x', say: 'this rival explains far too much about itself', move: () => 1 }] })).toThrow(/8 words/);
    const chatty = new Automa<number, number>({ rules: [{ id: 'x', say: (n) => 'a '.repeat(n).trim(), move: (n) => n }] });
    expect(chatty.next(6, chatty.start(1))!.say).toBe('a a a a a a');
    expect(() => chatty.next(7, chatty.start(1))).toThrow(/7 words/);
    expect(new Automa({ rules: [{ id: 'x', say: 'rival.cheapest', move: () => 1 }] }).next(0, { level: 0, rng: 0, deck: [], turn: 0 })!.say).toBe('rival.cheapest');
  });

  it('easier levels slip: they pass over their best rule at the declared rate, the same way every time for a seed', () => {
    const a = rival();
    const easy = new Automa<Market, Take>({ rules, levels: [{ slip: 0.4 }, { slip: 0.4 }] });
    let slips = 0;
    const N = 2000;
    for (let seed = 0; seed < N; seed++) {
      const i = easy.next(market(), easy.start(seed, 1))!;
      if (i.slipped) {
        slips++;
        expect(i.rule).toBe('cheap'); // the next rule that could act
      }
    }
    expect(Math.abs(slips / N - 0.4)).toBeLessThan(0.04);
    expect(a.next(market(), a.start(3, 0))).toEqual(a.next(market(), a.start(3, 0)));
  });

  it('a deck of priority cards: one a turn, reshuffled when spent; its habits vary but each card can be shown', () => {
    const deckRival = new Automa<Market, Take>({ rules, levels: [{}, {}], deck: [['cheap'], ['gold', 'cheap'], ['set', 'gold']] });
    let s: AutomaState = deckRival.start(42, 1);
    const cards: number[] = [];
    for (let t = 0; t < 6; t++) {
      const i = deckRival.next(market(), s)!;
      cards.push(i.card!);
      expect(deckRival.order(s)[0]).toBe(deckRival.deck[i.card!][0]);
      s = i.state;
    }
    expect([...cards.slice(0, 3)].sort()).toEqual([0, 1, 2]);
    expect([...cards.slice(3)].sort()).toEqual([0, 1, 2]);
    expect(() => new Automa({ rules, deck: [['nope']] })).toThrow(/unknown rule/);
  });

  it('a whole race: the rival and a greedy player alternate on a shared market; replayed from a save it is the same', () => {
    const a = rival();
    const play = (seed: number, saveAt = -1): string[] => {
      let m: Market = { crates: Array.from({ length: 8 }, (_, i) => ({ id: `k${i}`, price: 1 + ((i * 3) % 4), color: i % 2 ? 'red' : 'blue', gold: i === 5 })), rivalCoins: 6, rivalReds: 0 };
      let s = a.start(seed, 1);
      const log: string[] = [];
      for (let t = 0; t < 4; t++) {
        if (t === saveAt) s = a.sanitize(JSON.parse(JSON.stringify(s)));
        const intent = a.next(m, s);
        if (!intent) {
          s = a.pass(s);
          log.push('pass');
          continue;
        }
        log.push(`${intent.rule}:${intent.move.take}`);
        const c = m.crates.find((x) => x.id === intent.move.take)!;
        m = { crates: m.crates.filter((x) => x !== c), rivalCoins: m.rivalCoins - c.price, rivalReds: m.rivalReds + (c.color === 'red' ? 1 : 0) };
        s = intent.state;
        // the player takes the dearest crate left
        const mine = best(m.crates, (x) => x.price, seededRng(t));
        if (mine) m = { ...m, crates: m.crates.filter((x) => x !== mine) };
      }
      return log;
    };
    expect(play(5)).toEqual(play(5));
    expect(play(5, 2)).toEqual(play(5));
    expect(play(5)[0]).toBe('gold:k5');
    expect(play(5)).toContain('pass'); // out of coins by the end
  });

  it('sanitize, best() and bad options', () => {
    const a = rival();
    expect(a.sanitize({ level: 9, rng: -1, deck: [5, 'x'], turn: 2 }, 3)).toEqual({ level: 1, rng: 3, deck: [], turn: 2 });
    expect(best([], (x: number) => x, seededRng(1))).toBeNull();
    expect(best([1, 3, 2], (x) => x, seededRng(1))).toBe(3);
    const ties = new Set(Array.from({ length: 30 }, (_, i) => best(['x', 'y', 'z'], () => 0, seededRng(i))));
    expect(ties.size).toBe(3);
    expect(() => new Automa({ rules: [] })).toThrow();
    expect(() => new Automa({ rules: [{ id: 'a', say: 'a', move: () => 1 }], levels: [{ slip: 2 }] })).toThrow();
  });
});
