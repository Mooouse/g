import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { bossTheme, compose, createAmbience, createMixer, createMusic, createSceneMusic, midiOf, musicTheme, PLACES, SCENES, type SoundHost } from '../src/sound';

// A fake WebAudio: nodes remember where they connect, sources when they start, the clock moves with the fake timers

class Param {
  value: number;
  constructor(v = 0) {
    this.value = v;
  }
  setValueAtTime(v: number) {
    this.value = v;
    return this;
  }
  linearRampToValueAtTime(v: number) {
    this.value = v;
    return this;
  }
  exponentialRampToValueAtTime(v: number) {
    this.value = v;
    return this;
  }
  cancelScheduledValues() {
    return this;
  }
}

class Node {
  out: Node[] = [];
  constructor(readonly ctx: FakeCtx) {}
  connect<T>(n: T): T {
    if (n instanceof Node) this.out.push(n);
    return n;
  }
  disconnect() {
    this.out = [];
  }
}

class Source extends Node {
  frequency = new Param(440);
  detune = new Param();
  type = 'sine';
  buffer: unknown = null;
  loop = false;
  loopStart = 0;
  stopped = Infinity;
  start(t = 0) {
    this.ctx.started.push({ node: this, t, muted: this.ctx.muted });
  }
  stop(t = 0) {
    this.stopped = t;
  }
  setPeriodicWave() {}
}

class FakeCtx {
  currentTime = 0;
  state: 'running' | 'suspended' = 'running';
  sampleRate = 8000;
  muted = false;
  started: { node: Source; t: number; muted: boolean }[] = [];
  createGain() {
    return Object.assign(new Node(this), { gain: new Param(1) });
  }
  createOscillator() {
    return new Source(this);
  }
  createBufferSource() {
    return new Source(this);
  }
  createBiquadFilter() {
    return Object.assign(new Node(this), { type: 'lowpass', frequency: new Param(350), Q: new Param(1) });
  }
  createDelay() {
    return Object.assign(new Node(this), { delayTime: new Param() });
  }
  createWaveShaper() {
    return Object.assign(new Node(this), { curve: null as unknown });
  }
  createPeriodicWave() {
    return {};
  }
  createBuffer(_ch: number, len: number) {
    const data = new Float32Array(len);
    return { getChannelData: () => data };
  }
}

function reaches(n: Node, target: Node, seen = new Set<Node>()): boolean {
  if (n === target) return true;
  if (seen.has(n)) return false;
  seen.add(n);
  return n.out.some((o) => reaches(o, target, seen));
}

function makeHost() {
  const ctx = new FakeCtx();
  const out = ctx.createGain();
  let pauseFn = () => {};
  let resumeFn = () => {};
  const host = {
    unlocked: true,
    paused: false,
    portalMuted: false,
    get audio() {
      return this.unlocked ? { ctx: ctx as unknown as AudioContext, out: out as unknown as GainNode } : null;
    },
    onPause: (f: () => void) => (pauseFn = f),
    onResume: (f: () => void) => (resumeFn = f),
  };
  return { ctx, out, host: host as typeof host & SoundHost, pause: () => pauseFn(), resume: () => resumeFn() };
}

/** Move the clock and the timers together, 50 ms at a time */
function step(ctx: FakeCtx, sec: number) {
  for (let i = 0; i < Math.round(sec / 0.05); i++) {
    if (ctx.state === 'running') ctx.currentTime += 0.05;
    vi.advanceTimersByTime(50);
  }
}

beforeEach(() => vi.useFakeTimers());
afterEach(() => vi.useRealTimers());

describe('compose', () => {
  it('is the same tune for the same seed, another for another seed', () => {
    const a = compose(musicTheme('bright', 23));
    expect(compose(musicTheme('bright', 23))).toEqual(a);
    const lead = (s: number) => compose(musicTheme('bright', s)).filter((n) => n.part === 'lead').map((n) => `${n.step}:${n.midi}`).join(' ');
    expect(lead(24)).not.toBe(lead(23));
  });

  it('keeps every mood and the boss variant in range and inside the loop', () => {
    for (const mood of ['calm', 'bright', 'cozy', 'mystery', 'dark', 'tense', 'heroic', 'spooky'] as const) {
      for (const t of [musicTheme(mood, 5), bossTheme(musicTheme(mood, 5), 9)]) {
        const notes = compose(t);
        expect(notes.some((n) => n.part === 'pad')).toBe(true);
        for (const n of notes) {
          expect(n.step).toBeGreaterThanOrEqual(0);
          expect(n.step).toBeLessThan(8 * 16);
          if (n.part !== 'kick' && n.part !== 'hat') {
            expect(n.midi).toBeGreaterThanOrEqual(24);
            expect(n.midi).toBeLessThanOrEqual(86);
          }
        }
      }
    }
  });

  it('reads note names', () => {
    expect(midiOf('C4')).toBe(60);
    expect(midiOf('F#3')).toBe(54);
    expect(midiOf('Bb4')).toBe(70);
    expect(midiOf(57)).toBe(57);
    expect(() => midiOf('H2')).toThrow(/root/);
  });
});

describe('music', () => {
  const themes = { menu: musicTheme('calm', 11), act: musicTheme('bright', 23), boss: bossTheme(musicTheme('bright', 23), 61) };

  it('plays only through host.audio.out', () => {
    const { ctx, out, host } = makeHost();
    const music = createMusic(createMixer(host), themes);
    music.play('act');
    step(ctx, 6);
    expect(ctx.started.length).toBeGreaterThan(20);
    for (const s of ctx.started) expect(reaches(s.node, out)).toBe(true);
  });

  it('waits for the first tap, then starts by itself', () => {
    const { ctx, host } = makeHost();
    host.unlocked = false;
    const music = createMusic(createMixer(host), themes);
    music.play('menu');
    step(ctx, 2);
    expect(ctx.started.length).toBe(0);
    host.unlocked = true;
    step(ctx, 2);
    expect(ctx.started.length).toBeGreaterThan(0);
  });

  it('starts nothing while the portal mutes, and goes on after', () => {
    const { ctx, host } = makeHost();
    const music = createMusic(createMixer(host), themes);
    music.play('act');
    step(ctx, 1);
    host.portalMuted = true;
    ctx.muted = true;
    const before = ctx.started.length;
    step(ctx, 5);
    // Notes scheduled ahead before the mute may still start on time; nothing new after the look-ahead
    expect(ctx.started.filter((s) => s.muted && s.t > 1.4).length).toBe(0);
    expect(ctx.started.length - before).toBeLessThan(25);
    host.portalMuted = false;
    ctx.muted = false;
    step(ctx, 2);
    expect(ctx.started.filter((s) => s.t > 6.2).length).toBeGreaterThan(0);
  });

  it('stops its timer on the host pause and on hold, and starts again', () => {
    const { ctx, host, pause, resume } = makeHost();
    const music = createMusic(createMixer(host), themes);
    music.play('act');
    step(ctx, 1);
    expect(music.ticking).toBe(true);
    host.paused = true;
    ctx.state = 'suspended';
    pause();
    expect(music.ticking).toBe(false);
    host.paused = false;
    ctx.state = 'running';
    resume();
    expect(music.ticking).toBe(true);
    music.hold(true);
    step(ctx, 1);
    expect(music.ticking).toBe(false);
    const n = ctx.started.length;
    step(ctx, 5);
    expect(ctx.started.length).toBe(n);
    music.hold(false);
    step(ctx, 1);
    expect(music.ticking).toBe(true);
    expect(ctx.started.length).toBeGreaterThan(n);
  });

  it('never bursts the missed notes after a long suspend', () => {
    const { ctx, host } = makeHost();
    const music = createMusic(createMixer(host), themes);
    music.play('boss');
    step(ctx, 2);
    // The context stood still for 10 s of wall time while the timer kept going (a hidden tab without the host's pause)
    ctx.state = 'suspended';
    step(ctx, 10);
    ctx.state = 'running';
    ctx.currentTime += 10;
    const n = ctx.started.length;
    step(ctx, 0.05);
    expect(ctx.started.length - n).toBeLessThan(12);
  });

  it('crossfades: the old theme is gone after its fade, play(null) stops the timer', () => {
    const { ctx, host } = makeHost();
    const music = createMusic(createMixer(host), themes);
    music.play('menu');
    step(ctx, 2);
    music.play('boss');
    step(ctx, 4);
    expect(music.theme).toBe('boss');
    music.play(null);
    step(ctx, 4);
    expect(music.ticking).toBe(false);
    expect(() => music.play('nope')).toThrow(/no theme 'nope'/);
  });
});

describe('scene music', () => {
  /** The oscillators started of a type (and a frequency, when given), after time t */
  const voices = (ctx: FakeCtx, type: string, after = -1) => ctx.started.filter((s) => s.node.type === type && s.t > after);

  it('plays only through host.audio.out, on the music bus — the stings too', () => {
    const { ctx, out, host } = makeHost();
    const mixer = createMixer(host);
    const music = createSceneMusic(mixer);
    music.scene('fight');
    step(ctx, 4);
    music.alarm();
    music.roar(0.8);
    music.riser();
    step(ctx, 0.1);
    expect(ctx.started.length).toBeGreaterThan(40);
    const bus = mixer.bus('music') as unknown as Node;
    for (const s of ctx.started) expect(reaches(s.node, bus)).toBe(true);
    for (const s of ctx.started) expect(reaches(s.node, out)).toBe(true);
    expect(reaches(mixer.bus('sfx') as unknown as Node, bus)).toBe(false);
  });

  it('waits for the first tap, then starts by itself; nothing while the portal mutes', () => {
    const { ctx, host } = makeHost();
    host.unlocked = false;
    const music = createSceneMusic(createMixer(host));
    music.scene('menu');
    step(ctx, 2);
    expect(ctx.started.length).toBe(0);
    host.unlocked = true;
    step(ctx, 2);
    expect(ctx.started.length).toBeGreaterThan(0);
    host.portalMuted = true;
    ctx.muted = true;
    step(ctx, 3);
    expect(ctx.started.filter((s) => s.muted && s.t > ctx.currentTime - 2.5).length).toBe(0);
    music.alarm();
    music.roar();
    expect(ctx.started.filter((s) => s.muted).length).toBe(0);
  });

  it('stops its timer on the host pause and on hold, schedules nothing held, and starts again', () => {
    const { ctx, host, pause, resume } = makeHost();
    const music = createSceneMusic(createMixer(host));
    music.scene('explore');
    step(ctx, 1);
    expect(music.ticking).toBe(true);
    host.paused = true;
    ctx.state = 'suspended';
    pause();
    expect(music.ticking).toBe(false);
    host.paused = false;
    ctx.state = 'running';
    resume();
    expect(music.ticking).toBe(true);
    music.hold(true);
    step(ctx, 1);
    const n = ctx.started.length;
    step(ctx, 4);
    music.alarm();
    expect(ctx.started.length).toBe(n);
    expect(music.ticking).toBe(false);
    music.hold(false);
    step(ctx, 1);
    expect(ctx.started.length).toBeGreaterThan(n);
    music.scene(null);
    step(ctx, 2);
    expect(music.ticking).toBe(false);
  });

  it('changes scene at the next bar: the siren of the enrage starts on a bar line, not before', () => {
    const { ctx, host } = makeHost();
    const music = createSceneMusic(createMixer(host));
    music.scene('menu'); // 100 BPM: a bar is 2.4 s
    step(ctx, 1);
    const t0 = ctx.started[0].t;
    music.scene('enrage');
    expect(music.current).toBe('enrage');
    step(ctx, 4);
    // The siren: a sawtooth wailing from 640 Hz; the first one on the first bar line after the change
    const sirens = ctx.started.filter((s) => s.node.type === 'sawtooth' && s.node.frequency.value === 640);
    expect(sirens.length).toBeGreaterThan(0);
    expect(sirens[0].t).toBeCloseTo(t0 + 2.4, 2);
    expect(music.levels().siren).toBeCloseTo(0.45);
    expect(() => music.scene('nope')).toThrow(/no scene 'nope'/);
  });

  it('a stage is a key: the bass plays other notes on another stage', () => {
    const notes = (stage: number) => {
      const { ctx, host } = makeHost();
      const music = createSceneMusic(createMixer(host));
      music.scene('fight', stage);
      step(ctx, 3);
      return new Set(voices(ctx, 'sawtooth').map((s) => Math.round(s.node.frequency.value)));
    };
    const a = notes(0);
    const d = notes(1);
    expect([...a].some((f) => !d.has(f))).toBe(true);
  });

  it('the layers follow the intensity: a [low, high] level moves, a number stays', () => {
    const { ctx, host } = makeHost();
    const music = createSceneMusic(createMixer(host));
    music.scene('fight');
    step(ctx, 0.5);
    expect(music.levels().lead).toBeCloseTo(SCENES.fight.layers.lead[0]);
    music.intensity(1);
    expect(music.levels().lead).toBeCloseTo(SCENES.fight.layers.lead[1]);
    expect(music.levels().sub).toBeCloseTo(0.4);
    music.intensity(7);
    expect(music.level).toBe(1);
  });

  it('never bursts the missed steps after a long suspend', () => {
    const { ctx, host } = makeHost();
    const music = createSceneMusic(createMixer(host));
    music.scene('boss');
    step(ctx, 2);
    ctx.state = 'suspended';
    step(ctx, 10);
    ctx.state = 'running';
    ctx.currentTime += 10;
    const n = ctx.started.length;
    step(ctx, 0.05);
    // ≈ 0.3 s of a busy boss bar at most
    expect(ctx.started.length - n).toBeLessThan(40);
  });

  it('asked to play before the context runs (suspended, the first tap not yet handled), it starts once it runs', () => {
    const { ctx, host } = makeHost();
    ctx.state = 'suspended';
    const music = createSceneMusic(createMixer(host));
    music.scene('menu');
    step(ctx, 2);
    expect(ctx.started.length).toBe(0);
    expect(music.ticking).toBe(true);
    ctx.state = 'running';
    step(ctx, 1);
    expect(ctx.started.length).toBeGreaterThan(5);
  });
});

describe('ambience', () => {
  it('plays beds and events through host.audio.out, and stops when set to nothing', () => {
    const { ctx, out, host } = makeHost();
    const amb = createAmbience(createMixer(host), { seed: 3 });
    amb.set({ ...PLACES.forest, ...PLACES.camp });
    step(ctx, 20);
    const loops = ctx.started.filter((s) => s.node.loop && s.node.stopped === Infinity);
    expect(loops.length).toBe(2); // wind, fire
    expect(ctx.started.length).toBeGreaterThan(20); // birds, crickets, crackle
    for (const s of ctx.started) expect(reaches(s.node, out)).toBe(true);
    amb.set({}, 1);
    step(ctx, 2);
    expect(amb.ticking).toBe(false);
    expect(ctx.started.filter((s) => s.node.loop).every((s) => s.node.stopped < Infinity)).toBe(true);
  });

  it('starts nothing while muted or held, and the timer stands still while held', () => {
    const { ctx, host } = makeHost();
    const amb = createAmbience(createMixer(host), { seed: 4 });
    host.portalMuted = true;
    amb.set(PLACES.night);
    step(ctx, 10);
    expect(ctx.started.length).toBe(0);
    host.portalMuted = false;
    step(ctx, 10);
    expect(ctx.started.length).toBeGreaterThan(0);
    amb.hold(true);
    step(ctx, 1);
    expect(amb.ticking).toBe(false);
    const n = ctx.started.length;
    step(ctx, 10);
    expect(ctx.started.length).toBe(n);
    amb.hold(false);
    step(ctx, 5);
    expect(ctx.started.length).toBeGreaterThan(n);
  });
});

describe('mixer', () => {
  it('keeps volumes in 0–1 and builds the buses on the host output', () => {
    const { out, host } = makeHost();
    const mixer = createMixer(host, { music: 2, sfx: -1 });
    expect(mixer.volumes()).toEqual({ music: 1, ambient: 0.6, sfx: 0 });
    mixer.setVolume('ambient', 0.25);
    expect(mixer.volume('ambient')).toBe(0.25);
    for (const b of ['music', 'ambient', 'sfx'] as const) expect(reaches(mixer.bus(b) as unknown as Node, out)).toBe(true);
    expect(() => mixer.duck(0.7, 0.4)).not.toThrow();
  });

  it('has no buses before the first tap', () => {
    const { host } = makeHost();
    host.unlocked = false;
    expect(createMixer(host).bus('sfx')).toBeNull();
  });
});
