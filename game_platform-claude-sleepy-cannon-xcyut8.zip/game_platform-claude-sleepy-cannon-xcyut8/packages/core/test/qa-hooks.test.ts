// The QA hooks a designer bot uses (gp design): host.qa({ state }) through host.qaState(), and ?qa-demo=0 switching the
// demo bot off. The host needs a page to be made, so these call its methods on a stand-in `this` (they read only the
// driver and the URL).

import { afterEach, describe, expect, it, vi } from 'vitest';
import { GameHost, type QaDriver } from '../src/host';

const qaState = (driver: Partial<QaDriver> | null) => GameHost.prototype.qaState.call({ qaDriver: driver } as unknown as GameHost);
const demoOff = (search: string) => {
  vi.stubGlobal('location', { search });
  return Object.getOwnPropertyDescriptor(GameHost.prototype, 'demoOff')!.get!.call({});
};

afterEach(() => vi.unstubAllGlobals());

describe('host.qa({ state }) → host.qaState()', () => {
  it('null without the hook, or when it throws or says no screen', () => {
    expect(qaState(null)).toBeNull();
    expect(qaState({ play() {}, end() {} })).toBeNull();
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    expect(
      qaState({
        state: () => {
          throw new Error('boom');
        },
      }),
    ).toBeNull();
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
    expect(qaState({ state: () => ({}) as never })).toBeNull();
  });

  it('the screen, the stage, the goal and what to touch — checked and clipped', () => {
    const touch = Array.from({ length: 20 }, (_, i) => ({ x: i + 0.123, y: 2, label: i === 0 ? '' : `nut ${i}` }));
    const st = qaState({ state: () => ({ screen: 'play', stage: '  garage 2, car 3 of 8 ', goal: '', touch: [...touch, { x: Number.NaN, y: 1, label: 'bad' }] }) });
    expect(st).toMatchObject({ screen: 'play', stage: 'garage 2, car 3 of 8' });
    expect(st).not.toHaveProperty('goal');
    expect(st!.touch).toHaveLength(12);
    expect(st!.touch![0]).toEqual({ x: 0.1, y: 2, label: 'touch' });
    expect(qaState({ state: () => ({ screen: 'title' }) })).toEqual({ screen: 'title' });
  });
});

describe('?qa-demo=0', () => {
  it('switches the demo bot off: host.qa keeps the driver without demo()', () => {
    expect(demoOff('?seed=1&qa-demo=0')).toBe(true);
    expect(demoOff('?seed=1')).toBe(false);
    expect(demoOff('?qa-demo=1')).toBe(false);
    const demo = vi.fn();
    const driver: QaDriver = { play() {}, end() {}, demo };
    const off = { demoOff: true, qaDriver: null as QaDriver | null };
    GameHost.prototype.qa.call(off as unknown as GameHost, driver);
    expect(off.qaDriver!.demo).toBeUndefined();
    expect(typeof off.qaDriver!.play).toBe('function');
    const on = { demoOff: false, qaDriver: null as QaDriver | null };
    GameHost.prototype.qa.call(on as unknown as GameHost, driver);
    expect(on.qaDriver).toBe(driver);
  });
});
