import { describe, expect, it } from 'vitest';
import { QualityLadder, deviceTier, isSoftwareGpu, qualityPin, startLevel } from '../src/quality.ts';

const LEVELS = ['best', 'high', 'mid', 'low', 'lowest', 'tiny', 'min'] as const;

/** Feed `sec` seconds of frames at a fixed interval (ms) */
function feed(q: { frame(ms: number): void }, ms: number, sec: number): void {
  const n = Math.round((sec * 1000) / ms);
  for (let i = 0; i < n; i++) q.frame(ms);
}

describe('deviceTier / startLevel', () => {
  it('a software rasterizer is software; a touch screen a phone (low with few cores or little memory); else a desktop', () => {
    expect(deviceTier({ renderer: 'ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero)), SwiftShader driver)', coarse: false }).tier).toBe('software');
    expect(deviceTier({ renderer: 'llvmpipe (LLVM 15.0.7, 256 bits)', coarse: true }).software).toBe(true);
    expect(deviceTier({ renderer: 'Adreno (TM) 640', coarse: true, cores: 8, memoryGB: 6 }).tier).toBe('phone');
    expect(deviceTier({ renderer: 'Mali-G52', coarse: true, cores: 4, memoryGB: 2 }).tier).toBe('low');
    expect(deviceTier({ renderer: 'NVIDIA GeForce RTX 3060', coarse: false }).tier).toBe('desktop');
    expect(isSoftwareGpu('Microsoft Basic Render Driver')).toBe(true);
    expect(isSoftwareGpu('Apple M2')).toBe(false);
  });

  it('maps a tier to a level of N: software the cheapest, a phone the middle, a desktop the second best (Frankengun\'s 6 / 3 / 1 of 7)', () => {
    expect(startLevel('software', 7)).toBe(6);
    expect(startLevel('phone', 7)).toBe(3);
    expect(startLevel('low', 7)).toBe(4);
    expect(startLevel('desktop', 7)).toBe(1);
    expect(startLevel('desktop', 1)).toBe(0);
  });

  it('?q= pins a level in dev builds only (clamped), and nothing else does', () => {
    expect(qualityPin(7, '?q=2')).toBe(import.meta.env.DEV ? 2 : null);
    expect(qualityPin(7, '?q=99')).toBe(import.meta.env.DEV ? 6 : null);
    expect(qualityPin(7, '?q=x')).toBeNull();
    expect(qualityPin(7, '')).toBeNull();
  });
});

describe('QualityLadder', () => {
  it('starts at the tier\'s level; a slow stretch on the frame interval steps it down, one level at a time', () => {
    const changes: number[] = [];
    const q = new QualityLadder({ levels: LEVELS, start: 'desktop', pin: null, onChange: (_l, i) => changes.push(i) });
    expect(q.level).toBe(1);
    expect(q.current).toBe('high');
    feed(q, 16.7, 3);
    expect(changes).toEqual([]);
    feed(q, 33, 2); // 30 fps
    expect(q.level).toBeGreaterThan(1);
    expect(changes[0]).toBe(2);
  });

  it('a calm stretch steps it up; the calm needed doubles after every step down (5 s → 60 s max), so it does not flap', () => {
    const q = new QualityLadder({ levels: LEVELS, start: 3, pin: null });
    feed(q, 16.7, 5.6);
    expect(q.level).toBe(2);
    feed(q, 30, 1.5);
    expect(q.level).toBe(3);
    expect(q.calmSec).toBe(10);
    feed(q, 16.7, 8);
    expect(q.level).toBe(3); // 10 s needed now
    feed(q, 16.7, 3);
    expect(q.level).toBe(2);
    for (let i = 0; i < 6; i++) {
      feed(q, 30, 1.5);
      feed(q, 16.7, 61);
    }
    expect(q.calmSec).toBe(60);
  });

  it('a level whose step up failed three times is not tried again (until a settings choice)', () => {
    const q = new QualityLadder({ levels: LEVELS, start: 2, pin: null, calmMaxSec: 5 });
    let ups = 0;
    let last = q.level;
    for (let i = 0; i < 12; i++) {
      // Calm at 2 → up to 1; level 1 runs slow → back to 2
      feed(q, 16.7, 6);
      if (q.level < last) ups++;
      last = q.level;
      if (q.level === 1) feed(q, 30, 1.5);
      last = q.level;
    }
    expect(ups).toBe(3);
    expect(q.level).toBe(2);
    q.set(1);
    expect(q.level).toBe(1);
  });

  it('a hitch counts as 100 ms at most; the floor is never passed; a pinned ladder ignores frames', () => {
    const q = new QualityLadder({ levels: LEVELS, start: 0, pin: null, floor: 2 });
    expect(q.level).toBe(2);
    feed(q, 16.7, 1);
    q.frame(5000);
    expect(q.avg).toBeLessThan(30);
    expect(q.level).toBe(2);
    q.floor = 4;
    expect(q.level).toBe(4);
    const p = new QualityLadder({ levels: LEVELS, pin: 5 });
    expect(p.pinned).toBe(true);
    expect(p.level).toBe(5);
    feed(p, 50, 5);
    expect(p.level).toBe(5);
  });

  it('work measure: the frame\'s own ms against a 10 ms budget', () => {
    const q = new QualityLadder({ levels: LEVELS, start: 0, measure: 'work', pin: null });
    feed(q, 4, 2);
    expect(q.level).toBe(0);
    for (let i = 0; i < 80; i++) q.frame(14);
    expect(q.level).toBe(1);
  });

  it('watch() measures intervals only while the engine runs, and never across a stop', () => {
    let fn: () => void = () => {};
    const eng = { running: false, onFrame: (f: () => void) => ((fn = f), () => {}) };
    const q = new QualityLadder({ levels: LEVELS, start: 0, pin: null });
    let t = 0;
    q.watch(eng, () => t);
    const frames = (n: number, ms: number) => {
      for (let i = 0; i < n; i++) {
        t += ms;
        fn();
      }
    };
    frames(100, 50); // a still frame now and then (renderOnce on a menu): not measured
    expect(q.avg).toBeCloseTo(19.25);
    eng.running = true;
    frames(60, 16.7);
    eng.running = false;
    t += 10000; // a pause
    frames(1, 16.7);
    eng.running = true;
    frames(2, 16.7);
    expect(q.avg).toBeLessThan(18);
    expect(q.level).toBe(0);
  });
});
