// createMusic on a real AudioContext: music asked for before the first tap (no context yet), or while the context is
// suspended, comes in at full level once the context runs — not near-silent until the first pause, the bug Frankengun
// found in its own music (a fade-in scheduled before there was a context; 2026-10-18). Runs with `npm run test:browser`.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./sound-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  // The fixture plays without a tap: the test stands for the player's first one
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined, args: ['--autoplay-policy=no-user-gesture-required'] });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

describe('createMusic: the start before the context', () => {
  it('music played and its volume set before the first tap (or while suspended) is as loud as music started after it', { timeout: 60000 }, async () => {
    const page = await browser.newPage();
    await page.goto(base);
    await page.waitForFunction(() => '__level' in window);
    const level = (order: string) => page.evaluate((o) => (window as unknown as { __level: (o: string) => Promise<number> }).__level(o), order);
    const after = await level('after');
    const before = await level('before');
    const paused = await level('paused');
    // The reference plays at all (a working meter), and the early starts reach its level
    expect(after).toBeGreaterThan(0.005);
    expect(before / after, `before ${before}, after ${after}`).toBeGreaterThan(0.5);
    expect(paused / after, `paused ${paused}, after ${after}`).toBeGreaterThan(0.5);
    await page.close();
  });
});
