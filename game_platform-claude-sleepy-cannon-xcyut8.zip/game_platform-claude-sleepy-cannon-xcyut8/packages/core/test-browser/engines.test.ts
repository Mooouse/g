// Browser test of the engine adapters' shared contract (@gp/core/engines/*): created stopped, runs only in play and
// while the host isn't paused, stops inside a step, resumes without a time jump, DPR capped, sound only on a running
// context, a lost WebGL context comes back and the still frame is redrawn. The engines themselves (Pixi, Phaser, three)
// are each game's own dependency, not the platform's: engines-real.test.ts runs the adapters on the real packages,
// installed only in its own folder.
// Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./engine-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface Stats {
  raf: number;
  steps: number;
  frames: number;
  renders: number;
  running: boolean;
  width: number;
  height: number;
}
interface T {
  host: { adBreak(): Promise<void>; paused: boolean; pauseReasons: ReadonlySet<string>; audio: { ctx: AudioContext | null } };
  eng: { setRunning(on: boolean): void; renderOnce(): void; running: boolean; audio: { live(): unknown; play(b: AudioBuffer): unknown } };
  log: string[];
  dts: number[];
  pixi: { tickerRaf: number; tickerUpdates: number; tickerStarted: boolean; renders: number; textureRenders: number };
  audioContexts(): number;
  stats(): Stats;
  setHidden(h: boolean): void;
}
const t = <R>(page: Page, fn: (t: T) => R) => page.evaluate(`(${fn.toString()})(window.__t)`) as Promise<Awaited<R>>;
const until = (page: Page, fn: (t: T) => boolean) => page.waitForFunction(`(${fn.toString()})(window.__t)`, null, { timeout: 10000 });

async function open(query = '', opts: { dpr?: number } = {}): Promise<Page> {
  const ctx = await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: opts.dpr ?? 1 });
  const page = await ctx.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(`${base}${query}`);
  await page.waitForFunction('!!window.__t');
  (page as unknown as { errors: string[] }).errors = errors;
  return page;
}
const errorsOf = (page: Page) => (page as unknown as { errors: string[] }).errors;

describe('the engine contract (canvasAdapter on the shared driver)', () => {
  it('created stopped: no requestAnimationFrame, no step, no frame until setRunning(true); then fixed 1/60 s steps and a frame each rAF', async () => {
    const page = await open();
    await page.waitForTimeout(400);
    expect(await t(page, (x) => x.stats())).toMatchObject({ raf: 0, steps: 0, frames: 0, running: false });
    await t(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(500);
    const s = await t(page, (x) => ({ ...x.stats(), dts: [...new Set(x.dts)] }));
    expect(s.running).toBe(true);
    expect(s.steps).toBeGreaterThan(10);
    expect(s.frames).toBeGreaterThan(10);
    expect(s.dts).toEqual([1 / 60]);
    // Stopped again: the loop really stops (no more rAF callbacks)
    await t(page, (x) => x.eng.setRunning(false));
    const r0 = await t(page, (x) => x.stats().raf);
    await page.waitForTimeout(300);
    expect(await t(page, (x) => x.stats().raf)).toBe(r0);
    expect(errorsOf(page)).toEqual([]);
    await page.close();
  });

  it('setRunning(false) from inside a step: no more step listeners, steps or draw in that frame', async () => {
    const page = await open('?stopAt=3');
    await t(page, (x) => x.eng.setRunning(true));
    await until(page, (x) => x.dts.length >= 3);
    await page.waitForTimeout(300);
    const s = await t(page, (x) => ({ ...x.stats(), log: x.log.filter((l) => l.startsWith('step2')) }));
    expect(s.steps).toBe(3);
    expect(s.running).toBe(false);
    // The second listener ran for steps 1 and 2, not for the step that ended the run
    expect(s.log).toEqual(['step2:1', 'step2:2']);
    await page.close();
  });

  it("the host's pause stops it (a hidden tab), resume goes on without counting the stopped time", async () => {
    const page = await open();
    await t(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(300);
    await t(page, (x) => x.setHidden(true));
    expect(await t(page, (x) => ({ running: x.eng.running, paused: x.host.paused }))).toEqual({ running: false, paused: true });
    const before = await t(page, (x) => x.stats());
    await page.waitForTimeout(1000);
    expect(await t(page, (x) => x.stats())).toMatchObject({ steps: before.steps, raf: before.raf });
    await t(page, (x) => x.setHidden(false));
    expect(await t(page, (x) => x.eng.running)).toBe(true);
    await page.waitForTimeout(250);
    // A jump would be the second of standing still counted at once: at most the 0.25 s of play (plus a frame)
    const after = await t(page, (x) => x.stats().steps);
    expect(after - before.steps).toBeLessThan(0.25 * 60 + 4);
    // The game's own "not in play" wins over a resume
    await t(page, (x) => x.eng.setRunning(false));
    await t(page, (x) => x.setHidden(true));
    await t(page, (x) => x.setHidden(false));
    expect(await t(page, (x) => x.eng.running)).toBe(false);
    await page.close();
  });

  it('an ad pauses it like the host does, and the still frame is redrawn after', async () => {
    const page = await open();
    await t(page, (x) => x.eng.setRunning(true));
    const ad = t(page, (x) => x.host.adBreak());
    await until(page, (x) => x.host.paused);
    expect(await t(page, (x) => x.eng.running)).toBe(false);
    await ad;
    expect(await t(page, (x) => x.eng.running)).toBe(true);
    await page.close();
  });

  it('DPR capped at 2, the transform in CSS px, resize from the window (and a redraw while standing still)', async () => {
    const page = await open('', { dpr: 3 });
    expect(await t(page, (x) => x.stats())).toMatchObject({ width: 1280, height: 720 });
    await t(page, (x) => x.eng.renderOnce());
    expect(await t(page, (x) => x.log.filter((l) => l.startsWith('frame')))).toEqual(['frame:scale=2']);
    await page.setViewportSize({ width: 400, height: 300 });
    await until(page, (x) => x.log.some((l) => l.startsWith('onResize')));
    expect(await t(page, (x) => ({ ...x.stats(), log: x.log.filter((l) => l.startsWith('onResize')) }))).toMatchObject({ width: 800, height: 600, log: ['onResize:400x300@2'], frames: 2 });
    await page.close();
  });

  it('setRenderScale: fewer pixels at the same CSS size, the transform and onResize follow, a still frame redrawn; pixelated below 0.6 and the CSS put back', async () => {
    const page = await open('', { dpr: 2 });
    await t(page, (x) => ((x.eng as unknown as { setRenderScale(k: number, o?: { dprMax?: number }): void }).setRenderScale(0.5), 0));
    const a = await t(page, (x) => ({ ...x.stats(), log: x.log.filter((l) => l.startsWith('onResize') || l.startsWith('frame')), css: (document.getElementById('game') as HTMLCanvasElement).style.imageRendering }));
    expect(a).toMatchObject({ width: 640, height: 360, css: 'pixelated', log: ['onResize:640x360@1', 'frame:scale=1'] });
    await t(page, (x) => ((x.eng as unknown as { setRenderScale(k: number, o?: { dprMax?: number }): void }).setRenderScale(0.5, { dprMax: 1 }), 0));
    const b = await t(page, (x) => ({ ...x.stats(), css: (document.getElementById('game') as HTMLCanvasElement).style.imageRendering }));
    expect(b).toMatchObject({ width: 320, height: 180, css: 'pixelated' });
    await t(page, (x) => ((x.eng as unknown as { setRenderScale(k: number, o?: { dprMax?: number }): void }).setRenderScale(1, { dprMax: 2 }), 0));
    expect(await t(page, (x) => ({ ...x.stats(), css: (document.getElementById('game') as HTMLCanvasElement).style.imageRendering }))).toMatchObject({ width: 1280, height: 720, css: '' });
    expect(errorsOf(page)).toEqual([]);
    await page.close();
  });

  it('sound only on a running context: nothing before the first tap, nothing while paused', async () => {
    const page = await open();
    expect(await t(page, (x) => ({ live: x.eng.audio.live(), played: x.eng.audio.play(new AudioBuffer({ length: 10, sampleRate: 44100 })) }))).toEqual({ live: null, played: null });
    await page.mouse.click(10, 10);
    await until(page, (x) => !!x.eng.audio.live());
    await t(page, (x) => x.setHidden(true));
    expect(await t(page, (x) => x.eng.audio.live())).toBeNull();
    await t(page, (x) => x.setHidden(false));
    await until(page, (x) => !!x.eng.audio.live());
    expect(await t(page, (x) => !!x.eng.audio.play(new AudioBuffer({ length: 10, sampleRate: 44100 })))).toBe(true);
    // One AudioContext on the page: the host's, the one the adapter plays on
    expect(await t(page, (x) => ({ n: x.audioContexts(), same: (x.eng.audio.live() as { ctx: AudioContext }).ctx === x.host.audio.ctx }))).toEqual({ n: 1, same: true });
    await page.close();
  });
});

describe('a lost WebGL context (the driver of the WebGL adapters)', () => {
  it('preventDefault on the loss (no reload screen), stopped while lost, the still frame redrawn after the restore', async () => {
    const page = await open('?engine=webgl');
    await t(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(200);
    await page.evaluate('window.__lose.loseContext()');
    await until(page, (x) => x.host.paused);
    expect(await t(page, (x) => ({ running: x.eng.running, reasons: [...x.host.pauseReasons] }))).toEqual({ running: false, reasons: ['context'] });
    await page.waitForTimeout(200);
    expect(await page.locator('[data-gp=reload]').count()).toBe(0);
    // The game's own pause screen comes up meanwhile: after the restore the adapter draws the still frame once
    await t(page, (x) => x.eng.setRunning(false));
    const renders = await t(page, (x) => x.log.filter((l) => l.startsWith('render')).length);
    await page.evaluate('window.__lose.restoreContext()');
    await until(page, (x) => !x.host.paused);
    await page.waitForFunction(`window.__t.log.filter((l) => l.startsWith('render')).length > ${renders}`, null, { timeout: 10000 });
    expect(await t(page, (x) => x.log.filter((l) => l.startsWith('render')).slice(-1))).toEqual(['render:lost=false']);
    expect(await t(page, (x) => x.eng.running)).toBe(false);
    await t(page, (x) => x.eng.setRunning(true));
    expect(await t(page, (x) => x.eng.running)).toBe(true);
    expect(errorsOf(page)).toEqual([]);
    await page.close();
  });
});

describe('pixiAdapter (on a fake pixi.js with Pixi 8\'s loop API: Pixi itself is each game\'s dependency)', () => {
  it("stops Pixi's own ticker loop, created stopped, drives the ticker from its frames, stops on every pause reason, resumes without a jump", async () => {
    const page = await open('?engine=pixi');
    await page.waitForTimeout(300);
    const p0 = await t(page, (x) => ({ ...x.pixi, ...x.stats() }));
    // Pixi's Ticker.system loop stopped at once; no frame of the adapter's until a run is on
    expect(p0).toMatchObject({ tickerStarted: false, raf: 0, steps: 0, renders: 0, tickerUpdates: 0, running: false });
    expect(p0.tickerRaf).toBeLessThan(3);
    await t(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(400);
    const p1 = await t(page, (x) => ({ ...x.pixi, ...x.stats(), dts: [...new Set(x.dts)] }));
    expect(p1.steps).toBeGreaterThan(10);
    expect(p1.dts).toEqual([1 / 60]);
    // The ticker is updated once per drawn frame, by the adapter, and Pixi's own loop stays off
    expect(p1.tickerUpdates).toBe(p1.renders);
    expect(p1.tickerRaf).toBe(p0.tickerRaf);
    // Each pause reason stops it; resume counts no stopped time
    for (const reason of ['hidden', 'ad', 'context'] as const) {
      const before = await t(page, (x) => x.stats().steps);
      if (reason === 'hidden') await t(page, (x) => x.setHidden(true));
      const ad = reason === 'ad' ? t(page, (x) => x.host.adBreak()) : null;
      if (reason === 'context') await page.evaluate('window.__lose.loseContext()');
      await until(page, (x) => x.host.paused);
      expect(await t(page, (x) => ({ running: x.eng.running, reasons: [...x.host.pauseReasons] }))).toEqual({ running: false, reasons: [reason] });
      const stopped = await t(page, (x) => x.stats().steps);
      expect(stopped - before).toBeLessThan(0.1 * 60);
      await page.waitForTimeout(500);
      expect(await t(page, (x) => x.stats().steps)).toBe(stopped);
      if (reason === 'hidden') await t(page, (x) => x.setHidden(false));
      if (ad) await ad;
      if (reason === 'context') await page.evaluate('window.__lose.restoreContext()');
      await until(page, (x) => !x.host.paused && x.eng.running);
      await page.waitForTimeout(200);
      expect((await t(page, (x) => x.stats().steps)) - stopped).toBeLessThan(0.2 * 60 + 4);
    }
    // The generated texture was drawn again after the restore
    expect(await t(page, (x) => x.pixi.textureRenders)).toBe(1);
    // renderOnce while stopped: one synchronous render
    await t(page, (x) => x.eng.setRunning(false));
    const r = await t(page, (x) => x.pixi.renders);
    await t(page, (x) => x.eng.renderOnce());
    expect(await t(page, (x) => x.pixi.renders)).toBe(r + 1);
    expect(errorsOf(page)).toEqual([]);
    await page.close();
  });
});
