// Browser test of the first-minute blocks (docs/guides/first-minute.md): the host's first visit, funnel and saved run;
// hints() one at a time and never over a modal; mountResults' big "continue" button, next goal and auto-continue; the
// welcome-back card; the daily reward card. Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./first-minute-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

/* eslint-disable @typescript-eslint/no-explicit-any */
const t = <R>(page: Page, fn: (t: any) => R) => page.evaluate(`(${fn.toString()})(window.__t)`) as Promise<Awaited<R>>;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function open(query = '', viewport = { width: 360, height: 800 }): Promise<Page> {
  const page = await browser.newPage({ viewport, hasTouch: true });
  await page.goto(`${base}${query}`);
  await page.waitForFunction(() => (window as any).__t);
  return page;
}

describe('GameHost: the first visit', () => {
  it('true with no save, false with one; ?visit= forces either in dev builds', async () => {
    let page = await open();
    expect(await t(page, (t) => t.host.firstVisit)).toBe(true);
    await page.close();
    page = await open(`?save=${encodeURIComponent('{"best":3}')}`);
    expect(await t(page, (t) => t.host.firstVisit)).toBe(false);
    await page.close();
    page = await open(`?save=${encodeURIComponent('{"best":3}')}&visit=first`);
    expect(await t(page, (t) => t.host.firstVisit)).toBe(true);
    await page.close();
    page = await open('?visit=returning');
    expect(await t(page, (t) => t.host.firstVisit)).toBe(false);
    await page.close();
  });

  it('holdGameplayUntilLoaded: a run started before loaded() reaches the portal after loadingStop', async () => {
    const page = await open('?hold=1');
    await t(page, (t) => {
      t.host.gameplay(true);
    });
    expect(await t(page, (t) => t.calls.slice())).toEqual([]);
    expect(await t(page, (t) => t.host.isPlaying)).toBe(false);
    await t(page, (t) => t.host.loaded());
    expect(await t(page, (t) => t.calls.slice())).toEqual(['loadingStop', 'gameplayStart']);
    expect(await t(page, (t) => t.funnel())).toEqual(['boot', 'loaded', 'gameplayStart']);
    await page.close();
  });
});

describe('GameHost: the funnel', () => {
  it('boot, title, firstInput, gameplayStart, firstFail, firstResults — each once; play15 after 15 s of gameplay', async () => {
    const page = await open();
    await t(page, (t) => {
      t.host.screen('title');
      t.host.screen('title');
    });
    await page.mouse.click(10, 10);
    await t(page, (t) => {
      t.host.gameplay(true);
      t.host.fail({ why: 'hit' });
      t.host.roundEnd({ score: 3 });
      t.host.gameplay(true);
      t.host.roundEnd({ lost: true });
    });
    expect(await t(page, (t) => t.funnel())).toEqual(['boot', 'title', 'firstInput', 'gameplayStart', 'firstFail', 'firstResults']);
    const input = await t(page, (t) => t.host.events.log.find((e: any) => e.type === 'funnel' && e.data.step === 'firstInput').data);
    expect(input).toMatchObject({ kind: 'pointer', screen: 'title' });
    // The gameplay clock: only while playing (a paused stretch doesn't count)
    await page.clock.install();
    await t(page, (t) => t.host.gameplay(true));
    await page.clock.runFor(14_000);
    expect(await t(page, (t) => t.funnel().includes('play15'))).toBe(false);
    await page.clock.runFor(2_000);
    expect(await t(page, (t) => t.funnel().includes('play15'))).toBe(true);
    await page.close();
  });

  it('exit on pagehide names the last screen and the gameplay seconds', async () => {
    const page = await open();
    await t(page, (t) => t.host.screen('shop'));
    await t(page, () => window.dispatchEvent(new PageTransitionEvent('pagehide')));
    const exit = await t(page, (t) => t.host.events.log.find((e: any) => e.type === 'funnel' && e.data.step === 'exit')?.data);
    expect(exit).toMatchObject({ step: 'exit', screen: 'shop', playedSec: 0, reached: 'boot' });
    await page.close();
  });
});

describe('GameHost: saveRun / loadRun', () => {
  it('a run survives a reload, shaped by the defaults; cleared, it is gone; too old, it is ignored', async () => {
    const page = await open();
    await t(page, (t) => t.host.saveRun({ room: 4, hp: 2, junk: 'x' }));
    await page.reload();
    await page.waitForFunction(() => (window as any).__t);
    expect(await t(page, (t) => t.host.loadRun({ room: 0, hp: 3 }))).toEqual({ room: 4, hp: 2 });
    expect(await t(page, (t) => t.host.loadRun({ room: 0 }, { maxAgeHours: -1 }))).toBeNull();
    await t(page, (t) => t.host.clearRun());
    expect(await t(page, (t) => t.host.loadRun({ room: 0 }))).toBeNull();
    // A run is not a save: the next visit is still a first one
    await page.reload();
    await page.waitForFunction(() => (window as any).__t);
    expect(await t(page, (t) => t.host.firstVisit)).toBe(true);
    await page.close();
  });
});

describe('hints()', () => {
  it('one at a time: the second waits, done() shows the next; learned hints never come back and are saved', async () => {
    const page = await open();
    await t(page, (t) => {
      (window as any).seen = [];
      (window as any).saves = 0;
      (window as any).h = t.hints({ seen: (window as any).seen, onSeen: () => (window as any).saves++ });
      (window as any).h.show('move', 'Drag to move');
      (window as any).h.show('dash', 'Tap to dash');
    });
    await sleep(350);
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Drag to move');
    expect(await page.locator('[data-gp=hint]').isVisible()).toBe(true);
    await t(page, () => (window as any).h.done('move'));
    await sleep(350);
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Tap to dash');
    await t(page, () => {
      (window as any).h.done('dash');
      (window as any).h.show('move', 'Drag to move');
    });
    await sleep(400);
    expect(await t(page, () => (window as any).seen)).toEqual(['move', 'dash']);
    expect(await t(page, () => (window as any).saves)).toBe(2);
    expect(await t(page, () => (window as any).h.current)).toBeNull();
    expect(await page.locator('[data-gp=hint]').isVisible()).toBe(false);
    await page.close();
  });

  it('after: shown only when the player has not done it in time; never over a modal; no pointer events', async () => {
    const page = await open();
    await t(page, (t) => {
      (window as any).h = t.hints();
      (window as any).h.show('quick', 'Tap', { after: 300 });
      (window as any).h.done('quick');
      (window as any).h.show('slow', 'Hold to aim', { after: 200 });
    });
    await sleep(600);
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Hold to aim');
    expect(await page.locator('[data-gp=hint]').evaluate((e) => getComputedStyle(e).pointerEvents)).toBe('none');
    await t(page, () => {
      const d = document.createElement('div');
      d.dataset.gp = 'dialog';
      d.style.cssText = 'position:fixed;inset:20px;background:#000';
      d.id = 'modal';
      document.body.append(d);
    });
    await sleep(600);
    expect(await page.locator('[data-gp=hint]').evaluate((e) => getComputedStyle(e).opacity)).toBe('0');
    expect(await t(page, () => (window as any).h.current)).toBeNull();
    await t(page, () => document.getElementById('modal')!.remove());
    await sleep(600);
    expect(await page.locator('[data-gp=hint]').evaluate((e) => getComputedStyle(e).opacity)).toBe('1');
    await page.close();
  });

  it('a requestAnimationFrame-free block: nothing runs on a still screen because of a hint', async () => {
    const page = await open();
    await page.evaluate(() => {
      (window as any).raf = 0;
      const orig = window.requestAnimationFrame.bind(window);
      window.requestAnimationFrame = (cb) => ((window as any).raf++, orig(cb));
    });
    await t(page, (t) => t.hints().show('x', 'Tap'));
    await sleep(800);
    expect(await page.evaluate(() => (window as any).raf)).toBe(0);
    await page.close();
  });

  it('never cut short: without a queue a new hint waits until the one on screen was read (2 s + 50 ms a character)', async () => {
    const page = await open();
    await page.clock.install();
    await t(page, (t) => {
      (window as any).h = t.hints({ queue: false });
      // 20 characters: 2 s to notice + 1 s to read
      (window as any).h.show('place', 'Drag a tile onto it');
      (window as any).h.show('flip', 'Tap to flip');
      (window as any).h.show('turn', 'Double-tap to turn');
    });
    await page.clock.runFor(2_900);
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Drag a tile onto it');
    expect(await t(page, () => (window as any).h.current)).toBe('place');
    await page.clock.runFor(200);
    // The latest of the ones that came meanwhile takes its place
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Double-tap to turn');
    // The player doing it still takes a hint away at once
    await t(page, () => (window as any).h.done('turn'));
    expect(await t(page, () => (window as any).h.current)).toBeNull();
    await page.close();
  });

  it('the time behind a modal is not reading time; with the queue a hint on screen waits for done()', async () => {
    const page = await open();
    await page.clock.install();
    await t(page, (t) => {
      (window as any).h = t.hints({ queue: false });
      (window as any).h.show('a', 'Tap a card', { minSec: 2 });
      const d = document.createElement('div');
      d.setAttribute('aria-modal', 'true');
      d.style.cssText = 'position:fixed;inset:20px;background:#000';
      d.id = 'modal';
      document.body.append(d);
      (window as any).h.show('b', 'Swipe');
    });
    await page.clock.runFor(5_000);
    await t(page, () => document.getElementById('modal')!.remove());
    await page.clock.runFor(1_000);
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Tap a card');
    await page.clock.runFor(1_500);
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Swipe');
    // With the queue (the default) the next one never replaces the one on screen, however long it has been up
    await t(page, (t) => {
      (window as any).h.destroy();
      (window as any).q = t.hints();
      (window as any).q.show('a', 'Tap a card');
      (window as any).q.show('b', 'Swipe');
    });
    await page.clock.runFor(20_000);
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Tap a card');
    await t(page, () => (window as any).q.done('a'));
    expect(await page.locator('[data-gp=hint]').innerText()).toBe('Swipe');
    await page.close();
  });

  it("top: px or a CSS length from the top of the screen, or --gp-hints-top in the game's CSS", async () => {
    const page = await open();
    await t(page, (t) => {
      (window as any).h = t.hints({ top: 72 });
      (window as any).h.show('x', 'Tap');
    });
    await sleep(350);
    expect(Math.round((await page.locator('[data-gp=hint]').boundingBox())!.y)).toBe(72);
    await t(page, (t) => {
      (window as any).h.destroy();
      const s = document.createElement('style');
      s.textContent = ':root { --gp-hints-top: 25%; }';
      document.head.append(s);
      (window as any).h = t.hints({ position: 'center' });
      (window as any).h.show('y', 'Tap');
    });
    await sleep(350);
    expect(Math.round((await page.locator('[data-gp=hint]').boundingBox())!.y)).toBe(200);
    await page.close();
  });
});

describe('mountResults()', () => {
  it("a game's plain rules win (no #ui #gp-results needed), its generic button look doesn't; the panel centres itself", async () => {
    const page = await open();
    await t(page, (t) => {
      // The game's stylesheet, in <head> before the results screen first mounts (as a game's CSS is)
      const s = document.createElement('style');
      s.textContent = '#gp-results { padding: 30px; } #gp-results h2 { font-size: 40px; } #gp-results .gp-primary { background: rgb(1, 2, 3); }';
      document.head.append(s);
      // A plain block root: no flex or grid to centre it
      const root = document.createElement('div');
      root.style.cssText = 'position: fixed; inset: 0;';
      document.body.append(root);
      t.results({}, root);
    });
    const r = await page.locator('[data-gp=results]').evaluate((e) => {
      const b = e.getBoundingClientRect();
      const btn = getComputedStyle(e.querySelector('.gp-primary')!);
      return { cx: b.left + b.width / 2, cy: b.top + b.height / 2, pad: getComputedStyle(e).paddingTop, h2: getComputedStyle(e.querySelector('h2')!).fontSize, bg: btn.backgroundColor, minW: btn.minWidth };
    });
    expect(Math.abs(r.cx - 180)).toBeLessThan(2);
    expect(Math.abs(r.cy - 400)).toBeLessThan(2);
    expect(r.pad).toBe('30px');
    expect(r.h2).toBe('40px');
    expect(r.bg).toBe('rgb(1, 2, 3)');
    // The fixture's `#ui button { min-width: 300px }` would reach it in #ui; here it would not anyway, so check in #ui too
    await t(page, (t) => t.results());
    expect(await page.locator('#ui [data-gp=results] .gp-primary').evaluate((e) => getComputedStyle(e).minWidth)).toBe('0px');
    expect(await page.evaluate(() => document.head.firstElementChild?.id)).toBe('gp-results-css');
    await page.close();
  });

  it('the big button continues play (data-gp="again"), Menu is small; the next goal and its share are shown', async () => {
    const page = await open();
    await t(page, (t) => t.results());
    const size = (sel: string) => page.locator(sel).evaluate((e) => {
      const r = e.getBoundingClientRect();
      return { w: r.width, h: r.height, left: r.left, right: r.right };
    });
    const again = await size('[data-gp=again]');
    const menu = await size('[data-gp=menu]');
    expect(again.w * again.h).toBeGreaterThan(menu.w * menu.h * 1.5);
    expect(again.h).toBeGreaterThanOrEqual(64);
    expect(menu.h).toBeGreaterThanOrEqual(48);
    expect(again.left).toBeGreaterThanOrEqual(0);
    expect(again.right).toBeLessThanOrEqual(360);
    expect(await page.locator('[data-gp=again]').innerText()).toContain('Play again');
    expect(await page.locator('[data-gp=results-goal]').innerText()).toMatch(/Next goal[\s\S]*Star[\s\S]*82\s%[\s\S]*9 coins to go/i);
    // The game's hostile #ui button styles don't reach it (magenta)
    expect(await page.locator('[data-gp=again]').evaluate((e) => getComputedStyle(e).backgroundColor)).not.toBe('rgb(255, 0, 255)');
    expect(await t(page, (t) => t.host.events.log.filter((e: any) => e.type === 'screen').map((e: any) => e.data.name))).toEqual(['results']);
    await page.tap('[data-gp=again]');
    await sleep(100);
    expect(await t(page, (t) => t.log.slice())).toEqual(['primary']);
    await page.close();
  });

  it('auto-continue: "Next in 3", then the next run by itself; a tap on the screen stops it', async () => {
    const page = await open();
    await t(page, (t) => t.results({ primary: 'next', autoContinueSec: 1 }));
    expect(await page.locator('[data-gp=next]').innerText()).toMatch(/Next[\s\S]*Next in 1/);
    await sleep(1400);
    expect(await t(page, (t) => t.log.slice())).toEqual(['primary']);
    await t(page, (t) => t.results({ primary: 'next', autoContinueSec: 1 }));
    await page.locator('[data-gp=results] h2').tap();
    await sleep(1400);
    expect(await t(page, (t) => t.log.slice())).toEqual(['primary']);
    await page.close();
  });

  it('the auto-continue stands still while the host is paused, and stops when the game replaces the screen', async () => {
    const page = await open();
    await t(page, (t) => {
      t.results({ primary: 'next', autoContinueSec: 1 });
      Object.defineProperty(document, 'hidden', { configurable: true, get: () => true });
      document.dispatchEvent(new Event('visibilitychange'));
    });
    await sleep(1400);
    expect(await t(page, (t) => t.log.slice())).toEqual([]);
    await t(page, (t) => t.ui.replaceChildren());
    await t(page, () => {
      Object.defineProperty(document, 'hidden', { configurable: true, get: () => false });
      document.dispatchEvent(new Event('visibilitychange'));
    });
    await sleep(1400);
    expect(await t(page, (t) => t.log.slice())).toEqual([]);
    await page.close();
  });
});

describe('welcomeBack()', () => {
  it("a modal card with today's daily and the goal left; its big button plays, × closes", async () => {
    const page = await open();
    await t(page, (t) => t.welcome());
    const card = page.locator('[data-gp=welcome]');
    expect(await card.innerText()).toMatch(/Welcome back![\s\S]*Today's challenge is ready[\s\S]*50\s%[\s\S]*Star/);
    expect(await card.getAttribute('aria-modal')).toBe('true');
    const go = await page.locator('[data-gp=welcome-continue]').boundingBox();
    expect(go!.height).toBeGreaterThanOrEqual(56);
    await page.tap('[data-gp=welcome-continue]');
    expect(await card.count()).toBe(0);
    await t(page, (t) => t.welcome({ resume: true }));
    expect(await page.locator('[data-gp=welcome-continue]').innerText()).toBe('Continue your run');
    await page.tap('[data-gp=welcome-close]');
    expect(await t(page, (t) => t.log.slice())).toEqual(['continue', 'close']);
    // extra: an offline-earnings ×2 above the big button
    await t(page, (t) => t.welcome({ extra: [Object.assign(document.createElement('button'), { textContent: '▶ Double it' })] }));
    expect(await card.innerText()).toMatch(/Double it[\s\S]*Play/);
    await page.close();
  });
});

describe('mountStreakCard()', () => {
  for (const viewport of [{ width: 360, height: 800 }, { width: 800, height: 360 }, { width: 1280, height: 720 }])
    it(`the week on one screen at ${viewport.width}×${viewport.height}: claim once, tomorrow's reward, × closes`, async () => {
      const page = await open('', viewport);
      await t(page, (t) => {
        t.streak(3);
      });
      const card = page.locator('[data-gp=streak]');
      const box = (await card.boundingBox())!;
      expect(box.y).toBeGreaterThanOrEqual(0);
      expect(box.y + box.height).toBeLessThanOrEqual(viewport.height);
      expect(box.x + box.width).toBeLessThanOrEqual(viewport.width);
      // No scrolling inside, the seven dots in one row
      expect(await card.evaluate((e) => e.scrollHeight <= e.clientHeight + 1)).toBe(true);
      const tops = await page.locator('[data-gp=streak-dots] > *').evaluateAll((els) => els.map((e) => Math.round(e.getBoundingClientRect().top)));
      expect(tops.length).toBe(7);
      expect(new Set(tops).size).toBe(1);
      expect(await page.locator('.gp-s-dot[data-state=claimed]').count()).toBe(2);
      const claim = page.locator('[data-gp=streak-claim]');
      expect(((await claim.boundingBox())!).height).toBeGreaterThanOrEqual(56);
      expect(await claim.innerText()).toMatch(/Claim\s+150/);
      expect(await page.locator('[data-gp=streak-tomorrow]').innerText()).toMatch(/Tomorrow:\s+200/);
      await claim.click();
      await claim.click({ force: true }); // a second tap pays nothing (aria-disabled)
      expect(await claim.innerText()).toBe('Claimed');
      // Drawn marks, not glyphs: the check on the button and on each claimed day, the coin on the others
      expect(await claim.locator('svg[data-icon=check]').count()).toBe(1);
      expect(await page.locator('.gp-s-dot[data-state=claimed] svg[data-icon=check]').count()).toBe(3);
      expect(await page.locator('.gp-s-dot:not([data-state=claimed]) svg[data-icon=coin]').count()).toBe(4);
      expect(await page.locator('[data-gp=streak-close] svg[data-icon=close]').count()).toBe(1);
      expect(await page.locator('.gp-s-dot[data-state=claimed]').count()).toBe(3);
      await page.click('[data-gp=streak-close]');
      expect(await card.count()).toBe(0);
      expect(await t(page, (t) => t.log.slice())).toEqual(['claim 150', 'close']);
      // Never before the first play; claimed today: only with force (a look at the week)
      expect(await t(page, (t) => t.streak(1, {}, { played: false }) === null)).toBe(true);
      expect(await t(page, (t) => t.streak(3, {}, { claimToday: true }) === null)).toBe(true);
      expect(await t(page, (t) => t.streak(3, { force: true }, { claimToday: true }) === null)).toBe(false);
      expect(await page.locator('[data-gp=streak-claim]').innerText()).toBe('Claimed');
      await page.close();
    });

  it('every language fits: no day label or amount spills out of its dot at 360×800', async () => {
    for (const lang of ['de', 'pl', 'ru', 'fr', 'tr', 'id', 'ja', 'pt-BR']) {
      const page = await open(`?lang=${lang}`);
      await t(page, (t) => {
        t.streak(7);
      });
      const spill = await page.locator('.gp-s-dot > *').evaluateAll((els) => els.filter((e) => e.scrollWidth > e.parentElement!.clientWidth + 1).map((e) => e.textContent));
      expect(spill, lang).toEqual([]);
      // QA's smallest text (MIN_TEXT_PX, 12 px): Frankengun had to override the day labels' 10 px in its own CSS
      const small = await page.locator('[data-gp=streak] *').evaluateAll((els) => els.filter((e) => e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent!.trim()) && parseFloat(getComputedStyle(e).fontSize) < 12).map((e) => e.textContent));
      expect(small, lang).toEqual([]);
      // …and at 12 px a day label may wrap between its words, never inside one ("Dzie|ń 1")
      const broken = await page.locator('.gp-s-dot small').evaluateAll((els) =>
        els
          .filter((e) =>
            e.textContent!.split(/\s+/).some((word) => {
              const w = Object.assign(document.createElement('small'), { textContent: word });
              w.style.cssText = 'position:absolute; white-space:nowrap';
              e.parentElement!.append(w);
              const wide = w.getBoundingClientRect().width > e.clientWidth + 0.5;
              w.remove();
              return wide;
            }),
          )
          .map((e) => e.textContent),
      );
      expect(broken, lang).toEqual([]);
      const card = (await page.locator('[data-gp=streak]').boundingBox())!;
      expect(card.y + card.height, lang).toBeLessThanOrEqual(800);
      await page.close();
    }
  });
});

describe('screenTheme: one look for every platform screen', () => {
  it("the results, welcome and streak cards take the theme; a screen's own variable still wins; undo restores the stock look", async () => {
    const page = await open();
    const look = () =>
      page.evaluate(() => {
        const s = (sel: string) => (document.querySelector(sel) ? getComputedStyle(document.querySelector(sel)!) : null);
        return {
          results: s('#gp-results')?.backgroundColor,
          primary: s('#gp-results .gp-primary')?.backgroundColor,
          font: s('#gp-results')?.fontFamily,
          title: s('#gp-results h2')?.fontFamily,
          radius: s('#gp-results')?.borderTopLeftRadius,
          welcome: s('#gp-welcome')?.backgroundColor,
          veil: s('#gp-welcome-veil')?.backgroundColor,
        };
      });
    await t(page, (t) => {
      t.results();
      t.welcome();
    });
    const stock = await look();
    expect(stock.results).toBe('rgba(16, 26, 38, 0.92)');
    expect(stock.primary).toBe('rgb(255, 209, 102)');
    const undo = await t(page, (t) => {
      (window as any).__undo = t.screenTheme({ bg: '#123456', accent: '#ff00aa', accentInk: '#ffffff', radius: 6, font: '"Test Face"', display: '"Test Display"', backdrop: 'rgba(1, 2, 3, 0.5)' });
      return typeof (window as any).__undo;
    });
    expect(undo).toBe('function');
    const themed = await look();
    expect(themed.results).toBe('rgb(18, 52, 86)');
    expect(themed.welcome).toBe('rgb(18, 52, 86)');
    expect(themed.primary).toBe('rgb(255, 0, 170)');
    expect(themed.radius).toBe('6px');
    expect(themed.veil).toBe('rgba(1, 2, 3, 0.5)');
    expect(themed.font).toMatch(/^"Test Face", /);
    expect(themed.title).toMatch(/^"Test Display", /);
    // The streak card opened after the theme wears it too
    await t(page, (t) => {
      t.streak(2);
    });
    expect(await page.evaluate(() => getComputedStyle(document.querySelector('#gp-streak')!).backgroundColor)).toBe('rgb(18, 52, 86)');
    // A game's own per-screen variable wins over the theme
    await page.addStyleTag({ content: '#gp-results { --gp-results-bg: #010203; }' });
    expect((await look()).results).toBe('rgb(1, 2, 3)');
    expect((await look()).welcome).toBe('rgb(18, 52, 86)');
    await page.evaluate(() => (window as any).__undo());
    expect((await look()).welcome).toBe('rgb(24, 38, 58)');
    expect((await look()).primary).toBe('rgb(255, 209, 102)');
    await page.close();
  });
});
