// Test page for mountSitesMap (packages/core/test-browser/sites-map.test.ts): not a game, just the map over a Sites with
// a state the test sets through the query and reads through window.__map.
//   ?coins=500        the wallet
//   ?open=corner,mill sites bought already (the shed is free)
//   ?views=2          a second view (space) whose pin moves on an orbit — else one view (a town), as most games have
//   ?lang=ru          the platform's words in another language
//   ?crowd=1          the town's pins crowded together and one on the view's very edge (no padding around the view)
import { byLanguage, createI18n, LANGUAGE_CODES, mountSitesMap, PLATFORM_STRINGS, Sites, UpgradeShop, type SitesMapView } from '../../src/index';

const q = new URLSearchParams(location.search);
type S = 'shed' | 'corner' | 'mill' | 'harbor' | 'moon';
const shop = new UpgradeShop<'workers'>([{ id: 'workers', max: 20, baseCost: 10, growth: 1.3 }]);
const sites = new Sites<S, 'workers'>(
  [
    { id: 'shed', price: 0 },
    { id: 'corner', price: 300 },
    { id: 'mill', price: 1500, requires: 'corner' },
    { id: 'harbor', price: 9000, requires: 'mill' },
    { id: 'moon', price: 50_000, tier: 3 },
  ],
  { shop, rate: (_s, l) => l.workers * 1.5, start: () => ({ workers: 1 }) },
);
sites.coins = 100_000;
for (const id of (q.get('open') ?? '').split(',').filter(Boolean) as S[]) sites.unlock(id);
sites.setLevels('shed', { workers: 3 });
sites.coins = Number(q.get('coins') ?? 500);

const log: string[] = [];
const town: SitesMapView<S> = {
  id: 'town',
  label: 'Town',
  aspect: 1.6,
  // The game's own painting: grass, a river, roads
  draw(g, w, h, _t, cam) {
    g.fillStyle = '#3f7d4a';
    g.fillRect(cam.visible.x, cam.visible.y, cam.visible.w, cam.visible.h);
    g.fillStyle = '#7ec850';
    g.fillRect(0, 0, w, h);
    g.fillStyle = '#3a8fd6';
    g.fillRect(w * 0.62, 0, w * 0.08, h);
    g.strokeStyle = '#d9c7a0';
    g.lineWidth = 6;
    g.beginPath();
    g.moveTo(0, h * 0.5);
    g.lineTo(w, h * 0.5);
    g.stroke();
  },
  pins:
    q.get('crowd') === '1'
      ? { shed: { x: 0, y: 0.3 }, corner: { x: 0.5, y: 0.5 }, mill: { x: 0.52, y: 0.51 }, harbor: { x: 0.54, y: 0.49 } }
      : { shed: { x: 0.15, y: 0.3 }, corner: { x: 0.4, y: 0.7 }, mill: { x: 0.55, y: 0.25 }, harbor: { x: 0.85, y: 0.7 } },
  ...(q.get('crowd') === '1' ? { pad: 0 } : {}),
};
const space: SitesMapView<S> = {
  id: 'space',
  label: 'Space',
  icon: '🪐',
  background: '#050816',
  draw(g, w, h, t) {
    g.fillStyle = '#ffd34a';
    g.beginPath();
    g.arc(w / 2, h / 2, Math.min(w, h) * 0.06, 0, Math.PI * 2);
    g.fill();
    g.strokeStyle = 'rgba(160,190,255,0.3)';
    g.beginPath();
    g.ellipse(w / 2, h / 2, w * 0.3, h * 0.3, 0, 0, Math.PI * 2);
    g.stroke();
    void t;
  },
  // A pin that moves: the moon base on its orbit
  pins: (t) => ({ moon: { x: 0.5 + 0.3 * Math.cos(t * 0.2), y: 0.5 + 0.3 * Math.sin(t * 0.2) } }),
};
const i18n = q.get('lang') ? createI18n({ strings: byLanguage(PLATFORM_STRINGS), languages: LANGUAGE_CODES, lang: q.get('lang')! }) : undefined;
const map = mountSitesMap(document.getElementById('ui')!, sites, {
  views: q.get('views') === '2' ? [town, space] : [town],
  items: {
    shed: { name: 'Old Shed', icon: '🛖', badge: () => `👷 ${sites.levels('shed').workers}` },
    corner: { name: 'Corner Shop' },
    mill: { name: 'Mill', icon: '🌾' },
    harbor: { name: 'Harbor', icon: '⚓' },
    moon: { name: 'Moon Base', icon: '🌙' },
  },
  minTouchPx: 48,
  ...(i18n ? { i18n } : {}),
  onEnter: (id) => log.push(`enter:${id}`),
  onDenied: (id) => log.push(`deny:${id}`),
  onBack: () => log.push('back'),
  onView: (id) => log.push(`view:${id}`),
});
(window as unknown as { __map: unknown }).__map = { sites, log, map };
