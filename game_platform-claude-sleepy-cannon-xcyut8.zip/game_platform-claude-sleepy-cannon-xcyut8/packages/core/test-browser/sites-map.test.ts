// Browser test of the sites map (mountSitesMap) of an idle game: pins from Sites, tap to enter or open, pan, wheel and
// pinch zoom, the switch between views, and the kit-code QA one-screen checks (no panel or page scroll, every button on
// screen and ≥ minTouchPx, no text cut) at a phone, a phone on its side and a desktop.
// Runs with `npm run test:browser` (needs Playwright's Chromium). The fixture page carries a game's hostile button CSS.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { panelScrolls, tappables, textFit } from '../../kit-code/qa/suite.ts';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./sites-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

async function open(query = '', viewport = { width: 360, height: 800 }): Promise<Page> {
  const page = await browser.newPage({ viewport, hasTouch: true });
  await page.goto(`${base}?${query}`);
  await page.waitForSelector('[data-gp=sites-map] [data-gp-site=shed]');
  await page.waitForTimeout(150);
  return page;
}
type W = { __map: { sites: { at: string; coins: number; isOpen(id: string): boolean }; log: string[]; map: { view: string; camera: { zoom: number; x: number; y: number } } } };
const log = (page: Page) => page.evaluate(() => (window as unknown as W).__map.log.slice());
const cam = (page: Page) => page.evaluate(() => ({ ...(window as unknown as W).__map.map.camera }));
const pin = (page: Page, id: string, view = 'town') => page.locator(`.gp-pins[data-view=${view}] [data-gp-site=${id}]`);
/** A pin's caption (its name and line) */
const cap = (page: Page, id: string, view = 'town') => page.locator(`.gp-pins[data-view=${view}] [data-gp-cap=${id}]`);

describe('mountSitesMap', () => {
  it('a pin per site of the view: open ones with their level, income and badge; the next one with its price; locked ones closed', async () => {
    const page = await open('coins=500');
    expect(await page.locator('.gp-pins[data-view=town] [data-gp-site]').evaluateAll((els) => els.map((e) => [(e as HTMLElement).dataset.gpSite, (e as HTMLElement).dataset.state]))).toEqual([
      ['shed', 'open'],
      ['corner', 'affordable'],
      ['mill', 'locked'],
      ['harbor', 'locked'],
    ]);
    const shed = await cap(page, 'shed').innerText();
    expect(shed).toContain('Old Shed');
    expect(shed).toContain('Lv 3');
    expect(shed).toContain('+4/s'); // 3 workers × 1.5, rounded down
    expect(shed).toContain('👷 3');
    expect(await pin(page, 'shed').getAttribute('aria-current')).toBe('location');
    expect(await cap(page, 'corner').innerText()).toMatch(/Corner Shop\s+300/);
    // A locked pin shows only its head: the map stays readable
    expect(await cap(page, 'mill').isVisible()).toBe(false);
    expect(await pin(page, 'mill').isVisible()).toBe(true);
    expect(await page.locator('[data-gp=sites-balance]').innerText()).toBe('500');
    expect(await page.locator('[data-gp=sites-rate]').innerText()).toBe('+4/s');
    // One view: no switcher
    expect(await page.locator('#gp-sites footer').isVisible()).toBe(false);
    await page.close();
  });

  it('a tap on an open pin enters it; on a closed one opens its card: Open buys it and enters, what is too dear says no', async () => {
    const page = await open('coins=500&open=corner');
    await pin(page, 'corner').tap();
    expect(await log(page)).toEqual(['enter:corner']);
    expect(await page.evaluate(() => (window as unknown as W).__map.sites.at)).toBe('corner');
    // The mill: affordable (1500 needs more) — too expensive at 500
    await pin(page, 'mill').tap();
    await page.waitForSelector('[data-gp=sites-card]');
    expect(await page.locator('[data-gp=sites-card]').innerText()).toMatch(/Mill[\s\S]*Need\s1\.00K/);
    expect(await page.getAttribute('[data-gp=sites-open]', 'aria-disabled')).toBe('true');
    await page.tap('[data-gp=sites-open]', { force: true });
    expect(await log(page)).toContain('deny:mill');
    await page.tap('[data-gp=sites-card-close]');
    expect(await page.locator('[data-gp=sites-card]').isVisible()).toBe(false);
    // A locked one says what opens it, with no button
    await pin(page, 'harbor').tap();
    expect(await page.locator('[data-gp=sites-card]').innerText()).toContain('Needs Mill');
    expect(await page.locator('[data-gp=sites-open]').isVisible()).toBe(false);
    await page.close();

    const rich = await open('coins=2000&open=corner');
    await pin(rich, 'mill').tap();
    await rich.tap('[data-gp=sites-open]');
    expect(await log(rich)).toEqual(['enter:mill']);
    const st = await rich.evaluate(() => ({ coins: (window as unknown as W).__map.sites.coins, open: (window as unknown as W).__map.sites.isOpen('mill') }));
    expect(st).toEqual({ coins: 500, open: true });
    await rich.waitForTimeout(300);
    expect(await pin(rich, 'mill').getAttribute('data-state')).toBe('open');
    // The harbor needed the mill: now it is the next one, with its price
    expect(await pin(rich, 'harbor').getAttribute('data-state')).toBe('too-expensive');
    expect(await cap(rich, 'harbor').innerText()).toMatch(/Harbor\s+9\.00K/);
    await rich.close();
  });

  it('the wheel zooms about the cursor and a drag pans; a drag that starts on a pin does not enter it', async () => {
    const page = await open('coins=0', { width: 1280, height: 720 });
    const c0 = await cam(page);
    expect(c0.zoom).toBe(1);
    const stage = (await page.locator('[data-gp=sites-stage]').boundingBox())!;
    await page.mouse.move(stage.x + stage.width * 0.3, stage.y + stage.height * 0.4);
    await page.mouse.wheel(0, -400);
    await page.waitForTimeout(100);
    const c1 = await cam(page);
    expect(c1.zoom).toBeGreaterThan(1.5);
    // Drag from the shed's pin to the right: the map moves, nothing is entered
    const p = (await pin(page, 'shed').boundingBox())!;
    await page.mouse.move(p.x + p.width / 2, p.y + 20);
    await page.mouse.down();
    await page.mouse.move(p.x + p.width / 2 + 80, p.y + 40, { steps: 6 });
    await page.mouse.up();
    const c2 = await cam(page);
    expect(c2.x).toBeLessThan(c1.x);
    expect(await log(page)).toEqual([]);
    // + and − buttons
    await page.click('[data-gp=sites-zoom-out]');
    await page.click('[data-gp=sites-zoom-out]');
    await page.click('[data-gp=sites-zoom-out]');
    expect((await cam(page)).zoom).toBe(1);
    await page.click('[data-gp=sites-zoom-in]');
    expect((await cam(page)).zoom).toBeCloseTo(1.4);
    await page.close();
  });

  it('two fingers pinch to zoom', async () => {
    const page = await open('coins=0');
    const r = (await page.locator('[data-gp=sites-stage]').boundingBox())!;
    await page.evaluate(
      ({ r }) => {
        const stage = document.querySelector('[data-gp=sites-stage]')!;
        const cx = r.x + r.width / 2;
        const cy = r.y + r.height / 2;
        const ev = (type: string, id: number, x: number) =>
          stage.dispatchEvent(new PointerEvent(type, { pointerId: id, pointerType: 'touch', clientX: x, clientY: cy, bubbles: true, isPrimary: id === 1 }));
        ev('pointerdown', 1, cx - 40);
        ev('pointerdown', 2, cx + 40);
        for (let i = 1; i <= 10; i++) {
          ev('pointermove', 1, cx - 40 - 8 * i);
          ev('pointermove', 2, cx + 40 + 8 * i);
        }
        ev('pointerup', 1, cx - 120);
        ev('pointerup', 2, cx + 120);
      },
      { r },
    );
    expect((await cam(page)).zoom).toBeCloseTo(3, 1); // 80 px apart → 240 px apart
    expect(await log(page)).toEqual([]);
    await page.close();
  });

  it('two views: a tab for each, a cross-fade between them, only the shown view\'s pins on screen; a pin may move', async () => {
    const page = await open('coins=0&views=2');
    expect(await page.locator('#gp-sites footer [data-gp-view]').evaluateAll((els) => els.map((e) => (e as HTMLElement).dataset.gpView))).toEqual(['town', 'space']);
    expect(await pin(page, 'moon', 'space').isVisible()).toBe(false);
    await page.tap('[data-gp-view=space]');
    await page.waitForTimeout(80);
    // Mid-fade both layers show, partly
    const mid = await page.evaluate(() => [...document.querySelectorAll<HTMLElement>('.gp-pins')].map((l) => Number(l.style.opacity)));
    expect(mid[0]).toBeGreaterThan(0);
    expect(mid[1]).toBeLessThan(1);
    await page.waitForTimeout(500);
    expect(await page.evaluate(() => [...document.querySelectorAll<HTMLElement>('.gp-pins')].map((l) => l.style.opacity))).toEqual(['0', '1']);
    expect(await log(page)).toEqual(['view:space']);
    expect(await page.getAttribute('[data-gp-view=space]', 'aria-pressed')).toBe('true');
    expect(await pin(page, 'moon', 'space').isVisible()).toBe(true);
    expect(await pin(page, 'shed').isVisible()).toBe(false);
    const a = (await pin(page, 'moon', 'space').boundingBox())!;
    await page.waitForTimeout(700);
    const b = (await pin(page, 'moon', 'space').boundingBox())!;
    expect(Math.hypot(a.x - b.x, a.y - b.y)).toBeGreaterThan(1);
    await page.close();
  });

  for (const vp of [{ width: 360, height: 800 }, { width: 800, height: 360 }, { width: 1280, height: 720 }])
    it(`one screen at ${vp.width}×${vp.height}: no panel or page scroll, every button on screen and ≥ 48 px, no text cut — zoomed in too`, async () => {
      const page = await open('coins=500&views=2&open=corner', vp);
      const check = async () => {
        const [tap, fit, panels] = [await tappables(page, 48), await textFit(page), await panelScrolls(page)];
        return { tap: tap.bad, offscreen: fit.offscreen, clipped: fit.clipped, spills: fit.spills, scroll: fit.scroll, panels: panels.bad, count: tap.count };
      };
      const clean = { tap: [], offscreen: [], clipped: [], spills: [], scroll: false, panels: [] };
      const r0 = await check();
      expect({ ...r0, count: undefined }).toEqual({ ...clean, count: undefined });
      expect(r0.count).toBeGreaterThanOrEqual(7); // 4 pins, zoom ±, back, 2 tabs
      await page.screenshot({ path: `${process.env.SHOP_SHOTS ?? '/tmp'}/sites-map-${vp.width}x${vp.height}.png` });
      // Zoomed in, pins near the edges are hidden rather than cut
      for (let i = 0; i < 4; i++) await page.tap('[data-gp=sites-zoom-in]');
      await page.waitForTimeout(100);
      const r1 = await check();
      expect({ ...r1, count: undefined }).toEqual({ ...clean, count: undefined });
      // The card of a closed site fits too
      await page.click('[data-gp=sites-zoom-out]');
      await page.click('[data-gp=sites-zoom-out]');
      await page.click('[data-gp=sites-zoom-out]');
      await page.click('[data-gp=sites-zoom-out]');
      await pin(page, 'mill').tap({ force: true });
      const r2 = await check();
      expect({ ...r2, count: undefined }).toEqual({ ...clean, count: undefined });
      await page.close();
    });

  for (const vp of [{ width: 360, height: 800 }, { width: 1280, height: 720 }])
    it(`crowded pins at ${vp.width}×${vp.height}: no caption on another caption or a head; a pin on the view's edge shows inside, not cut or hidden`, async () => {
      const page = await open('coins=500&open=corner&crowd=1', vp);
      const boxes = () =>
        page.evaluate(() => {
          const stage = document.querySelector('[data-gp=sites-stage]')!.getBoundingClientRect();
          const vis = (e: Element) => getComputedStyle(e).visibility === 'visible' && !(e as HTMLElement).hidden;
          const rect = (e: Element) => {
            const r = e.getBoundingClientRect();
            return { x: r.x - stage.x, y: r.y - stage.y, w: r.width, h: r.height };
          };
          const layer = document.querySelector('.gp-pins[data-view=town]')!;
          return {
            W: stage.width,
            H: stage.height,
            heads: [...layer.querySelectorAll('[data-gp-site]')].filter(vis).map((e) => ({ id: (e as HTMLElement).dataset.gpSite!, ...rect(e) })),
            caps: [...layer.querySelectorAll('[data-gp-cap]')].filter(vis).map((e) => ({ id: (e as HTMLElement).dataset.gpCap!, ...rect(e) })),
          };
        });
      type B = { x: number; y: number; w: number; h: number };
      const hit = (a: B, b: B) => a.x < b.x + b.w - 0.5 && b.x < a.x + a.w - 0.5 && a.y < b.y + b.h - 0.5 && b.y < a.y + a.h - 0.5;
      const b = await boxes();
      expect(b.heads.map((h) => h.id).sort()).toEqual(['corner', 'harbor', 'mill', 'shed']);
      for (const h of b.heads) {
        expect(h.x).toBeGreaterThanOrEqual(3.5);
        expect(h.y).toBeGreaterThanOrEqual(3.5);
        expect(h.x + h.w).toBeLessThanOrEqual(b.W - 3.5);
        expect(h.y + h.h).toBeLessThanOrEqual(b.H - 3.5);
      }
      // The player's site keeps its caption; the others where there is room
      expect(b.caps.map((c) => c.id)).toContain('shed');
      for (const c of b.caps) {
        for (const d of b.caps) if (c !== d) expect(hit(c, d), `${c.id} on ${d.id}`).toBe(false);
        for (const h of b.heads) expect(hit(c, h), `${c.id}'s caption on the ${h.id} pin`).toBe(false);
      }
      await page.screenshot({ path: `${process.env.SHOP_SHOTS ?? '/tmp'}/sites-map-crowd-${vp.width}x${vp.height}.png` });
      // A locked pin shows no caption until it is selected; selected, it shows one even in the crowd
      expect(b.caps.map((c) => c.id)).not.toContain('harbor');
      // (its head is under the others' in this crowd: a tap there takes the top one, so the click goes to it directly)
      await pin(page, 'harbor').dispatchEvent('click');
      await page.waitForTimeout(350);
      const sel = await boxes();
      expect(sel.caps.map((c) => c.id)).toContain('harbor');
      for (const c of sel.caps) for (const d of sel.caps) if (c !== d) expect(hit(c, d), `${c.id} on ${d.id}`).toBe(false);
      await page.close();
    });

  it("the platform's words in the player's language", async () => {
    const page = await open('coins=500&lang=ru');
    expect(await page.locator('#gp-sites h2').innerText()).toBe('Карта');
    expect(await cap(page, 'shed').innerText()).toContain('Ур. 3');
    expect(await page.locator('[data-gp=sites-rate]').innerText()).toBe('+4/с');
    await page.close();
  });
});
