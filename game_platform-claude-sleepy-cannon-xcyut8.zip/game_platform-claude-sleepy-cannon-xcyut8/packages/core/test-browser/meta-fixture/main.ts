// Test page for the meta screens and helpers (goals, album, rewards hub, inspect plates, the coach hand, the one-card
// queue): not a game — each `?screen=` mounts one over a state the query sets; the tests read window.__meta.
import {
  achievements,
  byLanguage,
  cards,
  coachHand,
  collection,
  createI18n,
  dailyOffers,
  dailyQuests,
  dailyStreak,
  goalBanners,
  hints,
  inspect,
  luckyWheel,
  mountAlbum,
  mountGoals,
  mountRewardsHub,
  mountStreakCard,
  PLATFORM_STRINGS,
  playtimeGifts,
  timedBoost,
  welcomeBack,
  type CollectionEntry,
  type QuestDef,
} from '../../src/index';

const q = new URLSearchParams(location.search);
const lang = q.get('lang') ?? 'en';
const i18n = createI18n({ strings: [byLanguage(PLATFORM_STRINGS)], lang });
const log: string[] = [];
const ui = document.getElementById('ui')!;
const day = (d: number) => new Date(2026, 9, d, 12).getTime();
const clock = { t: day(Number(q.get('day') ?? 5)) };
const now = () => clock.t;
const host = {
  minTouchPx: 48,
  screen: (n: string) => log.push(`screen:${n}`),
  t: (k: string, p?: Record<string, string | number>) => i18n.t(k, p),
  i18n,
  rewardedAvailable: q.get('ads') !== 'none',
  adPending: false,
  rewarded: async (placement: string) => {
    log.push(`ad:${placement}`);
    return q.get('ads') !== 'fail';
  },
};
if (q.get('theme') === '1') {
  const st = document.createElement('style');
  // The shared base (screenTheme) and a screen's own variable: the own one wins over the base
  st.textContent = ':root { --gp-theme-bg: rgb(1, 2, 3); --gp-theme-accent: rgb(4, 5, 6); } #gp-album { --gp-album-bg: rgb(7, 8, 9); }';
  document.head.append(st);
}
const svg = (color: string) => `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8"><circle cx="4" cy="4" r="3.5" fill="${color}"/></svg>`)}`;
const GEM = svg('#5ad');
const COIN = svg('gold');
const out: Record<string, unknown> = { log };
const screen = q.get('screen');

if (screen === 'goals' || screen === 'cards') {
  type Id = 'blocks' | 'chests' | 'merges' | 'items' | 'taps' | 'forge';
  const POOL: QuestDef<Id, number>[] = [
    { id: 'blocks', need: 120, reward: 15 },
    { id: 'chests', need: 15, reward: 15 },
    { id: 'merges', need: 5, reward: 15 },
    { id: 'items', need: 4, reward: 10 },
    { id: 'taps', need: 50, reward: 10 },
    { id: 'forge', need: 4, reward: 10 },
  ];
  const save: Record<string, unknown> = {};
  if (q.get('carry') === '1') clock.t = day(4);
  const quests = dailyQuests<Id>(save, { pool: POOL, perDay: 3, bonus: 25, salt: 'fixture', now });
  const done = Number(q.get('done') ?? (q.get('carry') === '1' ? 3 : 0));
  quests.state().quests.slice(0, done).forEach((r) => quests.add(r.id, r.need));
  if (q.get('carry') === '1') clock.t = day(5);
  const first = quests.state().quests[0];
  quests.add(first.id, Math.floor(first.need / 2) || 0);
  type Stats = { runs: number };
  const ach = achievements<Stats, number>(save, {
    list: Array.from({ length: 14 }, (_, i) => ({
      id: `a${i + 1}`,
      rarity: (['common', 'rare', 'epic', 'legendary'] as const)[i % 4],
      hidden: i === 5 || i === 13,
      test: (s: Stats) => s.runs > i,
      progress: (s: Stats) => s.runs / (i + 1),
      ...(i === 1 ? { reward: 40 } : {}),
    })),
    now,
  });
  const stats = { runs: Number(q.get('got') ?? 0) };
  ach.check(stats);
  const open = () =>
    mountGoals(ui, {
      host,
      quests,
      achievements: ach,
      ctx: stats,
      questText: (id, need) => `${id === 'blocks' ? 'Break' : 'Do'} ${need} ${id}`,
      achievement: (id) => ({ name: `Achievement ${id.slice(1)}`, text: `What ${id} asks of the player`, icon: id === 'a1' ? COIN : undefined }),
      view: (r) => ({ icon: GEM, label: String(r) }),
      onClaim: (cs) => log.push(`claim:${cs.map((c) => `${c.kind}:${c.id || 'bonus'}=${c.reward}`).join(',')}`),
      onClose: () => log.push('close'),
      tab: (q.get('tab') as 'quests' | 'achievements' | null) ?? undefined,
      texts: lang === 'en' ? undefined : undefined,
    });
  out.quests = quests;
  out.ach = ach;
  out.stats = stats;
  out.banners = goalBanners({ host, root: ui });
  if (screen === 'goals') out.screen = open();
  else {
    // The title of a returning player on a new day: the welcome card, the week and the goals all want it — one at a time
    const streak = dailyStreak(save, { reward: (d) => 10 * d, now });
    streak.played();
    out.openGoals = open;
    out.cards = cards;
    cards.offer('streak', () => mountStreakCard(ui, streak, { host, onClaim: (n) => log.push(`streak:${n}`), onClose: () => log.push('streak-close') }));
    cards.offer('goals', () => (quests.state().quests.length ? open() : null));
    cards.offer('welcome', () => welcomeBack({ host, root: ui, onContinue: () => log.push('play'), onClose: () => log.push('welcome-close') }), { priority: 2 });
    cards.offer('nothing', () => null, { priority: 1 });
  }
}

if (screen === 'album') {
  const MATS = ['wood', 'stone', 'copper', 'iron', 'gold', 'emerald', 'diamond', 'ruby', 'obsidian', 'abyssal', 'quantum'];
  const COLORS = ['#a0522d', '#888', '#b87333', '#aab', '#ffd700', '#50c878', '#b9f2ff', '#e0115f', '#3d3553', '#226', '#a6f'];
  const entries: CollectionEntry[] = [
    ...MATS.flatMap((m) => Array.from({ length: 8 }, (_, l) => ({ id: `${m}:${l + 1}`, group: 'picks', row: m, rarity: l >= 6 ? ('epic' as const) : l >= 4 ? ('rare' as const) : ('common' as const), bonus: 0.01 }))),
    ...Array.from({ length: 12 }, (_, i) => ({ id: `fish${i}`, group: 'fish', rarity: i === 11 ? ('legendary' as const) : ('common' as const), secret: i === 11 })),
  ];
  const save: Record<string, unknown> = {};
  const album = collection(save, { entries, now });
  const found = Number(q.get('found') ?? 6);
  album.findAll(entries.slice(0, found).map((e) => e.id));
  album.markSeen(entries.slice(0, Math.max(0, found - 2)).map((e) => e.id));
  out.album = album;
  out.screen = mountAlbum(ui, album, {
    host,
    view: (id, f) => ({ icon: id.startsWith('fish') ? '🐟' : svg(COLORS[MATS.indexOf(id.split(':')[0])]), name: f ? `Pickaxe ${id}` : '?' }),
    rowName: (_g, row) => ({ label: row[0].toUpperCase() + row.slice(1), icon: svg(COLORS[MATS.indexOf(row)]), tint: COLORS[MATS.indexOf(row)] }),
    groupName: (g) => (g === 'picks' ? 'Pickaxes' : 'Fish'),
    onClose: () => log.push('close'),
  });
}

if (screen === 'rewards') {
  type R = { coins?: number; gems?: number; boost?: number };
  const save: Record<string, unknown> = {};
  let gems = Number(q.get('gems') ?? 30);
  const gifts = playtimeGifts<R>(save, {
    gifts: [1, 3, 6, 10, 15, 22, 30].map((min, i) => ({ min, reward: i % 2 ? { gems: 5 * i } : { coins: 100 * (i + 1) } })),
    now,
  });
  gifts.tick(Number(q.get('played') ?? 200));
  const wheel = luckyWheel<R>(save, {
    slices: [{ coins: 120 }, { gems: 5 }, { coins: 300 }, { boost: 600 }, { coins: 800 }, { gems: 20 }, { coins: 2000 }, { gems: 50 }].map((reward, i) => ({ reward, weight: 8 - i })),
    free: 1,
    ad: 1,
    paid: { price: 10, pay: (p) => (gems >= p ? ((gems -= p), true) : false) },
    rand: () => Number(q.get('rand') ?? 0.4),
    now,
  });
  if (q.get('pending') === '1') wheel.spin('free');
  if (q.get('freeUsed') === '1') (wheel.spin('free'), wheel.collect());
  const offers = dailyOffers<R>(save, {
    pool: [5, 8, 12, 20, 35, 40, 45, 90].map((price, i) => ({ id: `o${i}`, price, reward: { coins: price * 40 } })),
    fixed: [{ id: 'boost', price: 25, reward: { boost: 900 } }],
    perDay: 3,
    salt: 'fixture',
    ad: { reward: { gems: 10 }, perDay: 3 },
    now,
  });
  const boost = timedBoost(save, { factor: 2 });
  if (q.get('boost') === '1') boost.add(754);
  out.wheel = wheel;
  out.gifts = gifts;
  out.offers = offers;
  out.gems = () => gems;
  out.screen = mountRewardsHub<R>(ui, {
    host,
    gifts,
    wheel,
    offers,
    boost,
    view: (r) => (r.gems ? { icon: GEM, label: String(r.gems) } : r.boost ? { label: `×2 ${Math.round(r.boost / 60)}m` } : { icon: COIN, label: String(r.coins) }),
    currency: { icon: GEM, amount: () => gems },
    pay: (p) => (gems >= p ? ((gems -= p), true) : false),
    onPrize: (r, from, id) => log.push(`prize:${from}${id ? `:${id}` : ''}:${JSON.stringify(r)}`),
    onClose: () => log.push('close'),
    tab: (q.get('tab') as 'gifts' | 'wheel' | 'offers' | null) ?? undefined,
  });
}

if (screen === 'inspect') {
  const board = document.createElement('div');
  board.id = 'board';
  ui.append(board);
  const tips = hints({ seen: [] });
  out.tips = tips;
  board.addEventListener('pointerup', () => log.push('game-up'));
  board.addEventListener('click', () => log.push('game-click'));
  out.insp = inspect(
    board,
    (x, y) => (x < 150 && y < 150 ? { title: 'Ember bone', text: 'Scores ×2 next to fire.', kind: 'rare' } : y > 250 ? { title: 'Low', text: 'Near the bottom edge of the screen.' } : null),
    { host, tips, onTap: (x, y) => log.push(`tap:${Math.round(x)},${Math.round(y)}`), vibrate: false },
  );
}

if (screen === 'coach') {
  const a = document.createElement('div');
  a.id = 'a';
  const b = document.createElement('div');
  b.id = 'b';
  ui.append(a, b);
  const gesture = (q.get('gesture') ?? 'drag') as 'tap' | 'drag' | 'swipe' | 'hold';
  if (q.get('via') === 'hints') {
    const tips = hints({ seen: [] });
    tips.show('merge', 'Drag onto its twin', { hand: { gesture, from: a, to: b, at: a } });
    out.tips = tips;
  } else out.hand = coachHand({ gesture, at: a, from: a, to: b });
}

(window as unknown as { __meta: unknown }).__meta = out;
document.body.dataset.ready = '1';
