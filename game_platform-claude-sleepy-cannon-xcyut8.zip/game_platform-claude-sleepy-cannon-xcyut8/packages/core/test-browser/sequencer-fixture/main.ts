// Test page for the ScoreSequencer in a real frame loop (packages/core/test-browser/sequencer.test.ts): a chain of steps
// at points close together, played on requestAnimationFrame, its labels as DOM boxes sized by the sequencer (the text
// measured on a canvas), a click fast-forwarding it, a host whose pause the test toggles.
import { previewScore, ScoreSequencer, type ScoreStep } from '../../src/sequencer';

const q = new URLSearchParams(location.search);
const n = Number(q.get('n') ?? 16);
const host = { paused: false };
const font = '800 22px sans-serif';
const g = document.createElement('canvas').getContext('2d')!;
g.font = font;
const steps: ScoreStep[] = Array.from({ length: n }, (_, i) => ({ kind: 'card', at: { x: 380 + (i % 3) * 20, y: 300 }, add: 10 + i, ...(i % 4 === 3 ? { times: 2 } : i % 2 ? { mult: 1 } : {}) }));
const log = { beats: [] as { i: number; t: number; fast: boolean; pitch: number }[], land: null as null | { t: number; total: number; big: number; fast: boolean }, done: null as null | number, rolls: 0, overlaps: 0, overflow: 0, maxLabels: 0 };
const seq = new ScoreSequencer({
  host,
  onStep: (e) => log.beats.push({ i: e.index, t: performance.now(), fast: e.fast, pitch: e.pitch }),
  onRoll: () => log.rolls++,
  onLand: (e) => (log.land = { t: performance.now(), total: e.total, big: e.big, fast: e.fast }),
  onDone: (total) => (log.done = total),
  labels: { size: 22, measure: (text) => g.measureText(text).width + 8, bounds: { w: 800, h: 600 } },
});
const boxes = new Map<number, HTMLDivElement>();

function render(): void {
  const labels = seq.labels();
  log.maxLabels = Math.max(log.maxLabels, labels.length);
  for (const el of boxes.values()) el.remove();
  boxes.clear();
  labels.forEach((l, i) => {
    const el = document.createElement('div');
    el.className = 'label';
    el.textContent = l.text;
    Object.assign(el.style, { left: `${l.x - l.w / 2}px`, top: `${l.y - l.h / 2}px`, width: `${l.w}px`, height: `${l.h}px`, opacity: String(l.alpha) });
    document.body.append(el);
    boxes.set(i, el);
  });
  // What a player sees: no two labels on top of each other, every text inside its box
  const rects = [...boxes.values()].map((el) => el.getBoundingClientRect());
  for (let a = 0; a < rects.length; a++) {
    for (let b = a + 1; b < rects.length; b++) {
      const A = rects[a];
      const B = rects[b];
      if (A.left < B.right - 0.5 && B.left < A.right - 0.5 && A.top < B.bottom - 0.5 && B.top < A.bottom - 0.5) log.overlaps++;
    }
  }
  for (const el of boxes.values()) if (el.scrollWidth > el.clientWidth + 1) log.overflow++;
}

let last = 0;
function frame(t: number): void {
  const dt = last ? (t - last) / 1000 : 0;
  last = t;
  seq.update(dt);
  render();
  requestAnimationFrame(frame);
}
addEventListener('pointerdown', () => seq.skip());
seq.play(steps, { target: 400 });
requestAnimationFrame(frame);
Object.assign(window, { __seq: { log, host, preview: previewScore(steps).total, state: () => seq.state } });
