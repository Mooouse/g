// The start-before-resume trap, on a real AudioContext: music asked to play before the player's first tap (the title's
// music at load) must play at its full level once the context runs — Frankengun's own score stayed near-silent until
// the first pause. createSceneMusic and createMusic, with host.audio null until the tap (GameHost) and with a context
// that is there but suspended. Runs with `npm run test:browser` (Playwright's Chromium, its fake audio output).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./music-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

async function levels(kind: 'scene' | 'theme', when: 'late' | 'suspended'): Promise<{ first: number; after: number; state: string }> {
  const page = await browser.newPage();
  await page.goto(`${base}?kind=${kind}&when=${when}`);
  await page.waitForFunction(() => typeof (window as unknown as { __rms?: unknown }).__rms === 'function');
  // A moment on the title before the tap: the music has been asked for, the context can't run yet
  await page.waitForTimeout(600);
  const state = await page.evaluate(() => (window as unknown as { __state: () => string }).__state());
  await page.click('#tap');
  // The first stretch after the tap (the waiting timer finds the context within ¼ s, the fade-in takes ≤ 1.4 s) …
  await page.waitForTimeout(1600);
  const first = await page.evaluate(() => (window as unknown as { __rms: (s: number) => Promise<number> }).__rms(3));
  // … against the level after a pause and a resume, where Frankengun's score finally came up
  await page.evaluate(() => (window as unknown as { __pause: () => Promise<void> }).__pause());
  await page.waitForTimeout(300);
  await page.evaluate(() => (window as unknown as { __resume: () => Promise<void> }).__resume());
  await page.waitForTimeout(1600);
  const after = await page.evaluate(() => (window as unknown as { __rms: (s: number) => Promise<number> }).__rms(3));
  await page.close();
  return { first, after, state };
}

describe('music asked to play before the first tap', () => {
  for (const kind of ['scene', 'theme'] as const)
    for (const when of ['late', 'suspended'] as const)
      it(`${kind === 'scene' ? 'createSceneMusic' : 'createMusic'}, host.audio ${when === 'late' ? 'null until the tap' : 'there but suspended'}: full level at once, not after a pause`, async () => {
        const r = await levels(kind, when);
        console.log(`${kind} ${when}: first ${r.first.toFixed(4)}, after a pause ${r.after.toFixed(4)}`);
        expect(r.state).toBe('suspended');
        expect(r.after, 'the music plays after a pause and resume').toBeGreaterThan(0.003);
        expect(r.first, `before the first pause: rms ${r.first.toFixed(4)} against ${r.after.toFixed(4)} after it`).toBeGreaterThan(r.after * 0.5);
      }, 30000);
});
