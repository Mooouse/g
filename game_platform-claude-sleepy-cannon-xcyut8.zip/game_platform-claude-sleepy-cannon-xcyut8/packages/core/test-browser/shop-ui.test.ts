// Browser test of the ready shop screen (mountUpgradeShop) against the shop rules in docs/guides/upgrades.md.
// Runs with `npm run test:browser` (needs Playwright's Chromium). The fixture page carries a game's hostile button CSS.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./shop-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

async function open(q: { coins: number; levels?: Record<string, number>; many?: boolean; extra?: string }, viewport = { width: 360, height: 800 }): Promise<Page> {
  const page = await browser.newPage({ viewport, hasTouch: true });
  await page.goto(`${base}?coins=${q.coins}&levels=${encodeURIComponent(JSON.stringify(q.levels ?? {}))}${q.many ? '&many=1' : ''}${q.extra ?? ''}`);
  await page.waitForSelector('[data-gp=shop-screen]');
  return page;
}
const text = (page: Page, sel: string) => page.locator(sel).first().innerText();
const coins = (page: Page) => page.evaluate(() => (window as unknown as { __shop: { state: { coins: number } } }).__shop.state.coins);
const log = (page: Page) => page.evaluate(() => (window as unknown as { __shop: { log: string[] } }).__shop.log.slice());

describe('mountUpgradeShop', () => {
  it('one card per upgrade in definition order, each with effect, now → next, level and price', async () => {
    const page = await open({ coins: 100, levels: { speed: 2 } });
    expect(await page.locator('[data-gp-upgrade]').evaluateAll((els) => els.map((e) => (e as HTMLElement).dataset.gpUpgrade))).toEqual(['speed', 'tiny', 'calm', 'gold']);
    const speed = await text(page, '[data-gp-upgrade=speed]');
    expect(speed).toContain('Move faster');
    expect(speed).toContain('296 px/s → 315 px/s');
    // The level as drawn pips (no ● ○ glyphs): 2 of 8 filled
    expect(await page.getAttribute('[data-gp-upgrade=speed] .gp-pips', 'data-level')).toBe('2/8');
    expect(await page.locator('[data-gp-upgrade=speed] .gp-pips > i').count()).toBe(8);
    expect(await page.locator('[data-gp-upgrade=speed] .gp-pips > i.gp-on').count()).toBe(2);
    expect(await text(page, '[data-gp-buy=speed]')).toContain('13');
    await page.close();
  });

  it('four states told by text, not colour: affordable, too expensive (bar + runs), locked (what unlocks it), max', async () => {
    const page = await open({ coins: 20, levels: { tiny: 6 } });
    expect(await text(page, '[data-gp-upgrade=calm]')).toContain('Needs Flagella');
    expect(await text(page, '[data-gp-upgrade=tiny]')).toContain('Max');
    const gold = await text(page, '[data-gp-upgrade=gold]');
    expect(gold).toMatch(/Need\s*980/);
    // The platform's marks are drawn: the coin, the lock, the check (no 🪙 🔒 ✓)
    expect(await page.locator('[data-gp-upgrade=gold] .gp-line svg[data-icon=coin]').count()).toBe(1);
    expect(await page.locator('[data-gp-upgrade=calm] svg[data-icon=lock]').count()).toBeGreaterThan(0);
    expect(await page.locator('[data-gp-buy=tiny] svg[data-icon=check]').count()).toBe(1);
    expect(await text(page, '[data-gp-upgrade=gold]')).not.toMatch(/[🪙🔒✓●○◀▶]/u);
    expect(gold).toMatch(/≈\s245\sruns/);
    expect(await page.locator('[data-gp-upgrade=gold] .gp-bar').count()).toBe(1);
    expect(await page.getAttribute('[data-gp-buy=speed]', 'aria-disabled')).toBe('false');
    expect(await page.getAttribute('[data-gp-buy=gold]', 'aria-disabled')).toBe('true');
    expect(await page.locator('.gp-tag').count()).toBe(1);
    await page.close();
  });

  it('every button on a 360 px phone is on screen and ≥ 48 px, even under the game\'s own button CSS', async () => {
    const page = await open({ coins: 100 });
    const bad = await page.evaluate(() =>
      [...document.querySelectorAll<HTMLElement>('#gp-shop button')]
        .filter((b) => !b.hidden)
        .map((b) => ({ t: b.textContent, r: b.getBoundingClientRect(), bg: getComputedStyle(b).backgroundColor }))
        .filter((x) => x.r.left < 0 || x.r.right > innerWidth || x.r.height < 48 || x.bg === 'rgb(255, 0, 255)')
        .map((x) => `${x.t} ${Math.round(x.r.width)}×${Math.round(x.r.height)} ${x.bg}`),
    );
    expect(bad).toEqual([]);
    await page.close();
  });

  it('a purchase spends the exact price, pops the card and offers undo; undo gives it back exactly', async () => {
    const page = await open({ coins: 100 });
    await page.tap('[data-gp-buy=speed]');
    expect(await coins(page)).toBe(95);
    expect(await log(page)).toEqual(['buy:speed:1']);
    expect(await page.isVisible('[data-gp=shop-undo]')).toBe(true);
    await page.tap('[data-gp=shop-undo]');
    expect(await coins(page)).toBe(100);
    expect(await page.isVisible('[data-gp=shop-undo]')).toBe(false);
    await page.close();
  });

  it('no amount toggle for upgrades of 5–10 levels: one level a press', async () => {
    const page = await open({ coins: 1000 });
    expect(await page.locator('[data-amount]').count()).toBe(0);
    await page.tap('[data-gp-buy=speed]');
    expect(await log(page)).toEqual(['buy:speed:1']);
    await page.close();
  });

  it('an idle-scale economy (an upgrade with 25+ levels) gets ×1 / ×10 / Next / Max; an explicit list wins', async () => {
    const page = await open({ coins: 1000, extra: '&idle=1' });
    expect(await page.locator('[data-amount]').evaluateAll((els) => els.map((e) => (e as HTMLElement).dataset.amount))).toEqual(['1', '10', 'next', 'max']);
    expect(await page.isVisible('[data-amount="10"]')).toBe(true);
    await page.close();
    const own = await open({ coins: 1000, extra: `&amounts=${encodeURIComponent('[1,"max"]')}` });
    expect(await own.locator('[data-amount]').evaluateAll((els) => els.map((e) => (e as HTMLElement).dataset.amount))).toEqual(['1', 'max']);
    await own.close();
  });

  it("the game's theme on #gp-shop wins over the defaults, wherever its style sheet is", async () => {
    const page = await open({ coins: 100, extra: '&theme=1' });
    const st = await page.evaluate(() => {
      const box = document.getElementById('gp-shop')!;
      return { bg: getComputedStyle(box).backgroundColor, buy: getComputedStyle(document.querySelector<HTMLElement>('[data-gp-buy=speed]')!).backgroundColor };
    });
    expect(st).toEqual({ bg: 'rgb(1, 2, 3)', buy: 'rgb(4, 5, 6)' });
    await page.close();
  });

  it('icons: text, an element (a canvas) or an image URL; the "% upgraded" line can be turned off', async () => {
    const page = await open({ coins: 100, extra: '&icons=1&progress=0' });
    expect(await page.locator('[data-gp-upgrade=speed] .gp-icon canvas[data-test=canvas-icon]').count()).toBe(1);
    expect(await page.getAttribute('[data-gp-upgrade=tiny] .gp-icon img', 'src')).toMatch(/^data:image\/svg\+xml/);
    expect(await text(page, '[data-gp-upgrade=calm] .gp-icon')).toBe('🧘');
    expect(await page.isVisible('#gp-shop .gp-complete')).toBe(false);
    expect(await page.isVisible('#gp-shop > .gp-bar')).toBe(false);
    await page.close();
    const def = await open({ coins: 100 });
    expect(await text(def, '#gp-shop .gp-complete')).toMatch(/\d+% upgraded/);
    await def.close();
  });

  it('×10 shows the total price for that many and buys exactly that many or nothing', async () => {
    const page = await open({ coins: 1000, extra: `&amounts=${encodeURIComponent('[1,10,"max"]')}` });
    await page.tap('[data-amount="10"]');
    const label = await text(page, '[data-gp-buy=speed]');
    expect(label).toContain('×8'); // capped at the levels left
    await page.tap('[data-gp-buy=speed]');
    const s = await page.evaluate(() => (window as unknown as { __shop: { state: { levels: Record<string, number> } } }).__shop.state.levels.speed);
    expect(s).toBe(8);
    await page.close();
  });

  it('holding the button keeps buying, faster, and stops when the coins run out', async () => {
    const page = await open({ coins: 60 });
    const box = (await page.locator('[data-gp-buy=speed]').boundingBox())!;
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await page.mouse.down();
    await page.waitForTimeout(2500);
    await page.mouse.up();
    const bought = (await log(page)).filter((x) => x.startsWith('buy:speed')).length;
    expect(bought).toBeGreaterThanOrEqual(3); // 5 + 8 + 13 + 20 = 46 ≤ 60 < 46 + 33
    expect(await coins(page)).toBe(60 - 46);
    expect(await log(page)).toContain('deny:speed'); // the hold ended on a "no", not silently
    await page.close();
  });

  it('a tap on what can\'t be bought shakes the card and says no; a held key buys one level only', async () => {
    const page = await open({ coins: 20 });
    await page.tap('[data-gp-buy=gold]', { force: true }); // aria-disabled buttons still take taps: that's the "no"
    expect(await page.getAttribute('[data-gp-upgrade=gold]', 'class')).toContain('gp-deny');
    expect(await log(page)).toEqual(['deny:gold']);
    await page.focus('[data-gp-buy=speed]');
    await page.keyboard.down('Enter');
    await page.keyboard.down('Enter'); // auto-repeat
    await page.keyboard.up('Enter');
    expect((await log(page)).filter((x) => x === 'buy:speed:1')).toHaveLength(1);
    await page.close();
  });

  for (const vp of [{ width: 360, height: 800 }, { width: 800, height: 360 }, { width: 1280, height: 720 }])
    it(`eight upgrades fit ${vp.width}×${vp.height} without scrolling, every button ≥ 48 px, text ≥ 12 px`, async () => {
      const page = await open({ coins: 100, many: true }, vp);
      const r = await page.evaluate(() => {
        const list = document.querySelector<HTMLElement>('#gp-shop .gp-list')!;
        const bad = [...document.querySelectorAll<HTMLElement>('#gp-shop button')]
          .filter((b) => !b.hidden)
          .map((b) => ({ t: b.textContent, r: b.getBoundingClientRect() }))
          .filter((x) => x.r.left < 0 || x.r.top < 0 || x.r.right > innerWidth || x.r.bottom > innerHeight || x.r.height < 48)
          .map((x) => `${x.t} ${Math.round(x.r.width)}×${Math.round(x.r.height)} @${Math.round(x.r.top)}`);
        const small = [...document.querySelectorAll<HTMLElement>('#gp-shop *')]
          .filter((e) => e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent!.trim()))
          .filter((e) => parseFloat(getComputedStyle(e).fontSize) < 12)
          .map((e) => e.textContent!.trim().slice(0, 16));
        return { cards: document.querySelectorAll('[data-gp-upgrade]').length, scrolls: list.scrollHeight > list.clientHeight + 1, bad, small };
      });
      await page.screenshot({ path: `${process.env.SHOP_SHOTS ?? '/tmp'}/shop-8-${vp.width}x${vp.height}.png` });
      expect(r.cards).toBe(8);
      expect(r.scrolls).toBe(false);
      expect(r.bad).toEqual([]);
      expect(r.small).toEqual([]);
      expect(await page.isVisible('[data-gp=shop-next]')).toBe(false);
      await page.close();
    });

  for (const vp of [{ width: 360, height: 800 }, { width: 800, height: 360 }, { width: 1280, height: 720 }])
    it(`twenty-four upgrades at ${vp.width}×${vp.height}: pages, not a list to scroll; every card on some page`, async () => {
      const page = await open({ coins: 100, many: true, extra: '&lots=1' }, vp);
      const state = () =>
        page.evaluate(() => {
          const list = document.querySelector<HTMLElement>('#gp-shop .gp-list')!;
          const shown = [...document.querySelectorAll<HTMLElement>('[data-gp-upgrade]')].filter((c) => !c.hidden).map((c) => c.dataset.gpUpgrade!);
          const off = [...document.querySelectorAll<HTMLElement>('#gp-shop button')]
            .filter((b) => b.getClientRects().length)
            .map((b) => b.getBoundingClientRect())
            .filter((r) => r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth || r.height < 48).length;
          return { shown, scrolls: list.scrollHeight > list.clientHeight + 2, off, no: document.querySelector('.gp-pageno')!.textContent };
        });
      const seen = new Set<string>();
      let s = await state();
      expect(s.no).toMatch(/^1\/\d+$/);
      const pages = Number(s.no!.split('/')[1]);
      expect(pages).toBeGreaterThan(1);
      for (let i = 0; i < pages; i++) {
        expect(s.scrolls).toBe(false);
        expect(s.off).toBe(0);
        for (const id of s.shown) seen.add(id);
        if (i < pages - 1) {
          await page.tap('[data-gp=shop-next]');
          s = await state();
        }
      }
      expect(seen.size).toBe(24);
      await page.close();
    });
});
