// Test page for mountUpgradeShop (packages/core/test-browser/shop-ui.test.ts): not a game, just the component with
// a state the test can set through window.__shop.
import { mountUpgradeShop, UpgradeShop, type Levels, type ShopItemText } from '../../src/index';

const q = new URLSearchParams(location.search);
// ?many=1: eight upgrades, as in Germ Bait and Yeet the Gnome (the phone layouts must fit them without scrolling)
const EXTRA = q.get('many') === '1' ? (['e1', 'e2', 'e3', 'e4'] as const) : [];
// ?lots=1: sixteen more upgrades — more than a screen holds: the shop pages instead of scrolling
const LOTS = q.get('lots') === '1' ? Array.from({ length: 16 }, (_, i) => `l${i + 1}` as `l${number}`) : [];
// ?idle=1: an idle-scale upgrade (40 levels): the shop offers ×1 / ×10 / Max by itself
const IDLE = q.get('idle') === '1' ? (['stand'] as const) : [];
// ?theme=1: the game's own theme, in a style sheet that comes BEFORE the shop's (Candle Crypt's case): it must still win
if (q.get('theme') === '1') {
  const st = document.createElement('style');
  st.textContent = '#gp-shop { --gp-shop-bg: rgb(1, 2, 3); --gp-shop-accent: rgb(4, 5, 6); }';
  document.head.append(st);
}
// ?icons=1: an element icon and an image URL icon (Starsilk walked .gp-icon by hand to put its pixel sprites in)
const canvasIcon = document.createElement('canvas');
canvasIcon.dataset.test = 'canvas-icon';
const SVG_URL = `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8"><rect width="8" height="8" fill="red"/></svg>')}`;
const icons = q.get('icons') === '1';
const shop = new UpgradeShop<Id>([
  { id: 'speed', max: 8, baseCost: 5, growth: 1.6, value: (l: number) => Math.round(260 * (1 + 0.07 * l)) },
  { id: 'tiny', max: 6, baseCost: 8, growth: 1.7, value: (l: number) => 16 * 0.93 ** l },
  { id: 'calm', max: 6, baseCost: 12, growth: 1.8, requires: 'speed', value: (l: number) => 1.2 + 0.4 * l },
  { id: 'gold', max: 3, baseCost: 1000, growth: 2 },
  ...EXTRA.map((id, i) => ({ id, max: 10, baseCost: 20 + 10 * i, growth: 1.5, value: (l: number) => 10 + 5 * l })),
  ...LOTS.map((id, i) => ({ id, max: 5, baseCost: 30 + 5 * i, growth: 1.5 })),
  ...IDLE.map((id) => ({ id, max: 40, baseCost: 3, growth: 1.07, milestones: [10, 25] })),
]);
type Id = 'speed' | 'tiny' | 'calm' | 'gold' | 'e1' | 'e2' | 'e3' | 'e4' | 'stand' | `l${number}`;
const state = { levels: shop.sanitize(JSON.parse(q.get('levels') ?? '{}')) as Levels<Id>, coins: Number(q.get('coins') ?? 0) };
const log: string[] = [];
const ui = mountUpgradeShop<Id>(document.getElementById('ui')!, {
  shop,
  items: {
    speed: { name: 'Flagella', icon: icons ? canvasIcon : '💨', effect: 'Move faster', format: (v) => `${v} px/s` },
    tiny: { name: 'Shrink', icon: icons ? SVG_URL : '🔬', effect: 'A smaller cell', format: (v) => `${v.toFixed(1)} px` },
    calm: { name: 'Calm start', icon: '🧘', effect: 'Germs come later', format: (v) => `${v.toFixed(1)} s` },
    gold: { name: 'Gold', icon: '🥇', effect: 'Shiny' },
    e1: { name: 'Magnet', icon: '🧲', effect: 'Pull coins in', format: (v) => `${v} px` },
    e2: { name: 'Armor', icon: '🛡️', effect: 'Take less damage', format: (v) => `${v}%` },
    e3: { name: 'Luck', icon: '🍀', effect: 'More gold drops', format: (v) => `${v}%` },
    e4: { name: 'Timer', icon: '⏱️', effect: 'Longer runs', format: (v) => `${v} s` },
    stand: { name: 'Lemonade stand', icon: '🍋', effect: 'More income' },
    ...Object.fromEntries(LOTS.map((id) => [id, { name: `Part ${id.slice(1)}`, icon: '⚙️', effect: 'A bit better' }])),
  } as Record<Id, ShopItemText>,
  ...(q.get('progress') === '0' ? { progress: false } : {}),
  ...(q.get('amounts') ? { amounts: JSON.parse(q.get('amounts')!) } : {}),
  minTouchPx: 48,
  get: () => state,
  set: (levels, coins) => {
    state.levels = levels;
    state.coins = coins;
  },
  incomePerRun: () => 4,
  onBuy: (id, n) => log.push(`buy:${id}:${n}`),
  onDenied: (id) => log.push(`deny:${id}`),
  onBack: () => log.push('back'),
});
(window as unknown as { __shop: unknown }).__shop = { state, log, refresh: ui.refresh };
