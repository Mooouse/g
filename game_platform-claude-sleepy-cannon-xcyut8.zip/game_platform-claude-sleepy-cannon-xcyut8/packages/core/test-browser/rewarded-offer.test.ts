// Browser test of the UI under a pending ad and of rewardedOffer() (kit: code). The repro is Frankengun's code review,
// bug #1 (QmaCyber/game22): "No thanks" clicked under a loading revive ad ended the run, then the late reward revived
// it over the results screen — a softlock. Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./host-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface Offer {
  el: HTMLElement;
  offer: HTMLButtonElement;
  skip: HTMLButtonElement;
  settled: boolean;
  close(): void;
}
interface T {
  host: { adBreak(): Promise<void>; adPending: boolean; rewardedAvailable: boolean };
  ui: HTMLElement;
  outcome: string[];
  mountOffer(): boolean;
  offer(): Offer | null;
  events(): string[];
}
const t = <R>(page: Page, fn: (t: T) => R) => page.evaluate(`(${fn.toString()})(window.__t)`) as Promise<Awaited<R>>;
const until = (page: Page, fn: (t: T) => boolean) => page.waitForFunction(`(${fn.toString()})(window.__t)`, null, { timeout: 10000 });

async function open(query = ''): Promise<Page> {
  const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
  await page.goto(`${base}${query}`);
  await page.waitForFunction('!!window.__t');
  return page;
}

describe('under a pending ad nothing can be tapped', () => {
  it('a midgame break makes the UI layer and the canvas inert from the request to the end', async () => {
    const page = await open();
    expect(await t(page, (x) => x.ui.inert)).toBe(false);
    await t(page, (x) => void x.host.adBreak());
    expect(await t(page, (x) => ({ ui: x.ui.inert, canvas: (document.getElementById('game') as HTMLElement).inert, pending: x.host.adPending }))).toEqual({ ui: true, canvas: true, pending: true });
    await until(page, (x) => x.events().includes('ad:end'));
    expect(await t(page, (x) => ({ ui: x.ui.inert, canvas: (document.getElementById('game') as HTMLElement).inert }))).toEqual({ ui: false, canvas: false });
    await page.close();
  });
});

describe('rewardedOffer: the offer and its own "No thanks"', () => {
  it('the two buttons are the same size; a tap on the offer disables the skip, a late skip does nothing, the reward comes once', async () => {
    const page = await open();
    expect(await t(page, (x) => x.mountOffer())).toBe(true);
    const sizes = await t(page, (x) => [x.offer()!.offer, x.offer()!.skip].map((b) => [Math.round(b.getBoundingClientRect().width), Math.round(b.getBoundingClientRect().height)]));
    expect(sizes[0]).toEqual(sizes[1]);
    expect(await t(page, (x) => x.offer()!.skip.textContent)).toBe('No thanks');
    await page.click('[data-gp-rewarded]');
    expect(await t(page, (x) => ({ skip: x.offer()!.skip.disabled, inert: x.ui.inert, pending: x.host.adPending }))).toEqual({ skip: true, inert: true, pending: true });
    // The Frankengun path: a click on "No thanks" that slips through before the ad covers the page (or Enter on it)
    await t(page, (x) => x.offer()!.skip.click());
    await until(page, (x) => x.events().includes('ad:rewarded'));
    expect(await t(page, (x) => ({ outcome: x.outcome.slice(), settled: x.offer()!.settled, skip: x.offer()!.skip.disabled }))).toEqual({ outcome: ['revived'], settled: true, skip: true });
    await page.close();
  });

  it('a reward that arrives after the run moved on (close(), the screen replaced) is ignored', async () => {
    const page = await open();
    await t(page, (x) => x.mountOffer());
    await page.click('[data-gp-rewarded]');
    await t(page, (x) => x.offer()!.close());
    await until(page, (x) => x.events().includes('ad:rewarded'));
    expect(await t(page, (x) => x.outcome.slice())).toEqual([]);
    // The screen replaced under the ad (the game showed its results): the reward is stale too
    await t(page, (x) => x.mountOffer());
    await page.click('[data-gp-rewarded]');
    await t(page, (x) => x.ui.replaceChildren());
    await until(page, (x) => x.events().filter((e) => e === 'ad:rewarded').length === 2);
    expect(await t(page, (x) => x.outcome.slice())).toEqual([]);
    await page.close();
  });

  it('a failed ad says so and gives "No thanks" back: the player goes on without the reward', async () => {
    const page = await open('?ads=unfilled');
    await t(page, (x) => x.mountOffer());
    await page.click('[data-gp-rewarded]');
    await until(page, (x) => x.events().includes('ad:rewarded'));
    expect(await t(page, (x) => ({ text: x.offer()!.offer.textContent, skip: x.offer()!.skip.disabled, inert: x.ui.inert }))).toEqual({ text: 'No ad available right now', skip: false, inert: false });
    await page.click('[data-gp=skip]');
    expect(await t(page, (x) => x.outcome.slice())).toEqual(['skipped']);
    await page.close();
  });

  it('no rewarded ad can be offered: null (the screen goes on without it)', async () => {
    const page = await open('?ads=fail');
    await t(page, (x) => x.mountOffer());
    await page.click('[data-gp-rewarded]');
    await until(page, (x) => x.events().includes('ad:rewarded'));
    expect(await t(page, (x) => ({ available: x.host.rewardedAvailable, again: x.mountOffer() }))).toEqual({ available: false, again: false });
    await page.close();
  });
});
