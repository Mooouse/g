// Browser test of the live world's screen parts: the restock countdown ticks and turns over with the clock, says when
// the stock is the player's own, speaks the player's language, takes the game's theme variables; the share card is a
// 1200×630 canvas with the band drawn. Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./live-world-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

async function open(query = ''): Promise<Page> {
  const page = await browser.newPage({ viewport: { width: 360, height: 800 } });
  await page.goto(`${base}?${query}`);
  await page.waitForSelector('[data-gp=restock-timer]');
  return page;
}
const pill = (page: Page) => page.locator('[data-gp=restock-timer]').innerText();

describe('mountRestockTimer', () => {
  it('counts down to the next restock and turns over with the clock', async () => {
    const page = await open();
    expect(await pill(page)).toBe('New stock in 1:48');
    await page.evaluate(() => ((window as unknown as { __t: number }).__t += 30_000));
    await expect.poll(() => pill(page)).toBe('New stock in 1:18');
    await page.evaluate(() => ((window as unknown as { __t: number }).__t += 80_000));
    await expect.poll(() => page.evaluate(() => ((window as unknown as { __live: { restocks(): number } }).__live.restocks()))).toBe(1);
    expect(await pill(page)).toMatch(/^New stock in 4:5\d$/);
    // The player's own restock says so
    await page.evaluate(() => (window as unknown as { __live: { own(): void } }).__live.own());
    expect(await pill(page)).toMatch(/^Your restock · shared stock in 4:5\d$/);
    await page.evaluate(() => (window as unknown as { __live: { destroy(): void } }).__live.destroy());
    expect(await page.locator('[data-gp=restock-timer]').count()).toBe(0);
    await page.close();
  });
  it("speaks the player's language and takes the game's theme variables", async () => {
    const page = await open('lang=de&theme=1');
    expect(await pill(page)).toBe('Neue Ware in 1:48');
    const color = await page.locator('[data-gp=restock-timer] b').evaluate((b) => getComputedStyle(b).color);
    expect(color).toBe('rgb(1, 2, 3)');
    const fits = await page.locator('[data-gp=restock-timer]').evaluate((el) => el.getBoundingClientRect().right <= innerWidth);
    expect(fits).toBe(true);
    await page.close();
  });
});

describe('drawShareCard', () => {
  it('draws a 1200×630 card with the band bar, and the text to copy', async () => {
    const page = await open();
    const r = await page.evaluate(() => {
      const c = document.getElementById('card') as HTMLCanvasElement;
      const g = c.getContext('2d')!;
      // The bar of bands at y = 440…462: the first two reached (accent), the third not
      const px = (x: number, y: number) => Array.from(g.getImageData(x, y, 1, 1).data.slice(0, 3));
      return { w: c.width, h: c.height, first: px(c.width / 2 - 120, 450), corner: px(5, 5), text: (window as unknown as { __live: { text: string } }).__live.text };
    });
    expect([r.w, r.h]).toEqual([1200, 630]);
    expect(r.corner).toEqual([0x18, 0x26, 0x3a]);
    expect(r.first).toEqual([0xff, 0xd1, 0x66]);
    expect(r.text).toMatch(/^Fixture Game · 2026-10-19\nSilver · 388\n▰▰▱\n12 points from Gold\n#[0-9A-Z]{4}-[0-9A-Z]{4}$/);
    await page.close();
  });
});
