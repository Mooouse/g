// Browser test of the goals screen (mountGoals) and the unlock banners (goalBanners): one screen at every size (pages,
// never a scroll), buttons ≥ 48 px under a game's hostile button CSS, claims, secrets, carried rewards, the platform's
// words in another language, banners held while a panel is open. `npm run test:browser` (Playwright's Chromium).
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { layoutOf, metaLog, SIZES, startFixture, type Fixture } from './meta-helpers';

let fx: Fixture;
beforeAll(async () => {
  fx = await startFixture();
}, 60000);
afterAll(async () => fx?.close());

describe('mountGoals', () => {
  it('fits one screen at every size on both tabs; the achievements page on a phone, all at once on a desktop', async () => {
    for (const viewport of SIZES) {
      for (const tab of ['quests', 'achievements']) {
        const page = await fx.open(`screen=goals&tab=${tab}&done=1&got=3`, viewport);
        expect(await layoutOf(page, 'gp-goals'), `${tab} ${viewport.width}×${viewport.height}`).toEqual([]);
        if (tab === 'achievements') {
          const cells = await page.locator('[data-gp=goals-ach]').count();
          const pager = await page.isVisible('[data-gp=goals-pager]');
          if (viewport.width === 1280) expect([cells, pager]).toEqual([14, false]);
          if (viewport.width === 360) expect(pager).toBe(true);
        }
        await page.close();
      }
    }
  }, 90000);

  it("today's quests: progress, a Claim on a done one (once), the bonus when all are claimed", async () => {
    const page = await fx.open('screen=goals&done=2');
    expect(await page.locator('[data-gp=goals-quest]').count()).toBe(3);
    expect(await page.locator('[data-gp=goals-quest][data-state=ready]').count()).toBe(2);
    expect(await page.locator('[data-gp=goals-tab][data-gp-tab=quests] .gp-ui-badge').innerText()).toBe('2');
    await page.locator('[data-gp=goals-claim]').first().tap();
    expect(await page.locator('[data-gp=goals-quest][data-state=claimed]').count()).toBe(1);
    expect(await page.locator('[data-gp=goals-quest][data-state=claimed] .gp-g-done svg[data-mark=check]').count()).toBe(1);
    await page.locator('[data-gp=goals-claim]').first().tap();
    // The third: finish it from the game, the screen refreshed
    await page.evaluate(() => {
      const m = (window as unknown as { __meta: { quests: { state(): { quests: { id: string; need: number }[] }; add(id: string, n: number): void }; screen: { refresh(): void } } }).__meta;
      const r = m.quests.state().quests[2];
      m.quests.add(r.id, r.need);
      m.screen.refresh();
    });
    await page.locator('[data-gp=goals-claim]').first().tap();
    expect(await page.getAttribute('[data-gp=goals-bonus]', 'data-state')).toBe('ready');
    await page.tap('[data-gp=goals-bonus-claim]');
    expect(await page.getAttribute('[data-gp=goals-bonus]', 'data-state')).toBe('claimed');
    const claims = (await metaLog(page)).filter((l) => l.startsWith('claim:'));
    expect(claims).toHaveLength(4);
    expect(claims.at(-1)).toBe('claim:bonus:bonus=25');
    expect(await page.innerText('.gp-g-sum')).toBe('3/3');
    await page.close();
  });

  it("yesterday's done quests and bonus wait as one row; Claim all pays them", async () => {
    const page = await fx.open('screen=goals&carry=1');
    expect(await page.innerText('[data-gp=goals-carried] .gp-g-text')).toBe('Waiting from earlier: 4');
    await page.tap('[data-gp=goals-claim-carried]');
    const last = (await metaLog(page)).at(-1)!;
    expect(last.split(',')).toHaveLength(4);
    expect(last).toContain('bonus:bonus=25');
    expect(await page.locator('[data-gp=goals-carried]').count()).toBe(0);
    await page.close();
  });

  it('achievements: the rarity, "???" for a secret not earned, a bar, a reward claimed by a tap; drawn marks', async () => {
    const page = await fx.open('screen=goals&tab=achievements&got=3', SIZES[1]);
    expect(await page.getAttribute('[data-gp-ach=a1]', 'data-rarity')).toBe('common');
    expect(await page.locator('[data-gp-ach=a1][data-unlocked]').count()).toBe(1);
    expect(await page.innerText('[data-gp-ach=a6] .gp-g-name')).toBe('???');
    expect(await page.locator('[data-gp-ach=a6] svg[data-mark=question]').count()).toBe(1);
    expect(await page.locator('[data-gp-ach=a5] .gp-g-bar').count()).toBe(1);
    expect(await page.innerText('[data-gp-ach=a3] .gp-g-rar')).toBe('Epic');
    expect(await page.innerText('.gp-g-sum')).toBe('3/14');
    // a2 has a reward: claimable, a tap pays it once
    expect(await page.locator('[data-gp-ach=a2][data-claimable]').count()).toBe(1);
    await page.tap('[data-gp-ach=a2]');
    await page.tap('[data-gp-ach=a2]', { force: true });
    expect((await metaLog(page)).filter((l) => l.startsWith('claim:'))).toEqual(['claim:achievement:a2=40']);
    await page.tap('[data-gp=goals-close]');
    expect(await page.locator('#gp-goals').count()).toBe(0);
    expect((await metaLog(page)).at(-1)).toBe('close');
    await page.close();
  });

  it("the phone pages the achievements; the platform's words come in the player's language", async () => {
    const page = await fx.open('screen=goals&tab=achievements&lang=ru');
    expect(await page.innerText('#gp-goals h2')).toBe('Цели');
    expect(await page.innerText('[data-gp=goals-tab][data-gp-tab=achievements] .gp-ui-tablabel')).toBe('Достижения');
    const first = await page.locator('[data-gp=goals-ach]').count();
    await page.tap('[data-gp=goals-next]');
    const second = await page.locator('[data-gp=goals-ach]').count();
    expect(first + second).toBe(14);
    expect(await layoutOf(page, 'gp-goals')).toEqual([]);
    await page.close();
  });
});

describe('goalBanners', () => {
  it('one at a time, held while a panel is open, then shown in order', async () => {
    const page = await fx.open('screen=goals&tab=quests');
    // The goals screen is open: the banner waits
    await page.evaluate(() => {
      const m = (window as unknown as { __meta: { banners: { push(b: object): void } } }).__meta;
      m.banners.push({ title: 'First win', rarity: 'rare' });
      m.banners.push({ title: 'Second', rarity: 'epic' });
    });
    await page.waitForTimeout(400);
    expect(await page.locator('[data-gp=banner]').count()).toBe(0);
    await page.tap('[data-gp=goals-close]');
    await page.waitForSelector('[data-gp=banner]');
    expect(await page.innerText('[data-gp=banner] b')).toBe('First win');
    expect(await page.innerText('[data-gp=banner] small')).toBe('Achievement unlocked · Rare');
    expect(await page.locator('[data-gp=banner]').count()).toBe(1);
    expect(await page.evaluate(() => getComputedStyle(document.getElementById('gp-banners')!).pointerEvents)).toBe('none');
    await page.waitForFunction(() => document.querySelector('[data-gp=banner] b')?.textContent === 'Second', null, { timeout: 8000 });
    await page.close();
  });
});
