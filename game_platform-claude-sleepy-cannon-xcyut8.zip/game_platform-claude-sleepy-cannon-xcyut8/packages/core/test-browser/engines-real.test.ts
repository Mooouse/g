// Browser test of the engine adapters on the REAL engines: Phaser 4, three.js and PixiJS 8 at the versions the platform
// supports (engines-real/package.json). engines.test.ts checks the shared contract on Canvas 2D, a recording WebGL part
// and a fake Pixi; this one checks that each adapter keeps it with the engine's own loop, renderer and audio: created
// stopped, runs only in play and while the host isn't paused (a hidden tab, an ad, a lost WebGL context), stops inside a
// step, resumes without a jump, sound only on the host's running context and into host.audio.out, a lost context comes
// back with the still frame redrawn, destroy() stops it for good.
// The engines are installed only in that folder (never in the platform): `npm ci --prefix packages/core/test-browser/engines-real`
// (CI does it before `npm run test:browser`). Without them these tests are skipped and say so.

import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { horizontalFovDeg, type CameraLike } from '../../kit-code/qa/look.ts';

const DIR = fileURLToPath(new URL('./engines-real', import.meta.url));
const ENGINES = ['phaser', 'three', 'pixi.js'];
const installed = ENGINES.every((e) => existsSync(`${DIR}/node_modules/${e}/package.json`));
if (!installed) console.warn('[engines-real] skipped: the real engines are not installed — npm ci --prefix packages/core/test-browser/engines-real');

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  if (!installed) return;
  // Pre-bundled up front: a dependency found on the first page load would reload the page mid-test
  server = await createServer({ root: DIR, configFile: false, logLevel: 'error', server: { port: 0 }, optimizeDeps: { include: ENGINES } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 120000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface Stats {
  raf: number;
  steps: number;
  frames: number;
  renders: number;
  running: boolean;
}
interface Linked {
  sameContext: boolean;
  toOut: boolean;
  toDestination: boolean;
}
interface T {
  host: { adBreak(): Promise<void>; paused: boolean; pauseReasons: ReadonlySet<string> };
  eng: { setRunning(on: boolean): void; renderOnce(): void; destroy(): void; running: boolean; audio: { live(): unknown } };
  log: string[];
  dts: number[];
  extra(k: string): unknown;
  audioContexts(): number;
  stats(): Stats;
  setHidden(h: boolean): void;
}
const t = <R>(page: Page, fn: (t: T) => R) => page.evaluate(`(${fn.toString()})(window.__t)`) as Promise<Awaited<R>>;
const until = (page: Page, fn: (t: T) => boolean) => page.waitForFunction(`(${fn.toString()})(window.__t)`, null, { timeout: 15000 });

async function open(engine: string, query = ''): Promise<Page> {
  const ctx = await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(`${base}?engine=${engine}${query}`);
  await page.waitForFunction('!!window.__t', null, { timeout: 30000 });
  (page as unknown as { errors: string[] }).errors = errors;
  return page;
}
const errorsOf = (page: Page) => (page as unknown as { errors: string[] }).errors;

/** rAF callbacks and steps over `ms` while the page stands still */
async function still(page: Page, ms: number): Promise<{ raf: number; steps: number; renders: number }> {
  const a = await t(page, (x) => x.stats());
  await page.waitForTimeout(ms);
  const b = await t(page, (x) => x.stats());
  return { raf: b.raf - a.raf, steps: b.steps - a.steps, renders: b.renders - a.renders };
}

describe.skipIf(!installed).each(['phaser', 'three', 'pixi'])('%sAdapter on the real engine', (engine) => {
  it("created stopped (no loop of the engine's own), then fixed 1/60 s steps and real draws; stopped again, the loop really stops", async () => {
    const page = await open(engine);
    const s0 = await still(page, 500);
    expect(s0.raf).toBeLessThanOrEqual(3);
    expect(await t(page, (x) => x.stats())).toMatchObject({ steps: 0, frames: 0, renders: 0, running: false });
    if (engine === 'pixi') expect(await t(page, (x) => x.extra('tickerStarted'))).toBe(false);
    if (engine === 'phaser') {
      // Phaser's window.onblur / onfocus put back (they paused and resumed its loop by themselves)
      expect(await t(page, (x) => x.extra('windowBlur'))).toBe(true);
      expect(await t(page, (x) => x.extra('loopFrame'))).toBeLessThanOrEqual(1);
    }
    if (engine === 'three') {
      expect(await t(page, (x) => x.extra('webgl2'))).toBe(true);
      // gp qa finds the camera through the host: the adapter's eng.camera, as it is now (E_QA_PORTRAIT_FOV)
      expect(await t(page, (x) => x.extra('engineCamera'))).toBe(true);
      const cam = (await t(page, (x) => x.extra('perspective'))) as CameraLike & { same: boolean };
      expect(cam).toMatchObject({ same: true, isPerspectiveCamera: true, fov: 75 });
      expect(horizontalFovDeg(cam)).toBeCloseTo(38.1, 1);
    }
    const x0 = engine === 'phaser' ? ((await t(page, (x) => x.extra('boxX'))) as number) : 0;
    await t(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(600);
    const s1 = await t(page, (x) => ({ ...x.stats(), dts: [...new Set(x.dts.map((d) => Math.round(d * 1e6) / 1e6))] }));
    expect(s1.running).toBe(true);
    expect(s1.steps).toBeGreaterThan(10);
    expect(s1.frames).toBeGreaterThan(10);
    expect(s1.renders).toBeGreaterThan(10);
    expect(s1.dts).toEqual([Math.round(1e6 / 60) / 1e6]);
    // Arcade physics really stepped (Phaser's world, not only the adapter's listeners)
    if (engine === 'phaser') expect((await t(page, (x) => x.extra('boxX'))) as number).toBeGreaterThan(x0 + 5);
    await t(page, (x) => x.eng.setRunning(false));
    await page.waitForTimeout(50);
    expect(await still(page, 400)).toMatchObject({ steps: 0, renders: 0 });
    expect((await still(page, 400)).raf).toBeLessThanOrEqual(1);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('setRunning(false) from inside a step: no more steps or listeners in that frame', async () => {
    const page = await open(engine, '&stopAt=3');
    await t(page, (x) => x.eng.setRunning(true));
    await until(page, (x) => x.dts.length >= 3);
    await page.waitForTimeout(300);
    const s = await t(page, (x) => ({ ...x.stats(), log: x.log.filter((l) => l.startsWith('step2')) }));
    expect(s.steps).toBe(3);
    expect(s.running).toBe(false);
    expect(s.log).toEqual(['step2:1', 'step2:2']);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it.runIf(engine === 'phaser')("a stop inside a step of Arcade's catch-up (a long frame): the world doesn't step on in that frame", async () => {
    // Step 2 blocks the main thread for 120 ms: the next frame catches up with several Arcade steps, the first one stops
    const page = await open(engine, '&stopAt=3&stall=120');
    await t(page, (x) => x.eng.setRunning(true));
    await until(page, (x) => x.log.some((l) => l.startsWith('stopped:')));
    await page.waitForTimeout(300);
    const at = await t(page, (x) => Number(x.log.find((l) => l.startsWith('stopped:'))!.slice(8)));
    expect(await t(page, (x) => x.extra('boxX'))).toBe(at);
    expect(await t(page, (x) => x.stats().steps)).toBe(3);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('every host pause reason stops it (hidden tab, ad, lost WebGL context); it resumes without counting the stopped time', async () => {
    const page = await open(engine);
    await t(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(300);
    for (const reason of ['hidden', 'ad', 'context'] as const) {
      const before = await t(page, (x) => x.stats().steps);
      if (reason === 'hidden') await t(page, (x) => x.setHidden(true));
      const ad = reason === 'ad' ? t(page, (x) => x.host.adBreak()) : null;
      if (reason === 'context') await page.evaluate('window.__lose.loseContext()');
      await until(page, (x) => x.host.paused);
      expect(await t(page, (x) => ({ running: x.eng.running, reasons: [...x.host.pauseReasons] }))).toEqual({ running: false, reasons: [reason] });
      const stopped = await t(page, (x) => x.stats().steps);
      expect(stopped - before).toBeLessThan(0.1 * 60 + 4);
      const s = await still(page, 500);
      expect(s.steps).toBe(0);
      expect(s.raf).toBeLessThanOrEqual(3);
      if (reason === 'hidden') await t(page, (x) => x.setHidden(false));
      if (ad) await ad;
      if (reason === 'context') await page.evaluate('window.__lose.restoreContext()');
      await until(page, (x) => !x.host.paused && x.eng.running);
      await page.waitForTimeout(250);
      // A jump would be the half second of standing still counted at once
      expect((await t(page, (x) => x.stats().steps)) - stopped).toBeLessThan(0.25 * 60 + 6);
    }
    // The context came back (the adapter prevented the loss's default): no "reload" screen
    expect(await page.locator('[data-gp=reload]').count()).toBe(0);
    // Pixi's generated textures come back empty: the adapter drew the one eng.texture() made again, once
    if (engine === 'pixi') expect(await t(page, (x) => x.extra('textureRenders'))).toBe(1);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('a context lost and restored while standing still: the still frame is drawn again', async () => {
    const page = await open(engine);
    await t(page, (x) => x.eng.renderOnce());
    const r0 = await t(page, (x) => x.stats().renders);
    expect(r0).toBe(1);
    await page.evaluate('window.__lose.loseContext()');
    await until(page, (x) => x.host.paused);
    await page.evaluate('window.__lose.restoreContext()');
    await until(page, (x) => !x.host.paused);
    await page.waitForFunction(`window.__t.stats().renders > ${r0}`, null, { timeout: 10000 });
    expect(await t(page, (x) => x.eng.running)).toBe(false);
    expect(await page.locator('[data-gp=reload]').count()).toBe(0);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it("sound only on the host's running context, into host.audio.out; one AudioContext on the page", async () => {
    const page = await open(engine);
    const own = engine === 'phaser' ? 'sound' : engine === 'three' ? 'listener' : null;
    expect(await t(page, (x) => x.eng.audio.live())).toBeNull();
    if (own) expect(await page.evaluate(`window.__t.extra(${JSON.stringify(own)})`)).toBeNull();
    await page.mouse.click(10, 10);
    await until(page, (x) => !!x.eng.audio.live());
    if (own) {
      const linked = (await page.evaluate(`window.__t.extra(${JSON.stringify(own)})`)) as Linked;
      // Phaser's sound manager / three's AudioListener on the host's context, its output through the host (mute, ads)
      expect(linked).toEqual({ sameContext: true, toOut: true, toDestination: false });
    }
    await t(page, (x) => x.setHidden(true));
    expect(await t(page, (x) => x.eng.audio.live())).toBeNull();
    if (own) expect(await page.evaluate(`window.__t.extra(${JSON.stringify(own)})`)).toBeNull();
    await t(page, (x) => x.setHidden(false));
    await until(page, (x) => !!x.eng.audio.live());
    const ad = t(page, (x) => x.host.adBreak());
    await until(page, (x) => x.host.paused);
    expect(await t(page, (x) => x.eng.audio.live())).toBeNull();
    await ad;
    expect(await t(page, (x) => x.audioContexts())).toBe(1);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('destroy(): stopped for good — no loop, no setRunning, no redraw on a resize or a resume', async () => {
    const page = await open(engine);
    await t(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(200);
    await t(page, (x) => x.eng.destroy());
    expect(await t(page, (x) => x.eng.running)).toBe(false);
    if (engine === 'phaser') expect(await t(page, (x) => x.extra('randomIsReal'))).toBe(true);
    await page.waitForTimeout(50);
    await t(page, (x) => x.eng.setRunning(true));
    expect(await t(page, (x) => x.eng.running)).toBe(false);
    const s = await still(page, 400);
    expect(s).toMatchObject({ steps: 0, renders: 0 });
    expect(s.raf).toBeLessThanOrEqual(1);
    await page.setViewportSize({ width: 500, height: 300 });
    await t(page, (x) => x.setHidden(true));
    await t(page, (x) => x.setHidden(false));
    await page.waitForTimeout(200);
    expect(await still(page, 300)).toMatchObject({ steps: 0, renders: 0 });
    if (engine === 'pixi') {
      // A context restore after destroy() draws nothing (the game may have destroyed the renderer and its textures)
      const tex = await t(page, (x) => x.extra('textureRenders'));
      await page.evaluate('window.__lose.loseContext()');
      await page.waitForTimeout(100);
      await page.evaluate('window.__lose.restoreContext()');
      await page.waitForTimeout(300);
      expect(await t(page, (x) => x.extra('textureRenders'))).toBe(tex);
    }
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });
});

describe.skipIf(!installed)('render scale, snapshot and fitToRect on the real engines', () => {
  it.each(['phaser', 'three', 'pixi'])('%s: setRenderScale(0.5) halves the drawing buffer (CSS size kept), pixelated below 0.6, and back', async (engine) => {
    const page = await open(engine);
    const r = (await t(page, (x) => x.extra('renderScale'))) as Record<string, unknown> & { size: { width: number; scale: number; dpr: number } };
    expect(r.canvas).toBe(320);
    expect(r.size).toMatchObject({ width: 640, scale: 0.5, dpr: 0.5 });
    if (engine === 'three') expect(r.ratio).toBe(0.5);
    if (engine === 'phaser') expect(r).toMatchObject({ game: 320, zoom: 0.5 });
    expect(r.css).toBe('pixelated');
    expect(r).toMatchObject({ back: 640, cssBack: '' });
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it.each([true, false])('three: snapshot() of a scene framed by fitToRect (perspective %s) lands inside the rectangle; the renderer is put back', async (persp) => {
    const page = await open('three');
    const r = (await (persp ? t(page, (x) => x.extra('snapshot')) : t(page, (x) => x.extra('snapshotOrtho')))) as Record<string, number> & { rect: { x: number; y: number; w: number; h: number }; target: unknown; alphaKept: boolean };
    expect(r.w).toBe(200);
    expect(r.h).toBe(100);
    expect(r.n).toBeGreaterThan(400);
    // Inside the rectangle, and filling most of it
    expect(r.minX).toBeGreaterThanOrEqual(r.rect.x - 1);
    expect(r.maxX).toBeLessThanOrEqual(r.rect.x + r.rect.w + 1);
    expect(r.minY).toBeGreaterThanOrEqual(r.rect.y - 1);
    expect(r.maxY).toBeLessThanOrEqual(r.rect.y + r.rect.h + 1);
    expect(Math.max(r.maxX - r.minX, r.maxY - r.minY)).toBeGreaterThan(r.rect.w * 0.55);
    // A transparent background, the target and the clear colour put back
    expect(r.cornerAlpha).toBe(0);
    expect(r.target).toBeNull();
    expect(r.alphaKept).toBe(true);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('pixi: snapshot() draws a fresh root off screen (the stage untouched), fitRect places the subject', async () => {
    const page = await open('pixi');
    const r = (await t(page, (x) => x.extra('snapshot'))) as { w: number; h: number; inside: number[]; outside: number[]; stageKids: number };
    expect([r.w, r.h]).toEqual([100, 50]);
    expect(r.inside[0]).toBeGreaterThan(200);
    expect(r.inside[3]).toBeGreaterThan(200);
    expect(r.outside[3]).toBe(0);
    expect(r.stageKids).toBe(1);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });
});
