// Test page for the host's languages and the picker (packages/core/test-browser/i18n.test.ts): a game in en, de and ru
// with a title, a count with plural forms, the platform's own words and the language picker; it re-renders on a switch.
// ?portalLocale=… plays CrazyGames' systemInfo.locale (the dev portal stub), ?lang=… the QA override.
import { createI18n, createPortal, GameHost, LANGUAGE_CODES, languagePicker, openLanguageSheet, rewardedButton } from '../../src/index';

const host = new GameHost({
  saveKey: 'i18n-fixture',
  minTouchPx: 48,
  locale: 'en-US',
  ads: null,
  portal: createPortal('crazygames'),
  keepEventLog: true,
  languages: ['en', 'de', 'ru'],
  strings: {
    en: { hello: 'Hello', coins: { one: '{n} coin', other: '{n} coins' } },
    de: { hello: 'Hallo', coins: { one: '{n} Münze', other: '{n} Münzen' } },
    ru: { hello: 'Привет', coins: { one: '{n} монета', few: '{n} монеты', many: '{n} монет', other: '{n} монеты' } },
  },
});
const ui = document.getElementById('ui')!;
const renders: string[] = [];
function render(): void {
  renders.push(host.lang);
  const h = Object.assign(document.createElement('h1'), { textContent: host.t('hello') });
  const c = Object.assign(document.createElement('p'), { textContent: host.t('coins', { n: 5 }) });
  const play = Object.assign(document.createElement('button'), { textContent: host.t('gp.play') });
  const picker = languagePicker({ host, onChange: render });
  ui.replaceChildren(h, c, play, ...(picker ? [picker] : []));
}
render();
(window as unknown as Record<string, unknown>).__t = {
  host,
  renders,
  events: () => host.events.log.filter((e) => e.type === 'language').map((e) => e.data.lang),
  /** The sheet with all 13 languages the platform knows */
  sheetAll: () => void openLanguageSheet({ host: { i18n: createI18n({ strings: { en: {} }, languages: LANGUAGE_CODES }) } }),
  noAdText: () => {
    const b = rewardedButton({ host: { ...host, rewardedAvailable: true, rewarded: async () => false, i18n: host.i18n }, placement: 'x', label: 'x', onReward() {} })!;
    document.body.append(b);
    b.click();
    return new Promise((r) => setTimeout(() => r(b.textContent), 50));
  },
};
