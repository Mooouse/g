// What the browser tests of the meta screens share (goals-ui, album-ui, rewards-ui, inspect-coach-cards): the fixture
// server, the sizes, and the one-screen check (gp qa's rule: no panel scrolls, buttons on screen and ≥ 48 px, the
// game's hostile button CSS doesn't reach them, no text under 12 px).
import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';

export const SIZES = [
  { width: 360, height: 800 },
  { width: 1280, height: 720 },
  { width: 800, height: 360 },
];

export interface Fixture {
  open(query: string, viewport?: { width: number; height: number }, extra?: { reducedMotion?: 'reduce' | 'no-preference' }): Promise<Page>;
  close(): Promise<void>;
}

export async function startFixture(): Promise<Fixture> {
  const server: ViteDevServer = await createServer({ root: fileURLToPath(new URL('./meta-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  const base = server.resolvedUrls!.local[0];
  const browser: Browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  return {
    async open(query, viewport = SIZES[0], extra = {}) {
      const page = await browser.newPage({ viewport, hasTouch: true, reducedMotion: extra.reducedMotion });
      const errors: string[] = [];
      page.on('pageerror', (e) => errors.push(String(e)));
      await page.goto(`${base}?${query}`);
      await page.waitForSelector('body[data-ready="1"]');
      (page as unknown as { errors: string[] }).errors = errors;
      return page;
    },
    async close() {
      await browser?.close();
      await server?.close();
    },
  };
}

export const metaLog = (page: Page) => page.evaluate(() => (window as unknown as { __meta: { log: string[] } }).__meta.log.slice());

/** Everything the one-screen rule looks at, inside the box `#id` */
export const layoutOf = (page: Page, id: string) =>
  page.evaluate((id) => {
    const box = document.getElementById(id);
    if (!box) return [`#${id} is not on the page`];
    const r = box.getBoundingClientRect();
    const bad: string[] = [];
    const name = (e: HTMLElement) => e.dataset.gp ?? e.dataset.gpTab ?? e.className;
    if (r.top < -0.5 || r.left < -0.5 || r.bottom > innerHeight + 0.5 || r.right > innerWidth + 0.5) bad.push(`box ${Math.round(r.width)}×${Math.round(r.height)} off screen`);
    for (const b of box.querySelectorAll<HTMLElement>('button')) {
      if (b.closest('[hidden]')) continue;
      const q = b.getBoundingClientRect();
      if (q.width === 0 && q.height === 0) continue;
      if (q.left < r.left - 0.5 || q.right > r.right + 0.5 || q.top < r.top - 0.5 || q.bottom > r.bottom + 0.5) bad.push(`button ${name(b)} outside the box`);
      if (q.height < 47.5 || q.width < 47.5) bad.push(`button ${name(b)} ${Math.round(q.width)}×${Math.round(q.height)}`);
      if (getComputedStyle(b).backgroundColor === 'rgb(255, 0, 255)') bad.push(`button ${name(b)} has the game's CSS`);
    }
    for (const e of box.querySelectorAll<HTMLElement>('*')) {
      const s = getComputedStyle(e);
      if ((s.overflowY === 'auto' || s.overflowY === 'scroll') && e.scrollHeight > e.clientHeight + 1) bad.push(`${name(e)} scrolls`);
      if (e.children.length === 0 && e.textContent?.trim() && parseFloat(s.fontSize) < 12 && !e.closest('svg')) bad.push(`${name(e)} text ${s.fontSize}`);
      // Nothing spills out of the box (a grid overflows without scrolling)
      const q = e.getBoundingClientRect();
      if (q.width > 0 && q.height > 0 && !e.closest('[hidden]') && !e.closest('svg') && (q.bottom > r.bottom + 1 || q.right > r.right + 1 || q.left < r.left - 1)) bad.push(`${name(e)} spills out of the box`);
    }
    if (document.scrollingElement!.scrollHeight > innerHeight + 1) bad.push('the page scrolls');
    return [...new Set(bad)];
  }, id);
