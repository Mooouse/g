// Browser test of the host's languages (detection order, the saved choice, <html lang>, the platform's words) and the
// ready language picker (flags as inline SVG, every choice ≥ 48 px, a switch re-renders, Escape closes, it fits a phone).
// Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./i18n-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

async function open(q = '', o: { locale?: string; saved?: string; viewport?: { width: number; height: number } } = {}): Promise<Page> {
  const context = await browser.newContext({ locale: o.locale ?? 'en-US', viewport: o.viewport ?? { width: 360, height: 800 }, hasTouch: true });
  if (o.saved) await context.addInitScript((l) => localStorage.setItem('i18n-fixture.lang', l), o.saved);
  const page = await context.newPage();
  await page.goto(`${base}${q}`);
  await page.waitForSelector('h1');
  return page;
}
const state = (page: Page) =>
  page.evaluate(() => ({ lang: (window as any).__t.host.lang as string, html: document.documentElement.lang, h1: document.querySelector('h1')!.textContent, coins: document.querySelector('p')!.textContent }));

describe('the host picks the language', () => {
  it("the browser's language when the game has it, else English", async () => {
    expect(await state(await open('', { locale: 'ru-RU' }))).toEqual({ lang: 'ru', html: 'ru', h1: 'Привет', coins: '5 монет' });
    expect((await state(await open('', { locale: 'de-AT' }))).lang).toBe('de');
    expect((await state(await open('', { locale: 'ja-JP' }))).lang).toBe('en');
  });

  it("the portal's locale beats the browser's; the saved choice beats both; ?lang (dev, QA) beats all", async () => {
    expect((await state(await open('?portalLocale=de-DE', { locale: 'ru-RU' }))).lang).toBe('de');
    expect((await state(await open('?portalLocale=de-DE', { locale: 'ru-RU', saved: 'en' }))).lang).toBe('en');
    expect((await state(await open('?portalLocale=de-DE&lang=ru', { saved: 'en' }))).lang).toBe('ru');
  });

  it("the platform's own words come in the player's language", async () => {
    const page = await open('', { locale: 'de-DE' });
    expect(await page.locator('#ui button').first().textContent()).toBe('Spielen');
    expect(await page.evaluate(() => (window as any).__t.noAdText())).toBe('Gerade keine Werbung verfügbar');
  });
});

describe('languagePicker', () => {
  it('a button with the flag (inline SVG, no emoji) and the name; a sheet of every language ≥ 48 px; a choice re-renders and is saved', async () => {
    const page = await open('', { locale: 'en-US' });
    const toggle = page.locator('[data-gp=lang]');
    expect(await toggle.innerText()).toBe('English');
    expect(await toggle.locator('svg.gp-flag').count()).toBe(1);
    expect(await toggle.getAttribute('aria-label')).toBe('Language: English');
    await toggle.click();
    const choices = page.locator('[data-gp-lang]');
    expect(await choices.evaluateAll((els) => els.map((e) => (e as HTMLElement).dataset.gpLang))).toEqual(['en', 'de', 'ru']);
    expect(await choices.evaluateAll((els) => els.map((e) => e.textContent))).toEqual(['English', 'Deutsch', 'Русский']);
    for (const b of await choices.all()) {
      const r = (await b.boundingBox())!;
      expect(r.height).toBeGreaterThanOrEqual(48);
      expect(r.x).toBeGreaterThanOrEqual(0);
      expect(r.x + r.width).toBeLessThanOrEqual(360);
    }
    // The game's hostile button style stays off the sheet
    expect(await choices.first().evaluate((e) => getComputedStyle(e).borderRadius)).toBe('12px');
    expect(await page.evaluate(() => document.activeElement?.getAttribute('data-gp-lang'))).toBe('en');
    await page.locator('[data-gp-lang=de]').click();
    expect(await page.locator('[data-gp=lang-sheet]').count()).toBe(0);
    expect(await state(page)).toEqual({ lang: 'de', html: 'de', h1: 'Hallo', coins: '5 Münzen' });
    expect(await page.evaluate(() => (window as any).__t.events())).toEqual(['de']);
    expect(await page.evaluate(() => localStorage.getItem('i18n-fixture.lang'))).toBe('de');
    expect(await page.locator('[data-gp=lang]').innerText()).toBe('Deutsch');
    await page.reload();
    await page.waitForSelector('h1');
    expect((await state(page)).lang).toBe('de');
  });

  it('Escape or a click on the backdrop closes it without a switch; the focus goes back to the button', async () => {
    const page = await open('', { locale: 'ru-RU' });
    await page.locator('[data-gp=lang]').click();
    await page.keyboard.press('Escape');
    expect(await page.locator('[data-gp=lang-sheet]').count()).toBe(0);
    expect(await page.evaluate(() => document.activeElement?.getAttribute('data-gp'))).toBe('lang');
    await page.locator('[data-gp=lang]').click();
    await page.mouse.click(5, 5);
    expect(await page.locator('[data-gp=lang-sheet]').count()).toBe(0);
    expect((await state(page)).lang).toBe('ru');
    expect(await page.evaluate(() => (window as any).__t.renders.length)).toBe(1);
  });

  it('thirteen languages fit a phone and the smallest portal frame; no name breaks inside a word', async () => {
    for (const viewport of [{ width: 360, height: 800 }, { width: 800, height: 450 }, { width: 320, height: 568 }]) {
      const page = await open('', { viewport });
      await page.evaluate(() => (window as any).__t.sheetAll());
      const bad = await page.evaluate(() =>
        [...document.querySelectorAll<HTMLElement>('[data-gp-lang]')].flatMap((b) => {
          const r = b.getBoundingClientRect();
          const name = b.querySelector<HTMLElement>('.gp-lang-name')!;
          const words = name.textContent!.split(' ').length;
          const lines = Math.round(name.getBoundingClientRect().height / parseFloat(getComputedStyle(name).lineHeight));
          return [
            ...(r.height < 48 ? [`${b.dataset.gpLang} ${r.height}px high`] : []),
            ...(b.scrollWidth > b.clientWidth + 1 ? [`${b.dataset.gpLang} overflows`] : []),
            ...(lines > words ? [`${b.dataset.gpLang} breaks inside a word (${lines} lines, ${words} words)`] : []),
          ];
        }),
      );
      expect(bad, JSON.stringify(viewport)).toEqual([]);
      expect(await page.locator('[data-gp-lang]').count()).toBe(13);
      await page.context().close();
    }
  });
});
