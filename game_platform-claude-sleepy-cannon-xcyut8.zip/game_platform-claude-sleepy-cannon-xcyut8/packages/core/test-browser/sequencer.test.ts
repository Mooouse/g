// The ScoreSequencer in a real browser frame loop: beats on time and quickening, the host's pause holding it, a click
// fast-forwarding to the land, and labels that never sit on each other on screen. Runs with `npm run test:browser`.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { beatTimes } from '../src/sequencer.ts';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./sequencer-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface Log {
  beats: { i: number; t: number; fast: boolean; pitch: number }[];
  land: { t: number; total: number; big: number; fast: boolean } | null;
  done: number | null;
  rolls: number;
  overlaps: number;
  overflow: number;
  maxLabels: number;
}
const logOf = (page: Page) => page.evaluate(() => (window as unknown as { __seq: { log: Log } }).__seq.log);

async function open(n: number): Promise<Page> {
  const page = await browser.newPage({ viewport: { width: 800, height: 600 } });
  await page.goto(`${base}?n=${n}`);
  await page.waitForFunction(() => '__seq' in window);
  return page;
}

describe('ScoreSequencer in a browser', () => {
  it('plays every beat on time, quicker and higher each beat, lands and is done; labels never overlap', { timeout: 30000 }, async () => {
    const page = await open(16);
    await page.waitForFunction(() => (window as unknown as { __seq: { log: Log } }).__seq.log.done !== null, null, { timeout: 10000 });
    const log = await logOf(page);
    const preview = await page.evaluate(() => (window as unknown as { __seq: { preview: number } }).__seq.preview);
    expect(log.beats.map((b) => b.i)).toEqual([...Array(16).keys()]);
    const gaps = log.beats.slice(1).map((b, i) => (b.t - log.beats[i].t) / 1000);
    const want = beatTimes(16);
    // One frame of slack (≈ 17 ms) either way: the beats fire on the frame that reaches their time
    gaps.forEach((g, i) => expect(Math.abs(g - want[i]), `gap ${i}: ${g.toFixed(3)} s, want ${want[i].toFixed(3)} s`).toBeLessThan(0.034));
    expect(gaps[0]).toBeGreaterThan(gaps[14] * 2);
    for (let i = 1; i < 16; i++) expect(log.beats[i].pitch).toBeGreaterThan(log.beats[i - 1].pitch);
    expect(log.rolls).toBe(1);
    expect(log.land!.total).toBe(preview);
    expect(log.done).toBe(preview);
    expect(log.maxLabels).toBeGreaterThan(3);
    expect(log.overlaps, 'labels on top of each other').toBe(0);
    expect(log.overflow, 'a label wider than its box').toBe(0);
    await page.close();
  });

  it('stands still while the host is paused; a click fast-forwards to the land, a second ends it', { timeout: 30000 }, async () => {
    const page = await open(20);
    await page.waitForFunction(() => (window as unknown as { __seq: { log: Log } }).__seq.log.beats.length >= 3);
    await page.evaluate(() => ((window as unknown as { __seq: { host: { paused: boolean } } }).__seq.host.paused = true));
    const before = (await logOf(page)).beats.length;
    await page.waitForTimeout(600);
    expect((await logOf(page)).beats.length).toBe(before);
    await page.evaluate(() => ((window as unknown as { __seq: { host: { paused: boolean } } }).__seq.host.paused = false));
    await page.waitForFunction((n) => (window as unknown as { __seq: { log: Log } }).__seq.log.beats.length > n, before);
    await page.mouse.click(10, 10);
    const log = await logOf(page);
    expect(log.beats).toHaveLength(20);
    expect(log.beats.at(-1)!.fast).toBe(true);
    expect(log.land!.fast).toBe(true);
    expect(await page.evaluate(() => (window as unknown as { __seq: { state: () => string } }).__seq.state())).toBe('land');
    await page.mouse.click(10, 10);
    // Done at once, not LAND_HOLD later
    expect((await logOf(page)).done).toBe(log.land!.total);
    await page.close();
  });
});
