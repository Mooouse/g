// Test page for mountSeasonTrack (packages/core/test-browser/season-ui.test.ts): not a game, just the screen over a
// season pass the test sets through the query and reads through window.__season.
import { byLanguage, createI18n, mountSeasonTrack, PLATFORM_STRINGS, seasonPass, type SeasonClaim } from '../../src/index';

const q = new URLSearchParams(location.search);
const day = q.get('day') ?? '2026-10-18';
const lang = q.get('lang') ?? 'en';
const i18n = createI18n({ strings: [byLanguage(PLATFORM_STRINGS)], lang });
// ?theme=1: the game's own theme, in a style sheet that comes BEFORE the screen's: it must still win
if (q.get('theme') === '1') {
  const st = document.createElement('style');
  st.textContent = '#gp-season { --gp-season-bg: rgb(1, 2, 3); --gp-season-accent: rgb(4, 5, 6); }';
  document.head.append(st);
}
type Reward = { kind: 'coins'; n: number } | { kind: 'paint'; id: string };
const COIN = `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8"><circle cx="4" cy="4" r="3.5" fill="gold"/></svg>')}`;
const save: Record<string, unknown> = {};
// ?prior=<xp>: a save from season s1 with that much XP, nothing claimed (open it on a day of s2: the tiers carry over)
if (q.get('prior')) save.season = { season: 's1', xp: Number(q.get('prior')), claimed: [], carry: [], life: Number(q.get('prior')), played: ['s1'] };
const pass = seasonPass<Reward>(save, {
  seasons: [
    { id: 's1', from: '2026-10-01', to: '2027-01-31', tiers: Number(q.get('tiers') ?? 30), xp: 200 },
    { id: 's2', from: '2027-02-01', to: '2027-05-31', tiers: 30, xp: 200 },
  ],
  reward: (t) => (t % 3 === 0 ? { kind: 'paint', id: `${t / 3}` } : { kind: 'coins', n: 30 + 5 * t }),
  rewardEvery: 3,
  now: () => Date.parse(`${day}T12:00:00Z`),
});
pass.add(Number(q.get('xp') ?? 0));
const log: string[] = [];
const canvas = () => {
  const c = document.createElement('canvas');
  c.width = c.height = 36;
  c.dataset.test = 'paint';
  return c;
};
const screen = mountSeasonTrack<Reward>(document.getElementById('ui'), pass, {
  host: { minTouchPx: 48, screen: (n) => log.push(`screen:${n}`), t: (k, p) => i18n.t(k, p) },
  name: (s) => (s.id === 's1' ? 'Neon Premiere' : 'Chrome Riot'),
  view: (r) => (r.kind === 'coins' ? { icon: COIN, label: String(r.n) } : { icon: canvas(), label: `Paint ${r.id}` }),
  onClaim: (cs: SeasonClaim<Reward>[]) => log.push(`claim:${cs.map((c) => c.tier).join(',')}`),
  onClose: () => log.push('close'),
});
(window as unknown as { __season: unknown }).__season = { log, pass, screen };
