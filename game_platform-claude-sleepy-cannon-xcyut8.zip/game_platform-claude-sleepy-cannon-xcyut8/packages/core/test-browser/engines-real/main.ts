// Test page for the engine adapters on the REAL engines (packages/core/test-browser/engines-real.test.ts): Phaser 4,
// three.js and PixiJS 8 at the versions the platform supports (package.json here; installed only in this folder, never
// in the platform: `npm ci --prefix packages/core/test-browser/engines-real`). A host and one adapter on #game, with
// every requestAnimationFrame callback, step, frame and engine render counted, every AudioContext and audio connection
// recorded. Not a game. Not in tsconfig.json (CI type-checks before these engines are installed): Vite strips the types.
//   ?engine=phaser | three | pixi    ?stopAt=<n>: the n-th step ends the run, from inside the step
import { GameHost } from '../../src/index';
import type { Engine } from '../../src/engines/driver';

const q = new URLSearchParams(location.search);
// Phaser's adapter wraps Math.random in dev builds (a warning when Phaser's ranges bypass host.rng); destroy() puts it back
const realRandom = Math.random;
const which = q.get('engine') ?? 'three';

// Every requestAnimationFrame callback on the page: the adapter's loop and any loop of the engine's own
let rafCalls = 0;
const raf = window.requestAnimationFrame.bind(window);
window.requestAnimationFrame = (cb) =>
  raf((ts) => {
    rafCalls++;
    cb(ts);
  });

// Every AudioContext the page makes (the adapters must use the host's one) and where each audio node is connected
let audioContexts = 0;
const AC = window.AudioContext;
window.AudioContext = class extends AC {
  constructor(o?: AudioContextOptions) {
    super(o);
    audioContexts++;
  }
};
const links = new Map<AudioNode, Set<AudioNode | AudioParam>>();
const connect = AudioNode.prototype.connect;
const disconnect = AudioNode.prototype.disconnect;
AudioNode.prototype.connect = function (this: AudioNode, dest: AudioNode | AudioParam, ...rest: number[]) {
  if (!links.has(this)) links.set(this, new Set());
  links.get(this)!.add(dest);
  return (connect as (...a: unknown[]) => AudioNode).call(this, dest, ...rest);
} as typeof AudioNode.prototype.connect;
AudioNode.prototype.disconnect = function (this: AudioNode, ...a: unknown[]) {
  if (a.length === 0) links.delete(this);
  else links.get(this)?.delete(a[0] as AudioNode);
  return (disconnect as (...a: unknown[]) => void).apply(this, a);
} as typeof AudioNode.prototype.disconnect;

const canvas = document.getElementById('game') as HTMLCanvasElement;
const host = new GameHost({
  saveKey: 'engines-real',
  minTouchPx: 48,
  locale: 'en-US',
  ads: { policy: { noAdsAfterLaunchSec: 0, firstAdAfterRound: 0, everyRounds: 1, minIntervalSec: 0, maxAdWaitSec: 10, testAdCloseSec: 1 }, rewarded: true, admob: null },
  portal: null,
  keepEventLog: true,
  canvas,
  title: 'Engines Real',
});

const dts: number[] = [];
const log: string[] = [];
let frames = 0;
/** Draws the engine really made (its renderer's render / Phaser's postRender), not the adapter's calls */
let renders = 0;
let eng: Engine;
/** Per engine: what the test reads (its sound object, its own loop's state) */
let extra: Record<string, () => unknown> = {};

if (which === 'phaser') {
  const Phaser = (await import('phaser')).default;
  const { phaserAdapter } = await import('../../src/engines/phaser');
  /** The box's Arcade body: its position is where the world's steps left it (the game object follows after the frame) */
  let box: { position: { x: number } } | null = null;
  class Play extends Phaser.Scene {
    create(): void {
      const r = this.add.rectangle(40, 40, 24, 24, 0xffd166);
      this.physics.add.existing(r);
      const body = r.body as unknown as { position: { x: number }; setVelocity(x: number, y: number): unknown };
      body.setVelocity(60, 0);
      box = body;
    }
  }
  const p = phaserAdapter(host, canvas, Phaser, { scene: Play, physics: { default: 'arcade', arcade: { fps: 60 } }, background: '#102230' });
  await p.ready;
  const game = p.game as unknown as {
    renderer: { postRender(): void };
    loop: { frame: number; running: boolean; sleep(): void };
    scene: { scenes: { tweens: { prevTime: number } }[] };
  };
  const post = game.renderer.postRender.bind(game.renderer);
  game.renderer.postRender = () => {
    renders++;
    post();
  };
  eng = p;
  extra = {
    loopFrame: () => game.loop.frame,
    boxX: () => box?.position.x ?? null,
    sound: () => {
      const sm = p.sound() as unknown as { context: AudioContext; masterVolumeNode: AudioNode } | null;
      if (!sm) return null;
      const to = links.get(sm.masterVolumeNode) ?? new Set();
      return { sameContext: sm.context === host.audio?.ctx, toOut: to.has(host.audio!.out), toDestination: to.has(sm.context.destination) };
    },
    windowBlur: () => window.onblur === null && window.onfocus === null,
    renderScale: () => {
      p.setRenderScale(0.5);
      const g = p.game as unknown as { scale: { width: number }; scene: { scenes: { cameras: { main: { zoom: number } } }[] } };
      const out = { canvas: canvas.width, game: g.scale.width, zoom: g.scene.scenes[0].cameras.main.zoom, css: canvas.style.imageRendering, size: p.size };
      p.setRenderScale(1);
      return { ...out, back: canvas.width, cssBack: canvas.style.imageRendering };
    },
    randomIsReal: () => Math.random === realRandom,
  };
} else if (which === 'three') {
  const THREE = await import('three');
  const { threeAdapter, fitToRect } = await import('../../src/engines/three');
  const t = threeAdapter(host, canvas, { WebGLRenderer: THREE.WebGLRenderer, AudioContext: THREE.AudioContext, AudioListener: THREE.AudioListener, WebGLRenderTarget: THREE.WebGLRenderTarget, Color: THREE.Color }, { background: '#102230' });
  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(0, t.size.width, 0, -t.size.height, -10, 10);
  const mesh = new THREE.Mesh(new THREE.CircleGeometry(20, 24), new THREE.MeshBasicMaterial({ color: 0xffd166 }));
  scene.add(mesh);
  t.scene = scene;
  t.camera = camera;
  const render = t.renderer.render.bind(t.renderer);
  t.renderer.render = (s, c) => {
    renders++;
    render(s, c);
  };
  t.onResize((s) => {
    camera.right = s.width;
    camera.bottom = -s.height;
    camera.updateProjectionMatrix();
  });
  t.onFrame(() => mesh.position.set(40 + dts.length, -40, 0));
  (window as unknown as Record<string, unknown>).__lose = t.renderer.getContext().getExtension('WEBGL_lose_context');
  eng = t;
  extra = {
    listener: () => {
      const l = t.listener();
      if (!l) return null;
      const to = links.get(l.gain) ?? new Set();
      return { sameContext: l.context === host.audio?.ctx, toOut: to.has(host.audio!.out), toDestination: to.has(l.context.destination) };
    },
    webgl2: () => t.renderer.getContext() instanceof WebGL2RenderingContext,
    // gp qa reads the camera through the host (its portrait field-of-view check): the adapter's eng.camera
    engineCamera: () => host.engineCamera?.() === camera,
    perspective: () => {
      const p = new THREE.PerspectiveCamera(75, 360 / 800);
      t.camera = p;
      const c = host.engineCamera?.() as { isPerspectiveCamera?: boolean; fov?: number; aspect?: number } | null;
      t.camera = camera;
      return { same: c === p, isPerspectiveCamera: !!c?.isPerspectiveCamera, fov: c?.fov, aspect: c?.aspect };
    },
    // A red box framed into a rectangle of a 200×100 picture, off screen: where its pixels landed, and the renderer put back
    snapshot: () => snap(true),
    snapshotOrtho: () => snap(false),
  };
  function snap(persp: boolean) {
    {
      const W = 200;
      const H = 100;
      const rect = { x: 120, y: 20, w: 60, h: 60 };
      const s = new THREE.Scene();
      const box = new THREE.Mesh(new THREE.BoxGeometry(2, 1, 1), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
      box.position.set(5, -3, 2);
      box.rotation.y = 0.6;
      s.add(box);
      const cam = persp ? new THREE.PerspectiveCamera(40, 1, 0.1, 100) : new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 100);
      fitToRect(cam, new THREE.Box3().setFromObject(box), rect, { width: W, height: H }, { direction: { x: -0.3, y: -0.4, z: -1 } });
      const before = t.renderer.getClearAlpha();
      const pic = t.snapshot(W, H, () => ({ scene: s, camera: cam }));
      const px = pic.getContext('2d')!.getImageData(0, 0, W, H).data;
      let minX = W, minY = H, maxX = -1, maxY = -1, n = 0;
      for (let y = 0; y < H; y++)
        for (let x = 0; x < W; x++) {
          const i = (y * W + x) * 4;
          if (px[i + 3] > 128 && px[i] > 128) {
            n++;
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
          }
        }
      const centre = (90 * W + 10) * 4;
      return { w: pic.width, h: pic.height, n, minX, maxX, minY, maxY, rect, cornerAlpha: px[centre + 3], target: t.renderer.getRenderTarget(), alphaKept: t.renderer.getClearAlpha() === before };
    }
  }
  extra.renderScale = () => {
      t.setRenderScale(0.5, { dprMax: 1 });
      const out = { canvas: canvas.width, ratio: t.renderer.getPixelRatio(), css: canvas.style.imageRendering, size: t.size };
      t.setRenderScale(1);
      return { ...out, back: canvas.width, cssBack: canvas.style.imageRendering };
  };
} else {
  const PIXI = await import('pixi.js');
  const { pixiAdapter } = await import('../../src/engines/pixi');
  const fitter = await import('../../src/engines/pixi');
  const p = await pixiAdapter(host, canvas, { autoDetectRenderer: PIXI.autoDetectRenderer, Container: PIXI.Container, Ticker: PIXI.Ticker }, { background: '#102230' });
  const dot = p.texture(new PIXI.Graphics().circle(6, 6, 6).fill(0xffffff), { frame: new PIXI.Rectangle(0, 0, 12, 12) });
  const sprite = new PIXI.Sprite(dot as InstanceType<typeof PIXI.Texture>);
  p.stage.addChild(sprite);
  const render = p.renderer.render.bind(p.renderer);
  let textureRenders = 0;
  p.renderer.render = ((what: { target?: unknown }) => {
    if ((what as { target?: unknown }).target) textureRenders++;
    else renders++;
    return render(what as never);
  }) as typeof p.renderer.render;
  p.onFrame(() => (sprite.x = 40 + dts.length));
  (window as unknown as Record<string, unknown>).__lose = (p.renderer as unknown as { gl: WebGLRenderingContext }).gl.getExtension('WEBGL_lose_context');
  eng = p;
  extra = {
    tickerStarted: () => PIXI.Ticker.system.started,
    webgl: () => p.webgl,
    textureRenders: () => textureRenders,
    // A red square drawn into a 100×50 picture off screen (no Rectangle passed: the adapter's own frame)
    snapshot: () => {
      const pic = p.snapshot(100, 50, (root) => {
        const g = new PIXI.Graphics().rect(0, 0, 20, 20).fill(0xff0000);
        const { fitRect } = fitter;
        const f = fitRect(g.getLocalBounds(), { x: 60, y: 10, w: 30, h: 30 }, 0);
        g.scale.set(f.scale);
        g.position.set(f.x, f.y);
        root.addChild(g);
      });
      const px = pic.getContext('2d')!.getImageData(0, 0, 100, 50).data;
      const at = (x: number, y: number) => Array.from(px.slice((y * 100 + x) * 4, (y * 100 + x) * 4 + 4));
      return { w: pic.width, h: pic.height, inside: at(75, 25), outside: at(10, 25), stageKids: (p.stage as unknown as { children: unknown[] }).children.length };
    },
    renderScale: () => {
      p.setRenderScale(0.5);
      const out = { canvas: canvas.width, css: canvas.style.imageRendering, size: p.size };
      p.setRenderScale(1);
      return { ...out, back: canvas.width, cssBack: canvas.style.imageRendering };
    },
  };
}

if (which === 'phaser') (window as unknown as Record<string, unknown>).__lose = (canvas.getContext('webgl2') ?? canvas.getContext('webgl'))?.getExtension('WEBGL_lose_context');

const stopAt = Number(q.get('stopAt') ?? 0);
// ?stall=<ms>: the step before stopAt blocks the main thread, so the next frame has a long delta and the engine catches
// up with several steps in one frame (Phaser's Arcade loop): the stop must end that frame's remaining steps too
const stall = Number(q.get('stall') ?? 0);
eng.onStep((dt) => {
  dts.push(dt);
  if (stall && dts.length === stopAt - 1) {
    const end = performance.now() + stall;
    while (performance.now() < end);
  }
  if (stopAt && dts.length === stopAt) {
    eng.setRunning(false);
    log.push(`stopped:${JSON.stringify(extra.boxX?.() ?? null)}`);
  }
});
// A second listener: it must not run after the first one stopped the run in the same step
eng.onStep(() => log.push(`step2:${dts.length}`));
eng.onFrame(() => frames++);

/** Play a hidden tab: headless Chromium is never hidden by itself */
function setHidden(hidden: boolean): void {
  Object.defineProperty(document, 'hidden', { configurable: true, get: () => hidden });
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => (hidden ? 'hidden' : 'visible') });
  document.dispatchEvent(new Event('visibilitychange'));
}

(window as unknown as Record<string, unknown>).__t = {
  host,
  eng,
  log,
  dts,
  extra: (k: string) => extra[k]?.(),
  audioContexts: () => audioContexts,
  stats: () => ({ raf: rafCalls, steps: dts.length, frames, renders, running: eng.running }),
  setHidden,
};
