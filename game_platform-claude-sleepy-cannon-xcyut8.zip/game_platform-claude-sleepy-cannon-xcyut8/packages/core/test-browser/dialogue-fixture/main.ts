// Test page for mountDialogue (packages/core/test-browser/dialogue-ui.test.ts): not a game, just the component driven
// through window.__dlg. ?cps=0 for instant lines, ?portrait=1 for a portrait slot.
import { mountDialogue, type DialogueView } from '../../src/index';

const q = new URLSearchParams(location.search);
const log: string[] = [];
/** Lines shown one after another on onNext / onChoose, as a story engine would */
const queue: DialogueView[] = [];
const portraits: string[] = [];
const ui = mountDialogue(document.getElementById('ui')!, {
  minTouchPx: 48,
  typeCps: q.has('cps') ? Number(q.get('cps')) : undefined,
  portrait:
    q.get('portrait') === '1'
      ? (el, who, mood) => {
          portraits.push(`${who}:${mood ?? ''}`);
          el.textContent = '🙂';
        }
      : undefined,
  blip: () => log.push('blip'),
  onNext: () => {
    log.push('next');
    const v = queue.shift();
    if (v) ui.show(v);
  },
  onChoose: (id) => {
    log.push(`choose:${id}`);
    const v = queue.shift();
    if (v) ui.show(v);
  },
  onSkip: () => log.push('skip'),
});
(window as unknown as { __dlg: unknown }).__dlg = {
  log,
  portraits,
  /** Show a line; the rest follow on each onNext / onChoose */
  show: (v: DialogueView, ...then: DialogueView[]) => {
    queue.push(...then);
    ui.show(v);
  },
  hide: () => ui.hide(),
  typing: () => ui.typing,
};
