// Test page for createSfx on real WebAudio (packages/core/test-browser/sfx.test.ts): each case renders on an
// OfflineAudioContext the host hands the mixer (its state reads 'running', as a played-in context's does), so the test
// reads the exact samples: every recipe sounds and ends, a burst of booms stays under clipping (the limiter), a file
// decodes from a data: URL and its rate is its pitch.
import { createMixer, createSfx, MATERIALS, RECIPES, sfxRecipe, type SfxDef, type SfxSource } from '../../src/sound';

const RATE = 48000;

/** A WAV data: URL of a sine (16-bit mono) */
function wav(hz: number, sec: number): string {
  const n = Math.round(RATE * sec);
  const b = new DataView(new ArrayBuffer(44 + n * 2));
  const str = (o: number, s: string) => [...s].forEach((c, i) => b.setUint8(o + i, c.charCodeAt(0)));
  str(0, 'RIFF');
  b.setUint32(4, 36 + n * 2, true);
  str(8, 'WAVEfmt ');
  b.setUint32(16, 16, true);
  b.setUint16(20, 1, true);
  b.setUint16(22, 1, true);
  b.setUint32(24, RATE, true);
  b.setUint32(28, RATE * 2, true);
  b.setUint16(32, 2, true);
  b.setUint16(34, 16, true);
  str(36, 'data');
  b.setUint32(40, n * 2, true);
  for (let i = 0; i < n; i++) b.setInt16(44 + i * 2, Math.round(Math.sin((2 * Math.PI * hz * i) / RATE) * 0.5 * 32767), true);
  let bin = '';
  const u = new Uint8Array(b.buffer);
  for (let i = 0; i < u.length; i++) bin += String.fromCharCode(u[i]);
  return `data:audio/wav;base64,${btoa(bin)}`;
}

/** Render `sec` of a mixer whose effects are `sounds`, after `act` plays them at time 0 */
async function render(sounds: Record<string, SfxSource | SfxDef>, act: (sfx: ReturnType<typeof createSfx>) => void | Promise<void>, sec = 2.5) {
  const ctx = new OfflineAudioContext(2, Math.round(RATE * sec), RATE);
  Object.defineProperty(ctx, 'state', { get: () => 'running' });
  const out = ctx.createGain();
  out.connect(ctx.destination);
  const host = { paused: false, portalMuted: false, audio: { ctx: ctx as unknown as AudioContext, out } };
  const sfx = createSfx(createMixer(host), sounds);
  await sfx.load();
  await act(sfx);
  const buf = await ctx.startRendering();
  const L = buf.getChannelData(0);
  const R = buf.getChannelData(1);
  let peak = 0;
  let lastLoud = 0;
  for (let i = 0; i < L.length; i++) {
    const a = Math.max(Math.abs(L[i]), Math.abs(R[i]));
    if (a > peak) peak = a;
    if (a > 1e-3) lastLoud = i / RATE;
  }
  // Zero crossings of the left channel per second, over the first 0.1 s of sound
  let zc = 0;
  const first = L.findIndex((v) => Math.abs(v) > 1e-3);
  for (let i = Math.max(1, first); i < first + RATE * 0.1; i++) if ((L[i - 1] < 0 && L[i] >= 0) || (L[i - 1] >= 0 && L[i] < 0)) zc++;
  let left = 0;
  let right = 0;
  for (let i = 0; i < L.length; i++) {
    left += L[i] * L[i];
    right += R[i] * R[i];
  }
  return { peak, lastLoud, zcPerSec: zc / 0.1, balance: right / Math.max(1e-12, left) };
}

Object.assign(window, {
  __sfx: {
    /** Every recipe and material alone */
    recipes: async () => {
      const out: Record<string, { peak: number; lastLoud: number }> = {};
      for (const k of [...RECIPES, ...Object.keys(MATERIALS)]) {
        const r = await render({ s: sfxRecipe(k as never) }, (sfx) => void sfx.play('s'));
        out[k] = { peak: r.peak, lastLoud: r.lastLoud };
      }
      return out;
    },
    /** Booms and thuds stacked at once, as many as the voices allow */
    burst: async () => render({ ...Object.fromEntries(Array.from({ length: 8 }, (_, i) => [`b${i}`, { src: sfxRecipe('boom'), vol: 1.5, gap: 0, max: 8 }])) }, (sfx) => {
      for (let i = 0; i < 8; i++) for (let j = 0; j < 4; j++) sfx.play(`b${i}`, { vol: 1.5 });
    }),
    /** A file: decoded from a data: URL, played at a rate */
    file: async (rate: number) => render({ tone: { src: wav(440, 0.3), vary: 0 } }, (sfx) => void sfx.play('tone', { rate }), 1),
    /** A sound far to the right of the listener */
    pan: async () => render({ tone: { src: wav(440, 0.3), vary: 0 } }, (sfx) => {
      sfx.listener({ x: 0, y: 0, range: 100 });
      sfx.play('tone', { at: { x: 400, y: 0 } });
    }, 1),
  },
});
