// The game's canvas (red) under a DOM screen (a purple button), and the recorder watch the Playgama portal installs.
// A second listener, registered after it and not in the capture phase, plays the Bridge: it looks for the first canvas.
import { watchRecorder } from '../../src/recorder';

const canvas = document.getElementById('game') as HTMLCanvasElement;
canvas.width = innerWidth;
canvas.height = innerHeight;
const ctx = canvas.getContext('2d')!;
ctx.fillStyle = 'rgb(220, 30, 30)';
ctx.fillRect(0, 0, canvas.width, canvas.height);

watchRecorder();
const bridgeSaw: string[] = [];
addEventListener('message', (e) => {
  if (e.data?.type === 'recorder') bridgeSaw.push(document.querySelector('canvas')?.id ?? 'none');
});
(window as unknown as { __t: unknown }).__t = { bridgeSaw };
