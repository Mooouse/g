// "Remove ads" purchase (Google Play Billing via @capgo/native-purchases): one managed product.
// Where the buy and restore buttons live is up to the kit (in games for children — behind the parent gate).
// Providers: Google Play (Android), a stub (dev builds), none (web build — no buttons).

import { Capacitor } from '@capacitor/core';

export type PurchaseResult = 'purchased' | 'pending' | 'cancelled' | 'error';

export interface BillingProvider {
  /** Whether purchases exist on this platform (otherwise the buttons are hidden) */
  readonly available: boolean;
  /** Marks the button in the dev build */
  readonly isTest: boolean;
  /** Price for the button, e.g. "$2.99". null — unknown (offline) */
  price(): Promise<string | null>;
  purchase(): Promise<PurchaseResult>;
  /** Whether "Remove ads" is owned. null — could not find out (offline, no Google Play) */
  isOwned(): Promise<boolean | null>;
}

// Purchase.PurchaseState.PURCHASED in Google Play Billing
const PURCHASED = '1';

type Plugin = typeof import('@capgo/native-purchases');

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('timeout')), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      },
    );
  });
}

class PlayBilling implements BillingProvider {
  readonly available = true;
  readonly isTest = false;
  private readonly mod = import('@capgo/native-purchases');
  private queue: Promise<unknown> = Promise.resolve();

  constructor(private readonly product: string) {}

  /**
   * The plugin keeps a single Google Play connection and closes it at the end of every call,
   * so concurrent calls cut each other off. Run them strictly one at a time,
   * with a timeout so a stuck call can't block the rest.
   */
  private run<T>(task: (m: Plugin) => Promise<T>, timeoutMs: number): Promise<T> {
    const p = this.queue.then(() => this.mod).then((m) => withTimeout(task(m), timeoutMs));
    this.queue = p.catch(() => {});
    return p;
  }

  async price(): Promise<string | null> {
    try {
      return await this.run(async ({ NativePurchases, PURCHASE_TYPE }) => {
        const { product } = await NativePurchases.getProduct({ productIdentifier: this.product, productType: PURCHASE_TYPE.INAPP });
        return product.priceString || null;
      }, 20_000);
    } catch {
      return null;
    }
  }

  async purchase(): Promise<PurchaseResult> {
    try {
      return await this.run(async ({ NativePurchases, PURCHASE_TYPE }) => {
        // The plugin's auto-acknowledge doesn't wait for Google and can be cut off — acknowledge ourselves.
        // Without acknowledgement Google refunds the purchase after 3 days.
        const t = await NativePurchases.purchaseProduct({
          productIdentifier: this.product,
          productType: PURCHASE_TYPE.INAPP,
          quantity: 1,
          autoAcknowledgePurchases: false,
        });
        if (t.purchaseState !== undefined && t.purchaseState !== PURCHASED) return 'pending';
        if (t.purchaseToken && !t.isAcknowledged) {
          // If it fails, isOwned() acknowledges again on the next launch
          await NativePurchases.acknowledgePurchase({ purchaseToken: t.purchaseToken }).catch(() => {});
        }
        return 'purchased';
      }, 5 * 60_000);
    } catch (e) {
      const err = e as { code?: string; message?: string };
      if (err.code === 'USER_CANCELED') return 'cancelled';
      if (err.code === 'ITEM_ALREADY_OWNED') return 'purchased';
      if (err.message?.includes('pending')) return 'pending';
      console.warn('[billing] purchase failed', e);
      return 'error';
    }
  }

  async isOwned(): Promise<boolean | null> {
    try {
      return await this.run(async ({ NativePurchases, PURCHASE_TYPE }) => {
        const { purchases } = await NativePurchases.getPurchases({ productType: PURCHASE_TYPE.INAPP });
        const owned = purchases.filter(
          (p) => p.productIdentifier === this.product && (p.purchaseState ?? PURCHASED) === PURCHASED,
        );
        // Acknowledge again if it didn't go through at purchase time (or the payment was pending)
        for (const p of owned) {
          if (p.isAcknowledged === false && p.purchaseToken) {
            await NativePurchases.acknowledgePurchase({ purchaseToken: p.purchaseToken }).catch(() => {});
          }
        }
        return owned.length > 0;
      }, 30_000);
    } catch (e) {
      console.warn('[billing] query failed', e);
      return null;
    }
  }
}

/** Stub for npm run dev: purchase via confirm(), "ownership" kept in sessionStorage */
class StubBilling implements BillingProvider {
  readonly available = true;
  readonly isTest = true;
  private readonly key: string;

  constructor(product: string) {
    this.key = `stub.${product}`;
  }

  async price(): Promise<string | null> {
    return '$2.99';
  }

  async purchase(): Promise<PurchaseResult> {
    if (!window.confirm('Test purchase "Remove ads" ($2.99). Buy?')) return 'cancelled';
    try {
      sessionStorage.setItem(this.key, '1');
    } catch {
      // private mode — doesn't matter
    }
    return 'purchased';
  }

  async isOwned(): Promise<boolean | null> {
    try {
      return sessionStorage.getItem(this.key) === '1';
    } catch {
      return null;
    }
  }
}

class NoBilling implements BillingProvider {
  readonly available = false;
  readonly isTest = false;
  async price(): Promise<string | null> {
    return null;
  }
  async purchase(): Promise<PurchaseResult> {
    return 'error';
  }
  async isOwned(): Promise<boolean | null> {
    return null;
  }
}

export interface BillingOptions {
  /** Google Play product id of the one-time "Remove ads" purchase */
  product: string;
}

export function createBilling(opts: BillingOptions | null): BillingProvider {
  if (!opts) return new NoBilling();
  if (Capacitor.isNativePlatform()) return new PlayBilling(opts.product);
  if (import.meta.env.DEV) return new StubBilling(opts.product);
  return new NoBilling();
}
