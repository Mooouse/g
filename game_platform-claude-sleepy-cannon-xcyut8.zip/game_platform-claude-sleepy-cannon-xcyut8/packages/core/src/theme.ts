// Theme contract: everything visual that changes from game to game (background, tap target, colors, pop sound).
// Scenes and blocks draw only through the theme, so a reskin is a new theme, not new scenes.

import type { GameAudio } from './audio';

export interface ThemeUi {
  /** Button fill */
  button: string;
  buttonShadow: string;
  /** Icon color on buttons */
  icon: string;
  /** Outline of big titles and pop-up words */
  textOutline: string;
  /** The small grown-up lock in a corner */
  lock: string;
  /** Menu card fills, cycled */
  cardColors: readonly string[];
  /** Empty slot (album) */
  slotEmpty: string;
}

export interface Theme {
  readonly id: string;
  readonly ui: ThemeUi;
  /** Target colors (#rrggbb), also used for confetti and fireworks */
  readonly palette: readonly string[];
  /** Page/splash background color, shown before the first frame */
  readonly background: string;
  /** Background of every screen */
  drawBackground(ctx: CanvasRenderingContext2D, w: number, h: number, time: number): void;
  /** The tap target. (x, y) — center of its body, r — touch radius */
  drawTarget(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string, time: number): void;
  /** Target height relative to its width (hit testing and margins) */
  readonly targetAspect: number;
  /** What hangs below the target (a balloon string), in radii — to keep it on screen */
  readonly targetTail: number;
  /** Sound when a target is popped/caught */
  popSound(audio: GameAudio): void;
}
