// A daily challenge: today's key, a seed from it, and the days a player cleared. What Echoflies wrote by hand for
// Tonight's meadow (and filed as a block request) and Yeet the Gnome for its daily gift: a date key in the save, "done
// today?", a list of days trimmed so the save stays small, and a count that survives the trimming. gp forecast's lever
// "a daily reason to return" asks most games for one. Pure functions over a plain object kept in the game's own save.
//
//   const key = dayKey();                                   // '2026-10-01' (UTC: one challenge for everyone at once)
//   const level = makeLevel(seededRng(daySeed(key, 'echoflies')));
//   save.daily = loadDaily(save.daily);                     // on load: a broken or old save becomes a clean log
//   if (recordDaily(save.daily, key)) pay(reward);          // on a clear: true only the first time that day
//
// No streaks here: a missed day takes nothing away (game-design.md, D56). The log is a calendar of cleared days and a
// count. A week of daily rewards (claimed rewards are never taken back) and a daily order are streak.ts.

/** The days a player cleared (`YYYY-MM-DD`, oldest first, at most `keep`) and how many in all (never less than `days`) */
export interface DailyLog {
  days: string[];
  count: number;
}

const KEY = /^\d{4}-\d{2}-\d{2}$/;
/** How many cleared days a log keeps by default (two months: enough for a calendar, small in a cloud save) */
export const DAILY_KEEP = 60;

/**
 * Today's key, `YYYY-MM-DD`. UTC by default: every player gets the same challenge at the same moment (one shared
 * daily; it turns over at 00:00 UTC, which is evening in the Americas and morning in Asia). `local: true` turns over
 * at the player's own midnight: right for a gift, but two players on different dates then see different days.
 */
export function dayKey(date: Date = new Date(), opts: { local?: boolean } = {}): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return opts.local
    ? `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
    : `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}`;
}

/**
 * A 32-bit seed from a day's key (FNV-1a): neighbouring days get unrelated seeds. `salt` (the game's id) keeps two
 * games from sharing a day's seed. Feed it to `seededRng`, never to `seedRandom` (that is the run's `?seed`).
 */
export function daySeed(key: string, salt = ''): number {
  let h = 0x811c9dc5;
  for (const ch of `${salt}:${key}`) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/** The saved log made safe: real day keys only, each once, oldest first, the last `keep`; the count never shrinks */
export function loadDaily(saved: unknown, keep = DAILY_KEEP): DailyLog {
  const src = (saved && typeof saved === 'object' ? saved : {}) as { days?: unknown; count?: unknown };
  const list = Array.isArray(src.days) ? src.days : Array.isArray(saved) ? saved : [];
  const days = [...new Set(list.filter((d): d is string => typeof d === 'string' && KEY.test(d)))].sort().slice(-keep);
  const n = Number(src.count);
  return { days, count: Math.max(days.length, Number.isFinite(n) ? Math.floor(n) : 0) };
}

/** The day is in the log (cleared): show ✓ on its button, pay its reward once */
export const dailyDone = (log: DailyLog, key: string): boolean => log.days.includes(key);

/**
 * A clear of the day `key`: adds it to the log (trimmed to `keep`, the count goes on) and says whether it is new.
 * Pay the day's reward only on `true`; a replay of a cleared day returns `false` and changes nothing. Save after it.
 */
export function recordDaily(log: DailyLog, key: string, keep = DAILY_KEEP): boolean {
  if (!KEY.test(key) || log.days.includes(key)) return false;
  log.days = [...log.days, key].sort().slice(-keep);
  log.count = Math.max(log.count, 0) + 1;
  return true;
}

// ---------------------------------------------------------------------------------------------
// Visits: is this a return on a new day? (R3: a "welcome back" card — today's daily, the goal left — on the first visit
// of a day; welcomeBack() in @gp/core draws it). Keep the log in the game's save: `save.visit = recordVisit(save.visit).log`.

/** The first and the last day the player opened the game (`YYYY-MM-DD`, the player's own midnight) and on how many days */
export interface VisitLog {
  first: string;
  last: string;
  days: number;
}

export interface Visit {
  /** The log with today in it: save it */
  log: VisitLog;
  /** No earlier visit in the log */
  firstVisit: boolean;
  /** An earlier visit, and on another day: the moment for a "welcome back" */
  newDay: boolean;
  /** Days since the last visit (0 today, 1 yesterday; 0 on a first visit) */
  daysAway: number;
}

const dayNumber = (key: string) => Math.round(Date.UTC(+key.slice(0, 4), +key.slice(5, 7) - 1, +key.slice(8, 10)) / 86400000);

/**
 * Today's visit, from the saved log (anything else is a first visit). `today` defaults to the player's local day — a
 * "welcome back" turns over at their midnight, not at UTC's. A clock set back never makes `daysAway` negative.
 */
export function recordVisit(saved: unknown, today: string = dayKey(new Date(), { local: true })): Visit {
  const s = (saved && typeof saved === 'object' ? saved : {}) as Partial<Record<keyof VisitLog, unknown>>;
  const last = typeof s.last === 'string' && KEY.test(s.last) ? s.last : null;
  if (!last || !KEY.test(today)) return { log: { first: today, last: today, days: 1 }, firstVisit: true, newDay: false, daysAway: 0 };
  const first = typeof s.first === 'string' && KEY.test(s.first) ? s.first : last;
  const n = Number(s.days);
  const days = Math.max(1, Number.isFinite(n) ? Math.floor(n) : 1);
  const away = Math.max(0, dayNumber(today) - dayNumber(last));
  const newDay = away > 0;
  return { log: { first, last: newDay ? today : last, days: newDay ? days + 1 : days }, firstVisit: false, newDay, daysAway: away };
}
