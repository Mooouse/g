// @gp/core/callouts — an announcer that takes turns: one line at a time (its voice and its caption together), the next
// when it is done, by rank rather than by arrival. From Frankengun's host (game22 main.ts: callQ, say, pumpCalls):
//   rank 1 — the arena's news (a boss, a shrine, low health): goes first and cuts a playing line of rank ≥ 3 off the air;
//   rank 2 — rewards (a power-up, a jackpot);
//   rank 3 — big combos (a triple, a rampage);
//   rank 4 — small talk (a double, a headshot): only into silence — dropped while a line plays or waits, or within
//            `quiet` s after one ended (the hit marker says it).
// A streak that climbs while it waits keeps only its latest step; a line kept waiting over `maxWait` s is dropped; a
// line has a cooldown of its own; the queue holds at most `maxQueue`. A line holds for its voice's length (+ a beat), at
// least `minHold`; the music ducks under it through the mixer (by rank, or the line's own depth).
//
//   const host = callouts({
//     lines: { boss: { rank: 1 }, power: { rank: 2 }, triple: { rank: 3, streak: 'kills' }, double: { rank: 4, streak: 'kills', every: 4 } },
//     mixer,                                              // @gp/core/sound's: the music dips under each line
//     play: (key) => voice.say(key),                      // start the voice; return its seconds (0: a caption only)
//     show: (key, holdSec) => caption.show(t(`say.${key}`), holdSec),
//     hide: () => caption.hide(),
//     cut: () => voice.hush(),                            // a rank-1 line took the air
//   });
//   host.say('double');           // from the game's events
//   host.update(dt);              // every frame while the run is on: the game's clock, so the pause holds the queue
//
// Pure and clock-driven (update(dt)): a hidden tab, an ad or the pause screen hold every line where it is.

export type CalloutRank = 1 | 2 | 3 | 4;

export interface CalloutDef {
  rank: CalloutRank;
  /** Lines of one streak (kill counts): a waiting one is replaced by the newer step */
  streak?: string;
  /** Seconds before this line may be said again */
  every?: number;
  /** How far the music dips under it (0–1; default by rank) */
  duck?: number;
}

/** What the queue holds */
export interface CalloutLine {
  key: string;
  rank: CalloutRank;
  /** When it was asked for (the queue's clock, s) */
  at: number;
  /** Anything the game passed with it (a name, a number for the caption) */
  data?: unknown;
}

export interface CalloutsOptions {
  lines: Record<string, CalloutDef>;
  /** Start the line's voice (and anything else); return its length in seconds (0 or nothing: a caption only) */
  play?: (key: string, line: CalloutLine) => number | void;
  /** Show its caption for holdSec */
  show?: (key: string, holdSec: number, line: CalloutLine) => void;
  /** The line is over (or was cut): take the caption down */
  hide?: (key: string) => void;
  /** A rank-1 line cuts the current one: stop its voice now */
  cut?: (key: string) => void;
  /** Music ducking: mixer.duck(depth, sec) (@gp/core/sound's Mixer) */
  mixer?: { duck(depth?: number, sec?: number): void };
  /** Ducking depth by rank (default [0.45, 0.2, 0.3, 0.25]: news the deepest) */
  duckByRank?: readonly [number, number, number, number];
  /** A line waiting longer than this is dropped (default 3 s) */
  maxWait?: number;
  /** Small talk (rank ≥ minorRank) only this long after the last line ended (default 1.5 s) */
  quiet?: number;
  /** The rank that is small talk (default 4) */
  minorRank?: CalloutRank;
  /** Rank-1 lines cut a playing line of this rank or lower in importance (default 3) */
  cutsFrom?: CalloutRank;
  /** At most this many waiting (default 3; the least important go first) */
  maxQueue?: number;
  /** A line holds at least this long (default 1.1 s) and its voice + `pad` (default 0.2 s) */
  minHold?: number;
  pad?: number;
}

export interface Callouts {
  /** Ask for a line; false when it was dropped at once (unknown, cooling down, small talk into noise) */
  say(key: string, data?: unknown): boolean;
  /** Advance the queue's clock (the game's frame or step dt, only while playing) and start the next line when free */
  update(dt: number): void;
  /** The line on the air (null: silence) */
  readonly current: (CalloutLine & { hold: number; until: number }) | null;
  /** The lines waiting, in the order they will play */
  readonly queue: readonly CalloutLine[];
  /** The queue's clock, seconds */
  readonly now: number;
  /** Everything dropped, the current line taken down (a run ends, the results screen) */
  clear(): void;
}

export function callouts(o: CalloutsOptions): Callouts {
  const duckBy = o.duckByRank ?? [0.45, 0.2, 0.3, 0.25];
  const maxWait = o.maxWait ?? 3;
  const quiet = o.quiet ?? 1.5;
  const minor = o.minorRank ?? 4;
  const cutsFrom = o.cutsFrom ?? 3;
  const maxQueue = o.maxQueue ?? 3;
  const minHold = o.minHold ?? 1.1;
  const pad = o.pad ?? 0.2;
  const queue: CalloutLine[] = [];
  const saidAt = new Map<string, number>();
  let now = 0;
  let current: (CalloutLine & { hold: number; until: number }) | null = null;
  /** When the last line ended (−∞: none yet) */
  let endedAt = -Infinity;

  function end(cutIt: boolean): void {
    if (!current) return;
    const k = current.key;
    if (cutIt) o.cut?.(k);
    o.hide?.(k);
    current = null;
    endedAt = now;
  }

  function pump(): void {
    if (current && now < current.until) return;
    if (current) end(false);
    let next = queue.shift();
    while (next && now - next.at > maxWait) next = queue.shift();
    if (!next) return;
    const def = o.lines[next.key];
    const voice = Number(o.play?.(next.key, next) ?? 0) || 0;
    const hold = Math.max(minHold, voice + pad);
    current = { ...next, hold, until: now + hold };
    o.show?.(next.key, hold, next);
    o.mixer?.duck(def.duck ?? duckBy[next.rank - 1], hold);
  }

  const api: Callouts = {
    say(key, data) {
      const def = o.lines[key];
      if (!def) return false;
      const last = saidAt.get(key);
      if (def.every && last !== undefined && now - last < def.every) return false;
      // Small talk only into silence
      if (def.rank >= minor && (current || queue.length || now - endedAt < quiet)) return false;
      saidAt.set(key, now);
      const line: CalloutLine = { key, rank: def.rank, at: now, ...(data !== undefined ? { data } : {}) };
      // A streak keeps its latest step: the waiting one of the same streak goes
      if (def.streak) {
        const i = queue.findIndex((q) => o.lines[q.key]?.streak === def.streak);
        if (i >= 0) queue.splice(i, 1);
      }
      // In by rank, after the lines of the same rank
      const at = queue.findIndex((q) => q.rank > def.rank);
      if (at < 0) queue.push(line);
      else queue.splice(at, 0, line);
      if (queue.length > maxQueue) queue.length = maxQueue;
      // The news cuts a combo call off the air
      if (def.rank === 1 && current && current.rank >= cutsFrom) end(true);
      pump();
      return queue.includes(line) || (current !== null && current.key === key && current.at === line.at);
    },
    update(dt) {
      now += Math.max(0, dt);
      pump();
    },
    get current() {
      return current;
    },
    get queue() {
      return queue;
    },
    get now() {
      return now;
    },
    clear() {
      queue.length = 0;
      end(true);
    },
  };
  return api;
}
