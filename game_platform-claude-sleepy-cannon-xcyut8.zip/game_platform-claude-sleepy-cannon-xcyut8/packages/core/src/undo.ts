// An undo history for a puzzle's moves: Hang the Moon and Nimbus Drift wrote the same one (`history: State[]`, the
// current state is the last, the move count is its length − 1, undo pops but never the start). States are kept whole,
// so a move function must return a new state rather than change the old one.

export class UndoHistory<S> {
  private states: S[];

  constructor(start: S) {
    this.states = [start];
  }

  /** The state now */
  get current(): S {
    return this.states[this.states.length - 1];
  }

  /** Moves made since the start (undone ones don't count) */
  get moves(): number {
    return this.states.length - 1;
  }

  get canUndo(): boolean {
    return this.states.length > 1;
  }

  /** After a move: the new state becomes the current one */
  push(next: S): void {
    this.states.push(next);
  }

  /** Back one move; false (and nothing changes) at the start */
  undo(): boolean {
    if (this.states.length <= 1) return false;
    this.states.pop();
    return true;
  }

  /** Restart the level, or start another one */
  reset(start: S): void {
    this.states = [start];
  }

  /** Every state from the start to now (for a replay or a solver's hint from here) */
  all(): readonly S[] {
    return this.states;
  }
}
