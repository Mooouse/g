// Dice: a seeded pool of dice with faces you can rewrite, rerolls as a limited resource, slots that take dice by a
// rule (any, even, ≥ 4, exactly 6, a pair, a sum of 7), and the exact odds of an outcome for the UI's hints. Dice
// placement as Dicey Dungeons and Sky Team play it: the luck comes first, the decision after
// (docs/research/board-games-2026-10.md §1.4).
//
// Pure and save-safe like Zones: the Dice object holds the slots and their rules, the state is plain JSON (each die's
// faces and face up, where it is placed, the rerolls left, the rng's position) — saved as it is, sanitize()d on load,
// and every change returns a new state, so an UndoHistory of states undoes a placement. Undoing a roll brings back
// the same roll: the rng travels with the state, so undo can't be used to fish for a better one.
//
//   const tray = new Dice({ slots: [{ id: 'engine', accepts: slotRules.atLeast(4) }, { id: 'flaps', size: 2, accepts: slotRules.sum(7), done: sumIs(7) }] });
//   let s = tray.roll(tray.start([D6, D6, D6], seed, { rerolls: 1 }));
//   s = tray.place(s, 0, 'engine') ?? s;          // null when the die doesn't fit: the slot says no
//   tray.chanceAfterReroll(s, [1, 2], (v) => v[1] + v[2] === 7); // "reroll both: 17% to land the flaps"

import { seededRng } from './rng.ts';

export type Face = number | string;

/** Six-sided pips */
export const D6: readonly number[] = [1, 2, 3, 4, 5, 6];

export interface Die<F extends Face = number> {
  /** The faces (rewritten by forge) */
  faces: F[];
  /** The face up (an index into faces), null before the first roll */
  up: number | null;
  /** The slot it is placed in (placed dice don't reroll) */
  slot: string | null;
  /** Kept out of a reroll */
  held: boolean;
}

export interface DiceState<F extends Face = number> {
  dice: Die<F>[];
  rerolls: number;
  rng: number;
}

/** A slot's rule: does it take these values (the dice in it, the new one last); partial sets for a slot of several */
export type SlotRule<F extends Face = number> = (values: readonly F[], state: DiceState<F>) => boolean;

export interface SlotDef<F extends Face = number> {
  id: string;
  /** Dice it takes (default 1) */
  size?: number;
  accepts?: SlotRule<F>;
  /** Is it done (default: full and accepted) — a sum slot is done at its total */
  done?: (values: readonly F[], state: DiceState<F>) => boolean;
}

const num = (v: Face): number => (typeof v === 'number' ? v : Number.parseFloat(v));

/** The usual slot rules; partial sets pass while they can still be completed */
export const slotRules = {
  any: <F extends Face = number>(): SlotRule<F> => () => true,
  even: <F extends Face = number>(): SlotRule<F> => (v) => v.every((x) => num(x) % 2 === 0),
  odd: <F extends Face = number>(): SlotRule<F> => (v) => v.every((x) => Math.abs(num(x) % 2) === 1),
  atLeast: <F extends Face = number>(n: number): SlotRule<F> => (v) => v.every((x) => num(x) >= n),
  atMost: <F extends Face = number>(n: number): SlotRule<F> => (v) => v.every((x) => num(x) <= n),
  exactly: <F extends Face = number>(face: F): SlotRule<F> => (v) => v.every((x) => x === face),
  oneOf: <F extends Face = number>(faces: readonly F[]): SlotRule<F> => (v) => v.every((x) => faces.includes(x)),
  /** All the same (a pair, a triple) */
  same: <F extends Face = number>(): SlotRule<F> => (v) => v.every((x) => x === v[0]),
  /** All different */
  distinct: <F extends Face = number>(): SlotRule<F> => (v) => new Set(v).size === v.length,
  /** Adds up to at most `total` while filling (pair it with done: sumIs(total)) */
  sum: <F extends Face = number>(total: number): SlotRule<F> => (v) => v.reduce((s, x) => s + num(x), 0) <= total,
  /** A straight once sorted (1-2-3), partial sets with no repeats and a span that still fits */
  run: <F extends Face = number>(length: number): SlotRule<F> => (v) => {
    const n = v.map(num);
    return new Set(n).size === n.length && Math.max(...n) - Math.min(...n) < length;
  },
  /** Every rule at once */
  all: <F extends Face = number>(...rules: SlotRule<F>[]): SlotRule<F> => (v, s) => rules.every((r) => r(v, s)),
};

/** "Done" when the values add up to exactly `total` */
export const sumIs = <F extends Face = number>(total: number) => (v: readonly F[]): boolean => v.reduce((s, x) => s + num(x), 0) === total;

const isInt = (n: unknown): n is number => typeof n === 'number' && Number.isSafeInteger(n);

/** Above this many outcomes, odds are sampled (seeded, so the number is the same every time) instead of counted */
export const EXACT_ODDS_MAX = 200_000;
const SAMPLES = 20_000;

/**
 * The chance a pool's outcome passes `test`: every combination of faces counted when there are few enough
 * (EXACT_ODDS_MAX), else a seeded sample. `pools[i]` is die i's faces — one face for a die that isn't rolled.
 */
export function oddsOf<F extends Face = number>(pools: readonly (readonly F[])[], test: (values: F[]) => boolean): number {
  if (!pools.length) return test([]) ? 1 : 0;
  if (pools.some((p) => !p.length)) return 0;
  const total = pools.reduce((n, p) => n * p.length, 1);
  if (total <= EXACT_ODDS_MAX) {
    let hit = 0;
    const idx = pools.map(() => 0);
    const vals = pools.map((p) => p[0]);
    for (let k = 0; k < total; k++) {
      if (test([...vals])) hit++;
      for (let i = 0; i < idx.length; i++) {
        idx[i]++;
        if (idx[i] < pools[i].length) {
          vals[i] = pools[i][idx[i]];
          break;
        }
        idx[i] = 0;
        vals[i] = pools[i][0];
      }
    }
    return hit / total;
  }
  const r = seededRng(0x5eed);
  let hit = 0;
  for (let k = 0; k < SAMPLES; k++) if (test(pools.map((p) => p[r.int(p.length)]))) hit++;
  return hit / SAMPLES;
}

/** The distribution of a pool's sum: { 2: 1/36, …, 12: 1/36 } for 2d6 (exact by convolution) */
export function sumOdds(pools: readonly (readonly Face[])[]): Map<number, number> {
  let dist = new Map<number, number>([[0, 1]]);
  for (const faces of pools) {
    const next = new Map<number, number>();
    for (const [s, p] of dist) for (const f of faces) next.set(s + num(f), (next.get(s + num(f)) ?? 0) + p / faces.length);
    dist = next;
  }
  return new Map([...dist].sort((a, b) => a[0] - b[0]));
}

export class Dice<F extends Face = number> {
  readonly slots: readonly SlotDef<F>[];
  private readonly byId: Map<string, SlotDef<F>>;

  constructor(def: { slots?: readonly SlotDef<F>[] } = {}) {
    const slots = def.slots ?? [];
    const ids = new Set<string>();
    for (const sl of slots) {
      if (!sl.id || ids.has(sl.id)) throw new Error(`dice: slot "${sl.id}" is empty or twice`);
      if (sl.size !== undefined && !(isInt(sl.size) && sl.size >= 1)) throw new Error(`dice: slot ${sl.id}: size must be an integer ≥ 1`);
      ids.add(sl.id);
    }
    this.slots = slots;
    this.byId = new Map(slots.map((s) => [s.id, s]));
  }

  // --- State ------------------------------------------------------------------------------------------------------

  /** A pool of dice (each its list of faces), unrolled; `rerolls` for the turn (default 0) */
  start(pool: readonly (readonly F[])[], seed: number, opts: { rerolls?: number } = {}): DiceState<F> {
    for (const f of pool) if (!f.length) throw new Error('dice: a die needs at least one face');
    return { dice: pool.map((faces) => ({ faces: [...faces], up: null, slot: null, held: false })), rerolls: Math.max(0, Math.floor(opts.rerolls ?? 0)), rng: seed >>> 0 };
  }

  /** A loaded state made safe: dice with faces, a face up in range, slots that exist and aren't overfull */
  sanitize(raw: unknown, valid: (f: unknown) => f is F = (f): f is F => typeof f === 'number' || typeof f === 'string', seed = 1): DiceState<F> {
    const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
    const used = new Map<string, number>();
    const dice: Die<F>[] = [];
    for (const d of Array.isArray(r.dice) ? (r.dice as Partial<Die<F>>[]) : []) {
      if (!d || !Array.isArray(d.faces)) continue;
      const faces = (d.faces as unknown[]).filter(valid);
      if (!faces.length) continue;
      const up = isInt(d.up) && d.up >= 0 && d.up < faces.length ? d.up : null;
      let slot = typeof d.slot === 'string' && this.byId.has(d.slot) && up !== null ? d.slot : null;
      if (slot) {
        const n = (used.get(slot) ?? 0) + 1;
        if (n > (this.byId.get(slot)!.size ?? 1)) slot = null;
        else used.set(slot, n);
      }
      dice.push({ faces, up, slot, held: d.held === true });
    }
    const rr = r.rerolls;
    return { dice, rerolls: isInt(rr) && rr > 0 ? rr : 0, rng: isInt(r.rng) && r.rng >= 0 && r.rng < 2 ** 32 ? r.rng : seed >>> 0 };
  }

  // --- Reading ----------------------------------------------------------------------------------------------------

  /** The face up of die i (null before it is rolled) */
  value(s: DiceState<F>, i: number): F | null {
    const d = s.dice[i];
    return d && d.up !== null ? d.faces[d.up] : null;
  }

  /** Every die's face up */
  values(s: DiceState<F>): (F | null)[] {
    return s.dice.map((_, i) => this.value(s, i));
  }

  /** The dice in a slot, in the order placed (their indices) */
  inSlot(s: DiceState<F>, slot: string): number[] {
    return s.dice.map((d, i) => (d.slot === slot ? i : -1)).filter((i) => i >= 0);
  }

  /** The dice not placed yet */
  free(s: DiceState<F>): number[] {
    return s.dice.map((d, i) => (d.slot === null ? i : -1)).filter((i) => i >= 0);
  }

  /** Is a slot done (full and accepted, or its own done rule) */
  done(s: DiceState<F>, slot: string): boolean {
    const def = this.byId.get(slot);
    if (!def) return false;
    const vals = this.inSlot(s, slot).map((i) => this.value(s, i)!);
    if (def.done) return def.done(vals, s);
    return vals.length === (def.size ?? 1) && (def.accepts?.(vals, s) ?? true);
  }

  /** Can die i go into a slot now: rolled, not placed, room in the slot, and the slot's rule takes it */
  canPlace(s: DiceState<F>, i: number, slot: string): boolean {
    const d = s.dice[i];
    const def = this.byId.get(slot);
    if (!d || !def || d.up === null || d.slot !== null) return false;
    const inside = this.inSlot(s, slot);
    if (inside.length >= (def.size ?? 1) || this.done(s, slot)) return false;
    const vals = [...inside.map((j) => this.value(s, j)!), d.faces[d.up]];
    return def.accepts?.(vals, s) ?? true;
  }

  /** Every legal (die, slot) pair: the hint, the bot */
  placements(s: DiceState<F>): { die: number; slot: string }[] {
    return this.free(s).flatMap((die) => this.slots.filter((sl) => this.canPlace(s, die, sl.id)).map((sl) => ({ die, slot: sl.id })));
  }

  /** The chance a single roll of die i shows a face that passes `test` */
  chance(s: DiceState<F>, i: number, test: (face: F) => boolean): number {
    const d = s.dice[i];
    return d ? d.faces.filter(test).length / d.faces.length : 0;
  }

  /**
   * The chance the pool passes `test` after rerolling the dice listed (the others keep their faces): "reroll these two:
   * 42% to make the pair". Unrolled dice not listed count as rolled too.
   */
  chanceAfterReroll(s: DiceState<F>, reroll: readonly number[], test: (values: F[]) => boolean): number {
    const pools = s.dice.map((d, i) => (reroll.includes(i) || d.up === null ? d.faces : [d.faces[d.up]]));
    return oddsOf(pools, test);
  }

  // --- Changes ------------------------------------------------------------------------------------------------------

  /** Roll every die that isn't placed or held (the turn's roll: no reroll spent) */
  roll(s: DiceState<F>): DiceState<F> {
    return this.rollWhere(s, (d) => d.slot === null && !d.held);
  }

  /** Spend a reroll on the dice listed (placed ones stay); null without rerolls or a die to reroll */
  reroll(s: DiceState<F>, which: readonly number[]): DiceState<F> | null {
    if (s.rerolls <= 0) return null;
    const pick = new Set(which.filter((i) => s.dice[i] && s.dice[i].slot === null));
    if (!pick.size) return null;
    const next = this.rollWhere(s, (_, i) => pick.has(i));
    return { ...next, rerolls: s.rerolls - 1 };
  }

  /** More rerolls (a rewarded ad, a relic) */
  addRerolls(s: DiceState<F>, n = 1): DiceState<F> {
    return { ...this.copy(s), rerolls: s.rerolls + Math.max(0, Math.floor(n)) };
  }

  /** Keep a die out of the next roll (or let it roll again) */
  hold(s: DiceState<F>, i: number, held = true): DiceState<F> {
    const c = this.copy(s);
    if (c.dice[i]) c.dice[i].held = held;
    return c;
  }

  /** Turn a die to one of its faces (a "bump" or "flip" card) — null for a bad index */
  setFace(s: DiceState<F>, i: number, face: number): DiceState<F> | null {
    const d = s.dice[i];
    if (!d || !isInt(face) || face < 0 || face >= d.faces.length || d.slot !== null) return null;
    const c = this.copy(s);
    c.dice[i].up = face;
    return c;
  }

  /** Forge: rewrite one face of a die for good (Dice Forge, Dicey Dungeons' upgrades) — null for a bad index */
  forge(s: DiceState<F>, i: number, face: number, to: F): DiceState<F> | null {
    const d = s.dice[i];
    if (!d || !isInt(face) || face < 0 || face >= d.faces.length) return null;
    const c = this.copy(s);
    c.dice[i].faces[face] = to;
    return c;
  }

  /** A new die into the pool (unrolled), or one taken out */
  addDie(s: DiceState<F>, faces: readonly F[]): DiceState<F> {
    if (!faces.length) throw new Error('dice: a die needs at least one face');
    const c = this.copy(s);
    c.dice.push({ faces: [...faces], up: null, slot: null, held: false });
    return c;
  }

  removeDie(s: DiceState<F>, i: number): DiceState<F> | null {
    if (!s.dice[i]) return null;
    const c = this.copy(s);
    c.dice.splice(i, 1);
    return c;
  }

  /** Place die i in a slot; null if it can't go there (canPlace) */
  place(s: DiceState<F>, i: number, slot: string): DiceState<F> | null {
    if (!this.canPlace(s, i, slot)) return null;
    const c = this.copy(s);
    c.dice[i].slot = slot;
    c.dice[i].held = false;
    return c;
  }

  /** Take die i back out of its slot */
  unplace(s: DiceState<F>, i: number): DiceState<F> | null {
    if (!s.dice[i] || s.dice[i].slot === null) return null;
    const c = this.copy(s);
    c.dice[i].slot = null;
    return c;
  }

  /** A new turn: every die back in the tray, unrolled and unheld, the turn's rerolls */
  clear(s: DiceState<F>, rerolls = 0): DiceState<F> {
    return { dice: s.dice.map((d) => ({ faces: [...d.faces], up: null, slot: null, held: false })), rerolls: Math.max(0, Math.floor(rerolls)), rng: s.rng };
  }

  private rollWhere(s: DiceState<F>, which: (d: Die<F>, i: number) => boolean): DiceState<F> {
    const c = this.copy(s);
    const r = seededRng(s.rng);
    c.dice.forEach((d, i) => {
      if (which(d, i)) d.up = r.int(d.faces.length);
    });
    return { ...c, rng: r.state() };
  }

  private copy(s: DiceState<F>): DiceState<F> {
    return { dice: s.dice.map((d) => ({ ...d, faces: [...d.faces] })), rerolls: s.rerolls, rng: s.rng };
  }
}
