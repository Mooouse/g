// Prestige: start the economy again for a permanent multiplier (Cookie Clicker's ascension, AdVenture Capitalist's
// angels; Idle Garage Evolution wrote it by hand). An idle / clicker / tycoon block (@genre idle). Pure: the condition,
// the currency a reset gives, the multiplier it buys, the save keys a reset clears, and the lives the balance model
// walks (docs/guides/upgrades.md → Idle games → Prestige).
//
//   const PRESTIGE = new Prestige({
//     needs: (s: Save) => s.garage >= 5,                   // when the button shows: the fifth garage open
//     gain: Prestige.root(1e6, 2),                         // stars = floor(sqrt(lifetime / 1M)) over all lives
//     perPoint: 0.5,                                       // each star: +50 % income
//     keeps: ['prestige', 'lifetime', 'settings', 'streak', 'order', 'offline', 'visit'],
//   });
//   save.prestige = PRESTIGE.sanitize(save.prestige);
//   const income = base * PRESTIGE.multiplier(save.prestige);
//   PRESTIGE.next(save.lifetime, save.prestige);           // the button: "+3 ★"
//   const done = PRESTIGE.prestige(save, save.lifetime, save.prestige);   // null: not now
//   if (done) { save = PRESTIGE.restart(save, SAVE_DEFAULTS); save.prestige = done.save; host.save(save); }
//
// The points come from the lifetime earnings of all lives (minus what was already gained), as in both games above: a
// reset after a short life gives little, and playing longer before a reset always pays.

import type { BalanceModel } from './balance-model.ts';

/**
 * The genres this block is for (the platform's genre registry lists it). A game of another genre with an idle layer on
 * top (a den that earns while you raid, a rebirth in a speed runner) declares it — `money.hybrid: [idle]` in game.yaml —
 * and the block fits it too (W_GENRE_BLOCK stays quiet; docs/guides/live-world.md → Hybrids)
 */
export const PRESTIGE_GENRES = ['idle'] as const;

/** What it keeps in the save (`save.prestige`: put that key in `keeps`) */
export interface PrestigeSave {
  /** Points (stars, angels) the player holds: they give the multiplier */
  points: number;
  /** Points gained in all (the gain is counted against it) */
  earned: number;
  /** Prestiges done */
  count: number;
}

export interface PrestigeOptions<S> {
  /** When a prestige is offered (the game's own milestone): the fifth garage, the last stage cleared */
  needs: (state: S) => boolean;
  /** The points all lifetime earnings are worth (all lives together): `Prestige.root(1e6, 2)` = floor(sqrt(lifetime / 1e6)) */
  gain: (lifetime: number) => number;
  /** The multiplier each point adds (default 0.5: ×1.5 with one point, ×2 with two) */
  perPoint?: number;
  /** The save keys a reset keeps (the prestige field, lifetime earnings, settings, the daily blocks …) */
  keeps: readonly string[];
}

/** One life of `lives()`: the walk the balance model reads */
export interface PrestigeLife {
  /** 0: the first life (before any prestige) */
  life: number;
  /** The multiplier during this life */
  multiplier: number;
  /** Earned in this life */
  earned: number;
  /** Lifetime earnings at its end */
  lifetime: number;
  /** Points the prestige at its end gave */
  gained: number;
  /** Points held after it */
  points: number;
}

const finite = (n: unknown, d = 0) => (typeof n === 'number' && Number.isFinite(n) ? n : d);

/** A prestige layer (@genre idle): see the module's comment for the whole flow */
export class Prestige<S = unknown> {
  readonly perPoint: number;
  readonly keeps: readonly string[];

  constructor(private readonly opts: PrestigeOptions<S>) {
    const p = opts.perPoint ?? 0.5;
    if (!(p > 0) || !Number.isFinite(p)) throw new Error('Prestige: perPoint must be a positive number');
    if (!opts.keeps.length) throw new Error('Prestige: keeps lists no key — the prestige field itself must survive a reset');
    this.perPoint = p;
    this.keeps = [...opts.keeps];
  }

  /**
   * The gain of a root curve: floor(k × (lifetime / unit)^(1/root)) — root 2 (square root: 4× the earnings for 2× the
   * points, AdVenture Capitalist) or 3 (cube root: 8×, Cookie Clicker)
   */
  static root(unit: number, root = 2, k = 1): (lifetime: number) => number {
    if (!(unit > 0) || !(root >= 1)) throw new Error('Prestige.root: unit > 0 and root ≥ 1');
    return (lifetime) => Math.floor(k * Math.pow(Math.max(0, finite(lifetime)) / unit, 1 / root) + 1e-9);
  }

  /** A fresh prestige save */
  initial(): PrestigeSave {
    return { points: 0, earned: 0, count: 0 };
  }

  /** The saved field made safe: non-negative integers, never more points held than earned */
  sanitize(raw: unknown): PrestigeSave {
    const s = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
    const n = (v: unknown) => Math.max(0, Math.floor(finite(v)));
    const points = n(s.points);
    return { points, earned: Math.max(n(s.earned), points), count: n(s.count) };
  }

  /** The multiplier the points held give: 1 + points × perPoint */
  multiplier(ps: PrestigeSave): number {
    return 1 + Math.max(0, finite(ps.points)) * this.perPoint;
  }

  /** The points a prestige would give now: gain(lifetime) minus those already gained, never below 0 */
  next(lifetime: number, ps: PrestigeSave): number {
    const total = Math.floor(finite(this.opts.gain(Math.max(0, finite(lifetime)))));
    return Math.max(0, total - Math.max(0, finite(ps.earned)));
  }

  /** A prestige is possible: the game's condition holds and it would give at least one point */
  can(state: S, lifetime: number, ps: PrestigeSave): boolean {
    return this.opts.needs(state) && this.next(lifetime, ps) > 0;
  }

  /**
   * Prestige now: the new prestige save and the points gained, or null when it can't. Then clear the other keys
   * (`reset()` names them, `restart()` does it) and save
   */
  prestige(state: S, lifetime: number, ps: PrestigeSave): { save: PrestigeSave; gained: number } | null {
    if (!this.can(state, lifetime, ps)) return null;
    const gained = this.next(lifetime, ps);
    return { save: { points: ps.points + gained, earned: ps.earned + gained, count: ps.count + 1 }, gained };
  }

  /** The save keys a reset clears: every key of `save` not in `keeps` */
  reset(save: object): string[] {
    return Object.keys(save).filter((k) => !this.keeps.includes(k));
  }

  /** The save after a reset: `defaults` for every cleared key (a deep copy), the kept keys as they were */
  restart<T extends object>(save: T, defaults: T): T {
    const out = structuredClone(defaults) as Record<string, unknown>;
    const src = save as Record<string, unknown>;
    for (const k of this.keeps) if (k in src) out[k] = src[k];
    return out as T;
  }

  /**
   * The lives the balance model walks: each life earns `perLife(life, multiplier)` (in the game's currency, the
   * multiplier of that life applied by you or not) and ends in a prestige. `lives(3, …)[2].multiplier` is the third
   * life's multiplier; `multiplierAfter(n, …)` is the one after n prestiges
   */
  lives(n: number, perLife: number | ((life: number, multiplier: number) => number)): PrestigeLife[] {
    const out: PrestigeLife[] = [];
    let ps = this.initial();
    let lifetime = 0;
    for (let life = 0; life < Math.max(0, Math.floor(n)); life++) {
      const multiplier = this.multiplier(ps);
      const earned = Math.max(0, finite(typeof perLife === 'function' ? perLife(life, multiplier) : perLife));
      lifetime += earned;
      const gained = this.next(lifetime, ps);
      ps = { points: ps.points + gained, earned: ps.earned + gained, count: ps.count + 1 };
      out.push({ life, multiplier, earned, lifetime, gained, points: ps.points });
    }
    return out;
  }

  /** The multiplier after n prestiges, each after a life that earns `perLife` (1 for n = 0) */
  multiplierAfter(n: number, perLife: number | ((life: number, multiplier: number) => number)): number {
    const l = this.lives(n, perLife);
    return l.length ? this.multiplier({ points: l[l.length - 1].points, earned: 0, count: 0 }) : 1;
  }
}

/**
 * The balance model of a life after a prestige: the same tables with the multiplier applied — to every stage's
 * reward (income, the default: an idle game's prestige multiplies earnings) or to the start's power. Walk it with
 * walkModel() / solveModel() to see how much faster the second life runs (clearly faster to the same point: 2–5× is
 * a heuristic, not a measured number). @genre idle
 */
export function prestigeModel(model: BalanceModel, multiplier: number, on: 'reward' | 'power' = 'reward'): BalanceModel {
  const m = Number.isFinite(multiplier) && multiplier > 0 ? multiplier : 1;
  if (on === 'power') return { ...model, start: { ...model.start, power: model.start.power * m } };
  return { ...model, stages: model.stages.map((s) => ({ ...s, reward: s.reward * m })) };
}
