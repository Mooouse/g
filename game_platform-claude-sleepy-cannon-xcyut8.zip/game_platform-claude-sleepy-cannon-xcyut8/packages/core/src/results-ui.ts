// The results screen that launches the next run (T1 and R2 in docs/research/feedback-and-metrics-2026-10.md). Each
// results screen is an exit: Hang the Moon had 14 of them in a 15-minute session, and the games whose players stayed
// (Candle Crypt, Spin Brawl) put the next run one big tap away. So:
// - the big button continues play — "Play again" or "Next" (data-gp="again" / "next") — and Menu is small and plain;
// - the next goal and how far along it is ("Lithium Candle · 82 %"): a session that ends on an unfinished goal brings
//   the player back (the balance model's session-end hook; `goalFromSnapshot` reads its shape);
// - optionally, a level game goes on by itself after a few seconds (any tap or key stops the countdown); an auto-continue
//   never shows an ad (ads only on the player's own choice), the primary button does (host.adBreak());
// - the platform's words in the player's language (gp.playAgain, gp.next, gp.menu, gp.results.*), the game's own lines;
// - themeable with screenTheme() (one look for every platform screen) or CSS variables on #gp-results (--gp-results-bg,
//   -ink, -muted, -accent, -accent-ink, -bar, -radius, -font: they win over the theme),
//   and with the game's own plain rules: the platform's style goes first in <head>, each rule at the lowest specificity
//   that still keeps a game's generic `#ui button` look out (an id and a class), so `#gp-results h2 { … }` or
//   `#gp-results .gp-primary { … }` in the game's CSS wins without `#ui #gp-results`;
// - centred in the root by itself (absolutely, in the root's box when the root is positioned, as #ui is): a game's
//   `#gp-results { position: static; margin: 0 }` puts it back into the root's own layout.
//
//   mountResults(ui, { host, title: host.t('gp.newBest'), lines: [host.t('score', { n })], primary: 'again',
//     onPrimary: play, onMenu: showTitle, goal: { label: host.t('target.star.name'), progress: save.coins / 50 } });

import type { GameHost } from './host.ts';
import { FONT_FALLBACK } from './i18n.ts';

/** What the player works toward next, and how far along it is (0–1) */
export interface ResultsGoal {
  /** "Lithium Candle", "Depth 4", "the next chapter" */
  label: string;
  /** 0–1: drawn as a bar with a percentage (null or absent: the label alone) */
  progress?: number | null;
  /** A short line under it: "18 coins to go" */
  detail?: string;
}

export interface ResultsOptions {
  host: Pick<GameHost, 'adBreak' | 'minTouchPx' | 'screen' | 'paused' | 't'>;
  /** The headline: "New best!", "Level 3 cleared", "So close!" */
  title: string;
  /** The run's numbers, one line each (strings or your own elements) */
  lines?: (string | HTMLElement)[];
  /** What the big button does: 'again' (Play again: endless and score games) or 'next' (Next: levels, depths, waves) */
  primary: 'again' | 'next';
  /** The big button's words (default gp.playAgain / gp.next in the player's language) */
  primaryLabel?: string;
  /** Start the next run. mountResults has already awaited host.adBreak() (unless adBreak: false or it auto-continued) */
  onPrimary(): void;
  /** Back to the title (small, no ad: a navigational button) — omit to have no Menu */
  onMenu?(): void;
  menuLabel?: string;
  /** The next goal and its progress (the unfinished 60–80 % that brings a player back tomorrow) */
  goal?: ResultsGoal | null;
  /** More choices between the lines and the button: a rewarded ×2 (rewardedButton), a 1-of-3 pick */
  extra?: HTMLElement[];
  /** Level games: go on by themselves after this many seconds (3–5), unless the player taps or presses a key first */
  autoContinueSec?: number;
  /** Show a midgame ad on the big button (host.adBreak(), within the channel's limits). Default true */
  adBreak?: boolean;
}

export interface ResultsScreen {
  el: HTMLElement;
  /** Stop the auto-continue countdown (the player opened something else) */
  cancelAuto(): void;
  destroy(): void;
}

const CSS = `
:where(#gp-results) { --gp-results-bg: var(--gp-theme-bg, rgba(16, 26, 38, 0.92)); --gp-results-ink: var(--gp-theme-ink, #f2f7ff);
  --gp-results-muted: var(--gp-theme-muted, #a9b9cc); --gp-results-accent: var(--gp-theme-accent, #ffd166);
  --gp-results-accent-ink: var(--gp-theme-accent-ink, #18222e); --gp-results-bar: var(--gp-theme-track, rgba(255, 255, 255, 0.16));
  --gp-results-radius: var(--gp-theme-radius, 20px); --gp-results-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-results { position: absolute; inset: 0; margin: auto; height: fit-content;
  pointer-events: auto; box-sizing: border-box; width: min(92vw, 440px); max-height: 94vh; overflow: auto;
  display: flex; flex-direction: column; align-items: center; gap: 12px; padding: 22px 22px 16px; border-radius: var(--gp-results-radius);
  background: var(--gp-results-bg); color: var(--gp-results-ink); font: 600 17px var(--gp-results-font); text-align: center; }
#gp-results h2 { margin: 0; font-size: 32px; line-height: 1.1; font-family: var(--gp-theme-display, inherit); }
#gp-results .gp-lines { display: flex; flex-direction: column; gap: 4px; }
#gp-results .gp-goal { width: 100%; box-sizing: border-box; padding: 10px 12px; border-radius: 14px; background: var(--gp-theme-panel, rgba(255, 255, 255, 0.06)); text-align: left; }
#gp-results .gp-goal-k { font-size: 13px; color: var(--gp-results-muted); text-transform: uppercase; letter-spacing: 0.04em; }
#gp-results .gp-goal-row { display: flex; align-items: baseline; gap: 8px; margin-top: 2px; }
#gp-results .gp-goal-l { flex: 1; font-size: 18px; }
#gp-results .gp-goal-p { font-variant-numeric: tabular-nums; color: var(--gp-results-accent); }
#gp-results .gp-goal-d { font-size: 14px; color: var(--gp-results-muted); margin-top: 2px; }
#gp-results .gp-bar { height: 8px; border-radius: 4px; background: var(--gp-results-bar); overflow: hidden; margin-top: 6px; }
#gp-results .gp-bar i { display: block; height: 100%; background: var(--gp-results-accent); border-radius: 4px; }
#gp-results .gp-primary { position: relative; min-width: 0; margin: 0; text-transform: none; box-shadow: none; overflow: hidden; width: 100%; border: 0; border-radius: 999px; cursor: pointer;
  background: var(--gp-results-accent); color: var(--gp-results-accent-ink); font: 800 24px var(--gp-theme-display, var(--gp-results-font)); padding: 0 24px; }
#gp-results .gp-primary small { display: block; font-size: 13px; font-weight: 700; opacity: 0.75; }
#gp-results .gp-primary .gp-fill { position: absolute; inset: 0 auto 0 0; width: 0; background: rgba(255, 255, 255, 0.28); pointer-events: none; }
#gp-results .gp-primary span { position: relative; }
#gp-results .gp-menu { min-width: 0; width: auto; margin: 0; text-transform: none; box-shadow: none; border: 0; background: transparent; color: var(--gp-results-muted); font: 700 16px var(--gp-results-font);
  cursor: pointer; padding: 0 16px; text-decoration: underline; text-underline-offset: 3px; }
@media (max-height: 520px) { #gp-results { gap: 6px; padding: 12px 16px 10px; } #gp-results h2 { font-size: 24px; } }
`;

const el = <K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
};

/**
 * The goal from the balance model's walk (ModelSnapshot.goal: { id, kind, share }) or the same shape the game keeps
 * live: `name` turns the id into the player's words. null when nothing is left to reach
 */
export function goalFromSnapshot(s: { goal: { id: string; kind: string; share: number } | null } | null | undefined, name: (id: string, kind: string) => string): ResultsGoal | null {
  if (!s?.goal) return null;
  return { label: name(s.goal.id, s.goal.kind), progress: Math.max(0, Math.min(1, s.goal.share)) };
}

/** The results screen in `root` (its children are replaced, as a game's own screens do); host.screen('results') */
export function mountResults(root: HTMLElement, opts: ResultsOptions): ResultsScreen {
  const { host } = opts;
  if (!document.getElementById('gp-results-css')) {
    const style = el('style');
    style.id = 'gp-results-css';
    style.textContent = CSS;
    // First in <head>: the game's stylesheets come after it, so its rules of the same specificity win
    document.head.prepend(style);
  }
  const box = el('section');
  box.id = 'gp-results';
  box.dataset.gp = 'results';
  box.setAttribute('aria-label', opts.title);
  box.append(el('h2', undefined, opts.title));
  if (opts.lines?.length) {
    const lines = el('div', 'gp-lines');
    for (const l of opts.lines) lines.append(typeof l === 'string' ? el('div', undefined, l) : l);
    box.append(lines);
  }
  if (opts.goal) {
    const g = opts.goal;
    const goal = el('div', 'gp-goal');
    goal.dataset.gp = 'results-goal';
    goal.append(el('div', 'gp-goal-k', host.t('gp.results.goal')));
    const row = el('div', 'gp-goal-row');
    row.append(el('span', 'gp-goal-l', g.label));
    const p = typeof g.progress === 'number' && Number.isFinite(g.progress) ? Math.max(0, Math.min(1, g.progress)) : null;
    // Floor, never round up: "100 %" only when it is done
    if (p !== null) row.append(el('span', 'gp-goal-p', `${Math.floor(p * 100)}${' '}%`));
    goal.append(row);
    // gp qa's session section reads it: a goal that moved since the last results pulls the player on
    if (p !== null) goal.dataset.gpProgress = String(Math.round(p * 1000) / 1000);
    if (p !== null) {
      const bar = el('div', 'gp-bar');
      const fill = el('i');
      fill.style.width = `${p * 100}%`;
      bar.append(fill);
      goal.append(bar);
    }
    if (g.detail) goal.append(el('div', 'gp-goal-d', g.detail));
    box.append(goal);
  }
  for (const x of opts.extra ?? []) box.append(x);

  const primary = el('button', 'gp-primary');
  primary.type = 'button';
  primary.dataset.gp = opts.primary;
  const big = Math.max(64, Math.round(host.minTouchPx * 1.4));
  primary.style.minHeight = `${big}px`;
  const label = el('span', undefined, opts.primaryLabel ?? host.t(opts.primary === 'next' ? 'gp.next' : 'gp.playAgain'));
  const fill = el('i', 'gp-fill');
  primary.append(fill, label);
  box.append(primary);
  let menu: HTMLButtonElement | null = null;
  if (opts.onMenu) {
    menu = el('button', 'gp-menu', opts.menuLabel ?? host.t('gp.menu'));
    menu.type = 'button';
    menu.dataset.gp = 'menu';
    menu.style.minHeight = `${host.minTouchPx}px`;
    box.append(menu);
  }

  let gone = false;
  let busy = false;
  let timer: ReturnType<typeof setInterval> | null = null;
  const sub = el('small');
  const cancelAuto = () => {
    if (timer) clearInterval(timer);
    timer = null;
    sub.remove();
    fill.style.width = '0';
  };
  const go = async (auto: boolean) => {
    if (busy || gone) return;
    busy = true;
    cancelAuto();
    primary.disabled = true;
    if (menu) menu.disabled = true;
    // The player's choice is a natural break; a countdown is not (never an ad on a timer)
    if (!auto && opts.adBreak !== false) await host.adBreak();
    if (gone) return;
    opts.onPrimary();
  };
  primary.addEventListener('click', () => void go(false));
  menu?.addEventListener('click', () => {
    if (busy) return;
    cancelAuto();
    opts.onMenu!();
  });

  if (opts.autoContinueSec && opts.autoContinueSec > 0) {
    const total = opts.autoContinueSec * 1000;
    let left = total;
    let lastTs = performance.now();
    const tick = () => {
      // The game replaced the screen (a shop, the title): the countdown is over, nothing starts
      if (timer && !box.isConnected) return cancelAuto();
      const now = performance.now();
      // Stands still while the host is paused (a hidden tab, an ad) — no run starts behind the player's back
      if (!host.paused) left -= now - lastTs;
      lastTs = now;
      const s = Math.max(0, Math.ceil(left / 1000));
      sub.textContent = host.t('gp.results.auto', { s });
      fill.style.width = `${Math.min(100, ((total - left) / total) * 100)}%`;
      if (left <= 0) void go(true);
    };
    label.append(sub);
    // gp qa's session section reads it: the next run starts by itself
    primary.dataset.gpAuto = String(opts.autoContinueSec);
    tick();
    timer = setInterval(tick, 200);
    // Any tap or key on the screen other than the big button stops it: the player wants to look
    box.addEventListener('pointerdown', (e) => {
      if (!primary.contains(e.target as Node)) cancelAuto();
    });
    window.addEventListener('keydown', cancelAuto, { once: true });
  }

  root.replaceChildren(box);
  host.screen('results');
  return {
    el: box,
    cancelAuto,
    destroy() {
      gone = true;
      cancelAuto();
      window.removeEventListener('keydown', cancelAuto);
      box.remove();
    },
  };
}
