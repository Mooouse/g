// A daily reward week and a daily order: the two reasons to return that idle games (Idle Garage Evolution) kept writing
// by hand. Any genre may use them. Pure logic over a field of the game's own save, deterministic with an injected
// clock (`now`), never a DOM: Node tests and balance bots run them as they are. The claim card is mountStreakCard()
// (streak-ui.ts).
//
//   const streak = dailyStreak(save, { days: 7, reward: (day) => 50 * day, persist: () => host.save(save) });
//   // after the first run ends: streak.played();   — the card never shows before the player's first play
//   if (streak.state().show) mountStreakCard(ui, streak, { host, onClaim: (n) => (save.coins += n) });
//
//   const order = dailyOrder(save, { need: [{ id: 'sell', amount: 20 }, { id: 'paint', amount: 8 }], reward: 300,
//     from: 'secondVisit', seed: (key) => daySeed(key, 'idle-garage'), persist: () => host.save(save) });
//   order.add('sell');                                  // where the player sells a car: true when the order is just done
//   if (order.state().done) save.coins += order.claim() ?? 0;
//
// Loss framing (D56, game-design.md): a claimed reward is never taken back, and nothing the player sees says "you lost
// your streak". A missed day never costs anything: the week waits where it was (`miss: 'pause'`, the default, D56) —
// or, by a game's own choice, starts again at day 1 (`miss: 'restart'`). The card shows what is waiting today and tomorrow, never what
// was missed. Days are the player's local calendar days by default (a gift turns over at their midnight).

import { dayKey, daySeed } from './daily.ts';

const KEY = /^\d{4}-\d{2}-\d{2}$/;
const dayNumber = (key: string) => Math.round(Date.UTC(+key.slice(0, 4), +key.slice(5, 7) - 1, +key.slice(8, 10)) / 86400000);
const isKey = (v: unknown): v is string => typeof v === 'string' && KEY.test(v);
const int = (v: unknown, min: number, max: number, dflt: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.floor(n))) : dflt;
};
const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

/** Where a block keeps its field: the game's own save object (any object; the block writes `save[key]`) */
export type SaveHolder = object;

interface Clocked {
  /** The clock, in ms (default Date.now): inject one in tests and bots */
  now?: () => number;
  /** Days turn over at the player's own midnight (default true); false: at 00:00 UTC, the same day for everyone */
  local?: boolean;
  /** Called after every change of the block's field: `() => host.save(save)` */
  persist?: () => void;
}

const today = (o: Clocked) => dayKey(new Date((o.now ?? Date.now)()), { local: o.local ?? true });

// --- The daily streak: a week of rewards, one claim a day --------------------------------------------------------

/** What the streak keeps in the save (`save.streak` by default) */
export interface StreakLog {
  /** Rewards claimed in the current week (0 … days) */
  count: number;
  /** The day of the last claim (`YYYY-MM-DD`, '' none yet) */
  claimed: string;
  /** The last day the game was opened ('' none yet) */
  visit: string;
  /** The player has finished a first play (the card never shows before it) */
  played: boolean;
  /** Weeks completed */
  weeks: number;
  /** Rewards claimed in all */
  total: number;
}

export interface StreakOptions extends Clocked {
  /** Days in a week of rewards (default 7) */
  days?: number;
  /** The reward of a day of the week, 1 … days (a number of the game's currency): `(day) => 50 * day`, a big day 7 */
  reward: (day: number) => number;
  /** A missed day: the week waits where it was ('pause', the default: D56) or starts again at day 1 ('restart') */
  miss?: 'restart' | 'pause';
  /** The save field (default 'streak') */
  key?: string;
}

/** One dot of the week */
export interface StreakDot {
  /** 1 … days */
  day: number;
  reward: number;
  /** 'claimed' (this week), 'today' (claimable now) or 'later' */
  state: 'claimed' | 'today' | 'later';
  /** The dot of today (claimed or not) */
  current: boolean;
}

export interface StreakState {
  /** Today's day of the week, 1 … days (claimed or not) */
  day: number;
  days: number;
  /** Today's reward was claimed */
  claimedToday: boolean;
  /** Today's reward can be claimed */
  canClaim: boolean;
  /** Open the claim card now: the player has played once and today's reward is waiting */
  show: boolean;
  /** Today's reward */
  reward: number;
  /** The week's dots */
  dots: StreakDot[];
  /** Tomorrow's day of the week and its reward (if today's is claimed — or claimed by then) */
  tomorrow: { day: number; reward: number };
  /** Weeks completed */
  weeks: number;
}

export interface DailyStreak {
  readonly days: number;
  /** Where things stand today (it re-reads the clock: a session over midnight sees the new day) */
  state(): StreakState;
  /** Today's reward, once a day: the amount to pay, or null (claimed already) */
  claim(): number | null;
  /** The player finished a first play: from now on the card may show. Call it when a run ends (cheap: once) */
  played(): void;
  /** The saved field, cleaned */
  readonly log: StreakLog;
}

/** The saved streak made safe: wrong types, impossible counts and junk days go */
export function loadStreak(saved: unknown, days = 7): StreakLog {
  const s = record(saved);
  return {
    count: int(s.count, 0, days, 0),
    claimed: isKey(s.claimed) ? s.claimed : '',
    visit: isKey(s.visit) ? s.visit : '',
    played: s.played === true,
    weeks: int(s.weeks, 0, Number.MAX_SAFE_INTEGER, 0),
    total: int(s.total, 0, Number.MAX_SAFE_INTEGER, 0),
  };
}

/**
 * The daily streak over `save[key]`: today's visit is recorded at once (a new player's first day is day 1 of the week),
 * a day without a visit breaks the week (`miss`), `claim()` pays once a day, `state()` draws the card. Deterministic
 * with `now`. Show the card only when `state().show`: never before the player's first play (`played()`).
 */
export function dailyStreak(save: SaveHolder, opts: StreakOptions): DailyStreak {
  const days = int(opts.days ?? 7, 1, 31, 7);
  const key = opts.key ?? 'streak';
  const holder = save as Record<string, unknown>;
  const log = loadStreak(holder[key], days);
  holder[key] = log;
  const reward = (d: number) => {
    const r = Number(opts.reward(d));
    return Number.isFinite(r) && r > 0 ? r : 0;
  };
  const persist = () => opts.persist?.();

  /** Today's visit: a new day closes a full week, and a missed day breaks an unfinished one */
  const visit = (): string => {
    const t = today(opts);
    if (!log.visit) {
      log.visit = t;
      persist();
      return t;
    }
    if (t <= log.visit) return t; // the same day, or the clock was set back: nothing moves
    const gap = dayNumber(t) - dayNumber(log.visit);
    if (log.count >= days && log.claimed !== t) {
      log.count = 0; // the week is done: a new one starts
      log.weeks++;
    } else if (gap >= 2 && (opts.miss ?? 'pause') === 'restart') log.count = 0;
    log.visit = t;
    persist();
    return t;
  };
  // A claim dated after today (the clock set back): treat as claimed today, never twice
  const claimedOn = (t: string) => !!log.claimed && log.claimed >= t;

  visit();

  const state = (): StreakState => {
    const t = visit();
    const claimedToday = claimedOn(t);
    const day = claimedToday ? Math.max(1, log.count) : log.count + 1;
    const dots: StreakDot[] = [];
    for (let d = 1; d <= days; d++)
      dots.push({ day: d, reward: reward(d), state: d <= log.count ? 'claimed' : d === day ? 'today' : 'later', current: d === day });
    const next = (day % days) + 1;
    return {
      day,
      days,
      claimedToday,
      canClaim: !claimedToday,
      show: log.played && !claimedToday,
      reward: reward(day),
      dots,
      tomorrow: { day: next, reward: reward(next) },
      weeks: log.weeks,
    };
  };

  return {
    days,
    log,
    state,
    claim() {
      const t = visit();
      if (claimedOn(t)) return null;
      log.count = Math.min(days, log.count + 1);
      log.claimed = t;
      log.total++;
      persist();
      return reward(log.count);
    },
    played() {
      if (log.played) return;
      log.played = true;
      persist();
    },
  };
}

// --- The daily order: one goal a day, chosen by the day's seed ----------------------------------------------------

/** A goal an order can be: "sell 20 cars" is { id: 'sell', amount: 20 } */
export interface OrderGoal<Id extends string = string> {
  id: Id;
  amount: number;
}

/** What the order keeps in the save (`save.order` by default) */
export interface OrderLog {
  /** The day of the current order ('' none yet) */
  day: string;
  /** Its goal's id and amount */
  id: string;
  amount: number;
  progress: number;
  claimed: boolean;
  /** The first day the game was opened (for `from: 'secondVisit'`) */
  first: string;
  /** Orders claimed in all */
  total: number;
}

export interface OrderOptions<Id extends string> extends Clocked {
  /** The goals a day's order is chosen from (one a day, by `seed`) */
  need: readonly OrderGoal<Id>[];
  /** What a done order pays: a number, or by the goal */
  reward: number | ((goal: OrderGoal<Id>) => number);
  /**
   * From which day it is offered: 'secondVisit' (default: the first day belongs to the game itself, the order is a
   * reason to come back) or 'firstVisit'
   */
  from?: 'secondVisit' | 'firstVisit';
  /** The day's seed from its key: `(key) => daySeed(key, '<game id>')` (default daySeed(key)) */
  seed?: (key: string) => number;
  /** The save field (default 'order') */
  key?: string;
}

export interface OrderState<Id extends string> {
  /** Offered today (false on the first day with from: 'secondVisit') */
  available: boolean;
  goal: OrderGoal<Id>;
  progress: number;
  /** 0 … 1 */
  share: number;
  done: boolean;
  claimed: boolean;
  reward: number;
  /** The day it is for */
  day: string;
}

export interface DailyOrder<Id extends string> {
  state(): OrderState<Id>;
  /** Progress on goal `id` (n, default 1; fractions add up): true when this call completed today's order. Ignored when not offered */
  add(id: Id, n?: number): boolean;
  /** Pay a done order, once: the reward, or null */
  claim(): number | null;
  readonly log: OrderLog;
}

/** The saved order made safe */
export function loadOrder(saved: unknown): OrderLog {
  const s = record(saved);
  return {
    day: isKey(s.day) ? s.day : '',
    id: typeof s.id === 'string' ? s.id : '',
    amount: int(s.amount, 1, Number.MAX_SAFE_INTEGER, 1),
    progress: Number.isFinite(Number(s.progress)) ? Math.max(0, Number(s.progress)) : 0,
    claimed: s.claimed === true,
    first: isKey(s.first) ? s.first : '',
    total: int(s.total, 0, Number.MAX_SAFE_INTEGER, 0),
  };
}

/**
 * Today's order over `save[key]`: a goal from `need` picked by the day's seed (the same for every player on the same
 * day when `local: false`), its progress, done and claimed once a day. A new day brings a new order; an unclaimed done
 * order of yesterday is simply gone (nothing is taken: it was never paid).
 */
export function dailyOrder<Id extends string>(save: SaveHolder, opts: OrderOptions<Id>): DailyOrder<Id> {
  if (!opts.need.length) throw new Error('dailyOrder: `need` lists no goal');
  for (const g of opts.need) if (!(g.amount >= 1)) throw new Error(`dailyOrder: goal ${g.id} needs an amount of 1 or more`);
  const key = opts.key ?? 'order';
  const holder = save as Record<string, unknown>;
  const log = loadOrder(holder[key]);
  holder[key] = log;
  const seed = opts.seed ?? ((k: string) => daySeed(k));
  const persist = () => opts.persist?.();
  const goalOf = (): OrderGoal<Id> => opts.need.find((g) => g.id === log.id) ?? opts.need[0];
  const rewardOf = (g: OrderGoal<Id>) => {
    const r = Number(typeof opts.reward === 'function' ? opts.reward(g) : opts.reward);
    return Number.isFinite(r) && r > 0 ? r : 0;
  };

  const refresh = (): string => {
    const t = today(opts);
    let changed = false;
    if (!log.first || t < log.first) {
      log.first = t;
      changed = true;
    }
    // A new day (or an order of a goal the game no longer has): pick today's
    if (log.day !== t || !opts.need.some((g) => g.id === log.id)) {
      const g = opts.need[(seed(t) >>> 0) % opts.need.length];
      Object.assign(log, { day: t, id: g.id, amount: Math.floor(g.amount), progress: 0, claimed: false });
      changed = true;
    }
    if (changed) persist();
    return t;
  };
  const available = (t: string) => (opts.from ?? 'secondVisit') === 'firstVisit' || t > log.first;

  refresh();
  return {
    log,
    state() {
      const t = refresh();
      const goal = { id: log.id as Id, amount: log.amount };
      return {
        available: available(t),
        goal,
        progress: log.progress,
        share: Math.min(1, log.progress / log.amount),
        done: log.progress >= log.amount,
        claimed: log.claimed,
        reward: rewardOf(goalOf()),
        day: t,
      };
    },
    add(id, n = 1) {
      const t = refresh();
      if (!available(t) || id !== log.id || log.progress >= log.amount || !(n > 0)) return false;
      log.progress = Math.min(log.amount, log.progress + n);
      persist();
      return log.progress >= log.amount;
    },
    claim() {
      const t = refresh();
      if (!available(t) || log.claimed || log.progress < log.amount) return null;
      log.claimed = true;
      log.total++;
      persist();
      return rewardOf(goalOf());
    },
  };
}
