// Offline earnings: what an idle game earned while the player was away (CrazyGames calls "welcome back ×2" one of the
// highest-converting rewarded placements; Idle Garage Evolution, Brew & Banter and every idle game wrote it by hand).
// An idle / clicker / tycoon block (@genre idle). Pure: the time away from a stamp in the game's save, clamped to a cap,
// paid at a share of the income rate, once.
//
//   const away = offlineEarnings(save, { share: 0.6, maxHours: 8, minSec: 60, persist: () => host.save(save) }, () => income(save));
//   if (away) {                                          // null: away under a minute, or nothing to earn
//     const take = (mult: number) => { save.coins += away.collect(mult); host.save(save); };
//     const x2 = rewardedButton({ host, placement: 'offline-x2', label: host.t('gp.offline.double'),
//       onReward: () => { take(2); card.close(); play(); } });
//     const card = welcomeBack({ host, lines: [host.t('gp.offline.earned', { amount: formatAmount(away.amount) })],
//       extra: x2 ? [x2] : [], onContinue: () => { take(1); play(); }, onClose: () => take(1) });
//   }
//   // while playing, before every host.save(save) (and on pagehide): stampOffline(save) — the time away starts there.
//   // gp qa's reload check ignores the stamp (the `at` of the { at, pending } log): stamp on pagehide, save nothing else
//
// Paid exactly once, and never lost: offlineEarnings() moves the stamp to now and writes the pay-out into the save as
// pending in the same change (`persist` saves it before the card is shown). A reload before collect() shows the same
// pending pay-out again (plus any new time away); collect() clears it. A clock set back pays nothing and moves the stamp
// back with it; a clock set forward is capped at maxHours.

import type { SaveHolder } from './streak.ts';

/**
 * The genres this block is for (the platform's genre registry lists it). A game of another genre with an idle layer on
 * top (a den that earns while you raid, a rebirth in a speed runner) declares it — `money.hybrid: [idle]` in game.yaml —
 * and the block fits it too (W_GENRE_BLOCK stays quiet; docs/guides/live-world.md → Hybrids)
 */
export const OFFLINE_GENRES = ['idle'] as const;

/** What it keeps in the save (`save.offline` by default) */
export interface OfflineLog {
  /** The last moment the game was seen running (ms since 1970); 0: never */
  at: number;
  /** A pay-out computed but not collected yet (survives a reload) */
  pending: { amount: number; seconds: number } | null;
}

export interface OfflineOptions {
  /** The share of the running income paid for time away (default 0.6) */
  share?: number;
  /** At most this many hours count (default 8) */
  maxHours?: number;
  /** Under this many seconds away, nothing (default 60): a reload is not a return */
  minSec?: number;
  /** The save field (default 'offline') */
  key?: string;
  /** Called right after the stamp and the pending pay-out are written: `() => host.save(save)` */
  persist?: () => void;
  /** The clock in ms (default Date.now) — also the 4th argument */
  now?: () => number;
}

export interface OfflinePay {
  /** The amount at ×1 (floored), what the card says */
  amount: number;
  /** Seconds counted (clamped to maxHours) */
  seconds: number;
  /** The real time away was longer than maxHours */
  capped: boolean;
  /** The income per second it was computed from (× share) */
  rate: number;
  /** Pay it, once: the amount × mult (2 after a rewarded ad), floored. A second call returns 0 */
  collect(mult?: number): number;
}

const DEFAULTS = { share: 0.6, maxHours: 8, minSec: 60 };

let measuring = 0;
/**
 * Run `fn` as the measure of an offline rate: inside it a timedBoost (rewards.ts) answers ×1 — a boost bought for
 * play never multiplies the time away (Craft Pickaxe's code review: a ×2 boost doubled its offline earnings).
 * offlineEarnings() and Sites.offline() measure through it
 */
export function measuringOffline<T>(fn: () => T): T {
  measuring++;
  try {
    return fn();
  } finally {
    measuring--;
  }
}
/** An offline rate is being measured now (see measuringOffline) */
export const inOfflineMeasure = (): boolean => measuring > 0;

/** The saved log made safe */
export function loadOffline(saved: unknown): OfflineLog {
  const s = (saved && typeof saved === 'object' ? saved : {}) as { at?: unknown; pending?: unknown };
  const at = Number(s.at);
  const p = (s.pending && typeof s.pending === 'object' ? s.pending : null) as { amount?: unknown; seconds?: unknown } | null;
  const amount = Number(p?.amount);
  const seconds = Number(p?.seconds);
  return {
    at: Number.isFinite(at) && at > 0 ? at : 0,
    pending: p && Number.isFinite(amount) && amount > 0 ? { amount: Math.floor(amount), seconds: Number.isFinite(seconds) ? Math.max(0, seconds) : 0 } : null,
  };
}

/** Where the time away starts: call before every save while the game runs, and on pagehide (@genre idle) */
export function stampOffline(save: SaveHolder, opts: Pick<OfflineOptions, 'key' | 'now'> = {}): void {
  const holder = save as Record<string, unknown>;
  const key = opts.key ?? 'offline';
  const log = loadOffline(holder[key]);
  log.at = (opts.now ?? Date.now)();
  holder[key] = log;
}

/**
 * The earnings of the time away, from the stamp in `save[key]` (@genre idle): amount = share × rate() × seconds away
 * (clamped to maxHours), paid once through `collect()`. null under minSec (or when the rate earns nothing) — unless an
 * earlier pay-out is still pending. The first call on a fresh save only sets the stamp. Call it once at start, before
 * the game's own loop earns anything, then save (or pass `persist`).
 */
export function offlineEarnings(save: SaveHolder, opts: OfflineOptions, rate: () => number, now?: () => number): OfflinePay | null {
  const o = { ...DEFAULTS, ...opts };
  const clock = now ?? opts.now ?? Date.now;
  const holder = save as Record<string, unknown>;
  const key = opts.key ?? 'offline';
  const log = loadOffline(holder[key]);
  holder[key] = log;
  const t = clock();
  const share = Number.isFinite(o.share) ? Math.max(0, o.share) : DEFAULTS.share;
  const maxSec = Math.max(0, o.maxHours) * 3600;
  const awaySec = log.at ? Math.max(0, (t - log.at) / 1000) : 0;
  const seconds = Math.min(awaySec, maxSec);
  const perSec = Number(measuringOffline(rate));
  const r = Number.isFinite(perSec) && perSec > 0 ? perSec * share : 0;
  const earned = log.at && awaySec >= Math.max(0, o.minSec) ? Math.floor(r * seconds) : 0;
  // The stamp moves to now and the pay-out goes into the save in the same change: a reload can't pay it twice
  log.at = t;
  if (earned > 0) {
    const before = log.pending ?? { amount: 0, seconds: 0 };
    log.pending = { amount: before.amount + earned, seconds: Math.min(maxSec, before.seconds + seconds) };
  }
  opts.persist?.();
  if (!log.pending) return null;
  const pending = log.pending;
  let paid = false;
  return {
    amount: pending.amount,
    seconds: pending.seconds,
    capped: awaySec > maxSec,
    rate: r,
    collect(mult = 1) {
      if (paid) return 0;
      paid = true;
      // What is pending now: a later call may have added to it; already collected (another call's collect): nothing
      // In place, so a newer save object that took this field over (a prestige restart() keeps it) sees it too
      const field = holder[key];
      const cur = (field && typeof field === 'object' ? field : log) as OfflineLog;
      const amount = Number(cur.pending?.amount) || 0;
      if (!(amount > 0)) return 0;
      cur.pending = null;
      opts.persist?.();
      return Math.floor(amount * (Number.isFinite(mult) && mult > 0 ? mult : 1));
    },
  };
}
