// One card at a time: the welcome-back card, the daily reward week, the season, a story scene, the goals and the
// rewards hub all want the title of a returning player — Frankengun held the week's card back by hand until the
// welcome-back card was closed (holdStreak, main.ts:2483), and every game with two such cards had to. The queue opens
// them one after another, never two at once, and never while any other modal is up (the language sheet, a shop, a
// dialogue): the next one opens a beat after the last one closes.
//
//   import { cards } from '@gp/core';
//   showTitle();
//   if (visit.newDay) cards.offer('welcome', () => welcomeBack({ host, onContinue: play }), { priority: 2 });
//   cards.offer('streak', () => mountStreakCard(null, streak, { host, onClaim }));   // null: nothing to show, the next one
//   cards.offer('quests', () => (quests.state().claimable ? mountGoals(null, { host, quests, … }) : null));
//   // the player starts a run: nothing more opens over the play
//   cards.hold(true);   // … and hold(false) back on the title; cards.clear() forgets the waiting ones
//
// The platform's own cards (welcomeBack, mountStreakCard, mountSeasonTrack, mountGoals, mountAlbum, mountRewardsHub,
// the dialogue box) say when they open and close (cardOpened), so the queue moves on at once; a card of the game's own
// is followed by its element: closed when it leaves the page or is hidden.

/** A card on screen: its element (what the queue watches) and its close() */
export interface CardHandle {
  el: HTMLElement;
  close(): void;
}

export interface CardOfferOptions {
  /** Higher goes first (default 0; the same priority: in the order offered) */
  priority?: number;
}

export interface CardQueue {
  /**
   * A card that wants the screen: `open` is called when it is its turn (right after the code that offered it, when nothing
   * is up: the cards offered together go by priority) and returns the card,
   * or null (nothing to show any more: the next one). The same id while it waits is offered once (the newer `open` kept)
   */
  offer(id: string, open: () => CardHandle | { el: HTMLElement; close(): void } | null, opts?: CardOfferOptions): void;
  /** The card the queue opened that is on screen now, or null */
  readonly current: string | null;
  /** The ids waiting, in the order they will open */
  readonly waiting: string[];
  /** Hold the queue (true: a run is on — nothing opens over the play) or let it go on (false) */
  hold(on: boolean): void;
  /** Forget a waiting card */
  drop(id: string): void;
  /** Forget every waiting card (the open one stays) */
  clear(): void;
}

// --- Which cards are open: the platform's cards tell -------------------------------------------------------------

const openCards = new Map<HTMLElement, string>();
const listeners = new Set<() => void>();

/**
 * A platform card opened (its veil or box): the queue waits until the returned function is called (when it closes).
 * welcomeBack, mountStreakCard, mountSeasonTrack and the meta screens call it; a game's own card may too
 */
export function cardOpened(id: string, el: HTMLElement): () => void {
  openCards.set(el, id);
  let done = false;
  return () => {
    if (done) return;
    done = true;
    openCards.delete(el);
    for (const fn of [...listeners]) fn();
  };
}

const shown = (e: Element) => {
  if (!e.isConnected || (e as HTMLElement).hidden) return false;
  const r = e.getBoundingClientRect();
  return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden';
};

/** The id of a platform card on screen (registered and still on the page), or null */
export function cardOnScreen(): string | null {
  for (const [e, id] of openCards) {
    if (!e.isConnected) openCards.delete(e);
    else if (shown(e)) return id;
  }
  return null;
}

/** Any modal on screen: a platform card, the dialogue box, the language sheet, a shop, any [aria-modal=true] or <dialog open> */
export function anyModalOpen(): boolean {
  if (typeof document === 'undefined') return false;
  if (cardOnScreen()) return true;
  for (const e of document.querySelectorAll('[data-gp=dialog], [data-gp=lang-sheet], #gp-shop, [aria-modal=true], dialog[open]')) if (shown(e)) return true;
  return false;
}

/** The pause between two cards: the first one's veil is gone before the next comes (no flash of one into the other) */
const BEAT_MS = 280;

/** A queue of its own (the shared one is `cards`) */
export function cardQueue(opts: { isModal?: () => boolean; beatMs?: number } = {}): CardQueue {
  const isModal = opts.isModal ?? anyModalOpen;
  const beat = opts.beatMs ?? BEAT_MS;
  type Item = { id: string; open: () => CardHandle | null; priority: number; n: number };
  const queue: Item[] = [];
  let n = 0;
  let current: { id: string; el: HTMLElement } | null = null;
  let held = false;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let poll: ReturnType<typeof setInterval> | null = null;
  let lastClose = -Infinity;
  let scheduled = false;

  const sort = () => queue.sort((a, b) => b.priority - a.priority || a.n - b.n);
  const isUp = (e: HTMLElement) => e.isConnected && !e.hidden && e.getClientRects().length > 0;

  const watch = () => {
    const need = !!current || (queue.length > 0 && !held);
    if (need && !poll) poll = setInterval(pump, 250);
    if (!need && poll) {
      clearInterval(poll);
      poll = null;
    }
  };

  function pump(): void {
    if (current && !isUp(current.el)) {
      current = null;
      lastClose = performance.now();
    }
    if (!current && !held && queue.length) {
      const wait = beat - (performance.now() - lastClose);
      if (wait > 0) {
        if (!timer) timer = setTimeout(() => ((timer = null), pump()), wait + 1);
      } else if (!isModal()) {
        while (queue.length && !current) {
          const it = queue.shift()!;
          const h = it.open();
          if (h && h.el && isUp(h.el)) current = { id: it.id, el: h.el };
        }
      }
    }
    watch();
  }

  listeners.add(() => {
    // A platform card closed (one of the queue's or not): the next one a beat later
    lastClose = performance.now();
    queueMicrotask(pump);
  });

  return {
    offer(id, open, o = {}) {
      if (current?.id === id) return;
      const priority = o.priority ?? 0;
      const it = queue.find((q) => q.id === id);
      if (it) Object.assign(it, { open, priority });
      else queue.push({ id, open: open as () => CardHandle | null, priority, n: n++ });
      sort();
      // On the next microtask: the cards a title offers in one go are all in, and the highest priority opens first
      if (!scheduled) {
        scheduled = true;
        queueMicrotask(() => {
          scheduled = false;
          pump();
        });
      }
    },
    get current() {
      if (current && !isUp(current.el)) pump();
      return current?.id ?? null;
    },
    get waiting() {
      return queue.map((q) => q.id);
    },
    hold(on) {
      held = on;
      pump();
    },
    drop(id) {
      const i = queue.findIndex((q) => q.id === id);
      if (i >= 0) queue.splice(i, 1);
      watch();
    },
    clear() {
      queue.length = 0;
      if (timer) clearTimeout(timer);
      timer = null;
      watch();
    },
  };
}

/** The shared queue: the cards of the title (welcome back, the week, the season, story, goals, rewards) */
export const cards: CardQueue = cardQueue();
