// The platform's drawn icons: one set on a 24-unit grid, for DOM screens (an inline <svg>, its markup, a data URL for
// CSS or an <img>) and the canvas (Path2D) — never an emoji or a font's glyph (🔒 ✓ ◀ ▶ ★ ⚙ look different on every
// system and read as "a web app": Frankengun's reviewer, 2026-10-18). The platform's own screens use it; so can a game.
//
//   import { icon, iconSvg, iconUrl, drawIcon } from '@gp/core/icons';
//   button.prepend(icon('play'));                                    // 1.2em, currentColor: it takes the button's colour
//   price.prepend(icon('coin', { size: 20, color: '#ffd23f', style: 'solid' }));
//   tab.style.backgroundImage = `url(${iconUrl('gear', { size: 28, color: '#fff' })})`;
//   drawIcon(ctx, 'heart', x, y, 32, { color: '#ff4f6d', style: 'solid', glow: true });   // centred at (x, y)
//
// Three styles from one drawing: 'line' (strokes), 'duo' (strokes over a 30 % fill of the closed shapes) and 'solid'
// (the closed shapes filled, their inner details in `detail`, default a dark tint). `glow` adds a soft halo in the
// colour (or the colour given). A game's own picture (an icon drawn from its art) is an IconDef: the same parts.
// Generalised from Frankengun's icons.ts (QmaCyber/game22: ~95 icons on a 24 grid, neon strokes).

/**
 * One icon: SVG path data on a 24×24 box, one string per part. A part that starts with 'F' is a closed shape (filled in
 * the duo and solid styles; even-odd, so a circle inside it is a hole); 'D' is a detail drawn over a filled shape (in
 * `detail` in the solid style); anything else is a line, always in the icon's colour.
 */
export type IconDef = readonly string[];

const n = (v: number) => String(Math.round(v * 100) / 100);
/** A circle as path data (a closed subpath: a hole inside an 'F' part) */
const circle = (cx: number, cy: number, r: number) => `M${n(cx - r)} ${n(cy)}a${n(r)} ${n(r)} 0 1 0 ${n(2 * r)} 0a${n(r)} ${n(r)} 0 1 0 ${n(-2 * r)} 0z`;
/** A rectangle with round corners */
const rect = (x: number, y: number, w: number, h: number, r = 0) =>
  r
    ? `M${n(x + r)} ${n(y)}h${n(w - 2 * r)}a${n(r)} ${n(r)} 0 0 1 ${n(r)} ${n(r)}v${n(h - 2 * r)}a${n(r)} ${n(r)} 0 0 1 ${n(-r)} ${n(r)}h${n(2 * r - w)}a${n(r)} ${n(r)} 0 0 1 ${n(-r)} ${n(-r)}v${n(2 * r - h)}a${n(r)} ${n(r)} 0 0 1 ${n(r)} ${n(-r)}z`
    : `M${n(x)} ${n(y)}h${n(w)}v${n(h)}h${n(-w)}z`;
/** A star of `points` points */
const star = (cx: number, cy: number, outer: number, inner: number, points = 5, turn = -Math.PI / 2) => {
  let d = '';
  for (let i = 0; i < points * 2; i++) {
    const a = turn + (i * Math.PI) / points;
    const r = i % 2 ? inner : outer;
    d += `${i ? 'L' : 'M'}${n(cx + Math.cos(a) * r)} ${n(cy + Math.sin(a) * r)}`;
  }
  return `${d}z`;
};
/** A gear's outline: `teeth` flat teeth between two radii */
const gear = (cx: number, cy: number, outer: number, inner: number, teeth = 8) => {
  let d = '';
  const step = (Math.PI * 2) / teeth;
  for (let i = 0; i < teeth; i++) {
    const a = i * step - Math.PI / 2;
    const pts: [number, number][] = [
      [a - step * 0.5, inner],
      [a - step * 0.22, inner],
      [a - step * 0.15, outer],
      [a + step * 0.15, outer],
      [a + step * 0.22, inner],
    ];
    for (const [t, r] of pts) d += `${d ? 'L' : 'M'}${n(cx + Math.cos(t) * r)} ${n(cy + Math.sin(t) * r)}`;
  }
  return `${d}z`;
};
const F = (...d: string[]) => `F${d.join('')}`;
const D = (d: string) => `D${d}`;

/** The set. Keys are the names `icon()` takes */
export const ICONS = {
  // Controls
  close: ['M6 6l12 12M18 6L6 18'],
  check: ['M4.5 12.5l4.8 4.8L19.5 7'],
  plus: ['M12 5v14M5 12h14'],
  minus: ['M5 12h14'],
  chevronLeft: ['M15 5l-7 7 7 7'],
  chevronRight: ['M9 5l7 7-7 7'],
  chevronUp: ['M5 15l7-7 7 7'],
  chevronDown: ['M5 9l7 7 7-7'],
  chevronsUp: ['M6 12l6-6 6 6M6 18l6-6 6 6'],
  arrowLeft: ['M19 12H5M11 6l-6 6 6 6'],
  arrowRight: ['M5 12h14M13 6l6 6-6 6'],
  arrowUp: ['M12 19V5M6 11l6-6 6 6'],
  arrowDown: ['M12 5v14M6 13l6 6 6-6'],
  upgrade: [F('M12 3l8 8h-4.5v9h-7v-9H4z')],
  play: [F('M8 4.5v15l12-7.5z')],
  pause: [F(rect(6, 5, 4, 14, 1), rect(14, 5, 4, 14, 1))],
  stop: [F(rect(6, 6, 12, 12, 2))],
  refresh: ['M20 12a8 8 0 1 1-2.34-5.66', 'M20 4v5h-5'],
  undo: ['M9 14L4 9l5-5', 'M4 9h10.5a5.5 5.5 0 0 1 0 11H11'],
  home: [F('M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z')],
  menu: ['M4 7h16M4 12h16M4 17h16'],
  settings: [F(gear(12, 12, 10, 7.4, 8)), D(circle(12, 12, 3))],
  fullscreen: ['M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5'],
  exitFullscreen: ['M9 4v5H4M20 9h-5V4M15 20v-5h5M4 15h5v5'],
  search: [F(circle(10.5, 10.5, 6.5)), 'M15.5 15.5L21 21'],
  edit: [F('M4 20l1-5L15.5 4.5l4 4L9 19z'), 'M13.5 6.5l4 4'],
  trash: ['M4 7h16M10 3.5h4', F('M6 7l1 13h10l1-13z'), D('M10 11v5M14 11v5')],
  copy: [F(rect(8, 8, 12, 12, 2)), 'M4 16V6a2 2 0 0 1 2-2h10'],
  share: [F(circle(6, 12, 2.6)), F(circle(18, 5.5, 2.6)), F(circle(18, 18.5, 2.6)), 'M8.3 10.8l7.4-4M8.3 13.2l7.4 4'],
  link: ['M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1', 'M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1'],
  info: [F(circle(12, 12, 9.5)), D('M12 11v6M12 7.5v.2')],
  help: [F(circle(12, 12, 9.5)), D('M9.5 9.5a2.5 2.5 0 1 1 3.6 2.24c-.7.35-1.1 1-1.1 1.76v.5M12 17v.2')],
  warning: [F('M12 3.5l9.5 17h-19z'), D('M12 10v5M12 18v.2')],
  // Sound and the screen
  sound: [F('M4 9h4l5-4v14l-5-4H4z'), 'M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12'],
  soundOff: [F('M4 9h4l5-4v14l-5-4H4z'), 'M16.5 9.5l5 5M21.5 9.5l-5 5'],
  music: [F(circle(7, 18, 3)), F(circle(17, 16, 3)), 'M10 18V5l10-2v13', 'M10 9l10-2'],
  musicOff: [F(circle(7, 18, 3)), F(circle(17, 16, 3)), 'M10 18V5l10-2v13', 'M3 3l18 18'],
  video: [F(rect(2, 6, 14, 12, 2.5)), F('M16 10.5l6-3.5v10l-6-3.5z')],
  eye: [F('M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z'), D(circle(12, 12, 3))],
  globe: [F(circle(12, 12, 9.5)), D('M2.5 12h19M12 2.5c3.2 3 3.2 16 0 19M12 2.5c-3.2 3-3.2 16 0 19')],
  gamepad: [F('M7 7h10a5 5 0 0 1 4.9 6l-.6 3a3 3 0 0 1-5.1 1.5L14.5 16h-5l-1.7 1.5A3 3 0 0 1 2.7 16l-.6-3A5 5 0 0 1 7 7z'), D('M7 10v4M5 12h4M15.5 11v.2M17.5 13v.2')],
  // Rewards and currencies
  star: [F(star(12, 12.6, 10, 4.3))],
  sparkle: [F('M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z')],
  coin: [F(circle(12, 12, 9.5)), D(circle(12, 12, 5.8)), D('M12 9v6')],
  gem: [F('M7 4h10l4.5 5L12 20.5 2.5 9z'), D('M2.5 9h19M9.3 4L8 9l4 11.5L16 9l-1.3-5')],
  heart: [F('M12 20.5S3 15.2 3 9.2A4.7 4.7 0 0 1 12 6.8a4.7 4.7 0 0 1 9 2.4c0 6-9 11.3-9 11.3z')],
  shield: [F('M12 2.5l8.5 3.2v6.1c0 4.8-3.6 8.2-8.5 9.7-4.9-1.5-8.5-4.9-8.5-9.7V5.7z')],
  bolt: [F('M13.5 2L4 14h7l-1 8 9.5-12h-7z')],
  gift: [F(rect(4, 11, 16, 10, 1.5)), F(rect(2.5, 7, 19, 4, 1.5)), D('M12 7v14'), 'M12 7c-1.4-3.2-5.6-4.5-6.3-2.5C5 6.5 9 7 12 7zM12 7c1.4-3.2 5.6-4.5 6.3-2.5C19 6.5 15 7 12 7z'],
  chest: [F('M3 11.5h18V19a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 19z'), F('M3 11.5V9.5A5.5 5.5 0 0 1 8.5 4h7A5.5 5.5 0 0 1 21 9.5v2z'), D('M10 10h4v4.5h-4z')],
  trophy: [F('M7 3.5h10V9a5 5 0 0 1-10 0z'), 'M7 5.5H4.5A3 3 0 0 0 7.3 10M17 5.5h2.5a3 3 0 0 1-2.8 4.5', 'M12 14v3', F(rect(7.5, 17, 9, 3.5, 1))],
  crown: [F('M3 8l4.6 4.2L12 5l4.4 7.2L21 8l-2 11H5z')],
  medal: ['M8 2.5l3 7M16 2.5l-3 7', F(circle(12, 15.5, 6)), D(star(12, 15.8, 3.2, 1.4))],
  ticket: [F('M3 7.5A1.5 1.5 0 0 1 4.5 6h15A1.5 1.5 0 0 1 21 7.5V10a2 2 0 0 0 0 4v2.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 16.5V14a2 2 0 0 0 0-4z'), D('M14.5 7.5v1.5M14.5 11.25v1.5M14.5 15v1.5')],
  key: [F(circle(8, 12, 4.5)), D(circle(8, 12, 1.4)), 'M12.5 12H21M18 12v3.5M21 12v2.5'],
  lock: [F(rect(4.5, 10, 15, 11, 2.5)), 'M8 10V7a4 4 0 0 1 8 0v3', D('M12 14v3')],
  unlock: [F(rect(4.5, 10, 15, 11, 2.5)), 'M8 10V7a4 4 0 0 1 7.7-1.5', D('M12 14v3')],
  // Time and places
  clock: [F(circle(12, 12, 9.5)), D('M12 7v5l3.5 2.2')],
  hourglass: ['M5.5 3h13M5.5 21h13', F('M7 3c0 5 5 6 5 9s-5 4-5 9h10c0-5-5-6-5-9s5-4 5-9z')],
  calendar: [F(rect(3, 5, 18, 16, 2.5)), 'M8 3v4M16 3v4', D('M3 10h18')],
  mapPin: [F('M12 22s-7.5-6.8-7.5-12.5a7.5 7.5 0 0 1 15 0C19.5 15.2 12 22 12 22z'), D(circle(12, 9.5, 2.6))],
  map: [F('M3 6.5l6-2.5 6 2.5 6-2.5v13.5L15 20l-6-2.5L3 20z'), D('M9 4v13.5M15 6.5V20')],
  flag: ['M5 21.5V3.5', F('M5 4h13l-2.5 4.5L18 13H5z')],
  // Things in games
  cart: ['M2 3.5h3l2.4 11h11.2l2-8H6.2', F(circle(9, 19.5, 1.7)), F(circle(17, 19.5, 1.7))],
  bag: [F('M4.5 8h15l-1.2 12.5H5.7z'), 'M9 8V6.5a3 3 0 0 1 6 0V8'],
  fire: [F('M12 22c-4.1 0-7-2.9-7-6.8C5 11 9 9.5 9 3.5c3 2 4.2 5 4 7.5 1.2-.8 2.1-2.4 2.3-4C17.6 9 19 12 19 15.2 19 19.1 16.1 22 12 22z')],
  drop: [F('M12 2.5c3.3 4.8 6.5 8.2 6.5 12a6.5 6.5 0 0 1-13 0c0-3.8 3.2-7.2 6.5-12z')],
  snowflake: ['M12 2v20M3.3 7l17.4 10M20.7 7L3.3 17', 'M9 3.8l3 2 3-2M9 20.2l3-2 3 2'],
  leaf: [F('M4.5 19.5C4.5 9.5 10.5 4 20 4c0 9.5-5.5 15.5-15.5 15.5z'), D('M4.5 19.5l9.5-9.5')],
  skull: [F('M4.5 11a7.5 7.5 0 1 1 15 0v4l-2 1.2V19a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-2.8l-2-1.2z'), D(circle(9, 12, 1.6)), D(circle(15, 12, 1.6)), D('M10.5 20v-2.5M13.5 20v-2.5')],
  sword: [F('M20.5 3.5v3L10 17l-3-3L17.5 3.5z'), 'M5.5 12.5l6 6M7.8 16.2L3.5 20.5'],
  target: [F(circle(12, 12, 9.5)), D(circle(12, 12, 5.2)), D('M12 12v.2')],
  bomb: [F(circle(11, 14, 7.5)), 'M15.5 8.5l2.5-2.5', 'M19.5 2.5v1.2M22 5h-1.2M21.3 3.2l-.9.9'],
  potion: ['M9 3h6', F('M10 3h4v5.2l5 8.8a3 3 0 0 1-2.6 4.5H7.6A3 3 0 0 1 5 17l5-8.8z'), D('M7.5 15h9')],
  magnet: [F('M5 3h5v9a2 2 0 0 0 4 0V3h5v9A7 7 0 0 1 5 12z'), D('M5 7.5h5M14 7.5h5')],
  rocket: [F('M12 2c4 3 5.5 7.5 4.5 12.5h-9C6.5 9.5 8 5 12 2z'), D(circle(12, 9, 2)), 'M7.5 14.5L4.5 17.5v3l3.3-2M16.5 14.5l3 3v3l-3.3-2M10 18.5l2 3 2-3'],
  chart: ['M3.5 20.5h17', F(rect(5, 12, 3.5, 7, 0.8), rect(10.25, 8, 3.5, 11, 0.8), rect(15.5, 4, 3.5, 15, 0.8))],
  user: [F(circle(12, 8, 4.5)), F('M3.5 21a8.5 8.5 0 0 1 17 0z')],
  users: [F(circle(9, 8, 3.8)), F('M1.5 20.5a7.5 7.5 0 0 1 15 0z'), 'M15.5 4.4a3.8 3.8 0 0 1 0 7.2M18 13.4a7.5 7.5 0 0 1 4.5 7.1'],
  dice: [F(rect(3.5, 3.5, 17, 17, 3.5)), D('M8 8v.2M16 8v.2M12 12v.2M8 16v.2M16 16v.2')],
} as const satisfies Record<string, IconDef>;

export type IconName = keyof typeof ICONS;
/** Every icon's name, for a gallery or a check */
export const ICON_NAMES = Object.keys(ICONS) as IconName[];

export interface IconOptions {
  /** Width and height: px, or any CSS length (default '1.2em': the size of the text around it). iconUrl and drawIcon want px */
  size?: number | string;
  /** The colour of the lines and fills (default 'currentColor' in the DOM, white in a URL or on the canvas) */
  color?: string;
  /** 'line' (default), 'duo' (lines over a light fill) or 'solid' (filled shapes, details in `detail`) */
  style?: 'line' | 'duo' | 'solid';
  /** The details over a solid shape (default a dark tint of whatever is under it) */
  detail?: string;
  /** Line width on the 24 grid (default 2) */
  stroke?: number;
  /** A soft halo: true (6 px in the colour), a blur in px, or a colour */
  glow?: boolean | number | string;
  /** What it means, for a screen reader (default none: a decorative icon next to its words, aria-hidden) */
  title?: string;
  className?: string;
}

const DEFAULT_DETAIL = 'rgba(0, 0, 0, 0.42)';
const DUO_FILL = 0.3;

function defOf(name: IconName | IconDef): IconDef {
  if (typeof name !== 'string') return name;
  const d = (ICONS as Record<string, IconDef>)[name];
  if (d) return d;
  if (import.meta.env?.DEV) console.warn(`[icons] no icon "${name}": a circle instead`);
  return [F(circle(12, 12, 8))];
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function glowOf(o: IconOptions, color: string): { blur: number; color: string } | null {
  if (!o.glow) return null;
  const blur = typeof o.glow === 'number' ? o.glow : 6;
  const c = typeof o.glow === 'string' ? o.glow : color;
  return { blur, color: c };
}

/** The <path> elements of an icon as markup */
function parts(def: IconDef, o: IconOptions, color: string): string {
  const style = o.style ?? 'line';
  const detail = o.detail ?? DEFAULT_DETAIL;
  let out = '';
  for (const raw of def) {
    const kind = raw[0] === 'F' || raw[0] === 'D' ? raw[0] : '';
    const d = kind ? raw.slice(1) : raw;
    if (kind === 'F') {
      const fill = style === 'line' ? 'none' : color;
      const op = style === 'duo' ? ` fill-opacity="${DUO_FILL}"` : '';
      out += `<path d="${d}" fill="${fill}"${op} fill-rule="evenodd"/>`;
    } else if (kind === 'D' && style === 'solid') out += `<path d="${d}" stroke="${detail}"/>`;
    else out += `<path d="${d}"/>`;
  }
  return out;
}

const cssSize = (s: number | string) => (typeof s === 'number' ? `${s}px` : s);

/** The icon's SVG markup: for innerHTML, a template string, a file. `size` as for icon() */
export function iconSvg(name: IconName | IconDef, o: IconOptions = {}): string {
  const color = o.color ?? 'currentColor';
  const size = cssSize(o.size ?? '1.2em');
  const g = glowOf(o, color);
  const styles = [`width:${size}`, `height:${size}`, 'flex:none', 'vertical-align:-0.22em', 'overflow:visible'];
  if (g) styles.push(`filter:drop-shadow(0 0 ${g.blur / 2}px ${g.color})`);
  const label = o.title ? ` role="img" aria-label="${esc(o.title)}"` : ' aria-hidden="true"';
  const cls = o.className ? ` class="${esc(o.className)}"` : '';
  const nameAttr = typeof name === 'string' ? ` data-icon="${name}"` : '';
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"${nameAttr}${cls}${label} focusable="false" fill="none" stroke="${color}" ` +
    `stroke-width="${o.stroke ?? 2}" stroke-linecap="round" stroke-linejoin="round" style="${styles.join(';')}">${parts(defOf(name), o, color)}</svg>`
  );
}

/** The icon as an inline <svg> element (a new one each call: an element can be in one place only) */
export function icon(name: IconName | IconDef, o: IconOptions = {}): SVGSVGElement {
  const t = document.createElement('template');
  t.innerHTML = iconSvg(name, o);
  return t.content.firstChild as SVGSVGElement;
}

/** A data URL of the icon (SVG): for CSS backgrounds, an <img>, a favicon. Wants a concrete colour (default white) */
export function iconUrl(name: IconName | IconDef, o: IconOptions = {}): string {
  const size = typeof o.size === 'number' ? o.size : 24;
  const svg = iconSvg(name, { ...o, color: o.color && o.color !== 'currentColor' ? o.color : '#ffffff', size, title: undefined });
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

const pathCache = new Map<string, Path2D>();
const path2d = (d: string) => {
  let p = pathCache.get(d);
  if (!p) pathCache.set(d, (p = new Path2D(d)));
  return p;
};

/** Draw the icon on a canvas, centred at (x, y), `size` CSS px across (the context's transform applies) */
export function drawIcon(ctx: CanvasRenderingContext2D, name: IconName | IconDef, x: number, y: number, size: number, o: IconOptions = {}): void {
  const def = defOf(name);
  const color = o.color && o.color !== 'currentColor' ? o.color : '#ffffff';
  const style = o.style ?? 'line';
  const g = glowOf(o, color);
  const k = size / 24;
  // A shadow's blur is in device px, untouched by the transform: scale it by the context's own scale
  const m = ctx.getTransform();
  const dev = Math.hypot(m.a, m.b) || 1;
  ctx.save();
  ctx.translate(x - size / 2, y - size / 2);
  ctx.scale(k, k);
  ctx.lineWidth = o.stroke ?? 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (g) {
    ctx.shadowColor = g.color;
    ctx.shadowBlur = g.blur * dev;
  }
  for (const raw of def) {
    const kind = raw[0] === 'F' || raw[0] === 'D' ? raw[0] : '';
    const p = path2d(kind ? raw.slice(1) : raw);
    if (kind === 'F' && style !== 'line') {
      ctx.globalAlpha = style === 'duo' ? DUO_FILL : 1;
      ctx.fillStyle = color;
      ctx.fill(p, 'evenodd');
      ctx.globalAlpha = 1;
    }
    ctx.strokeStyle = kind === 'D' && style === 'solid' ? (o.detail ?? DEFAULT_DETAIL) : color;
    ctx.stroke(p);
  }
  ctx.restore();
}
