// A thin wrapper over the native Capacitor plugins, with safe fallbacks in the browser.
// Plugins are loaded dynamically so the web build stays lean.

import { Capacitor } from '@capacitor/core';

export const isNative = Capacitor.isNativePlatform();

/** System Back button (Android). In the browser, Escape does the same for testing. */
export function onBackButton(handler: () => void): void {
  if (isNative) {
    void import('@capacitor/app').then(({ App }) => App.addListener('backButton', handler));
  } else {
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') handler();
    });
  }
}

/** Minimize the app (Back on the home scene) */
export function minimizeApp(): void {
  if (isNative) void import('@capacitor/app').then(({ App }) => App.minimizeApp());
}

/** App went to background / came back */
export function onPauseResume(pause: () => void, resume: () => void): void {
  document.addEventListener('visibilitychange', () => (document.hidden ? pause() : resume()));
  if (isNative) {
    void import('@capacitor/app').then(({ App }) => {
      void App.addListener('pause', pause);
      void App.addListener('resume', resume);
    });
  }
}

/** Keep the screen on (during a round) */
export function keepAwake(on: boolean): void {
  if (!isNative) return;
  void import('@capacitor-community/keep-awake')
    .then(({ KeepAwake }) => (on ? KeepAwake.keepAwake() : KeepAwake.allowSleep()))
    .catch(() => {});
}

/** External link. In games for children only from behind the parent gate. */
export function openExternal(url: string): void {
  if (isNative) {
    void import('@capacitor/browser').then(({ Browser }) => Browser.open({ url })).catch(() => {});
  } else {
    window.open(url, '_blank', 'noopener');
  }
}
