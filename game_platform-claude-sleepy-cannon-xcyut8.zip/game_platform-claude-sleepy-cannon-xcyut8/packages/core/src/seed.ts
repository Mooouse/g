// Run seeds a player can see, copy, share and type back: the same seed gives the same run on every machine (Isaac,
// Spelunky, Slay the Spire). Жаслан, 2026-10-10: «Я хочу в Candle Crypt и в Swarm Smash системы сидов … Добавь модуль
// сидов в платформу».
//
//   const run = newRunSeed();                  // a fresh run: { code: 'K7M2-QX9P', seed: 1234…, custom: false }
//   const run = runSeedFrom('CANDLE');         // the player typed a seed (a code or any word): custom: true
//   const r = seededRng(run.seed);             // the run's own randomness — the map, the loot, the waves
//   host.saveRun({ ...state, seed: run.code }) // a resumed run keeps its seed
//
// A code is 8 characters of Crockford base32 (no I, L, O, U: nothing to misread), shown as two groups of four. Typing
// is forgiving: lower case, spaces, dashes, O for 0 and I/L for 1 are all read; text that is not a code (a word, a
// name) is hashed, so «CANDLE» is a seed too. A daily run's seed comes from the day (`dailyRunSeed`). Draw the seed on
// the run's screens (pause and results: `seedLabel`), offer «Copy» (`copySeed`) and a field to type one (`seedField`).
// A custom seed is the player's choice: a game decides whether such a run counts for the daily, a leaderboard or
// unlocks (the usual rule: unlocks yes, the daily and the leaderboard no — the seed could be chosen to be easy).

import { dayKey, daySeed } from './daily';

const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
/** 8 characters × 5 bits = 40 bits; the seed handed to `seededRng` is its low 32 bits mixed with the high 8 */
const LENGTH = 8;

export interface RunSeed {
  /** What the player sees and types: 'K7M2-QX9P' */
  code: string;
  /** For `seededRng(seed)` */
  seed: number;
  /** The player chose it (typed or pasted), not the game */
  custom: boolean;
}

/** A 32-bit seed from a 40-bit code value: both halves count, so codes that differ only in the top digits differ */
function mix(value: number): number {
  const lo = value % 2 ** 32;
  const hi = Math.floor(value / 2 ** 32);
  return (lo ^ Math.imul(hi + 1, 0x9e3779b1)) >>> 0;
}

function encode(value: number): string {
  let s = '';
  for (let i = 0; i < LENGTH; i++) {
    s = ALPHABET[value % 32] + s;
    value = Math.floor(value / 32);
  }
  return `${s.slice(0, 4)}-${s.slice(4)}`;
}

/** The code's characters as typed by a person: upper case, separators dropped, O→0, I and L→1 */
export function normalizeSeedText(text: string): string {
  return text
    .toUpperCase()
    .replace(/[\s\-_.]/g, '')
    .replace(/O/g, '0')
    .replace(/[IL]/g, '1');
}

/** The code's value when `text` is a code (8 characters of the alphabet), else null */
function decode(text: string): number | null {
  const s = normalizeSeedText(text);
  if (s.length !== LENGTH || [...s].some((c) => !ALPHABET.includes(c))) return null;
  let v = 0;
  for (const c of s) v = v * 32 + ALPHABET.indexOf(c);
  return v;
}

/** FNV-1a over the text, folded to 40 bits: any word or phrase becomes a seed */
function hashText(text: string): number {
  let h = 0x811c9dc5;
  for (const ch of text.trim().toUpperCase()) {
    h ^= ch.codePointAt(0)!;
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return (h >>> 0) + 2 ** 32 * (Math.imul(h, 0x9e3779b1) >>> 24);
}

/** A fresh run seed, from `random` (Math.random by default; never the run's own seeded rng) */
export function newRunSeed(random: () => number = Math.random): RunSeed {
  const value = Math.floor(random() * 2 ** 20) * 2 ** 20 + Math.floor(random() * 2 ** 20);
  return { code: encode(value), seed: mix(value), custom: false };
}

/** The player's seed: a code (forgiving: 'k7m2 qx9p', 'K7M2QX9P') or any text, which is hashed. Empty text: null */
export function runSeedFrom(text: string): RunSeed | null {
  if (!text.trim()) return null;
  const value = decode(text) ?? hashText(text);
  return { code: encode(value), seed: mix(value), custom: true };
}

/** A saved run's seed back from its code (what `host.saveRun` stored) */
export function runSeedOf(code: string, custom = false): RunSeed | null {
  const value = decode(code);
  return value === null ? null : { code: encode(value), seed: mix(value), custom };
}

/** Today's run seed, the same for every player (`salt`: the game's id, so two games don't share a day) */
export function dailyRunSeed(salt: string, key: string = dayKey()): RunSeed {
  const value = daySeed(key, salt);
  return { code: encode(value), seed: mix(value), custom: false };
}

/** The line for a run's pause and results screens: «Seed K7M2-QX9P» (custom: «Seed K7M2-QX9P · custom») */
export function seedLabel(run: RunSeed, t: (key: string) => string): string {
  return `${t('gp.seed')} ${run.code}${run.custom ? ` · ${t('gp.seed.custom')}` : ''}`;
}

/** Copies the code to the clipboard; false where the browser refuses (an iframe without permission) */
export async function copySeed(run: RunSeed): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(run.code);
    return true;
  } catch {
    return false;
  }
}

/**
 * A field to type a seed and a Play button: `onSeed` gets the run seed (or a fresh one when the field is empty).
 * Styled by the game's CSS through the classes `gp-seed`, `gp-seed-input`, `gp-seed-go`; the button carries
 * data-gp="seed-play", not "play": the title's own Play stays the one `gp qa` and the production check tap (Candle
 * Crypt 1.6.1 had two). Touch size from `minTouchPx` (48 by default). Keys and submit both start the run.
 */
export function seedField(opts: {
  t: (key: string) => string;
  onSeed: (run: RunSeed) => void;
  minTouchPx?: number;
  value?: string;
}): HTMLFormElement {
  const min = `${opts.minTouchPx ?? 48}px`;
  const form = document.createElement('form');
  form.className = 'gp-seed';
  const input = document.createElement('input');
  input.className = 'gp-seed-input';
  input.type = 'text';
  input.autocomplete = 'off';
  input.spellcheck = false;
  input.maxLength = 24;
  input.placeholder = opts.t('gp.seed.enter');
  input.setAttribute('aria-label', opts.t('gp.seed.enter'));
  input.style.minHeight = min;
  if (opts.value) input.value = opts.value;
  const go = document.createElement('button');
  go.className = 'gp-seed-go';
  go.type = 'submit';
  go.dataset.gp = 'seed-play';
  go.textContent = opts.t('gp.seed.play');
  go.style.minHeight = min;
  go.style.minWidth = min;
  form.append(input, go);
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    opts.onSeed(runSeedFrom(input.value) ?? newRunSeed());
  });
  return form;
}
