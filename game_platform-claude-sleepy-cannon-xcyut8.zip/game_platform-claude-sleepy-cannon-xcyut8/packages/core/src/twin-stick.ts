// Aim, look and fire for shooters, on top of MoveInput (which moves): one block for the two input bugs-in-waiting our
// shooters wrote by hand — Frankengun's first-person controls (game22 input.ts) and Candle Crypt's twin-stick (game9
// input.ts; its REPORT asked for this block after a review found three input bugs in its own version).
//
// TwinStick — top-down (mode 'aim'): WASD (or the left stick) moves; the mouse aims from the hero (left button fires,
// the right button and the wheel are buttons of yours, chorded through e.buttons); the arrow keys fire in their
// direction; on touch a floating move stick under the left thumb and an aim stick under the right (a drag aims and
// fires; no drag: `aim()` is null — auto-aim with aimAssist from @gp/core/aim).
//
// LookInput — first person (mode 'look'): the mouse looks under pointer lock. A click on the arena takes the lock (and
// fires); the "Click to aim" prompt is removed on pointerlockchange (not in its own click: once the lock is granted
// mouse events go to the locked canvas, and a prompt removed there stayed over the crosshair — Frankengun's review);
// losing the lock while playing pauses (Esc, alt-tab, the portal) — onPause(…, 'lock'); P pauses, never Esc (the
// browser's and CrazyGames'); a refused lock (an iframe without permission) falls back to drag-to-look. On touch a
// floating move stick and a look half: drag anywhere on the right to look (Fire is a look surface too, so one thumb aims
// while it fires).
//
// Both: the touch controls are drawn from the first frame of play (data-gp-touch on the stick and each button — gp qa's
// first-minute check), at least host.minTouchPx; nothing is read while the host is paused (a hidden tab, an ad, a lost
// context) and every held key, button, stick and drag is let go when it pauses; setActive(false) on every screen that
// isn't play does the same. Physical key codes (KeyW): ZQSD on AZERTY by itself.
//
//   const input = new LookInput({ host, canvas, parent: ui, buttons: [{ id: 'fire', label: t('fire'), aims: true }, { id: 'dash', label: t('dash'), keys: ['Space', 'ShiftLeft'] }] });
//   input.onPause(() => pauseGame());                    // P, or the lock lost in play
//   input.setActive(state === 'play');                   // on every screen change; Resume's own click: input.lock()
//   step: const m = input.move(); camera yaw = input.yaw, pitch = input.pitch; if (input.fire) shoot(); if (input.take('dash')) dash();

import { MoveInput } from './input';

export interface TwinStickHost {
  readonly paused: boolean;
  onPause(fn: () => void): void;
  onResume?(fn: () => void): void;
  /** The smallest touch target, CSS px (GameHost.minTouchPx) */
  readonly minTouchPx?: number;
  /** The platform's texts (GameHost.t): "Click to aim" in the player's language */
  t?(key: string): string;
}

export interface TwinStickButton {
  id: string;
  /** Its name for screen readers (aria-label) and its text when it has no icon */
  label: string;
  /** Inline SVG (or any HTML) drawn in it */
  icon?: string;
  /** Keys that press it on a keyboard (e.code: 'Space', 'ShiftLeft', 'KeyE') */
  keys?: readonly string[];
  /** Also a look / aim surface: a drag that starts on it looks (first person) or aims (top-down), as Fire */
  aims?: boolean;
}

export interface TwinStickOptions {
  host: TwinStickHost;
  /** The arena: mouse aim and look happen on it, a click on it takes the pointer lock */
  canvas: HTMLElement;
  /** Where the touch layer goes (default document.body): the game's ui element */
  parent?: HTMLElement;
  /** 'aim' (TwinStick's default): top-down; 'look': first person */
  mode?: 'aim' | 'look';
  /** Touch buttons in the right thumb's arc, and their keys. Default: one Fire button that also aims */
  buttons?: readonly TwinStickButton[];
  /** Mouse look, radians per px (default 0.0022) */
  sensitivity?: number;
  /** Touch look is this many times the mouse's (default 1.6) */
  touchLook?: number;
  /** The look's pitch stays within ±this (default 1.25 rad) */
  pitchLimit?: number;
  /** The move stick's full deflection, CSS px (default 52) */
  stickRadius?: number;
  /** The share of the screen's width that is the move half (default 0.5) */
  split?: number;
  /** Top-down: a drag on the aim half also fires (default true) */
  aimFires?: boolean;
  /** Buttons the mouse's right button and wheel press (top-down; ids of `buttons` or of your own: take(id)) */
  mouseRight?: string;
  wheel?: string;
  /** The pause key (default 'KeyP'; never Escape) */
  pauseKey?: string;
  /** The first-person prompt; false: none (draw your own and call lock() from its click) */
  clickToAim?: string | false;
}

type PauseWhy = 'key' | 'lock';
type FirstKind = 'move' | 'aim' | 'fire' | string;

let cssDone = false;
function css(): void {
  if (cssDone || typeof document === 'undefined') return;
  cssDone = true;
  const s = document.createElement('style');
  s.id = 'gp-twinstick-css';
  s.textContent = `
.gp-ts { position: fixed; inset: 0; pointer-events: none; z-index: 2; display: none; -webkit-user-select: none; user-select: none; }
.gp-ts.on { display: block; }
.gp-ts-pad { position: absolute; top: 0; bottom: 0; pointer-events: auto; touch-action: none; }
.gp-ts-base { position: absolute; border-radius: 50%; border: 2px solid rgba(255,255,255,0.42); background: rgba(10,14,28,0.28);
  box-shadow: inset 0 0 18px rgba(255,255,255,0.10); transform: translate(-50%, -50%); pointer-events: none; }
.gp-ts-knob { position: absolute; left: 50%; top: 50%; width: 46%; height: 46%; margin: -23% 0 0 -23%; border-radius: 50%;
  background: rgba(255,255,255,0.55); box-shadow: 0 2px 10px rgba(0,0,0,0.35); }
.gp-ts-base.live { border-color: rgba(255,255,255,0.7); }
.gp-ts-btns { position: absolute; right: calc(16px + env(safe-area-inset-right, 0px)); bottom: calc(18px + env(safe-area-inset-bottom, 0px));
  display: flex; flex-direction: column-reverse; align-items: flex-end; gap: 12px; pointer-events: none; }
.gp-ts-btn { pointer-events: auto; touch-action: none; border-radius: 50%; border: 2px solid rgba(255,255,255,0.5);
  background: rgba(10,14,28,0.42); color: #fff; font: 700 13px system-ui, sans-serif; display: flex; align-items: center;
  justify-content: center; padding: 0; -webkit-tap-highlight-color: transparent; }
.gp-ts-btn.down { background: rgba(255,255,255,0.3); }
.gp-ts-btn:first-child { transform: scale(1.18); transform-origin: 100% 100%; margin: 0 0 6px 0; }
.gp-ts-aim { position: fixed; left: 50%; top: 62%; transform: translate(-50%, -50%); padding: 8px 16px; border-radius: 999px;
  background: rgba(8,10,22,0.66); color: #fff; font: 700 15px system-ui, sans-serif; pointer-events: none; z-index: 3;
  display: none; white-space: nowrap; letter-spacing: 0.02em; }
.gp-ts-aim.on { display: block; }`;
  document.head.append(s);
}

/** Aim, look and fire for shooters (top-down by default; first person: LookInput or mode 'look') */
export class TwinStick {
  readonly mode: 'aim' | 'look';
  /** The movement: WASD (and the arrows in first person) and the left touch stick */
  readonly moveInput: MoveInput;
  /** The touch layer (in `parent`): the pads, the stick and the buttons */
  readonly el: HTMLElement;
  /** First person: where the view looks (radians). Set them to turn the view (aim assist, a respawn) */
  yaw = 0;
  pitch = 0;
  /** Mouse look sensitivity (rad/px): a settings slider */
  sensitivity: number;
  /** Auto-fire on touch (the game's switch: fire when aimAssist says onTarget) */
  autoFire = true;
  private readonly host: TwinStickHost;
  private readonly canvas: HTMLElement;
  private readonly o: TwinStickOptions;
  private active = false;
  private touchMode: boolean;
  private dxAcc = 0;
  private dyAcc = 0;
  private fireMouse = false;
  private dragLook = false;
  private lockRefused = false;
  private readonly held = new Set<string>();
  private readonly edges = new Set<string>();
  private readonly keysDown = new Set<string>();
  /** Touch look/aim drags by pointer id: their last point (look) or their press point (aim) */
  private readonly drags = new Map<number, { x: number; y: number; ox: number; oy: number; button: string | null }>();
  private mouse = { x: 0, y: 0, t: -1e9, right: false };
  private wheelT = -1e9;
  private readonly pauseFns: ((why: PauseWhy) => void)[] = [];
  private readonly lockFns: (() => void)[] = [];
  private readonly firstFns: ((kind: FirstKind) => void)[] = [];
  private firstSeen = false;
  private readonly prompt: HTMLElement | null;
  private readonly base: HTMLElement;
  private readonly knob: HTMLElement;
  private readonly buttons: readonly TwinStickButton[];
  private readonly btnEls = new Map<string, HTMLElement>();
  private readonly off: (() => void)[] = [];
  private readonly radius: number;

  constructor(o: TwinStickOptions) {
    css();
    this.o = o;
    this.mode = o.mode ?? 'aim';
    this.host = o.host;
    this.canvas = o.canvas;
    this.sensitivity = o.sensitivity ?? 0.0022;
    this.buttons = o.buttons ?? [{ id: 'fire', label: o.host.t?.('gp.fire') ?? 'Fire', aims: true, keys: ['KeyJ'] }];
    this.touchMode = typeof matchMedia === 'function' && (matchMedia('(pointer: coarse)').matches || (navigator.maxTouchPoints > 0 && !matchMedia('(pointer: fine)').matches));
    const minTouch = Math.max(48, o.host.minTouchPx ?? 48);
    this.radius = Math.max(o.stickRadius ?? 52, minTouch * 0.75);
    const split = Math.max(0.2, Math.min(0.8, o.split ?? 0.5));

    // --- The touch layer: a move pad (left), a look/aim pad (right), the buttons
    const el = (this.el = document.createElement('div'));
    el.className = 'gp-ts';
    el.dataset.gp = 'twin-stick';
    const padL = document.createElement('div');
    padL.className = 'gp-ts-pad gp-ts-move';
    padL.style.left = '0';
    padL.style.width = `${split * 100}%`;
    padL.dataset.gpTouch = 'move';
    const base = (this.base = document.createElement('div'));
    base.className = 'gp-ts-base';
    base.style.width = base.style.height = `${this.radius * 2}px`;
    const knob = (this.knob = document.createElement('div'));
    knob.className = 'gp-ts-knob';
    base.append(knob);
    padL.append(base);
    const padR = document.createElement('div');
    padR.className = 'gp-ts-pad gp-ts-look';
    padR.style.right = '0';
    padR.style.width = `${(1 - split) * 100}%`;
    padR.dataset.gpTouch = this.mode === 'look' ? 'look' : 'aim';
    const btns = document.createElement('div');
    btns.className = 'gp-ts-btns';
    this.buttons.forEach((b, i) => {
      const e = document.createElement('button');
      e.type = 'button';
      e.className = 'gp-ts-btn';
      e.dataset.gpTouch = b.id;
      e.setAttribute('aria-label', b.label);
      // The first (the main action) a little bigger; every one at least the channel's touch size
      const size = Math.round(Math.max(minTouch, i === 0 ? 72 : 60));
      e.style.width = e.style.height = `${size}px`;
      if (b.icon) e.innerHTML = b.icon;
      else e.textContent = b.label;
      btns.append(e);
      this.btnEls.set(b.id, e);
    });
    el.append(padL, padR, btns);
    (o.parent ?? document.body).append(el);
    this.homeStick();

    this.prompt = this.mode === 'look' && o.clickToAim !== false ? document.createElement('div') : null;
    if (this.prompt) {
      this.prompt.className = 'gp-ts-aim';
      this.prompt.dataset.gp = 'click-to-aim';
      this.prompt.textContent = o.clickToAim || (o.host.t?.('gp.look.click') ?? 'Click to aim');
      (o.parent ?? document.body).append(this.prompt);
    }

    // --- Movement: MoveInput on the left pad (the arrows stay the game's in top-down: they fire)
    this.moveInput = new MoveInput(padL, { maxRadius: this.radius, keys: this.mode === 'aim' ? 'wasd' : 'both', host: o.host });
    const placeKnob = () => {
      const s = this.moveInput.stick;
      if (!s) return this.homeStick();
      const r = padL.getBoundingClientRect();
      base.classList.add('live');
      base.style.left = `${s.ox - r.left}px`;
      base.style.top = `${s.oy - r.top}px`;
      let dx = s.x - s.ox;
      let dy = s.y - s.oy;
      const d = Math.hypot(dx, dy);
      if (d > this.radius) (dx *= this.radius / d), (dy *= this.radius / d);
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
      if (d > 8) this.first('move');
    };
    this.on(padL, 'pointerdown', (e) => {
      this.useTouch(true);
      e.preventDefault();
      placeKnob();
    });
    this.on(padL, 'pointermove', placeKnob);
    this.on(padL, 'pointerup', placeKnob);
    this.on(padL, 'pointercancel', placeKnob);

    // --- Touch look / aim: the right pad and the buttons that aim
    const dragDown = (button: string | null) => (e: PointerEvent) => {
      if (!this.live()) return;
      this.useTouch(true);
      e.preventDefault();
      try {
        (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
      } catch {
        /* a synthetic pointer */
      }
      this.drags.set(e.pointerId, { x: e.clientX, y: e.clientY, ox: e.clientX, oy: e.clientY, button });
    };
    const dragMove = (e: PointerEvent) => {
      const p = this.drags.get(e.pointerId);
      if (!p || !this.live()) return;
      const ddx = e.clientX - p.x;
      const ddy = e.clientY - p.y;
      p.x = e.clientX;
      p.y = e.clientY;
      if (this.mode === 'look') {
        this.turn(ddx * this.sensitivity * (o.touchLook ?? 1.6), ddy * this.sensitivity * (o.touchLook ?? 1.6), ddx, ddy);
        if (Math.abs(ddx) + Math.abs(ddy) > 2) this.first('aim');
      } else if (Math.hypot(p.x - p.ox, p.y - p.oy) > 8) this.first('aim');
    };
    const dragUp = (e: PointerEvent) => void this.drags.delete(e.pointerId);
    this.on(padR, 'pointerdown', dragDown(null));
    for (const [id, b] of this.btnEls) {
      const def = this.buttons.find((x) => x.id === id)!;
      this.on(b, 'pointerdown', (e) => {
        if (!this.live()) return;
        e.preventDefault();
        this.useTouch(true);
        this.press(id);
        b.classList.add('down');
        if (def.aims) dragDown(id)(e);
      });
      const up = (e: PointerEvent) => {
        this.release(id);
        b.classList.remove('down');
        dragUp(e);
      };
      this.on(b, 'pointerup', up);
      this.on(b, 'pointercancel', up);
      if (def.aims) this.on(b, 'pointermove', dragMove);
    }
    this.on(padR, 'pointermove', dragMove);
    this.on(padR, 'pointerup', dragUp);
    this.on(padR, 'pointercancel', dragUp);

    // --- Mouse
    this.on(o.canvas, 'contextmenu', (e) => e.preventDefault());
    // A touch on the arena of a touch laptop: the touch layer comes up (its pads take the next touches)
    this.on(o.canvas, 'pointerdown', (e) => {
      if (e.pointerType === 'touch' || e.pointerType === 'pen') this.useTouch(true);
    });
    this.on(o.canvas, 'mousedown', (e) => {
      if (!this.live() || this.isTouchEvent(e)) return;
      this.useTouch(false);
      this.mouseButtons(e.buttons || 1 << e.button);
      if (this.mode === 'look' && !this.locked) {
        this.lock();
        this.dragLook = true;
      }
    });
    this.on(window, 'mouseup', (e) => {
      this.mouseButtons(e.buttons);
      if (!e.buttons) this.dragLook = false;
    });
    this.on(window, 'mousemove', (e) => {
      if (this.isTouchEvent(e)) return;
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
      if (!this.live()) return;
      // A second button pressed while one is held arrives as a move (Pointer Events chording)
      if (e.buttons !== undefined) this.mouseButtons(e.buttons);
      if (this.mode === 'aim') {
        this.mouse.t = performance.now();
        this.useTouch(false);
        return;
      }
      const locked = this.locked;
      if (!locked && !(this.dragLook && e.buttons)) return;
      // Some browsers send one huge jump when the lock is taken
      const mx = Math.max(-200, Math.min(200, e.movementX || 0));
      const my = Math.max(-200, Math.min(200, e.movementY || 0));
      this.turn(mx * this.sensitivity, my * this.sensitivity, mx, my);
      if (Math.abs(mx) + Math.abs(my) > 1) {
        this.first('aim');
        if (!locked) this.showPrompt(false);
      }
    });
    this.on(o.canvas, 'wheel', (e) => {
      const now = performance.now();
      // One press per scroll gesture (trackpads send dozens of events)
      if (o.wheel && this.live() && Math.abs(e.deltaY) > 4 && now - this.wheelT > 300) this.edges.add(o.wheel);
      if (Math.abs(e.deltaY) > 4) this.wheelT = now;
    }, { passive: true });
    this.on(document, 'pointerlockchange', () => {
      if (this.locked) {
        this.lockRefused = false;
        this.showPrompt(false);
        for (const f of this.lockFns) f();
      } else if (this.active && !this.touchMode && this.mode === 'look') {
        this.release('*');
        this.sync();
        for (const f of this.pauseFns) f('lock');
      }
    });
    this.on(document, 'pointerlockerror', () => {
      // Refused (an iframe without the permission, too soon after an exit): drag to look instead
      this.lockRefused = true;
      if (this.prompt) this.prompt.textContent = this.o.host.t?.('gp.look.drag') ?? 'Drag to look';
    });

    // --- Keyboard
    this.on(window, 'keydown', (e) => {
      if (this.host.paused) return;
      if (e.code === (o.pauseKey ?? 'KeyP')) {
        if (this.active && !e.repeat) for (const f of this.pauseFns) f('key');
        return;
      }
      if (!this.active) return;
      if (e.code.startsWith('Arrow') || e.code === 'Space') e.preventDefault();
      this.keysDown.add(e.code);
      if (/^Key[WASD]$/.test(e.code) || (this.mode === 'look' && e.code.startsWith('Arrow'))) this.first('move');
      if (this.mode === 'aim' && e.code.startsWith('Arrow')) this.first('fire');
      for (const b of this.buttons)
        if (b.keys?.includes(e.code) && !e.repeat) {
          this.press(b.id);
          this.first(b.id);
        }
    });
    this.on(window, 'keyup', (e) => {
      this.keysDown.delete(e.code);
      for (const b of this.buttons) if (b.keys?.includes(e.code) && !b.keys.some((k) => this.keysDown.has(k))) this.release(b.id);
    });
    this.on(window, 'blur', () => this.clear());

    // --- The host's pause lets everything go; an ad needs the cursor: the lock is given back (the game pauses on it)
    o.host.onPause(() => {
      this.clear();
      if (this.locked) this.unlock();
      this.sync();
    });
    o.host.onResume?.(() => this.sync());
  }

  // --- State the game reads ---------------------------------------------------------------------------------------

  /** The movement, length ≤ 1 (screen axes: y < 0 is up / forward) */
  move(): { x: number; y: number } {
    return this.live() ? this.moveInput.direction() : { x: 0, y: 0 };
  }

  /** Fire is held: the left mouse button, the arrow keys (top-down), Fire (or its keys), a touch aim drag (top-down) */
  get fire(): boolean {
    if (!this.live()) return false;
    if (this.fireMouse || this.held.has('fire')) return true;
    if (this.mode === 'aim') {
      if (this.arrows()) return true;
      if ((this.o.aimFires ?? true) && [...this.drags.values()].some((d) => Math.hypot(d.x - d.ox, d.y - d.oy) > 8)) return true;
    }
    return false;
  }

  /**
   * Top-down: the aim as a unit vector from `from` (the hero on screen, CSS px) — the mouse while it moved in the last
   * 2.5 s or a button is held, the arrow keys, a touch aim drag; null when none: auto-aim then (aimAssist)
   */
  aim(from: { x: number; y: number }): { x: number; y: number } | null {
    if (!this.live()) return null;
    const a = this.arrows();
    if (a) return a;
    for (const d of this.drags.values()) {
      const dx = d.x - d.ox;
      const dy = d.y - d.oy;
      const l = Math.hypot(dx, dy);
      if (l > 8) return { x: dx / l, y: dy / l };
    }
    if (!this.touchMode && (this.fireMouse || performance.now() - this.mouse.t < 2500)) {
      const dx = this.mouse.x - from.x;
      const dy = this.mouse.y - from.y;
      const l = Math.hypot(dx, dy);
      if (l > 1) return { x: dx / l, y: dy / l };
    }
    return null;
  }

  /** The look's movement since the last call (px): the gun's sway */
  takeLook(): { dx: number; dy: number } {
    const r = { dx: this.dxAcc, dy: this.dyAcc };
    this.dxAcc = this.dyAcc = 0;
    return r;
  }

  /** A button (or a key mapped to it) is held */
  holding(id: string): boolean {
    return this.live() && this.held.has(id);
  }

  /** A button was pressed since the last take (once per press) */
  take(id: string): boolean {
    const v = this.edges.has(id);
    this.edges.delete(id);
    return v && this.live();
  }

  /** The last input came from a touch screen (the touch layer shows while active) */
  get touch(): boolean {
    return this.touchMode;
  }

  /** The pointer is locked to the arena (first person on a desktop) */
  get locked(): boolean {
    return typeof document !== 'undefined' && document.pointerLockElement === this.canvas;
  }

  /** The browser refused the lock: drag to look works instead */
  get refused(): boolean {
    return this.lockRefused;
  }

  // --- Control ------------------------------------------------------------------------------------------------------

  /** Play has the controls (true) or a screen does (false: everything let go, the touch layer and the prompt hidden) */
  setActive(on: boolean): void {
    if (on && !this.active) this.firstSeen = false;
    this.active = on;
    if (!on) this.clear();
    this.moveInput.setEnabled(on);
    this.sync();
  }

  /** Take the pointer (first person, a desktop). Call it inside a click: Resume's and Next's own handlers, before play() */
  lock(): void {
    if (this.mode !== 'look' || this.touchMode || this.locked) return;
    const c = this.canvas as HTMLElement & { requestPointerLock?: () => unknown };
    try {
      const p = c.requestPointerLock?.() as Promise<void> | undefined;
      p?.catch?.(() => {
        this.lockRefused = true;
      });
    } catch {
      // Refused (an iframe without the permission): drag to look still works
      this.lockRefused = true;
    }
  }

  unlock(): void {
    if (this.locked) document.exitPointerLock();
  }

  /** P in play, or the lock lost in play (first person): show the pause screen. `why` says which */
  onPause(fn: (why: PauseWhy) => void): void {
    this.pauseFns.push(fn);
  }

  /** The pointer lock was granted */
  onLock(fn: () => void): void {
    this.lockFns.push(fn);
  }

  /** The first move, aim, fire or button of a setActive(true) stretch (hold the clock until it: a desktop first run) */
  onFirstInput(fn: (kind: FirstKind) => void): void {
    this.firstFns.push(fn);
  }

  /** Everything let go: keys, buttons, the stick, the drags, the mouse buttons */
  clear(): void {
    this.keysDown.clear();
    this.held.clear();
    this.edges.clear();
    this.drags.clear();
    this.fireMouse = false;
    this.dragLook = false;
    this.mouse.right = false;
    this.moveInput.clear();
    for (const b of this.btnEls.values()) b.classList.remove('down');
    this.homeStick();
  }

  /** Remove the layer and every listener (the game is torn down) */
  destroy(): void {
    this.setActive(false);
    for (const f of this.off) f();
    this.el.remove();
    this.prompt?.remove();
  }

  // --- Inside ---------------------------------------------------------------------------------------------------------

  private live(): boolean {
    return this.active && !this.host.paused;
  }

  private sync(): void {
    const show = this.active && !this.host.paused;
    this.el.classList.toggle('on', show && this.touchMode);
    this.showPrompt(show && !this.touchMode && !this.locked);
  }

  /** The device in use changed (a touch on a laptop, the mouse again): the layer and the prompt follow */
  private useTouch(on: boolean): void {
    if (this.touchMode === on) return;
    this.touchMode = on;
    this.sync();
  }

  private showPrompt(on: boolean): void {
    this.prompt?.classList.toggle('on', on && this.mode === 'look');
  }

  private turn(yaw: number, pitch: number, dx: number, dy: number): void {
    const lim = this.o.pitchLimit ?? 1.25;
    this.yaw += yaw;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch - pitch));
    this.dxAcc += dx;
    this.dyAcc += dy;
  }

  private arrows(): { x: number; y: number } | null {
    const k = this.keysDown;
    const x = (k.has('ArrowRight') ? 1 : 0) - (k.has('ArrowLeft') ? 1 : 0);
    const y = (k.has('ArrowDown') ? 1 : 0) - (k.has('ArrowUp') ? 1 : 0);
    if (!x && !y) return null;
    const l = Math.hypot(x, y);
    return { x: x / l, y: y / l };
  }

  /** Left held → fire; a new right press → the mouseRight button */
  private mouseButtons(buttons: number): void {
    const left = this.live() && (buttons & 1) !== 0;
    if (left && !this.fireMouse) this.first('fire');
    this.fireMouse = left;
    const right = (buttons & 2) !== 0;
    if (right && !this.mouse.right && this.live() && this.o.mouseRight) {
      this.edges.add(this.o.mouseRight);
      this.first(this.o.mouseRight);
    }
    this.mouse.right = right;
  }

  private press(id: string): void {
    if (!this.live()) return;
    if (!this.held.has(id)) this.edges.add(id);
    this.held.add(id);
    if (id === 'fire') this.first('fire');
  }

  private release(id: string): void {
    if (id === '*') {
      this.held.clear();
      this.fireMouse = false;
      return;
    }
    this.held.delete(id);
  }

  private first(kind: FirstKind): void {
    if (this.firstSeen || !this.active) return;
    this.firstSeen = true;
    for (const f of this.firstFns) f(kind);
  }

  private homeStick(): void {
    // The stick's home under the left thumb, visible from the first frame of play
    this.base.classList.remove('live');
    this.base.style.left = `max(${this.radius + 20}px, 22%)`;
    this.base.style.top = `calc(100% - ${this.radius + 36}px - env(safe-area-inset-bottom, 0px))`;
    this.knob.style.transform = '';
  }

  private isTouchEvent(e: MouseEvent): boolean {
    // Compatibility mouse events after a touch carry sourceCapabilities.firesTouchEvents (Chromium)
    return !!(e as MouseEvent & { sourceCapabilities?: { firesTouchEvents?: boolean } }).sourceCapabilities?.firesTouchEvents;
  }

  private on(t: EventTarget, type: string, fn: (e: PointerEvent & KeyboardEvent & WheelEvent) => void, opts?: AddEventListenerOptions): void {
    const h = fn as EventListener;
    t.addEventListener(type, h, opts);
    this.off.push(() => t.removeEventListener(type, h, opts));
  }
}

/** First person: TwinStick in mode 'look' (pointer lock with "Click to aim", drag to look; touch: a look half) */
export class LookInput extends TwinStick {
  constructor(o: Omit<TwinStickOptions, 'mode'>) {
    super({ ...o, mode: 'look' });
  }
}
