// A loot table: weighted outcomes in rarity tiers with odds the player SEES before every roll, a pity that guarantees
// a tier within N rolls, and luck that only ever raises the floor or the better tiers' weights (eggs, chests, drops:
// docs/research/roblox-2026-10.md P2). The block is where the rules live, so a game can't get them wrong:
//
//   const EGGS = new LootTable(save, 'eggs', {
//     tiers: [{ id: 'common', weight: 60 }, { id: 'rare', weight: 30 }, { id: 'epic', weight: 9 }, { id: 'mythic', weight: 1 }],
//     items: [{ id: 'moss-fox', tier: 'common' }, { id: 'glow-owl', tier: 'epic' }, …],
//     sources: { 'storm-egg': { weights: { common: 40, rare: 40, epic: 17, mythic: 3 } } },   // per-source tables
//     pity: { tier: 'epic', within: 40 },          // the 40th roll without an epic or better is one
//     rng: host.rng, persist: () => host.save(save),
//   });
//   EGGS.odds('meadow-egg');                       // the odds panel, ALWAYS on screen before the roll: [{ tier, chance, oneIn }]
//   const r = EGGS.roll('meadow-egg');             // { id, tier, chance, pity, pityLeft, first }
//   EGGS.roll('meadow-egg', { floor: 'rare' });    // a rewarded "lucky incubator": a guaranteed floor on a roll the player makes anyway
//
// The rules (PEGI from June 2026; docs/guides/live-world.md → Fair randomness):
// - the odds are shown before every roll (`odds()` returns the very numbers `roll()` uses; gp validate: W_LOOT_ODDS);
// - a roll is never sold for real money or for a currency sold for real money (PEGI 16; gp validate: E_PAID_RANDOM);
// - a rewarded ad gives a guaranteed thing — a floor, a second item, a reroll of run choices — never a spin;
// - no casino look: no slot reels, no roulette wheel of prizes (simulated gambling is PEGI 18).
// Seeded through the `rng` it is given (host.rng: `?seed=` repeats a run; seededRng(n) for a bot). The save field keeps
// the pity counters, the rolls per source and the items seen (`first`): small, plain JSON.

import type { SaveHolder } from './streak.ts';

export interface LootTier<T extends string = string> {
  id: T;
  /** Its weight in the default table (any positive numbers: shares are weight / Σ) */
  weight: number;
}

export interface LootItem<T extends string = string> {
  id: string;
  tier: T;
  /** Its weight among the items of its tier (default 1) */
  weight?: number;
}

export interface LootSource<T extends string = string> {
  /** This source's tier weights (a tier left out has weight 0 here) */
  weights?: Partial<Record<T, number>>;
  /** This source's items (default: the table's) */
  items?: readonly LootItem<T>[];
}

export interface LootOptions<T extends string = string> {
  /** The tiers, from the most common to the rarest: the order is what "floor" and "better" mean */
  tiers: readonly LootTier<T>[];
  /** What a roll gives inside its tier (none: a roll gives a tier, the game picks the thing) */
  items?: readonly LootItem<T>[];
  /** Per-source tables (an egg, a chest): any other source id rolls the default table */
  sources?: Record<string, LootSource<T>>;
  /** A guarantee: the `within`-th roll of a source without `tier` or better gives one (default none) */
  pity?: { tier: T; within: number };
  /** The random source: host.rng, or seededRng(n) for a bot or a test */
  rng: (() => number) | { random(): number };
  /** Called after every roll: `() => host.save(save)` */
  persist?: () => void;
}

/** A roll's options: a floor (nothing below this tier: a rewarded "lucky" roll), luck (× the weights of every tier above the lowest, ≥ 1) */
export interface RollOptions<T extends string = string> {
  floor?: T;
  luck?: number;
}

export interface LootOdds<T extends string = string> {
  tier: T;
  /** 0 … 1 */
  chance: number;
  /** 1 in N, rounded (Infinity for 0) */
  oneIn: number;
}

export interface LootRoll<T extends string = string> {
  /** The item (the tier's id when the table has no items) */
  id: string;
  tier: T;
  /** The tier's chance at this roll, as the odds panel showed it */
  chance: number;
  /** The pity gave this tier (the roll was guaranteed) */
  pity: boolean;
  /** Rolls left until the pity guarantees (null: no pity) */
  pityLeft: number | null;
  /** The first time the player gets this item */
  first: boolean;
}

/** What the table keeps in the save */
export interface LootLog {
  /** Rolls since the last pity tier or better, by source */
  dry: Record<string, number>;
  /** Rolls in all, by source */
  rolls: Record<string, number>;
  /** Items seen at least once */
  seen: string[];
}

const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});
const counts = (v: unknown): Record<string, number> =>
  Object.fromEntries(Object.entries(record(v)).flatMap(([k, n]) => (typeof n === 'number' && Number.isFinite(n) && n >= 0 ? [[k, Math.floor(n)]] : [])));

/** The saved log made safe */
export function loadLoot(saved: unknown): LootLog {
  const s = record(saved);
  return { dry: counts(s.dry), rolls: counts(s.rolls), seen: Array.isArray(s.seen) ? [...new Set(s.seen.filter((x): x is string => typeof x === 'string'))] : [] };
}

/** A chance as people read it: '30%', '2.5%', '1 in 100', '1 in 3.2M' (from about 1 % down it says 1 in N) */
export function formatOdds(chance: number): string {
  if (!(chance > 0)) return '0%';
  if (chance >= 1) return '100%';
  if (chance >= 0.015) {
    const p = chance * 100;
    return `${p >= 10 ? Math.round(p) : Math.round(p * 10) / 10}%`;
  }
  const n = 1 / chance;
  const short = n >= 1e9 ? `${Math.round(n / 1e8) / 10}B` : n >= 1e6 ? `${Math.round(n / 1e5) / 10}M` : n >= 1e4 ? `${Math.round(n / 100) / 10}K` : String(Math.round(n));
  return `1 in ${short}`;
}

/** A loot table with visible odds, a pity and luck: see the module's comment */
export class LootTable<T extends string = string> {
  readonly tiers: readonly T[];
  readonly log: LootLog;
  private readonly opts: LootOptions<T>;
  private readonly next: () => number;

  constructor(save: SaveHolder, key: string, opts: LootOptions<T>) {
    if (!opts.tiers.length) throw new Error('LootTable: no tiers');
    const ids = opts.tiers.map((t) => t.id);
    if (new Set(ids).size !== ids.length) throw new Error('LootTable: a tier id twice');
    for (const t of opts.tiers) if (!(t.weight >= 0) || !Number.isFinite(t.weight)) throw new Error(`LootTable: tier ${t.id} needs a weight ≥ 0`);
    const check = (items: readonly LootItem<T>[] | undefined, where: string) => {
      for (const it of items ?? []) if (!ids.includes(it.tier)) throw new Error(`LootTable: ${where} item ${it.id} is in the unknown tier '${it.tier}'`);
    };
    check(opts.items, 'the');
    for (const [s, src] of Object.entries(opts.sources ?? {})) {
      check(src.items, `source ${s}:`);
      for (const k of Object.keys(src.weights ?? {})) if (!ids.includes(k as T)) throw new Error(`LootTable: source ${s} weighs the unknown tier '${k}'`);
    }
    if (opts.pity) {
      if (!ids.includes(opts.pity.tier)) throw new Error(`LootTable: the pity tier '${opts.pity.tier}' is not a tier`);
      if (!(Number.isInteger(opts.pity.within) && opts.pity.within >= 1)) throw new Error('LootTable: pity.within is a whole number ≥ 1');
    }
    this.opts = opts;
    this.tiers = ids;
    const r = opts.rng;
    this.next = typeof r === 'function' ? r : () => r.random();
    const holder = save as Record<string, unknown>;
    this.log = loadLoot(holder[key]);
    holder[key] = this.log;
  }

  private rank(t: T): number {
    return this.tiers.indexOf(t);
  }

  private weightsOf(source: string): number[] {
    const src = this.opts.sources?.[source];
    return this.opts.tiers.map((t) => {
      const w = src?.weights ? (src.weights[t.id] ?? 0) : t.weight;
      return Number.isFinite(w) && w > 0 ? w : 0;
    });
  }

  private itemsOf(source: string): readonly LootItem<T>[] {
    return this.opts.sources?.[source]?.items ?? this.opts.items ?? [];
  }

  /** Rolls left before the pity guarantees on this source (1: the next roll is guaranteed); null without a pity */
  pityLeft(source: string): number | null {
    const p = this.opts.pity;
    return p ? Math.max(1, p.within - (this.log.dry[source] ?? 0)) : null;
  }

  /** The floor a roll has: the one asked, raised to the pity tier when the pity is due */
  private floorOf(source: string, o: RollOptions<T>): { floor: number; pity: boolean } {
    const asked = o.floor !== undefined ? this.rank(o.floor) : 0;
    if (o.floor !== undefined && asked < 0) throw new Error(`LootTable: the floor '${o.floor}' is not a tier`);
    const p = this.opts.pity;
    const due = !!p && (this.log.dry[source] ?? 0) + 1 >= p.within;
    const pityRank = p ? this.rank(p.tier) : 0;
    return due && pityRank > asked ? { floor: pityRank, pity: true } : { floor: asked, pity: false };
  }

  /**
   * The odds of the next roll of `source` with these options (the pity included when it is due): each tier's chance,
   * in the tiers' order. Show them before every roll — they are the numbers roll() uses.
   */
  odds(source: string, o: RollOptions<T> = {}): LootOdds<T>[] {
    const luck = Number.isFinite(o.luck) && (o.luck as number) > 1 ? (o.luck as number) : 1;
    const { floor } = this.floorOf(source, o);
    const w = this.weightsOf(source).map((x, i) => (i < floor ? 0 : i > 0 ? x * luck : x));
    let sum = w.reduce((a, b) => a + b, 0);
    if (!(sum > 0)) {
      // A floor above every weighted tier: the floor tier itself (a guarantee always gives something)
      w[floor] = 1;
      sum = 1;
    }
    return this.opts.tiers.map((t, i) => {
      const chance = w[i] / sum;
      return { tier: t.id, chance, oneIn: chance > 0 ? Math.round(1 / chance) : Infinity };
    });
  }

  /** The odds as one line for a panel: 'Common 60% · Rare 30% · Epic 9% · Mythic 1 in 100' (names: the tiers' ids, or yours) */
  oddsText(source: string, o: RollOptions<T> & { name?: (tier: T) => string } = {}): string {
    const name = o.name ?? ((t: T) => t.charAt(0).toUpperCase() + t.slice(1));
    return this.odds(source, o)
      .filter((x) => x.chance > 0)
      .map((x) => `${name(x.tier)} ${formatOdds(x.chance)}`)
      .join(' · ');
  }

  /** Roll `source` once: the tier by the odds shown, then an item of that tier; the pity and the counters move, then persist */
  roll(source: string, o: RollOptions<T> = {}): LootRoll<T> {
    const odds = this.odds(source, o);
    const { pity: byPity } = this.floorOf(source, o);
    let x = this.next();
    let i = odds.length - 1;
    for (let k = 0; k < odds.length; k++) if (odds[k].chance > 0 && (x -= odds[k].chance) < 0) {
      i = k;
      break;
    }
    while (odds[i].chance <= 0 && i > 0) i--;
    const tier = odds[i].tier;
    const pool = this.itemsOf(source).filter((it) => it.tier === tier && (it.weight ?? 1) > 0);
    let id: string = tier;
    if (pool.length) {
      const sum = pool.reduce((a, it) => a + (it.weight ?? 1), 0);
      let y = this.next() * sum;
      id = pool[pool.length - 1].id;
      for (const it of pool) if ((y -= it.weight ?? 1) < 0) {
        id = it.id;
        break;
      }
    }
    const p = this.opts.pity;
    const reached = !!p && this.rank(tier) >= this.rank(p.tier);
    this.log.dry[source] = reached ? 0 : (this.log.dry[source] ?? 0) + 1;
    this.log.rolls[source] = (this.log.rolls[source] ?? 0) + 1;
    const first = !this.log.seen.includes(id);
    if (first) this.log.seen.push(id);
    this.opts.persist?.();
    // The pity "gave" it only when the tier is one the roll could not have had without the guarantee
    const pityGave = byPity && reached && (o.floor === undefined || this.rank(o.floor) < this.rank(tier));
    return { id, tier, chance: odds[i].chance, pity: pityGave, pityLeft: this.pityLeft(source), first };
  }

  /** The expected share of each tier over many rolls, the pity included (a bot's view for the balance model) */
  expected(source: string, rolls = 1000): LootOdds<T>[] {
    const odds = this.odds(source, {}).map((x) => x.chance);
    const p = this.opts.pity;
    if (!p) return this.odds(source, {});
    // A Markov walk over the dry counter: exact, no sampling
    const pr = this.rank(p.tier);
    const below = odds.slice(0, pr).reduce((a, b) => a + b, 0);
    const forced = this.weightsOf(source).map((w, i) => (i < pr ? 0 : w));
    const fsum = forced.reduce((a, b) => a + b, 0) || 1;
    let dist = new Array(p.within).fill(0);
    dist[0] = 1;
    const out = new Array(this.tiers.length).fill(0);
    for (let n = 0; n < rolls; n++) {
      const nextDist = new Array(p.within).fill(0);
      for (let d = 0; d < p.within; d++) {
        if (!dist[d]) continue;
        if (d + 1 >= p.within) {
          forced.forEach((w, i) => (out[i] += (dist[d] * w) / fsum));
          nextDist[0] += dist[d];
        } else {
          odds.forEach((c, i) => (out[i] += dist[d] * c));
          nextDist[d + 1] += dist[d] * below;
          nextDist[0] += dist[d] * (1 - below);
        }
      }
      dist = nextDist;
    }
    return this.opts.tiers.map((t, i) => ({ tier: t.id, chance: out[i] / rolls, oneIn: out[i] > 0 ? Math.round(rolls / out[i]) : Infinity }));
  }
}
