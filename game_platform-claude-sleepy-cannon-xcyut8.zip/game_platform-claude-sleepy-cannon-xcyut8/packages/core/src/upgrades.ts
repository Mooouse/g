// Meta progression for games with their own code: a shop of permanent upgrades bought with the game's currency between
// runs. Pure (no DOM): usable from the game, unit tests and balance bots. The rules (docs/guides/upgrades.md):
//
// Cost of the level after `l` levels:  c(l) = max( round(base × growth^l), c(l−1) + 1 ),  c(0) = max(1, round(base))
// - growth^l is built by repeated multiplication, not Math.pow: IEEE multiplication is exactly rounded, so every engine
//   gets the same table (Math.pow may differ in the last bit between engines, and round() at .5 would then differ);
// - every level costs strictly more than the one before (a small base with growth near 1 would otherwise repeat prices);
// - all costs are safe integers (≤ 2^53 − 1), checked when the shop is created — bigger economies need a big-number type.
// Bulk purchases sum the same table, so "buy 10" costs exactly what ten single purchases would.
// Levels read from a save are sanitised: an integer in 0..max (a tampered or old save can't make prices negative).
//
// From Yeet the Gnome (QmaCyber/game4, data.ts and bot.ts); its prices are reproduced to the coin (tests).
// A level shop fits idle and launch-distance games; other genres pick another shape (progression.ts: a roster of
// unlocks, tiers, pacts, run choices) — docs/guides/upgrades.md → pick a shape.

export interface UpgradeDef<Id extends string = string> {
  id: Id;
  /** Highest level */
  max: number;
  /** Price of level 1 */
  baseCost: number;
  /** Price multiplier per level (≥ 1) */
  growth: number;
  /** Needs at least one level of this upgrade first (show it locked until then) */
  requires?: Id;
  /** What the upgrade gives at a level (0..max), e.g. launch speed — for "120 → 138" and value-for-money bots */
  value?: (level: number) => number;
  /** Levels with an extra bonus (e.g. ×2 at 10 and 25): the shop's "Next" amount buys up to the next one */
  milestones?: readonly number[];
}

export type Levels<Id extends string = string> = Record<Id, number>;

export type UpgradeState = 'maxed' | 'locked' | 'affordable' | 'too-expensive';

/** How many levels the shop's buy button buys: one, ten, up to the next milestone, or as many as the player can afford */
export type BuyAmount = 1 | 10 | 'next' | 'max';

/** One row of the shop screen: everything a card needs, computed in one place */
export interface ShopRow<Id extends string> {
  id: Id;
  level: number;
  max: number;
  state: UpgradeState;
  /** Levels the buy button buys at the chosen amount (Max: what the coins cover, at least 1; 0 when maxed) */
  count: number;
  /** Their total price (null when maxed) — the label on the button */
  cost: number | null;
  /** The player can buy `count` levels now */
  canBuy: boolean;
  /** 0..1: how close the player is to affording `cost` (goal-gradient: show it as a bar) */
  progress: number;
  /** value(level) and value(level + count) when the def has `value` */
  now?: number;
  next?: number;
  /** Runs until affordable at the given income per run (null: can't estimate) */
  runsToAfford: number | null;
  /** The best value for money among affordable rows (by `score` if given, else by value gain per coin) */
  best: boolean;
  requires?: Id;
  /** Why it is locked when the game's own condition locks it (a story flag, a zone reached): shown instead of "Needs …" */
  lockReason?: string;
}

export interface UpgradeShopOptions<Id extends string> {
  /**
   * The game's own unlock conditions, asked every time: return why `id` is still locked ("Grandma's notebook knows
   * how…"), or null when it's open. For locks that aren't another upgrade (`requires`): story flags, zones, events —
   * and tiers (`lock: (id, levels) => tiers.lock(id, levels)`, progression.ts), which is why it gets the levels.
   * From Brew & Banter (QmaCyber/game5), which had to wrap the shop for its story-locked upgrades.
   */
  lock?: (id: Id, levels: Levels<Id>) => string | null;
}

export class UpgradeShop<Id extends string> {
  readonly defs: readonly UpgradeDef<Id>[];
  private readonly byId: Map<Id, UpgradeDef<Id>>;
  /** costs.get(id)[l] = price of level l + 1 */
  private readonly costs: Map<Id, number[]>;
  /** prefix.get(id)[l] = total price of levels 1..l */
  private readonly prefix: Map<Id, number[]>;

  private readonly lock: ((id: Id, levels: Levels<Id>) => string | null) | undefined;

  constructor(defs: readonly UpgradeDef<Id>[], opts: UpgradeShopOptions<Id> = {}) {
    this.lock = opts.lock;
    const ids = new Set<Id>();
    for (const d of defs) {
      if (ids.has(d.id)) throw new Error(`upgrade ${d.id} is defined twice`);
      ids.add(d.id);
      if (!(Number.isInteger(d.max) && d.max >= 1)) throw new Error(`upgrade ${d.id}: max must be an integer ≥ 1`);
      if (!(Number.isFinite(d.baseCost) && d.baseCost > 0)) throw new Error(`upgrade ${d.id}: baseCost must be > 0`);
      if (!(Number.isFinite(d.growth) && d.growth >= 1)) throw new Error(`upgrade ${d.id}: growth must be ≥ 1`);
    }
    for (const d of defs) if (d.requires && !ids.has(d.requires)) throw new Error(`upgrade ${d.id} requires unknown ${d.requires}`);
    this.defs = defs;
    this.byId = new Map(defs.map((d) => [d.id, d]));
    this.costs = new Map();
    this.prefix = new Map();
    for (const d of defs) {
      const table: number[] = [];
      const sums: number[] = [0];
      let p = d.baseCost;
      for (let l = 0; l < d.max; l++) {
        const c = Math.max(Math.round(p), l === 0 ? 1 : table[l - 1] + 1);
        const sum = sums[l] + c;
        if (!Number.isSafeInteger(sum)) throw new Error(`upgrade ${d.id}: costs pass 2^53 at level ${l + 1} — lower growth/max or use a big-number economy`);
        table.push(c);
        sums.push(sum);
        p *= d.growth;
      }
      this.costs.set(d.id, table);
      this.prefix.set(d.id, sums);
    }
  }

  /** All levels at 0 — also the save defaults for host.load(), so a new upgrade in an update gets level 0 */
  noLevels(): Levels<Id> {
    return Object.fromEntries(this.defs.map((d) => [d.id, 0])) as Levels<Id>;
  }

  private def(id: Id): UpgradeDef<Id> {
    const d = this.byId.get(id);
    if (!d) throw new Error(`unknown upgrade ${id}`);
    return d;
  }

  /** The level of `id` in `levels`, sanitised: an integer in 0..max */
  level(id: Id, levels: Partial<Levels<Id>>): number {
    const v = levels[id];
    const max = this.def(id).max;
    return typeof v === 'number' && Number.isFinite(v) ? Math.min(max, Math.max(0, Math.floor(v))) : 0;
  }

  /** Every level sanitised (use on a loaded save) */
  sanitize(levels: Partial<Levels<Id>>): Levels<Id> {
    return Object.fromEntries(this.defs.map((d) => [d.id, this.level(d.id, levels)])) as Levels<Id>;
  }

  /** What the upgrade gives at its current level in `levels` (its def's `value`; NaN without one) */
  value(id: Id, levels: Partial<Levels<Id>>): number {
    const v = this.def(id).value;
    return v ? v(this.level(id, levels)) : NaN;
  }

  /** Price of the next level from `level` (level 0 → the price of level 1); null at max */
  cost(id: Id, level: number): number | null {
    this.def(id);
    const t = this.costs.get(id)!;
    const l = Math.floor(level);
    return l >= 0 && l < t.length ? t[l] : null;
  }

  /** Price of the next level, or null when maxed */
  nextCost(id: Id, levels: Partial<Levels<Id>>): number | null {
    return this.cost(id, this.level(id, levels));
  }

  /** Total price of `n` levels starting at level `from` (exact: the same table as single purchases); null past max */
  costOf(id: Id, from: number, n: number): number | null {
    this.def(id);
    const sums = this.prefix.get(id)!;
    const a = Math.floor(from);
    const b = a + Math.floor(n);
    if (a < 0 || n < 0 || b >= sums.length) return null;
    return sums[b] - sums[a];
  }

  /** How many levels `coins` buys now (0 when locked or maxed) */
  affordableCount(id: Id, levels: Partial<Levels<Id>>, coins: number): number {
    if (this.isLocked(id, levels)) return 0;
    const sums = this.prefix.get(id)!;
    const a = this.level(id, levels);
    // Largest b with sums[b] − sums[a] ≤ coins (sums is increasing: binary search)
    let lo = a;
    let hi = sums.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (sums[mid] - sums[a] <= coins) lo = mid;
      else hi = mid - 1;
    }
    return lo - a;
  }

  private isLocked(id: Id, levels: Partial<Levels<Id>>): boolean {
    const r = this.def(id).requires;
    return (!!r && this.level(r, levels) === 0) || !!this.lock?.(id, this.sanitize(levels));
  }

  state(id: Id, levels: Partial<Levels<Id>>, coins: number): UpgradeState {
    const lv = this.level(id, levels);
    if (lv >= this.def(id).max) return 'maxed';
    if (this.isLocked(id, levels)) return 'locked';
    return this.cost(id, lv)! <= coins ? 'affordable' : 'too-expensive';
  }

  /** Something can be bought now: the "!" badge on the shop button */
  anyAffordable(levels: Partial<Levels<Id>>, coins: number): boolean {
    return this.defs.some((d) => this.state(d.id, levels, coins) === 'affordable');
  }

  /**
   * Buy levels: 1 (default), 10, or 'max'. A fixed count buys exactly that many or nothing; 'max' buys as many as the
   * coins cover. Returns the new levels and coins, or null if nothing was bought. Never changes its inputs.
   */
  buy(id: Id, levels: Partial<Levels<Id>>, coins: number, amount: BuyAmount = 1): { levels: Levels<Id>; coins: number; bought: number } | null {
    const lv = this.level(id, levels);
    const can = this.affordableCount(id, levels, coins);
    const want = this.amountCount(id, lv, amount);
    const n = amount === 'max' ? can : want <= can ? want : 0;
    if (n <= 0) return null;
    return { levels: { ...this.sanitize(levels), [id]: lv + n }, coins: coins - this.costOf(id, lv, n)!, bought: n };
  }

  /** Levels a fixed amount means at level `lv`: 1, 10 (capped at max), or up to the next milestone (else to max) */
  private amountCount(id: Id, lv: number, amount: BuyAmount): number {
    const d = this.def(id);
    if (amount === 'max') return d.max - lv;
    if (amount === 'next') {
      const m = (d.milestones ?? []).filter((x) => x > lv && x <= d.max).sort((a, b) => a - b)[0];
      return (m ?? d.max) - lv;
    }
    return Math.min(amount, d.max - lv);
  }

  /**
   * Undo / respec: give back the last `n` levels (default 1) at exactly what they cost — a purchase and its refund
   * round-trip to the same coins. Returns null if there is nothing to refund, if another upgrade still needs this one,
   * or if it would close what else was bought (a tier opened by these levels: the game's `lock`).
   */
  refund(id: Id, levels: Partial<Levels<Id>>, coins: number, n = 1): { levels: Levels<Id>; coins: number } | null {
    const lv = this.level(id, levels);
    const k = Math.min(Math.floor(n), lv);
    if (k <= 0) return null;
    const cur = this.sanitize(levels);
    if (lv - k === 0 && this.defs.some((d) => d.requires === id && cur[d.id] > 0)) return null;
    const after = { ...cur, [id]: lv - k };
    if (this.lock && this.defs.some((d) => d.id !== id && cur[d.id] > 0 && !this.lock!(d.id, cur) && this.lock!(d.id, after))) return null;
    return { levels: after, coins: coins + this.costOf(id, lv - k, k)! };
  }

  /** Full respec: every level back at its price (the free-refund pattern of Kingdom Rush and Vampire Survivors) */
  refundAll(levels: Partial<Levels<Id>>, coins: number): { levels: Levels<Id>; coins: number } {
    const cur = this.sanitize(levels);
    return { levels: this.noLevels(), coins: coins + this.defs.reduce((s, d) => s + this.costOf(d.id, 0, cur[d.id])!, 0) };
  }

  /** Ids affordable now — keep the set the player last saw and badge the shop only for new ones (so it doesn't nag) */
  affordableIds(levels: Partial<Levels<Id>>, coins: number): Id[] {
    return this.defs.filter((d) => this.state(d.id, levels, coins) === 'affordable').map((d) => d.id);
  }

  /** Coins needed to buy every level of everything — the length of the meta game, for the balance plan */
  totalCost(): number {
    return this.defs.reduce((s, d) => s + this.prefix.get(d.id)![d.max], 0);
  }

  /** Share of all levels bought, 0..1 — for a progress bar and the balance bot's "how far after N minutes" */
  progress(levels: Partial<Levels<Id>>): number {
    const all = this.defs.reduce((s, d) => s + d.max, 0);
    return this.defs.reduce((s, d) => s + this.level(d.id, levels), 0) / all;
  }

  /**
   * The shop screen in one call: a row per upgrade with its state, what the buy button buys at `amount`, its price,
   * the progress to affording it, "now → next" values, runs until affordable, and the best value for money.
   * `score(levels)` (optional) is the game's measure of power (e.g. the balance bot's expected distance): the best row is
   * the one with the biggest score gain per coin; without it, the biggest relative value gain per coin.
   */
  view(levels: Partial<Levels<Id>>, coins: number, opts: { amount?: BuyAmount; incomePerRun?: number; score?: (levels: Levels<Id>) => number } = {}): ShopRow<Id>[] {
    const amount = opts.amount ?? 1;
    const lv0 = this.sanitize(levels);
    const rows = this.defs.map((d): ShopRow<Id> => {
      const level = lv0[d.id];
      const state = this.state(d.id, lv0, coins);
      const can = this.affordableCount(d.id, lv0, coins);
      // What the button buys at this amount: the fixed count, or for Max what the coins cover (at least the next level)
      const count = state === 'maxed' ? 0 : amount === 'max' ? Math.max(1, can) : this.amountCount(d.id, level, amount);
      const cost = count > 0 ? this.costOf(d.id, level, count) : null;
      const canBuy = state === 'affordable' && cost !== null && cost <= coins;
      const income = opts.incomePerRun;
      return {
        id: d.id,
        level,
        max: d.max,
        state,
        count,
        cost,
        canBuy,
        progress: cost === null ? 1 : Math.min(1, Math.max(0, coins / cost)),
        ...(d.value ? { now: d.value(level), next: d.value(level + count) } : {}),
        runsToAfford: cost === null || state === 'locked' ? null : canBuy ? 0 : income && income > 0 ? Math.ceil((cost - coins) / income) : null,
        best: false,
        ...(d.requires ? { requires: d.requires } : {}),
        ...(state === 'locked' && this.lock?.(d.id, lv0) ? { lockReason: this.lock(d.id, lv0)! } : {}),
      };
    });
    // Best value for money among the affordable rows
    let best: { row: ShopRow<Id>; v: number } | null = null;
    const base = opts.score?.(lv0);
    for (const r of rows) {
      if (!r.canBuy || !r.cost) continue;
      let gain: number | null = null;
      if (opts.score && base !== undefined) gain = opts.score({ ...lv0, [r.id]: r.level + r.count }) - base;
      else if (r.now !== undefined && r.next !== undefined) gain = r.now === 0 ? r.next - r.now : Math.abs(r.next / r.now - 1);
      if (gain === null) continue;
      const v = gain / r.cost;
      if (!best || v > best.v) best = { row: r, v };
    }
    if (best && best.v > 0) best.row.best = true;
    return rows;
  }

  /** A typical new player: the cheapest available level first, until nothing is affordable (balance bots) */
  spendLikeAPlayer(levels: Partial<Levels<Id>>, coins: number): { levels: Levels<Id>; coins: number; bought: Id[] } {
    return this.spend(levels, coins, (id, cur) => -this.cost(id, this.level(id, cur))!);
  }

  /**
   * A careful player: the level with the biggest `score` gain per coin first (score = the game's measure of power,
   * e.g. expected distance). Compare both bots in the balance test: if the careful one is much faster, the cheap
   * upgrades are traps; if both are equal, prices don't matter enough.
   */
  spendBestValue(levels: Partial<Levels<Id>>, coins: number, score: (levels: Levels<Id>) => number): { levels: Levels<Id>; coins: number; bought: Id[] } {
    return this.spend(levels, coins, (id, cur) => {
      const before = score(cur);
      const after = score({ ...cur, [id]: this.level(id, cur) + 1 });
      return (after - before) / this.cost(id, this.level(id, cur))!;
    });
  }

  private spend(levels: Partial<Levels<Id>>, coins: number, rank: (id: Id, cur: Levels<Id>) => number): { levels: Levels<Id>; coins: number; bought: Id[] } {
    let cur = { levels: this.sanitize(levels), coins };
    const bought: Id[] = [];
    for (;;) {
      let pick: { id: Id; r: number } | null = null;
      for (const d of this.defs) {
        if (this.state(d.id, cur.levels, cur.coins) !== 'affordable') continue;
        const r = rank(d.id, cur.levels);
        if (!pick || r > pick.r) pick = { id: d.id, r };
      }
      if (!pick) return { ...cur, bought };
      const next = this.buy(pick.id, cur.levels, cur.coins)!;
      cur = { levels: next.levels, coins: next.coins };
      bought.push(pick.id);
    }
  }
}

const SUFFIXES = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'Dc'];

/**
 * A game amount for the screen: 999, 1.23K, 12.3K, 123K, 1.23M … up to Dc (10^33), then 1.23e36.
 * Three significant digits. `round: 'down'` for what the player has (never show more than they own), `'up'` for prices
 * (never show less than they cost) — so a balance of 1,000 and a price of 1,005 read 1.00K and 1.01K, not both 1.00K.
 */
export function formatAmount(n: number, round: 'down' | 'up' = 'down'): string {
  if (!Number.isFinite(n)) return n > 0 ? '∞' : n < 0 ? '−∞' : '—';
  const sign = n < 0 ? '−' : '';
  const a = Math.abs(n);
  // On the magnitude; the tiny nudge absorbs binary noise (1.23 stored as 1.2299999…)
  const r = (x: number) => (round === 'down' ? Math.floor(x + 1e-9) : Math.ceil(x - 1e-9));
  if (a < 1000) return sign + String(r(a));
  let tier = Math.floor(Math.log10(a) / 3);
  // log10 can be off by one ulp at exact powers: make the mantissa land in [1, 1000)
  if (a / 10 ** (tier * 3) >= 1000) tier++;
  if (a / 10 ** (tier * 3) < 1) tier--;
  const sci = tier >= SUFFIXES.length;
  const exp = sci ? Math.floor(Math.log10(a)) : tier * 3;
  const m0 = a / 10 ** exp;
  const digits = sci || m0 < 10 ? 2 : m0 < 100 ? 1 : 0;
  const f = 10 ** digits;
  const m = r(m0 * f) / f;
  // Rounding up can reach the next tier (999.5K → 1.00M)
  if (!sci && m >= 1000) return tier + 1 < SUFFIXES.length ? `${sign}1.00${SUFFIXES[tier + 1]}` : `${sign}1.00e${(tier + 1) * 3}`;
  if (sci && m >= 10) return `${sign}1.00e${exp + 1}`;
  return sign + (sci ? `${m.toFixed(2)}e${exp}` : `${m.toFixed(digits)}${SUFFIXES[tier]}`);
}
