// @gp/core/quality — quality levels for any engine: N levels of your own settings (render scale, DPR cap, bloom,
// shadows, particle share …), a start guessed from the device (a software GPU at the cheapest, a phone in the middle, a
// desktop near the top), judged on the interval between frames (a WebGL frame's GPU time never shows in the CPU time of
// your update and draw), stepping down after a slow stretch and up after a calm one whose length doubles after every
// step down (5 s → at most 60 s), so it doesn't flap — and a level that failed three step ups isn't tried again. Dev builds pin a level with ?q=<n> (glare audits, screenshots).
//
// From Frankengun (game22, view.ts: seven levels on three, the render scale the strongest lever). @gp/art/perf's
// AutoQuality is the Canvas 2D one (four fixed levels judged on the frame's work).
//
//   const LEVELS = [{ scale: 1, dprMax: 2, bloom: true }, { scale: 1, dprMax: 1.25, bloom: false }, { scale: 0.65, dprMax: 1, bloom: false }];
//   const q = new QualityLadder({ levels: LEVELS, start: deviceTier({ gl: eng.renderer.getContext() }).tier, onChange: apply });
//   function apply(l) { eng.setRenderScale(l.scale, { dprMax: l.dprMax }); bloomOn = l.bloom; }
//   apply(q.current);
//   q.watch(eng);                     // measures every frame while a run is on (nothing on menus, the pause, an ad)

/** A guess at the device: what it renders on and what it is */
export type DeviceTier = 'software' | 'low' | 'phone' | 'desktop';

export interface DeviceInfo {
  tier: DeviceTier;
  /** The GPU's name as WebGL reports it ('' when unknown) */
  renderer: string;
  /** A software rasterizer (SwiftShader, llvmpipe, Microsoft Basic Render): a blocklisted GPU, a VM, gp qa's headless Chromium */
  software: boolean;
  /** A touch screen is the main pointer */
  coarse: boolean;
}

type GL = WebGLRenderingContext | WebGL2RenderingContext;

/** The GPU's name: the unmasked renderer where the browser gives it, else RENDERER. Without a context: a throwaway one ('' outside a browser) */
export function gpuRenderer(gl?: GL | null): string {
  let own: GL | null = null;
  try {
    if (!gl) {
      if (typeof document === 'undefined') return '';
      own = document.createElement('canvas').getContext('webgl2') ?? document.createElement('canvas').getContext('webgl');
      gl = own;
    }
    if (!gl) return '';
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    return String(gl.getParameter(dbg ? dbg.UNMASKED_RENDERER_WEBGL : gl.RENDERER) ?? '');
  } catch {
    return '';
  } finally {
    // A throwaway context is given back at once (browsers allow only so many)
    own?.getExtension('WEBGL_lose_context')?.loseContext();
  }
}

/** A software rasterizer's name */
export const isSoftwareGpu = (renderer: string): boolean => /swiftshader|llvmpipe|softpipe|lavapipe|software|basic render|mesa offscreen/i.test(renderer);

/**
 * The device's tier: 'software' when WebGL runs on the CPU; on a touch screen 'low' (≤ 4 cores or ≤ 3 GB, where the
 * browser says) or 'phone'; else 'desktop'. Pass the game's own context (`gl`) or its renderer string to skip the probe
 */
export function deviceTier(o: { gl?: GL | null; renderer?: string; coarse?: boolean; cores?: number; memoryGB?: number } = {}): DeviceInfo {
  const renderer = o.renderer ?? gpuRenderer(o.gl);
  const nav = (typeof navigator !== 'undefined' ? navigator : {}) as { hardwareConcurrency?: number; deviceMemory?: number };
  const coarse = o.coarse ?? (typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches);
  const cores = o.cores ?? nav.hardwareConcurrency ?? 8;
  const mem = o.memoryGB ?? nav.deviceMemory ?? 8;
  const software = isSoftwareGpu(renderer);
  const tier: DeviceTier = software ? 'software' : coarse ? (cores <= 4 || mem <= 3 ? 'low' : 'phone') : 'desktop';
  return { tier, renderer, software, coarse };
}

/** The level a tier starts at, of `count` levels: software the cheapest, low two thirds down, phone the middle, desktop the second best */
export function startLevel(tier: DeviceTier, count: number): number {
  const last = Math.max(0, count - 1);
  if (tier === 'software') return last;
  if (tier === 'low') return Math.round(last * 0.67);
  if (tier === 'phone') return Math.round(last / 2);
  return Math.min(1, last);
}

/** Dev builds: the level `?q=<n>` pins (null without one, and always null in a production build) */
export function qualityPin(count: number, search: string = typeof location !== 'undefined' ? location.search : ''): number | null {
  if (!import.meta.env?.DEV) return null;
  const v = new URLSearchParams(search).get('q');
  if (v === null || v === '' || !/^\d+$/.test(v)) return null;
  return Math.max(0, Math.min(count - 1, Number(v)));
}

export interface QualityOptions<L> {
  /** From the best (0) to the cheapest: each level's settings, any shape */
  levels: readonly L[];
  /** A level, or a device tier (deviceTier().tier) mapped by startLevel(). Default 'desktop' */
  start?: number | DeviceTier;
  /** 'interval' (default): the time between frames, ms — what a WebGL game is limited by. 'work': ms of your update + draw */
  measure?: 'interval' | 'work';
  /** Slow above this smoothed ms (interval: 21 ≈ under 48 fps; work: 10) */
  slowMs?: number;
  /**
   * Calm below this smoothed ms (interval: 17.5 — holding a 60 Hz display's rate; work: 5). On a 60 Hz display the
   * interval can't show headroom, so a step up is a try: if it runs slow, it steps back and the next try waits twice as long
   */
  fastMs?: number;
  /** Frames slow in a row before a step down (45) */
  slowFrames?: number;
  /** Seconds of calm before the first step up (5); doubles after each step down */
  calmSec?: number;
  /** The calm needed never grows past this (60 s) */
  calmMaxSec?: number;
  /** Never better than this level (a settings "Low": a floor) */
  floor?: number;
  /** A fixed level: measure() leaves it alone (default: qualityPin(): ?q= in dev). null: not pinned */
  pin?: number | null;
  onChange?: (level: L, index: number) => void;
}

/** Engines report frames like this (the adapters' Engine): watch() measures on it */
interface FrameSource {
  readonly running: boolean;
  onFrame(fn: () => void): () => void;
}

/** N quality levels with a device start, measured on the frame interval, doubling hysteresis, a floor and a dev pin */
export class QualityLadder<L> {
  readonly levels: readonly L[];
  level: number;
  /** Smoothed measure, ms */
  avg: number;
  /** Seconds of calm the next step up needs (doubles after each step down, up to calmMaxSec) */
  calmSec: number;
  readonly pinned: boolean;
  private flr: number;
  /** The best level steps up may reach: a level whose step up failed 3 times isn't tried again this session */
  private top = 0;
  private readonly fails = new Map<number, number>();
  /** Frames since the last step up (a step down within 10 s of it: that step up failed) */
  private sinceUp = Infinity;
  private slow = 0;
  private calm = 0;
  private frames = 0;
  private readonly o: Required<Omit<QualityOptions<L>, 'onChange' | 'pin' | 'levels' | 'start' | 'floor'>>;
  private readonly onChange?: (level: L, index: number) => void;

  constructor(o: QualityOptions<L>) {
    if (!o.levels.length) throw new Error('QualityLadder: no levels');
    this.levels = o.levels;
    const work = o.measure === 'work';
    this.o = {
      measure: o.measure ?? 'interval',
      slowMs: o.slowMs ?? (work ? 10 : 21),
      fastMs: o.fastMs ?? (work ? 5 : 17.5),
      slowFrames: o.slowFrames ?? 45,
      calmSec: o.calmSec ?? 5,
      calmMaxSec: o.calmMaxSec ?? 60,
    };
    this.calmSec = this.o.calmSec;
    this.flr = this.clamp(o.floor ?? 0, 0);
    const pin = o.pin === undefined ? qualityPin(o.levels.length) : o.pin;
    this.pinned = pin !== null;
    const start = pin ?? (typeof o.start === 'number' ? o.start : startLevel(o.start ?? 'desktop', o.levels.length));
    this.level = this.clamp(start, this.pinned ? 0 : this.flr);
    this.avg = (this.o.slowMs + this.o.fastMs) / 2;
    this.onChange = o.onChange;
  }

  get current(): L {
    return this.levels[this.level];
  }
  get count(): number {
    return this.levels.length;
  }
  /** Never better than this level */
  get floor(): number {
    return this.flr;
  }
  set floor(v: number) {
    this.flr = this.clamp(v, 0);
    if (this.level < this.flr) this.go(this.flr);
  }

  /** One frame's measure (ms): the interval since the last frame, or the frame's work. Ignored while pinned */
  frame(ms: number): void {
    if (this.pinned || !(ms >= 0)) return;
    this.frames++;
    this.sinceUp++;
    // A hitch (a GC, a tab switch) counts as 100 ms at most
    const x = Math.min(ms, 100);
    this.avg = this.avg * 0.92 + x * 0.08;
    if (this.frames < 20) return;
    if (this.avg > this.o.slowMs) {
      this.calm = 0;
      if (++this.slow > this.o.slowFrames && this.level < this.levels.length - 1) {
        this.calmSec = Math.min(this.o.calmMaxSec, this.calmSec * 2);
        if (this.sinceUp < 600) {
          const n = (this.fails.get(this.level) ?? 0) + 1;
          this.fails.set(this.level, n);
          if (n >= 3) this.top = Math.max(this.top, this.level + 1);
        }
        this.sinceUp = Infinity;
        this.go(this.level + 1);
        // Start the new level's average from the middle: it is judged on its own frames
        this.avg = (this.o.slowMs + this.o.fastMs) / 2;
      }
    } else if (this.avg < this.o.fastMs) {
      this.slow = 0;
      // Calm counted in frames at 60 per second (interval mode: the frames are the time)
      if (++this.calm > this.calmSec * 60 && this.level > Math.max(this.flr, this.top)) {
        this.go(this.level - 1);
        this.sinceUp = 0;
      }
    } else this.slow = this.calm = 0;
  }

  /** Go to a level now (a settings choice): clamped to the floor, the backoff and the failed tries start over */
  set(level: number): void {
    this.calmSec = this.o.calmSec;
    this.top = 0;
    this.fails.clear();
    this.sinceUp = Infinity;
    this.go(level);
  }

  /**
   * Measure an engine's frames: the interval between frames while it runs (menus, the pause, an ad and the first frame
   * after one are left out). Returns an unsubscribe
   */
  watch(eng: FrameSource, now: () => number = () => performance.now()): () => void {
    let last = -1;
    return eng.onFrame(() => {
      if (!eng.running) {
        last = -1;
        return;
      }
      const t = now();
      if (last >= 0) this.frame(t - last);
      last = t;
    });
  }

  private clamp(l: number, min: number): number {
    return Math.max(min, Math.min(this.levels.length - 1, Math.round(l)));
  }

  private go(level: number): void {
    const l = this.clamp(level, this.flr);
    this.slow = this.calm = 0;
    if (l === this.level) return;
    this.level = l;
    this.onChange?.(this.levels[l], l);
  }
}
