// "Welcome back" (R3 and R4 in docs/research/feedback-and-metrics-2026-10.md): on the first visit of a new day, a short
// card over the title says what is waiting — today's daily, the goal left from last time, a run to go on with — and its
// one big button goes straight into play (still one click from the portal's Play Now to gameplay). D1 was 1–4 % in
// every launched game and none of them said "tomorrow" or "welcome back"; the card says it.
//
//   const visit = recordVisit(save.visit);            // @gp/core/daily: is this a new day?
//   save.visit = visit.log; host.save(save);
//   showTitle();
//   if (visit.newDay) welcomeBack({ host, daily: { done: dailyDone(save.daily, dayKey()) }, goal, resume: !!host.loadRun(RUN),
//     onContinue: () => (host.loadRun(RUN) ? resumeRun() : play()) });
//
// The card is a modal over whatever is on screen (hints wait under it); a tap outside it, or its ×, closes it.
// Themeable: screenTheme() for every platform screen at once, or --gp-welcome-bg, -ink, -muted, -accent, -accent-ink,
// -radius, -font on #gp-welcome.

import { cardOpened } from './cards.ts';
import type { GameHost } from './host.ts';
import { FONT_FALLBACK } from './i18n.ts';
import { icon } from './icons.ts';
import type { ResultsGoal } from './results-ui.ts';

export interface WelcomeBackOptions {
  host: Pick<GameHost, 'minTouchPx' | 'screen' | 't'>;
  /** Today's daily: ready or done (omit when the game has none) */
  daily?: { done: boolean; label?: string } | null;
  /** The goal left from the last session ("Lithium Candle · 82 %") */
  goal?: ResultsGoal | null;
  /** A run saved before the player left (host.loadRun): the button says "Continue your run" */
  resume?: boolean;
  /** Your own lines: what's new since the last visit (one or two, short) — offline earnings: host.t('gp.offline.earned', …) */
  lines?: string[];
  /** More choices above the big button: a rewardedButton() ×2 for the offline earnings (@gp/core offlineEarnings) */
  extra?: HTMLElement[];
  /** The big button: into play (resume the saved run, or a new one) */
  onContinue(): void;
  /** The card was closed without playing (the × or a tap outside) */
  onClose?(): void;
  /** Its words (default gp.welcome.title, gp.welcome.resume / gp.play) */
  title?: string;
  continueLabel?: string;
  /** Where it goes (default document.body) */
  root?: HTMLElement;
}

const CSS = `
:where(#gp-welcome) { --gp-welcome-bg: var(--gp-theme-bg, #18263a); --gp-welcome-ink: var(--gp-theme-ink, #f2f7ff);
  --gp-welcome-muted: var(--gp-theme-muted, #a9b9cc); --gp-welcome-accent: var(--gp-theme-accent, #ffd166);
  --gp-welcome-accent-ink: var(--gp-theme-accent-ink, #18222e); --gp-welcome-radius: var(--gp-theme-radius, 20px);
  --gp-welcome-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-welcome-veil { position: fixed; inset: 0; z-index: 40; display: flex; align-items: center; justify-content: center; background: var(--gp-theme-backdrop, rgba(0, 0, 0, 0.45)); }
#gp-welcome { position: relative; box-sizing: border-box; width: min(90vw, 400px); max-height: 92vh; overflow: auto; display: flex; flex-direction: column;
  gap: 10px; padding: 22px 20px 18px; border-radius: var(--gp-welcome-radius); background: var(--gp-welcome-bg); color: var(--gp-welcome-ink);
  font: 600 17px var(--gp-welcome-font); text-align: center; }
#gp-welcome h2 { margin: 0 32px; font-size: 28px; font-family: var(--gp-theme-display, inherit); }
#gp-welcome .gp-w-line { color: var(--gp-welcome-muted); }
#gp-welcome .gp-w-line svg { color: var(--gp-welcome-accent); margin-left: 4px; }
#gp-welcome .gp-w-goal { text-align: left; padding: 10px 12px; border-radius: 14px; background: var(--gp-theme-panel, rgba(255, 255, 255, 0.06)); }
#gp-welcome .gp-w-goal b { float: right; color: var(--gp-welcome-accent); font-variant-numeric: tabular-nums; }
#gp-welcome .gp-bar { clear: both; height: 8px; border-radius: 4px; background: var(--gp-theme-track, rgba(255, 255, 255, 0.16)); overflow: hidden; margin-top: 6px; }
#gp-welcome .gp-bar i { display: block; height: 100%; background: var(--gp-welcome-accent); }
#gp-welcome button.gp-w-go { min-width: 0; margin: 0; text-transform: none; border: 0; border-radius: 999px; cursor: pointer; background: var(--gp-welcome-accent); color: var(--gp-welcome-accent-ink);
  font: 800 22px var(--gp-theme-display, var(--gp-welcome-font)); padding: 0 22px; }
#gp-welcome button.gp-w-x { position: absolute; min-width: 0; padding: 0; margin: 0; top: 6px; right: 6px; border: 0; background: transparent; color: var(--gp-welcome-muted);
  font: 700 24px var(--gp-welcome-font); cursor: pointer; display: flex; align-items: center; justify-content: center; }
`;

/** The card, open now; returns a close() for the game (it closes itself on its buttons) */
export function welcomeBack(opts: WelcomeBackOptions): { close(): void; el: HTMLElement } {
  const { host } = opts;
  if (!document.getElementById('gp-welcome-css')) {
    const style = document.createElement('style');
    style.id = 'gp-welcome-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  // One card at a time: a second call replaces the first
  document.getElementById('gp-welcome-veil')?.remove();
  const veil = document.createElement('div');
  veil.id = 'gp-welcome-veil';
  const card = document.createElement('section');
  card.id = 'gp-welcome';
  card.dataset.gp = 'welcome';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-modal', 'true');
  const title = opts.title ?? host.t('gp.welcome.title');
  card.setAttribute('aria-label', title);
  const h = document.createElement('h2');
  h.textContent = title;
  card.append(h);
  const line = (text: string) => Object.assign(document.createElement('div'), { className: 'gp-w-line', textContent: text });
  if (opts.daily) {
    const l = line(opts.daily.label ?? host.t(opts.daily.done ? 'gp.welcome.dailyDone' : 'gp.welcome.daily'));
    // "done" is a drawn check after the words, not a glyph in them
    if (opts.daily.done && opts.daily.label === undefined) l.append(icon('check', { stroke: 2.6 }));
    card.append(l);
  }
  for (const l of opts.lines ?? []) card.append(line(l));
  if (opts.goal) {
    const g = document.createElement('div');
    g.className = 'gp-w-goal';
    g.dataset.gp = 'welcome-goal';
    const p = typeof opts.goal.progress === 'number' && Number.isFinite(opts.goal.progress) ? Math.max(0, Math.min(1, opts.goal.progress)) : null;
    g.textContent = opts.goal.label;
    if (p !== null) {
      const b = document.createElement('b');
      b.textContent = `${Math.floor(p * 100)} %`;
      g.prepend(b);
      const bar = document.createElement('div');
      bar.className = 'gp-bar';
      const fill = document.createElement('i');
      fill.style.width = `${p * 100}%`;
      bar.append(fill);
      g.append(bar);
    }
    card.append(g);
  }
  const go = document.createElement('button');
  go.type = 'button';
  go.className = 'gp-w-go';
  go.dataset.gp = 'welcome-continue';
  go.style.minHeight = `${Math.max(56, host.minTouchPx * 1.2)}px`;
  go.textContent = opts.continueLabel ?? host.t(opts.resume ? 'gp.welcome.resume' : 'gp.play');
  const x = document.createElement('button');
  x.type = 'button';
  x.className = 'gp-w-x';
  x.dataset.gp = 'welcome-close';
  x.append(icon('close', { size: 22, stroke: 2.4 }));
  x.setAttribute('aria-label', host.t('gp.back'));
  x.style.minWidth = x.style.minHeight = `${host.minTouchPx}px`;
  for (const e of opts.extra ?? []) card.append(e);
  card.append(go, x);
  veil.append(card);
  let open = true;
  let closed = () => {};
  const close = () => {
    if (!open) return;
    open = false;
    veil.remove();
    closed();
  };
  go.addEventListener('click', () => {
    close();
    opts.onContinue();
  });
  x.addEventListener('click', () => {
    close();
    opts.onClose?.();
  });
  veil.addEventListener('click', (e) => {
    if (e.target === veil) {
      close();
      opts.onClose?.();
    }
  });
  (opts.root ?? document.body).append(veil);
  closed = cardOpened('welcome', veil); // one card at a time (cards.ts): queued cards wait for it
  host.screen('welcome');
  return { close, el: card };
}
