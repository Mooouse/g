// Stars per level and sequential unlock: what every level-based code game wrote by hand. Germ Bait (12 dishes), Hang the
// Moon (30 nights), Nimbus Drift (39 levels), Dread Throne (6 stages) and Starsilk (10 depths) each kept `stars: number[]`
// in the save, clamped it on load, kept the best, counted the new stars for a first-clear bonus and opened a level once
// the one before it had a star. Pure functions over a plain array, so the array stays in the game's own save.

export type StarCount = 0 | 1 | 2 | 3;

/** The saved stars made safe: one entry per level, each a whole 0–3 (an old, short or broken save gets 0s) */
export function loadStars(saved: unknown, levels: number): StarCount[] {
  const src = Array.isArray(saved) ? saved : [];
  return Array.from({ length: levels }, (_, i) => {
    const n = Number(src[i]);
    return (Number.isFinite(n) ? Math.max(0, Math.min(3, Math.floor(n))) : 0) as StarCount;
  });
}

/** Level i is open when it is the first, the one before it has a star, or it has a star itself (a level added later) */
export function levelOpen(stars: readonly number[], i: number): boolean {
  return i === 0 || (stars[i - 1] ?? 0) > 0 || (stars[i] ?? 0) > 0;
}

/** Where Play goes: the first level without a star, or the last one when every level has one */
export function firstOpenLevel(stars: readonly number[]): number {
  const i = stars.findIndex((s) => !(s > 0));
  return i < 0 ? Math.max(0, stars.length - 1) : i;
}

export const totalStars = (stars: readonly number[]): number => stars.reduce((a, b) => a + (b > 0 ? b : 0), 0);

export interface StarsRecord {
  /** Stars above the previous best (0 on a worse replay): what a "new stars" bonus pays for, once */
  gained: number;
  /** The best now */
  best: StarCount;
  /** The level had no star before this */
  firstClear: boolean;
}

/** Keep the best: writes `stars[i] = max(old, got)` and says what changed. Save after it; pay `gained`, never `got` */
export function recordStars(stars: number[], i: number, got: number): StarsRecord {
  const old = Math.max(0, Math.min(3, Math.floor(stars[i] ?? 0)));
  const now = Math.max(0, Math.min(3, Math.floor(got)));
  const best = Math.max(old, now) as StarCount;
  stars[i] = best;
  return { gained: best - old, best, firstClear: old === 0 && best > 0 };
}

/**
 * Stars for a finished level where lower is better (moves, seconds, tilt) against its par, the best possible:
 * 3 within `par + three`, 2 within `par + two`, else 1. Nimbus Drift: `{ three: 0, two: max(2, ⌈0.3 · par⌉) }` swipes;
 * Hang the Moon: `{ three: 0.75, two: 4 }` degrees.
 */
export function starsFromPar(score: number, par: number, slack: { three?: number; two: number }): 1 | 2 | 3 {
  if (score <= par + (slack.three ?? 0)) return 3;
  if (score <= par + slack.two) return 2;
  return 1;
}

/**
 * Stars for a finished level where higher is better, as a share 0–1 (health left): 3 from `three`, 2 from `two`, else 1.
 * Germ Bait: `(hp, 0.75, 0.35)`; Dread Throne: `(hp, 0.9, 0.5)`.
 */
export function starsFromShare(share: number, three: number, two: number): 1 | 2 | 3 {
  if (share >= three) return 3;
  if (share >= two) return 2;
  return 1;
}
