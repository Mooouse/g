// The coach's hand: a ghost hand that shows the gesture instead of a sentence — a tap, a swipe, a drag or a press and
// hold, at a point or from one point (or element) to another. Idle Garage Evolution drew one by hand on its canvas
// (scene.ts:763-812: a swipe, a tap, a hold, a pull) and Craft Pickaxe another (view.ts:686): "show the rule, don't
// write it" (first-minute.md §3). A DOM overlay over whatever the game draws (canvas, Pixi, three, DOM), no pointer
// events, drawn SVG (themeable) or a sprite of the game's own; with reduced motion asked for, a still hand and an arrow.
//
//   const tips = hints({ seen: save.hints, onSeen: () => host.save(save) });
//   tips.show('merge', host.t('hint.merge'), { hand: { gesture: 'drag', from: () => cellCenter(a), to: () => cellCenter(b) } });
//   // the hand comes and goes with its hint: gone on tips.done('merge'), hidden behind a modal
//
//   const hand = coachHand({ gesture: 'tap', at: document.querySelector('[data-gp=play]')! });   // standalone
//   hand.destroy();
//
// Points are viewport CSS px ({ x, y }: clientX/clientY), an element (its centre) or a function returning a point —
// read again on every loop, so the hand follows a layout that moves (a resize, a camera). Themeable: --gp-coach-fill,
// --gp-coach-ink, --gp-coach-ring (falling back to --gp-theme-accent) on #gp-coach.

import { iconOf, injectCss, reducedMotion, SVG_NS, type UiIcon } from './ui-kit.ts';

export type CoachGesture = 'tap' | 'swipe' | 'drag' | 'hold';
export type CoachPoint = { x: number; y: number } | Element | (() => { x: number; y: number } | null);

export interface CoachHandOptions {
  /** Default 'tap' (or 'swipe' when `from` and `to` are given) */
  gesture?: CoachGesture;
  /** Where a tap or a hold goes */
  at?: CoachPoint;
  /** Where a swipe or a drag starts … */
  from?: CoachPoint;
  /** … and ends */
  to?: CoachPoint;
  /** Where it shows (default document.body) */
  root?: HTMLElement;
  /** The game's own hand (an image URL, an element, an <svg>) instead of the platform's drawn one */
  sprite?: UiIcon;
  /** The fingertip in the sprite, as a share of its width and height (default [0.42, 0.04]: the drawn hand's tip) */
  hotspot?: [number, number];
  /** The hand's height in CSS px (default 64) */
  size?: number;
}

export interface CoachHand {
  readonly el: HTMLElement;
  /** Show it (again), with new options merged in */
  show(opts?: Partial<CoachHandOptions>): void;
  hide(): void;
  readonly visible: boolean;
  destroy(): void;
}

const CSS = `
:where(#gp-coach) { --gp-coach-fill: #ffffff; --gp-coach-ink: #1b2233; --gp-coach-ring: var(--gp-theme-accent, #ffd166); }
#gp-coach { position: fixed; inset: 0; z-index: 31; pointer-events: none; overflow: hidden; }
#gp-coach[hidden] { display: none; }
#gp-coach .gp-ch-hand { position: absolute; left: 0; top: 0; transform-origin: 0 0; will-change: transform; filter: drop-shadow(0 3px 4px rgba(0, 0, 0, 0.35)); }
#gp-coach .gp-ch-hand > img, #gp-coach .gp-ch-hand > canvas, #gp-coach .gp-ch-hand > svg { display: block; width: 100%; height: 100%; object-fit: contain; }
#gp-coach .gp-ch-ring { position: absolute; left: 0; top: 0; width: 44px; height: 44px; margin: -22px 0 0 -22px; border-radius: 50%;
  border: 3px solid var(--gp-coach-ring); box-sizing: border-box; opacity: 0; }
#gp-coach svg.gp-ch-path { position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; }
#gp-coach svg.gp-ch-path path, #gp-coach svg.gp-ch-path line { stroke: var(--gp-coach-ring); stroke-width: 3; fill: none; stroke-linecap: round; stroke-dasharray: 6 8; opacity: 0.85; }
#gp-coach svg.gp-ch-path polygon { fill: var(--gp-coach-ring); opacity: 0.9; }
`;

// A pointing hand on a 40×48 box; its fingertip at (17, 2)
const HAND_PATH =
  'M17 2.5c2.3 0 4 1.8 4 4V22l1.6-.4c2-.5 4 .6 4.6 2.5l.2.6 1.2-.2c2-.3 3.9 1 4.3 2.9l.1.5 .8-.1c2.1-.2 3.9 1.4 3.9 3.5V38c0 4.7-3.8 8.5-8.5 8.5h-6.4c-3.1 0-5.9-1.6-7.5-4.3L4.6 32.4c-1.1-1.8-.5-4.2 1.4-5.2 1.6-.9 3.6-.5 4.8.9L13 31V6.5c0-2.2 1.8-4 4-4z';
const HOT: [number, number] = [17 / 40, 2 / 48];

function drawnHand(): SVGSVGElement {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 40 48');
  svg.setAttribute('aria-hidden', 'true');
  svg.dataset.mark = 'hand';
  const p = document.createElementNS(SVG_NS, 'path');
  p.setAttribute('d', HAND_PATH);
  p.setAttribute('fill', 'var(--gp-coach-fill)');
  p.setAttribute('stroke', 'var(--gp-coach-ink)');
  p.setAttribute('stroke-width', '2.4');
  p.setAttribute('stroke-linejoin', 'round');
  const nail = document.createElementNS(SVG_NS, 'path');
  nail.setAttribute('d', 'M14.6 7.5a2.4 2.4 0 0 1 4.8 0');
  nail.setAttribute('fill', 'none');
  nail.setAttribute('stroke', 'var(--gp-coach-ink)');
  nail.setAttribute('stroke-width', '1.6');
  nail.setAttribute('stroke-linecap', 'round');
  svg.append(p, nail);
  return svg;
}

/** A point now: an element's centre, a function's answer, or the point itself (null: not on the page) */
export function coachPoint(p: CoachPoint | undefined): { x: number; y: number } | null {
  if (!p) return null;
  if (typeof p === 'function') return p();
  if (p instanceof Element) {
    if (!p.isConnected) return null;
    const r = p.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }
  return Number.isFinite(p.x) && Number.isFinite(p.y) ? { x: p.x, y: p.y } : null;
}

/** The coach's hand, on screen now (one at a time: a second replaces the first) */
export function coachHand(initial: CoachHandOptions): CoachHand {
  injectCss('gp-coach-css', CSS);
  document.getElementById('gp-coach')?.remove();
  let o: CoachHandOptions = { ...initial };
  const layer = document.createElement('div');
  layer.id = 'gp-coach';
  layer.dataset.gp = 'coach';
  layer.setAttribute('aria-hidden', 'true');
  const path = document.createElementNS(SVG_NS, 'svg');
  path.classList.add('gp-ch-path');
  const ring = document.createElement('div');
  ring.className = 'gp-ch-ring';
  const hand = document.createElement('div');
  hand.className = 'gp-ch-hand';
  layer.append(path, ring, hand);
  (o.root ?? document.body).append(layer);

  let anims: Animation[] = [];
  let visible = false;
  let alive = true;
  let retry: ReturnType<typeof setTimeout> | null = null;

  const gesture = (): CoachGesture => o.gesture ?? (o.from && o.to ? 'swipe' : 'tap');
  const stop = () => {
    for (const a of anims) a.cancel();
    anims = [];
    if (retry) clearTimeout(retry);
    retry = null;
  };

  const setSprite = () => {
    const size = o.size ?? 64;
    hand.replaceChildren(o.sprite !== undefined ? iconOf(o.sprite) : drawnHand());
    hand.style.height = `${size}px`;
    hand.style.width = `${o.sprite !== undefined ? size : (size * 40) / 48}px`;
  };

  /** One loop of the gesture, from the points as they are now; the next loop reads them again */
  const loop = () => {
    stop();
    if (!layer.isConnected) alive = false; // replaced by another hand, or the page cleared
    if (!alive || !visible) return;
    const g = gesture();
    const a = coachPoint(g === 'swipe' || g === 'drag' ? (o.from ?? o.at) : (o.at ?? o.from));
    const b = g === 'swipe' || g === 'drag' ? coachPoint(o.to) : null;
    if (!a || ((g === 'swipe' || g === 'drag') && !b)) {
      // The point isn't on the page yet (a cell not laid out): look again shortly
      layer.style.visibility = 'hidden';
      retry = setTimeout(loop, 400);
      return;
    }
    layer.style.visibility = '';
    const size = o.size ?? 64;
    const w = o.sprite !== undefined ? size : (size * 40) / 48;
    const [hx, hy] = o.hotspot ?? HOT;
    /** The hand's transform with its fingertip at (x, y), lifted by `lift` px, scaled by `s` */
    const at = (x: number, y: number, lift = 0, s = 1) => `translate(${x - hx * w * s}px, ${y - hy * size * s + lift}px) scale(${s})`;
    ring.style.left = `${a.x}px`;
    ring.style.top = `${a.y}px`;
    path.replaceChildren();
    if (b) {
      const line = document.createElementNS(SVG_NS, 'line');
      line.setAttribute('x1', String(a.x));
      line.setAttribute('y1', String(a.y));
      line.setAttribute('x2', String(b.x));
      line.setAttribute('y2', String(b.y));
      // An arrowhead at the end: where it goes, even standing still
      const ang = Math.atan2(b.y - a.y, b.x - a.x);
      const tip = (d: number, s: number) => `${b.x - Math.cos(ang) * d + Math.cos(ang + Math.PI / 2) * s},${b.y - Math.sin(ang) * d + Math.sin(ang + Math.PI / 2) * s}`;
      const head = document.createElementNS(SVG_NS, 'polygon');
      head.setAttribute('points', `${b.x},${b.y} ${tip(14, 8)} ${tip(14, -8)}`);
      path.append(line, head);
    }
    const still = reducedMotion() || typeof hand.animate !== 'function';
    if (still) {
      // No motion: the hand pressed at the start, the path's arrow says where to
      hand.style.transform = at(a.x, a.y, 0, 0.94);
      ring.style.opacity = g === 'hold' || g === 'tap' ? '0.9' : '0';
      ring.style.transform = 'scale(1)';
      layer.dataset.still = '';
      return;
    }
    delete layer.dataset.still;
    const ms = { tap: 1400, hold: 2200, swipe: 1500, drag: 2300 }[g];
    let frames: Keyframe[];
    let ringFrames: Keyframe[];
    if (g === 'tap') {
      frames = [
        { transform: at(a.x, a.y, 18), opacity: 0, offset: 0 },
        { transform: at(a.x, a.y, 14), opacity: 1, offset: 0.2 },
        { transform: at(a.x, a.y, 0, 0.92), opacity: 1, offset: 0.4 },
        { transform: at(a.x, a.y, 10), opacity: 1, offset: 0.6 },
        { transform: at(a.x, a.y, 16), opacity: 0, offset: 1 },
      ];
      ringFrames = [
        { opacity: 0, transform: 'scale(0.3)', offset: 0 },
        { opacity: 0, transform: 'scale(0.3)', offset: 0.38 },
        { opacity: 1, transform: 'scale(0.6)', offset: 0.42 },
        { opacity: 0, transform: 'scale(1.5)', offset: 0.85 },
        { opacity: 0, transform: 'scale(1.5)', offset: 1 },
      ];
    } else if (g === 'hold') {
      frames = [
        { transform: at(a.x, a.y, 18), opacity: 0, offset: 0 },
        { transform: at(a.x, a.y, 0, 0.92), opacity: 1, offset: 0.15 },
        { transform: at(a.x, a.y, 0, 0.92), opacity: 1, offset: 0.75 },
        { transform: at(a.x, a.y, 14), opacity: 0, offset: 1 },
      ];
      ringFrames = [
        { opacity: 0, transform: 'scale(0.3)', offset: 0 },
        { opacity: 1, transform: 'scale(0.4)', offset: 0.15 },
        { opacity: 1, transform: 'scale(1.3)', offset: 0.75 },
        { opacity: 0, transform: 'scale(1.3)', offset: 0.9 },
        { opacity: 0, transform: 'scale(1.3)', offset: 1 },
      ];
    } else {
      // A swipe is quick and lifts at the end; a drag presses, carries, lets go
      const go = g === 'swipe' ? 0.5 : 0.62;
      frames = [
        { transform: at(a.x, a.y, 16), opacity: 0, offset: 0 },
        { transform: at(a.x, a.y, 0, 0.92), opacity: 1, offset: 0.15 },
        { transform: at(a.x, a.y, 0, 0.92), opacity: 1, offset: g === 'drag' ? 0.25 : 0.18, easing: 'ease-in-out' },
        { transform: at(b!.x, b!.y, 0, 0.92), opacity: 1, offset: go },
        { transform: at(b!.x, b!.y, 12), opacity: 1, offset: go + 0.12 },
        { transform: at(b!.x, b!.y, 14), opacity: 0, offset: 1 },
      ];
      ringFrames = [
        { opacity: 0, transform: 'scale(0.4)', offset: 0 },
        { opacity: 0.9, transform: 'scale(0.6)', offset: 0.16 },
        { opacity: 0, transform: 'scale(1.2)', offset: 0.4 },
        { opacity: 0, transform: 'scale(1.2)', offset: 1 },
      ];
    }
    const h = hand.animate(frames, { duration: ms, easing: 'linear', fill: 'both' });
    anims = [h, ring.animate(ringFrames, { duration: ms, fill: 'both' })];
    h.onfinish = () => alive && visible && loop();
  };

  const api: CoachHand = {
    el: layer,
    show(more) {
      if (!alive) return;
      if (more) o = { ...o, ...more };
      setSprite();
      visible = true;
      layer.hidden = false;
      loop();
    },
    hide() {
      visible = false;
      stop();
      layer.hidden = true;
    },
    get visible() {
      return visible;
    },
    destroy() {
      alive = false;
      api.hide();
      layer.remove();
    },
  };
  api.show();
  return api;
}
