// The restock countdown: a small pill "New stock in 3:12" that ticks every second and says when a restock arrived. It
// is a DOM element the game places itself (on the shop panel, over the canvas, on the title), in the player's language
// (gp.restock.*), and it never says what was missed (D56): what is coming, not what passed.
//
//   const timer = mountRestockTimer(panel, shop, { host, onRestock: () => drawShop() });
//   // the "Restock now" offer beside it is a rewardedButton({ placement: 'restock', … onReward: () => shop.restockNow() })
//   timer.destroy();      // when the panel closes
//
// Themeable: --gp-restock-bg, -ink, -accent, -radius, -font on .gp-restock — each falls back to the game's theme
// variables (--gp-theme-panel, --gp-theme-ink, --gp-theme-accent, --gp-theme-radius, --gp-theme-font) and then to
// the platform's defaults, so a game that sets its theme once gets a timer in its colours.

import { formatClock } from './clock.ts';
import type { GameHost } from './host.ts';
import { FONT_FALLBACK } from './i18n.ts';
import type { RestockShop } from './restock.ts';

export interface RestockTimerOptions {
  host: Pick<GameHost, 't'>;
  /** A new stock arrived (the slot turned, or the player's own restock): redraw the shop */
  onRestock?: () => void;
  /** The line (default: the platform's gp.restock.in, gp.restock.own for the player's own stock) */
  text?: (time: string, personal: boolean) => string;
  /** How often it ticks, ms (default 1000) */
  tickMs?: number;
}

export interface RestockTimer {
  el: HTMLElement;
  /** Read the shop again now (after a restockNow(), say) */
  update(): void;
  destroy(): void;
}

const CSS = `
:where(.gp-restock) { --gp-restock-bg: var(--gp-theme-panel, rgba(16, 24, 38, 0.82)); --gp-restock-ink: var(--gp-theme-ink, #f2f7ff);
  --gp-restock-accent: var(--gp-theme-accent, #ffd166); --gp-restock-radius: var(--gp-theme-radius, 999px);
  --gp-restock-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
.gp-restock { display: inline-block; vertical-align: middle; box-sizing: border-box; max-width: 100%; padding: 4px 12px;
  border-radius: var(--gp-restock-radius); background: var(--gp-restock-bg); color: var(--gp-restock-ink);
  font: 700 14px/1.25 var(--gp-restock-font); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.gp-restock b { color: var(--gp-restock-accent); font-variant-numeric: tabular-nums; font-weight: 800; }
.gp-restock[data-fresh] { animation: gp-restock-pop 0.6s ease-out; }
@keyframes gp-restock-pop { 0% { transform: scale(1.18); } 100% { transform: scale(1); } }
@media (prefers-reduced-motion: reduce) { .gp-restock[data-fresh] { animation: none; } }
`;

/** The countdown pill in `root`: ticks every second, calls onRestock when the stock turns over */
export function mountRestockTimer(root: HTMLElement, shop: RestockShop, opts: RestockTimerOptions): RestockTimer {
  if (!document.getElementById('gp-restock-css')) {
    const style = document.createElement('style');
    style.id = 'gp-restock-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  const el = document.createElement('div');
  el.className = 'gp-restock';
  el.dataset.gp = 'restock-timer';
  el.setAttribute('role', 'timer');
  el.setAttribute('aria-live', 'off');
  const line = opts.text ?? ((time: string, own: boolean) => opts.host.t(own ? 'gp.restock.own' : 'gp.restock.in', { time }));
  // The time in <b> (accent, tabular digits), the words around it as the language puts them; the nodes stay, their text changes
  const before = document.createTextNode('');
  const b = document.createElement('b');
  const after = document.createTextNode('');
  el.append(before, b, after);
  let last = '';
  const update = () => {
    const s = shop.state();
    const id = `${s.slot.index}:${shop.log.own}`;
    const [head, tail = ''] = line('\u0000', s.personal).split('\u0000');
    if (before.nodeValue !== head) before.nodeValue = head;
    if (after.nodeValue !== tail) after.nodeValue = tail;
    b.textContent = formatClock(s.nextIn);
    if (last && id !== last) {
      el.removeAttribute('data-fresh');
      void el.offsetWidth; // restart the pop
      el.setAttribute('data-fresh', '');
      opts.onRestock?.();
    }
    last = id;
  };
  update();
  root.append(el);
  const timer = setInterval(update, Math.max(200, opts.tickMs ?? 1000));
  return {
    el,
    update,
    destroy() {
      clearInterval(timer);
      el.remove();
    },
  };
}
