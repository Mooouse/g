// Drawing helpers shared by every game: outlined text, emoji, panels, icon buttons, stars, particles, easing.
// Everything is drawn in code. Themes cache heavy parts in offscreen canvases (offscreen() below) and
// drop the caches when the pixel density changes (onRenderScaleChange).

// Roboto ships with every Android device; other platforms fall back to the system font
export const FONT = 'Roboto, system-ui, "Noto Sans", "Segoe UI", Arial, sans-serif';
export const EMOJI_FONT = '"Noto Color Emoji", "Apple Color Emoji", "Segoe UI Emoji", sans-serif';

import { rng } from './rng';

let dpr = 1;
const scaleListeners = new Set<(dprChanged: boolean) => void>();

/** Called by the app when screen size or pixel density changes */
export function setRenderScale(scale: number): void {
  const changed = scale !== dpr;
  dpr = scale;
  for (const l of scaleListeners) l(changed);
}

/** Current canvas pixel density */
export function renderScale(): number {
  return dpr;
}

/** Themes register their cache reset here: screen-sized caches on every call, pixel-density ones when dprChanged */
export function onRenderScaleChange(listener: (dprChanged: boolean) => void): void {
  scaleListeners.add(listener);
}

/** An offscreen canvas at the current pixel density, with the context already scaled */
export function offscreen(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.ceil(w * dpr));
  c.height = Math.max(1, Math.ceil(h * dpr));
  const ctx = c.getContext('2d')!;
  ctx.scale(dpr, dpr);
  return [c, ctx];
}

// --- Color -----------------------------------------------------------------------------------

export function parseHex(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/** Lighten (amt > 0) or darken (amt < 0) a #rrggbb color */
export function shade(hex: string, amt: number): string {
  const [r, g, b] = parseHex(hex);
  const f = (c: number) => Math.round(amt >= 0 ? c + (255 - c) * amt : c * (1 + amt));
  return `rgb(${f(r)}, ${f(g)}, ${f(b)})`;
}

// --- Text and emoji ----------------------------------------------------------------------

/** Outlined text — readable on any background */
export function drawText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  size: number,
  fill = '#ffffff',
  outline: string | null = '#2a5d9c',
  weight = 800,
): void {
  ctx.font = `${weight} ${Math.round(size)}px ${FONT}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  if (outline) {
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(2, size * 0.16);
    ctx.strokeStyle = outline;
    ctx.strokeText(text, x, y);
  }
  ctx.fillStyle = fill;
  ctx.fillText(text, x, y);
}

/** Shrinks the font size until the text fits the width */
export function fitTextSize(ctx: CanvasRenderingContext2D, text: string, size: number, maxWidth: number, weight = 800): number {
  ctx.font = `${weight} ${Math.round(size)}px ${FONT}`;
  const w = ctx.measureText(text).width;
  return w > maxWidth ? Math.max(8, size * (maxWidth / w)) : size;
}

export function drawEmoji(ctx: CanvasRenderingContext2D, emoji: string, x: number, y: number, size: number): void {
  ctx.font = `${Math.round(size)}px ${EMOJI_FONT}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#000';
  // Emoji visually sit slightly above the line center
  ctx.fillText(emoji, x, y + size * 0.06);
}

// --- Shapes and buttons ---------------------------------------------------------------------

export function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  // A degenerate box (the WebView can collapse for a frame during Android activity switches) draws nothing:
  // arcTo throws on a negative radius and would kill the frame
  const rr = Math.max(0, Math.min(r, w / 2, h / 2));
  if (!(w > 0 && h > 0)) {
    ctx.beginPath();
    return;
  }
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

/** Card/button with a "shadow" drawn as an offset shape, without costly shadowBlur */
export function drawPanel(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  fill: string,
  shadow = 'rgba(20, 70, 130, 0.22)',
): void {
  if (!(w > 0 && h > 0)) return;
  const d = Math.max(3, Math.min(w, h) * 0.04);
  ctx.fillStyle = shadow;
  roundRect(ctx, x, y + d, w, h, r);
  ctx.fill();
  ctx.fillStyle = fill;
  roundRect(ctx, x, y, w, h, r);
  ctx.fill();
}

export function starPath(ctx: CanvasRenderingContext2D, x: number, y: number, r: number): void {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? r : r * 0.48;
    const px = x + Math.cos(a) * rad;
    const py = y + Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

export function drawStar(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, filled: boolean): void {
  starPath(ctx, x, y, r);
  ctx.lineJoin = 'round';
  ctx.lineWidth = Math.max(2, r * 0.12);
  if (filled) {
    const g = ctx.createRadialGradient(x - r * 0.2, y - r * 0.3, r * 0.1, x, y, r);
    g.addColorStop(0, '#fff3a0');
    g.addColorStop(1, '#ffc21a');
    ctx.fillStyle = g;
    ctx.strokeStyle = '#e59a00';
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
  }
  ctx.fill();
  ctx.stroke();
}

export type IconName = 'home' | 'next' | 'album' | 'lock' | 'back';

function drawIcon(ctx: CanvasRenderingContext2D, icon: IconName, x: number, y: number, s: number, color: string): void {
  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  switch (icon) {
    case 'home': {
      ctx.lineWidth = s * 0.14;
      ctx.beginPath();
      ctx.moveTo(x - s * 0.62, y - s * 0.02);
      ctx.lineTo(x, y - s * 0.58);
      ctx.lineTo(x + s * 0.62, y - s * 0.02);
      ctx.stroke();
      roundRect(ctx, x - s * 0.42, y - s * 0.12, s * 0.84, s * 0.66, s * 0.08);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      roundRect(ctx, x - s * 0.12, y + s * 0.18, s * 0.24, s * 0.36, s * 0.06);
      ctx.fill();
      break;
    }
    case 'next': {
      ctx.lineWidth = s * 0.12;
      ctx.beginPath();
      ctx.moveTo(x - s * 0.3, y - s * 0.5);
      ctx.lineTo(x + s * 0.5, y);
      ctx.lineTo(x - s * 0.3, y + s * 0.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      break;
    }
    case 'back': {
      ctx.lineWidth = s * 0.18;
      ctx.beginPath();
      ctx.moveTo(x + s * 0.1, y - s * 0.45);
      ctx.lineTo(x - s * 0.35, y);
      ctx.lineTo(x + s * 0.1, y + s * 0.45);
      ctx.moveTo(x - s * 0.3, y);
      ctx.lineTo(x + s * 0.5, y);
      ctx.stroke();
      break;
    }
    case 'album': {
      roundRect(ctx, x - s * 0.5, y - s * 0.55, s * 1.0, s * 1.1, s * 0.12);
      ctx.fill();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.fillRect(x - s * 0.38, y - s * 0.55, s * 0.08, s * 1.1);
      starPath(ctx, x + s * 0.06, y, s * 0.3);
      ctx.fillStyle = '#ffd21f';
      ctx.fill();
      break;
    }
    case 'lock': {
      ctx.lineWidth = s * 0.14;
      ctx.beginPath();
      ctx.arc(x, y - s * 0.12, s * 0.28, Math.PI, 0);
      ctx.lineTo(x + s * 0.28, y + s * 0.05);
      ctx.moveTo(x - s * 0.28, y + s * 0.05);
      ctx.lineTo(x - s * 0.28, y - s * 0.12);
      ctx.stroke();
      roundRect(ctx, x - s * 0.44, y - s * 0.02, s * 0.88, s * 0.62, s * 0.1);
      ctx.fill();
      break;
    }
  }
}

/** Round icon button. scale is for the springy appear animation */
export function drawIconButton(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  icon: IconName,
  opts: { fill?: string; icon?: string; shadow?: string; scale?: number } = {},
): void {
  const s = opts.scale ?? 1;
  if (s <= 0.01) return;
  const rr = r * s;
  ctx.fillStyle = opts.shadow ?? 'rgba(20, 70, 130, 0.22)';
  ctx.beginPath();
  ctx.arc(x, y + rr * 0.08, rr, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = opts.fill ?? '#ffffff';
  ctx.beginPath();
  ctx.arc(x, y, rr, 0, Math.PI * 2);
  ctx.fill();
  drawIcon(ctx, icon, x, y, rr * 0.62, opts.icon ?? '#2f7bd9');
}

/** Icon without a background (e.g. the grey parent lock) */
export function drawBareIcon(ctx: CanvasRenderingContext2D, icon: IconName, x: number, y: number, s: number, color: string): void {
  drawIcon(ctx, icon, x, y, s, color);
}

// --- Confetti and fireworks --------------------------------------------------------------------

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  vr: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  dot: boolean;
  gravity: number;
  drag: number;
}

const MAX_PARTICLES = 500;

export class Particles {
  private list: Particle[] = [];

  get count(): number {
    return this.list.length;
  }

  clear(): void {
    this.list.length = 0;
  }

  /** Confetti from a point — a balloon pop */
  confetti(x: number, y: number, colors: readonly string[], count: number, speed: number): void {
    for (let i = 0; i < count; i++) {
      const a = rng.random() * Math.PI * 2;
      const v = speed * (0.35 + rng.random() * 0.65);
      this.add({
        x,
        y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v - speed * 0.35,
        rot: rng.random() * Math.PI,
        vr: (rng.random() - 0.5) * 14,
        size: speed * (0.034 + rng.random() * 0.026),
        color: colors[(rng.random() * colors.length) | 0],
        life: 0,
        maxLife: 0.9 + rng.random() * 0.6,
        dot: false,
        gravity: speed * 1.6,
        drag: 2.2,
      });
    }
  }

  /** Soft firework: a ring of glowing dots */
  burst(x: number, y: number, color: string, count: number, speed: number): void {
    for (let i = 0; i < count; i++) {
      const a = (i / count) * Math.PI * 2 + rng.random() * 0.2;
      const v = speed * (0.75 + rng.random() * 0.25);
      this.add({
        x,
        y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v,
        rot: 0,
        vr: 0,
        size: speed * 0.022,
        color,
        life: 0,
        maxLife: 0.9 + rng.random() * 0.3,
        dot: true,
        gravity: speed * 0.5,
        drag: 1.6,
      });
    }
  }

  /** Confetti falling from the top ("Well done!" screen) */
  rain(w: number, colors: readonly string[], count: number, size: number): void {
    for (let i = 0; i < count; i++) {
      this.add({
        x: rng.random() * w,
        y: -size * (1 + rng.random() * 6),
        vx: (rng.random() - 0.5) * size * 2,
        vy: size * (4 + rng.random() * 3),
        rot: rng.random() * Math.PI,
        vr: (rng.random() - 0.5) * 8,
        size: size * (0.7 + rng.random() * 0.6),
        color: colors[(rng.random() * colors.length) | 0],
        life: 0,
        maxLife: 6,
        dot: false,
        gravity: 0,
        drag: 0,
      });
    }
  }

  private add(p: Particle): void {
    if (this.list.length >= MAX_PARTICLES) this.list.shift();
    this.list.push(p);
  }

  update(dt: number, h: number): void {
    const list = this.list;
    let j = 0;
    for (let i = 0; i < list.length; i++) {
      const p = list[i];
      p.life += dt;
      const k = Math.max(0, 1 - p.drag * dt);
      p.vx *= k;
      p.vy = p.vy * k + p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      if (p.life < p.maxLife && p.y < h + 40) list[j++] = p;
    }
    list.length = j;
  }

  draw(ctx: CanvasRenderingContext2D): void {
    for (const p of this.list) {
      const fade = Math.min(1, (p.maxLife - p.life) / 0.35);
      ctx.globalAlpha = Math.max(0, fade);
      ctx.fillStyle = p.color;
      if (p.dot) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Fake rotation by squeezing the width — cheaper than setTransform per particle
        const w = p.size * Math.abs(Math.cos(p.rot)) + 1;
        ctx.fillRect(p.x - w / 2, p.y - p.size * 0.35, w, p.size * 0.7);
      }
    }
    ctx.globalAlpha = 1;
  }
}

/** Springy appear: 0 → a bit over 1 → 1 */
export function easeOutBack(t: number): number {
  const c = 1.9;
  const x = Math.min(1, Math.max(0, t)) - 1;
  return 1 + (c + 1) * x * x * x + c * x * x;
}
