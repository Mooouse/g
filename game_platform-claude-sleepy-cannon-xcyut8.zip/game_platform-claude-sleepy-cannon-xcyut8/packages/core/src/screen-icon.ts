// How the platform's screens show a game's icon (an upgrade, a site, a reward, the currency): a drawn one (an element
// from icon() of @gp/core/icons, iconImg() of @gp/art/dom, a canvas), a function that makes one, an image URL, or text
// (an emoji — the old way, still read). The platform's own marks are drawn icons (DEFAULT_CURRENCY: a gold coin).

import { icon } from './icons.ts';

/** An icon a game gives a platform screen: an element, a function that makes one, an image URL, or text (an emoji) */
export type ScreenIcon = string | Element | (() => Node);

/** An image URL rather than an emoji or a word: a scheme, a path, or an image file name */
const IMAGE_URL = /^(?:data:image\/|blob:|https?:\/\/|\.{0,2}\/)|\.(?:png|svg|webp|avif|gif|jpe?g)(?:[?#].*)?$/i;

/** The platform's coin, where a game gave no currency icon */
export const DEFAULT_CURRENCY = (): Node => icon('coin', { style: 'solid', color: '#ffc93c', className: 'gp-cur' });

/**
 * The icon's node: an element as given (a copy when it is on screen already: a currency shows in several places, a
 * canvas copy gets its pixels), a function's node, an <img> for an image URL, else text
 */
export function screenIcon(i: ScreenIcon): Node {
  if (typeof i === 'function') return i();
  if (typeof i !== 'string') {
    if (!i.isConnected) return i;
    const copy = i.cloneNode(true) as Element;
    if (i instanceof HTMLCanvasElement && copy instanceof HTMLCanvasElement && i.width && i.height) copy.getContext('2d')?.drawImage(i, 0, 0);
    return copy;
  }
  if (!IMAGE_URL.test(i.trim())) return document.createTextNode(i);
  const img = document.createElement('img');
  img.src = i.trim();
  img.alt = '';
  img.decoding = 'async';
  img.className = 'gp-cur';
  return img;
}

/** A token for "the icon goes here" inside a translated string ("Claim {reward}" with reward = `${ICON_AT} 150`) */
export const ICON_AT = '\uE000';

/** Put `text` into `el`, each ICON_AT replaced by the icon (text icons stay text: the old look) */
export function setIconText(el: Element, text: string, i: ScreenIcon | null): void {
  if (!i) {
    el.textContent = text.split(ICON_AT).join('').replace(/\s{2,}/g, ' ').trim();
    return;
  }
  const parts = text.split(ICON_AT);
  const out: Node[] = [];
  parts.forEach((p, k) => {
    if (k) {
      const node = screenIcon(i);
      // The same element twice in one line: the second is a copy
      out.push(out.includes(node) ? node.cloneNode(true) : node);
    }
    if (p) out.push(document.createTextNode(p));
  });
  el.replaceChildren(...out);
}
