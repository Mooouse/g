// The daily rewards hub: playtime gifts, a lucky wheel, the day's offers and a timed boost — the meta of the genre's
// hits (the mining simulators' gifts for the minutes played, a free spin a day, Idle Miner's three new offers a day) that
// Craft Pickaxe Idle wrote by hand (meta.ts), with the bugs its code review and its quality review found fixed here once:
// a wheel prize lost on a reload mid-spin, the prize spoiled before the wheel stopped, the ad spin offered before the
// free one, a bought ×2 boost doubling the offline earnings. Any genre (idle and simulators most). Pure logic over
// fields of the game's own save, an injected clock (`now`) and randomness (`rand`); the screen is mountRewardsHub()
// (rewards-ui.ts).
//
//   const gifts = playtimeGifts(save, { gifts: [{ min: 1, reward: { coins: 50 } }, { min: 5, reward: { gems: 5 } }], persist });
//   // in the loop while the player plays: gifts.tick(dt)   — today's minutes, kept across sessions with the save
//   const wheel = luckyWheel(save, { slices: [{ reward: 50, weight: 30 }, { reward: 500, weight: 5 }, …], free: 1, ad: 1, persist });
//   const spun = wheel.spin('free');                // the prize is decided and SAVED now …
//   // … the wheel turns to spun.slice; when it stops: pay(wheel.collect())  (a reload before that keeps it pending)
//   const offers = dailyOffers(save, { pool, perDay: 3, firstFree: true, salt: 'my-game', persist });
//   const boost = timedBoost(save, { factor: 2, persist });   // income × boost.factor() — the time away never ×2
//
// Nothing is taken away (D56): a gift reached and not taken when the day turns is kept (carried), a pending wheel prize
// stays until collected, a boost's time left stays.

import { dayKey } from './daily.ts';
import { dayShuffle } from './goals.ts';
import { inOfflineMeasure } from './offline.ts';
import type { SaveHolder } from './streak.ts';

const KEY = /^\d{4}-\d{2}-\d{2}$/;
const isKey = (v: unknown): v is string => typeof v === 'string' && KEY.test(v);
const num = (v: unknown, min: number, max: number, dflt: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : dflt;
};
const int = (v: unknown, min: number, max: number, dflt: number) => Math.floor(num(v, min, max, dflt));
const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

interface Clocked {
  /** The clock, in ms (default Date.now): inject one in tests and bots */
  now?: () => number;
  /** Days turn over at the player's own midnight (default true); false: at 00:00 UTC */
  local?: boolean;
  /** Called after a change that must not be lost (a claim, a spin, a new day): `() => host.save(save)` */
  persist?: () => void;
  /** The save field */
  key?: string;
}
const today = (o: Clocked) => dayKey(new Date((o.now ?? Date.now)()), { local: o.local ?? true });

// --- Playtime gifts ------------------------------------------------------------------------------------------------

export interface GiftDef<R> {
  /** Minutes of play (today's, or in all with reset: 'never') */
  min: number;
  reward: R;
}

/** What the gifts keep in the save (`save.gifts` by default) */
export interface GiftLog {
  day: string;
  /** Seconds played (today, or in all) */
  played: number;
  /** The gifts taken (their indices) */
  taken: number[];
  /** Reached on an earlier day and not taken: still the player's */
  carry: number[];
}

export interface GiftsOptions<R> extends Clocked {
  /** In order of their minutes */
  gifts: readonly GiftDef<R>[];
  /** 'daily' (default): the minutes and the gifts start again each day; 'never': one ladder for good */
  reset?: 'daily' | 'never';
}

export interface GiftRow<R> {
  index: number;
  min: number;
  reward: R;
  state: 'taken' | 'ready' | 'locked';
  /** Seconds of play still to go (0 when reached) */
  inSec: number;
}

export interface GiftsState<R> {
  played: number;
  gifts: GiftRow<R>[];
  /** Ready now (today's and carried) */
  ready: number;
  /** The next gift to reach */
  next: { index: number; inSec: number } | null;
  carried: { index: number; reward: R }[];
}

export interface PlaytimeGifts<R> {
  /**
   * Seconds played (call it from the loop while the player plays: menus and pauses don't count). Counted in memory,
   * saved with the game's next save; saved at once when a gift is reached. The indices just reached
   */
  tick(sec: number): number[];
  state(): GiftsState<R>;
  /** Take a reached gift, once: its reward, or null */
  take(index: number): R | null;
  /** Every reached gift (and the carried ones) */
  takeAll(): { index: number; reward: R }[];
  readonly log: GiftLog;
}

export function loadGifts(saved: unknown, count: number): GiftLog {
  const s = record(saved);
  const valid = (v: unknown) => (Array.isArray(v) ? v.filter((i): i is number => Number.isInteger(i) && i >= 0 && i < count) : []);
  // Taken: each once; carried: one entry per day it was left (two days' first gift are two gifts)
  return { day: isKey(s.day) ? s.day : '', played: num(s.played, 0, 1e9, 0), taken: [...new Set(valid(s.taken))].sort((a, b) => a - b), carry: valid(s.carry).slice(-100) };
}

export function playtimeGifts<R>(save: SaveHolder, opts: GiftsOptions<R>): PlaytimeGifts<R> {
  const gifts = opts.gifts;
  for (let i = 1; i < gifts.length; i++) if (!(gifts[i].min >= gifts[i - 1].min)) throw new Error('playtimeGifts: list the gifts in order of their minutes');
  const key = opts.key ?? 'gifts';
  const holder = save as Record<string, unknown>;
  const log = loadGifts(holder[key], gifts.length);
  holder[key] = log;
  const persist = () => opts.persist?.();
  const daily = (opts.reset ?? 'daily') === 'daily';
  const reached = (i: number) => log.played >= gifts[i].min * 60;

  const refresh = () => {
    const t = today(opts);
    if (log.day === t) return;
    if (daily && log.day && t > log.day) {
      for (let i = 0; i < gifts.length; i++) if (reached(i) && !log.taken.includes(i)) log.carry.push(i);
      log.carry = log.carry.slice(-100);
      log.played = 0;
      log.taken = [];
    }
    log.day = t;
    persist();
  };
  refresh();

  const api: PlaytimeGifts<R> = {
    log,
    tick(sec) {
      refresh();
      if (!(sec > 0) || !Number.isFinite(sec)) return [];
      const before = gifts.map((_, i) => reached(i));
      log.played = Math.min(1e9, log.played + Math.min(sec, 3600));
      const fresh = gifts.map((_, i) => i).filter((i) => !before[i] && reached(i) && !log.taken.includes(i));
      if (fresh.length) persist();
      return fresh;
    },
    state() {
      refresh();
      const rows = gifts.map((g, i): GiftRow<R> => ({
        index: i,
        min: g.min,
        reward: g.reward,
        state: log.taken.includes(i) ? 'taken' : reached(i) ? 'ready' : 'locked',
        inSec: Math.max(0, g.min * 60 - log.played),
      }));
      const nextRow = rows.find((r) => r.state === 'locked');
      const carried = log.carry.map((i) => ({ index: i, reward: gifts[i].reward }));
      return { played: log.played, gifts: rows, ready: rows.filter((r) => r.state === 'ready').length + carried.length, next: nextRow ? { index: nextRow.index, inSec: nextRow.inSec } : null, carried };
    },
    take(i) {
      refresh();
      if (!gifts[i] || log.taken.includes(i) || !reached(i)) return null;
      log.taken.push(i);
      persist();
      return gifts[i].reward;
    },
    takeAll() {
      refresh();
      const out = log.carry.map((i) => ({ index: i, reward: gifts[i].reward }));
      log.carry = [];
      for (let i = 0; i < gifts.length; i++)
        if (reached(i) && !log.taken.includes(i)) {
          log.taken.push(i);
          out.push({ index: i, reward: gifts[i].reward });
        }
      if (out.length) persist();
      return out;
    },
  };
  return api;
}

// --- The lucky wheel -------------------------------------------------------------------------------------------------

export interface WheelSlice<R> {
  reward: R;
  /** Its chance against the others (default 1) */
  weight?: number;
}

export type SpinKind = 'free' | 'ad' | 'paid';

/** What the wheel keeps in the save (`save.wheel` by default) */
export interface WheelLog {
  day: string;
  /** Spins used today: free and for an ad */
  free: number;
  ad: number;
  /** The prize decided at the spin and not yet collected (survives a reload mid-spin) */
  pending: { slice: number; how: SpinKind; at: number } | null;
  /** Spins in all */
  total: number;
}

export interface WheelOptions<R> extends Clocked {
  slices: readonly WheelSlice<R>[];
  /** Free spins a day (default 1) */
  free?: number;
  /** Spins for a rewarded ad a day, offered only once the free ones are used (default 1; 0: none) */
  ad?: number;
  /** A spin for the game's currency: its price, and pay() that takes it (true: paid) */
  paid?: { price: number; pay(price: number): boolean };
  /** Randomness in [0, 1) (default Math.random; the run's rng.random in a game) */
  rand?: () => number;
}

export interface WheelState<R> {
  slices: { index: number; reward: R; weight: number; share: number }[];
  freeLeft: number;
  adLeft: number;
  /** A free spin now */
  canFree: boolean;
  /** An ad spin now: the free ones used today, ad spins left, nothing pending */
  canAd: boolean;
  /** A paid spin now (its price; the game's pay() decides) */
  canPaid: boolean;
  price: number | null;
  /** A prize spun and not collected: show the wheel stopped on it, then collect() */
  pending: { slice: number; reward: R; how: SpinKind } | null;
}

export interface LuckyWheel<R> {
  state(): WheelState<R>;
  /** Spin: the slice is decided and saved now (pending); null when this spin isn't allowed now or one is pending */
  spin(how: SpinKind, rand?: () => number): { slice: number; reward: R } | null;
  /** The wheel stopped: the pending prize, paid once (null: none). Saved at once */
  collect(): { slice: number; reward: R; how: SpinKind } | null;
  readonly log: WheelLog;
}

export function loadWheel(saved: unknown, slices: number): WheelLog {
  const s = record(saved);
  const p = record(s.pending);
  const how = p.how === 'free' || p.how === 'ad' || p.how === 'paid' ? p.how : null;
  const slice = Number(p.slice);
  return {
    day: isKey(s.day) ? s.day : '',
    free: int(s.free, 0, 100, 0),
    ad: int(s.ad, 0, 100, 0),
    pending: how && Number.isInteger(slice) && slice >= 0 && slice < slices ? { slice, how, at: int(p.at, 0, Number.MAX_SAFE_INTEGER, 0) } : null,
    total: int(s.total, 0, Number.MAX_SAFE_INTEGER, 0),
  };
}

export function luckyWheel<R>(save: SaveHolder, opts: WheelOptions<R>): LuckyWheel<R> {
  if (opts.slices.length < 2) throw new Error('luckyWheel: two slices or more');
  const weights = opts.slices.map((s) => num(s.weight ?? 1, 0, 1e9, 1));
  const sum = weights.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new Error('luckyWheel: the weights add up to 0');
  const key = opts.key ?? 'wheel';
  const holder = save as Record<string, unknown>;
  const log = loadWheel(holder[key], opts.slices.length);
  holder[key] = log;
  const persist = () => opts.persist?.();
  const freeMax = int(opts.free ?? 1, 0, 100, 1);
  const adMax = int(opts.ad ?? 1, 0, 100, 1);
  const clock = opts.now ?? Date.now;

  const refresh = () => {
    const t = today(opts);
    if (log.day === t) return;
    // A new day: the spins come back (a pending prize stays: it is the player's)
    log.day = t;
    log.free = 0;
    log.ad = 0;
    persist();
  };
  refresh();

  const state = (): WheelState<R> => {
    refresh();
    const freeLeft = Math.max(0, freeMax - log.free);
    const adLeft = Math.max(0, adMax - log.ad);
    return {
      slices: opts.slices.map((s, i) => ({ index: i, reward: s.reward, weight: weights[i], share: weights[i] / sum })),
      freeLeft,
      adLeft,
      canFree: !log.pending && freeLeft > 0,
      canAd: !log.pending && freeLeft === 0 && adLeft > 0,
      canPaid: !log.pending && !!opts.paid,
      price: opts.paid ? opts.paid.price : null,
      pending: log.pending ? { slice: log.pending.slice, reward: opts.slices[log.pending.slice].reward, how: log.pending.how } : null,
    };
  };

  return {
    log,
    state,
    spin(how, rand) {
      const s = state();
      if (how === 'free' ? !s.canFree : how === 'ad' ? !s.canAd : !s.canPaid) return null;
      if (how === 'paid' && !opts.paid!.pay(opts.paid!.price)) return null;
      if (how === 'free') log.free++;
      else if (how === 'ad') log.ad++;
      const r = (rand ?? opts.rand ?? Math.random)();
      let x = (Number.isFinite(r) ? Math.max(0, Math.min(0.999999, r)) : 0) * sum;
      let slice = opts.slices.length - 1;
      for (let i = 0; i < weights.length; i++) {
        x -= weights[i];
        if (x < 0) {
          slice = i;
          break;
        }
      }
      log.pending = { slice, how, at: clock() };
      log.total++;
      persist();
      return { slice, reward: opts.slices[slice].reward };
    },
    collect() {
      const p = log.pending;
      if (!p) return null;
      log.pending = null;
      persist();
      return { slice: p.slice, reward: opts.slices[p.slice].reward, how: p.how };
    },
  };
}

// --- The day's offers --------------------------------------------------------------------------------------------------

export interface OfferDef<R> {
  id: string;
  /** In the game's currency */
  price: number;
  reward: R;
}

/** What the offers keep in the save (`save.offers` by default) */
export interface OfferLog {
  day: string;
  /** Today's offers from the pool (ids) */
  list: string[];
  /** Today's offers bought (each once a day) */
  bought: string[];
  /** The day's first offer was taken free */
  free: boolean;
  /** Rewarded-ad currency taken today */
  ad: number;
}

export interface OffersOptions<R> extends Clocked {
  /** The pool the day's offers come from */
  pool: readonly OfferDef<R>[];
  /** Offers a day from the pool (default 3) */
  perDay?: number;
  /** Always there, bought any number of times */
  fixed?: readonly OfferDef<R>[];
  /** The first of the day's offers is free, once a day (default true): a reason to open the shop daily */
  firstFree?: boolean;
  /** The game's id (daySeed's salt) */
  salt?: string;
  /** Currency for a rewarded ad (the 'currency' kind in money.ts): what it gives and how often a day (default 3) */
  ad?: { reward: R; perDay?: number } | null;
}

export interface OfferRow<R> {
  id: string;
  /** What it costs now (0: the free one) */
  price: number;
  basePrice: number;
  reward: R;
  /** One of the day's (else fixed) */
  daily: boolean;
  /** A daily one bought today */
  bought: boolean;
  free: boolean;
}

export interface OffersState<R> {
  day: string;
  offers: OfferRow<R>[];
  ad: { reward: R; left: number } | null;
}

export interface DailyOffers<R> {
  state(): OffersState<R>;
  /** Buy: `pay(price)` takes the currency (true: paid; not called for the free one). The reward, or null */
  buy(id: string, pay: (price: number) => boolean): R | null;
  /** After a rewarded ad: the currency, once per allowed view (null: none left today) */
  adClaim(): R | null;
  readonly log: OfferLog;
}

export function loadOffers(saved: unknown): OfferLog {
  const s = record(saved);
  const strs = (v: unknown) => (Array.isArray(v) ? [...new Set(v.filter((x): x is string => typeof x === 'string'))].slice(0, 50) : []);
  return { day: isKey(s.day) ? s.day : '', list: strs(s.list), bought: strs(s.bought), free: s.free === true, ad: int(s.ad, 0, 100, 0) };
}

export function dailyOffers<R>(save: SaveHolder, opts: OffersOptions<R>): DailyOffers<R> {
  const perDay = int(opts.perDay ?? 3, 1, 12, 3);
  if (opts.pool.length < perDay) throw new Error(`dailyOffers: the pool has ${opts.pool.length} offer(s), a day takes ${perDay}`);
  const all = [...(opts.fixed ?? []), ...opts.pool];
  if (new Set(all.map((o) => o.id)).size !== all.length) throw new Error('dailyOffers: an offer id twice (pool and fixed together)');
  const key = opts.key ?? 'offers';
  const holder = save as Record<string, unknown>;
  const log = loadOffers(holder[key]);
  holder[key] = log;
  const persist = () => opts.persist?.();
  const pool = new Map(opts.pool.map((o) => [o.id, o]));
  const fixed = new Map((opts.fixed ?? []).map((o) => [o.id, o]));
  const firstFree = opts.firstFree ?? true;
  const adMax = opts.ad ? int(opts.ad.perDay ?? 3, 0, 100, 3) : 0;

  const draw = (day: string) => dayShuffle(opts.pool.map((o) => o.id), day, `${opts.salt ?? ''}:offers`).slice(0, perDay);
  const refresh = (): string => {
    const t = today(opts);
    if (log.day !== t || log.list.length !== perDay || log.list.some((id) => !pool.has(id))) {
      const same = log.day === t;
      log.list = draw(t);
      if (!same) Object.assign(log, { day: t, bought: [], free: false, ad: 0 });
      persist();
    }
    return t;
  };
  refresh();
  const priceOf = (o: OfferDef<R>, daily: boolean) => (daily && firstFree && !log.free && log.list[0] === o.id && !log.bought.includes(o.id) ? 0 : Math.max(0, o.price));

  return {
    log,
    state() {
      const day = refresh();
      const rows: OfferRow<R>[] = [
        ...[...fixed.values()].map((o) => ({ id: o.id, price: Math.max(0, o.price), basePrice: o.price, reward: o.reward, daily: false, bought: false, free: false })),
        ...log.list.map((id) => {
          const o = pool.get(id)!;
          const price = priceOf(o, true);
          return { id, price, basePrice: o.price, reward: o.reward, daily: true, bought: log.bought.includes(id), free: price === 0 };
        }),
      ];
      return { day, offers: rows, ad: opts.ad ? { reward: opts.ad.reward, left: Math.max(0, adMax - log.ad) } : null };
    },
    buy(id, pay) {
      refresh();
      const daily = log.list.includes(id);
      const o = daily ? pool.get(id) : fixed.get(id);
      if (!o || (daily && log.bought.includes(id))) return null;
      const price = priceOf(o, daily);
      if (price > 0 && !pay(price)) return null;
      if (price === 0 && daily) log.free = true;
      if (daily) log.bought.push(id);
      persist();
      return o.reward;
    },
    adClaim() {
      refresh();
      if (!opts.ad || log.ad >= adMax) return null;
      log.ad++;
      persist();
      return opts.ad.reward;
    },
  };
}

// --- A timed boost -------------------------------------------------------------------------------------------------

/** What the boost keeps in the save (`save.boost` by default) */
export interface BoostLog {
  /** Seconds left (the play clock) */
  left: number;
  /** When it ends (ms, the wall clock); 0: none */
  until: number;
}

export interface BoostOptions {
  /** The multiplier while it runs (default 2) */
  factor?: number;
  /** 'play' (default): it runs only while tick() is called (play time, menus and the time away don't count); 'wall': real time */
  clock?: 'play' | 'wall';
  /** At most this much stacked (default 4 h) */
  maxSec?: number;
  key?: string;
  now?: () => number;
  persist?: () => void;
}

export interface TimedBoost {
  /** Add time (a reward, a rewarded ad, a bought boost): stacks up to maxSec. Saved at once */
  add(sec: number): void;
  /** Play time passed (clock 'play'): counted in memory, saved with the game's next save */
  tick(sec: number): void;
  /** Seconds left */
  readonly left: number;
  readonly active: boolean;
  /**
   * The multiplier now: `factor` while it runs, else 1 — and always 1 inside offlineEarnings() and Sites.offline():
   * a boost never multiplies the time away
   */
  factor(): number;
  /** `n × factor()` */
  apply(n: number): number;
  readonly log: BoostLog;
}

export function loadBoost(saved: unknown): BoostLog {
  const s = record(saved);
  return { left: num(s.left, 0, 7 * 86400, 0), until: num(s.until, 0, Number.MAX_SAFE_INTEGER, 0) };
}

export function timedBoost(save: SaveHolder, opts: BoostOptions = {}): TimedBoost {
  const key = opts.key ?? 'boost';
  const holder = save as Record<string, unknown>;
  const log = loadBoost(holder[key]);
  holder[key] = log;
  const factor = num(opts.factor ?? 2, 1, 1000, 2);
  const maxSec = num(opts.maxSec ?? 4 * 3600, 1, 7 * 86400, 4 * 3600);
  const wall = opts.clock === 'wall';
  const now = opts.now ?? Date.now;
  const left = () => (wall ? Math.max(0, (log.until - now()) / 1000) : log.left);
  const api: TimedBoost = {
    log,
    add(sec) {
      if (!(sec > 0) || !Number.isFinite(sec)) return;
      const next = Math.min(maxSec, left() + sec);
      if (wall) log.until = now() + next * 1000;
      else log.left = next;
      opts.persist?.();
    },
    tick(sec) {
      if (wall || !(sec > 0) || !Number.isFinite(sec)) return;
      log.left = Math.max(0, log.left - Math.min(sec, 3600));
    },
    get left() {
      return left();
    },
    get active() {
      return left() > 0;
    },
    factor: () => (left() > 0 && !inOfflineMeasure() ? factor : 1),
    apply: (n) => n * api.factor(),
  };
  return api;
}
