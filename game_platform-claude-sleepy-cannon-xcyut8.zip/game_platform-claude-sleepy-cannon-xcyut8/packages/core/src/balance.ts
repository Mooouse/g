// The balance contract: a game's balance bot measures its progression curve and reports a few numbers; the platform
// reads them against the channel's targets (`gp balance`, a section of `gp qa`). Pure, no imports: Node runs it as is.
//
// The game exports from bot.ts (or balance.ts):   export function balance(): BalanceReport   (may be async)
// The numbers come from the game's own bots, the recipe every game so far used (docs/guides/upgrades.md → balance):
// a fresh vs a fully progressed save on the same test; a new player who buys the cheapest thing first and a careful
// one who buys the best value first, each playing a campaign with fixed seeds; when the first purchase came, when
// each new thing arrived and when the meta was finished; and any purchase the bot measured as changing nothing.
// Beside the curve, the quality of the decisions (docs/research/game-design-2026-10.md): a skill ladder of bots (naive,
// average, skilled — the win rate, the winning run's length, how far naive falls behind), the pick rate of every offered
// option and the final builds (choiceLog()), and how hard and how long each stage is.

/** One buyer's campaign, averaged over the bot's seeds (meanCurve) */
export interface BuyerCurve {
  /** Runs until the first purchase or unlock (1 = right after the first run); null: never within the bot's budget */
  firstPurchaseRun: number | null;
  /** Minutes of play (menus included) until then */
  firstPurchaseMin?: number | null;
  /** Minutes of play until the meta is finished (everything bought, or the campaign's last goal); null: not within the budget */
  finishMin: number | null;
  /** Runs until then */
  finishRun?: number | null;
  /** Minutes of play when each new thing arrived, in order: a goal reached, a stage cleared, a new tier or hero */
  goalsMin?: readonly number[];
}

/**
 * What a run offered at one stage (a wave, a floor, a depth): every card of every offer the bot was shown there — the
 * upgrades, parts, perks, shop items — across its seeds, repeats included. A roguelite's late run that keeps offering
 * the same few things reads as "the same six upgrades keep dropping" (a Frankengun playtester); `offers` lets the report
 * count the distinct ones per stage.
 */
export interface OfferStage {
  /** The stage as the game names it: 12, or "wave 12" */
  stage: number | string;
  /** The ids offered there (repeats included: each card shown counts) */
  ids: readonly string[];
}

/** Gathers a bot's offers by stage, in the order the stages come: `log.add(wave, offer.map((c) => c.id))`, then `offers: log.stages()` */
export function offerLog(): { add(stage: number | string, ids: Iterable<string>): void; stages(): OfferStage[] } {
  const by = new Map<number | string, string[]>();
  return {
    add(stage, ids) {
      const list = by.get(stage) ?? [];
      if (!by.has(stage)) by.set(stage, list);
      for (const id of ids) list.push(id);
    },
    stages: () => [...by].map(([stage, ids]) => ({ stage, ids })),
  };
}

/**
 * The decision tables for qa/balance.md (empty when the report has none): the skill ladder, and every option's pick
 * rate — what a Slay the Spire dashboard shows, from the bot's runs
 */
export function decisionsMarkdown(report: BalanceReport, targets: BalanceTargets | string = 'crazygames'): string {
  const t = typeof targets === 'string' ? balanceTargets(targets) : targets;
  const L: string[] = [];
  const sk = skillSummary(report);
  const ladder = BOT_SKILLS.map((k) => sk[k]).filter((x): x is SkillSummary => !!x);
  if (ladder.length) {
    L.push('### The skill ladder', '', `| Bot | Runs | Won | Win rate | Winning run (median) | Progress${report.measure ? ` (${report.measure})` : ''} |`, '|---|---|---|---|---|---|');
    for (const x of ladder) L.push(`| ${x.skill} | ${x.runs} | ${x.wins ?? '—'} | ${x.winRate === null ? '—' : pc(x.winRate)} | ${num(x.winMin) ? `${f1(x.winMin)} min` : '—'} | ${num(x.progress) ? f1(x.progress) : '—'} |`);
    L.push('');
  }
  const rates = pickRates(report.choices ?? []);
  if (rates.length) {
    L.push('### Pick rates', '', `Picked ÷ offered, over offers of two or more options; judged from ${t.pickMinOffered} offers (over ${pc(t.pickDominant)} dominant, under ${pc(t.pickDead)} dead weight).`, '', '| Option | Offered | Picked | Rate | |', '|---|---|---|---|---|');
    for (const r of rates) {
      const mark = r.offered < t.pickMinOffered ? 'too few' : r.rate > t.pickDominant ? 'dominant' : r.rate < t.pickDead ? 'dead weight' : '';
      L.push(`| ${r.id} | ${r.offered} | ${r.picked} | ${pc(r.rate)} | ${mark} |`);
    }
    L.push('');
  }
  return L.join('\n');
}

/** Every option's pick rate as CSV (gp balance --csv: qa/balance-picks.csv) */
export function pickRatesCsv(report: BalanceReport): string {
  return ['option,offered,picked,rate', ...pickRates(report.choices ?? []).map((r) => `"${r.id.replace(/"/g, '""')}",${r.offered},${r.picked},${Math.round(r.rate * 1e4) / 1e4}`)].join('\n') + '\n';
}

export interface BalanceReport {
  /** What `fresh` and `full` measure, higher = stronger ("stage-5 win rate", "depth reached", "metres") */
  measure?: string;
  /** The measure for a fresh save … */
  fresh?: number;
  /** … and for a fully progressed one, in the same test (the same stage, seeds and bot skill) */
  full?: number;
  /** A new player: the cheapest thing first (UpgradeShop.spendLikeAPlayer, Roster.spendCheapest, PactTree.spendCheapest) */
  cheap?: BuyerCurve;
  /** A careful player: the best value first (spendBestValue, spendBest) */
  careful?: BuyerCurve;
  /** Purchases the bot measured as changing nothing (their ids): power after = power before */
  dead?: readonly string[];
  /** What each stage offered, in run order (roguelites: the upgrade, part and shop choices; offerLog() gathers them) */
  offers?: readonly OfferStage[];
  /**
   * The bot skill ladder: runs per skill from a fresh save (naive, average, skilled) — the win rate, the winning run's
   * length, how far naive falls behind skilled. Or tagged `runs` (each with its skill); both are read together
   */
  skills?: Partial<Record<BotSkill, SkillRuns>>;
  /** Single runs, tagged with their skill: won, minutes, progress, the stages played, the final build */
  runs?: readonly BotRun[];
  /** Every offer the bot was shown and what it picked (choiceLog()): the pick rate of each option */
  choices?: readonly ChoiceRecord[];
  /** Each run's final build (choiceLog().builds(); else the tagged runs' `build`): build diversity */
  builds?: readonly (readonly string[])[];
  /** Each stage's attempts, clears and minutes an attempt (else from the tagged runs' stages): hard stages are short */
  stages?: readonly StageStat[];
  /** Seeds and runs behind the numbers, for the report ("3 seeds × 300 runs, average bot") */
  note?: string;
}

// --- The bot skill ladder ----------------------------------------------------------------------------------------------

/**
 * A bot's skill. naive: a player on their first runs (slow, imprecise, no plan — a portal's new visitor); average: the
 * curve's player (the buyers' campaigns); skilled: a good human, the owner's level (Frankengun's SKILLED: tighter aim,
 * quicker reactions, dodges most telegraphs). The difficulty is read from the gaps between them
 */
export type BotSkill = 'naive' | 'average' | 'skilled';
export const BOT_SKILLS: readonly BotSkill[] = ['naive', 'average', 'skilled'];

/** One stage of one run as the bot played it: a roguelite's wave reached, a campaign's attempt at a level */
export interface StagePlay {
  stage: number | string;
  cleared: boolean;
  /** Minutes the attempt took (to the clear or the loss) */
  minutes: number;
}

/** One run of the bot (tagged runs: the report summarises them per skill) */
export interface BotRun {
  /** Who played it (default 'average') */
  skill?: BotSkill;
  /** The run won (cleared every stage, beat the last boss, reached the goal) */
  won: boolean;
  /** Minutes of play of the run (menus between stages included) */
  minutes: number;
  /** How far it got, in the report's `measure` (waves cleared, depth, metres) */
  progress?: number;
  /** The stages it played, in order (for "hard stages are short") */
  stages?: readonly StagePlay[];
  /** The run's final build: the ids it ended with, repeats for levels (build diversity; choiceLog() gathers it too) */
  build?: readonly string[];
}

/** Runs at one skill, summarised by the game (or give tagged `runs` and the report summarises them) */
export interface SkillRuns {
  /** Runs played (from a fresh save, or the save the `note` says) */
  runs: number;
  /** Runs won (leave out for a game without a win: an endless dodger compares `progress` only) */
  wins?: number;
  /** Minutes of each winning run (or their median) */
  winMin?: readonly number[] | number | null;
  /** A run's mean progress, in the report's `measure` */
  progress?: number | null;
}

/** One skill's runs as the report reads them */
export interface SkillSummary {
  skill: BotSkill;
  runs: number;
  /** Runs won; null: the game reports no wins (progress only) */
  wins: number | null;
  winRate: number | null;
  /** The median winning run, in minutes (null: none won, or not reported) */
  winMin: number | null;
  progress: number | null;
}

/** One stage across the bot's runs: how often it was attempted and cleared, and how long an attempt takes */
export interface StageStat {
  stage: number | string;
  attempts: number;
  clears: number;
  /** Minutes of an attempt (the median of the plays) */
  minutes: number;
}

/**
 * game.yaml `balance.difficulty`: the win rate a skill should have from a fresh save (± tolerance, default 0.1) and the
 * minutes a winning run should last — Frankengun's targets: a skilled player wins ≈ 4 runs of 20, a winning run 30–40 min
 */
export interface DifficultyTarget {
  naive?: { winRate: number; tolerance?: number };
  average?: { winRate: number; tolerance?: number };
  skilled?: { winRate: number; tolerance?: number };
  /** [shortest, longest] minutes of a winning run (the skilled bot's, else the best skill that won) */
  winningRunMin?: readonly [number, number];
}

const median = (xs: readonly number[]): number | null => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

/** The report's runs per skill: `skills` as given, tagged `runs` summarised (both given: read together) */
export function skillSummary(report: Pick<BalanceReport, 'skills' | 'runs'>): Partial<Record<BotSkill, SkillSummary>> {
  const out: Partial<Record<BotSkill, SkillSummary>> = {};
  for (const skill of BOT_SKILLS) {
    const given = report.skills?.[skill];
    const tagged = (report.runs ?? []).filter((r) => (r.skill ?? 'average') === skill);
    if (!given && !tagged.length) continue;
    const givenRuns = given && num(given.runs) ? given.runs : 0;
    const givenWins = given && num(given.wins) ? given.wins : null;
    // The win rate counts the runs whose wins are known: the tagged ones, and the given ones when they say their wins
    const winRuns = (givenWins !== null ? givenRuns : 0) + tagged.length;
    const wins = givenWins !== null || tagged.length ? (givenWins ?? 0) + tagged.filter((r) => r.won).length : null;
    const gw = given?.winMin;
    const winTimes = [...(Array.isArray(gw) ? (gw as readonly number[]) : num(gw) ? [gw] : []), ...tagged.filter((r) => r.won && num(r.minutes)).map((r) => r.minutes)];
    const prog = tagged.filter((r) => num(r.progress)).map((r) => r.progress!);
    const gp = given && num(given.progress) ? given.progress : null;
    const progN = (gp !== null ? givenRuns : 0) + prog.length;
    const progress = progN ? ((gp ?? 0) * (gp !== null ? givenRuns : 0) + prog.reduce((a, b) => a + b, 0)) / progN : gp;
    out[skill] = { skill, runs: givenRuns + tagged.length, wins, winRate: wins !== null && winRuns > 0 ? wins / winRuns : null, winMin: median(winTimes), progress };
  }
  return out;
}

/** The stages across the bot's runs: `stages` as given, else from the tagged runs' plays (in the order first played) */
export function stageStats(report: Pick<BalanceReport, 'stages' | 'runs'>): StageStat[] {
  if (report.stages?.length) return [...report.stages];
  const by = new Map<number | string, { attempts: number; clears: number; minutes: number[] }>();
  for (const run of report.runs ?? [])
    for (const p of run.stages ?? []) {
      const s = by.get(p.stage) ?? { attempts: 0, clears: 0, minutes: [] };
      if (!by.has(p.stage)) by.set(p.stage, s);
      s.attempts++;
      if (p.cleared) s.clears++;
      if (num(p.minutes)) s.minutes.push(p.minutes);
    }
  return [...by].map(([stage, s]) => ({ stage, attempts: s.attempts, clears: s.clears, minutes: median(s.minutes) ?? 0 }));
}

/** The minutes of a winning run: the skill asked for, else the most skilled that won (null: no run won) */
export function winningRunMin(report: Pick<BalanceReport, 'skills' | 'runs'>, prefer: BotSkill = 'skilled'): { skill: BotSkill; minutes: number; wins: number | null } | null {
  const s = skillSummary(report);
  for (const skill of [prefer, ...[...BOT_SKILLS].reverse().filter((k) => k !== prefer)]) {
    const x = s[skill];
    if (x && num(x.winMin)) return { skill, minutes: x.winMin, wins: x.wins };
  }
  return null;
}

// --- Decision quality: what the bot was offered and what it picked ------------------------------------------------------

/** One offer the bot was shown (a 1-of-3 card pick, a shop, a draft) and the one it took (null: none) */
export interface ChoiceRecord {
  offered: readonly string[];
  picked: string | null;
  stage?: number | string;
  /** The run it was made in (choiceLog numbers them from 1) */
  run?: number;
}

/** An option's pick rate over the bot's runs */
export interface PickRate {
  id: string;
  /** Times it was in an offer of two or more distinct options */
  offered: number;
  picked: number;
  rate: number;
}

/**
 * Gathers a bot's choices: `log.pick(offer.map((c) => c.id), chosen?.id ?? null, wave)` at every offer, `log.endRun()`
 * after each run (its build: the ids picked in it, or the build you pass), then `choices: log.choices(), builds:
 * log.builds()` — and `offers: log.offers()` (the offers by stage, for the late-run variety check) without an offerLog
 */
export function choiceLog(): {
  pick(offered: Iterable<string>, picked: string | null, stage?: number | string): void;
  endRun(build?: Iterable<string>): void;
  choices(): ChoiceRecord[];
  builds(): string[][];
  offers(): OfferStage[];
} {
  const all: ChoiceRecord[] = [];
  const builds: string[][] = [];
  const offers = offerLog();
  let run = 1;
  let picks: string[] = [];
  return {
    pick(offered, picked, stage) {
      const ids = [...offered];
      all.push({ offered: ids, picked, ...(stage !== undefined ? { stage } : {}), run });
      if (stage !== undefined) offers.add(stage, ids);
      if (picked !== null) picks.push(picked);
    },
    endRun(build) {
      builds.push(build ? [...build] : picks);
      picks = [];
      run++;
    },
    choices: () => all.map((c) => ({ ...c, offered: [...c.offered] })),
    builds: () => builds.map((b) => [...b]),
    offers: () => offers.stages(),
  };
}

/** Each option's pick rate: picked ÷ offered, over offers of two or more distinct options (a real choice); highest first */
export function pickRates(choices: readonly ChoiceRecord[]): PickRate[] {
  const by = new Map<string, { offered: number; picked: number }>();
  for (const c of choices) {
    const ids = new Set(c.offered);
    if (ids.size < 2) continue;
    for (const id of ids) {
      const o = by.get(id) ?? { offered: 0, picked: 0 };
      if (!by.has(id)) by.set(id, o);
      o.offered++;
      if (c.picked === id) o.picked++;
    }
  }
  return [...by].map(([id, o]) => ({ id, offered: o.offered, picked: o.picked, rate: o.picked / o.offered })).sort((a, b) => b.rate - a.rate || b.offered - a.offered || (a.id < b.id ? -1 : 1));
}

/** A build's main pieces (the most repeated, then the first taken; default three), sorted and joined: "drum+pierce+scope" */
export function buildCore(build: readonly string[], n = 3): string {
  const count = new Map<string, { n: number; first: number }>();
  build.forEach((id, i) => {
    const c = count.get(id);
    if (c) c.n++;
    else count.set(id, { n: 1, first: i });
  });
  return [...count].sort((a, b) => b[1].n - a[1].n || a[1].first - b[1].first).slice(0, n).map(([id]) => id).sort().join('+');
}

/**
 * How alike the runs' final builds are: the mean Jaccard similarity of every pair of builds as sets (0: nothing shared,
 * 1: identical), the distinct top-3 cores (buildCore) and the share of the runs with the most common one
 */
export function buildDiversity(builds: readonly (readonly string[])[]): { runs: number; jaccard: number | null; cores: number; topCore: string | null; topShare: number } {
  const full = builds.filter((b) => b.length);
  const sets = full.map((b) => new Set(b));
  let sum = 0;
  let pairs = 0;
  for (let i = 0; i < sets.length; i++)
    for (let j = i + 1; j < sets.length; j++) {
      let inter = 0;
      for (const x of sets[i]) if (sets[j].has(x)) inter++;
      sum += inter / (sets[i].size + sets[j].size - inter);
      pairs++;
    }
  const cores = new Map<string, number>();
  for (const b of full) {
    const k = buildCore(b);
    cores.set(k, (cores.get(k) ?? 0) + 1);
  }
  const top = [...cores].sort((a, b) => b[1] - a[1])[0];
  return { runs: full.length, jaccard: pairs ? sum / pairs : null, cores: cores.size, topCore: top?.[0] ?? null, topShare: top ? top[1] / full.length : 0 };
}

export interface BalanceTargets {
  /** The first purchase after at most this many runs (a warning above) … */
  firstPurchaseRuns: number;
  /** … and a failure above this many (or never) */
  failFirstPurchaseRuns: number;
  /** The first new thing within this many minutes of play */
  firstGoalMin: number;
  /** The meta lasts at least this long (a warning below) … */
  finishMin: number;
  /** … a failure below this (everything bought in a few minutes) … */
  failFinishMin: number;
  /** … and a warning above this (the end out of reach) */
  maxFinishMin: number;
  /** No stretch longer than this without a new thing */
  goalGapMin: number;
  /** Fully progressed at least this many times as strong as fresh */
  fullOverFresh: number;
  /** The careful buyer at most this much faster than the cheap one (a warning above: cheap buys are traps) … */
  buyerGap: number;
  /** … a failure above this */
  failBuyerGap: number;
  /** Late in a run (its last third of stages) every stage offers at least this many distinct things (when it showed twice as many cards) … */
  lateOfferDistinct: number;
  /** … and at least this share of the most an earlier stage offered */
  lateOfferShare: number;
  /** The least skilled bot reaching this share of the most skilled one's progress (or win rate) plays itself: skill doesn't matter (warn) */
  skillGapShare: number;
  /** A declared win rate is met within this much either side, when game.yaml gives no tolerance */
  winRateTolerance: number;
  /** A win rate is judged from this many runs on (fewer: a warning that the sample is too small) */
  minWinRuns: number;
  /** An option picked more than this share of the times it is offered dominates (warn) … */
  pickDominant: number;
  /** … less than this share, it is dead weight (warn) … */
  pickDead: number;
  /** … judged only when offered at least this many times */
  pickMinOffered: number;
  /** The runs' final builds more alike than this (mean Jaccard) are one build (warn) … */
  buildJaccard: number;
  /** … judged from this many runs on */
  buildMinRuns: number;
  /** A stage cleared in fewer than this share of its attempts is hard … */
  hardClear: number;
  /** … and must not take longer an attempt than the median stage; judged from this many attempts on */
  hardMinAttempts: number;
}

/**
 * CrazyGames (13+): a purchase after every early run (Yeet the Gnome, Germ Bait, Starsilk: the first within two runs);
 * Full Launch needs ~10 min average play (game-design.md), so the meta must outlast that; a new thing every 2–7 min;
 * a careful buyer no more than a third faster (Starsilk's balance test); fully upgraded clearly stronger (Candle
 * Crypt: fresh wins 4/16, full 16/16). The own site has no portal data yet: the same numbers.
 */
const PORTAL: BalanceTargets = {
  firstPurchaseRuns: 2,
  failFirstPurchaseRuns: 5,
  firstGoalMin: 3,
  finishMin: 10,
  failFinishMin: 3,
  maxFinishMin: 180,
  goalGapMin: 7,
  fullOverFresh: 1.5,
  buyerGap: 1.33,
  failBuyerGap: 2,
  // Frankengun's late waves offered six things and read as "the same upgrades keep dropping"
  lateOfferDistinct: 8,
  lateOfferShare: 0.5,
  // Decision quality (docs/research/game-design-2026-10.md P1, P3, P19, P20 — rules of thumb): Slay the Spire's pick
  // rates (Giovannetti, GDC 2019), King's "if a level is really hard, it should also be really short", a naive player
  // that keeps up with a skilled one means the game plays itself; Frankengun's skilled win rate needed 120 seeds (40 varied)
  skillGapShare: 0.8,
  winRateTolerance: 0.1,
  minWinRuns: 20,
  pickDominant: 0.6,
  pickDead: 0.05,
  pickMinOffered: 20,
  buildJaccard: 0.8,
  buildMinRuns: 5,
  hardClear: 0.3,
  hardMinAttempts: 10,
};

export const BALANCE_TARGETS: Readonly<Record<string, BalanceTargets>> = { crazygames: PORTAL, web: PORTAL };

/** The targets for a channel (a channel without its own gets the portal's) */
export function balanceTargets(channel: string): BalanceTargets {
  return BALANCE_TARGETS[channel] ?? PORTAL;
}

export type BalanceStatus = 'ok' | 'warn' | 'fail' | 'skip';

export interface BalanceRow {
  name: string;
  status: BalanceStatus;
  /** The measured numbers */
  detail: string;
  /** The target, in words */
  target: string;
}

export interface BalanceVerdict {
  rows: BalanceRow[];
  /** No row failed */
  ok: boolean;
  failed: number;
  warned: number;
  markdown: string;
}

const num = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const f1 = (n: number) => (Math.abs(n) >= 100 ? String(Math.round(n)) : String(Math.round(n * 10) / 10));
const avg = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
const pc = (p: number) => `${Math.round(p * 100)} %`;

/** Several seeds' curves as one: means of the numbers; null when any seed never got there (the honest reading) */
export function meanCurve(curves: readonly BuyerCurve[]): BuyerCurve {
  if (!curves.length) return { firstPurchaseRun: null, finishMin: null };
  const m = (pick: (c: BuyerCurve) => number | null | undefined): number | null => {
    const xs = curves.map(pick);
    return xs.every(num) ? avg(xs as number[]) : null;
  };
  const goals = Math.min(...curves.map((c) => c.goalsMin?.length ?? 0));
  return {
    firstPurchaseRun: m((c) => c.firstPurchaseRun),
    firstPurchaseMin: m((c) => c.firstPurchaseMin),
    finishMin: m((c) => c.finishMin),
    finishRun: m((c) => c.finishRun),
    ...(goals ? { goalsMin: Array.from({ length: goals }, (_, i) => avg(curves.map((c) => c.goalsMin![i]))) } : {}),
  };
}

/** What game.yaml declares beside the report (the CLI passes it), and where the report came from */
export interface BalanceDesignInput {
  /** game.yaml balance.difficulty: the win rates and the winning run's length the skill ladder is held to */
  difficulty?: DifficultyTarget | null;
  /** 'model': the report is the balance model's (a patch runs it alone): the bot's skill ladder was not run */
  from?: 'bot' | 'model';
}

/**
 * Read a game's balance report against its channel's targets: a row per check, ok / warn / fail / skip. `design`: what
 * game.yaml declares (balance.difficulty: the skill ladder's targets, which then fail like the curve's)
 */
export function evaluateBalance(report: BalanceReport, targets: BalanceTargets | string = 'crazygames', design: BalanceDesignInput = {}): BalanceVerdict {
  const t = typeof targets === 'string' ? balanceTargets(targets) : targets;
  const rows: BalanceRow[] = [];
  const row = (name: string, status: BalanceStatus, detail: string, target: string) => rows.push({ name, status, detail, target });
  const cheap = report.cheap;

  // 1. The first purchase: the reason to play a second run
  {
    const name = 'The first purchase comes early';
    const target = `after ≤ ${t.firstPurchaseRuns} runs (fails after ${t.failFirstPurchaseRuns})`;
    if (!cheap) row(name, 'skip', 'no `cheap` curve reported', target);
    else {
      const r = cheap.firstPurchaseRun;
      const min = num(cheap.firstPurchaseMin) ? ` (${f1(cheap.firstPurchaseMin)} min)` : '';
      if (r === null || !num(r)) row(name, 'fail', 'never, within the bot\'s runs', target);
      else row(name, r <= t.firstPurchaseRuns ? 'ok' : r <= t.failFirstPurchaseRuns ? 'warn' : 'fail', `after run ${f1(r)}${min}`, target);
    }
  }

  // 2. The first new thing (a goal, a stage, an unlock)
  {
    const name = 'The first new thing arrives soon';
    const target = `within ${t.firstGoalMin} min`;
    const g = cheap?.goalsMin;
    if (!g?.length) row(name, 'skip', 'no `goalsMin` reported', target);
    else row(name, g[0] <= t.firstGoalMin ? 'ok' : 'warn', `at ${f1(g[0])} min`, target);
  }

  // 3. The meta's length
  {
    const name = 'The meta lasts';
    const target = `${t.finishMin}–${t.maxFinishMin} min of play (fails under ${t.failFinishMin})`;
    if (!cheap) row(name, 'skip', 'no `cheap` curve reported', target);
    else if (!num(cheap.finishMin)) row(name, 'warn', 'not finished within the bot\'s runs: the end may be out of reach (fine if the game is endless by design — say so)', target);
    else {
      const m = cheap.finishMin;
      const runs = num(cheap.finishRun) ? `, ${f1(cheap.finishRun)} runs` : '';
      row(name, m < t.failFinishMin ? 'fail' : m < t.finishMin || m > t.maxFinishMin ? 'warn' : 'ok', `finished at ${f1(m)} min${runs}`, target);
    }
  }

  // 4. No long stretch without news
  {
    const name = 'No long stretch without a new thing';
    const target = `≤ ${t.goalGapMin} min between new things`;
    const g = cheap?.goalsMin;
    if (!g?.length) row(name, 'skip', 'no `goalsMin` reported', target);
    else {
      let gap = g[0];
      let at = 0;
      for (let i = 1; i < g.length; i++) if (g[i] - g[i - 1] > gap) [gap, at] = [g[i] - g[i - 1], i];
      row(name, gap <= t.goalGapMin ? 'ok' : 'warn', `longest ${f1(gap)} min (before new thing ${at + 1} of ${g.length})`, target);
    }
  }

  // 5. Progress means power
  {
    const name = 'Fully progressed is clearly stronger';
    const target = `full ≥ ${t.fullOverFresh}× fresh`;
    const { fresh, full } = report;
    const m = report.measure ? ` (${report.measure})` : '';
    if (!num(fresh) || !num(full)) row(name, 'skip', 'no `fresh` / `full` reported (fine for sideways unlocks: say so)', target);
    else {
      const detail = `fresh ${f1(fresh)} → full ${f1(full)}${m}`;
      if (full < fresh) row(name, 'fail', `${detail}: progress makes the player weaker`, target);
      else if (full === fresh) row(name, 'warn', `${detail}: no stronger — fine only if the progression is sideways by design`, target);
      else row(name, fresh <= 0 || full >= fresh * t.fullOverFresh ? 'ok' : 'warn', detail, target);
    }
  }

  // 6. The buyers: a trap or a dominant pick shows as a gap between cheap and careful
  {
    const name = 'No trap, no dominant pick';
    const target = `careful buyer ≤ ${t.buyerGap}× faster than cheapest-first (fails over ${t.failBuyerGap}×)`;
    const a = cheap?.finishMin;
    const b = report.careful?.finishMin;
    if (!report.careful) row(name, 'skip', 'no `careful` curve reported', target);
    else if (!num(a) && !num(b)) row(name, 'skip', 'neither buyer finished: nothing to compare', target);
    else if (!num(a)) row(name, 'fail', `careful finished at ${f1(b!)} min, cheapest-first never: cheapest-first gets stuck, the cheap buys are traps`, target);
    else if (!num(b)) row(name, 'warn', `cheapest-first finished at ${f1(a)} min, careful never: buying "best value" gets stuck — the game's value measure is off`, target);
    else {
      const gap = a / b;
      const detail = `cheapest-first ${f1(a)} min, careful ${f1(b)} min (${f1(gap)}×)`;
      if (gap > t.failBuyerGap) row(name, 'fail', `${detail}: the cheap buys are traps`, target);
      else if (gap > t.buyerGap) row(name, 'warn', `${detail}: the cheap buys slow a new player down`, target);
      else if (gap < 1 / t.buyerGap) row(name, 'warn', `${detail}: buying "best value" is slower — the game's value measure is off`, target);
      else row(name, 'ok', `${detail}${gap === 1 ? ' — prices may not matter enough' : ''}`, target);
    }
  }

  // 7. Dead purchases
  {
    const name = 'Every purchase changes something';
    const target = 'no purchase the bot measured as doing nothing';
    const d = report.dead;
    if (!d) row(name, 'skip', 'no `dead` list reported', target);
    else row(name, d.length ? 'fail' : 'ok', d.length ? `changes nothing: ${d.join(', ')}` : 'none', target);
  }

  // 8. The late run keeps offering something new (a cheap variety check: a warning, never a failure)
  {
    const name = 'The late run still offers variety';
    const target = `each late stage (the last third) offers ≥ ${t.lateOfferDistinct} distinct things and ≥ ${Math.round(t.lateOfferShare * 100)} % of the most an earlier stage did`;
    const stages = (report.offers ?? []).filter((o) => o.ids.length > 0);
    if (!stages.length) row(name, 'skip', 'no `offers` reported (roguelites: what each stage offered — docs/guides/upgrades.md)', target);
    else {
      const counted = stages.map((o) => ({ stage: o.stage, shown: o.ids.length, distinct: new Set(o.ids).size, ids: o.ids }));
      const lateFrom = Math.min(counted.length - 1, Math.floor((counted.length * 2) / 3));
      const early = counted.slice(0, lateFrom);
      const late = counted.slice(lateFrom);
      const best = early.length ? Math.max(...early.map((c) => c.distinct)) : 0;
      const low = late.filter((c) => (c.shown >= 2 * t.lateOfferDistinct && c.distinct < t.lateOfferDistinct) || (best > 0 && c.distinct < best * t.lateOfferShare));
      const worst = [...late].sort((a, b) => a.distinct - b.distinct)[0]!;
      const range = late.length > 1 ? `stages ${late[0]!.stage}–${late.at(-1)!.stage}` : `stage ${late[0]!.stage}`;
      const counts = late.map((c) => c.distinct);
      const span = Math.min(...counts) === Math.max(...counts) ? `${counts[0]}` : `${Math.min(...counts)}–${Math.max(...counts)}`;
      const detail = `late (${range}): ${span} distinct${best ? `; the most earlier: ${best}` : ''}`;
      if (!low.length) row(name, 'ok', detail, target);
      else {
        const tally = new Map<string, number>();
        for (const id of worst.ids) tally.set(id, (tally.get(id) ?? 0) + 1);
        const top = [...tally].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([id, n]) => `${id} ×${n}`).join(', ');
        row(name, 'warn', `${detail} — stage ${worst.stage} offered ${worst.distinct} distinct in ${worst.shown} cards (${top}): the late offers collapse to a few; widen the late pool, drop finished things, make repeats rarer`, target);
      }
    }
  }

  // 9–11. The skill ladder: naive behind skilled, the declared win rates, the winning run's length
  const sk = skillSummary(report);
  const ladder = BOT_SKILLS.map((k) => sk[k]).filter((x): x is SkillSummary => !!x);
  const said = (x: SkillSummary) => [num(x.progress) ? f1(x.progress) : '', x.winRate !== null ? `wins ${pc(x.winRate)} (${x.wins} of ${x.runs})` : ''].filter(Boolean).join(', ');
  {
    const name = 'Skill matters: naive falls behind skilled';
    const target = `the least skilled bot below ${pc(t.skillGapShare)} of the most skilled one's progress (or win rate)`;
    if (ladder.length < 2) row(name, 'skip', ladder.length ? `only the ${ladder[0].skill} bot reported (skills: { naive, average, skilled }, or tagged runs)` : 'no runs per skill reported (skills: { naive, average, skilled }, or tagged runs — docs/guides/upgrades.md → the skill ladder)', target);
    else {
      const lo = ladder[0];
      const hi = ladder[ladder.length - 1];
      const byProgress = num(lo.progress) && num(hi.progress) && hi.progress > 0;
      const share = byProgress ? lo.progress! / hi.progress! : lo.winRate !== null && hi.winRate !== null && hi.winRate > 0 ? lo.winRate / hi.winRate : null;
      const detail = ladder.map((x) => `${x.skill}: ${said(x) || `${x.runs} runs`}`).join(' · ') + (byProgress && report.measure ? ` (${report.measure})` : '');
      if (share === null) row(name, 'skip', `${detail} — nothing to compare (no progress reported, and the ${hi.skill} bot never won)`, target);
      else {
        const gap = `${lo.skill} at ${pc(share)} of ${hi.skill}${byProgress ? '' : ' (win rates)'}`;
        if (share > 1) row(name, 'warn', `${detail} (${gap}): the ${lo.skill} bot does better than the ${hi.skill} one — the bots' skills are off, or the game punishes playing well`, target);
        else if (share >= t.skillGapShare) row(name, 'warn', `${detail} (${gap}): the ${lo.skill} bot keeps up — skill hardly matters, the game plays itself (reward aim, timing, dodging and choices)`, target);
        else row(name, 'ok', `${detail} (${gap})`, target);
      }
    }
  }
  const dif = design.difficulty ?? null;
  const patch = design.from === 'model';
  const declared = dif ? BOT_SKILLS.filter((k) => dif[k]) : [];
  for (const skill of declared) {
    const goal = dif![skill]!;
    const tol = goal.tolerance ?? t.winRateTolerance;
    const name = `The ${skill} player's win rate`;
    const target = `${pc(goal.winRate)} ± ${pc(tol)} of runs from a fresh save (game.yaml balance.difficulty)`;
    const s = sk[skill];
    if (patch) row(name, 'skip', "the balance model alone (a patch): the bot's skill ladder is not run — gp qa --bot, gp balance", target);
    else if (!s || s.winRate === null) row(name, 'warn', `not measured: balance() reports no ${skill} runs with their wins (skills.${skill} = { runs, wins, winMin }, or tagged runs)`, target);
    else if (s.runs < t.minWinRuns) row(name, 'warn', `${s.wins} of ${s.runs} runs (${pc(s.winRate)}): too few runs to judge — play ${t.minWinRuns}+ (Frankengun needed 120 seeds: 40 varied too much)`, target);
    else {
      const off = Math.abs(s.winRate - goal.winRate) > tol + 1e-9;
      const how = s.winRate > goal.winRate ? 'too easy' : 'too hard';
      row(name, off ? 'fail' : 'ok', `${s.wins} of ${s.runs} runs (${pc(s.winRate)})${off ? `: ${how} for the ${skill} player` : ''}`, target);
    }
  }
  if (!declared.length && ladder.some((x) => x.winRate !== null))
    row("The skilled player's win rate", 'skip', ladder.filter((x) => x.winRate !== null).map((x) => `${x.skill} ${pc(x.winRate!)} (${x.wins} of ${x.runs})`).join(' · '), 'no target declared (game.yaml balance.difficulty: { skilled: { winRate } })');
  {
    const name = "The winning run's length";
    const range = dif?.winningRunMin;
    const w = winningRunMin(report);
    const target = range ? `${range[0]}–${range[1]} min (game.yaml balance.difficulty.winningRunMin)` : 'no target declared (game.yaml balance.difficulty.winningRunMin)';
    if (range) {
      if (patch) row(name, 'skip', "the balance model alone (a patch): the bot's winning runs are not played — gp qa --bot, gp balance", target);
      else if (!w) row(name, 'warn', 'no run won: the winning run\'s length is not measured (skills.<skill>.winMin, or tagged runs that won)', target);
      else {
        const detail = `the ${w.skill} bot's winning run: ${f1(w.minutes)} min (median${w.wins !== null ? ` of ${w.wins}` : ''})`;
        const short = w.minutes < range[0];
        row(name, short || w.minutes > range[1] ? 'fail' : 'ok', `${detail}${short ? ': shorter than designed' : w.minutes > range[1] ? ': longer than designed' : ''}`, target);
      }
    } else if (w) row(name, 'skip', `the ${w.skill} bot's winning run: ${f1(w.minutes)} min (median)`, target);
  }

  // 12. Offered choices are real choices: no option always taken, none never (Slay the Spire's pick rates)
  {
    const name = 'Offered choices are real choices';
    const target = `every option offered ${t.pickMinOffered}+ times is picked ${pc(t.pickDead)}–${pc(t.pickDominant)} of the times it is offered`;
    const choices = report.choices ?? [];
    if (!choices.length) row(name, 'skip', 'no `choices` reported (choiceLog(): each offer the bot saw and what it picked)', target);
    else {
      const rates = pickRates(choices);
      const judged = rates.filter((r) => r.offered >= t.pickMinOffered);
      const few = rates.length - judged.length;
      const head = `${judged.length} of ${rates.length} options judged over ${choices.length} offers${few ? ` (${few} offered under ${t.pickMinOffered} times)` : ''}`;
      if (!judged.length) row(name, 'skip', `${head}: too few choices logged to judge — more runs or seeds`, target);
      else {
        const dom = judged.filter((r) => r.rate > t.pickDominant);
        const dead = judged.filter((r) => r.rate < t.pickDead);
        const list = (xs: PickRate[]) => xs.slice(0, 5).map((r) => `${r.id} ${pc(r.rate)} of ${r.offered}`).join(', ') + (xs.length > 5 ? ` and ${xs.length - 5} more` : '');
        if (!dom.length && !dead.length) row(name, 'ok', `${head}: pick rates ${pc(judged[judged.length - 1].rate)}–${pc(judged[0].rate)}`, target);
        else
          row(name, 'warn', `${head}${dom.length ? ` — dominant: ${list(dom)}` : ''}${dead.length ? ` — dead weight: ${list(dead)}` : ''}: a no-brainer or a never-pick is not a decision; weaken or make situational what always wins, give a role to (or drop) what never does`, target);
      }
    }
  }

  // 13. The runs end in different builds
  {
    const name = 'Builds differ from run to run';
    const target = `the final builds of ${t.buildMinRuns}+ runs share at most ${pc(t.buildJaccard)} (mean Jaccard of every pair)`;
    const builds = report.builds ?? (report.runs ?? []).filter((r) => r.build?.length).map((r) => r.build!);
    const d = buildDiversity(builds);
    if (!d.runs) row(name, 'skip', 'no `builds` reported (choiceLog().builds(), or tagged runs with their build)', target);
    else if (d.runs < t.buildMinRuns || d.jaccard === null) row(name, 'skip', `${d.runs} build(s): too few to compare (${t.buildMinRuns}+)`, target);
    else {
      const detail = `${d.runs} runs: ${d.cores} distinct top-3 cores (the most common, ${d.topCore}, in ${pc(d.topShare)}), builds ${pc(d.jaccard)} alike`;
      row(name, d.jaccard > t.buildJaccard ? 'warn' : 'ok', d.jaccard > t.buildJaccard ? `${detail}: every run ends in nearly the same build — one path wins; vary the offers, give rival builds their own payoff` : detail, target);
    }
  }

  // 14. Hard stages are short (King: "if a level is really hard, it should also be really short")
  {
    const name = 'Hard stages are short';
    const target = `a stage cleared in under ${pc(t.hardClear)} of its attempts takes no longer an attempt than the median stage (judged from ${t.hardMinAttempts} attempts)`;
    const stats = stageStats(report).filter((s) => s.attempts >= t.hardMinAttempts && num(s.minutes));
    if (!stats.length) row(name, 'skip', 'no stage attempts reported (`stages`, or tagged runs with the stages they played)', target);
    else {
      const med = median(stats.map((s) => s.minutes))!;
      const rate = (s: StageStat) => s.clears / s.attempts;
      const hard = stats.filter((s) => rate(s) < t.hardClear);
      const long = hard.filter((s) => s.minutes > med + 1e-9);
      const say = (s: StageStat) => `${s.stage}: ${pc(rate(s))} cleared, ${f1(s.minutes)} min an attempt`;
      if (!hard.length) {
        const hardest = [...stats].sort((a, b) => rate(a) - rate(b))[0];
        row(name, 'ok', `${stats.length} stages, none under ${pc(t.hardClear)} cleared (the hardest, ${say(hardest)})`, target);
      } else if (long.length)
        row(name, 'warn', `${long.slice(0, 4).map(say).join('; ')} — longer than the median stage (${f1(med)} min): a hard stage that is also long costs the most time a loss; shorten it, or ease it`, target);
      else row(name, 'ok', `${hard.length} hard stage(s) (${hard.slice(0, 3).map(say).join('; ')}), none longer than the median ${f1(med)} min`, target);
    }
  }

  const failed = rows.filter((r) => r.status === 'fail').length;
  const warned = rows.filter((r) => r.status === 'warn').length;
  const icon: Record<BalanceStatus, string> = { ok: '✅', warn: '⚠️', fail: '❌', skip: '–' };
  const markdown = [
    `**Balance: ${failed ? `${failed} failed` : 'no failures'}, ${warned} warning(s).**${report.note ? ` ${report.note}` : ''}`,
    '',
    '| | Check | Measured | Target |',
    '|---|---|---|---|',
    ...rows.map((r) => `| ${icon[r.status]} | ${r.name} | ${r.detail.replace(/\|/g, '\\|')} | ${r.target} |`),
    '',
  ].join('\n');
  return { rows, ok: failed === 0, failed, warned, markdown };
}
