// What the platform's meta screens share (goals, the album, the rewards hub): the drawn marks, the icons a game passes
// in, the theme variables with the shared `--gp-theme-*` base as their fallback, a modal veil that takes its place in
// the one-card-at-a-time queue, and the grid that shows as many cells as fit and pages the rest (gp qa's one-screen
// rule: never a panel to scroll). Internal: the screens' own modules are the API.

import { cardOpened } from './cards.ts';
import { FONT_FALLBACK } from './i18n.ts';

export const SVG_NS = 'http://www.w3.org/2000/svg';

/**
 * An icon from the game: an image URL (data:, blob:, http(s), a path, a file name with an image extension), a short text
 * (an emoji or a letter), an element (an <img>, a <canvas>, an inline <svg>: iconImg() from @gp/art/dom), or a function
 * that makes one (called for every place it shows)
 */
export type UiIcon = string | Element | (() => string | Element);

const IMAGE_URL = /^(?:data:image\/|blob:|https?:\/\/|\.{0,2}\/)|\.(?:png|svg|webp|avif|gif|jpe?g)(?:[?#].*)?$/i;

/** A copy of an element for a second place: a canvas keeps its pixels */
function copyOf(node: Element): Element {
  const c = node.cloneNode(true) as Element;
  if (node instanceof HTMLCanvasElement && c instanceof HTMLCanvasElement) c.getContext('2d')?.drawImage(node, 0, 0);
  return c;
}

/** The node for an icon. An element already on the page (or shown before) is copied: the same icon fits many cells */
export function iconOf(icon: UiIcon | undefined | null, used?: WeakSet<Element>): Node {
  if (icon === undefined || icon === null) return document.createTextNode('');
  const v = typeof icon === 'function' ? icon() : icon;
  if (typeof v === 'string') {
    if (!IMAGE_URL.test(v.trim())) return document.createTextNode(v);
    const img = document.createElement('img');
    img.src = v.trim();
    img.alt = '';
    img.decoding = 'async';
    img.draggable = false;
    return img;
  }
  if (v.isConnected || used?.has(v)) return copyOf(v);
  used?.add(v);
  return v;
}

/** The platform's marks on a 24-unit box: drawn, so they look the same everywhere (no emoji, no font glyph) */
export const MARKS = {
  check: 'M4.5 12.5l4.8 4.8L19.5 7',
  lock: 'M7 10.5V8a5 5 0 0 1 10 0v2.5M5.5 10.5h13v9.5h-13z',
  star: 'M12 3.2l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3.1-5.4 3.1 1.2-6-4.5-4.2 6.1-.7z',
  prev: 'M15 5l-7 7 7 7',
  next: 'M9 5l7 7-7 7',
  close: 'M6 6l12 12M18 6L6 18',
  gift: 'M4 11h16v9H4zM3 7.5h18V11H3zM12 7.5V20M12 7.5c-1.5-3.5-5.5-4-5.5-1.5S12 7.5 12 7.5zM12 7.5c1.5-3.5 5.5-4 5.5-1.5S12 7.5 12 7.5z',
  chest: 'M4 10a8 5 0 0 1 16 0v9H4zM4 12.5h16M10.5 11h3v3.5h-3z',
  clock: 'M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM12 7.5V12l3 2',
  question: 'M9 9.2a3 3 0 1 1 4.3 2.7c-.9.5-1.3 1.1-1.3 2.1M12 17.5v.2',
  play: 'M8 5.5v13l10.5-6.5z',
  dot: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',
} as const;
export type MarkName = keyof typeof MARKS;

/** A drawn mark: an inline SVG in currentColor (`data-mark` names it for tests) */
export function mark(name: MarkName, size = 18, filled = false): SVGSVGElement {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', String(size));
  svg.setAttribute('height', String(size));
  svg.setAttribute('aria-hidden', 'true');
  svg.dataset.mark = name;
  const p = document.createElementNS(SVG_NS, 'path');
  p.setAttribute('d', MARKS[name]);
  p.setAttribute('fill', filled ? 'currentColor' : 'none');
  p.setAttribute('stroke', 'currentColor');
  p.setAttribute('stroke-width', filled ? '1.5' : '2.4');
  p.setAttribute('stroke-linecap', 'round');
  p.setAttribute('stroke-linejoin', 'round');
  svg.append(p);
  return svg;
}

export function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

export function button(cls: string, gp: string, text?: string): HTMLButtonElement {
  const b = el('button', cls ? `gp-b ${cls}` : 'gp-b', text);
  b.type = 'button';
  b.dataset.gp = gp;
  return b;
}

/** The style sheet, once, FIRST in <head>: a game's own rules (`#gp-goals { … }`) win wherever they are */
export function injectCss(id: string, text: string): void {
  if (document.getElementById(id)) return;
  const style = document.createElement('style');
  style.id = id;
  style.textContent = text;
  document.head.prepend(style);
}

/** The shared base (screenTheme() sets these): a screen's own variable falls back to it, then to the platform's colour */
export const THEME_BASE = {
  bg: ['--gp-theme-bg', '#17223a'],
  panel: ['--gp-theme-panel', 'rgba(255, 255, 255, 0.07)'],
  ink: ['--gp-theme-ink', '#f2f6ff'],
  muted: ['--gp-theme-muted', '#a7b4cc'],
  accent: ['--gp-theme-accent', '#ffd166'],
  'accent-ink': ['--gp-theme-accent-ink', '#1b2233'],
  radius: ['--gp-theme-radius', '20px'],
  font: ['--gp-theme-font', FONT_FALLBACK],
} as const;

/**
 * The variables of a screen `#<id>` (`--gp-<ns>-bg` …), each defaulting to the shared `--gp-theme-*` and then to the
 * platform's colour; `extra` adds the screen's own (`[name, value]`). `:where()` keeps them at no specificity
 */
export function themeVars(id: string, ns: string, extra: [string, string][] = []): string {
  const base = Object.entries(THEME_BASE).map(([k, [theme, dflt]]) => `--gp-${ns}-${k}: var(${theme}, ${dflt});`);
  return `:where(#${id}) { ${[...base, ...extra.map(([k, v]) => `--gp-${ns}-${k}: ${v};`)].join(' ')} }`;
}

/** The modal's frame: the veil, the box (role=dialog), a close that the one-card queue hears */
export interface Modal {
  veil: HTMLElement;
  box: HTMLElement;
  close(): void;
  readonly open: boolean;
}

/**
 * A modal veil over the screen with its box `#<id>`, in `root` (default document.body). A tap on the veil outside the
 * box calls `onDismiss`. Registers as a card (cards.ts): queued cards wait until it closes
 */
export function modal(id: string, label: string, root: HTMLElement | null | undefined, onDismiss: () => void, onClosed?: () => void): Modal {
  document.getElementById(`${id}-veil`)?.remove();
  const veil = el('div');
  veil.id = `${id}-veil`;
  veil.className = 'gp-ui-veil';
  const box = el('section');
  box.id = id;
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-modal', 'true');
  box.setAttribute('aria-label', label);
  veil.append(box);
  let open = true;
  let closed: (() => void) | null = null;
  const m: Modal = {
    veil,
    box,
    get open() {
      return open;
    },
    close() {
      if (!open) return;
      open = false;
      veil.remove();
      closed?.();
      onClosed?.();
    },
  };
  veil.addEventListener('click', (e) => {
    if (e.target === veil) onDismiss();
  });
  (root ?? document.body).append(veil);
  closed = cardOpened(id, veil);
  return m;
}

/** The veil's style (shared): over everything the game draws, under nothing of its own */
export const VEIL_CSS = `.gp-ui-veil { position: fixed; inset: 0; z-index: 40; display: flex; align-items: center; justify-content: center; background: rgba(0, 0, 0, 0.5); }`;

/**
 * How many cells of at least `w`×`h` fit `track` now (columns × rows); sets its grid so that a page of them fills it
 * (rows at most 1.6 × `h`). `count`: the cells there are (fewer rows when they all fit)
 */
export function fitGrid(track: HTMLElement, count: number, w: number, h: number, gap: number, maxRows = Infinity): number {
  const cw = track.clientWidth;
  const ch = track.clientHeight;
  const cols = Math.max(1, Math.floor((cw + gap) / (w + gap)));
  const rows = Math.max(1, Math.min(maxRows, Math.floor((ch + gap) / (h + gap))));
  const used = Math.min(rows, Math.max(1, Math.ceil(count / cols)));
  const rowH = Math.min(h * 1.6, (ch - gap * (used - 1)) / used);
  track.style.gridTemplateColumns = `repeat(${cols}, minmax(0, 1fr))`;
  track.style.gridAutoRows = `${Math.max(h, Math.floor(rowH))}px`;
  return cols * rows;
}

/** A pager (‹ 1/3 ›): returns its element and set(page, pages) */
export function pager(gp: string, minTouchPx: number, label: (n: number, max: number) => string, go: (delta: number) => void): { el: HTMLElement; set(page: number, pages: number): void } {
  const wrap = el('div', 'gp-ui-pager');
  wrap.dataset.gp = `${gp}-pager`;
  const prev = button('gp-ui-page', `${gp}-prev`);
  prev.append(mark('prev', 20));
  const next = button('gp-ui-page', `${gp}-next`);
  next.append(mark('next', 20));
  for (const b of [prev, next]) b.style.minWidth = b.style.minHeight = `${minTouchPx}px`;
  const no = el('span', 'gp-ui-pageno');
  wrap.append(prev, no, next);
  let at = 0;
  let of = 1;
  prev.addEventListener('click', () => at > 0 && go(-1));
  next.addEventListener('click', () => at < of - 1 && go(1));
  return {
    el: wrap,
    set(page, pages) {
      at = page;
      of = pages;
      no.textContent = `${page + 1}/${pages}`;
      no.setAttribute('aria-label', label(page + 1, pages));
      prev.setAttribute('aria-disabled', String(page === 0));
      next.setAttribute('aria-disabled', String(page >= pages - 1));
      wrap.hidden = pages <= 1;
    },
  };
}

/** The pager's style inside a screen `#<id>` with the variables of `ns` */
export const pagerCss = (id: string, ns: string) => `
#${id} .gp-ui-pager { display: flex; align-items: center; gap: 6px; }
#${id} .gp-ui-page { border-radius: 999px; background: var(--gp-${ns}-panel); box-shadow: inset 0 0 0 2px var(--gp-${ns}-off, rgba(255, 255, 255, 0.16)); display: inline-flex; align-items: center; justify-content: center; }
#${id} .gp-ui-page[aria-disabled=true] { opacity: 0.4; cursor: default; }
#${id} .gp-ui-pageno { font-size: 13px; color: var(--gp-${ns}-muted); white-space: nowrap; }`;

/** The tabs row (role=tablist): returns its element and select(id) */
export function tabs<T extends string>(gp: string, items: { id: T; label: string; badge?: number }[], minTouchPx: number, onSelect: (id: T) => void): { el: HTMLElement; select(id: T): void; badge(id: T, n: number): void } {
  const row = el('div', 'gp-ui-tabs');
  row.setAttribute('role', 'tablist');
  const btns = new Map<T, HTMLButtonElement>();
  for (const it of items) {
    const b = button('gp-ui-tab', `${gp}-tab`);
    b.dataset.gpTab = it.id;
    b.setAttribute('role', 'tab');
    b.style.minHeight = `${minTouchPx}px`;
    const label = el('span', 'gp-ui-tablabel', it.label);
    const dot = el('span', 'gp-ui-badge');
    dot.hidden = true;
    b.append(label, dot);
    b.addEventListener('click', () => onSelect(it.id));
    btns.set(it.id, b);
    row.append(b);
  }
  const api = {
    el: row,
    select(id: T) {
      for (const [k, b] of btns) b.setAttribute('aria-selected', String(k === id));
    },
    badge(id: T, n: number) {
      const dot = btns.get(id)?.querySelector<HTMLElement>('.gp-ui-badge');
      if (!dot) return;
      dot.hidden = !(n > 0);
      dot.textContent = n > 0 ? String(n) : '';
    },
  };
  for (const it of items) api.badge(it.id, it.badge ?? 0);
  row.hidden = items.length < 2;
  return api;
}

export const tabsCss = (id: string, ns: string) => `
#${id} .gp-ui-tabs { display: flex; gap: 6px; }
#${id} .gp-ui-tab { flex: 1 1 0; border-radius: 999px; padding: 0 10px; background: var(--gp-${ns}-panel); color: var(--gp-${ns}-muted); font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center; gap: 6px; min-width: 0; }
#${id} .gp-ui-tablabel { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
#${id} .gp-ui-tab[aria-selected=true] { background: var(--gp-${ns}-ink); color: var(--gp-${ns}-bg); }
#${id} .gp-ui-badge { min-width: 20px; height: 20px; border-radius: 10px; padding: 0 5px; box-sizing: border-box; font-size: 12px; line-height: 20px;
  background: var(--gp-${ns}-accent); color: var(--gp-${ns}-accent-ink); }`;

/**
 * The reset every platform screen puts on its buttons (an id and a class: a game's `#ui button { … }`, an id and an
 * element, doesn't reach them, while the game's own `#gp-goals .gp-claim { … }` after it wins)
 */
export const buttonReset = (id: string) => `#${id} .gp-b { font: inherit; border: 0; margin: 0; min-width: 0; box-shadow: none; text-transform: none; letter-spacing: normal;
  cursor: pointer; touch-action: manipulation; color: inherit; background: none; padding: 0; }
#${id} [hidden] { display: none !important; }`;

/** "m:ss" (or "h:mm:ss"): a countdown that reads the same in every language */
export function clockText(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(r)}` : `${m}:${pad(r)}`;
}

/** Reduced motion asked for by the player's system */
export const reducedMotion = (): boolean => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
