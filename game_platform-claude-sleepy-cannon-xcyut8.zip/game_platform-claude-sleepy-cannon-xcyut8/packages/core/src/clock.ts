// A world clock: time slots, scheduled events and weather that are the same for every player at the same moment,
// because they are only a function of the UTC clock and a seed (Grow a Garden's 5-minute restock, Blox Fruits' 4-hour
// dealer, a weather front, a festival hour: docs/research/roblox-2026-10.md P1, P6). No server: two players who open
// the game at 18:03 UTC see the same slot, the same storm and the same festival — so a game may truthfully say "the
// same for every player". Pure: an injected `now`, plain numbers out; Node tests, balance bots and QA's virtual clock
// run it as it is.
//
//   const clock = worldClock({ salt: 'storm-geodes', every: '5m' });       // every player on the same UTC slot
//   clock.slot();            // { index, key: '2026-10-19#137', start, end, nextIn: 192, seed }
//   const sky = clock.weather({ states: [{ id: 'clear', weight: 6, lasts: ['10m', '25m'] }, { id: 'storm', weight: 1, lasts: '6m' }] });
//   sky.state();             // { id: 'storm', since, until, endsIn: 214, next: { id: 'clear', at, startsIn: 214 } }
//   const fest = clock.schedule([{ id: 'aurora', every: '2h', offset: '45m', lasts: '10m' },
//                                { id: 'festival', weekly: 'SAT 18:00', lasts: '30m', data: { mutations: 2 } }]);
//   fest.state();            // { active: [...], upcoming: [{ id: 'aurora', start, startsIn: 2520, … }] }
//
// Rules (D56, docs/guides/live-world.md): a slot that passes takes nothing away — the UI shows what is coming, never
// what was missed ("come back in 5 minutes or lose it" is the framing we never use). Never print a count of players
// in the shared world: the world is shared, the players in it are not visible. Dev and QA move time with
// `offsetMs: clockShift(location.search)` (`?clock=+300` jumps 5 minutes ahead, `?clock=2026-10-24T18:05Z` to a moment).

import { dayKey, daySeed } from './daily.ts';
import { seededRng } from './rng.ts';

/** A length of time: seconds as a number, or text: '90s', '5m', '2h', '1d', '1w', '1h30m' */
export type Duration = number | string;

const UNIT: Record<string, number> = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 };
const DAY_MS = 86400000;
const WEEK_MS = 7 * DAY_MS;
/** 1970-01-01 was a Thursday: the first Monday 00:00 UTC is 4 days in */
const MONDAY_MS = 4 * DAY_MS;
const WEEKDAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

/** A duration in milliseconds ('5m' → 300000, 90 → 90000); throws on text it can't read or a negative length */
export function durationMs(d: Duration): number {
  if (typeof d === 'number') {
    if (!Number.isFinite(d) || d < 0) throw new Error(`duration: ${d} is not a number of seconds ≥ 0`);
    return Math.round(d * 1000);
  }
  const s = d.trim().toLowerCase().replace(/\s+/g, '');
  if (!/^(\d+(\.\d+)?[smhdw])+$/.test(s)) throw new Error(`duration: '${d}' — write it like 90s, 5m, 2h, 1d, 1w or 1h30m`);
  let ms = 0;
  for (const m of s.matchAll(/(\d+(?:\.\d+)?)([smhdw])/g)) ms += Number(m[1]) * UNIT[m[2]] * 1000;
  return Math.round(ms);
}

/** Seconds as a clock reads them: '3:12', '12:05', '2:14:05' (rounded up: 0.2 s left is '0:01'; never negative) */
export function formatClock(sec: number): string {
  const s = Math.max(0, Math.ceil(Number.isFinite(sec) ? sec : 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const pad = (n: number) => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(s % 60)}` : `${m}:${pad(s % 60)}`;
}

/**
 * The time travel of a dev build or a QA run, from the page's query: `?clock=+300` (seconds ahead; `-60` back,
 * `+2h`, `+1d`) or `?clock=2026-10-24T18:05Z` (a moment). The offset in ms to pass as `worldClock({ offsetMs })`;
 * 0 without the parameter or with one it can't read. Only in dev and QA builds (`import.meta.env.DEV`): a player's
 * URL never moves the shared world.
 */
export function clockShift(search: string, now: number = Date.now()): number {
  const v = new URLSearchParams(search).get('clock');
  if (!v) return 0;
  // A '+' in a query string reads as a space; a bare length ('300', '2h') is ahead too
  const s = v.replace(/^ /, '+').trim();
  const rel = /^([+-])(.+)$/.exec(s) ?? (/^(\d+(\.\d+)?[smhdw]?)+$/.test(s) ? ['', '+', s] : null);
  if (rel) {
    try {
      return (rel[1] === '-' ? -1 : 1) * durationMs(/^\d+(\.\d+)?$/.test(rel[2]) ? Number(rel[2]) : rel[2]);
    } catch {
      return 0;
    }
  }
  const t = Date.parse(v);
  return Number.isFinite(t) ? t - now : 0;
}

/** One slot of the clock: the same index, key and seed for every player inside [start, end) */
export interface ClockSlot {
  /** Slots since 1970-01-01 00:00 UTC */
  index: number;
  /** 'YYYY-MM-DD#n': the UTC day of its start and its number within that day (for a save, a log line) */
  key: string;
  /** ms */
  start: number;
  end: number;
  /** Seconds until the next slot (rounded up: what a countdown shows) */
  nextIn: number;
  /** The slot's own seed (mixed with the clock's salt) */
  seed: number;
}

/** A scheduled event: a fixed rhythm (every / daily / weekly) or a seeded chance per window; `lasts` ≤ its period */
export type ClockEventDef<D = unknown> = {
  id: string;
  lasts: Duration;
  /** The game's own payload (a rule, a multiplier): handed back on every occurrence */
  data?: D;
} & (
  | { every: Duration; offset?: Duration }
  /** 'HH:MM' UTC, every day */
  | { daily: string }
  /** 'SAT 18:00' UTC, every week */
  | { weekly: string }
  /** Each window of `per` (default: the clock's slot) holds the event with this chance, from its start: a seeded surprise, the same for everyone */
  | { chance: number; per?: Duration }
);

/** One occurrence of an event */
export interface ClockOccurrence<D = unknown> {
  id: string;
  /** ms */
  start: number;
  end: number;
  /** Running at the moment asked */
  active: boolean;
  /** Seconds until it starts (0 when active) and until it ends */
  startsIn: number;
  endsIn: number;
  data: D | undefined;
}

export interface ScheduleState<D = unknown> {
  /** The events running now */
  active: ClockOccurrence<D>[];
  /** The next occurrence of each event that is not running (soonest first); a chance event with none in reach is left out */
  upcoming: ClockOccurrence<D>[];
}

export interface Schedule<D = unknown> {
  state(at?: number): ScheduleState<D>;
  /** The event `id` is running */
  active(id: string, at?: number): boolean;
  /** Its occurrence now (running) or the next one; null for a chance event with none in reach */
  next(id: string, at?: number): ClockOccurrence<D> | null;
}

/** A weather state: how often it comes (weight) and how long it lasts (a duration, or [shortest, longest]) */
export interface WeatherStateDef<Id extends string = string> {
  id: Id;
  weight: number;
  lasts: Duration | readonly [Duration, Duration];
}

export interface WeatherOptions<Id extends string = string> {
  /** Names the sequence (two weathers of one game differ): default 'weather' */
  id?: string;
  states: readonly WeatherStateDef<Id>[];
  /** The sequence is drawn per cycle (default '1d', UTC): a cycle starts a fresh draw. At least the longest state */
  cycle?: Duration;
  /** Lengths are whole steps (default '1m') */
  step?: Duration;
  /** The same state twice in a row (default false: a change is a change) */
  repeat?: boolean;
}

/** A stretch of one weather state */
export interface WeatherSpan<Id extends string = string> {
  id: Id;
  /** ms */
  start: number;
  end: number;
}

export interface WeatherNow<Id extends string = string> {
  id: Id;
  /** ms: when it began and when it ends */
  since: number;
  until: number;
  /** Seconds left */
  endsIn: number;
  /** What comes after it */
  next: { id: Id; at: number; startsIn: number };
}

export interface Weather<Id extends string = string> {
  state(at?: number): WeatherNow<Id>;
  /** The next `n` stretches from now (the current one first): a forecast strip */
  forecast(n: number, at?: number): WeatherSpan<Id>[];
  /** Share of the time each state holds in the long run (weight × mean length): for a "storms 8 % of the time" line */
  shares(): { id: Id; share: number }[];
}

export interface WorldClockOptions {
  /** The game's id: mixed into every seed, so two games don't share their slots */
  salt: string;
  /** The slot length (default '5m'; at least 1 minute) */
  every?: Duration;
  /** The clock in ms (default Date.now): inject one in tests and bots */
  now?: () => number;
  /** Added to `now()`: QA's and dev's time travel (`clockShift(location.search)`); 0 for players */
  offsetMs?: number;
}

export interface WorldClock {
  readonly salt: string;
  /** The slot length in ms */
  readonly everyMs: number;
  /** ms, with the offset */
  now(): number;
  /** The slot of a moment (default now), of the clock's length or of another (`slot('1h')`) */
  slot(every?: Duration, at?: number): ClockSlot;
  /** A seed for a named stream at a slot index (the same for every player): a stock, a rival, a sky */
  seed(name: string, index: number): number;
  /** A seeded random source for a named stream at a slot index */
  rng(name: string, index: number): ReturnType<typeof seededRng>;
  /** A schedule of events (the definitions are checked once, here) */
  schedule<D = unknown>(defs: readonly ClockEventDef<D>[]): Schedule<D>;
  /** schedule(defs).state(at) */
  events<D = unknown>(defs: readonly ClockEventDef<D>[], at?: number): ScheduleState<D>;
  /** A seeded weather sequence */
  weather<Id extends string>(opts: WeatherOptions<Id>): Weather<Id>;
}

const hhmm = (s: string, what: string): number => {
  const m = /^(\d{1,2}):(\d{2})$/.exec(s.trim());
  if (!m || +m[1] > 23 || +m[2] > 59) throw new Error(`${what}: '${s}' — write the UTC time as HH:MM, like 18:00`);
  return (+m[1] * 60 + +m[2]) * 60000;
};

interface Rhythm {
  period: number;
  offset: number;
}

/** A schedule's problems (empty: fine): duplicate ids, lengths longer than their period, unreadable times */
export function checkSchedule(defs: readonly ClockEventDef[]): string[] {
  const out: string[] = [];
  const ids = new Set<string>();
  for (const d of defs) {
    if (!d.id || ids.has(d.id)) out.push(d.id ? `the event id '${d.id}' twice` : 'an event without an id');
    ids.add(d.id);
    try {
      const lasts = durationMs(d.lasts);
      if (!(lasts > 0)) out.push(`${d.id}: lasts must be longer than 0`);
      if ('chance' in d) {
        if (!(d.chance >= 0 && d.chance <= 1)) out.push(`${d.id}: chance is a share 0 … 1`);
        if (d.per !== undefined && lasts > durationMs(d.per)) out.push(`${d.id}: lasts longer than its window (per)`);
      } else {
        const r = rhythmOf(d);
        if (lasts > r.period) out.push(`${d.id}: lasts longer than its period`);
      }
    } catch (e) {
      out.push(`${d.id}: ${(e as Error).message}`);
    }
  }
  return out;
}

function rhythmOf(d: ClockEventDef): Rhythm {
  if ('every' in d) {
    const period = durationMs(d.every);
    if (!(period >= 60000)) throw new Error('every is at least 1 minute');
    return { period, offset: durationMs(d.offset ?? 0) % period };
  }
  if ('daily' in d) return { period: DAY_MS, offset: hhmm(d.daily, 'daily') };
  if ('weekly' in d) {
    const m = /^([A-Za-z]{3})\w*\s+(.+)$/.exec(d.weekly.trim());
    const day = m ? WEEKDAYS.indexOf(m[1].toUpperCase()) : -1;
    if (!m || day < 0) throw new Error(`weekly: '${d.weekly}' — write a weekday and a UTC time, like SAT 18:00`);
    return { period: WEEK_MS, offset: (MONDAY_MS + day * DAY_MS + hhmm(m[2], 'weekly')) % WEEK_MS };
  }
  throw new Error('an event needs every, daily, weekly or chance');
}

/** How many windows ahead a chance event is looked for (a chance of 1 in 1000 per window has none in reach, mostly) */
const CHANCE_REACH = 2000;

/** The world clock: see the module's comment */
export function worldClock(opts: WorldClockOptions): WorldClock {
  if (!opts.salt) throw new Error('worldClock: salt (the game id) is required');
  const everyMs = durationMs(opts.every ?? '5m');
  if (!(everyMs >= 60000)) throw new Error('worldClock: every is at least 1 minute (a restock every few seconds is a spinner, not a clock)');
  const base = opts.now ?? Date.now;
  const offset = Number.isFinite(opts.offsetMs) ? (opts.offsetMs as number) : 0;
  const now = () => base() + offset;
  const seed = (name: string, index: number) => daySeed(String(index), `${opts.salt}:${name}`);
  const secs = (ms: number) => Math.max(0, Math.ceil(ms / 1000 - 1e-9));

  const slot = (every?: Duration, at?: number): ClockSlot => {
    const len = every === undefined ? everyMs : durationMs(every);
    if (!(len >= 1000)) throw new Error('slot: a length of at least 1 second');
    const t = at ?? now();
    const index = Math.floor(t / len);
    const start = index * len;
    const day = Math.floor(start / DAY_MS) * DAY_MS;
    return {
      index,
      key: `${dayKey(new Date(start))}#${Math.floor((start - day) / len)}`,
      start,
      end: start + len,
      nextIn: secs(start + len - t),
      seed: seed(`slot:${len}`, index),
    };
  };

  const schedule = <D>(defs: readonly ClockEventDef<D>[]): Schedule<D> => {
    const problems = checkSchedule(defs as readonly ClockEventDef[]);
    for (const d of defs) if ('chance' in d && d.per === undefined && durationMs(d.lasts) > everyMs) problems.push(`${d.id}: lasts longer than its window (the clock's slot)`);
    if (problems.length) throw new Error(`schedule: ${problems.join('; ')}`);
    const occ = (d: ClockEventDef<D>, start: number, t: number): ClockOccurrence<D> => {
      const end = start + durationMs(d.lasts);
      const active = t >= start && t < end;
      return { id: d.id, start, end, active, startsIn: active ? 0 : secs(start - t), endsIn: secs(end - t), data: d.data };
    };
    /** The occurrence running at t, and the next one to start after t */
    const around = (d: ClockEventDef<D>, t: number): { now: ClockOccurrence<D> | null; next: ClockOccurrence<D> | null } => {
      if ('chance' in d) {
        const per = d.per === undefined ? everyMs : durationMs(d.per);
        const hit = (k: number) => seededRng(seed(`event:${d.id}`, k))() < d.chance;
        const k = Math.floor(t / per);
        const cur = hit(k) ? occ(d, k * per, t) : null;
        let next: ClockOccurrence<D> | null = null;
        for (let j = k + 1; j <= k + CHANCE_REACH; j++)
          if (hit(j)) {
            next = occ(d, j * per, t);
            break;
          }
        return { now: cur?.active ? cur : null, next };
      }
      const r = rhythmOf(d as ClockEventDef);
      const k = Math.floor((t - r.offset) / r.period);
      const cur = occ(d, r.offset + k * r.period, t);
      return { now: cur.active ? cur : null, next: occ(d, r.offset + (k + 1) * r.period, t) };
    };
    const state = (at?: number): ScheduleState<D> => {
      const t = at ?? now();
      const active: ClockOccurrence<D>[] = [];
      const upcoming: ClockOccurrence<D>[] = [];
      for (const d of defs) {
        const a = around(d, t);
        if (a.now) active.push(a.now);
        if (a.next) upcoming.push(a.next);
      }
      upcoming.sort((a, b) => a.start - b.start);
      return { active, upcoming };
    };
    const def = (id: string) => {
      const d = defs.find((x) => x.id === id);
      if (!d) throw new Error(`schedule: no event '${id}'`);
      return d;
    };
    return {
      state,
      active: (id, at) => !!around(def(id), at ?? now()).now,
      next(id, at) {
        const a = around(def(id), at ?? now());
        return a.now ?? a.next;
      },
    };
  };

  const weather = <Id extends string>(w: WeatherOptions<Id>): Weather<Id> => {
    const states = w.states.filter((s) => s.weight > 0);
    if (!states.length) throw new Error('weather: no state with a weight above 0');
    const ids = new Set<string>();
    for (const s of w.states) {
      if (ids.has(s.id)) throw new Error(`weather: the state '${s.id}' twice`);
      ids.add(s.id);
    }
    const step = Math.max(1000, durationMs(w.step ?? '1m'));
    const range = (s: WeatherStateDef<Id>): [number, number] => {
      const [a, b] = Array.isArray(s.lasts) ? (s.lasts as readonly [Duration, Duration]).map(durationMs) : [durationMs(s.lasts as Duration), durationMs(s.lasts as Duration)];
      const lo = Math.max(step, Math.min(a, b));
      return [lo, Math.max(lo, Math.max(a, b))];
    };
    const ranges = new Map(states.map((s) => [s.id, range(s)]));
    const cycle = durationMs(w.cycle ?? '1d');
    const longest = Math.max(...[...ranges.values()].map((r) => r[1]));
    if (cycle < longest) throw new Error(`weather: the cycle (${cycle / 1000} s) is shorter than the longest state (${longest / 1000} s)`);
    const name = `weather:${w.id ?? 'weather'}`;
    const total = states.reduce((a, s) => a + s.weight, 0);
    const cache = new Map<number, WeatherSpan<Id>[]>();
    const spansOf = (e: number): WeatherSpan<Id>[] => {
      const hit = cache.get(e);
      if (hit) return hit;
      const r = seededRng(seed(name, e));
      const start = e * cycle;
      const end = start + cycle;
      const out: WeatherSpan<Id>[] = [];
      let prev: Id | null = null;
      for (let t = start; t < end; ) {
        const pool: WeatherStateDef<Id>[] = !w.repeat && prev !== null && states.length > 1 ? states.filter((s) => s.id !== prev) : states;
        const sum = pool === states ? total : pool.reduce((a, s) => a + s.weight, 0);
        let x = r() * sum;
        let pick: WeatherStateDef<Id> = pool[pool.length - 1];
        for (const s of pool) if ((x -= s.weight) < 0) {
          pick = s;
          break;
        }
        const [lo, hi] = ranges.get(pick.id)!;
        const len = Math.max(step, Math.round((lo + r() * (hi - lo)) / step) * step);
        out.push({ id: pick.id, start: t, end: Math.min(end, t + len) });
        prev = pick.id;
        t += len;
      }
      if (cache.size > 4) cache.delete(cache.keys().next().value as number);
      cache.set(e, out);
      return out;
    };
    /**
     * Stretches from the one holding t on, merged across a cycle's edge when the state goes on (a state that never
     * changes — one state only — is cut a few cycles ahead, so the walk always ends)
     */
    const walk = (t: number, n: number): WeatherSpan<Id>[] => {
      const e0 = Math.floor(t / cycle);
      let e = e0;
      let list = spansOf(e);
      let i = list.findIndex((s) => t >= s.start && t < s.end);
      const first = { ...list[i] };
      // The stretch may have begun in an earlier cycle
      for (let b = e0; b > e0 - 3 && first.start === b * cycle; b--) {
        const prev = spansOf(b - 1);
        const p = prev[prev.length - 1];
        if (p.id !== first.id) break;
        first.start = p.start;
      }
      const out: WeatherSpan<Id>[] = [first];
      i++;
      for (;;) {
        if (i >= list.length) {
          if (e - e0 > n + 2) break;
          list = spansOf(++e);
          i = 0;
        }
        const s = list[i];
        const last = out[out.length - 1];
        if (last.id === s.id && last.end === s.start) {
          last.end = s.end;
          i++;
          continue;
        }
        if (out.length >= n) break;
        out.push({ ...s });
        i++;
      }
      return out;
    };
    return {
      state(at) {
        const t = at ?? now();
        const [cur, after] = walk(t, 2);
        const nxt = after ?? { id: cur.id, start: cur.end };
        return { id: cur.id, since: cur.start, until: cur.end, endsIn: secs(cur.end - t), next: { id: nxt.id, at: nxt.start, startsIn: secs(nxt.start - t) } };
      },
      forecast: (n, at) => walk(at ?? now(), Math.max(1, Math.floor(n))),
      shares() {
        const mass = states.map((s) => {
          const [lo, hi] = ranges.get(s.id)!;
          return { id: s.id, m: s.weight * ((lo + hi) / 2) };
        });
        const sum = mass.reduce((a, s) => a + s.m, 0);
        return w.states.map((s) => ({ id: s.id, share: (mass.find((m) => m.id === s.id)?.m ?? 0) / sum }));
      },
    };
  };

  return {
    salt: opts.salt,
    everyMs,
    now,
    slot,
    seed,
    rng: (name, index) => seededRng(seed(name, index)),
    schedule,
    events: (defs, at) => schedule(defs).state(at),
    weather,
  };
}
