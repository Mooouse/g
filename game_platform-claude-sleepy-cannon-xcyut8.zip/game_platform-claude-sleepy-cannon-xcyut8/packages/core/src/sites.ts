// Several places of one idle game — garages of a network, shops of a town, planets — each with its own upgrade levels
// (an UpgradeShop per site), its unlock price and tier, and one shared wallet. Pure (no DOM): usable from the game,
// unit tests and balance bots. The rules (docs/guides/upgrades.md → Idle games → Several places: Sites):
//
// - a site's income per second comes from its numbers (its levels, its tier, the game's own per-site data) through the
//   game's own `rate()` — never from its scene, so the sites the player isn't in earn too (tick) and so does the time
//   away (offline: clamped hours, a share);
// - each site's levels are its own: buying in one never changes another; the wallet is shared;
// - the save is one JSON object (a record per open site) and every load is sanitised: unknown sites, wrong types and
//   levels past the max go; a free site is always open;
// - a game that had one place moves its old save into site 0 (migrate), so an update keeps every player's progress.
//
// From Idle Garage Evolution 1.3 → 1.4 (QmaCyber/game19: economy.ts sites/siteRate/offline), which wrote all of it
// by hand. The ready map screen is mountSitesMap (sites-map.ts).

import { measuringOffline } from './offline.ts';
import { mergeShape } from './save.ts';
import type { BuyAmount, Levels, UpgradeShop } from './upgrades.ts';

/**
 * The genres this block is for (a genre registry lists it): sites and their map are a shape of idle games.
 * @genre idle
 */
export const SITES_GENRES = ['idle'] as const;

/** One place of the game, as data */
export interface SiteDef<S extends string = string> {
  id: S;
  /** Its price from the shared wallet; 0 = open from the start. The first site must be free: it is where a new player plays */
  price: number;
  /** The game's meaning of a tier (a garage level, a planet's ring): given to `shop`, `start` and `rate` (default 1) */
  tier?: number;
  /** Needs this site open first */
  requires?: S;
}

/** One open site in the save */
export interface SiteSave<U extends string = string, D = Record<string, unknown>> {
  levels: Levels<U>;
  /** What it earned in total (scene, background, offline) */
  earned: number;
  /** The game's own record of it (its `data` defaults' shape) */
  data: D;
}

/** The whole save of the sites: put it into the game's save as one field */
export interface SitesSave<S extends string = string, U extends string = string, D = Record<string, unknown>> {
  v: 1;
  coins: number;
  /** The site the player is in */
  at: S;
  /** Every open site (a missing one is closed) */
  sites: Partial<Record<S, SiteSave<U, D>>>;
  /** ms timestamp of the last save (offline income) */
  seen: number;
}

/** A save of a game that had one place: its wallet and its levels (and, optionally, its own record and timestamp) */
export interface SingleSiteSave<U extends string = string, D = Record<string, unknown>> {
  coins?: number;
  levels?: Partial<Levels<U>>;
  data?: Partial<D>;
  seen?: number;
  earned?: number;
}

export type SiteState = 'open' | 'affordable' | 'too-expensive' | 'locked';

/** One pin of the map or one row of a sites list: everything it shows, computed in one place */
export interface SiteRow<S extends string = string> {
  id: S;
  state: SiteState;
  /** The site the player is in */
  here: boolean;
  tier: number;
  /** Its price (0 for a free one) */
  price: number;
  /** 0..1 towards the price (a bar: the goal-gradient); 1 when open */
  progress: number;
  /** Its level as the game counts it (default: the levels bought in its shop); 0 when closed */
  level: number;
  /** Its income per second now (0 when closed) */
  rate: number;
  earned: number;
  /** The next site to open (the first one in order that is neither open nor locked) */
  next: boolean;
  /** Why it is locked: its requirement's id, or the game's own reason */
  needs?: S;
  lockReason?: string;
}

/** What the time away earned: show it (welcomeBack's lines, a card with a ×2 rewarded offer), then collect() it */
export interface SitesOffline<S extends string = string> {
  /** Seconds counted (clamped to maxHours) */
  sec: number;
  /** Seconds really away (unclamped) */
  awaySec: number;
  coins: number;
  /** Each site's part (only those that earned) */
  bySite: Partial<Record<S, number>>;
  /** The time it was measured at: collect() moves the save's timestamp there, so it can't be collected twice */
  now: number;
}

export interface SitesOptions<S extends string, U extends string, D> {
  /** Each site's level shop: one for all sites, or one per site (a tier's own caps and prices) */
  shop: UpgradeShop<U> | ((site: SiteDef<S>) => UpgradeShop<U>);
  /**
   * Income per second of one open site from its numbers — its levels, tier and data — without its scene: the game's own
   * formula (an average job's value ÷ its time; prestige multipliers from the closure). Called often (every tick, every
   * pin): keep it cheap or cache it inside. A non-finite or negative result counts as 0
   */
  rate(site: SiteDef<S>, levels: Levels<U>, data: D): number;
  /** The levels a site opens with (default all 0): a higher tier may start with its basic kit */
  start?(site: SiteDef<S>): Partial<Levels<U>>;
  /** The defaults of the game's own record per site (cars restored, a name the player gave it): loaded through mergeShape */
  data?: D;
  /** The game's own unlock condition (a prestige reached, a story flag): why `site` is still locked, or null */
  lock?(site: SiteDef<S>, sites: Sites<S, U, D>): string | null;
  /** A site's level as the map shows it (default: the levels bought in its shop) */
  level?(site: SiteDef<S>, levels: Levels<U>, data: D): number;
  /**
   * The site the player is in earns through its scene (the game credits it with earn()): tick() then pays only the
   * others. Default false: tick() pays every open site
   */
  scenePays?: boolean;
  /** Offline income: at most `maxHours` (default 8), at `share` of the rate (default 0.6), nothing under `minSec` (default 60) */
  offline?: { maxHours?: number; share?: number; minSec?: number };
}

const OFFLINE_DEFAULTS = { maxHours: 8, share: 0.6, minSec: 60 };

const num = (v: unknown, d = 0): number => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});
const income = (n: number): number => (Number.isFinite(n) && n > 0 ? n : 0);

/**
 * Several places of one idle game with one wallet: each site's own levels, unlock price and tier; income per second from
 * the numbers (`rate(id)`, `totalRate()`); `tick(dt)` pays the sites without their scenes; offline income over all sites;
 * a sanitised save per site; `migrate()` moves a one-place save into site 0. Stateful (it holds the wallet): keep one per
 * game, save `sites.save()` into your save, `load()` it back.
 *
 *   const sites = new Sites(SITES, { shop: (s) => shopFor(s.tier), rate: (s, levels) => perSec(s, levels) });
 *   sites.load(save.sites, { legacy: () => ({ coins: save.coins, levels: save.levels }) }); // 1.3's single garage → site 0
 *   function frame(dt) { sites.tick(dt); … }                                                // in the game's own loop
 *
 * @genre idle
 */
export class Sites<S extends string = string, U extends string = string, D = Record<string, unknown>> {
  readonly defs: readonly SiteDef<S>[];
  private readonly byId: Map<S, SiteDef<S>>;
  private readonly shops = new Map<S, UpgradeShop<U>>();
  private readonly opts: SitesOptions<S, U, D>;
  private readonly off: { maxHours: number; share: number; minSec: number };
  private wallet = 0;
  private here: S;
  private state = new Map<S, SiteSave<U, D>>();
  private seen = 0;

  constructor(defs: readonly SiteDef<S>[], opts: SitesOptions<S, U, D>) {
    if (!defs.length) throw new Error('sites: at least one site');
    const ids = new Set<S>();
    for (const d of defs) {
      if (typeof d.id !== 'string' || !d.id) throw new Error('sites: every id must be a non-empty string');
      if (ids.has(d.id)) throw new Error(`site ${d.id} is defined twice`);
      ids.add(d.id);
      if (!(Number.isFinite(d.price) && d.price >= 0)) throw new Error(`site ${d.id}: price must be ≥ 0`);
      if (d.tier !== undefined && !Number.isFinite(d.tier)) throw new Error(`site ${d.id}: tier must be a number`);
    }
    for (const d of defs) if (d.requires !== undefined && (!ids.has(d.requires) || d.requires === d.id)) throw new Error(`site ${d.id} requires unknown ${d.requires}`);
    if (defs[0].price !== 0) throw new Error(`sites: the first site (${defs[0].id}) must be free (price 0): a new player starts there and migrate() moves a one-place save into it`);
    this.defs = defs;
    this.byId = new Map(defs.map((d) => [d.id, d]));
    this.opts = opts;
    this.off = { ...OFFLINE_DEFAULTS, ...opts.offline };
    if (!(this.off.maxHours >= 0 && this.off.share >= 0 && this.off.minSec >= 0)) throw new Error('sites: offline maxHours, share and minSec must be ≥ 0');
    for (const d of defs) {
      const shop = typeof opts.shop === 'function' ? opts.shop(d) : opts.shop;
      this.shops.set(d.id, shop);
    }
    this.here = defs[0].id;
    this.load(null);
  }

  // --- The places

  /** A site's definition */
  site(id: S): SiteDef<S> {
    const d = this.byId.get(id);
    if (!d) throw new Error(`unknown site ${id}`);
    return d;
  }

  /** A site's level shop (the same object every call) */
  shop(id: S): UpgradeShop<U> {
    this.site(id);
    return this.shops.get(id)!;
  }

  isOpen(id: S): boolean {
    this.site(id);
    return this.state.has(id);
  }

  /** The open sites, in definition order */
  openIds(): S[] {
    return this.defs.filter((d) => this.state.has(d.id)).map((d) => d.id);
  }

  /** The site the player is in */
  get at(): S {
    return this.here;
  }

  /** Go to an open site (its scene is the game's); false when it isn't open */
  travel(id: S): boolean {
    if (!this.isOpen(id)) return false;
    this.here = id;
    return true;
  }

  /** A site's levels (a copy; all 0 when closed) */
  levels(id: S = this.here): Levels<U> {
    const st = this.state.get(id);
    return st ? { ...st.levels } : this.shop(id).noLevels();
  }

  /** Store a site's new levels (sanitised by its shop); false when it isn't open */
  setLevels(id: S, levels: Partial<Levels<U>>): boolean {
    const st = this.state.get(id);
    if (!st) return false;
    st.levels = this.shop(id).sanitize(levels);
    return true;
  }

  /** The game's own record of an open site — the live object: change it, then save (null when closed) */
  data(id: S = this.here): D | null {
    return this.state.get(id)?.data ?? null;
  }

  /** What an open site earned in total (0 when closed) */
  earned(id: S): number {
    return this.state.get(id)?.earned ?? 0;
  }

  /** A site's level as the game counts it (the `level` option; default the levels bought in its shop); 0 when closed */
  level(id: S): number {
    const st = this.state.get(id);
    if (!st) return 0;
    const d = this.site(id);
    if (this.opts.level) return income(this.opts.level(d, { ...st.levels }, st.data));
    return this.shop(id).defs.reduce((a, u) => a + st.levels[u.id], 0);
  }

  // --- The wallet

  /** The shared wallet (may hold fractions of a coin from income per second: show it with formatAmount, rounded down) */
  get coins(): number {
    return this.wallet;
  }

  set coins(n: number) {
    this.wallet = Math.max(0, num(n));
  }

  /** Credit coins a site earned through its scene (a car restored): to the wallet and the site's total */
  earn(amount: number, id: S = this.here): void {
    const a = income(amount);
    this.wallet += a;
    const st = this.state.get(id);
    if (st) st.earned += a;
  }

  /** Buy levels of an upgrade in a site (default the one the player is in) from the shared wallet; the levels bought, or 0 */
  buy(upgrade: U, amount: BuyAmount = 1, id: S = this.here): number {
    const st = this.state.get(id);
    if (!st) return 0;
    const r = this.shop(id).buy(upgrade, st.levels, this.wallet, amount);
    if (!r) return 0;
    st.levels = r.levels;
    this.wallet = r.coins;
    return r.bought;
  }

  /** Give back the last `n` levels of an upgrade in a site at exactly their price (undo); false when nothing went back */
  refund(upgrade: U, n = 1, id: S = this.here): boolean {
    const st = this.state.get(id);
    if (!st) return false;
    const r = this.shop(id).refund(upgrade, st.levels, this.wallet, n);
    if (!r) return false;
    st.levels = r.levels;
    this.wallet = r.coins;
    return true;
  }

  /**
   * The shop of one site wired to the shared wallet, for mountUpgradeShop: `mountUpgradeShop(ui, { ...sites.shopFor(),
   * items, minTouchPx, onBack })`. `save` is called after every purchase (host.save)
   */
  shopFor(id: S = this.here, save?: () => void): { shop: UpgradeShop<U>; get(): { levels: Levels<U>; coins: number }; set(levels: Levels<U>, coins: number): void } {
    return {
      shop: this.shop(id),
      get: () => ({ levels: this.levels(id), coins: this.wallet }),
      set: (levels, coins) => {
        this.setLevels(id, levels);
        this.coins = coins;
        save?.();
      },
    };
  }

  // --- Opening sites

  /** Why a closed site can't be opened yet: its requirement (`needs`) or the game's own reason; null when it can */
  lockReason(id: S): { needs?: S; reason?: string } | null {
    const d = this.site(id);
    if (d.requires && !this.state.has(d.requires)) return { needs: d.requires };
    const r = this.opts.lock?.(d, this);
    return r ? { reason: r } : null;
  }

  siteState(id: S): SiteState {
    if (this.isOpen(id)) return 'open';
    if (this.lockReason(id)) return 'locked';
    return this.site(id).price <= this.wallet ? 'affordable' : 'too-expensive';
  }

  /** Pay a site's price and open it (with its `start` levels); false when it can't be bought now. Doesn't travel there */
  unlock(id: S): boolean {
    if (this.siteState(id) !== 'affordable') return false;
    this.wallet -= this.site(id).price;
    this.state.set(id, this.fresh(this.site(id)));
    return true;
  }

  /** The next site to open: the first in order that is neither open nor locked (the HUD's goal); null when none */
  next(): S | null {
    return this.defs.find((d) => !this.state.has(d.id) && !this.lockReason(d.id))?.id ?? null;
  }

  /** Share of the sites open, 0..1 */
  progress(): number {
    return this.state.size / this.defs.length;
  }

  private fresh(d: SiteDef<S>): SiteSave<U, D> {
    const shop = this.shops.get(d.id)!;
    return { levels: shop.sanitize(this.opts.start?.(d) ?? {}), earned: 0, data: this.dataOf(undefined) };
  }

  private dataOf(raw: unknown): D {
    return this.opts.data === undefined ? ({} as D) : mergeShape(this.opts.data, raw ?? null);
  }

  // --- Income

  /** A site's income per second from its numbers (0 when closed) */
  rate(id: S): number {
    const st = this.state.get(id);
    if (!st) return 0;
    return income(this.opts.rate(this.site(id), { ...st.levels }, st.data));
  }

  /** Every open site's income per second, the one the player is in too */
  totalRate(): number {
    return this.openIds().reduce((a, id) => a + this.rate(id), 0);
  }

  /** What tick() pays per second: every open site, or (scenePays) all but the one the player is in */
  backgroundRate(): number {
    return this.openIds().reduce((a, id) => a + (this.opts.scenePays && id === this.here ? 0 : this.rate(id)), 0);
  }

  /** Pay `dt` seconds of income of the sites without their scenes (call it every frame or every second); the coins paid */
  tick(dt: number): number {
    const s = income(dt);
    if (!s) return 0;
    let paid = 0;
    for (const id of this.openIds()) {
      if (this.opts.scenePays && id === this.here) continue;
      const a = this.rate(id) * s;
      if (!a) continue;
      this.state.get(id)!.earned += a;
      paid += a;
    }
    this.wallet += paid;
    return paid;
  }

  /**
   * What the time since the last save earned at every open site (the one the player was in too): the rate × the
   * share × the time away, clamped to maxHours; null under minSec, before the first save, or when the clock went back.
   * Doesn't pay: show it, then collect() it (×2 for a rewarded ad)
   */
  offline(now: number = Date.now()): SitesOffline<S> | null {
    if (!this.seen || !Number.isFinite(now)) return null;
    const awaySec = (now - this.seen) / 1000;
    if (!(awaySec >= this.off.minSec) || awaySec <= 0) return null;
    const sec = Math.min(awaySec, this.off.maxHours * 3600);
    const bySite: Partial<Record<S, number>> = {};
    let coins = 0;
    for (const id of this.openIds()) {
      // Measured as offline: a timed boost answers ×1 inside it (rewards.ts timedBoost)
      const a = measuringOffline(() => this.rate(id)) * sec * this.off.share;
      if (a <= 0) continue;
      bySite[id] = a;
      coins += a;
    }
    if (coins <= 0) return null;
    return { sec, awaySec, coins, bySite, now };
  }

  /** Pay what offline() measured, × `mult` (2 after a rewarded ad); the coins paid. Its time becomes the last save's */
  collect(off: SitesOffline<S>, mult = 1): number {
    if (!(off.now > this.seen)) return 0;
    const m = income(mult);
    let paid = 0;
    for (const [id, a] of Object.entries(off.bySite) as [S, number][]) {
      const st = this.state.get(id);
      if (!st) continue;
      st.earned += a * m;
      paid += a * m;
    }
    this.wallet += paid;
    this.seen = off.now;
    return paid;
  }

  // --- The map's rows

  /** A row per site, in definition order: its state, price, progress, level, income — what a pin or a list card shows */
  rows(): SiteRow<S>[] {
    const next = this.next();
    return this.defs.map((d) => {
      const state = this.siteState(d.id);
      const lock = state === 'locked' ? this.lockReason(d.id) : null;
      return {
        id: d.id,
        state,
        here: d.id === this.here,
        tier: d.tier ?? 1,
        price: d.price,
        progress: state === 'open' || d.price === 0 ? 1 : Math.min(1, this.wallet / d.price),
        level: this.level(d.id),
        rate: this.rate(d.id),
        earned: this.earned(d.id),
        next: d.id === next,
        ...(lock?.needs ? { needs: lock.needs } : {}),
        ...(lock?.reason ? { lockReason: lock.reason } : {}),
      };
    });
  }

  // --- The save

  /** The save (JSON-safe), stamped with `now` for offline income: put it into the game's save, host.save() it */
  save(now: number = Date.now()): SitesSave<S, U, D> {
    if (Number.isFinite(now) && now > 0) this.seen = now;
    const sites: Partial<Record<S, SiteSave<U, D>>> = {};
    for (const id of this.openIds()) {
      const st = this.state.get(id)!;
      sites[id] = { levels: { ...st.levels }, earned: st.earned, data: structuredClone(st.data) };
    }
    return { v: 1, coins: this.wallet, at: this.here, sites, seen: this.seen };
  }

  /** A sites save: an object with a `sites` record (a one-place save has none) */
  static isSave(raw: unknown): boolean {
    const r = record(raw);
    return !!r.sites && typeof r.sites === 'object' && !Array.isArray(r.sites);
  }

  /**
   * Load a save, sanitised: unknown sites dropped, levels through each site's shop, the game's data through its
   * defaults, the free sites always open, the player in an open site. Nothing saved yet (null) → a new game.
   * `legacy`: whenever `raw` isn't a sites save (an old save has no `sites` field: `raw` is then undefined), it is asked
   * for the one-place version's wallet and levels, which go into site 0 (migrate); return null for nothing to move
   */
  load(raw: unknown, opts: { legacy?: (raw: unknown) => SingleSiteSave<U, D> | null } = {}): this {
    if (!Sites.isSave(raw) && opts.legacy) {
      const old = opts.legacy(raw);
      if (old) return this.migrate(old);
    }
    const r = record(raw);
    const stored = record(r.sites);
    this.state = new Map();
    for (const d of this.defs) {
      const st = stored[d.id];
      if (st && typeof st === 'object' && !Array.isArray(st)) {
        const s = record(st);
        this.state.set(d.id, {
          levels: this.shops.get(d.id)!.sanitize(record(s.levels) as Partial<Levels<U>>),
          earned: Math.max(0, num(s.earned)),
          data: this.dataOf(s.data),
        });
      } else if (d.price === 0) this.state.set(d.id, this.fresh(d));
    }
    this.wallet = Math.max(0, num(r.coins));
    this.seen = Math.max(0, num(r.seen));
    const at = r.at as S;
    this.here = typeof at === 'string' && this.state.has(at) ? at : this.openIds()[0];
    return this;
  }

  /**
   * Move a save of the one-place version into site 0 (the first, free site): its wallet, levels, own data and
   * timestamp. The other free sites open fresh, the rest stay closed. The game's next save() writes the new shape
   */
  migrate(old: SingleSiteSave<U, D>): this {
    const first = this.defs[0];
    const o = record(old);
    this.load(null);
    const st = this.state.get(first.id)!;
    st.levels = this.shops.get(first.id)!.sanitize(record(o.levels) as Partial<Levels<U>>);
    st.earned = Math.max(0, num(o.earned));
    st.data = this.dataOf(o.data);
    this.wallet = Math.max(0, num(o.coins));
    this.seen = Math.max(0, num(o.seen));
    this.here = first.id;
    return this;
  }

  /** Start over (a prestige): every site closed but the free ones, fresh; the wallet at `coins` (default 0) */
  reset(coins = 0): void {
    const seen = this.seen;
    this.load(null);
    this.wallet = Math.max(0, num(coins));
    this.seen = seen;
  }
}
