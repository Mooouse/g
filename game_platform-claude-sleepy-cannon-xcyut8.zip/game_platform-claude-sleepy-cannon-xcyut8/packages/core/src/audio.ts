// Sounds are synthesized with WebAudio — no sound files at all. Soft volume, no harsh sounds.
// The sound names (pop, tap, nope, win, star, sparkle, firework) are the platform's sound library.
// Voice: speechSynthesis in the browser, the system TTS via a plugin in the Android app
// (speechSynthesis does not work in Android WebView).

import { Capacitor } from '@capacitor/core';
import { rng } from './rng';

interface Speaker {
  speak(text: string): void;
  stop(): void;
}

class WebSpeaker implements Speaker {
  private voices: SpeechSynthesisVoice[] = [];

  constructor(private readonly lang: string) {
    const load = () => (this.voices = speechSynthesis.getVoices());
    load();
    speechSynthesis.addEventListener?.('voiceschanged', load);
  }

  speak(text: string): void {
    const code = this.lang;
    const prefix = code.slice(0, 2);
    const voice =
      this.voices.find((v) => v.lang.replace('_', '-') === code) ??
      this.voices.find((v) => v.lang.toLowerCase().startsWith(prefix));
    // No voice for the language — better stay silent than read the word with a foreign accent
    if (!voice && this.voices.length > 0) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = code;
    if (voice) u.voice = voice;
    u.rate = 0.9;
    u.pitch = 1.15;
    speechSynthesis.speak(u);
  }

  stop(): void {
    speechSynthesis.cancel();
  }
}

class NativeSpeaker implements Speaker {
  private tts = import('@capacitor-community/text-to-speech');

  constructor(private readonly lang: string) {}

  // The plugin itself rejects if there's no voice for the language or TTS isn't ready yet — then stay silent.
  // No upfront language check: on a cold start it falsely says "no" and the voice would be lost for the session.
  speak(text: string): void {
    void this.tts
      .then(({ TextToSpeech, QueueStrategy }) =>
        TextToSpeech.speak({
          text,
          lang: this.lang,
          rate: 0.9,
          pitch: 1.15,
          volume: 1,
          queueStrategy: QueueStrategy.Flush,
        }),
      )
      .catch(() => {});
  }

  stop(): void {
    void this.tts.then(({ TextToSpeech }) => TextToSpeech.stop()).catch(() => {});
  }
}

class SilentSpeaker implements Speaker {
  speak(): void {}
  stop(): void {}
}

export interface AudioSettings {
  sound(): boolean;
  voice(): boolean;
}

export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private paused = false;
  private readonly speaker: Speaker;

  /** lang — BCP 47 language for text-to-speech, e.g. "en-US" */
  constructor(
    private readonly settings: AudioSettings,
    lang: string,
  ) {
    if (Capacitor.isNativePlatform()) this.speaker = new NativeSpeaker(lang);
    else if ('speechSynthesis' in window) this.speaker = new WebSpeaker(lang);
    else this.speaker = new SilentSpeaker();
  }

  /** Call from a touch handler: browsers allow audio only after a user gesture */
  unlock(): void {
    if (!this.ctx) {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      this.ctx = new Ctx();
      const comp = this.ctx.createDynamicsCompressor();
      // A gentle glue, not a pump: a hard 6:1 with the default 3 ms attack squeezed every kick and made the bed breathe
      comp.threshold.value = -18;
      comp.knee.value = 24;
      comp.ratio.value = 3;
      comp.attack.value = 0.01;
      comp.release.value = 0.25;
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.55;
      this.master.connect(comp).connect(this.ctx.destination);
      this.noise = this.makeNoise(this.ctx);
    }
    if (!this.paused && this.ctx.state !== 'running') void this.ctx.resume().catch(() => {});
  }

  /** Pause while an ad is shown or the app is in the background */
  pause(): void {
    this.paused = true;
    this.speaker.stop();
    if (this.ctx?.state === 'running') void this.ctx.suspend().catch(() => {});
  }

  resume(): void {
    this.paused = false;
    if (this.ctx && this.ctx.state !== 'running') void this.ctx.resume().catch(() => {});
  }

  speak(text: string): void {
    if (this.paused || !this.settings.voice()) return;
    this.speaker.speak(text);
  }

  stopSpeech(): void {
    this.speaker.stop();
  }

  /** Pop (a balloon, a bubble): a soft noise "puff" plus a short low thump */
  pop(pitch = 1): void {
    const a = this.ready();
    if (!a) return;
    const { ctx, out, t } = a;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 1400 * pitch;
    bp.Q.value = 0.9;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.7, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
    src.connect(bp).connect(g).connect(out);
    src.start(t);
    src.stop(t + 0.16);

    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(260 * pitch, t);
    o.frequency.exponentialRampToValueAtTime(70, t + 0.12);
    const og = ctx.createGain();
    og.gain.setValueAtTime(0.0001, t);
    og.gain.exponentialRampToValueAtTime(0.45, t + 0.005);
    og.gain.exponentialRampToValueAtTime(0.0001, t + 0.13);
    o.connect(og).connect(out);
    o.start(t);
    o.stop(t + 0.15);
  }

  /** Button tap */
  tap(): void {
    this.tone(660, 0.07, 0.25, 'sine');
    this.tone(990, 0.06, 0.12, 'sine', 0.03);
  }

  /** A gentle "nope" (wrong answer, wrong code) — quiet, not scary */
  nope(): void {
    this.tone(330, 0.12, 0.2, 'triangle');
    this.tone(262, 0.16, 0.2, 'triangle', 0.1);
  }

  /** Victory tune: C-E-G-C */
  win(): void {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => this.tone(f, 0.22, 0.28, 'triangle', i * 0.12));
  }

  /** Star: the higher the index, the higher the note */
  star(index: number): void {
    const base = [784, 988, 1175][index % 3];
    this.tone(base, 0.25, 0.25, 'sine');
    this.tone(base * 2, 0.18, 0.08, 'sine', 0.02);
  }

  /** Sparkles */
  sparkle(): void {
    for (let i = 0; i < 5; i++) this.tone(1600 + rng.random() * 1400, 0.12, 0.08, 'sine', i * 0.05);
  }

  /** Soft fireworks — a muffled "puff", no crackle */
  firework(): void {
    this.pop(0.6);
    this.sparkle();
  }

  private ready(): { ctx: AudioContext; out: GainNode; t: number } | null {
    if (!this.settings.sound() || this.paused || !this.ctx || !this.master) return null;
    if (this.ctx.state !== 'running') return null;
    return { ctx: this.ctx, out: this.master, t: this.ctx.currentTime + 0.005 };
  }

  private tone(freq: number, dur: number, vol: number, type: OscillatorType, delay = 0): void {
    const a = this.ready();
    if (!a) return;
    const { ctx, out } = a;
    const t = a.t + delay;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(out);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private makeNoise(ctx: AudioContext): AudioBuffer {
    const len = Math.floor(ctx.sampleRate * 0.3);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1; // noise, not game randomness
    return buf;
  }
}
