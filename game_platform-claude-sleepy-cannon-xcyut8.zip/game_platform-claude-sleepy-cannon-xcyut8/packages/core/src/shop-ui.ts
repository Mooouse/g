// A ready level-shop screen for games with their own code, built on UpgradeShop — the progression shape for idle and
// launch-distance games (other genres pick another shape: docs/guides/upgrades.md → pick a shape). It follows the
// platform's shop rules: each card shows the effect "now → next", the level, the price (rounded up; the balance is
// rounded down); four states told by text and icon, not colour alone; a bar and "≈N runs" towards what's too expensive;
// an amount toggle only for an idle-scale economy (×1 / ×10 / Next / Max when an upgrade has 25+ levels; none for 5–10
// levels); hold to keep buying, faster and faster; feedback on every purchase and a "denied" shake; undo for the last
// purchases instead of confirmation dialogs; one "Best value" tag; a stable order; and, optionally, the whole shop's
// completion; when the cards don't fit the screen, pages (◀ 1/3 ▶) instead of a list to scroll (Жаслан, 2026-10-10:
// «всё помещается в один экран»). Theme it with screenTheme() (every platform screen at once) or CSS variables on
// `#gp-shop { --gp-shop-*: … }` (the defaults have no specificity, so the game's win); the platform's marks (the coin,
// the lock, the check, the pager's chevrons, the level pips) are drawn, not glyphs; a game's icons are drawn elements
// (icon() from @gp/core/icons, iconImg() from @gp/art/dom), image URLs or text; all text is replaceable.

import { FONT_FALLBACK, type I18n } from './i18n.ts';
import { icon as drawn } from './icons.ts';
import { DEFAULT_CURRENCY, screenIcon, type ScreenIcon } from './screen-icon.ts';
import { formatAmount, type BuyAmount, type Levels, type ShopRow, type UpgradeShop } from './upgrades';

/**
 * A card's icon: an element (icon() from @gp/core/icons, a canvas, an <img>, an inline SVG), a function that makes one,
 * an image URL (png, svg, webp, a data: URL) or text (an emoji: the old way, still shown)
 */
export type ShopIcon = ScreenIcon;

export interface ShopItemText {
  name: string;
  /** One line: what a level does ("Launch faster") */
  effect: string;
  icon?: ShopIcon;
  /** How the upgrade's value reads on the card ("27 m/s"); default: formatAmount */
  format?: (value: number) => string;
}

export interface ShopTexts {
  title: string;
  back: string;
  buy: string;
  maxed: string;
  needs: string;
  need: string;
  runs: (n: number) => string;
  best: string;
  undo: string;
  upgraded: (percent: number) => string;
  amounts: Record<'1' | '10' | 'next' | 'max', string>;
}

export const SHOP_TEXTS_EN: ShopTexts = {
  title: 'Upgrades',
  back: 'Back',
  buy: 'Buy',
  maxed: 'Max',
  needs: 'Needs',
  need: 'Need',
  runs: (n) => (n === 1 ? '≈\u00a01\u00a0run' : `≈\u00a0${n}\u00a0runs`),
  best: 'Best value',
  undo: 'Undo',
  upgraded: (p) => `${p}% upgraded`,
  amounts: { '1': '×1', '10': '×10', next: 'Next', max: 'Max' },
};

/** The shop's words in the player's language (the platform's gp.shop.* texts): what `i18n` in the options gives */
export function shopTexts(i18n: I18n): ShopTexts {
  const t = (k: string, p?: Record<string, number>) => i18n.t(`gp.shop.${k}`, p);
  return {
    title: t('title'),
    back: t('back'),
    buy: t('buy'),
    maxed: t('maxed'),
    needs: t('needs'),
    need: t('need'),
    runs: (n) => t('runs', { n }),
    best: t('best'),
    undo: t('undo'),
    upgraded: (p) => t('upgraded', { p }),
    amounts: { '1': '×1', '10': '×10', next: t('next'), max: t('max') },
  };
}

export interface ShopUiOptions<Id extends string> {
  shop: UpgradeShop<Id>;
  items: Record<Id, ShopItemText>;
  /** The current levels and coins (from your save) */
  get(): { levels: Levels<Id>; coins: number };
  /** Store the new levels and coins (save them) */
  set(levels: Levels<Id>, coins: number): void;
  /** The audience's smallest touch target (host.minTouchPx) */
  minTouchPx: number;
  /** The currency: its icon (default the platform's drawn coin; a drawn icon, a URL or text) and its name for screen readers */
  currency?: { icon: ShopIcon; name: string };
  /** Average coins per run, for "≈ N runs" (null: don't show) */
  incomePerRun?: () => number | null;
  /** The game's measure of power, for the "Best value" tag (default: the upgrade's value gain per coin) */
  score?: (levels: Levels<Id>) => number;
  /**
   * The amount toggle. Default: none (one level a press) — unless the economy is idle-scale (some upgrade has 25+ levels):
   * then ×1 / ×10 / Max, plus Next when an upgrade has milestones. A list here always wins; [1] hides the toggle.
   */
  amounts?: BuyAmount[];
  /** The "37% upgraded" line and bar (default true) */
  progress?: boolean;
  /** Your own words for any of the shop's (they win over `i18n`) */
  texts?: Partial<ShopTexts>;
  /** host.i18n: the shop's words in the player's language (default English); your item names come translated already */
  i18n?: I18n;
  /** A purchase went through (play a sound) */
  onBuy?(id: Id, count: number): void;
  /** The player tried to buy what they can't afford (play a "no" sound) */
  onDenied?(id: Id): void;
  onBack?(): void;
}

/** Upgrades with this many levels make an idle-scale economy: only then does the shop offer ×10 / Max */
const IDLE_LEVELS = 25;

// Every rule starts at #gp-shop: an id selector, so a game's own `#ui button { … }` styles can't override the shop's.
// The theme's defaults sit on :where(#gp-shop) — no specificity — so a game's `#gp-shop { --gp-shop-bg: … }` wins,
// wherever its style sheet is (Candle Crypt needed `#ui #gp-shop` before)
const CSS = `
:where(#gp-shop) { --gp-shop-bg: var(--gp-theme-bg, #fff8ec); --gp-shop-ink: var(--gp-theme-ink, #2b1d10); --gp-shop-muted: var(--gp-theme-muted, #6b5a48);
  --gp-shop-card: var(--gp-theme-panel, #ffffff); --gp-shop-accent: var(--gp-theme-accent, #1f8a4c); --gp-shop-accent-ink: var(--gp-theme-accent-ink, #ffffff);
  --gp-shop-off: var(--gp-theme-track, #d8cfc2); --gp-shop-best: var(--gp-theme-accent2, #ffcf33);
  --gp-shop-radius: var(--gp-theme-radius, 18px); --gp-shop-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-shop { color: var(--gp-shop-ink); background: var(--gp-shop-bg); border-radius: var(--gp-shop-radius); padding: 14px; box-sizing: border-box;
  width: min(96vw, 620px); max-height: 94vh; display: flex; flex-direction: column; gap: 10px; pointer-events: auto;
  font: 600 15px var(--gp-shop-font); font-variant-numeric: tabular-nums; text-align: left; }
#gp-shop header { display: flex; align-items: center; gap: 10px; }
#gp-shop h2 { margin: 0; font-size: 22px; flex: 1; font-family: var(--gp-theme-display, inherit); }
#gp-shop .gp-balance { font-size: 20px; font-weight: 800; display: flex; align-items: center; gap: 0.25em; }
#gp-shop .gp-cur, #gp-shop .gp-mark { flex: none; }
#gp-shop img.gp-cur { width: 1.15em; height: 1.15em; object-fit: contain; vertical-align: -0.2em; }
#gp-shop .gp-buy, #gp-shop .gp-line, #gp-shop .gp-page { display: inline-flex; align-items: center; justify-content: center; gap: 0.25em; }
#gp-shop .gp-line { justify-content: flex-start; flex-wrap: wrap; column-gap: 0.3em; }
#gp-shop .gp-nw { display: inline-flex; align-items: center; gap: 0.25em; white-space: nowrap; }
#gp-shop .gp-pips { display: inline-flex; gap: 3px; align-items: center; }
#gp-shop .gp-pips > i { width: 7px; height: 7px; border-radius: 50%; box-sizing: border-box; border: 1.5px solid currentColor; opacity: 0.55; }
#gp-shop .gp-pips > i.gp-on { background: var(--gp-shop-accent); border-color: var(--gp-shop-accent); opacity: 1; }
#gp-shop .gp-complete { font-size: 12px; color: var(--gp-shop-muted); }
#gp-shop .gp-bar { height: 8px; border-radius: 4px; background: var(--gp-shop-off); overflow: hidden; }
#gp-shop .gp-bar > i { display: block; height: 100%; background: var(--gp-shop-accent); }
#gp-shop .gp-amounts { display: flex; gap: 8px; }
#gp-shop button { font: inherit; border: 0; border-radius: 999px; cursor: pointer; touch-action: manipulation;
  min-width: 0; margin: 0; padding: 0 12px; box-shadow: none; text-transform: none; letter-spacing: normal; }
#gp-shop .gp-amounts button { flex: 1; background: var(--gp-shop-card); color: var(--gp-shop-ink); box-shadow: inset 0 0 0 2px var(--gp-shop-off); }
#gp-shop .gp-amounts button[aria-pressed=true] { box-shadow: inset 0 0 0 3px var(--gp-shop-ink); font-weight: 800; }
#gp-shop .gp-list { position: relative; overflow: auto; min-height: 0; display: flex; flex-direction: column; gap: 8px; padding-right: 2px; }
#gp-shop .gp-card { background: var(--gp-shop-card); border-radius: 14px; padding: 10px; display: grid; gap: 4px 10px;
  grid-template-columns: auto 1fr auto; grid-template-areas: 'icon name buy' 'icon info buy' 'icon state buy'; align-items: center; }
#gp-shop .gp-card .gp-icon { grid-area: icon; font-size: 28px; width: 40px; text-align: center; }
#gp-shop .gp-card .gp-icon > img, #gp-shop .gp-card .gp-icon > svg, #gp-shop .gp-card .gp-icon > canvas { width: 36px; height: 36px; object-fit: contain; vertical-align: middle; }
#gp-shop .gp-card .gp-icon > svg[data-icon=upgrade] { color: var(--gp-shop-accent); }
#gp-shop .gp-card .gp-name { grid-area: name; font-weight: 800; display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
#gp-shop .gp-card .gp-info { grid-area: info; font-size: 13px; color: var(--gp-shop-muted); }
#gp-shop .gp-card .gp-state { grid-area: state; font-size: 13px; display: flex; flex-direction: column; gap: 3px; }
#gp-shop .gp-card .gp-buy { grid-area: buy; background: var(--gp-shop-accent); color: var(--gp-shop-accent-ink); padding: 0 16px; font-weight: 800; }
#gp-shop .gp-card .gp-buy[aria-disabled=true] { background: var(--gp-shop-off); color: var(--gp-shop-muted); }
#gp-shop .gp-tag { background: var(--gp-shop-best); color: #2b1d10; border-radius: 6px; padding: 1px 6px; font-size: 12px; font-weight: 800; }
#gp-shop .gp-pips { letter-spacing: 1px; }
#gp-shop .gp-undo { align-self: center; background: transparent; color: var(--gp-shop-ink); text-decoration: underline; }
#gp-shop .gp-back { background: var(--gp-shop-ink); color: var(--gp-shop-bg); padding: 0 18px; }
#gp-shop .gp-page { flex: none; background: var(--gp-shop-card); color: var(--gp-shop-ink); box-shadow: inset 0 0 0 2px var(--gp-shop-off); font-weight: 800; }
#gp-shop .gp-page[aria-disabled=true] { opacity: 0.4; }
#gp-shop .gp-pageno { align-self: center; font-size: 13px; color: var(--gp-shop-muted); white-space: nowrap; }
#gp-shop .gp-card { min-width: 0; }
#gp-shop [hidden] { display: none !important; }
/* Eight cards without scrolling on phones (the layout Germ Bait, QmaCyber/game6, found for 360×800 and 800×360).
   Tall screens: two columns of upright cards */
@media (max-aspect-ratio: 4/5) {
  #gp-shop { max-height: 98vh; padding: 8px; gap: 6px; }
  #gp-shop h2 { font-size: 20px; }
  #gp-shop .gp-list { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; }
  #gp-shop .gp-card { grid-template-columns: auto 1fr; grid-template-areas: 'icon name' 'info info' 'state state' 'buy buy'; padding: 5px 7px 7px; gap: 1px 6px; }
  #gp-shop .gp-card .gp-icon { font-size: 20px; width: auto; }
  #gp-shop .gp-card .gp-icon > img, #gp-shop .gp-card .gp-icon > svg, #gp-shop .gp-card .gp-icon > canvas { width: 24px; height: 24px; }
  #gp-shop .gp-card .gp-name { font-size: 14px; }
  #gp-shop .gp-card .gp-info, #gp-shop .gp-card .gp-state { font-size: 12px; }
}
/* Wide screens: two columns */
@media (min-aspect-ratio: 5/4) {
  #gp-shop { width: min(96vw, 980px); }
  #gp-shop .gp-list { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
/* A phone on its side: one top row (title, amounts, back), then four columns of cards */
@media (min-aspect-ratio: 5/4) and (max-height: 520px) {
  #gp-shop { display: grid; grid-template-columns: auto 1fr auto; grid-template-rows: auto auto 1fr; padding: 6px 10px; gap: 5px 10px; max-height: 98vh; }
  #gp-shop > header { grid-area: 1 / 1; }
  #gp-shop > .gp-complete { display: none; }
  #gp-shop > .gp-bar { grid-area: 2 / 1 / 3 / 4; }
  #gp-shop > .gp-pick { grid-area: 1 / 2; }
  #gp-shop > .gp-list { grid-area: 3 / 1 / 4 / 4; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 5px; }
  #gp-shop > .gp-foot { grid-area: 1 / 3; }
  #gp-shop .gp-card { grid-template-columns: 1fr; grid-template-areas: 'name' 'info' 'state' 'buy'; padding: 5px 8px 7px; gap: 1px; }
  #gp-shop .gp-card .gp-icon { display: none; }
  #gp-shop .gp-card .gp-name { font-size: 13px; }
  #gp-shop .gp-card .gp-info, #gp-shop .gp-card .gp-state { font-size: 12px; }
  #gp-shop h2 { font-size: 18px; }
}
@media (prefers-reduced-motion: no-preference) {
  #gp-shop .gp-pop { animation: gp-pop 0.22s ease-out; }
  #gp-shop .gp-deny { animation: gp-deny 0.3s ease-in-out; }
}
@keyframes gp-pop { 50% { transform: scale(1.08); } }
@keyframes gp-deny { 20%, 60% { transform: translateX(-5px); } 40%, 80% { transform: translateX(5px); } }
`;

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

/** The icon's content: an element (a copy when it is on screen already), an <img> for an image URL, text; none: a drawn arrow up */
export function iconNode(icon: ShopIcon | undefined): Node {
  return icon === undefined ? drawn('upgrade', { style: 'duo', size: 32 }) : screenIcon(icon);
}

/** A drawn mark of the shop's own (lock, check), the size of the text */
const mark = (name: 'lock' | 'check') => drawn(name, { className: 'gp-mark', stroke: name === 'check' ? 2.8 : 2.2 });

/** Mount the shop screen into `root`; returns refresh() (call after coins change elsewhere) and destroy() */
export function mountUpgradeShop<Id extends string>(root: HTMLElement, opts: ShopUiOptions<Id>): { refresh(): void; destroy(): void } {
  const words = opts.i18n ? shopTexts(opts.i18n) : SHOP_TEXTS_EN;
  const t: ShopTexts = { ...words, ...opts.texts, amounts: { ...words.amounts, ...opts.texts?.amounts } };
  const cur: { icon: ShopIcon; name: string } = opts.currency ?? { icon: DEFAULT_CURRENCY, name: opts.i18n ? opts.i18n.t('gp.shop.coins') : 'coins' };
  const coin = () => screenIcon(cur.icon);
  const levelOf = (level: number, max: number) => (opts.i18n ? opts.i18n.t('gp.shop.level', { level, max }) : `level ${level} of ${max}`);
  const hasMilestones = opts.shop.defs.some((d) => d.milestones?.length);
  // ×10 / Max are for idle economies with dozens of levels; with 5–10 levels an upgrade they only get in the way
  const idle = opts.shop.defs.some((d) => d.max >= IDLE_LEVELS);
  const amounts: BuyAmount[] = opts.amounts?.length ? opts.amounts : idle ? (hasMilestones ? [1, 10, 'next', 'max'] : [1, 10, 'max']) : [1];
  let amount: BuyAmount = amounts[0];
  /** Purchases of this visit, newest last: undo gives them back exactly */
  const undo: { id: Id; count: number }[] = [];
  const min = `${opts.minTouchPx}px`;

  if (!document.getElementById('gp-shop-css')) {
    const style = el('style');
    style.id = 'gp-shop-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  const box = el('section', 'gp-shop');
  box.id = 'gp-shop';
  box.setAttribute('aria-label', t.title);
  box.dataset.gp = 'shop-screen';
  const header = el('header');
  const title = el('h2', undefined, t.title);
  const balance = el('div', 'gp-balance');
  balance.dataset.gp = 'shop-balance';
  balance.setAttribute('aria-live', 'polite');
  header.append(title, balance);
  const complete = el('div', 'gp-complete');
  const bar = el('div', 'gp-bar');
  const barFill = el('i');
  bar.append(barFill);
  const amountRow = el('div', 'gp-amounts gp-pick');
  amountRow.setAttribute('role', 'group');
  const list = el('div', 'gp-list');
  const foot = el('div', 'gp-amounts gp-foot');
  const undoBtn = el('button', 'gp-undo', t.undo);
  undoBtn.dataset.gp = 'shop-undo';
  const back = el('button', 'gp-back', t.back);
  back.dataset.gp = 'shop-back';
  // Pages, shown only when the cards don't fit (paginate)
  const prev = el('button', 'gp-page');
  prev.append(drawn('chevronLeft', { size: 22, stroke: 2.6 }));
  prev.dataset.gp = 'shop-prev';
  const next = el('button', 'gp-page');
  next.append(drawn('chevronRight', { size: 22, stroke: 2.6 }));
  next.dataset.gp = 'shop-next';
  const pageNo = el('span', 'gp-pageno');
  for (const b of [prev, next]) {
    b.style.minWidth = min;
    b.setAttribute('aria-label', opts.i18n ? opts.i18n.t(b === prev ? 'gp.back' : 'gp.next') : b === prev ? 'Previous' : 'Next');
  }
  for (const b of [undoBtn, back, prev, next]) b.style.minHeight = min;
  foot.append(prev, pageNo, next, undoBtn, back);
  let page = 0;
  let perPage = 0;
  box.append(header, complete, bar, amountRow, list, foot);
  if (opts.progress === false) complete.hidden = bar.hidden = true;
  root.replaceChildren(box);

  // One amount: no toggle at all (no hidden buttons for QA to trip over)
  for (const a of amounts.length > 1 ? amounts : []) {
    const b = el('button', undefined, t.amounts[String(a) as keyof ShopTexts['amounts']]);
    b.style.minHeight = min;
    b.dataset.amount = String(a);
    b.addEventListener('click', () => {
      amount = a;
      render();
    });
    amountRow.append(b);
  }
  if (amounts.length < 2) amountRow.hidden = true;

  // One card per upgrade, created once (stable order, no re-layout under the finger), updated by render()
  const cards = new Map<Id, { card: HTMLElement; icon: HTMLElement; name: HTMLElement; info: HTMLElement; state: HTMLElement; buy: HTMLButtonElement }>();
  for (const d of opts.shop.defs) {
    const text = opts.items[d.id];
    const card = el('article', 'gp-card');
    card.dataset.gpUpgrade = d.id;
    const icon = el('div', 'gp-icon');
    icon.append(iconNode(text.icon));
    icon.setAttribute('aria-hidden', 'true');
    const name = el('div', 'gp-name');
    const info = el('div', 'gp-info');
    const state = el('div', 'gp-state');
    const buy = el('button', 'gp-buy');
    buy.dataset.gpBuy = d.id;
    buy.style.minHeight = min;
    buy.style.minWidth = `${opts.minTouchPx * 2}px`;
    holdToBuy(buy, d.id);
    card.append(icon, name, info, state, buy);
    list.append(card);
    cards.set(d.id, { card, icon, name, info, state, buy });
  }

  function fmt(id: Id, v: number): string {
    return opts.items[id].format?.(v) ?? formatAmount(v);
  }

  function rows(): ShopRow<Id>[] {
    const { levels, coins } = opts.get();
    return opts.shop.view(levels, coins, { amount, incomePerRun: opts.incomePerRun?.() ?? undefined, score: opts.score });
  }

  function render(): void {
    const { levels, coins } = opts.get();
    balance.replaceChildren(coin(), document.createTextNode(formatAmount(coins, 'down')));
    balance.setAttribute('aria-label', `${formatAmount(coins, 'down')} ${cur.name}`);
    const pct = Math.floor(opts.shop.progress(levels) * 100);
    complete.textContent = t.upgraded(pct);
    barFill.style.width = `${pct}%`;
    for (const b of amountRow.querySelectorAll('button')) b.setAttribute('aria-pressed', String(b.dataset.amount === String(amount)));
    for (const r of rows()) {
      const c = cards.get(r.id)!;
      const text = opts.items[r.id];
      c.name.replaceChildren(document.createTextNode(text.name));
      if (r.best) c.name.append(el('span', 'gp-tag', t.best));
      const change = r.now !== undefined && r.next !== undefined && r.state !== 'maxed' ? ` · ${fmt(r.id, r.now)} → ${fmt(r.id, r.next)}` : r.now !== undefined ? ` · ${fmt(r.id, r.now)}` : '';
      c.info.textContent = `${text.effect}${change}`;
      c.state.replaceChildren();
      // The level: drawn pips (filled up to it) for a short track, "7/40" for a long one
      const pips = el('span', 'gp-pips');
      if (r.max <= 12) for (let i = 0; i < r.max; i++) pips.append(el('i', i < r.level ? 'gp-on' : undefined));
      else pips.textContent = `${r.level}/${r.max}`;
      pips.dataset.level = `${r.level}/${r.max}`;
      pips.setAttribute('role', 'img');
      pips.setAttribute('aria-label', levelOf(r.level, r.max));
      c.state.append(pips);
      const line = (...parts: (Node | string)[]) => {
        const s = el('span', 'gp-line');
        s.append(...parts);
        return s;
      };
      if (r.state === 'maxed') c.state.append(line(mark('check'), t.maxed));
      else if (r.state === 'locked') c.state.append(line(mark('lock'), r.lockReason ?? `${t.needs} ${opts.items[r.requires!]?.name ?? r.requires}`));
      else if (!r.canBuy && r.cost !== null) {
        const more = r.cost - coins;
        const b = el('div', 'gp-bar');
        const f = el('i');
        f.style.width = `${Math.floor(r.progress * 100)}%`;
        b.append(f);
        // "Need ◎ 980" never breaks inside (the coin is drawn: no no-break space can hold it to its words)
        const need = el('span', 'gp-nw');
        need.append(t.need, coin(), formatAmount(more, 'up'));
        c.state.append(line(need, r.runsToAfford ? `· ${t.runs(r.runsToAfford)}` : ''), b);
      }
      const b = c.buy;
      if (r.state === 'maxed') {
        b.replaceChildren(mark('check'), t.maxed);
        b.setAttribute('aria-disabled', 'true');
      } else {
        const n = r.count > 1 ? ` ×${r.count}` : '';
        b.replaceChildren(r.state === 'locked' ? mark('lock') : coin(), `${r.cost === null ? '' : formatAmount(r.cost, 'up')}${n}`);
        b.setAttribute('aria-disabled', String(!r.canBuy));
        b.setAttribute('aria-label', `${t.buy} ${text.name}${n}, ${r.cost ?? ''} ${cur.name}`);
      }
    }
    undoBtn.hidden = undo.length === 0;
    paginate();
  }

  /**
   * One screen, no scrolling: when every card doesn't fit the room the list has, show as many as fit and pages for the
   * rest (◀ 1/3 ▶). Measured on the real layout, so a phone, a portal frame and a desktop each get their own count
   */
  function paginate(): void {
    const all = [...cards.values()].map((c) => c.card);
    for (const c of all) c.hidden = false;
    prev.hidden = next.hidden = pageNo.hidden = true;
    if (list.clientHeight === 0 || list.scrollHeight <= list.clientHeight + 2) {
      perPage = 0;
      return;
    }
    prev.hidden = next.hidden = pageNo.hidden = false;
    const room = list.clientHeight + 1;
    perPage = Math.max(1, all.filter((c) => c.offsetTop + c.offsetHeight <= room).length);
    const pages = Math.ceil(all.length / perPage);
    page = Math.min(page, pages - 1);
    all.forEach((c, i) => (c.hidden = Math.floor(i / perPage) !== page));
    pageNo.textContent = `${page + 1}/${pages}`;
    prev.setAttribute('aria-disabled', String(page === 0));
    next.setAttribute('aria-disabled', String(page === pages - 1));
  }
  const turn = (d: number) => {
    if (!perPage) return;
    const pages = Math.ceil(cards.size / perPage);
    page = Math.max(0, Math.min(pages - 1, page + d));
    paginate();
  };
  prev.addEventListener('click', () => turn(-1));
  next.addEventListener('click', () => turn(1));
  // Again when the screen or the list's room changes (the shop mounted before it was shown, a phone turned)
  const onResize = () => paginate();
  addEventListener('resize', onResize);
  const watch = typeof ResizeObserver === 'function' ? new ResizeObserver(onResize) : null;
  watch?.observe(box);

  /** One purchase at the current amount; false when it didn't happen */
  function buyOnce(id: Id): boolean {
    const { levels, coins } = opts.get();
    const r = opts.shop.buy(id, levels, coins, amount);
    const c = cards.get(id)!;
    if (!r) {
      c.card.classList.remove('gp-deny');
      void c.card.offsetWidth; // restart the animation
      c.card.classList.add('gp-deny');
      opts.onDenied?.(id);
      return false;
    }
    opts.set(r.levels, r.coins);
    undo.push({ id, count: r.bought });
    c.card.classList.remove('gp-pop');
    void c.card.offsetWidth;
    c.card.classList.add('gp-pop');
    opts.onBuy?.(id, r.bought);
    render();
    return true;
  }

  /** Tap buys once; holding keeps buying, starting slow and speeding up, until it can't */
  function holdToBuy(btn: HTMLButtonElement, id: Id): void {
    let timer = 0;
    let delay = 0;
    const stop = () => {
      clearTimeout(timer);
      timer = 0;
    };
    const step = () => {
      if (!buyOnce(id)) return stop();
      delay = Math.max(60, delay * 0.8);
      timer = window.setTimeout(step, delay);
    };
    btn.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      btn.setPointerCapture?.(e.pointerId);
      if (!buyOnce(id)) return;
      delay = 220;
      timer = window.setTimeout(step, 450);
    });
    for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture'] as const) btn.addEventListener(ev, stop);
    // Keyboard: Enter/Space buy once (repeat keys are ignored — no accidental bulk)
    btn.addEventListener('keydown', (e) => {
      if ((e.key === 'Enter' || e.key === ' ') && !e.repeat) {
        e.preventDefault();
        buyOnce(id);
      }
    });
  }

  undoBtn.addEventListener('click', () => {
    const last = undo.pop();
    if (!last) return;
    const { levels, coins } = opts.get();
    const r = opts.shop.refund(last.id, levels, coins, last.count);
    if (r) opts.set(r.levels, r.coins);
    render();
  });
  back.addEventListener('click', () => opts.onBack?.());

  render();
  return {
    refresh: render,
    destroy: () => {
      removeEventListener('resize', onResize);
      watch?.disconnect();
      box.remove();
    },
  };
}

/**
 * The shop entry button's badge: true when a next level became affordable that the player hasn't seen affordable yet.
 * Keep `seen` in the save (a list of "id:level" keys) and call markSeen() when the shop opens — so the badge means news,
 * and comes back for the next level, instead of nagging all the time.
 */
export function shopBadge<Id extends string>(shop: UpgradeShop<Id>, levels: Levels<Id>, coins: number, seen: readonly string[]): boolean {
  return shop.affordableIds(levels, coins).some((id) => !seen.includes(`${id}:${shop.level(id, levels)}`));
}

export function markSeen<Id extends string>(shop: UpgradeShop<Id>, levels: Levels<Id>, coins: number, seen: readonly string[]): string[] {
  return [...new Set([...seen, ...shop.affordableIds(levels, coins).map((id) => `${id}:${shop.level(id, levels)}`)])];
}
