// Progression shapes for games with their own code: what a run's currency (or the run itself) buys besides "+stat"
// levels. Pure (no DOM): usable from the game, unit tests and balance bots; deterministic (randomness only from the rng
// you pass, e.g. host.rng); save-safe (sanitize() every loaded state — unknown ids, duplicates and wrong types go).
// Each shape is taken from a game that proved it (docs/guides/upgrades.md → pick a shape):
//
//   Roster      new heroes / tools that change how you play, bought once, one selected      Candle Crypt's candles (game9)
//   Tiers       sets of items; buying in one tier opens the next                            Starsilk's Loom (game11)
//   PactTree    gains paired with a cost, on paths; Oaths sworn one of two ways; forks       Dread Throne's pacts (game10)
//   RunChoices  pick 1 of N during a run: weights, stacks, no duplicates, rerolls           Candle Crypt's feats (game9)
//
// The level shop (UpgradeShop, upgrades.ts) is the fifth shape — for idle and launch-distance games.

/** A random source: host.rng, or a bare () => number in bots and tests */
export type Rand = (() => number) | { random(): number };
const roll = (r: Rand): number => (typeof r === 'function' ? r() : r.random());

const isInt = (n: unknown): n is number => typeof n === 'number' && Number.isSafeInteger(n);
const list = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);
const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

function checkIds(kind: string, ids: readonly string[]): Set<string> {
  const seen = new Set<string>();
  for (const id of ids) {
    if (typeof id !== 'string' || !id) throw new Error(`${kind}: every id must be a non-empty string`);
    if (seen.has(id)) throw new Error(`${kind} ${id} is defined twice`);
    seen.add(id);
  }
  return seen;
}

const reqs = <Id extends string>(r: Id | readonly Id[] | undefined): readonly Id[] => (r === undefined ? [] : typeof r === 'string' ? [r] : r);

// --- Roster: unlocks that change how you play -------------------------------------------------------------------

export interface RosterEntry<Id extends string = string> {
  id: Id;
  /** Price in the game's currency; 0 = owned from the start (at least one entry must be free) */
  price: number;
  /** Needs this entry owned first */
  requires?: Id;
}

/** What goes into the save: the entries owned and the one in play */
export interface RosterSave<Id extends string = string> {
  owned: Id[];
  selected: Id;
}

export type RosterState = 'selected' | 'owned' | 'affordable' | 'too-expensive' | 'locked';

export interface RosterRow<Id extends string> {
  id: Id;
  price: number;
  state: RosterState;
  /** Can be bought now */
  canBuy: boolean;
  /** 0..1 towards the price (a bar: the goal-gradient) */
  progress: number;
  /** Locked because this entry isn't owned yet (show its name: "🔒 Needs Copper Candle") */
  needs?: Id;
  /** Locked by the game's own condition: its reason */
  lockReason?: string;
}

export interface RosterOptions<Id extends string> {
  /** The game's own unlock condition (a depth reached, a story flag): why `id` is still locked, or null */
  lock?: (id: Id, save: RosterSave<Id>) => string | null;
}

/**
 * A roster of heroes, tools or modes, each bought once and each playing differently; one is selected for the run.
 * From Candle Crypt (QmaCyber/game9): gems buy new candles, each with its own class power, instead of "+5% damage".
 * A new entry must change what the player does (a new power, a new rule); a bigger number is a level, not an unlock.
 */
export class Roster<Id extends string> {
  readonly entries: readonly RosterEntry<Id>[];
  private readonly byId: Map<Id, RosterEntry<Id>>;
  private readonly lockFn: RosterOptions<Id>['lock'];

  constructor(entries: readonly RosterEntry<Id>[], opts: RosterOptions<Id> = {}) {
    const ids = checkIds('roster entry', entries.map((e) => e.id));
    for (const e of entries) {
      if (!(isInt(e.price) && e.price >= 0)) throw new Error(`roster entry ${e.id}: price must be a safe integer ≥ 0`);
      if (e.requires !== undefined && (!ids.has(e.requires) || e.requires === e.id)) throw new Error(`roster entry ${e.id} requires unknown ${e.requires}`);
    }
    if (!entries.some((e) => e.price === 0)) throw new Error('roster: at least one entry must be free (price 0): the one a new player plays');
    this.entries = entries;
    this.byId = new Map(entries.map((e) => [e.id, e]));
    this.lockFn = opts.lock;
  }

  private entry(id: Id): RosterEntry<Id> {
    const e = this.byId.get(id);
    if (!e) throw new Error(`unknown roster entry ${id}`);
    return e;
  }

  private get firstFree(): Id {
    return this.entries.find((e) => e.price === 0)!.id;
  }

  /** A new save: the free entries owned, the first of them selected — also the defaults for host.load() */
  initial(): RosterSave<Id> {
    return { owned: this.entries.filter((e) => e.price === 0).map((e) => e.id), selected: this.firstFree };
  }

  /** A loaded save made safe: known ids only, no duplicates, the free ones always owned, the selected one owned */
  sanitize(raw: unknown): RosterSave<Id> {
    const r = record(raw);
    const had = new Set(list(r.owned).filter((x): x is Id => typeof x === 'string' && this.byId.has(x as Id)));
    const owned = this.entries.filter((e) => e.price === 0 || had.has(e.id)).map((e) => e.id);
    const sel = r.selected as Id;
    return { owned, selected: typeof sel === 'string' && owned.includes(sel) ? sel : this.firstFree };
  }

  owns(id: Id, save: RosterSave<Id>): boolean {
    return this.entry(id).price === 0 || save.owned.includes(id);
  }

  /** Why `id` can't be bought yet (its requirement or the game's condition), or null */
  lockReason(id: Id, save: RosterSave<Id>): string | null {
    const e = this.entry(id);
    if (e.requires && !this.owns(e.requires, save)) return `Needs ${e.requires}`;
    return this.lockFn?.(id, save) ?? null;
  }

  state(id: Id, save: RosterSave<Id>, coins: number): RosterState {
    if (this.owns(id, save)) return save.selected === id ? 'selected' : 'owned';
    if (this.lockReason(id, save)) return 'locked';
    return this.entry(id).price <= coins ? 'affordable' : 'too-expensive';
  }

  /** Buy `id` (and select it, as Candle Crypt does, unless `select: false`); null if it can't be bought now */
  buy(id: Id, save: RosterSave<Id>, coins: number, opts: { select?: boolean } = {}): { save: RosterSave<Id>; coins: number } | null {
    if (this.state(id, save, coins) !== 'affordable') return null;
    const owned = this.entries.filter((e) => e.id === id || this.owns(e.id, save)).map((e) => e.id);
    return { save: { owned, selected: opts.select === false ? save.selected : id }, coins: coins - this.entry(id).price };
  }

  /** Play with `id` next (it must be owned); null otherwise */
  select(id: Id, save: RosterSave<Id>): RosterSave<Id> | null {
    return this.owns(id, save) ? { owned: [...save.owned], selected: id } : null;
  }

  /**
   * Undo a purchase at exactly its price; null for a free entry, one not owned, one another owned entry needs, or when
   * the undo would lock another owned entry (a tier it opened: the game's `lock`)
   */
  refund(id: Id, save: RosterSave<Id>, coins: number): { save: RosterSave<Id>; coins: number } | null {
    const e = this.entry(id);
    if (e.price === 0 || !save.owned.includes(id)) return null;
    if (this.entries.some((x) => x.requires === id && x.price > 0 && save.owned.includes(x.id))) return null;
    const owned = save.owned.filter((x) => x !== id);
    const after = { owned, selected: save.selected === id ? this.firstFree : save.selected };
    const lock = this.lockFn;
    if (lock && this.entries.some((x) => x.id !== id && x.price > 0 && save.owned.includes(x.id) && !lock(x.id, save) && lock(x.id, after))) return null;
    return { save: after, coins: coins + e.price };
  }

  /** The cheapest entry not owned and not locked — the goal to show ("Next: Copper Candle, 300"); null when all are owned */
  next(save: RosterSave<Id>): RosterEntry<Id> | null {
    return this.entries.filter((e) => !this.owns(e.id, save) && !this.lockReason(e.id, save)).sort((a, b) => a.price - b.price)[0] ?? null;
  }

  /** Share of the paid entries owned, 0..1 */
  progress(save: RosterSave<Id>): number {
    const paid = this.entries.filter((e) => e.price > 0);
    return paid.length ? paid.filter((e) => save.owned.includes(e.id)).length / paid.length : 1;
  }

  /** Everything's price: the length of this track, for the balance plan */
  totalCost(): number {
    return this.entries.reduce((s, e) => s + e.price, 0);
  }

  /** The screen in one call: a row per entry, in definition order (stable: never re-sorted under the finger) */
  view(save: RosterSave<Id>, coins: number): RosterRow<Id>[] {
    return this.entries.map((e) => {
      const state = this.state(e.id, save, coins);
      const needs = state === 'locked' && e.requires && !this.owns(e.requires, save) ? e.requires : undefined;
      const reason = state === 'locked' && !needs ? this.lockFn?.(e.id, save) : null;
      return {
        id: e.id,
        price: e.price,
        state,
        canBuy: state === 'affordable',
        progress: state === 'owned' || state === 'selected' ? 1 : e.price ? Math.min(1, Math.max(0, coins / e.price)) : 1,
        ...(needs ? { needs } : {}),
        ...(reason ? { lockReason: reason } : {}),
      };
    });
  }

  /** Balance bot, a new player: the cheapest affordable entry first, until nothing is affordable */
  spendCheapest(save: RosterSave<Id>, coins: number): { save: RosterSave<Id>; coins: number; bought: Id[] } {
    return this.spend(save, coins, (e) => -e.price);
  }

  /**
   * Balance bot, a careful player: the biggest gain per coin first, where `power(id)` is how well a run goes with that
   * entry (the bot's measure) and the gain is over the best entry owned; sidegrades (no gain) cheapest first after that.
   * Selects the strongest owned entry, as a player would.
   */
  spendBest(save: RosterSave<Id>, coins: number, power: (id: Id) => number): { save: RosterSave<Id>; coins: number; bought: Id[] } {
    const r = this.spend(save, coins, (e, cur) => {
      const top = Math.max(...cur.owned.map(power));
      const gain = power(e.id) - top;
      return gain > 0 ? 1e9 + gain / Math.max(1, e.price) : -e.price;
    });
    return { ...r, save: { ...r.save, selected: this.best(r.save, power) } };
  }

  /** The owned entry with the highest `power` (ties: the earlier one) */
  best(save: RosterSave<Id>, power: (id: Id) => number): Id {
    let top: Id = save.selected;
    for (const e of this.entries) if (this.owns(e.id, save) && power(e.id) > power(top)) top = e.id;
    return top;
  }

  private spend(save: RosterSave<Id>, coins: number, rank: (e: RosterEntry<Id>, cur: RosterSave<Id>) => number): { save: RosterSave<Id>; coins: number; bought: Id[] } {
    let cur = { save: this.sanitize(save), coins };
    const bought: Id[] = [];
    for (;;) {
      let pick: { e: RosterEntry<Id>; r: number } | null = null;
      for (const e of this.entries) {
        if (this.state(e.id, cur.save, cur.coins) !== 'affordable') continue;
        const r = rank(e, cur.save);
        if (!pick || r > pick.r) pick = { e, r };
      }
      if (!pick) return { ...cur, bought };
      cur = this.buy(pick.e.id, cur.save, cur.coins, { select: false })!;
      bought.push(pick.e.id);
    }
  }
}

// --- Tiers: a tier opens the next set ---------------------------------------------------------------------------

export interface TierDef<Id extends string = string> {
  /** Shown on the screen ("The Way", "Tier II") */
  name?: string;
  /** The items in this tier: upgrade ids of an UpgradeShop, or roster / pact ids */
  items: readonly Id[];
  /**
   * Levels (or items) bought in all the tiers below that open this one. Default: as many as all the tiers below have
   * items (one of each), so each tier waits for the whole set below it. The first tier is always open.
   */
  opensAt?: number;
}

export interface TierView {
  tier: number;
  name: string;
  open: boolean;
  /** Levels bought in this tier */
  bought: number;
  /** More levels below it to open it (0 when open) */
  need: number;
  /** Why it is closed, or null */
  reason: string | null;
}

export interface TiersOptions {
  /** The game's own condition on a tier (a depth cleared, a boss beaten): why tier `t` is still closed, or null */
  gate?: (tier: number) => string | null;
  /** The closed tier's line; default "3 more to open The Light" */
  text?: (need: number, name: string) => string;
}

/**
 * Tiers of items: what the player buys in one tier opens the next — a new set of things arrives every few minutes
 * instead of all at once (unlock pacing). From Starsilk (QmaCyber/game11): the Loom in tiers, the answers to new
 * shadows opening with the depth where they first appear. Wire it into a shop:
 *   const tiers = new Tiers(TIERS);
 *   const shop = new UpgradeShop(UPGRADES, { lock: (id, levels) => tiers.lock(id, levels) });
 * `counts` is what was bought per id: an UpgradeShop's levels, or countsOf(roster.owned) for things bought once.
 */
export class Tiers<Id extends string> {
  readonly tiers: readonly TierDef<Id>[];
  private readonly of: Map<Id, number>;
  private readonly opts: TiersOptions;

  constructor(tiers: readonly TierDef<Id>[], opts: TiersOptions = {}) {
    if (!tiers.length) throw new Error('tiers: at least one tier');
    checkIds('tier item', tiers.flatMap((t) => [...t.items]));
    for (const [i, t] of tiers.entries()) {
      if (!t.items.length) throw new Error(`tier ${i + 1} has no items`);
      if (t.opensAt !== undefined && !(isInt(t.opensAt) && t.opensAt >= 0)) throw new Error(`tier ${i + 1}: opensAt must be an integer ≥ 0`);
    }
    this.tiers = tiers;
    this.of = new Map(tiers.flatMap((t, i) => t.items.map((id) => [id, i] as [Id, number])));
    this.opts = opts;
  }

  /** The tier `id` is in (0-based), or -1: not in any tier (never closed by tiers) */
  tierOf(id: Id): number {
    return this.of.get(id) ?? -1;
  }

  private name(t: number): string {
    return this.tiers[t].name ?? `Tier ${t + 1}`;
  }

  private opensAt(t: number): number {
    if (t === 0) return 0;
    // `below()` counts every tier below, so the default does too: one of each item in all of them
    return this.tiers[t].opensAt ?? this.tiers.slice(0, t).reduce((s, x) => s + x.items.length, 0);
  }

  private bought(t: number, counts: Partial<Record<Id, number>>): number {
    return this.tiers[t].items.reduce((s, id) => {
      const n = counts[id];
      return s + (typeof n === 'number' && Number.isFinite(n) && n > 0 ? Math.floor(n) : 0);
    }, 0);
  }

  /** Levels bought in the tiers below `t` */
  below(t: number, counts: Partial<Record<Id, number>>): number {
    let s = 0;
    for (let i = 0; i < t; i++) s += this.bought(i, counts);
    return s;
  }

  /** Why tier `t` is closed, or null. A tier needs the one below it open too */
  closed(t: number, counts: Partial<Record<Id, number>>): string | null {
    for (let i = 1; i <= t; i++) {
      const need = this.opensAt(i) - this.below(i, counts);
      if (need > 0) return i === t ? (this.opts.text ?? ((n, name) => `${n} more to open ${name}`))(need, this.name(i)) : `Open ${this.name(i)} first`;
      const g = this.opts.gate?.(i);
      if (g) return g;
    }
    return null;
  }

  /** Why `id` is locked by its tier, or null — pass it to UpgradeShop's `lock` (or a Roster's / PactTree's) */
  lock(id: Id, counts: Partial<Record<Id, number>>): string | null {
    const t = this.tierOf(id);
    return t <= 0 ? null : this.closed(t, counts);
  }

  /** How many tiers are open (the first always is) */
  openCount(counts: Partial<Record<Id, number>>): number {
    let n = 1;
    while (n < this.tiers.length && !this.closed(n, counts)) n++;
    return n;
  }

  /** A row per tier for the screen: open or not, what it takes, what was bought in it */
  view(counts: Partial<Record<Id, number>>): TierView[] {
    return this.tiers.map((_, t) => {
      const reason = t === 0 ? null : this.closed(t, counts);
      return { tier: t, name: this.name(t), open: !reason, bought: this.bought(t, counts), need: t === 0 ? 0 : Math.max(0, this.opensAt(t) - this.below(t, counts)), reason };
    });
  }
}

/** Things bought once (a roster's or a pact tree's list) as counts for Tiers: { id: 1 } */
export function countsOf<Id extends string>(owned: readonly Id[]): Partial<Record<Id, number>> {
  return Object.fromEntries(owned.map((id) => [id, 1])) as Partial<Record<Id, number>>;
}

// --- PactTree: gains with a cost --------------------------------------------------------------------------------

/** Numbers a pact changes, summed over everything taken: { damage: 0.5, wax: -12 } */
export type Mods = Readonly<Record<string, number>>;

export interface PactSide<Side extends string = string> {
  id: Side;
  mods?: Mods;
}

export interface PactDef<Id extends string = string, Side extends string = string> {
  id: Id;
  price: number;
  /** Needs this pact (or all of these) taken first: paths and trees */
  requires?: Id | readonly Id[];
  /** The path it is on (the screen's rows: "The Throne", "The Dungeon") */
  path?: string;
  /** What taking it changes — a gain AND its cost: { damage: 0.5, wax: -12 }. mods() sums them */
  mods?: Mods;
  /** An Oath: taken once, then sworn one of these ways; re-swearing is free, so trying a build costs nothing */
  sides?: readonly PactSide<Side>[];
  /** Can't be taken together with these (a fork: the brute or the trick); the other way round too */
  excludes?: readonly Id[];
}

export interface PactSave<Id extends string = string, Side extends string = string> {
  taken: Id[];
  /** The side each taken Oath is sworn to (missing: its first side) */
  sworn: Partial<Record<Id, Side>>;
}

export type PactState = 'taken' | 'affordable' | 'too-expensive' | 'locked' | 'excluded';

export interface PactRow<Id extends string, Side extends string> {
  id: Id;
  price: number;
  path?: string;
  state: PactState;
  canBuy: boolean;
  progress: number;
  /** The side in force for a taken Oath */
  side?: Side;
  /** Locked: this pact on its path isn't taken yet (show its name: "🔒 Needs Royal Claws") */
  needs?: Id;
  /** Excluded: the other side of the fork, already taken ("Instead of Hidden Pit") */
  excludedBy?: Id;
  /** Locked by the game's own condition: its reason ("Clear stage 2 first") */
  lockReason?: string;
}

export interface PactTreeOptions<Id extends string, Side extends string> {
  /** The game's own condition (a stage cleared): why `id` is still locked, or null */
  lock?: (id: Id, save: PactSave<Id, Side>) => string | null;
}

/**
 * Pacts: every node gives something and takes something (a gain with a cost), on paths where each needs the one before;
 * an Oath is bought once and sworn one of two ways; `excludes` makes a fork (one of two, never both). From Dread Throne
 * (QmaCyber/game10): three paths of Dark Pacts with Oaths, and every fixture's level-3 fork (the brute or the trick).
 * Ranks (a pact with 1–3 levels) are an UpgradeShop next to it; its `lock` can ask this tree.
 */
export class PactTree<Id extends string, Side extends string = string> {
  readonly defs: readonly PactDef<Id, Side>[];
  private readonly byId: Map<Id, PactDef<Id, Side>>;
  private readonly excl: Map<Id, Set<Id>>;
  private readonly lockFn: PactTreeOptions<Id, Side>['lock'];

  constructor(defs: readonly PactDef<Id, Side>[], opts: PactTreeOptions<Id, Side> = {}) {
    const ids = checkIds('pact', defs.map((d) => d.id));
    this.excl = new Map(defs.map((d) => [d.id, new Set<Id>()]));
    for (const d of defs) {
      if (!(isInt(d.price) && d.price >= 0)) throw new Error(`pact ${d.id}: price must be a safe integer ≥ 0`);
      for (const r of reqs(d.requires)) if (!ids.has(r) || r === d.id) throw new Error(`pact ${d.id} requires unknown ${r}`);
      for (const x of d.excludes ?? []) {
        if (!ids.has(x) || x === d.id) throw new Error(`pact ${d.id} excludes unknown ${x}`);
        this.excl.get(d.id)!.add(x);
        this.excl.get(x)!.add(d.id);
      }
      if (d.sides) {
        if (d.sides.length < 2) throw new Error(`pact ${d.id}: an Oath needs at least two sides`);
        checkIds(`pact ${d.id} side`, d.sides.map((s) => s.id));
      }
      for (const m of [d.mods, ...(d.sides ?? []).map((s) => s.mods)]) for (const [k, v] of Object.entries(m ?? {})) if (!Number.isFinite(v)) throw new Error(`pact ${d.id}: mod ${k} must be a finite number`);
    }
    // Requirements must not loop (a pact that needs itself through others could never be taken)
    const visiting = new Set<Id>();
    const done = new Set<Id>();
    const visit = (id: Id) => {
      if (done.has(id)) return;
      if (visiting.has(id)) throw new Error(`pact ${id}: its requirements loop`);
      visiting.add(id);
      for (const r of reqs(defs.find((d) => d.id === id)!.requires)) visit(r);
      visiting.delete(id);
      done.add(id);
    };
    for (const d of defs) visit(d.id);
    this.defs = defs;
    this.byId = new Map(defs.map((d) => [d.id, d]));
    this.lockFn = opts.lock;
  }

  private def(id: Id): PactDef<Id, Side> {
    const d = this.byId.get(id);
    if (!d) throw new Error(`unknown pact ${id}`);
    return d;
  }

  /** Nothing taken — also the defaults for host.load() */
  initial(): PactSave<Id, Side> {
    return { taken: [], sworn: {} };
  }

  /**
   * A loaded save made safe: known ids once each (in definition order), no two that exclude each other (the first in the
   * save stays), sworn sides only for taken Oaths and only sides they have. Pacts whose requirement is missing stay:
   * they were paid for (refund them yourself if the tree changed).
   */
  sanitize(raw: unknown): PactSave<Id, Side> {
    const r = record(raw);
    const want = list(r.taken).filter((x): x is Id => typeof x === 'string' && this.byId.has(x as Id));
    const keep = new Set<Id>();
    for (const id of want) if (![...keep].some((k) => this.excl.get(k)!.has(id))) keep.add(id);
    const taken = this.defs.filter((d) => keep.has(d.id)).map((d) => d.id);
    const sworn: Partial<Record<Id, Side>> = {};
    for (const [k, v] of Object.entries(record(r.sworn))) {
      const d = this.byId.get(k as Id);
      if (d?.sides && keep.has(d.id) && d.sides.some((s) => s.id === v)) sworn[d.id] = v as Side;
    }
    return { taken, sworn };
  }

  has(id: Id, save: PactSave<Id, Side>): boolean {
    return save.taken.includes(id);
  }

  /** Why `id` can't be taken now (not counting its price), or null */
  lockReason(id: Id, save: PactSave<Id, Side>): string | null {
    const d = this.def(id);
    const x = [...this.excl.get(id)!].find((o) => this.has(o, save));
    if (x) return `Excludes ${x}`;
    const missing = reqs(d.requires).find((r) => !this.has(r, save));
    if (missing) return `Needs ${missing}`;
    return this.lockFn?.(id, save) ?? null;
  }

  state(id: Id, save: PactSave<Id, Side>, coins: number): PactState {
    if (this.has(id, save)) return 'taken';
    if ([...this.excl.get(id)!].some((o) => this.has(o, save))) return 'excluded';
    if (this.lockReason(id, save)) return 'locked';
    return this.def(id).price <= coins ? 'affordable' : 'too-expensive';
  }

  /** Take a pact (an Oath starts sworn to `side`, default its first); null if it can't be taken now */
  take(id: Id, save: PactSave<Id, Side>, coins: number, side?: Side): { save: PactSave<Id, Side>; coins: number } | null {
    if (this.state(id, save, coins) !== 'affordable') return null;
    const d = this.def(id);
    if (side !== undefined && !d.sides?.some((s) => s.id === side)) return null;
    const taken = this.defs.filter((x) => x.id === id || this.has(x.id, save)).map((x) => x.id);
    const sworn = { ...save.sworn };
    if (side !== undefined) sworn[id] = side;
    return { save: { taken, sworn }, coins: coins - d.price };
  }

  /** Swear a taken Oath another way: free, any time between runs; null if it isn't a taken Oath with that side */
  swear(id: Id, side: Side, save: PactSave<Id, Side>): PactSave<Id, Side> | null {
    const d = this.def(id);
    if (!this.has(id, save) || !d.sides?.some((s) => s.id === side)) return null;
    return { taken: [...save.taken], sworn: { ...save.sworn, [id]: side } };
  }

  /** The side in force for a taken Oath (its first side when none was sworn), null otherwise */
  side(id: Id, save: PactSave<Id, Side>): Side | null {
    const d = this.def(id);
    if (!d.sides || !this.has(id, save)) return null;
    const s = save.sworn[id];
    return s !== undefined && d.sides.some((x) => x.id === s) ? s : d.sides[0].id;
  }

  /** Every side in force — what the run reads ("if (sides.has('thorns')) …") */
  sides(save: PactSave<Id, Side>): Set<Side> {
    const out = new Set<Side>();
    for (const id of save.taken) {
      const s = this.side(id, save);
      if (s !== null) out.add(s);
    }
    return out;
  }

  /** The numbers in force: the mods of every taken pact and of each Oath's sworn side, summed */
  mods(save: PactSave<Id, Side>): Record<string, number> {
    const out: Record<string, number> = {};
    const add = (m: Mods | undefined) => {
      for (const [k, v] of Object.entries(m ?? {})) out[k] = (out[k] ?? 0) + v;
    };
    for (const id of save.taken) {
      const d = this.def(id);
      add(d.mods);
      const s = this.side(id, save);
      add(d.sides?.find((x) => x.id === s)?.mods);
    }
    return out;
  }

  /**
   * Undo / break one pact at exactly its price; null if it isn't taken, a taken pact still needs it, or the undo would
   * lock another taken pact (a tier it opened: the game's `lock`)
   */
  release(id: Id, save: PactSave<Id, Side>, coins: number): { save: PactSave<Id, Side>; coins: number } | null {
    if (!this.has(id, save)) return null;
    if (this.defs.some((d) => this.has(d.id, save) && reqs(d.requires).includes(id))) return null;
    const sworn = { ...save.sworn };
    delete sworn[id];
    const after = { taken: save.taken.filter((x) => x !== id), sworn };
    const lock = this.lockFn;
    if (lock && save.taken.some((x) => x !== id && !lock(x, save) && lock(x, after))) return null;
    return { save: after, coins: coins + this.def(id).price };
  }

  /** Break every pact: all of it back (Dread Throne's two-tap "Break all pacts"); never refused, since nothing stays taken */
  releaseAll(save: PactSave<Id, Side>, coins: number): { save: PactSave<Id, Side>; coins: number } {
    return { save: this.initial(), coins: coins + save.taken.reduce((s, id) => s + (this.byId.get(id)?.price ?? 0), 0) };
  }

  /** The paths in definition order, each with its pacts in order (the screen's rows) */
  paths(): { path: string; ids: Id[] }[] {
    const out: { path: string; ids: Id[] }[] = [];
    for (const d of this.defs) {
      const p = d.path ?? '';
      const row = out.find((r) => r.path === p) ?? out[out.push({ path: p, ids: [] }) - 1];
      row.ids.push(d.id);
    }
    return out;
  }

  /** Everything's price (with forks a player spends less: one side of each) */
  totalCost(): number {
    return this.defs.reduce((s, d) => s + d.price, 0);
  }

  /** Share of what can be taken together (a fork counts once), 0..1 */
  progress(save: PactSave<Id, Side>): number {
    const blocked = this.defs.filter((d) => !this.has(d.id, save) && [...this.excl.get(d.id)!].some((o) => this.has(o, save))).length;
    const reachable = this.defs.length - blocked;
    return reachable ? save.taken.length / reachable : 1;
  }

  view(save: PactSave<Id, Side>, coins: number): PactRow<Id, Side>[] {
    return this.defs.map((d) => {
      const state = this.state(d.id, save, coins);
      const excludedBy = state === 'excluded' ? [...this.excl.get(d.id)!].find((o) => this.has(o, save)) : undefined;
      const needs = state === 'locked' ? reqs(d.requires).find((r) => !this.has(r, save)) : undefined;
      const reason = state === 'locked' && !needs ? this.lockFn?.(d.id, save) : null;
      const side = this.side(d.id, save);
      return {
        id: d.id,
        price: d.price,
        ...(d.path !== undefined ? { path: d.path } : {}),
        state,
        canBuy: state === 'affordable',
        progress: state === 'taken' ? 1 : d.price ? Math.min(1, Math.max(0, coins / d.price)) : 1,
        ...(side !== null ? { side } : {}),
        ...(needs ? { needs } : {}),
        ...(excludedBy ? { excludedBy } : {}),
        ...(reason ? { lockReason: reason } : {}),
      };
    });
  }

  /** Balance bot, a new player: the cheapest pact that can be taken, until none can */
  spendCheapest(save: PactSave<Id, Side>, coins: number): { save: PactSave<Id, Side>; coins: number; bought: Id[] } {
    return this.spend(save, coins, (d) => -d.price);
  }

  /** Balance bot, a careful player: the biggest `score` gain per coin first (score = the bot's measure of power) */
  spendBest(save: PactSave<Id, Side>, coins: number, score: (save: PactSave<Id, Side>) => number): { save: PactSave<Id, Side>; coins: number; bought: Id[] } {
    return this.spend(save, coins, (d, cur) => {
      const next = this.take(d.id, cur, Number.MAX_SAFE_INTEGER)!.save;
      return (score(next) - score(cur)) / Math.max(1, d.price);
    });
  }

  private spend(save: PactSave<Id, Side>, coins: number, rank: (d: PactDef<Id, Side>, cur: PactSave<Id, Side>) => number): { save: PactSave<Id, Side>; coins: number; bought: Id[] } {
    let cur = { save: this.sanitize(save), coins };
    const bought: Id[] = [];
    for (;;) {
      let pick: { d: PactDef<Id, Side>; r: number } | null = null;
      for (const d of this.defs) {
        if (this.state(d.id, cur.save, cur.coins) !== 'affordable') continue;
        const r = rank(d, cur.save);
        if (!pick || r > pick.r) pick = { d, r };
      }
      if (!pick) return { ...cur, bought };
      cur = this.take(pick.d.id, cur.save, cur.coins)!;
      bought.push(pick.d.id);
    }
  }
}

// --- RunChoices: pick 1 of N in a run ---------------------------------------------------------------------------

export interface RunChoiceDef<Id extends string = string> {
  id: Id;
  /** How often it comes up against the others (default 1): rarity */
  weight?: number;
  /** How many times it can be picked in one run (default 1) */
  max?: number;
  /** Offered only after this one was picked */
  requires?: Id;
  /** Never offered once any of these was picked (and the other way round) */
  excludes?: readonly Id[];
  /**
   * A filler ("+20 health", "a handful of coins"): offered only when the real cards can't fill an offer (late in a run,
   * most of them maxed: Frankengun's boss bench showed 1 card), never instead of one. No `max` by default (it can come
   * back every time); its requires / excludes / eligible still apply
   */
  fill?: boolean;
}

/** One run's choices: kept in the run's state (and in a mid-run save) */
export interface ChoicesState<Id extends string = string> {
  /** Times each was picked */
  picked: Partial<Record<Id, number>>;
  /** What is on offer now (empty between offers) */
  offer: Id[];
  /** Rerolls left */
  rerolls: number;
  /** The last offers (newest last), when RunChoicesOptions.recent is on: their cards come up less often */
  recent?: Id[][];
}

export interface RunChoicesOptions<Id extends string> {
  /** Cards per offer (default 3) */
  size?: number;
  /** Rerolls a run starts with (default 0; a rewarded ad can add one: addRerolls) */
  rerolls?: number;
  /** The game's own condition ("no Glass Candle below 20 wax", "no Moth Lantern for a snuffed candle") */
  eligible?: (id: Id, state: ChoicesState<Id>) => boolean;
  /**
   * Remember the last `offers` offers (and rerolls) and draw their cards at `weight` × their own (default off; a usual
   * setting is { offers: 2, weight: 0.25 }): the same three cards don't come back offer after offer (Frankengun's
   * drops kept a memory of 6). A card is only made rarer, never banned: a short pool still fills
   */
  recent?: { offers: number; weight?: number };
}

/**
 * Run choices: at a level-up, a floor or a shrine the game offers N cards and the player keeps one — the build is made in
 * the run, not in a menu. Weighted without replacement (no duplicates in an offer), stacks up to `max`, requirements and
 * exclusions, rerolls that avoid the cards just seen. Deterministic with the rng you pass (host.rng: ?seed=1 repeats it).
 * From Candle Crypt (QmaCyber/game9): a pick of three feats at every level-up, one reroll for a rewarded ad.
 */
export class RunChoices<Id extends string> {
  readonly defs: readonly RunChoiceDef<Id>[];
  readonly size: number;
  private readonly byId: Map<Id, RunChoiceDef<Id>>;
  private readonly excl: Map<Id, Set<Id>>;
  private readonly opts: RunChoicesOptions<Id>;

  constructor(defs: readonly RunChoiceDef<Id>[], opts: RunChoicesOptions<Id> = {}) {
    const ids = checkIds('choice', defs.map((d) => d.id));
    this.excl = new Map(defs.map((d) => [d.id, new Set<Id>()]));
    for (const d of defs) {
      if (d.weight !== undefined && !(Number.isFinite(d.weight) && d.weight > 0)) throw new Error(`choice ${d.id}: weight must be > 0`);
      if (d.max !== undefined && !(isInt(d.max) && d.max >= 1)) throw new Error(`choice ${d.id}: max must be an integer ≥ 1`);
      if (d.requires !== undefined && (!ids.has(d.requires) || d.requires === d.id)) throw new Error(`choice ${d.id} requires unknown ${d.requires}`);
      for (const x of d.excludes ?? []) {
        if (!ids.has(x) || x === d.id) throw new Error(`choice ${d.id} excludes unknown ${x}`);
        this.excl.get(d.id)!.add(x);
        this.excl.get(x)!.add(d.id);
      }
    }
    const size = opts.size ?? 3;
    if (!(isInt(size) && size >= 1)) throw new Error('run choices: size must be an integer ≥ 1');
    if (opts.rerolls !== undefined && !(isInt(opts.rerolls) && opts.rerolls >= 0)) throw new Error('run choices: rerolls must be an integer ≥ 0');
    if (opts.recent && !(isInt(opts.recent.offers) && opts.recent.offers >= 0)) throw new Error('run choices: recent.offers must be an integer ≥ 0');
    if (opts.recent?.weight !== undefined && !(Number.isFinite(opts.recent.weight) && opts.recent.weight > 0 && opts.recent.weight <= 1)) throw new Error('run choices: recent.weight must be in (0, 1]');
    if (defs.length && defs.every((d) => d.fill)) throw new Error('run choices: every choice is a filler: at least one real card');
    this.defs = defs;
    this.size = size;
    this.byId = new Map(defs.map((d) => [d.id, d]));
    this.opts = opts;
  }

  /** A new run: nothing picked, nothing on offer, the run's rerolls */
  start(): ChoicesState<Id> {
    return { picked: {}, offer: [], rerolls: this.opts.rerolls ?? 0 };
  }

  /** A loaded state made safe: known ids, counts clamped to 0..max, an offer of distinct eligible ids, rerolls ≥ 0 */
  sanitize(raw: unknown): ChoicesState<Id> {
    const r = record(raw);
    const picked: Partial<Record<Id, number>> = {};
    for (const [k, v] of Object.entries(record(r.picked))) {
      const d = this.byId.get(k as Id);
      if (d && typeof v === 'number' && Number.isFinite(v) && v >= 1) picked[d.id] = Math.min(d.max ?? 1, Math.floor(v));
    }
    const known = [...new Set(list(r.offer).filter((x): x is Id => typeof x === 'string' && this.byId.has(x as Id)))];
    const rr = r.rerolls;
    const out: ChoicesState<Id> = { picked, offer: [] as Id[], rerolls: typeof rr === 'number' && Number.isFinite(rr) && rr > 0 ? Math.floor(rr) : 0 };
    const keep = this.opts.recent?.offers ?? 0;
    if (keep > 0)
      out.recent = list(r.recent)
        .map((o) => list(o).filter((x): x is Id => typeof x === 'string' && this.byId.has(x as Id)))
        .slice(-keep);
    return { ...out, offer: known.filter((id) => this.eligible(id, out)).slice(0, this.size) };
  }

  count(state: ChoicesState<Id>, id: Id): number {
    return state.picked[id] ?? 0;
  }

  /** Can `id` be offered now: not maxed, its requirement picked, nothing it excludes picked, the game's condition */
  eligible(id: Id, state: ChoicesState<Id>): boolean {
    const d = this.byId.get(id);
    if (!d) return false;
    if (this.count(state, id) >= (d.max ?? (d.fill ? Infinity : 1))) return false;
    if (d.requires && !this.count(state, d.requires)) return false;
    if ([...this.excl.get(id)!].some((x) => this.count(state, x) > 0)) return false;
    return this.opts.eligible?.(id, state) ?? true;
  }

  /** Every real card that could be offered now (maxed, excluded and fillers left out) */
  pool(state: ChoicesState<Id>): Id[] {
    return this.defs.filter((d) => !d.fill && this.eligible(d.id, state)).map((d) => d.id);
  }

  /** The fillers that could top up an offer now */
  fillers(state: ChoicesState<Id>): Id[] {
    return this.defs.filter((d) => d.fill && this.eligible(d.id, state)).map((d) => d.id);
  }

  /**
   * Draw `n` distinct eligible choices, weighted, without replacement. `avoid` is left out while enough others remain
   * (a reroll shows new cards when there are any); cards of the recent offers (RunChoicesOptions.recent) are drawn at the
   * recent weight; when the real cards run out, fillers top the offer up. One rng call per card: the same seed draws
   * the same cards.
   */
  draw(state: ChoicesState<Id>, rand: Rand, n = this.size, avoid: readonly Id[] = []): Id[] {
    const pool = this.pool(state);
    const fresh = pool.filter((id) => !avoid.includes(id));
    const fill = this.fillers(state);
    const seen = new Set(this.opts.recent?.offers ? (state.recent ?? []).slice(-this.opts.recent.offers).flat() : []);
    const rare = this.opts.recent?.weight ?? 0.25;
    const weight = (id: Id) => (this.byId.get(id)!.weight ?? 1) * (seen.has(id) ? rare : 1);
    // Fill from the fresh ones first; only when they run out, the avoided ones come back; then the fillers
    const out: Id[] = [];
    for (const from of [fresh, pool, fill.filter((id) => !avoid.includes(id)), fill]) {
      const left = from.filter((id) => !out.includes(id));
      while (out.length < n && left.length) {
        const total = left.reduce((s, id) => s + weight(id), 0);
        let x = roll(rand) * total;
        let i = 0;
        for (; i < left.length - 1; i++) {
          x -= weight(left[i]);
          if (x < 0) break;
        }
        out.push(left.splice(i, 1)[0]);
      }
    }
    return out;
  }

  /** The recent offers with this one added (RunChoicesOptions.recent), or none when it is off */
  private remember(state: ChoicesState<Id>, offer: Id[]): Pick<ChoicesState<Id>, 'recent'> {
    const keep = this.opts.recent?.offers ?? 0;
    return keep > 0 ? { recent: [...(state.recent ?? []), offer].slice(-keep) } : {};
  }

  /** Put a new offer on the table (an empty offer when nothing is eligible: skip the pick) */
  offer(state: ChoicesState<Id>, rand: Rand): ChoicesState<Id> {
    const offer = this.draw(state, rand);
    return { ...state, picked: { ...state.picked }, offer, ...this.remember(state, offer) };
  }

  /** Spend a reroll: new cards, avoiding the ones on offer where possible; null without rerolls or anything to show */
  reroll(state: ChoicesState<Id>, rand: Rand): ChoicesState<Id> | null {
    if (state.rerolls <= 0 || !state.offer.length) return null;
    const offer = this.draw(state, rand, this.size, state.offer);
    return { ...state, picked: { ...state.picked }, offer, rerolls: state.rerolls - 1, ...this.remember(state, offer) };
  }

  /** More rerolls (a rewarded ad, a relic) */
  addRerolls(state: ChoicesState<Id>, n = 1): ChoicesState<Id> {
    return { ...state, picked: { ...state.picked }, offer: [...state.offer], rerolls: state.rerolls + Math.max(0, Math.floor(n)) };
  }

  /** Keep one card of the offer; the offer closes. null if `id` isn't on offer or no longer eligible (maxed, excluded) */
  pick(state: ChoicesState<Id>, id: Id): ChoicesState<Id> | null {
    if (!state.offer.includes(id) || !this.eligible(id, state)) return null;
    return { picked: { ...state.picked, [id]: this.count(state, id) + 1 }, offer: [], rerolls: state.rerolls, ...(state.recent ? { recent: state.recent } : {}) };
  }

  /**
   * Grant one without an offer (a starting blessing, a shrine); null if it isn't eligible. An open offer keeps only the
   * cards still eligible after it (a maxed or excluded card leaves the table)
   */
  grant(state: ChoicesState<Id>, id: Id): ChoicesState<Id> | null {
    if (!this.eligible(id, state)) return null;
    const next = { ...state, picked: { ...state.picked, [id]: this.count(state, id) + 1 }, offer: [] as Id[] };
    return { ...next, offer: state.offer.filter((x) => this.eligible(x, next)) };
  }
}
