// Automa: a rival (or a partner) driven by a short ordered list of priority rules, the way board games run their solo
// opponents (Automa Factory's Viticulture, Scythe, Wingspan; Heat's Legends; Spirit Island's invader cards). Each turn
// it takes the first rule that can act. next() is pure: it returns the move AND a ≤ 6-word explanation to draw before
// the move resolves (the telegraphed intent: Slay the Spire's intents, Wildfrost's counters), so the solo game is a
// puzzle the player reads, not a dice roll. docs/research/board-games-2026-10.md §1.18 (block #4).
//
// Deterministic by seed: the automa's state (its level, the rng's position, its deck of priority cards) is plain JSON
// kept in the game's save; the same game state and automa state always give the same intent.
//
//   const rival = new Automa<Market, Buy>({
//     rules: [
//       { id: 'gold', say: 'grabs any gold crate', move: (m) => m.crates.find((c) => c.gold) ?? null },
//       { id: 'cheap', say: 'takes the cheapest crate', move: (m, r) => best(m.crates, (c) => -c.price, r) },
//     ],
//     levels: [{ name: 'Rookie', slip: 0.3 }, { name: 'Pro' }],
//   });
//   let a = rival.start(seed, 1);
//   const intent = rival.next(market, a);   // { move, rule: 'cheap', say: 'takes the cheapest crate', state }
//   // draw intent.say over the rival; on its turn: market = apply(market, intent.move); a = intent.state;

import { seededRng, type SeededRng } from './rng.ts';

/** The longest intent: the same budget as a hint (HINT_MAX_WORDS in hints.ts) — read in a glance */
export const AUTOMA_MAX_WORDS = 6;

export interface AutomaRule<S, M> {
  id: string;
  /** What the player is told, ≤ 6 words ("takes the cheapest crate"), a strings key for host.t, or made from the move */
  say: string | ((move: M, state: S) => string);
  /** The move this rule makes now, or null when it can't (then the next rule is tried); `rand` breaks ties */
  move: (state: S, rand: SeededRng) => M | null;
  /** The lowest level that uses it (default 0): a harder rival knows more rules */
  from?: number;
}

export interface AutomaLevel {
  /** What the level is called on the difficulty picker ("Rookie", "Pro") */
  name?: string;
  /** The chance it passes over the first rule that applies and takes the next one (an easier rival errs), 0–1 */
  slip?: number;
}

export interface AutomaOptions<S, M> {
  /** In priority order: the first that can act, acts */
  rules: readonly AutomaRule<S, M>[];
  /** Difficulty levels (default one); level i uses the rules with from ≤ i */
  levels?: readonly AutomaLevel[];
  /**
   * A deck of priority cards (each an order of rule ids), one drawn a turn and reshuffled when spent: the rival's habits
   * vary from turn to turn but stay readable (show the card). Without it the rules' own order is used every turn.
   */
  deck?: readonly (readonly string[])[];
  /** Words an explanation may have (default AUTOMA_MAX_WORDS; 0: no check) */
  maxWords?: number;
}

/** The automa's own state: plain JSON, saved with the game */
export interface AutomaState {
  level: number;
  rng: number;
  /** The priority cards left in its deck (indices into options.deck), the next first */
  deck: number[];
  /** Turns taken */
  turn: number;
}

export interface Intent<M> {
  move: M;
  /** The rule that made it */
  rule: string;
  /** The explanation to show (≤ maxWords) */
  say: string;
  /** The priority card it played (an index into options.deck), null without a deck */
  card: number | null;
  /** It passed over a better rule (an easier level's slip) */
  slipped: boolean;
  /** The automa's state after this move: keep it once the move is made */
  state: AutomaState;
}

const isInt = (n: unknown): n is number => typeof n === 'number' && Number.isSafeInteger(n);
const words = (t: string) => t.trim().split(/\s+/).filter(Boolean).length;

/** The highest-scoring item, ties broken by `rand` (null for an empty list): "the cheapest crate" is best(crates, c => -c.price, r) */
export function best<T>(items: readonly T[], score: (item: T) => number, rand: SeededRng | (() => number)): T | null {
  let top: T[] = [];
  let hi = -Infinity;
  for (const it of items) {
    const v = score(it);
    if (Number.isNaN(v)) continue;
    if (v > hi) {
      hi = v;
      top = [it];
    } else if (v === hi) top.push(it);
  }
  if (!top.length) return null;
  return top.length === 1 ? top[0] : top[Math.floor((typeof rand === 'function' ? rand() : (rand as SeededRng).random()) * top.length)];
}

export class Automa<S, M> {
  readonly rules: readonly AutomaRule<S, M>[];
  readonly levels: readonly AutomaLevel[];
  readonly deck: readonly (readonly string[])[];
  private readonly maxWords: number;
  private readonly byId: Map<string, AutomaRule<S, M>>;

  constructor(opts: AutomaOptions<S, M>) {
    if (!opts.rules.length) throw new Error('automa: at least one rule');
    this.maxWords = opts.maxWords ?? AUTOMA_MAX_WORDS;
    this.byId = new Map();
    for (const r of opts.rules) {
      if (!r.id || this.byId.has(r.id)) throw new Error(`automa: rule "${r.id}" is empty or twice`);
      if (typeof r.say === 'string') this.checkWords(r.id, r.say);
      if (r.from !== undefined && !(isInt(r.from) && r.from >= 0)) throw new Error(`automa: rule ${r.id}: from must be an integer ≥ 0`);
      this.byId.set(r.id, r);
    }
    this.levels = opts.levels?.length ? opts.levels : [{}];
    for (const l of this.levels) if (l.slip !== undefined && !(l.slip >= 0 && l.slip <= 1)) throw new Error('automa: slip must be between 0 and 1');
    this.deck = opts.deck ?? [];
    for (const card of this.deck) {
      if (!card.length) throw new Error('automa: an empty priority card');
      for (const id of card) if (!this.byId.has(id)) throw new Error(`automa: a priority card names unknown rule ${id}`);
    }
    this.rules = opts.rules;
  }

  /** A new rival at a level (clamped to the levels there are), seeded */
  start(seed: number, level = 0): AutomaState {
    return { level: Math.min(this.levels.length - 1, Math.max(0, Math.floor(level))), rng: seed >>> 0, deck: [], turn: 0 };
  }

  /** A loaded state made safe */
  sanitize(raw: unknown, seed = 1): AutomaState {
    const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
    const level = isInt(r.level) ? Math.min(this.levels.length - 1, Math.max(0, r.level)) : 0;
    const deck = Array.isArray(r.deck) ? (r.deck as unknown[]).filter((i): i is number => isInt(i) && i >= 0 && i < this.deck.length) : [];
    return { level, rng: isInt(r.rng) && r.rng >= 0 && r.rng < 2 ** 32 ? r.rng : seed >>> 0, deck: [...new Set(deck)], turn: isInt(r.turn) && r.turn >= 0 ? r.turn : 0 };
  }

  /** The name of a level (for the picker), or "Level n" */
  levelName(level: number): string {
    return this.levels[level]?.name ?? `Level ${level + 1}`;
  }

  /** The rules this level knows, in the order they are tried this turn (with a deck: the card on top, then the rest) */
  order(a: AutomaState): string[] {
    const known = this.rules.filter((r) => (r.from ?? 0) <= a.level).map((r) => r.id);
    if (!this.deck.length) return known;
    const card = this.peekCard(a).card;
    const first = this.deck[card].filter((id) => known.includes(id));
    return [...first, ...known.filter((id) => !first.includes(id))];
  }

  /**
   * What it will do: the first rule (in this turn's order) whose move isn't null, with its explanation and the
   * automa's state after the move. Pure — call it to telegraph, call it again after the player's move (the same card
   * and rng, the move fitted to the new state). null when no rule can act (it passes: keep `a`, or advance it with pass()).
   */
  next(game: S, a: AutomaState): Intent<M> | null {
    const r = seededRng(a.rng);
    const { card, deck } = this.peekCard(a, r);
    const slip = this.levels[a.level]?.slip ?? 0;
    const slipNow = slip > 0 && r.random() < slip;
    let first: { rule: AutomaRule<S, M>; move: M } | null = null;
    for (const id of this.order({ ...a, deck })) {
      const rule = this.byId.get(id)!;
      const move = rule.move(game, r);
      if (move === null || move === undefined) continue;
      if (!slipNow) return this.intent(game, a, rule, move, card, false, deck, r);
      if (!first) first = { rule, move };
      else return this.intent(game, a, rule, move, card, true, deck, r);
    }
    return first ? this.intent(game, a, first.rule, first.move, card, false, deck, r) : null;
  }

  /** It passes this turn (no rule could act): the card is spent, the turn counted */
  pass(a: AutomaState): AutomaState {
    const r = seededRng(a.rng);
    const { deck } = this.peekCard(a, r);
    r.random();
    return { level: a.level, rng: r.state(), deck: this.deck.length ? deck.slice(1) : [], turn: a.turn + 1 };
  }

  private intent(game: S, a: AutomaState, rule: AutomaRule<S, M>, move: M, card: number, slipped: boolean, deck: number[], r: SeededRng): Intent<M> {
    const say = typeof rule.say === 'string' ? rule.say : rule.say(move, game);
    if (typeof rule.say !== 'string') this.checkWords(rule.id, say);
    return {
      move,
      rule: rule.id,
      say,
      card: this.deck.length ? card : null,
      slipped,
      state: { level: a.level, rng: r.state(), deck: this.deck.length ? deck.slice(1) : [], turn: a.turn + 1 },
    };
  }

  /** This turn's priority card, reshuffling the deck when it is spent (with `r`: the shuffle uses it) */
  private peekCard(a: AutomaState, r: SeededRng = seededRng(a.rng)): { card: number; deck: number[] } {
    if (!this.deck.length) return { card: -1, deck: [] };
    let deck = a.deck;
    if (!deck.length) {
      deck = this.deck.map((_, i) => i);
      for (let i = deck.length - 1; i > 0; i--) {
        const j = r.int(i + 1);
        [deck[i], deck[j]] = [deck[j], deck[i]];
      }
    }
    return { card: deck[0], deck };
  }

  private checkWords(id: string, say: string): void {
    if (this.maxWords > 0 && words(say) > this.maxWords)
      throw new Error(`automa: rule ${id} says "${say}" — ${words(say)} words, the most is ${this.maxWords} (a glance: show it, don't explain it)`);
  }
}
