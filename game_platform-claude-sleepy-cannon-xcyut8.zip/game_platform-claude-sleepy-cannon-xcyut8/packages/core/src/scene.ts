// A scene is one screen: menu, round, result... The app calls update → draw every frame and passes taps.

/** A tappable element as QA and layout checks see it. Coordinates are CSS pixels. */
export interface ProbeTarget {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  /** Child-facing (the audience's minimum touch size applies) or grown-up (44 px is enough) */
  audience?: 'player' | 'grown-up';
}

export interface Scene {
  /** Stable scene id for events and QA: 'menu', 'round', 'reward', ... */
  readonly id: string;
  enter?(): void;
  exit?(): void;
  update(dt: number): void;
  draw(ctx: CanvasRenderingContext2D): void;
  pointer(x: number, y: number): void;
  /** System Back button. Return true if the scene handled it itself */
  back?(): boolean;
  /** The home scene: Back minimizes the app */
  readonly isHome?: boolean;
  /** Tappable elements on screen right now — for automated layout checks */
  probe?(): ProbeTarget[];
}
