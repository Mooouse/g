// @gp/core/sound — music and ambience for code games, synthesized on the host's AudioContext: no sound files, a few KB.
//
//   const mixer = createMixer(host, save.volumes);          // three buses: music, ambient, sfx — each with its volume
//   const music = createMusic(mixer, {
//     menu: musicTheme('calm', 11),                          // a mood and a seed: the same seed, the same tune
//     forest: musicTheme('bright', 23, { root: 'G4' }),
//     boss: bossTheme(musicTheme('bright', 23), 61),         // a driving variant in the same key
//   });
//   const ambience = createAmbience(mixer, { seed: 7 });
//   music.play('forest'); ambience.set({ wind: 0.5, birds: 0.6 }); // crossfades, never a click
//   mySound.connect(mixer.bus('sfx') ?? host.audio!.out);    // your effects: on the sfx bus (its slider), ducking music
//   mixer.duck();                                            // under a big hit: music and ambience dip for a moment
//   music.hold(true); ambience.hold(true);                   // the pause screen: fade out, schedule nothing
//
// An action game's adaptive score instead of themes: createSceneMusic(mixer) — scenes (menu, explore, fight, boss,
// enrage, shop) whose layers fade with the scene and an intensity, a key and a tempo per stage, an alarm, a crowd's roar
// and a riser on the music bus:
//
//   const score = createSceneMusic(mixer);                   // SCENES and STAGES, or your own
//   score.scene('fight', stage); score.intensity(0.7); score.alarm();
//
// The rules it keeps for you (Firefly Rush 2.1.0 wrote them by hand; a reviewer caught its timers running on a quiet
// screen): every sound goes through host.audio.out (the portal's mute and the ad pause silence it); nothing is
// scheduled while the portal mutes, the host is paused (an ad, a hidden tab) or the context isn't running; the timers
// stop when nothing plays, while held and while the host is paused; every note and layer starts and ends on an
// envelope; a slow frame never makes it stutter (it schedules 0.25 s ahead on the context's clock) and a suspended
// context never bursts the missed notes when it comes back.

// Effects: createSfx(mixer, sounds) — files and procedural recipes on the sfx bus (sfx.ts):
//
//   const sfx = createSfx(mixer, { coin: coinUrl, hit: sfxRecipe('hit'), ping: sfxRecipe('glass') });
//   sfx.play('hit', { at: enemy, rate: 1.1 }); sfx.say('line1'); sfx.hush();

export { createSfx, sfxRecipe, MATERIALS, RECIPES, SFX_MAX_VOICES, type Sfx, type SfxDef, type SfxListener, type SfxPlayOptions, type SfxRecipe, type SfxSource, type RecipeKind, type RecipeOptions, type Material, type Mode } from './sfx';

// --- The host side -------------------------------------------------------------------------------------------------

/** What the module needs of the host (GameHost has all of it) */
export interface SoundHost {
  readonly audio: { ctx: AudioContext; out: GainNode } | null;
  readonly paused: boolean;
  readonly portalMuted: boolean;
  onPause?(fn: () => void): void;
  onResume?(fn: () => void): void;
}

export type Bus = 'music' | 'ambient' | 'sfx';
export type Volumes = Record<Bus, number>;

/** The sliders' defaults: music under the effects, the ambience under the music */
export const DEFAULT_VOLUMES: Volumes = { music: 0.6, ambient: 0.6, sfx: 1 };
/** Each bus at its slider's 100 %: music ≈ 4 dB, the ambience ≈ 7 dB under the effects */
const BUS_LEVEL: Volumes = { music: 0.65, ambient: 0.45, sfx: 1 };

export interface Mixer {
  /** The bus to connect to (null until the player's first tap: browsers block audio before one) */
  bus(kind: Bus): GainNode | null;
  /** The host's AudioContext (null until the first tap) */
  ctx(): AudioContext | null;
  volume(kind: Bus): number;
  /** 0–1, a slider's value; save `volumes()` with the game */
  setVolume(kind: Bus, v: number): void;
  volumes(): Volumes;
  /** Music and ambience dip by `depth` (0–1) for `sec` and come back: under an explosion, a boss roar, a jingle */
  duck(depth?: number, sec?: number): void;
  /** Nothing may start now: the portal mutes, the host is paused or the context isn't running */
  silent(): boolean;
  /** Called on the host's pause and resume (the music and the ambience stop their timers) */
  onPause(fn: () => void): void;
  onResume(fn: () => void): void;
}

export function createMixer(host: SoundHost, volumes: Partial<Volumes> = {}): Mixer {
  const vol: Volumes = { ...DEFAULT_VOLUMES };
  for (const k of Object.keys(vol) as Bus[]) if (typeof volumes[k] === 'number') vol[k] = clamp01(volumes[k]!);
  let ctx: AudioContext | null = null;
  let buses: Record<Bus, GainNode> | null = null;
  let ducker: GainNode | null = null;
  const pauseFns: (() => void)[] = [];
  const resumeFns: (() => void)[] = [];
  host.onPause?.(() => pauseFns.forEach((f) => f()));
  host.onResume?.(() => resumeFns.forEach((f) => f()));

  function setup(): boolean {
    const a = host.audio;
    if (!a) return false;
    if (ctx === a.ctx && buses) return true;
    // A new context: the old one's nodes can't be reused
    ctx = a.ctx;
    ducker = ctx.createGain();
    // A soft top on music and ambience: nothing above ~9 kHz but air, so the beds and the tune never sound "electric"
    // on laptop speakers (the owner: «чуть мягче его сделай», 2026-10-10)
    const soft = ctx.createBiquadFilter();
    soft.type = 'lowpass';
    soft.frequency.value = 9000;
    soft.Q.value = 0.5;
    ducker.connect(soft).connect(a.out);
    const make = (k: Bus, to: AudioNode) => {
      const g = ctx!.createGain();
      g.gain.value = vol[k] * BUS_LEVEL[k];
      g.connect(to);
      return g;
    };
    buses = { music: make('music', ducker), ambient: make('ambient', ducker), sfx: make('sfx', a.out) };
    // Each bus says what it carries: gp qa's sound section tells the effects from the music by it (a property, no cost)
    for (const k of Object.keys(buses) as Bus[]) Object.defineProperty(buses[k], '__gpBus', { value: k });
    return true;
  }

  return {
    bus: (kind) => (setup() ? buses![kind] : null),
    ctx: () => (setup() ? ctx : null),
    volume: (kind) => vol[kind],
    setVolume(kind, v) {
      vol[kind] = clamp01(v);
      if (setup()) ramp(buses![kind].gain, ctx!, vol[kind] * BUS_LEVEL[kind], 0.08);
    },
    volumes: () => ({ ...vol }),
    duck(depth = 0.5, sec = 0.6) {
      if (!setup() || !ducker) return;
      const g = ducker.gain;
      const now = ctx!.currentTime;
      g.cancelScheduledValues(now);
      g.setValueAtTime(g.value, now);
      g.linearRampToValueAtTime(1 - clamp01(depth), now + 0.05);
      g.setValueAtTime(1 - clamp01(depth), now + 0.05 + sec * 0.4);
      g.linearRampToValueAtTime(1, now + 0.05 + sec);
    },
    silent: () => host.portalMuted || host.paused || !host.audio || host.audio.ctx.state !== 'running',
    onPause: (fn) => pauseFns.push(fn),
    onResume: (fn) => resumeFns.push(fn),
  };
}

// --- Music ---------------------------------------------------------------------------------------------------------

export type ScaleName = 'major' | 'minor' | 'dorian' | 'harmonic' | 'pentatonic' | 'minorPentatonic' | 'phrygian' | 'lydian';
export const SCALES: Record<ScaleName, number[]> = {
  major: [0, 2, 4, 5, 7, 9, 11],
  minor: [0, 2, 3, 5, 7, 8, 10],
  dorian: [0, 2, 3, 5, 7, 9, 10],
  harmonic: [0, 2, 3, 5, 7, 8, 11],
  pentatonic: [0, 2, 4, 7, 9],
  minorPentatonic: [0, 3, 5, 7, 10],
  phrygian: [0, 1, 3, 5, 7, 8, 10],
  lydian: [0, 2, 4, 6, 7, 9, 11],
};

/** A theme: a short loop built from a seed — a pad on the chords, a bass, an arpeggio, a melody, drums, an echo */
export interface MusicTheme {
  bpm: number;
  /** The key's root: a MIDI note (60 = C4) or a name ('C4', 'F#3', 'Bb4') */
  root: number | string;
  scale: ScaleName | number[];
  /** Chord roots as scale degrees (0-based), one per bar, repeated over the loop */
  chords: number[];
  /** Arpeggio over 16 steps: a chord tone (0–3) or −1, a rest. Empty: no arpeggio */
  arp?: number[];
  /** Melody density 0–1 (0: none) */
  melody?: number;
  bass?: 'long' | 'pulse' | 'drive' | 'none';
  /** 0 none, 1 soft hats, 2 a kick and hats */
  drums?: 0 | 1 | 2;
  pad?: OscillatorType;
  lead?: OscillatorType;
  /** The pad's filter cutoff, Hz: dark 800 … bright 2400 */
  bright?: number;
  /** The echo's level 0–1 */
  echo?: number;
  /** Bars in the loop (default 8) */
  bars?: number;
  seed: number;
}

export type Mood = 'calm' | 'bright' | 'cozy' | 'mystery' | 'dark' | 'tense' | 'heroic' | 'spooky';

const MOODS: Record<Mood, Omit<MusicTheme, 'seed'>> = {
  // A dreamy menu: slow, open chords, a sparse bell
  calm: { bpm: 72, root: 60, scale: 'major', chords: [0, 5, 3, 4], arp: [0, -1, -1, 2, -1, -1, 1, -1, 3, -1, -1, 2, -1, -1, -1, -1], melody: 0.3, bass: 'long', drums: 0, pad: 'triangle', lead: 'sine', bright: 1400 },
  // A summer day: a running pluck, soft hats
  bright: { bpm: 100, root: 67, scale: 'major', chords: [0, 4, 5, 3], arp: [0, 1, 2, 3, 2, 1, 0, 1, 0, 1, 2, 3, 2, 3, 1, 2], melody: 0.55, bass: 'pulse', drums: 1, pad: 'triangle', lead: 'triangle', bright: 2200 },
  // A tavern, a shop, a home screen: pentatonic, warm, unhurried
  cozy: { bpm: 88, root: 65, scale: 'pentatonic', chords: [0, 3, 1, 4], arp: [0, -1, 1, -1, 2, -1, 1, -1, 0, -1, 1, -1, 3, -1, 2, -1], melody: 0.45, bass: 'pulse', drums: 1, pad: 'sine', lead: 'triangle', bright: 1600 },
  // Mist, a marsh, a puzzle: dorian, dripping staccato
  mystery: { bpm: 84, root: 62, scale: 'dorian', chords: [0, 3, 0, 6], arp: [0, -1, 2, -1, -1, 1, -1, 3, 0, -1, -1, 2, -1, 3, -1, -1], melody: 0.4, bass: 'pulse', drums: 1, pad: 'sine', lead: 'sine', bright: 1100 },
  // Ruins, a crypt: harmonic minor, slow, a choir-like pad
  dark: { bpm: 70, root: 57, scale: 'harmonic', chords: [0, 5, 4, 0], arp: [0, -1, -1, -1, 2, -1, -1, -1, 1, -1, -1, 3, -1, -1, -1, -1], melody: 0.35, bass: 'long', drums: 0, pad: 'sawtooth', lead: 'sine', bright: 900 },
  // A timer running out, a chase: minor, driving eighths
  tense: { bpm: 120, root: 62, scale: 'minor', chords: [0, 0, 5, 6], arp: [0, 2, 0, 3, 0, 2, 0, 3, 0, 2, 0, 3, 1, 2, 3, 2], melody: 0.3, bass: 'drive', drums: 2, pad: 'sawtooth', lead: 'triangle', bright: 1500 },
  // A victory road, a battle: major, bold, a kick
  heroic: { bpm: 112, root: 62, scale: 'major', chords: [0, 4, 5, 3], arp: [0, 2, 3, 2, 0, 2, 3, 2, 1, 2, 3, 2, 0, 3, 2, 1], melody: 0.6, bass: 'drive', drums: 2, pad: 'sawtooth', lead: 'square', bright: 2000 },
  // A haunted house: phrygian, sparse, a low drone
  spooky: { bpm: 66, root: 55, scale: 'phrygian', chords: [0, 1, 0, 6], arp: [0, -1, -1, 1, -1, -1, -1, -1, 3, -1, -1, -1, 2, -1, -1, -1], melody: 0.25, bass: 'long', drums: 0, pad: 'sine', lead: 'sine', bright: 800 },
};

/** A theme from a mood: the seed makes it the game's own tune (another seed, another melody); `over` changes any field */
export function musicTheme(mood: Mood, seed: number, over: Partial<MusicTheme> = {}): MusicTheme {
  return { ...MOODS[mood], ...over, seed };
}

/** A boss or a final stretch in a theme's key: faster, a driving bass, a kick, a tense arpeggio */
export function bossTheme(t: MusicTheme, seed: number, over: Partial<MusicTheme> = {}): MusicTheme {
  const major = t.scale === 'major' || t.scale === 'pentatonic' || t.scale === 'lydian';
  return { ...t, bpm: Math.max(124, t.bpm + 28), scale: major ? 'minor' : t.scale, chords: [0, 5, 6, 4], arp: [0, 2, 3, 2, 0, 2, 3, 2, 1, 2, 3, 2, 1, 3, 2, 3], melody: 0.5, bass: 'drive', drums: 2, pad: 'sawtooth', lead: 'square', bright: 1700, ...over, seed };
}

/** A note of a composed loop */
export interface Note {
  step: number;
  midi: number;
  /** Length in steps (16 per bar) */
  len: number;
  part: 'pad' | 'bass' | 'arp' | 'lead' | 'kick' | 'hat';
  vel: number;
}

const STEPS = 16;
const NOTE_NAMES: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };

/** 'C4' → 60, 'F#3' → 54, 'Bb4' → 70; a number stays as it is */
export function midiOf(root: number | string): number {
  if (typeof root === 'number') return root;
  const m = /^([A-Ga-g])([#b]?)(-?\d)$/.exec(root.trim());
  if (!m) throw new Error(`music: a root like 'C4' or 'F#3' (or a MIDI number), not '${root}'`);
  return 12 * (Number(m[3]) + 1) + NOTE_NAMES[m[1].toUpperCase()] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
}

const hz = (midi: number) => 440 * 2 ** ((midi - 69) / 12);

/** A theme's loop as notes. Pure: the same theme, the same notes (a test can pin a tune) */
export function compose(d: MusicTheme): Note[] {
  const rand = seeded(d.seed);
  const scale = Array.isArray(d.scale) ? d.scale : SCALES[d.scale];
  const n = scale.length;
  const root = midiOf(d.root);
  const deg = (k: number) => root + Math.floor(k / n) * 12 + scale[((k % n) + n) % n];
  /** High notes come down by octaves (a bell, never a whistle), the lowest bass up (a rumble no speaker plays) */
  const tame = (m: number) => {
    while (m > 86) m -= 12;
    while (m < 28) m += 12;
    return m;
  };
  // A chord of 4 tones: every other scale step (a pentatonic's thirds are its 2nd step too)
  const chord = (c: number) => [c, c + 2, c + 4, c + 6];
  const bars = d.bars ?? 8;
  const melody = d.melody ?? 0.4;
  const bass = d.bass ?? 'pulse';
  const notes: Note[] = [];
  let prev = n;
  for (let bar = 0; bar < bars; bar++) {
    const c = d.chords[bar % d.chords.length];
    const tones = chord(c);
    const s0 = bar * STEPS;
    for (const k of [0, 1, 2]) notes.push({ step: s0, midi: tame(deg(tones[k]) - 12), len: STEPS, part: 'pad', vel: 0.5 });
    if (bass === 'long') notes.push({ step: s0, midi: tame(deg(c) - 24), len: STEPS, part: 'bass', vel: 0.8 });
    else if (bass !== 'none')
      for (let s = 0; s < STEPS; s += bass === 'drive' ? 2 : 4)
        notes.push({ step: s0 + s, midi: tame(deg(c) - 24 + (bass === 'pulse' && s === 12 ? 7 : 0)), len: bass === 'drive' ? 1.5 : 3, part: 'bass', vel: s % 8 === 0 ? 0.9 : 0.65 });
    (d.arp ?? []).forEach((k, s) => {
      if (k >= 0 && s < STEPS) notes.push({ step: s0 + s, midi: tame(deg(tones[k % 4]) + (bar % 4 === 3 && s > 11 ? 12 : 0)), len: 1.5, part: 'arp', vel: s % 4 === 0 ? 0.8 : 0.55 });
    });
    // The melody steps from its last note toward chord tones, in phrases of 4 bars (bars 4–7 answer bars 0–3)
    for (let s = 0; melody > 0 && s < STEPS; s += 2) {
      if (rand() > melody * (s % 4 === 0 ? 1.4 : 0.7)) continue;
      const target = tones[Math.floor(rand() * 3)] + n;
      prev += Math.sign(target - prev) * (rand() < 0.6 ? 1 : 2);
      if (Math.abs(target - prev) > 5) prev = target;
      const len = rand() < 0.4 ? 4 : 2;
      const cadence = bar % 8 === 7 && s >= 8;
      notes.push({ step: s0 + s, midi: tame(deg(cadence ? tones[0] + n : prev)), len, part: 'lead', vel: 0.7 });
    }
    const drums = d.drums ?? 0;
    if (drums)
      for (let s = 0; s < STEPS; s++) {
        if (drums === 2 && s % 4 === 0) notes.push({ step: s0 + s, midi: 0, len: 1, part: 'kick', vel: s % 8 === 0 ? 1 : 0.7 });
        if ((drums === 1 && s % 4 === 2) || (drums === 2 && s % 2 === 1)) notes.push({ step: s0 + s, midi: 0, len: 1, part: 'hat', vel: s % 4 === 2 ? 0.7 : 0.4 });
      }
  }
  return notes.sort((x, y) => x.step - y.step);
}

export interface Music {
  /** The theme to play now (null: none). A new theme crossfades in; the same one goes on */
  play(theme: string | null): void;
  /** The theme asked for last */
  readonly theme: string | null;
  /** Hold (the pause screen): fade out, schedule nothing; release fades back in */
  hold(on: boolean): void;
  /** Timers running now (a test, and `gp qa`, can see the music stands still) */
  readonly ticking: boolean;
}

interface Playing {
  name: string;
  theme: MusicTheme;
  gain: GainNode;
  send: GainNode;
  notes: Note[];
  next: number;
  loopAt: number;
  stepSec: number;
  stopAt: number;
  /** Odd passes leave the melody out (a breath): a long level doesn't hear one loop on repeat */
  pass: number;
}

const FADE = 1.4;
const AHEAD = 0.25;

export function createMusic(mixer: Mixer, themes: Record<string, MusicTheme>): Music {
  let ctx: AudioContext | null = null;
  let bus: GainNode | null = null;
  let hold: GainNode | null = null;
  let echo: DelayNode | null = null;
  let held = false;
  let want: string | null = null;
  const playing: Playing[] = [];
  const composed = new Map<string, Note[]>();
  const timer = ticker(50, tick);
  // Asked to play before the player's first tap (no context yet): look again 4× a second until there is one
  const waiting = ticker(250, () => {
    if (mixer.ctx()) {
      waiting.stop();
      apply();
    }
  });
  mixer.onPause(() => timer.stop());
  mixer.onResume(() => apply());

  function setup(): boolean {
    const b = mixer.bus('music');
    const c = mixer.ctx();
    if (!b || !c) return false;
    if (ctx === c && bus === b) return true;
    playing.length = 0;
    ctx = c;
    bus = b;
    hold = c.createGain();
    hold.gain.value = held ? 0 : 1;
    hold.connect(b);
    // The echo: a soft feedback delay, darker each repeat
    echo = c.createDelay(1);
    echo.delayTime.value = 0.36;
    const fb = c.createGain();
    fb.gain.value = 0.32;
    const tone = c.createBiquadFilter();
    tone.type = 'lowpass';
    tone.frequency.value = 2400;
    echo.connect(tone).connect(fb).connect(echo);
    tone.connect(hold);
    return true;
  }

  /** One note on an envelope: it starts and ends at silence */
  function voice(p: Playing, n: Note, t: number): void {
    const c = ctx!;
    const d = p.theme;
    const len = n.len * p.stepSec;
    const g = c.createGain();
    g.connect(p.gain);
    const env = (peak: number, attack: number, release: number, sustain = len) => {
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(peak, t + attack);
      g.gain.setValueAtTime(peak, t + Math.max(attack, sustain - release));
      g.gain.exponentialRampToValueAtTime(0.0001, t + sustain + release);
      return t + sustain + release + 0.05;
    };
    if (n.part === 'kick') {
      const o = c.createOscillator();
      o.frequency.setValueAtTime(110, t);
      o.frequency.exponentialRampToValueAtTime(40, t + 0.18);
      o.connect(g);
      const end = env(0.34 * n.vel, 0.008, 0.16, 0.02);
      o.start(t);
      o.stop(end);
      return;
    }
    if (n.part === 'hat') {
      // A metallic tick from two high sines, no noise at all (a noise hat on every eighth read as a steady "shhh" on
      // laptop speakers, 2026-10-10 — the owner heard it after the first fix)
      for (const [fq, v] of [[6800, 1], [9400, 0.5]] as const) {
        const o = c.createOscillator();
        o.frequency.value = fq;
        const og = c.createGain();
        og.gain.value = v;
        o.connect(og).connect(g);
        o.start(t);
        o.stop(t + 0.12);
      }
      env(0.018 * n.vel, 0.003, 0.03, 0.005);
      return;
    }
    const f = hz(n.midi);
    if (n.part === 'pad') {
      const lp = c.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = d.bright ?? 1400;
      lp.connect(g);
      for (const det of [-6, 6]) {
        const o = c.createOscillator();
        o.type = d.pad ?? 'triangle';
        o.frequency.value = f;
        o.detune.value = det;
        o.connect(lp);
        o.start(t);
        o.stop(t + len + 0.9);
      }
      env((d.pad === 'sawtooth' || d.pad === 'square' ? 0.035 : 0.06) * n.vel, len * 0.35, 0.8, len * 0.95);
      return;
    }
    const o = c.createOscillator();
    if (n.part === 'bass') {
      o.type = 'triangle';
      o.frequency.value = f;
      o.connect(g);
      const end = d.bass === 'long' ? env(0.2 * n.vel, 0.08, 0.5, len * 0.9) : env(0.2 * n.vel, 0.02, 0.14, len * 0.6);
      o.start(t);
      o.stop(end);
      return;
    }
    o.type = n.part === 'lead' ? (d.lead ?? 'sine') : 'triangle';
    o.frequency.value = f;
    const lp = c.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = n.part === 'lead' ? 2600 : 3200;
    o.connect(lp).connect(g);
    g.connect(p.send);
    const peak = (n.part === 'lead' ? (d.lead === 'square' || d.lead === 'sawtooth' ? 0.035 : 0.09) : 0.05) * n.vel;
    const end = env(peak, n.part === 'lead' ? 0.015 : 0.008, n.part === 'lead' ? 0.35 : 0.18, n.part === 'lead' ? len * 0.7 : 0.03);
    o.start(t);
    o.stop(end);
  }

  function tick(): void {
    if (!ctx) return timer.stop();
    const now = ctx.currentTime;
    for (let i = playing.length - 1; i >= 0; i--) {
      const p = playing[i];
      if (p.stopAt && now > p.stopAt) {
        p.gain.disconnect();
        p.send.disconnect();
        playing.splice(i, 1);
      }
    }
    // Nothing to play, or held with no fade left to finish: no timer runs
    if (!playing.length || (held && !playing.some((p) => p.stopAt))) return timer.stop();
    if (mixer.silent()) return;
    for (const p of playing) {
      if (p.stopAt || held) continue;
      // A new theme starts on its first tick: a slow frame after a screen change can't eat bar 1
      if (Number.isNaN(p.loopAt)) p.loopAt = now + 0.06;
      const loopLen = (p.theme.bars ?? 8) * STEPS * p.stepSec;
      // Behind (the context was suspended, the timer slept): skip ahead, never burst the missed notes at once
      if (p.loopAt + p.notes[p.next].step * p.stepSec < now - 0.1) {
        while (p.loopAt + loopLen < now) p.loopAt += loopLen;
        p.next = p.notes.findIndex((n) => p.loopAt + n.step * p.stepSec >= now + 0.02);
        if (p.next < 0) {
          p.next = 0;
          p.loopAt += loopLen;
        }
      }
      for (;;) {
        const n = p.notes[p.next];
        const t = p.loopAt + n.step * p.stepSec;
        if (t > now + AHEAD) break;
        // A short note already late is skipped (its attack would be a click); a long one starts a moment late
        const late = t < now;
        const long = n.len >= 4 && now - t < (n.len * p.stepSec) / 2;
        const rest = n.part === 'lead' && p.pass % 2 === 1;
        if (!rest && (!late || long)) voice(p, n, late ? now + 0.01 : t);
        p.next++;
        if (p.next >= p.notes.length) {
          p.next = 0;
          p.pass++;
          p.loopAt += loopLen;
        }
      }
    }
  }

  function apply(): void {
    if (!setup()) {
      if (want) waiting.start();
      return;
    }
    const c = ctx!;
    const now = c.currentTime;
    const cur = playing.find((p) => !p.stopAt);
    if ((cur?.name ?? null) !== want) {
      for (const p of playing) {
        if (p.stopAt) continue;
        for (const g of [p.gain, p.send]) ramp(g.gain, c, 0, FADE);
        p.stopAt = now + FADE + 1.2;
      }
      if (want) {
        const theme = themes[want];
        if (!theme) throw new Error(`music: no theme '${want}' (themes: ${Object.keys(themes).join(', ')})`);
        let notes = composed.get(want);
        if (!notes) composed.set(want, (notes = compose(theme)));
        const gain = c.createGain();
        const send = c.createGain();
        for (const g of [gain, send]) {
          g.gain.setValueAtTime(0, now);
          g.gain.linearRampToValueAtTime(g === send ? (theme.echo ?? 0.35) : 1, now + FADE);
        }
        gain.connect(hold!);
        send.connect(echo!);
        playing.push({ name: want, theme, gain, send, notes, next: 0, loopAt: NaN, stepSec: 60 / theme.bpm / 4, stopAt: 0, pass: 0 });
      }
    }
    if (playing.length && !(held && !playing.some((p) => p.stopAt))) timer.start();
  }

  return {
    play(theme) {
      want = theme;
      apply();
    },
    get theme() {
      return want;
    },
    hold(on) {
      if (held === on) return;
      held = on;
      if (hold && ctx) ramp(hold.gain, ctx, on ? 0 : 1, on ? 0.3 : 0.8);
      apply();
    },
    get ticking() {
      return timer.running;
    },
  };
}

// --- Adaptive music: scenes, stages, intensity -----------------------------------------------------------------------

/**
 * The layers of the adaptive score. drums: kick, snare, hats; bass: two detuned saws through a filter that opens (a
 * Reese); sub: a sine under it; arp: a pulse-wave arpeggio; lead: a seeded motif; pad: the chords; perc: a struck
 * metal hit; siren: a slow two-tone wail (a boss's last phase)
 */
export type SceneLayer = 'drums' | 'bass' | 'sub' | 'arp' | 'lead' | 'pad' | 'perc' | 'siren';
export const SCENE_LAYERS: readonly SceneLayer[] = ['drums', 'bass', 'sub', 'arp', 'lead', 'pad', 'perc', 'siren'];

/** A layer's level in a scene: a number (0–1), or [at intensity 0, at intensity 1] — the layer follows `intensity()` */
export type LayerLevel = number | readonly [number, number];

/** A scene: what is happening (a menu, exploring, a fight, a boss), its tempo and its layers */
export interface MusicScene {
  bpm: number;
  layers: Partial<Record<SceneLayer, LayerLevel>>;
  /** A heavier beat: hats on every 16th, an extra kick and perc hit (a fight, a boss) */
  hard?: boolean;
}

/** A stage (a level, a biome, a floor): its own key, and a tempo a little off the scenes' */
export interface MusicStage {
  /** The bass's root: a MIDI note or a name ('A2', 'D3') */
  root: number | string;
  scale?: ScaleName | number[];
  /** BPM added to every scene on this stage (default 0) */
  bpm?: number;
}

/**
 * A ready set of scenes for an action game (Frankengun's arena show): the title, exploring, a fight, a boss, its last
 * phase, the shop between waves. Use them as they are, change a field, or write your own
 */
export const SCENES = {
  menu: { bpm: 100, layers: { drums: 0.3, bass: 0.45, arp: 0.5, pad: 0.7, perc: 0.25 } },
  explore: { bpm: 128, layers: { drums: [0.3, 0.6], sub: 0.9, arp: [0.3, 0.5], pad: 0.45, perc: [0.15, 0.35] } },
  fight: { bpm: 138, hard: true, layers: { drums: [0.75, 1], bass: [0.6, 0.95], sub: 0.4, arp: [0.45, 0.7], lead: [0.2, 0.65], pad: 0.25, perc: [0.4, 0.7] } },
  boss: { bpm: 150, hard: true, layers: { drums: 1, bass: 1, sub: 0.5, arp: [0.6, 0.8], lead: [0.55, 0.8], pad: 0.2, perc: 0.8 } },
  enrage: { bpm: 164, hard: true, layers: { drums: 1, bass: 1, sub: 0.5, arp: 0.8, lead: 0.8, perc: 0.9, siren: 0.45 } },
  shop: { bpm: 112, layers: { drums: 0.25, bass: 0.35, sub: 0.3, arp: 0.55, pad: 0.6, perc: 0.15 } },
} satisfies Record<string, MusicScene>;

/** Four stages in four keys of A minor's family (A, D, E, C): a stage change is heard */
export const STAGES: readonly MusicStage[] = [{ root: 'A2' }, { root: 'D3', bpm: 2 }, { root: 'E3', bpm: 4 }, { root: 'C3', bpm: 6 }];

export interface SceneMusicOptions {
  /** The scenes by name (default SCENES) */
  scenes?: Record<string, MusicScene>;
  /** The stages (default STAGES) */
  stages?: readonly MusicStage[];
  /** Chord roots as scale degrees, one a bar, 8 bars (default the darksynth walk i–VI–VII–i, i–iv–VI–V) */
  chords?: readonly number[];
  /** The lead's motif: another seed, another tune (default 11) */
  seed?: number;
}

export interface SceneMusic {
  /** What is happening, on which stage: the layers and the tempo follow at the next bar. null: fade out and stop */
  scene(name: string | null, stage?: number): void;
  /** How hot it is (0–1: enemies near, health low, the crowd's hype): the layers given as [low, high] follow in ½ s */
  intensity(v: number): void;
  /** Hold (the pause screen): fade out, schedule nothing; release fades back in */
  hold(on: boolean): void;
  /** A two-tone klaxon over the music: a boss's big attack is coming */
  alarm(): void;
  /** A crowd's roar, 0–1 (a kill streak, a boss down): a swell of voices that falls away */
  roar(k?: number): void;
  /** A rising sweep into a big moment (a boss's entrance, the bell) */
  riser(): void;
  /** The layers' levels now: the playing scene's at the intensity (a test, and a debug overlay, read them) */
  levels(): Record<SceneLayer, number>;
  /** The scene asked for last (it plays from the next bar), its stage, the intensity */
  readonly current: string | null;
  readonly stage: number;
  readonly level: number;
  readonly ticking: boolean;
}

/** The default chords: i – VI – VII – i, i – iv – VI – V */
const SCENE_CHORDS = [0, 5, 6, 0, 0, 3, 5, 4];

/**
 * Adaptive music with scenes (Frankengun's arena score, made a block): one loop whose layers fade in and out with the
 * scene and the intensity, a key and a tempo per stage, stings on top — on the mixer's music bus, so the music slider,
 * ducking, the host's pause, the portal's mute and the ad pause govern it like createMusic. Scheduled ahead on the
 * context's clock; asked to play before the player's first tap (no context yet, or one not yet resumed) it starts at
 * full level once the context runs — never near-silent until a pause (the start-before-resume trap Frankengun hit).
 *
 *   const music = createSceneMusic(mixer);             // SCENES and STAGES, or your own
 *   music.scene('menu');                                // the title, before the first tap: it waits for the context
 *   music.scene('fight', stage); music.intensity(enemiesNear / 12);
 *   music.scene('boss', stage); music.alarm();          // a scene changes at the next bar; a sting at once
 */
export function createSceneMusic(mixer: Mixer, opts: SceneMusicOptions = {}): SceneMusic {
  const scenes: Record<string, MusicScene> = opts.scenes ?? SCENES;
  const stages = opts.stages?.length ? opts.stages : STAGES;
  const chords = opts.chords?.length ? opts.chords : SCENE_CHORDS;
  let ctx: AudioContext | null = null;
  let bus: GainNode | null = null;
  let hold: GainNode | null = null;
  let master: GainNode | null = null;
  let fx: GainNode | null = null;
  let drive: WaveShaperNode | null = null;
  let echo: DelayNode | null = null;
  let noise: AudioBuffer | null = null;
  let pulse: PeriodicWave | null = null;
  const layer: Partial<Record<SceneLayer, GainNode>> = {};
  let held = false;
  let want: string | null = null;
  let wantStage = 0;
  let scene: string | null = null;
  let stage = 0;
  let heat = 0;
  let bpm = 120;
  let step = 0;
  let next = 0;
  let stopAt = 0;
  let seed = opts.seed ?? 11;
  const timer = ticker(50, tick);
  const waiting = ticker(250, () => {
    if (mixer.ctx()) {
      waiting.stop();
      apply();
    }
  });
  mixer.onPause(() => timer.stop());
  mixer.onResume(() => apply());

  const levelOf = (s: MusicScene | undefined, l: SceneLayer) => {
    const v = s?.layers[l];
    if (v === undefined) return 0;
    return clamp01(typeof v === 'number' ? v : v[0] + (v[1] - v[0]) * heat);
  };
  const rnd = (n: number) => {
    let h = (n * 374761393 + seed * 668265263) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };

  function setup(): boolean {
    const b = mixer.bus('music');
    const c = mixer.ctx();
    if (!b || !c) return false;
    if (ctx === c && bus === b) return true;
    ctx = c;
    bus = b;
    // hold (the pause screen) → master (the scene's fade in and out) → the bus; the stings skip the master
    hold = c.createGain();
    hold.gain.value = held ? 0 : 1;
    hold.connect(b);
    master = c.createGain();
    master.gain.value = 0;
    master.connect(hold);
    fx = c.createGain();
    fx.connect(hold);
    // A soft drive glues the layers; the echo is dark and short
    drive = c.createWaveShaper();
    drive.curve = shaper((x) => Math.tanh(x * 1.6) / Math.tanh(1.6));
    drive.connect(master);
    echo = c.createDelay(1);
    echo.delayTime.value = 0.33;
    const fb = c.createGain();
    fb.gain.value = 0.3;
    const tone = c.createBiquadFilter();
    tone.type = 'lowpass';
    tone.frequency.value = 2200;
    echo.connect(tone).connect(fb).connect(echo);
    tone.connect(drive);
    for (const l of SCENE_LAYERS) {
      const g = c.createGain();
      g.gain.value = 0;
      g.connect(drive);
      layer[l] = g;
    }
    noise = noiseBuffer(c, 1, seed * 7919);
    // A 25 % pulse: the chiptune arp
    const n = 24;
    const re = new Float32Array(n);
    const im = new Float32Array(n);
    for (let k = 1; k < n; k++) im[k] = (2 / (k * Math.PI)) * Math.sin(k * Math.PI * 0.25);
    pulse = c.createPeriodicWave(re, im);
    // A new context: the scene starts over at its first bar
    scene = null;
    return true;
  }

  /** The layers to the scene's levels at the intensity now, over `sec` */
  const mix = (sec: number) => {
    const s = scene ? scenes[scene] : undefined;
    for (const l of SCENE_LAYERS) ramp(layer[l]!.gain, ctx!, levelOf(s, l), sec);
  };

  // --- The voices: each a note on an envelope, from silence to silence
  const env = (g: GainNode, t: number, a: number, peak: number, d: number) => {
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
    return t + a + d + 0.05;
  };
  const osc = (type: OscillatorType, f: number, to: AudioNode, t: number, end: number, detune = 0) => {
    const o = ctx!.createOscillator();
    o.type = type;
    o.frequency.value = f;
    o.detune.value = detune;
    o.connect(to);
    o.start(t);
    o.stop(end);
    return o;
  };
  const gainTo = (to: AudioNode) => {
    const g = ctx!.createGain();
    g.connect(to);
    return g;
  };
  const filter = (type: BiquadFilterType, f: number, q: number, to: AudioNode) => {
    const fl = ctx!.createBiquadFilter();
    fl.type = type;
    fl.frequency.value = f;
    fl.Q.value = q;
    fl.connect(to);
    return fl;
  };
  function noiseHit(t: number, type: BiquadFilterType, f: number, q: number, vel: number, dur: number, to: AudioNode): void {
    const s = ctx!.createBufferSource();
    s.buffer = noise;
    const g = gainTo(to);
    s.connect(filter(type, f, q, g));
    const end = env(g, t, 0.002, vel, dur);
    s.start(t, rnd(t * 1000) * 0.5);
    s.stop(end);
  }
  function kick(t: number, vel: number): void {
    const g = gainTo(layer.drums!);
    const o = osc('sine', 150, g, t, env(g, t, 0.003, vel * 0.9, 0.32));
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
  }
  function snare(t: number, vel: number): void {
    noiseHit(t, 'bandpass', 1900, 0.8, vel * 0.5, 0.16, layer.drums!);
    const g = gainTo(layer.drums!);
    const o = osc('triangle', 220, g, t, env(g, t, 0.002, vel * 0.3, 0.1));
    o.frequency.exponentialRampToValueAtTime(140, t + 0.08);
  }
  /** A metallic tick from two high sines (a noise hat on every step reads as a steady hiss: see createMusic) */
  function hat(t: number, vel: number): void {
    const g = gainTo(layer.drums!);
    const end = env(g, t, 0.002, 0.02 * vel, 0.035);
    for (const f of [6800, 9400]) osc('sine', f, g, t, end);
  }
  function perc(t: number, vel: number): void {
    noiseHit(t, 'bandpass', 2300, 14, vel * 0.7, 0.22, layer.perc!);
    const g = gainTo(layer.perc!);
    const end = env(g, t, 0.002, vel * 0.04, 0.2);
    for (const f of [523, 547]) osc('square', f, g, t, end);
  }
  function bass(t: number, midi: number, len: number, vel: number): void {
    const g = gainTo(layer.bass!);
    const f = filter('lowpass', 260, 6, g);
    f.frequency.setValueAtTime(260, t);
    f.frequency.linearRampToValueAtTime(800 + vel * 800, t + len * 0.3);
    f.frequency.exponentialRampToValueAtTime(320, t + len);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.26 * vel, t + 0.01);
    g.gain.setValueAtTime(0.26 * vel, t + len * 0.8);
    g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    for (const d of [-11, 11]) osc('sawtooth', hz(midi), f, t, t + len + 0.03, d);
  }
  function sub(t: number, midi: number, len: number): void {
    const g = gainTo(layer.sub!);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.42, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    osc('sine', hz(midi), g, t, t + len + 0.03);
  }
  function arp(t: number, midi: number, vel: number): void {
    const g = gainTo(layer.arp!);
    g.connect(echo!);
    const end = env(g, t, 0.002, 0.08 * vel, 0.11);
    const o = osc('square', hz(midi), g, t, end);
    o.setPeriodicWave(pulse!);
  }
  function lead(t: number, midi: number, len: number): void {
    const g = gainTo(layer.lead!);
    g.connect(echo!);
    const f = filter('lowpass', 2400, 2, g);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.1, t + 0.02);
    g.gain.setValueAtTime(0.1, t + len * 0.85);
    g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    for (const [type, d] of [['sawtooth', -6], ['square', 7]] as const) osc(type, hz(midi), f, t, t + len + 0.03, d);
  }
  function pad(t: number, notes: number[], len: number): void {
    const g = gainTo(layer.pad!);
    const f = filter('lowpass', 900, 0.7, g);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.05, t + len * 0.3);
    g.gain.linearRampToValueAtTime(0, t + len);
    notes.forEach((m, i) => osc('sawtooth', hz(m), f, t, t + len + 0.05, (i - 1) * 8));
  }
  /** One bar of the siren: a wail between two tones, one rise and fall a bar */
  function siren(t: number, len: number): void {
    const g = gainTo(layer.siren!);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.045, t + 0.08);
    g.gain.setValueAtTime(0.045, t + len - 0.08);
    g.gain.linearRampToValueAtTime(0, t + len);
    const o = osc('sawtooth', 640, filter('bandpass', 900, 1, g), t, t + len + 0.02);
    o.frequency.setValueAtTime(640, t);
    o.frequency.linearRampToValueAtTime(900, t + len / 2);
    o.frequency.linearRampToValueAtTime(640, t + len);
  }

  /** One 16th step of the loop */
  function play(t: number, s: number): void {
    const sc = scenes[scene!];
    const st = stages[stage % stages.length];
    const scale = Array.isArray(st.scale) ? st.scale : SCALES[(st.scale as ScaleName | undefined) ?? 'minor'];
    const n = scale.length;
    const root = midiOf(st.root);
    const deg = (k: number) => root + Math.floor(k / n) * 12 + scale[((k % n) + n) % n];
    const bar = Math.floor(s / 16) % 8;
    const i = s % 16;
    const ch = chords[bar % chords.length];
    const chord = [ch, ch + 2, ch + 4];
    const beat = 60 / bpm / 4;
    const hard = !!sc.hard;
    const on = (l: SceneLayer) => levelOf(sc, l) > 0;
    // Drums: four on the floor, a broken beat in the second half of every fourth bar
    if (on('drums')) {
      const breaks = bar % 4 === 3 && i >= 8;
      if (breaks ? [8, 11, 14].includes(i) : i % 4 === 0) kick(t, i === 0 ? 1 : 0.85);
      if (hard && i === 15) kick(t, 0.6);
      if (i === 4 || i === 12 || (breaks && (i === 10 || i === 13))) snare(t, i === 4 || i === 12 ? 1 : 0.55);
      if (hard || i % 2 === 0) hat(t, i % 4 === 2 ? 1 : 0.55);
    }
    if (on('perc') && (i === 14 || (hard && i === 6))) perc(t, 0.8);
    // The bass: driving 8ths and 16ths on the chord's root, an octave up on the off-beats; the sub on the beats
    const pat = [1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1];
    if (on('bass') && pat[i]) bass(t, deg(ch) + (i % 8 === 6 ? 12 : 0), beat * (i % 4 === 0 ? 1.8 : 0.9), i % 4 === 0 ? 1 : 0.7);
    if (on('sub') && i % 4 === 0) sub(t, deg(ch) - 12, beat * 3.6);
    // The arp: chord tones up and down, an octave higher in the second half of the bar
    const order = [0, 1, 2, 1, 0, 2, 1, 2];
    if (on('arp')) arp(t, Math.min(86, deg(chord[order[i % 8]]) + 24 + (i >= 8 ? 12 : 0)), i % 4 === 0 ? 1 : 0.7);
    // The lead: a seeded motif on bars 5–8
    if (on('lead') && bar >= 4 && i % 2 === 0 && rnd(s * 7 + 3) < (hard ? 0.65 : 0.45)) {
      const k = chord[Math.floor(rnd(s) * 3)] + 7;
      lead(t, Math.min(86, deg(k) + 12), beat * (rnd(s + 2) < 0.4 ? 4 : 2));
    }
    if (on('pad') && i === 0) pad(t, chord.map((k) => deg(k) + 12), beat * 16);
    if (on('siren') && i === 0) siren(t, beat * 16);
  }

  function tick(): void {
    if (!ctx) return timer.stop();
    const now = ctx.currentTime;
    // Faded out (scene null) or held: nothing more to schedule
    if (!want && stopAt && now >= stopAt) {
      scene = null;
      stopAt = 0;
      return timer.stop();
    }
    if (held) return timer.stop();
    if (mixer.silent()) return;
    // Behind (a suspended context, a sleeping timer): start from now, never burst the missed steps
    if (next < now) next = now + 0.05;
    while (next < now + AHEAD) {
      // The scene, the stage and the tempo change at a bar's start (the first step of a new scene starts at once)
      if ((step % 16 === 0 || scene === null) && want && (want !== scene || wantStage !== stage)) {
        if (scene === null) step = 0;
        scene = want;
        stage = wantStage;
        const st = stages[stage % stages.length];
        bpm = Math.max(40, scenes[scene].bpm + (st.bpm ?? 0));
        seed = (opts.seed ?? 11) + stage * 7;
        for (const l of SCENE_LAYERS) rampAt(layer[l]!.gain, next, levelOf(scenes[scene], l), 0.6);
      }
      if (scene) play(next, step);
      step++;
      next += 60 / bpm / 4;
    }
  }

  function apply(): void {
    if (!setup()) {
      if (want) waiting.start();
      return;
    }
    const c = ctx!;
    if (want) {
      if (!scenes[want]) throw new Error(`music: no scene '${want}' (scenes: ${Object.keys(scenes).join(', ')})`);
      stopAt = 0;
      // From the level the master has now to full, on the context's clock: started while the context was suspended,
      // the ramp waits with the clock and plays out once it runs
      ramp(master!.gain, c, 0.9, 0.8);
    } else if (scene !== null || timer.running) {
      ramp(master!.gain, c, 0, 0.6);
      stopAt = c.currentTime + 0.7;
    }
    if (!held && (want || stopAt)) timer.start();
  }

  return {
    scene(name, st = wantStage) {
      if (name !== null && !scenes[name]) throw new Error(`music: no scene '${name}' (scenes: ${Object.keys(scenes).join(', ')})`);
      const again = name === want && st === wantStage;
      want = name;
      wantStage = Math.max(0, Math.floor(st));
      if (!again || !timer.running) apply();
    },
    intensity(v) {
      heat = clamp01(v);
      if (ctx && scene) mix(0.5);
    },
    hold(on) {
      if (held === on) return;
      held = on;
      if (hold && ctx) ramp(hold.gain, ctx, on ? 0 : 1, on ? 0.3 : 0.8);
      if (on) timer.stop();
      else apply();
    },
    alarm() {
      if (!setup() || held || mixer.silent()) return;
      const c = ctx!;
      const t = c.currentTime + 0.01;
      const g = gainTo(fx!);
      const o = osc('square', 930, filter('lowpass', 2400, 0.7, g), t, t + 0.42);
      g.gain.setValueAtTime(0, t);
      for (let k = 0; k < 2; k++) {
        const a = t + k * 0.18;
        o.frequency.setValueAtTime(k ? 620 : 930, a);
        g.gain.setValueAtTime(0, a);
        g.gain.linearRampToValueAtTime(0.12, a + 0.01);
        g.gain.setValueAtTime(0.12, a + 0.13);
        g.gain.linearRampToValueAtTime(0, a + 0.16);
      }
    },
    roar(k = 1) {
      if (!setup() || held || mixer.silent()) return;
      const c = ctx!;
      const t = c.currentTime + 0.01;
      const v = clamp01(k);
      // Voices: noise in the voice band, a swell up and a long fall
      for (const [f, q, w] of [[700, 0.8, 1], [1500, 1.2, 0.5]] as const) {
        const g = gainTo(fx!);
        const s = c.createBufferSource();
        s.buffer = noise;
        s.loop = true;
        s.connect(filter('bandpass', f, q, g));
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime((0.05 + 0.3 * v) * w, t + 0.18);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 1.4 + v);
        s.start(t, rnd(t) * 0.5);
        s.stop(t + 1.5 + v);
      }
    },
    riser() {
      if (!setup() || held || mixer.silent()) return;
      const c = ctx!;
      const t = c.currentTime + 0.01;
      const g = gainTo(fx!);
      const f = filter('bandpass', 300, 3, g);
      f.frequency.setValueAtTime(300, t);
      f.frequency.exponentialRampToValueAtTime(6000, t + 1.4);
      const s = c.createBufferSource();
      s.buffer = noise;
      s.loop = true;
      s.connect(f);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(0.2, t + 1.3);
      g.gain.linearRampToValueAtTime(0, t + 1.6);
      s.start(t);
      s.stop(t + 1.7);
    },
    levels() {
      const sc = scene ? scenes[scene] : undefined;
      return Object.fromEntries(SCENE_LAYERS.map((l) => [l, levelOf(sc, l)])) as Record<SceneLayer, number>;
    },
    get current() {
      return want;
    },
    get stage() {
      return wantStage;
    },
    get level() {
      return heat;
    },
    get ticking() {
      return timer.running;
    },
  };
}

function shaper(f: (x: number) => number): Float32Array<ArrayBuffer> {
  const a = new Float32Array(512);
  for (let i = 0; i < a.length; i++) a[i] = f((i / (a.length - 1)) * 2 - 1);
  return a;
}

// --- Ambience ------------------------------------------------------------------------------------------------------

/**
 * The layers of a place. Beds sound all the time (wind, rain, water, surf, fire, hum); the others are events at random
 * moments (birds, crickets, drips, crackle — the fire's pops, thunder). Mix them: a forest is wind + birds, a night
 * meadow crickets + a little wind, a cave drips + hum, a storm rain + wind + thunder, a camp fire + crackle + crickets.
 */
export type Layer = 'wind' | 'rain' | 'water' | 'surf' | 'fire' | 'hum' | 'birds' | 'crickets' | 'drips' | 'crackle' | 'thunder';
export const LAYERS: readonly Layer[] = ['wind', 'rain', 'water', 'surf', 'fire', 'hum', 'birds', 'crickets', 'drips', 'crackle', 'thunder'];
const BEDS: readonly Layer[] = ['wind', 'rain', 'water', 'surf', 'fire', 'hum'];
/** Events per second at level 1 */
const EVENT_RATE: Partial<Record<Layer, number>> = { birds: 0.7, crickets: 1.2, drips: 0.8, crackle: 4, thunder: 0.05 };

/** Ready-made places: `ambience.set(PLACES.forest)` */
export const PLACES = {
  forest: { wind: 0.4, birds: 0.6 },
  meadow: { wind: 0.3, birds: 0.4, crickets: 0.2 },
  night: { wind: 0.2, crickets: 0.7 },
  cave: { drips: 0.6, hum: 0.25, wind: 0.1 },
  storm: { rain: 0.8, wind: 0.6, thunder: 0.6 },
  rain: { rain: 0.6, drips: 0.2 },
  river: { water: 0.6, birds: 0.3, wind: 0.2 },
  beach: { surf: 0.7, wind: 0.3 },
  camp: { fire: 0.5, crackle: 0.5, crickets: 0.4 },
  station: { hum: 0.6 },
  crypt: { drips: 0.4, hum: 0.2, wind: 0.25 },
} satisfies Record<string, Partial<Record<Layer, number>>>;

export interface Ambience {
  /** The levels (0–1) to move to over `fadeSec`; layers left out fade to 0 */
  set(levels: Partial<Record<Layer, number>>, fadeSec?: number): void;
  /** Hold (the pause screen): fade out, stop the beds, schedule nothing; release fades back in */
  hold(on: boolean): void;
  readonly levels: Readonly<Partial<Record<Layer, number>>>;
  readonly ticking: boolean;
}

interface Bed {
  /** The bed's sources: a noise loop, or a hum's oscillators */
  srcs: AudioScheduledSourceNode[];
  filter: BiquadFilterNode;
  gain: GainNode;
  /** The bed's own slow movement (gusts, swells): the next time to pick a new target */
  nextMove: number;
}

export function createAmbience(mixer: Mixer, opts: { seed?: number } = {}): Ambience {
  const rand = seeded(opts.seed ?? 1);
  let ctx: AudioContext | null = null;
  let bus: GainNode | null = null;
  let hold: GainNode | null = null;
  let noise: AudioBuffer | null = null;
  let held = false;
  let fade = 2;
  const levels: Partial<Record<Layer, number>> = {};
  const beds = new Map<Layer, Bed>();
  let last = 0;
  const timer = ticker(100, tick);
  const waiting = ticker(250, () => {
    if (mixer.ctx()) {
      waiting.stop();
      apply();
    }
  });
  mixer.onPause(() => timer.stop());
  mixer.onResume(() => apply());

  const live = () => LAYERS.some((l) => (levels[l] ?? 0) > 0) || beds.size > 0;

  function setup(): boolean {
    const b = mixer.bus('ambient');
    const c = mixer.ctx();
    if (!b || !c) return false;
    if (ctx === c && bus === b) return true;
    beds.clear();
    ctx = c;
    bus = b;
    hold = c.createGain();
    hold.gain.value = held ? 0 : 1;
    hold.connect(b);
    // 4 s of noise, looped: long enough that no one hears the seam
    noise = noiseBuffer(c, 4, (opts.seed ?? 1) * 7919);
    return true;
  }

  /**
   * Each bed: a noise loop through its filter, then a lowpass at `top` (the hiss above a bed's body is not part of it: a
   * 2-pole bandpass on white noise leaves a steady "shhh" up to 20 kHz — Hang the Moon's and Starsilk's wind, measured
   * at −63 dB above 6 kHz under the music, heard as a noise; 2026-10-10), at its level × its base loudness
   */
  const BED: Record<string, { type: BiquadFilterType; f: number; q: number; base: number; move: number; top: number }> = {
    wind: { type: 'lowpass', f: 450, q: 0.7, base: 0.28, move: 3, top: 1000 },
    rain: { type: 'highpass', f: 2500, q: 0.3, base: 0.12, move: 6, top: 12000 },
    water: { type: 'bandpass', f: 900, q: 1.4, base: 0.3, move: 0.7, top: 2400 },
    surf: { type: 'lowpass', f: 700, q: 0.5, base: 0.4, move: 4, top: 1600 },
    fire: { type: 'lowpass', f: 380, q: 0.6, base: 0.45, move: 1.5, top: 1200 },
    hum: { type: 'lowpass', f: 160, q: 4, base: 0.5, move: 5, top: 600 },
  };

  function startBed(l: Layer, now: number): void {
    const c = ctx!;
    const def = BED[l];
    const filter = c.createBiquadFilter();
    filter.type = def.type;
    filter.frequency.value = def.f;
    filter.Q.value = def.q;
    const top = c.createBiquadFilter();
    top.type = 'lowpass';
    top.frequency.value = def.top;
    top.Q.value = 0.5;
    const gain = c.createGain();
    gain.gain.setValueAtTime(0, now);
    filter.connect(top).connect(gain).connect(hold!);
    const srcs: AudioScheduledSourceNode[] = [];
    if (l === 'hum') {
      // A machine's hum is a tone, not noise: two low sines a little apart (a slow beat), no "shhh" under the music
      for (const [fq, v] of [[55, 1], [110.6, 0.45]] as const) {
        const o = c.createOscillator();
        o.frequency.value = fq;
        const og = c.createGain();
        og.gain.value = v * 0.3;
        o.connect(og).connect(filter);
        o.start(now);
        srcs.push(o);
      }
    } else {
      const src = c.createBufferSource();
      src.buffer = noise;
      src.loop = true;
      src.loopStart = rand() * 2;
      src.connect(filter);
      src.start(now, src.loopStart);
      srcs.push(src);
    }
    beds.set(l, { srcs, filter, gain, nextMove: now });
  }

  /** The bed moves by itself: wind gusts, the surf swells, the fire breathes — slow ramps to random targets */
  function moveBed(l: Layer, b: Bed, now: number): void {
    const def = BED[l];
    const lv = levels[l] ?? 0;
    if (now < b.nextMove) return;
    // Wind comes in gusts with calm between them, never a steady bed: a constant noise floor under the music is what a
    // player hears as "шум" (the owner, twice, 2026-10-10)
    const calm = l === 'wind' && rand() < 0.55;
    const span = def.move * (calm ? 1.5 + rand() * 1.5 : 0.6 + rand() * 0.8);
    const swing = l === 'surf' ? 0.85 : l === 'wind' ? 0.6 : l === 'hum' ? 0.1 : 0.3;
    const target = calm ? 0 : lv * def.base * (1 - swing + rand() * swing);
    ramp(b.gain.gain, ctx!, target, Math.min(span, fade));
    const fSwing = l === 'wind' ? 0.8 : l === 'surf' ? 0.6 : 0.25;
    ramp(b.filter.frequency, ctx!, def.f * (1 - fSwing / 2 + rand() * fSwing), span);
    b.nextMove = now + span;
  }

  function stopBed(l: Layer, b: Bed, now: number): void {
    ramp(b.gain.gain, ctx!, 0, fade);
    for (const src of b.srcs) src.stop(now + fade + 0.1);
    beds.delete(l);
  }

  /** One event: a short voice on an envelope, at `t` */
  function event(l: Layer, lv: number, t: number): void {
    const c = ctx!;
    const g = c.createGain();
    g.connect(hold!);
    const env = (peak: number, attack: number, len: number) => {
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(peak * lv, t + attack);
      g.gain.exponentialRampToValueAtTime(0.0001, t + len);
      return t + len + 0.05;
    };
    if (l === 'birds') {
      // A phrase of 2–5 chirps gliding down or up
      const o = c.createOscillator();
      o.type = 'sine';
      const f0 = 2200 + rand() * 2200;
      const k = 2 + Math.floor(rand() * 4);
      const up = rand() < 0.4;
      for (let i = 0; i < k; i++) {
        const ti = t + i * (0.09 + rand() * 0.05);
        o.frequency.setValueAtTime(f0 * (up ? 0.8 : 1.2), ti);
        o.frequency.exponentialRampToValueAtTime(f0 * (up ? 1.25 : 0.75), ti + 0.07);
      }
      o.connect(g);
      const end = env(0.06, 0.01, k * 0.13 + 0.05);
      o.start(t);
      o.stop(end);
    } else if (l === 'crickets') {
      // A trill: a high tone pulsed fast by its own envelope
      const o = c.createOscillator();
      o.frequency.value = 4200 + rand() * 900;
      o.connect(g);
      const pulses = 3 + Math.floor(rand() * 4);
      g.gain.setValueAtTime(0, t);
      for (let i = 0; i < pulses; i++) {
        const ti = t + i * 0.055;
        g.gain.linearRampToValueAtTime(0.025 * lv, ti + 0.012);
        g.gain.linearRampToValueAtTime(0, ti + 0.04);
      }
      o.start(t);
      o.stop(t + pulses * 0.055 + 0.05);
    } else if (l === 'drips') {
      // A drop: a sine whose pitch jumps up and decays, with a little room
      const o = c.createOscillator();
      const f = 900 + rand() * 900;
      o.frequency.setValueAtTime(f, t);
      o.frequency.exponentialRampToValueAtTime(f * 2.2, t + 0.05);
      o.connect(g);
      const end = env(0.08, 0.003, 0.22);
      o.start(t);
      o.stop(end);
    } else if (l === 'crackle' || l === 'thunder') {
      const src = c.createBufferSource();
      src.buffer = noise;
      src.loop = true;
      const f = c.createBiquadFilter();
      if (l === 'crackle') {
        f.type = 'highpass';
        f.frequency.value = 1800 + rand() * 2500;
      } else {
        f.type = 'lowpass';
        f.frequency.setValueAtTime(900, t);
        f.frequency.exponentialRampToValueAtTime(120, t + 3);
      }
      src.connect(f).connect(g);
      const end = l === 'crackle' ? env(0.12 * (0.4 + rand() * 0.6), 0.001, 0.02 + rand() * 0.04) : env(0.5, 0.08 + rand() * 0.2, 3 + rand() * 2);
      src.start(t, rand() * 3);
      src.stop(end);
    }
  }

  function tick(): void {
    if (!ctx) return timer.stop();
    const now = ctx.currentTime;
    const dt = Math.min(0.5, Math.max(0, now - last));
    last = now;
    if (held) {
      // The hold's fade is over: the beds stop, the timer too (release starts them again)
      for (const [l, b] of beds) stopBed(l, b, now);
      return timer.stop();
    }
    if (mixer.silent()) return;
    for (const l of LAYERS) {
      const lv = levels[l] ?? 0;
      const b = beds.get(l);
      if (BEDS.includes(l)) {
        if (lv > 0 && !b) startBed(l, now);
        const nb = beds.get(l);
        if (nb && lv > 0) moveBed(l, nb, now);
        else if (nb) stopBed(l, nb, now);
      } else if (lv > 0) {
        const rate = EVENT_RATE[l] ?? 0;
        // Poisson over the tick: at most one event per layer and tick, a little after now (never in the past)
        if (rand() < rate * lv * dt) event(l, lv, now + 0.02 + rand() * 0.08);
      }
    }
    if (!live()) timer.stop();
  }

  function apply(): void {
    if (!setup()) {
      if (live()) waiting.start();
      return;
    }
    last = ctx!.currentTime;
    if (live()) timer.start();
  }

  return {
    set(next, fadeSec = 2) {
      fade = Math.max(0.05, fadeSec);
      for (const l of LAYERS) {
        const v = clamp01(next[l] ?? 0);
        if (v > 0) levels[l] = v;
        else delete levels[l];
      }
      // The beds move to the new levels on the next tick
      for (const b of beds.values()) b.nextMove = 0;
      apply();
    },
    hold(on) {
      if (held === on) return;
      held = on;
      if (hold && ctx) ramp(hold.gain, ctx, on ? 0 : 1, on ? 0.3 : 0.8);
      if (!on) for (const b of beds.values()) b.nextMove = 0;
      // Held: one more tick after the fade stops the beds and the timer
      if (on && timer.running) {
        timer.stop();
        setTimeout(() => {
          if (held) tick();
        }, 350);
      } else apply();
    },
    get levels() {
      return { ...levels };
    },
    get ticking() {
      return timer.running;
    },
  };
}

// --- Helpers -------------------------------------------------------------------------------------------------------

function clamp01(v: number): number {
  return Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : 0;
}

/** From the value now to `to` over `sec`, without a jump (cancels what was scheduled) */
function ramp(p: AudioParam, ctx: AudioContext, to: number, sec: number): void {
  rampAt(p, ctx.currentTime, to, sec);
}

/** From the value at time `t` to `to` over `sec` (a bar's start scheduled ahead) */
function rampAt(p: AudioParam, t: number, to: number, sec: number): void {
  // Hold the value the param has at that moment: `p.value` lags a running ramp, and starting from it made a step — a
  // click on every gust, swell and fade (the owner: «небольшие помехи в звуке», 2026-10-10)
  if (typeof p.cancelAndHoldAtTime === 'function') p.cancelAndHoldAtTime(t);
  else {
    p.cancelScheduledValues(t);
    p.setValueAtTime(p.value, t);
  }
  p.linearRampToValueAtTime(to, t + Math.max(0.02, sec));
}

function seeded(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function noiseBuffer(c: AudioContext, sec: number, seed: number): AudioBuffer {
  const b = c.createBuffer(1, Math.max(1, Math.floor(c.sampleRate * sec)), c.sampleRate);
  const ch = b.getChannelData(0);
  const r = seeded(seed);
  for (let i = 0; i < ch.length; i++) ch[i] = r() * 2 - 1;
  return b;
}

/** A setInterval that knows whether it runs */
function ticker(ms: number, fn: () => void): { start(): void; stop(): void; readonly running: boolean } {
  let id: ReturnType<typeof setInterval> | null = null;
  return {
    start() {
      if (!id) {
        id = setInterval(fn, ms);
        fn();
      }
    },
    stop() {
      if (id) clearInterval(id);
      id = null;
    },
    get running() {
      return id !== null;
    },
  };
}
