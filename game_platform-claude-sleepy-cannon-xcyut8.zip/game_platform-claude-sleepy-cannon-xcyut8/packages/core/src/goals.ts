// Goals: daily quests and achievements — what Craft Pickaxe Idle (meta.ts: 3 quests a day from a pool of 8, a quest
// chest for all three) and Idle Garage Evolution (achievements.ts: 31 tests over the save, four rarities, hidden ones)
// wrote by hand, and what dailyOrder (one goal a day, a save on every add) couldn't be. Any genre. Pure logic over
// fields of the game's own save, deterministic with an injected clock (`now`), never a DOM: Node tests and balance bots
// run them as they are. The screen is mountGoals() and the unlock banners goalBanners() (goals-ui.ts).
//
//   const quests = dailyQuests(save, {
//     pool: [{ id: 'blocks', need: 120, reward: 15 }, { id: 'chests', need: 15, reward: 15 }, { id: 'merges', need: 5, reward: 15 }, …],
//     perDay: 3, bonus: 25, salt: 'my-game', persist: () => host.save(save),
//   });
//   quests.add('blocks');                  // in memory: the game's next host.save(save) carries it (no save per block)
//   const paid = quests.claim('blocks');   // a done quest, once: its reward (saved at once)
//
//   const ach = achievements(save, { list: [
//     { id: 'first', rarity: 'common', test: (s) => s.stats.runs >= 1 },
//     { id: 'night', rarity: 'rare', hidden: true, test: (s) => s.lastRunHour < 5 },     // "???" until it is earned
//   ], persist: () => host.save(save) });
//   for (const a of ach.check(save)) banners.push({ title: host.t(`ach.${a.id}.name`), rarity: a.rarity });
//
// Nothing is taken away (D56, game-design.md): a missed day costs nothing. A quest done but not claimed when the day
// turns, and a bonus earned but not taken, are kept and paid later (`carried`, claimAll()); the day's quests are new.
// An achievement, once earned, stays earned — even if the test would fail later (a prestige reset, a sold car).

import { dayKey, daySeed } from './daily.ts';
import type { SaveHolder } from './streak.ts';

const KEY = /^\d{4}-\d{2}-\d{2}$/;
const isKey = (v: unknown): v is string => typeof v === 'string' && KEY.test(v);
const int = (v: unknown, min: number, max: number, dflt: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.floor(n))) : dflt;
};
const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

interface Clocked {
  /** The clock, in ms (default Date.now): inject one in tests and bots */
  now?: () => number;
  /** Days turn over at the player's own midnight (default true); false: at 00:00 UTC, the same quests for everyone */
  local?: boolean;
  /** Called after a change that must not be lost (a new day, a claim, an unlock): `() => host.save(save)` */
  persist?: () => void;
}
const today = (o: Clocked) => dayKey(new Date((o.now ?? Date.now)()), { local: o.local ?? true });

/**
 * A day's shuffle of `ids` (mulberry32 from the day's seed): the same order for the same day and salt, unrelated orders
 * on neighbouring days. The quests and the offers of a day are its first few
 */
export function dayShuffle<T>(items: readonly T[], day: string, salt: string): T[] {
  let a = daySeed(day, salt) >>> 0;
  const r = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const out = [...items];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

// --- Daily quests -------------------------------------------------------------------------------------------------

/** A quest a day can draw: "break 120 blocks" is { id: 'blocks', need: 120, reward } — one that fits a session */
export interface QuestDef<Id extends string = string, R = number> {
  id: Id;
  need: number;
  reward: R;
}

/** What the quests keep in the save (`save.quests` by default) */
export interface QuestLog {
  /** The day of today's quests ('' none yet) */
  day: string;
  /** Today's quests: id, progress, claimed */
  list: { id: string; have: number; claimed: boolean }[];
  /** Today's bonus was taken */
  bonus: boolean;
  /** Done on an earlier day and never claimed: still the player's (D56) */
  carry: { id: string; day: string }[];
  /** Bonuses earned on earlier days and never taken */
  carryBonus: number;
  /** The first day the quests were seen (for `from: 'secondVisit'`) */
  first: string;
  /** Quests claimed in all */
  total: number;
}

export interface QuestsOptions<Id extends string, R> extends Clocked {
  /** The quests a day draws from (at least `perDay`, ids unique); each should fit one session */
  pool: readonly QuestDef<Id, R>[];
  /** Quests a day (default 3) */
  perDay?: number;
  /** All of today's quests claimed: this bonus (a chest), once a day; omit or null for none */
  bonus?: R | null;
  /** The game's id: two games never draw the same days (daySeed's salt) */
  salt?: string;
  /** From the first day (default) or from the second visit (the first day belongs to the game itself) */
  from?: 'firstVisit' | 'secondVisit';
  /** The save field (default 'quests') */
  key?: string;
}

export interface QuestRow<Id extends string, R> {
  /** Its place in today's list (0 …) */
  index: number;
  id: Id;
  need: number;
  have: number;
  /** 0 … 1 */
  share: number;
  done: boolean;
  claimed: boolean;
  reward: R;
}

/** A reward paid: a quest of today or an earlier day, or a bonus */
export interface QuestClaim<Id extends string, R> {
  kind: 'quest' | 'bonus';
  /** The quest's id (a bonus: '') */
  id: Id | '';
  reward: R;
}

export interface QuestsState<Id extends string, R> {
  day: string;
  /** Offered today (false on the first day with from: 'secondVisit') */
  available: boolean;
  quests: QuestRow<Id, R>[];
  /** Today's bonus: what it gives, ready (every quest claimed), taken; null without a bonus */
  bonus: { reward: R; ready: boolean; claimed: boolean; share: number } | null;
  /** Done on earlier days, waiting to be claimed */
  carried: { id: Id; day: string; reward: R }[];
  carriedBonus: number;
  /** Rewards waiting now: done quests, a ready bonus, the carried ones */
  claimable: number;
  /** Every quest of today done */
  allDone: boolean;
}

export interface DailyQuests<Id extends string, R> {
  readonly perDay: number;
  state(): QuestsState<Id, R>;
  /**
   * Progress on quest `id` (n, default 1): counted in memory, saved with the game's next save (never a save per add).
   * True when this call completed today's quest. Ignored when it isn't one of today's (or not offered)
   */
  add(id: Id, n?: number): boolean;
  /** Claim a done quest of today (by id or its index), once: its reward, or null. Saved at once */
  claim(which: Id | number): R | null;
  /** Today's bonus (every quest claimed), once: its reward, or null */
  claimBonus(): R | null;
  /** Everything waiting: today's done quests, the bonus if that makes it ready, the carried ones */
  claimAll(): QuestClaim<Id, R>[];
  /** The quest definition of an id */
  def(id: Id): QuestDef<Id, R> | undefined;
  readonly log: QuestLog;
}

/** A pool's problems (empty: fine): no quests, fewer than a day takes, duplicate ids, a need under 1 */
export function checkQuests(pool: readonly QuestDef<string, unknown>[], perDay = 3): string[] {
  const out: string[] = [];
  if (pool.length < perDay) out.push(`the pool has ${pool.length} quest(s), a day takes ${perDay}`);
  const ids = new Set<string>();
  for (const q of pool) {
    if (!q.id || ids.has(q.id)) out.push(q.id ? `the id '${q.id}' twice` : 'a quest without an id');
    ids.add(q.id);
    if (!(q.need >= 1)) out.push(`quest ${q.id}: need is 1 or more`);
  }
  return out;
}

/** The saved quests made safe: wrong types, impossible counts and junk days go */
export function loadQuests(saved: unknown): QuestLog {
  const s = record(saved);
  const list = Array.isArray(s.list)
    ? s.list
        .map(record)
        .filter((q) => typeof q.id === 'string' && q.id)
        .slice(0, 20)
        .map((q) => ({ id: q.id as string, have: Math.max(0, Number.isFinite(Number(q.have)) ? Number(q.have) : 0), claimed: q.claimed === true }))
    : [];
  const carry = Array.isArray(s.carry)
    ? s.carry
        .map(record)
        .filter((c) => typeof c.id === 'string' && c.id && isKey(c.day))
        .slice(-60)
        .map((c) => ({ id: c.id as string, day: c.day as string }))
    : [];
  return {
    day: isKey(s.day) ? s.day : '',
    list: list.filter((q, i) => list.findIndex((x) => x.id === q.id) === i),
    bonus: s.bonus === true,
    carry,
    carryBonus: int(s.carryBonus, 0, 1000, 0),
    first: isKey(s.first) ? s.first : '',
    total: int(s.total, 0, Number.MAX_SAFE_INTEGER, 0),
  };
}

/**
 * Today's quests over `save[key]`: `perDay` of the pool drawn by the day's seed (the same for every player on the same
 * day with `local: false`), each claimed alone, a bonus when all are claimed. A new day draws new quests and keeps
 * what was earned and not claimed. Deterministic with `now`.
 */
export function dailyQuests<Id extends string, R = number>(save: SaveHolder, opts: QuestsOptions<Id, R>): DailyQuests<Id, R> {
  const perDay = int(opts.perDay ?? 3, 1, 10, 3);
  const problems = checkQuests(opts.pool, perDay);
  if (problems.length) throw new Error(`dailyQuests: ${problems.join('; ')}`);
  const key = opts.key ?? 'quests';
  const holder = save as Record<string, unknown>;
  const log = loadQuests(holder[key]);
  holder[key] = log;
  const persist = () => opts.persist?.();
  const byId = new Map(opts.pool.map((q) => [q.id as string, q]));
  const need = (id: string) => Math.floor(byId.get(id)?.need ?? 1);
  const hasBonus = opts.bonus !== undefined && opts.bonus !== null;

  /** The day's draw: a seeded shuffle of the pool, its first `perDay` */
  const draw = (day: string): string[] => dayShuffle(opts.pool.map((q) => q.id as string), day, `${opts.salt ?? ''}:quests`).slice(0, perDay);

  const refresh = (): string => {
    const t = today(opts);
    let changed = false;
    if (!log.first || t < log.first) {
      log.first = t;
      changed = true;
    }
    if (log.day !== t) {
      if (log.day && t > log.day) {
        // What was earned stays the player's: done and unclaimed quests carry, an earned bonus carries
        for (const q of log.list) if (!q.claimed && byId.has(q.id) && q.have >= need(q.id)) log.carry.push({ id: q.id, day: log.day });
        if (hasBonus && !log.bonus && log.list.length > 0 && log.list.every((q) => q.have >= need(q.id))) log.carryBonus++;
        log.carry = log.carry.slice(-60);
      }
      log.day = t;
      log.list = draw(t).map((id) => ({ id, have: 0, claimed: false }));
      log.bonus = false;
      changed = true;
    } else if (log.list.length !== perDay || log.list.some((q) => !byId.has(q.id))) {
      // The game's pool changed under a saved day: draw again, keeping the progress of the quests still there
      const kept = new Map(log.list.map((q) => [q.id, q]));
      log.list = draw(t).map((id) => kept.get(id) ?? { id, have: 0, claimed: false });
      changed = true;
    }
    if (changed) persist();
    return t;
  };
  const available = (t: string) => (opts.from ?? 'firstVisit') === 'firstVisit' || t > log.first;
  const rowOf = (q: QuestLog['list'][number], index: number): QuestRow<Id, R> => {
    const n = need(q.id);
    return { index, id: q.id as Id, need: n, have: Math.min(n, q.have), share: Math.min(1, q.have / n), done: q.have >= n, claimed: q.claimed, reward: byId.get(q.id)!.reward };
  };
  const bonusReady = () => hasBonus && !log.bonus && log.list.length > 0 && log.list.every((q) => q.claimed);

  refresh();

  const api: DailyQuests<Id, R> = {
    perDay,
    log,
    def: (id) => byId.get(id) as QuestDef<Id, R> | undefined,
    state() {
      const t = refresh();
      const quests = log.list.map(rowOf);
      const carried = log.carry.filter((c) => byId.has(c.id)).map((c) => ({ id: c.id as Id, day: c.day, reward: byId.get(c.id)!.reward }));
      const avail = available(t);
      const ready = avail ? quests.filter((q) => q.done && !q.claimed).length : 0;
      const bonus = hasBonus ? { reward: opts.bonus as R, ready: bonusReady(), claimed: log.bonus, share: quests.filter((q) => q.claimed).length / perDay } : null;
      return {
        day: t,
        available: avail,
        quests,
        bonus,
        carried,
        carriedBonus: hasBonus ? log.carryBonus : 0,
        claimable: ready + (avail && bonus?.ready ? 1 : 0) + carried.length + (hasBonus ? log.carryBonus : 0),
        allDone: quests.every((q) => q.done),
      };
    },
    add(id, n = 1) {
      const t = refresh();
      if (!available(t) || !(n > 0)) return false;
      const q = log.list.find((x) => x.id === id);
      if (!q || q.claimed) return false;
      const k = need(q.id);
      if (q.have >= k) return false;
      q.have = Math.min(k, q.have + n);
      return q.have >= k;
    },
    claim(which) {
      const t = refresh();
      if (!available(t)) return null;
      const q = typeof which === 'number' ? log.list[which] : log.list.find((x) => x.id === which);
      if (!q || q.claimed || q.have < need(q.id)) return null;
      q.claimed = true;
      log.total++;
      persist();
      return byId.get(q.id)!.reward;
    },
    claimBonus() {
      refresh();
      if (!bonusReady()) return null;
      log.bonus = true;
      persist();
      return opts.bonus as R;
    },
    claimAll() {
      const t = refresh();
      const out: QuestClaim<Id, R>[] = [];
      for (const c of log.carry) if (byId.has(c.id)) out.push({ kind: 'quest', id: c.id as Id, reward: byId.get(c.id)!.reward });
      log.total += out.length;
      log.carry = [];
      if (hasBonus) for (; log.carryBonus > 0; log.carryBonus--) out.push({ kind: 'bonus', id: '', reward: opts.bonus as R });
      if (available(t))
        for (const q of log.list)
          if (!q.claimed && q.have >= need(q.id)) {
            q.claimed = true;
            log.total++;
            out.push({ kind: 'quest', id: q.id as Id, reward: byId.get(q.id)!.reward });
          }
      if (available(t) && bonusReady()) {
        log.bonus = true;
        out.push({ kind: 'bonus', id: '', reward: opts.bonus as R });
      }
      if (out.length) persist();
      return out;
    },
  };
  return api;
}

// --- Achievements -------------------------------------------------------------------------------------------------

/** How rare an achievement is: the banner's and the card's colour */
export const RARITIES = ['common', 'rare', 'epic', 'legendary'] as const;
export type Rarity = (typeof RARITIES)[number];

/** A permanent goal: a test over what the game passes to check() (its save, its stats) */
export interface AchievementDef<C, R = never> {
  id: string;
  /** Default 'common' */
  rarity?: Rarity;
  /** Shown as "???" until earned (a secret: playing at night, a perfect run) */
  hidden?: boolean;
  /** Earned when this is true; an event of the game's own is unlock(id) instead (then test may be omitted) */
  test?: (ctx: C) => boolean;
  /** How far along, 0 … 1 (the card's bar): `(s) => s.stats.restored / 100` */
  progress?: (ctx: C) => number;
  /** What it pays when claimed (optional: most achievements are their own reward) */
  reward?: R;
}

/** What achievements keep in the save (`save.achievements` by default) */
export interface AchievementLog {
  /** Earned: id → the moment (ms since 1970) */
  got: Record<string, number>;
  /** Rewards claimed */
  paid: string[];
}

export interface AchievementsOptions<C, R> {
  list: readonly AchievementDef<C, R>[];
  /** The save field (default 'achievements') */
  key?: string;
  /** The clock in ms (default Date.now): when each was earned */
  now?: () => number;
  /** Called after an unlock or a claim: `() => host.save(save)` */
  persist?: () => void;
}

export interface AchievementRow<R> {
  id: string;
  rarity: Rarity;
  /** Hidden and not earned yet: show "???" */
  secret: boolean;
  unlocked: boolean;
  /** When it was earned (ms), or null */
  at: number | null;
  /** 0 … 1, or null (no progress function; a secret's is never shown) */
  progress: number | null;
  reward: R | null;
  /** Earned, with a reward not claimed yet */
  claimable: boolean;
}

export interface AchievementsState<R> {
  rows: AchievementRow<R>[];
  unlocked: number;
  total: number;
  claimable: number;
}

export interface Achievements<C, R> {
  /** Test every achievement not earned yet: the ones earned now (in the list's order). Saved when there are any */
  check(ctx: C): AchievementDef<C, R>[];
  /** Earn one by the game's own event ("first prestige"): true when it is new */
  unlock(id: string): boolean;
  unlocked(id: string): boolean;
  /** Where things stand; with `ctx` the progress bars are filled in */
  state(ctx?: C): AchievementsState<R>;
  /** Claim an earned achievement's reward, once: the reward, or null */
  claim(id: string): R | null;
  readonly log: AchievementLog;
}

/** The saved achievements made safe: unknown ids are kept (an older list may come back), junk goes */
export function loadAchievements(saved: unknown): AchievementLog {
  const s = record(saved);
  const got: Record<string, number> = {};
  // An older save may keep a plain list of ids (Garage's `ach: string[]`)
  if (Array.isArray(saved)) for (const id of saved) if (typeof id === 'string' && id) got[id] = 0;
  for (const [id, at] of Object.entries(record(s.got))) if (id) got[id] = int(at, 0, Number.MAX_SAFE_INTEGER, 0);
  const paid = Array.isArray(s.paid) ? [...new Set(s.paid.filter((x): x is string => typeof x === 'string' && x in got))] : [];
  return { got, paid };
}

/** Achievements over `save[key]`: earned once, never taken back, hidden ones secret until earned */
export function achievements<C, R = never>(save: SaveHolder, opts: AchievementsOptions<C, R>): Achievements<C, R> {
  const ids = new Set<string>();
  for (const a of opts.list) {
    if (!a.id || ids.has(a.id)) throw new Error(`achievements: ${a.id ? `the id '${a.id}' twice` : 'an achievement without an id'}`);
    ids.add(a.id);
  }
  const key = opts.key ?? 'achievements';
  const holder = save as Record<string, unknown>;
  const log = loadAchievements(holder[key]);
  holder[key] = log;
  const now = opts.now ?? Date.now;
  const persist = () => opts.persist?.();
  const byId = new Map(opts.list.map((a) => [a.id, a]));
  const clamp01 = (v: number) => (Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : 0);

  return {
    log,
    check(ctx) {
      const fresh: AchievementDef<C, R>[] = [];
      for (const a of opts.list) {
        if (a.id in log.got || !a.test) continue;
        let ok = false;
        try {
          ok = a.test(ctx) === true;
        } catch {
          ok = false; // a test over a save that lacks a field is simply not earned yet
        }
        if (ok) {
          log.got[a.id] = now();
          fresh.push(a);
        }
      }
      if (fresh.length) persist();
      return fresh;
    },
    unlock(id) {
      if (!byId.has(id) || id in log.got) return false;
      log.got[id] = now();
      persist();
      return true;
    },
    unlocked: (id) => id in log.got,
    state(ctx) {
      const rows = opts.list.map((a): AchievementRow<R> => {
        const unlocked = a.id in log.got;
        const secret = !!a.hidden && !unlocked;
        let progress: number | null = null;
        if (unlocked) progress = 1;
        else if (!secret && ctx !== undefined && a.progress) {
          try {
            progress = clamp01(a.progress(ctx));
          } catch {
            progress = 0;
          }
        }
        const reward = a.reward === undefined ? null : a.reward;
        return { id: a.id, rarity: a.rarity ?? 'common', secret, unlocked, at: unlocked ? log.got[a.id] || null : null, progress, reward, claimable: unlocked && reward !== null && !log.paid.includes(a.id) };
      });
      return { rows, unlocked: rows.filter((r) => r.unlocked).length, total: rows.length, claimable: rows.filter((r) => r.claimable).length };
    },
    claim(id) {
      const a = byId.get(id);
      if (!a || a.reward === undefined || !(id in log.got) || log.paid.includes(id)) return null;
      log.paid.push(id);
      persist();
      return a.reward;
    },
  };
}
