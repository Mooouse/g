// Shared layout helpers: margins, buttons sized for the audience, corner buttons that respect the
// screen cutout, circle and rect hit tests.

export interface Circle {
  x: number;
  y: number;
  r: number;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** What layout needs from the app */
export interface Screen {
  readonly w: number;
  readonly h: number;
  /** Short side */
  readonly u: number;
  readonly inset: { top: number; right: number; bottom: number; left: number };
  /** Smallest touch target for the audience (diameter, CSS px ≈ dp) */
  readonly minTouchPx: number;
}

/** Margin from the screen edges */
export function margin(s: Screen): number {
  return Math.max(10, s.u * 0.04);
}

/** Radius of a player-facing round button: k of the short side, but never below the audience minimum */
export function buttonRadius(s: Screen, k = 0.085): number {
  return Math.max(s.minTouchPx / 2, s.u * k);
}

/** Round button in the top-left corner (Home) */
export function topLeftButton(s: Screen, r = buttonRadius(s, 0.075)): Circle {
  const m = margin(s);
  return { x: s.inset.left + m + r, y: s.inset.top + m + r, r };
}

export function hitCircle(c: Circle, x: number, y: number, extra = 1.1): boolean {
  const dx = x - c.x;
  const dy = y - c.y;
  const rr = c.r * extra;
  return dx * dx + dy * dy <= rr * rr;
}

export function hitRect(r: Rect, x: number, y: number): boolean {
  return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
}

export function circleRect(c: Circle): Rect {
  return { x: c.x - c.r, y: c.y - c.r, w: c.r * 2, h: c.r * 2 };
}
