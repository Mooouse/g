// Canvas 2D through the engine contract (the default engine: no npm dependency, 16 KB gzipped in the engine lab, plays
// everywhere). The adapter owns the loop, the size and the pause; the game draws in onFrame and simulates in onStep.
//
//   const eng = canvasAdapter(host, canvas);
//   eng.onStep((dt) => sim.step(dt));
//   eng.onFrame(() => draw(eng.context, eng.size));   // the transform is already scaled to CSS px
//   eng.setRunning(true);                              // a run starts; false on the pause screen, results, menus

import { setRenderScale } from '../draw';
import type { GameHost } from '../host';
import { createDriver, type Engine, type EngineOptions } from './driver';

export type { Engine, EngineAudio, EngineOptions, EngineSize } from './driver';

export interface CanvasEngine extends Engine {
  /** The 2D context of #game. onFrame listeners get it with the transform set to CSS px (scaled by the capped DPR) */
  readonly context: CanvasRenderingContext2D;
}

export interface CanvasOptions extends EngineOptions {
  /** An opaque canvas is faster to composite (default false: draw a background every frame) */
  alpha?: boolean;
}

/** Canvas 2D on #game: created stopped; throws when the browser has no 2D canvas (the player shows "can't run") */
export function canvasAdapter(host: GameHost, canvas: HTMLCanvasElement, opts: CanvasOptions = {}): CanvasEngine {
  const context = canvas.getContext('2d', { alpha: opts.alpha ?? false });
  if (!context) throw new Error('no Canvas 2D in this browser');
  let dpr = 1;
  const d = createDriver(host, canvas, opts, (drv) => {
    const scale = () => context.setTransform(dpr, 0, 0, dpr, 0, 0);
    const loop = drv.loop({ render: () => {} });
    // The frame listeners are the drawing: scale the transform before them
    drv.engine.onFrame(scale);
    return {
      start: loop.start,
      stop: loop.stop,
      render: () => {},
      resize(s) {
        dpr = s.dpr;
        canvas.width = Math.round(s.width * s.dpr);
        canvas.height = Math.round(s.height * s.dpr);
        // The page's render scale is the canvas's: what is baked at the density (@gp/art, the themes) draws 1:1
        setRenderScale(dpr);
      },
    };
  });
  return Object.assign(d.engine, { context });
}
