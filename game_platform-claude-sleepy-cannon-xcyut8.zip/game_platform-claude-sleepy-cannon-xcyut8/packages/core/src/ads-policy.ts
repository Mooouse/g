// Ad policy: the pure part of ads — limits, session state and the "may an ad be shown now" rule.
// No DOM, no plugins: the validator (Node) and unit tests use it directly.

/** Frequency limits. Profiles set floors; a game may only make them stricter. */
export interface AdPolicy {
  /** No ads at all in the first N seconds after app launch */
  noAdsAfterLaunchSec: number;
  /** First ad — not before the end of this round number in a session… */
  firstAdAfterRound: number;
  /**
   * …or, if that comes first, once the session has lasted this many seconds (from sessionStartSec): for games whose
   * rounds are long runs, where "round 3" would mean 12–15 min without an ad. Never before noAdsAfterLaunchSec.
   * Undefined: no time path (the round rule alone).
   */
  firstAdAfterSec?: number;
  /** After that — at most once per this many rounds */
  everyRounds: number;
  /** And at most once per this many seconds */
  minIntervalSec: number;
  /** Safety cap: longest wait for a requested ad to close before the game moves on anyway, s */
  maxAdWaitSec: number;
  /** The dev stub closes itself after this many seconds */
  testAdCloseSec: number;
}

/** Session state for the frequency limits. Time is in seconds since app start. */
export interface AdState {
  sessionStartSec: number;
  roundsThisSession: number;
  roundsSinceAd: number;
  lastAdSec: number | null;
}

/** Whether an ad may be shown now, in the natural break after a round */
export function shouldShowAd(s: AdState, nowSec: number, noAds: boolean, p: AdPolicy): boolean {
  if (noAds) return false;
  if (nowSec - s.sessionStartSec < p.noAdsAfterLaunchSec) return false;
  const firstBySec = p.firstAdAfterSec ?? Infinity;
  if (s.roundsThisSession < p.firstAdAfterRound && nowSec - s.sessionStartSec < firstBySec) return false;
  if (s.lastAdSec !== null) {
    if (s.roundsSinceAd < p.everyRounds) return false;
    if (nowSec - s.lastAdSec < p.minIntervalSec) return false;
  }
  return true;
}

export interface AdMobConfig {
  interstitialId: string;
  /** true with Google's test IDs (all non-release builds) */
  isTesting: boolean;
  /** COPPA: tagForChildDirectedTreatment */
  childDirected: boolean;
  /** GDPR: tagForUnderAgeOfConsent */
  underAgeOfConsent: boolean;
  maxAdContentRating: 'G' | 'PG' | 'T' | 'MA';
  /** Non-personalized ads only */
  nonPersonalized: boolean;
}

