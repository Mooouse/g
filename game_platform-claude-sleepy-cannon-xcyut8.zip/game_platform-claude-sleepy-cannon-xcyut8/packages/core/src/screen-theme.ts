// One look for every platform screen: screenTheme({ bg, panel, ink, muted, accent, accentInk, radius, font, … }) sets
// a shared base of CSS variables (--gp-theme-*) on the page, and each platform screen — the results, welcome back, the
// language sheet, the daily streak, the dialogue, the season track, the level shop, the sites map, the hint — falls back
// to it wherever the game didn't set that screen's own variable. Before it a game themed ten namespaces by hand (or
// didn't, and its results wore the platform's slate grey and yellow beside its own art: Frankengun's review, 2026-10-18).
//
//   screenTheme({ bg: '#140c2a', panel: 'rgba(255,255,255,0.08)', ink: '#f4ecff', muted: '#a99cc8', accent: '#ff4fd8',
//     accentInk: '#ffffff', radius: 16, font: useFont(NUNITO_BLACK), display: useFont(DELA_GOTHIC_ONE) });
//
// The order, for each screen variable: the game's own (`#gp-results { --gp-results-bg: … }`) → the theme → the old
// default. So a game that themes nothing looks as before, and a per-screen variable still wins over the theme.

import { FONT_FALLBACK } from './i18n.ts';

export interface ScreenTheme {
  /** A screen's own panel: the results, a card, the shop, the map's background, the hint pill */
  bg?: string;
  /** A raised surface on it: a shop card, a season tier, a day of the streak, the language buttons, a goal box */
  panel?: string;
  /** The text */
  ink?: string;
  /** Secondary text: captions, details, the quiet buttons (Menu, ×) */
  muted?: string;
  /** The one primary colour: the big button, the bars' fill, what's ready, the chosen language */
  accent?: string;
  /** The words on the accent */
  accentInk?: string;
  /** A second accent: a season's big tiers, the shop's "Best value", "you are here" on the map */
  accent2?: string;
  /** The empty part of a bar, outlines and a disabled button */
  track?: string;
  /** A card's border and the speaker's plate in a dialogue */
  edge?: string;
  /** The veil behind a modal card (the streak, welcome back, the season, the language sheet) */
  backdrop?: string;
  /** Corner radius of the panels: px or a CSS length */
  radius?: number | string;
  /** The text's family (a bundled face: useFont() from @gp/art/type); the platform's FONT_FALLBACK is added after it */
  font?: string;
  /** Headings, big numbers and the main button (default: `font`) */
  display?: string;
}

/** The CSS variable of each theme field */
export const SCREEN_THEME_VARS: Readonly<Record<keyof ScreenTheme, string>> = {
  bg: '--gp-theme-bg',
  panel: '--gp-theme-panel',
  ink: '--gp-theme-ink',
  muted: '--gp-theme-muted',
  accent: '--gp-theme-accent',
  accentInk: '--gp-theme-accent-ink',
  accent2: '--gp-theme-accent2',
  track: '--gp-theme-track',
  edge: '--gp-theme-edge',
  backdrop: '--gp-theme-backdrop',
  radius: '--gp-theme-radius',
  font: '--gp-theme-font',
  display: '--gp-theme-display',
};

/** A family with the platform's fallback after it (CJK, emoji and the rest the face doesn't have) */
const withFallback = (family: string) => (family.includes(FONT_FALLBACK) ? family : `${family}, ${FONT_FALLBACK}`);

/** The theme as CSS variables: { '--gp-theme-bg': '#140c2a', … } (only the fields given) */
export function screenThemeVars(theme: ScreenTheme): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, name] of Object.entries(SCREEN_THEME_VARS) as [keyof ScreenTheme, string][]) {
    const v = theme[k];
    if (v === undefined || v === '') continue;
    if (k === 'radius') out[name] = typeof v === 'number' ? `${v}px` : String(v);
    else if (k === 'font' || k === 'display') out[name] = withFallback(String(v));
    else out[name] = String(v);
  }
  return out;
}

/** The theme as a CSS rule for the game's own style sheet (default selector :root) */
export function screenThemeCss(theme: ScreenTheme, selector = ':root'): string {
  const vars = Object.entries(screenThemeVars(theme)).map(([k, v]) => `${k}: ${v};`);
  return `${selector} { ${vars.join(' ')} }`;
}

/**
 * Dress every platform screen in the game's look: sets the --gp-theme-* variables on `root` (default the page's
 * <html>, so every screen inherits them wherever it is mounted). Call it again to change the look (fields left out
 * keep their value); the returned function removes what this call set.
 */
export function screenTheme(theme: ScreenTheme, root: HTMLElement = document.documentElement): () => void {
  const vars = screenThemeVars(theme);
  for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v);
  return () => {
    for (const [k, v] of Object.entries(vars)) if (root.style.getPropertyValue(k) === v) root.style.removeProperty(k);
  };
}
