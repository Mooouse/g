// Sign-in on the portal (Playgama Bridge: bridge.player). Playgama's QA Tool checks it (Authorization): where the
// platform has accounts, the game offers a way to sign in and hides it once the player is signed in. Never required to
// play (Playgama's checklist: launching needs no sign-in). On every other portal it is nothing.
// - signInButton(): a button for the game's own menu (its look: className). null when sign-in isn't offered or done;
// - autoSignIn(): what the host does on Playgama when the game placed no button: a small "Sign in" in the corner of the
//   menus, hidden during play and once signed in. A game that places its own (data-gp="sign-in") turns it off.

const ATTR = 'sign-in';

export interface SignInHost {
  readonly account: { supported: boolean; authorized: boolean; name: string | null };
  signIn(o?: { reload?: boolean }): Promise<boolean>;
  t(key: string, vars?: Record<string, string | number>): string;
  readonly minTouchPx?: number;
}

/** The game's own sign-in button (menu, settings). null when the portal has no sign-in or the player is signed in */
export function signInButton(opts: { host: SignInHost; className?: string; onSignIn?(): void }): HTMLButtonElement | null {
  const { host } = opts;
  if (!host.account.supported || host.account.authorized) return null;
  const b = document.createElement('button');
  b.type = 'button';
  b.dataset.gp = ATTR;
  if (opts.className) b.classList.add(...opts.className.split(/\s+/).filter(Boolean));
  b.textContent = host.t('gp.signIn');
  b.title = host.t('gp.signIn.why');
  const min = host.minTouchPx ?? 48;
  b.style.minHeight = `${min}px`;
  b.style.minWidth = `${min}px`;
  b.addEventListener('click', async () => {
    b.disabled = true;
    const ok = await host.signIn();
    if (ok) {
      document.querySelectorAll(`[data-gp="${ATTR}"]`).forEach((el) => el.remove());
      opts.onSignIn?.();
    } else b.disabled = false;
  });
  return b;
}

/**
 * The host's own sign-in on Playgama: a corner button on the menus (bottom left, inside the safe area), hidden while a
 * run plays and gone once signed in or when the game put its own data-gp="sign-in" on the page. It never lies on the
 * game's own controls (2026-10-10, Rivet Clash at 360×800: it covered "Build & fight"): when it would, it moves to the
 * next free corner or edge middle, and with none free it stays hidden on that screen. Returns a stop function.
 */
export function autoSignIn(host: SignInHost & { readonly isPlaying: boolean }, root: HTMLElement = document.body): () => void {
  if (typeof document === 'undefined' || !host.account.supported || host.account.authorized) return () => {};
  const b = signInButton({ host });
  if (!b) return () => {};
  b.dataset.gpAuto = '1';
  b.style.cssText += ';position:fixed;z-index:2147483000;padding:0 16px;border-radius:999px;border:1px solid rgba(255,255,255,.35);background:rgba(20,16,30,.78);color:#fff;font:600 15px/1 system-ui,sans-serif;cursor:pointer;backdrop-filter:blur(4px)';
  let corner = 0;
  place(b, corner);
  root.append(b);
  const tick = () => {
    const own = [...document.querySelectorAll(`[data-gp="${ATTR}"]`)].some((el) => el !== b);
    if (own || host.account.authorized) {
      b.remove();
      return true;
    }
    if (host.isPlaying) {
      b.style.display = 'none';
      return false;
    }
    b.style.display = '';
    // A corner clear of the game's controls and its text (a HUD counter: Hang the Moon's ★ at 360×800); failing that,
    // one clear of the controls; failing that, hidden on this screen
    const controls = controlRects(b);
    const texts = textRects(b);
    const clear = (c: number, withText: boolean) => (place(b, c), !clashes(b, controls) && (!withText || !clashes(b, texts)));
    for (const withText of [true, false]) {
      for (let i = 0; i < CORNERS.length; i++) {
        const c = (corner + i) % CORNERS.length;
        if (clear(c, withText)) {
          corner = c;
          return false;
        }
      }
    }
    place(b, corner);
    b.style.display = 'none';
    return false;
  };
  const id = setInterval(() => tick() && clearInterval(id), 250);
  tick();
  return () => {
    clearInterval(id);
    b.remove();
  };
}

// The places it tries, in order: bottom left first (menus keep their main buttons in the middle and settings on top),
// then the other corners, then the middle of the top and bottom edges (a phone title with every corner taken: Hang the
// Moon at 360×800)
const CORNERS = [
  ['left', 'bottom'],
  ['right', 'bottom'],
  ['left', 'top'],
  ['right', 'top'],
  ['center', 'top'],
  ['center', 'bottom'],
] as const;
const GAP = 8;

function place(b: HTMLElement, i: number): void {
  const [x, y] = CORNERS[i];
  b.style.left = x === 'left' ? 'calc(10px + env(safe-area-inset-left,0px))' : x === 'center' ? '50%' : 'auto';
  b.style.right = x === 'right' ? 'calc(10px + env(safe-area-inset-right,0px))' : 'auto';
  b.style.transform = x === 'center' ? 'translateX(-50%)' : '';
  b.style.bottom = y === 'bottom' ? 'calc(10px + env(safe-area-inset-bottom,0px))' : 'auto';
  b.style.top = y === 'top' ? 'calc(10px + env(safe-area-inset-top,0px))' : 'auto';
}

/** The page's visible controls: what a player taps (the game's buttons, links, inputs) */
function controlRects(self: HTMLElement): DOMRect[] {
  const out: DOMRect[] = [];
  for (const el of document.querySelectorAll<HTMLElement>('button,a[href],[role="button"],input,select,textarea')) {
    if (el === self || self.contains(el) || el.contains(self)) continue;
    if (el.tagName === 'CANVAS') continue;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0 || cs.pointerEvents === 'none') continue;
    if (r.width * r.height > window.innerWidth * window.innerHeight * 0.5) continue; // a full-screen layer, not a control
    out.push(r);
  }
  return out;
}

/** The page's visible text (each text node's own box): labels and counters a corner button must not cover */
function textRects(self: HTMLElement): DOMRect[] {
  const out: DOMRect[] = [];
  const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const range = document.createRange();
  for (let n = walk.nextNode(); n; n = walk.nextNode()) {
    if (!n.nodeValue?.trim() || self.contains(n)) continue;
    const el = n.parentElement;
    if (!el) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || Number(cs.opacity) === 0) continue;
    range.selectNodeContents(n);
    const r = range.getBoundingClientRect();
    if (r.width >= 1 && r.height >= 1) out.push(r);
  }
  return out;
}

function clashes(b: HTMLElement, controls: DOMRect[]): boolean {
  const r = b.getBoundingClientRect();
  return controls.some((o) => r.left < o.right + GAP && r.right > o.left - GAP && r.top < o.bottom + GAP && r.bottom > o.top - GAP);
}
