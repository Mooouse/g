// Movement input for games that steer something: keyboard (WASD / arrows) and a floating joystick
// (touch or mouse drag anywhere on the element). direction() is a vector of length ≤ 1.
// From Petri Panic (QmaCyber/game2, src/platform/input.ts), where its QA covered desktop and phones.
// A shooter's aim, look and fire on top of it: TwinStick / LookInput (twin-stick.ts), which moves with a MoveInput.

/** What MoveInput needs of the host to obey its pause (GameHost has it) */
export interface InputHost {
  readonly paused: boolean;
  onPause(fn: () => void): void;
}

export interface MoveInputOptions {
  /** Full deflection at this distance from the base, CSS px (default 56) */
  maxRadius?: number;
  /**
   * Which keys move: 'both' (default) WASD and the arrows; 'wasd' leaves the arrows to the game (a twin-stick's fire
   * directions); 'arrows' leaves WASD. Physical keys (e.code): WASD is ZQSD on AZERTY by itself
   */
  keys?: 'both' | 'wasd' | 'arrows';
  /** Which presses start the stick (default every one): `(e) => e.pointerType !== 'mouse'` keeps the mouse for aiming */
  accept?: (e: PointerEvent) => boolean;
  /** Obey the host's pause: held keys and the stick are let go, nothing moves while it is paused */
  host?: InputHost;
}

const ARROWS = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];

export class MoveInput {
  private readonly keys = new Set<string>();
  /** Joystick: where the finger went down (the base) and where it is now, CSS px. null — not touching */
  stick: { ox: number; oy: number; x: number; y: number; id: number } | null = null;
  /** Full deflection at this distance from the base, CSS px */
  readonly maxRadius: number;
  private enabled = false;
  private readonly useWasd: boolean;
  private readonly useArrows: boolean;
  private readonly host?: InputHost;

  constructor(el: HTMLElement, opts: MoveInputOptions = {}) {
    this.maxRadius = opts.maxRadius ?? 56;
    this.useWasd = opts.keys !== 'arrows';
    this.useArrows = opts.keys !== 'wasd';
    this.host = opts.host;
    const accept = opts.accept;
    window.addEventListener('keydown', (e) => {
      if (this.host?.paused) return;
      if ((this.useArrows && ARROWS.includes(e.key)) || e.key === ' ') e.preventDefault();
      this.keys.add(e.code);
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.clear());
    opts.host?.onPause(() => this.clear());
    el.addEventListener('pointerdown', (e) => {
      if (!this.enabled || this.stick || this.host?.paused || (accept && !accept(e))) return;
      // A synthetic or already released pointer can't be captured: the stick still works without the capture
      try {
        el.setPointerCapture?.(e.pointerId);
      } catch {
        /* not capturable */
      }
      this.stick = { ox: e.clientX, oy: e.clientY, x: e.clientX, y: e.clientY, id: e.pointerId };
    });
    el.addEventListener('pointermove', (e) => {
      const s = this.stick;
      if (!s || e.pointerId !== s.id) return;
      s.x = e.clientX;
      s.y = e.clientY;
      // The base follows a finger that went too far, so turning around stays quick
      const dx = s.x - s.ox;
      const dy = s.y - s.oy;
      const d = Math.hypot(dx, dy);
      const far = this.maxRadius * 1.6;
      if (d > far) {
        const k = (d - far) / d;
        s.ox += dx * k;
        s.oy += dy * k;
      }
    });
    const end = (e: PointerEvent) => {
      if (this.stick && e.pointerId === this.stick.id) this.stick = null;
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  }

  /** Only while playing: menus get their taps */
  setEnabled(on: boolean): void {
    this.enabled = on;
    if (!on) this.stick = null;
  }

  clear(): void {
    this.keys.clear();
    this.stick = null;
  }

  pressed(code: string): boolean {
    return this.keys.has(code);
  }

  direction(): { x: number; y: number } {
    let x = 0;
    let y = 0;
    if (this.host?.paused) return { x, y };
    const k = this.keys;
    const w = this.useWasd;
    const a = this.useArrows;
    if ((w && k.has('KeyA')) || (a && k.has('ArrowLeft'))) x -= 1;
    if ((w && k.has('KeyD')) || (a && k.has('ArrowRight'))) x += 1;
    if ((w && k.has('KeyW')) || (a && k.has('ArrowUp'))) y -= 1;
    if ((w && k.has('KeyS')) || (a && k.has('ArrowDown'))) y += 1;
    const s = this.stick;
    if (s) {
      const dx = s.x - s.ox;
      const dy = s.y - s.oy;
      const d = Math.hypot(dx, dy);
      if (d > 6) {
        const m = Math.min(1, d / this.maxRadius);
        x += (dx / d) * m;
        y += (dy / d) * m;
      }
    }
    const len = Math.hypot(x, y);
    return len > 1 ? { x: x / len, y: y / len } : { x, y };
  }
}
