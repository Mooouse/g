// A daily table: a different setup every day from the day's seed (which modules, scoring cards or rules are on the
// table today), the same for every player, with named score bands ("Gold at 400"), a near-miss line ("12 points from
// Gold") and a share card — text and a canvas — for the day's result (docs/research/board-games-2026-10.md §4 #5: the
// shared roll of a roll-and-write, the daily of a puzzle). On top of dailyRunSeed / recordDaily; pure logic over a field
// of the game's save, an injected clock. The canvas card is drawShareCard().
//
//   const TABLE = dailyTable(save, {
//     salt: 'nine-plots',
//     modules: { from: ['wind', 'bees', 'frost', 'market', 'moles'], pick: 2 },     // today's two modules
//     setup: (rng) => ({ start: rng.int(9) }),                                     // anything else of the day's own
//     bands: [{ id: 'bronze', at: 100 }, { id: 'silver', at: 250 }, { id: 'gold', at: 400 }, { id: 'legend', at: 600 }],
//     persist: () => host.save(save),
//   });
//   const day = TABLE.today();          // { key, seed: { code: 'K7M2-QX9P', seed }, modules: ['bees', 'moles'], setup }
//   const run = seededRng(day.seed.seed);
//   …
//   const r = TABLE.record(score);      // { best, newBest, first, band, next, need, near }
//   TABLE.nearLine(score, host.t);      // "12 points from Gold" (null when it isn't near)
//   const card = TABLE.card(score, { title: 'Nine Plots', name: (b) => host.t(`band.${b}`) });
//   shareText(card);                    // the text to copy; drawShareCard(canvas, card) — an image to save
//
// Rules: the day turns over at 00:00 UTC (one table for everyone; `local: true` for the player's own midnight). A
// missed day costs nothing (D56): the log counts days played, never a streak to lose. A run with a custom seed is not
// the daily: don't record() it.

import { DAILY_KEEP, dayKey, daySeed, loadDaily, recordDaily, type DailyLog } from './daily.ts';
import { seededRng, type SeededRng } from './rng.ts';
import { dailyRunSeed, type RunSeed } from './seed.ts';
import type { SaveHolder } from './streak.ts';

/** A named score band: reached at `at` points (or at most `at`, when lower is better) */
export interface ScoreBand {
  id: string;
  at: number;
}

export interface DailyTableOptions<M extends string = string, S = undefined> {
  /** The game's id: two games don't share a table */
  salt: string;
  /** From the easiest to reach to the best */
  bands: readonly ScoreBand[];
  /** A high score is better (default) or a low one (a time, moves) */
  better?: 'high' | 'low';
  /** Today's modules: `pick` distinct of `from`, by the day's seed */
  modules?: { from: readonly M[]; pick: number };
  /** The rest of the day's setup, from the day's own rng (a separate stream: adding a module doesn't change it) */
  setup?: (rng: SeededRng, key: string) => S;
  /** How close counts as a near miss: within this share of the step to the next band (default 0.25) */
  near?: number;
  /** The clock in ms (default Date.now) */
  now?: () => number;
  /** Days turn over at the player's midnight (default false: 00:00 UTC, the same table for everyone) */
  local?: boolean;
  /** The save field (default 'table') */
  key?: string;
  persist?: () => void;
}

export interface DailySetup<M extends string = string, S = undefined> {
  key: string;
  /** The day's run seed (dailyRunSeed of the salt): the run's randomness */
  seed: RunSeed;
  modules: M[];
  setup: S;
}

export interface BandResult {
  /** The best band reached (null: none yet) */
  band: ScoreBand | null;
  /** The next band up (null: the best reached) */
  next: ScoreBand | null;
  /** How far to the next band (points; null at the top) */
  need: number | null;
  /** Toward the next band, 0 … 1 (1 at the top) */
  share: number;
  /** Close to the next band (within `near` of the step) */
  near: boolean;
}

export interface TableLog {
  /** The day of `best` ('' none) */
  day: string;
  /** Today's best (null: not played today) */
  best: number | null;
  /** Runs today */
  plays: number;
  /** Days played (a calendar, never a streak) */
  days: DailyLog;
}

export interface TableRecord extends BandResult {
  best: number;
  newBest: boolean;
  /** The first run of the day */
  first: boolean;
}

/** What a share card says: the game's words already in the player's language */
export interface ShareCard {
  title: string;
  /** The day, YYYY-MM-DD */
  day: string;
  score: string;
  /** The band's name ('' none reached) */
  band: string;
  /** Bands reached of all */
  reached: number;
  total: number;
  /** The day's seed code */
  seed: string;
  /** The near-miss line, if near */
  near: string | null;
  url?: string;
}

export interface DailyTable<M extends string = string, S = undefined> {
  readonly bands: readonly ScoreBand[];
  /** The setup of a day (default today) */
  today(key?: string): DailySetup<M, S>;
  /** Where a score stands among the bands */
  band(score: number): BandResult;
  /** "12 points from Gold" when near (null otherwise); `unit` formats the amount ("0.4 s") instead of points */
  nearLine(score: number, t: (key: string, params?: Record<string, string | number>) => string, opts?: { name?: (band: string) => string; unit?: (n: number) => string }): string | null;
  /** A daily run's score: today's best kept, the day added to the calendar on its first run */
  record(score: number): TableRecord;
  /** The share card of a score (default today's best) */
  card(score: number | null, opts: { title: string; name?: (band: string) => string; format?: (n: number) => string; url?: string; t?: (key: string, params?: Record<string, string | number>) => string; unit?: (n: number) => string }): ShareCard;
  readonly log: TableLog;
}

const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});
const KEY = /^\d{4}-\d{2}-\d{2}$/;
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/** The saved field made safe */
export function loadTable(saved: unknown): TableLog {
  const s = record(saved);
  const best = typeof s.best === 'number' && Number.isFinite(s.best) ? s.best : null;
  const day = typeof s.day === 'string' && KEY.test(s.day) ? s.day : '';
  return { day, best: day ? best : null, plays: day && typeof s.plays === 'number' && s.plays > 0 ? Math.floor(s.plays) : 0, days: loadDaily(s.days) };
}

/** The daily table over `save[key]`: see the module's comment */
export function dailyTable<M extends string = string, S = undefined>(save: SaveHolder, opts: DailyTableOptions<M, S>): DailyTable<M, S> {
  if (!opts.salt) throw new Error('dailyTable: salt (the game id) is required');
  if (!opts.bands.length) throw new Error('dailyTable: no score band');
  const low = opts.better === 'low';
  const bands = opts.bands;
  if (new Set(bands.map((b) => b.id)).size !== bands.length) throw new Error('dailyTable: a band id twice');
  for (let i = 1; i < bands.length; i++)
    if (low ? !(bands[i].at < bands[i - 1].at) : !(bands[i].at > bands[i - 1].at))
      throw new Error(`dailyTable: bands go from the easiest to the best (${low ? 'falling' : 'rising'} \`at\`): ${bands[i - 1].id} ${bands[i - 1].at}, ${bands[i].id} ${bands[i].at}`);
  if (opts.modules && !(Number.isInteger(opts.modules.pick) && opts.modules.pick >= 0 && opts.modules.pick <= opts.modules.from.length))
    throw new Error('dailyTable: modules.pick is a whole number from 0 to the number of modules');
  const near = Number.isFinite(opts.near) ? Math.max(0, Math.min(1, opts.near as number)) : 0.25;
  const key = opts.key ?? 'table';
  const holder = save as Record<string, unknown>;
  const log = loadTable(holder[key]);
  holder[key] = log;
  const todayKey = () => dayKey(new Date((opts.now ?? Date.now)()), { local: opts.local ?? false });
  const reached = (score: number, b: ScoreBand) => (low ? score <= b.at : score >= b.at);

  const today = (k: string = todayKey()): DailySetup<M, S> => {
    const seed = dailyRunSeed(opts.salt, k);
    let modules: M[] = [];
    if (opts.modules) {
      const r = seededRng(daySeed(k, `${opts.salt}:modules`));
      const left = [...opts.modules.from];
      for (let i = 0; i < opts.modules.pick; i++) modules.push(left.splice(r.int(left.length), 1)[0]);
      modules = opts.modules.from.filter((m) => modules.includes(m)); // the list's order: the same reading every day
    }
    const setup = opts.setup ? opts.setup(seededRng(daySeed(k, `${opts.salt}:setup`)), k) : (undefined as S);
    return { key: k, seed, modules, setup };
  };

  const band = (score: number): BandResult => {
    let i = -1;
    bands.forEach((b, k) => (reached(score, b) ? (i = k) : 0));
    const cur = i >= 0 ? bands[i] : null;
    const next = bands[i + 1] ?? null;
    if (!next) return { band: cur, next: null, need: null, share: 1, near: false };
    const from = cur ? cur.at : low ? next.at + (bands[1] ? Math.abs(bands[0].at - bands[1].at) : next.at) : 0;
    const step = Math.abs(next.at - from) || 1;
    const need = Math.abs(next.at - score);
    const share = Math.max(0, Math.min(1, 1 - need / step));
    return { band: cur, next, need, share, near: need > 0 && need <= near * step };
  };

  const nearLine: DailyTable<M, S>['nearLine'] = (score, t, o = {}) => {
    const b = band(score);
    if (!b.near || !b.next || b.need === null) return null;
    const name = (o.name ?? cap)(b.next.id);
    const n = Math.round(b.need * 100) / 100;
    return o.unit ? t('gp.daily.near', { amount: o.unit(n), band: name }) : t('gp.daily.nearPoints', { n, band: name });
  };

  return {
    bands,
    log,
    today,
    band,
    nearLine,
    record(score) {
      const k = todayKey();
      if (log.day !== k) Object.assign(log, { day: k, best: null, plays: 0 });
      const first = recordDaily(log.days, k, DAILY_KEEP);
      const v = Number(score);
      const prev = log.best;
      const newBest = Number.isFinite(v) && (prev === null || (low ? v < prev : v > prev));
      if (newBest) log.best = v;
      log.plays++;
      opts.persist?.();
      const best = log.best ?? v;
      return { ...band(best), best, newBest, first };
    },
    card(score, o) {
      const k = todayKey();
      const v = score ?? (log.day === k ? log.best : null) ?? 0;
      const b = band(v);
      const name = o.name ?? cap;
      return {
        title: o.title,
        day: k,
        score: (o.format ?? ((n: number) => String(n)))(v),
        band: b.band ? name(b.band.id) : '',
        reached: b.band ? bands.indexOf(b.band) + 1 : 0,
        total: bands.length,
        seed: today(k).seed.code,
        near: o.t ? nearLine(v, o.t, { name, unit: o.unit }) : null,
        ...(o.url ? { url: o.url } : {}),
      };
    },
  };
}

/** The card as text to copy: title and day, band and score, a bar of the bands, the seed, the link */
export function shareText(card: ShareCard): string {
  const bar = '▰'.repeat(card.reached) + '▱'.repeat(Math.max(0, card.total - card.reached));
  return [`${card.title} · ${card.day}`, card.band ? `${card.band} · ${card.score}` : card.score, bar, card.near ?? '', `#${card.seed}`, card.url ?? ''].filter(Boolean).join('\n');
}

export interface ShareCardStyle {
  bg?: string;
  ink?: string;
  muted?: string;
  accent?: string;
  font?: string;
}

/**
 * The card drawn on a canvas (1200×630 by default — the size link previews use — or the canvas's own size if set):
 * the title, the day, the band in big letters, the score, a bar of the bands and the seed. Returns the canvas: save it
 * with canvas.toBlob() or show it on the results. The game's words go in the card; the colours in `style`.
 */
export function drawShareCard<C extends HTMLCanvasElement | OffscreenCanvas>(canvas: C, card: ShareCard, style: ShareCardStyle = {}): C {
  if (!canvas.width || !canvas.height || (canvas.width === 300 && canvas.height === 150)) {
    canvas.width = 1200;
    canvas.height = 630;
  }
  const g = canvas.getContext('2d') as CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D | null;
  if (!g) return canvas;
  const W = canvas.width;
  const H = canvas.height;
  const u = Math.min(W / 1200, H / 630);
  const font = style.font ?? 'system-ui, sans-serif';
  const bg = style.bg ?? '#18263a';
  const ink = style.ink ?? '#f2f7ff';
  const muted = style.muted ?? '#a9b9cc';
  const accent = style.accent ?? '#ffd166';
  g.fillStyle = bg;
  g.fillRect(0, 0, W, H);
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  const text = (s: string, y: number, size: number, color: string, weight = 700) => {
    g.font = `${weight} ${Math.round(size * u)}px ${font}`;
    g.fillStyle = color;
    let px = size * u;
    // Shrink a line that doesn't fit (a long title in German)
    while (g.measureText(s).width > W * 0.9 && px > 10) {
      px *= 0.92;
      g.font = `${weight} ${Math.round(px)}px ${font}`;
    }
    g.fillText(s, W / 2, y * u);
  };
  text(card.title, 90, 56, ink, 800);
  text(card.day, 150, 30, muted, 600);
  if (card.band) text(card.band, 260, 96, accent, 900);
  text(card.score, card.band ? 360 : 300, 64, ink, 800);
  const n = Math.max(1, card.total);
  const bw = Math.min(90, (W * 0.7) / n / u - 12);
  const total = n * bw + (n - 1) * 12;
  for (let i = 0; i < n; i++) {
    g.fillStyle = i < card.reached ? accent : 'rgba(255,255,255,0.14)';
    const x = W / 2 - (total * u) / 2 + i * (bw + 12) * u;
    g.fillRect(x, 440 * u, bw * u, 22 * u);
  }
  if (card.near) text(card.near, 505, 28, muted, 600);
  text(`#${card.seed}`, 575, 26, muted, 600);
  return canvas;
}
