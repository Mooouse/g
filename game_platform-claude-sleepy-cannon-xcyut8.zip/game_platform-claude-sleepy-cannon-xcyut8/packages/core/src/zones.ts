// Zones: the piles of a card, token or tile game — a deck, a hand, a discard, an exhaust pile, a blind bag whose makeup
// the player can see, a market row that slides and refills, and a push-your-luck bust rule with its live odds. What every
// card or bag game would otherwise write by hand (docs/research/board-games-2026-10.md §1.1–1.3, §1.9; block #1).
//
// Pure and save-safe: the rules live in a Zones object, the state is plain JSON (the piles, the rng's position, the last
// draw) — store it as it is in a mid-run save, sanitize() it on load, keep states in an UndoHistory (every call returns
// a new state and never changes the old one). Deterministic: the state carries its own seeded rng (rng.ts seededRng),
// so the same seed and the same calls draw the same cards on every machine, also after a save and a load.
//
//   const z = new Zones<Card, 'draw' | 'hand' | 'discard' | 'exhaust'>({
//     piles: ['draw', 'hand', 'discard', 'exhaust'], draw: { from: 'draw', to: 'hand' }, reshuffle: { draw: 'discard' },
//   });
//   let s = z.start({ draw: starterDeck }, runSeed);   // the draw pile shuffled
//   s = z.draw(s, 5);                                   // the discard is shuffled back in when the draw pile runs out
//   s = z.move(s, 'hand', 2, 'discard');                // play the third card
//   z.chanceWithin(s, 'draw', (c) => c.kind === 'attack', 5); // "an attack in the next hand": 0.82
//
// A pile's index 0 is its top (the next card drawn, the first market slot); a blind pile (a bag) is drawn at random and
// its order means nothing — counts() is what the player is shown.

import { seededRng, type SeededRng } from './rng.ts';

/** Where an item goes in its new pile: on top (drawn next), at the end (a hand's right, a discard), or shuffled in */
export type ZonePlace = 'top' | 'end' | 'shuffle';

export interface MarketDef<P extends string> {
  /** The pile that refills the row (a supply deck or bag) */
  from: P;
  /** Slots in the row */
  slots: number;
  /**
   * 'slide' (default): the items after a taken one move down a slot, the new one comes in at the end (Century, Small
   * World: waiting makes an item cheaper); 'in-place': the new one takes the empty slot (Splendor)
   */
  refill?: 'slide' | 'in-place';
  /** Where decay() sends the item it drops from slot 0 (default: out of the game) */
  decayTo?: P;
}

export interface ZonesDef<T, P extends string> {
  piles: readonly P[];
  /** Piles drawn blind and at random (a bag): their order means nothing, counts() is the makeup the player sees */
  blind?: readonly P[];
  /** The default draw (draw(s, n) with no piles): the deck into the hand, the bag into the pot */
  draw?: { from: P; to: P };
  /** When a draw finds a pile empty, the pile named here is shuffled into it first: { draw: 'discard' } */
  reshuffle?: Partial<Record<P, P>>;
  /** The most items a pile holds (a hand of 10): a draw into a full pile stops */
  limit?: Partial<Record<P, number>>;
  /** What kind an item is, for counts() (default: a string item itself, else item.kind, else item.id) */
  kind?: (item: T) => string;
  /** Push your luck: the pile is bust when `when` says so (Quacks: the white chips in the pot add up past 7) */
  bust?: { pile: P; when: (items: readonly T[]) => boolean };
  /** Market rows: a pile with slots, refilled from another pile; price() says what a slot costs */
  markets?: Partial<Record<P, MarketDef<P>>>;
  /** The price of the item in a market slot (default 0): `base + slot` for a row that gets cheaper as it slides */
  price?: (item: T, slot: number, pile: P) => number;
  /** A loaded item is kept only if this says so (sanitize); default: anything but undefined */
  valid?: (item: unknown) => item is T;
}

/** The last draw: what undoDraw() puts back */
export interface ZoneDraw<P extends string> {
  from: P;
  to: P;
  /** Items drawn (they are the last `n` of the `to` pile) */
  n: number;
  /** The index each one came from, in order */
  at: number[];
}

/** The whole state of the piles: plain JSON, a mid-run save as it is */
export interface ZonesState<T, P extends string> {
  piles: Record<P, T[]>;
  /** The rng's position (seededRng(state.rng) goes on from here) */
  rng: number;
  /** The last draw, for undoDraw(); null after any other change */
  last: ZoneDraw<P> | null;
}

const isInt = (n: unknown): n is number => typeof n === 'number' && Number.isSafeInteger(n);

function defaultKind(item: unknown): string {
  if (typeof item === 'string' || typeof item === 'number') return String(item);
  if (item && typeof item === 'object') {
    const o = item as { kind?: unknown; id?: unknown };
    if (typeof o.kind === 'string') return o.kind;
    if (typeof o.id === 'string' || typeof o.id === 'number') return String(o.id);
  }
  return JSON.stringify(item);
}

/** Fisher–Yates with the given rng (in place) */
function shuffleIn<T>(list: T[], r: SeededRng): void {
  for (let i = list.length - 1; i > 0; i--) {
    const j = r.int(i + 1);
    [list[i], list[j]] = [list[j], list[i]];
  }
}

/**
 * The piles of a card, bag or tile game: draw, shuffle, move, a blind bag with counts, market rows, a bust rule and its
 * odds, and an undo of the last draw (the rewarded "second chance"). The object holds the rules; every method takes a
 * state and returns a new one (or null when the move isn't possible), so an UndoHistory of states is the undo stack.
 */
export class Zones<T, P extends string = string> {
  readonly def: ZonesDef<T, P>;
  private readonly blind: Set<P>;

  constructor(def: ZonesDef<T, P>) {
    if (!def.piles.length) throw new Error('zones: at least one pile');
    const known = new Set<P>();
    for (const p of def.piles) {
      if (!p || known.has(p)) throw new Error(`zones: pile "${p}" is empty or twice`);
      known.add(p);
    }
    const check = (p: P | undefined, what: string) => {
      if (p !== undefined && !known.has(p)) throw new Error(`zones: ${what} names unknown pile "${p}"`);
    };
    for (const p of def.blind ?? []) check(p, 'blind');
    check(def.draw?.from, 'draw.from');
    check(def.draw?.to, 'draw.to');
    for (const [a, b] of Object.entries(def.reshuffle ?? {}) as [P, P][]) {
      check(a, 'reshuffle');
      check(b, `reshuffle.${a}`);
      if (a === b) throw new Error(`zones: pile "${a}" can't reshuffle into itself`);
    }
    for (const [p, n] of Object.entries(def.limit ?? {}) as [P, number][]) {
      check(p, 'limit');
      if (!(isInt(n) && n >= 0)) throw new Error(`zones: limit.${p} must be an integer ≥ 0`);
    }
    check(def.bust?.pile, 'bust.pile');
    for (const [p, m] of Object.entries(def.markets ?? {}) as [P, MarketDef<P>][]) {
      check(p, 'markets');
      check(m.from, `markets.${p}.from`);
      check(m.decayTo, `markets.${p}.decayTo`);
      if (m.from === p) throw new Error(`zones: market "${p}" can't refill from itself`);
      if (!(isInt(m.slots) && m.slots >= 1)) throw new Error(`zones: markets.${p}.slots must be an integer ≥ 1`);
    }
    this.def = def;
    this.blind = new Set(def.blind ?? []);
  }

  // --- State ------------------------------------------------------------------------------------------------------

  /**
   * A new game: the piles' contents (missing piles empty), the seed (a run seed, a level number). Every pile something
   * is drawn from (draw.from, the reshuffle targets, the markets' supplies) is shuffled, then the markets are filled.
   */
  start(contents: Partial<Record<P, readonly T[]>>, seed: number): ZonesState<T, P> {
    const piles = this.emptyPiles();
    for (const p of this.def.piles) piles[p] = [...(contents[p] ?? [])];
    const r = seededRng(seed >>> 0);
    const sources = new Set<P>([...(this.def.draw ? [this.def.draw.from] : []), ...(Object.keys(this.def.reshuffle ?? {}) as P[]), ...Object.values(this.def.markets ?? {}).map((m) => (m as MarketDef<P>).from)]);
    for (const p of sources) if (!this.blind.has(p)) shuffleIn(piles[p], r);
    let s: ZonesState<T, P> = { piles, rng: r.state(), last: null };
    for (const m of Object.keys(this.def.markets ?? {}) as P[]) s = this.refill(s, m);
    return s;
  }

  /** A loaded state made safe: every pile an array of valid items, unknown piles dropped, the rng an integer */
  sanitize(raw: unknown, seed = 1): ZonesState<T, P> {
    const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
    const src = r.piles && typeof r.piles === 'object' ? (r.piles as Record<string, unknown>) : {};
    const valid = this.def.valid ?? ((x: unknown): x is T => x !== undefined);
    const piles = this.emptyPiles();
    for (const p of this.def.piles) piles[p] = Array.isArray(src[p]) ? (src[p] as unknown[]).filter(valid) : [];
    const rng = isInt(r.rng) && r.rng >= 0 && r.rng < 2 ** 32 ? r.rng : seed >>> 0;
    const l = r.last as Partial<ZoneDraw<P>> | null | undefined;
    const lastOk =
      !!l && this.def.piles.includes(l.from as P) && this.def.piles.includes(l.to as P) && isInt(l.n) && l.n >= 1 && Array.isArray(l.at) && l.at.length === l.n && l.at.every(isInt) && piles[l.to as P].length >= l.n;
    return { piles, rng, last: lastOk ? { from: l!.from as P, to: l!.to as P, n: l!.n!, at: [...l!.at!] } : null };
  }

  // --- Reading ----------------------------------------------------------------------------------------------------

  size(s: ZonesState<T, P>, pile: P): number {
    return s.piles[pile].length;
  }

  /** The top `n` of a pile (a scry, the market row); a blind pile has no top, so it shows nothing */
  peek(s: ZonesState<T, P>, pile: P, n = 1): T[] {
    return this.blind.has(pile) ? [] : s.piles[pile].slice(0, Math.max(0, n));
  }

  /** The items just drawn by the last draw (empty after anything else) */
  drawn(s: ZonesState<T, P>): T[] {
    return s.last ? s.piles[s.last.to].slice(-s.last.n) : [];
  }

  /** What a pile holds by kind, keys sorted: the bag's makeup the player is shown ({ cherry: 4, pumpkin: 2 }) */
  counts(s: ZonesState<T, P>, pile: P): Record<string, number> {
    const kind = this.def.kind ?? defaultKind;
    const out: Record<string, number> = {};
    for (const it of s.piles[pile]) {
      const k = kind(it);
      out[k] = (out[k] ?? 0) + 1;
    }
    return Object.fromEntries(Object.keys(out).sort().map((k) => [k, out[k]]));
  }

  /** The chance the next draw from `pile` matches (0 for an empty pile): what the player can know, never the order */
  odds(s: ZonesState<T, P>, pile: P, match: (item: T) => boolean): number {
    const from = this.source(s, pile);
    return from.length ? from.filter(match).length / from.length : 0;
  }

  /** The chance at least one of the next `n` draws from `pile` matches (without replacement; no reshuffle counted) */
  chanceWithin(s: ZonesState<T, P>, pile: P, match: (item: T) => boolean, n: number): number {
    const from = this.source(s, pile);
    const N = from.length;
    const K = from.filter(match).length;
    const draws = Math.min(Math.max(0, Math.floor(n)), N);
    if (!K || !draws) return 0;
    let miss = 1;
    for (let i = 0; i < draws; i++) miss *= (N - K - i) / (N - i);
    return 1 - Math.max(0, miss);
  }

  /** Is the bust pile bust now */
  busted(s: ZonesState<T, P>): boolean {
    const b = this.def.bust;
    return !!b && b.when(s.piles[b.pile]);
  }

  /**
   * The chance of going bust within the next `draws` draws (default 1) from `from` (default draw.from) into the bust
   * pile — the number for the risk meter. Exact (every order of draws, without replacement), so keep `draws` small (≤ 4).
   * 1 when already bust, 0 with nothing to draw.
   */
  bustChance(s: ZonesState<T, P>, draws = 1, from: P | undefined = this.def.draw?.from): number {
    const b = this.def.bust;
    if (!b || from === undefined) return 0;
    const pot = s.piles[b.pile];
    if (b.when(pot)) return 1;
    const bag = this.source(s, from);
    const go = (pot: readonly T[], left: readonly T[], k: number): number => {
      if (k <= 0 || !left.length) return 0;
      // Identical items give the same branch: group them (JSON is the identity of a plain item)
      const groups = new Map<string, { item: T; i: number; n: number }>();
      left.forEach((item, i) => {
        const key = JSON.stringify(item) ?? String(i);
        const g = groups.get(key);
        if (g) g.n++;
        else groups.set(key, { item, i, n: 1 });
      });
      let p = 0;
      for (const g of groups.values()) {
        const next = [...pot, g.item];
        const w = g.n / left.length;
        if (b.when(next)) p += w;
        else if (k > 1) p += w * go(next, [...left.slice(0, g.i), ...left.slice(g.i + 1)], k - 1);
      }
      return p;
    };
    return go(pot, bag, Math.max(0, Math.floor(draws)));
  }

  /** What a market slot costs now (0 without a price rule; NaN for an empty slot) */
  price(s: ZonesState<T, P>, pile: P, slot: number): number {
    const it = s.piles[pile][slot];
    if (it === undefined) return NaN;
    return this.def.price ? this.def.price(it, slot, pile) : 0;
  }

  // --- Changes ------------------------------------------------------------------------------------------------------

  /**
   * Draw `n` items one at a time from `from` into `to` (default: def.draw). An empty `from` is first refilled from its
   * reshuffle pile (shuffled); a blind pile gives a random item. Stops early when both run dry, when `to` is full
   * (limit) or when the bust pile goes bust. The drawn items are drawn(next); undoDraw(next) puts them back.
   */
  draw(s: ZonesState<T, P>, n = 1, from: P | undefined = this.def.draw?.from, to: P | undefined = this.def.draw?.to): ZonesState<T, P> {
    if (from === undefined || to === undefined) throw new Error('zones: draw needs piles (or def.draw)');
    const piles = this.copyPiles(s);
    const r = seededRng(s.rng);
    const at: number[] = [];
    const cap = this.def.limit?.[to] ?? Infinity;
    for (let k = 0; k < n; k++) {
      if (piles[to].length >= cap) break;
      if (this.def.bust?.pile === to && this.def.bust.when(piles[to])) break;
      const got = this.pull(piles, from, r);
      if (!got) break;
      piles[to].push(got.item);
      at.push(got.at);
    }
    return { piles, rng: r.state(), last: at.length ? { from, to, n: at.length, at } : null };
  }

  /**
   * Undo the last draw: the rewarded "second chance" (take back the bust token, redraw a dead card). The items go back
   * where they came from; `shuffle` mixes them into a stacked pile so the next draw is a new chance (a bag always is).
   * The rng stays where it is — the next draw is not the same one again. null if the last change wasn't a draw.
   */
  undoDraw(s: ZonesState<T, P>, opts: { shuffle?: boolean } = {}): ZonesState<T, P> | null {
    const l = s.last;
    if (!l || s.piles[l.to].length < l.n) return null;
    const piles = this.copyPiles(s);
    const back = piles[l.to].splice(piles[l.to].length - l.n, l.n);
    for (let k = back.length - 1; k >= 0; k--) piles[l.from].splice(Math.min(l.at[k], piles[l.from].length), 0, back[k]);
    const r = seededRng(s.rng);
    if (opts.shuffle && !this.blind.has(l.from)) shuffleIn(piles[l.from], r);
    return { piles, rng: r.state(), last: null };
  }

  /** Move one item (by its index) to another pile; null for a bad index or a full pile */
  move(s: ZonesState<T, P>, from: P, index: number, to: P, place: ZonePlace = 'end'): ZonesState<T, P> | null {
    if (!isInt(index) || index < 0 || index >= s.piles[from].length) return null;
    if (from !== to && s.piles[to].length >= (this.def.limit?.[to] ?? Infinity)) return null;
    const piles = this.copyPiles(s);
    const [it] = piles[from].splice(index, 1);
    const r = seededRng(s.rng);
    this.put(piles[to], it, place, r);
    return { piles, rng: r.state(), last: null };
  }

  /** Move a whole pile (discard the hand, the pot back into the bag); 'shuffle' shuffles the pile it lands in */
  moveAll(s: ZonesState<T, P>, from: P, to: P, place: ZonePlace = 'end'): ZonesState<T, P> {
    if (from === to) return { ...s, piles: this.copyPiles(s), last: null };
    const piles = this.copyPiles(s);
    const moving = piles[from];
    piles[from] = [];
    const r = seededRng(s.rng);
    piles[to] = place === 'top' ? [...moving, ...piles[to]] : [...piles[to], ...moving];
    if (place === 'shuffle' && !this.blind.has(to)) shuffleIn(piles[to], r);
    return { piles, rng: r.state(), last: null };
  }

  /** A new item into a pile (a card bought, a curse, a token): 'shuffle' puts it at a random place */
  add(s: ZonesState<T, P>, item: T, to: P, place: ZonePlace = 'end'): ZonesState<T, P> {
    const piles = this.copyPiles(s);
    const r = seededRng(s.rng);
    this.put(piles[to], item, place, r);
    return { piles, rng: r.state(), last: null };
  }

  /** Take an item out of the game (a card removed at a shop); null for a bad index */
  remove(s: ZonesState<T, P>, pile: P, index: number): ZonesState<T, P> | null {
    if (!isInt(index) || index < 0 || index >= s.piles[pile].length) return null;
    const piles = this.copyPiles(s);
    piles[pile].splice(index, 1);
    return { piles, rng: s.rng, last: null };
  }

  shuffle(s: ZonesState<T, P>, pile: P): ZonesState<T, P> {
    const piles = this.copyPiles(s);
    const r = seededRng(s.rng);
    shuffleIn(piles[pile], r);
    return { piles, rng: r.state(), last: null };
  }

  /** Turn a stacked pile by `k` (a market ring: the pawn moves on, the passed items go to the back) */
  rotate(s: ZonesState<T, P>, pile: P, k: number): ZonesState<T, P> {
    const piles = this.copyPiles(s);
    const list = piles[pile];
    if (list.length) {
      const n = ((Math.floor(k) % list.length) + list.length) % list.length;
      piles[pile] = [...list.slice(n), ...list.slice(0, n)];
    }
    return { piles, rng: s.rng, last: null };
  }

  /**
   * Take the item in a market slot into `to` (pay price() first: the game owns the currency). The row then refills by
   * its rule: 'slide' moves the rest down and adds at the end, 'in-place' fills the same slot. null for an empty slot.
   */
  take(s: ZonesState<T, P>, market: P, slot: number, to: P, place: ZonePlace = 'end'): ZonesState<T, P> | null {
    const m = this.market(market);
    const moved = this.move(s, market, slot, to, place);
    if (!moved) return null;
    if ((m.refill ?? 'slide') === 'slide') return this.refill(moved, market);
    const piles = this.copyPiles(moved);
    const r = seededRng(moved.rng);
    const got = this.pull(piles, m.from, r);
    if (got) piles[market].splice(slot, 0, got.item);
    return { piles, rng: r.state(), last: null };
  }

  /** Fill a market row up to its slots from its supply (at the end) */
  refill(s: ZonesState<T, P>, market: P): ZonesState<T, P> {
    const m = this.market(market);
    const piles = this.copyPiles(s);
    const r = seededRng(s.rng);
    while (piles[market].length < m.slots) {
      const got = this.pull(piles, m.from, r);
      if (!got) break;
      piles[market].push(got.item);
    }
    return { piles, rng: r.state(), last: null };
  }

  /** The market decays: the item in slot 0 (the oldest) leaves (to decayTo, or out of the game), the row slides and refills */
  decay(s: ZonesState<T, P>, market: P): ZonesState<T, P> {
    const m = this.market(market);
    if (!s.piles[market].length) return this.refill(s, market);
    const piles = this.copyPiles(s);
    const [old] = piles[market].splice(0, 1);
    if (m.decayTo !== undefined) piles[m.decayTo].push(old);
    return this.refill({ piles, rng: s.rng, last: null }, market);
  }

  // --- Inside -------------------------------------------------------------------------------------------------------

  private emptyPiles(): Record<P, T[]> {
    return Object.fromEntries(this.def.piles.map((p) => [p, [] as T[]])) as Record<P, T[]>;
  }

  private copyPiles(s: ZonesState<T, P>): Record<P, T[]> {
    return Object.fromEntries(this.def.piles.map((p) => [p, [...(s.piles[p] ?? [])]])) as Record<P, T[]>;
  }

  private market(p: P): MarketDef<P> {
    const m = this.def.markets?.[p];
    if (!m) throw new Error(`zones: "${p}" is not a market`);
    return m;
  }

  /** What a draw from `pile` could give: the pile, or its reshuffle pile when it is empty */
  private source(s: ZonesState<T, P>, pile: P): readonly T[] {
    const own = s.piles[pile];
    const back = this.def.reshuffle?.[pile];
    return own.length || back === undefined ? own : s.piles[back];
  }

  /** One item off a pile (refilled from its reshuffle pile first if it is empty), and where it was; undefined when there is none */
  private pull(piles: Record<P, T[]>, from: P, r: SeededRng): { item: T; at: number } | undefined {
    if (!piles[from].length) {
      const back = this.def.reshuffle?.[from];
      if (back === undefined || !piles[back].length) return undefined;
      piles[from] = piles[back];
      piles[back] = [];
      if (!this.blind.has(from)) shuffleIn(piles[from], r);
    }
    const at = this.blind.has(from) ? r.int(piles[from].length) : 0;
    return { item: piles[from].splice(at, 1)[0], at };
  }

  private put(list: T[], it: T, place: ZonePlace, r: SeededRng): void {
    if (place === 'top') list.unshift(it);
    else if (place === 'shuffle') list.splice(r.int(list.length + 1), 0, it);
    else list.push(it);
  }
}
