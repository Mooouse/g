// A restock shop: a rotating stock that turns over every slot of the world clock, the same for every player in the same
// slot (Grow a Garden's seed shop every 5 minutes, Blox Fruits' dealer every 4 hours: docs/research/roblox-2026-10.md
// P1). Rarity weights, a world pity (every block of N restocks holds a rare), and a personal "restock now" the player
// earns with a rewarded ad (`restock`, a rewarded kind of its own in gp forecast). Pure: the clock is injected, the
// save keeps only the current slot's purchases; the countdown on screen is mountRestockTimer() (restock-ui.ts).
//
//   const clock = worldClock({ salt: 'storm-geodes', every: '5m' });
//   const shop = restockShop(save, { clock, slots: 4, pool: SEEDS,              // pool: { id, weight, price, rarity, stock }
//     rarities: ['common', 'rare', 'epic'], pity: { rarity: 'epic', within: 6 }, persist: () => host.save(save) });
//   shop.state();             // { slot, items: [{ id, price, rarity, stock, left }], nextIn: 192, personal: false, restock: { ready, in } }
//   shop.buy('frost-quartz', (price) => spend(price));   // the game takes the price: true → bought, the stock goes down
//   rewardedButton({ host, placement: 'restock', label: host.t('gp.restock.now'), onReward: () => shop.restockNow() });
//
// Rules (D56): a slot that passes takes nothing — what was not bought simply isn't offered any more, and the UI says
// what is coming ("New stock in 3:12"), never what was missed. Restocks are a good natural break: the player is between
// purchases (host.adBreak() on the way back into play, never on the shop button itself). A clock set back never offers a
// slot again (the stock stays the last one seen until the clock catches up); a personal restock is the player's own
// (state().personal: don't call it "the same for everyone").

import { durationMs, type ClockSlot, type Duration, type WorldClock } from './clock.ts';
import type { SaveHolder } from './streak.ts';

export interface StockDef<Id extends string = string> {
  id: Id;
  /** How often it is in stock (any positive numbers) */
  weight: number;
  /** Its price in the game's currency */
  price: number;
  /** Its rarity (one of `rarities`), for the pity and the glow */
  rarity?: string;
  /** How many a restock holds (default 1) */
  stock?: number;
}

export interface RestockOptions<Id extends string = string> {
  clock: WorldClock;
  /** A restock every … (default: the clock's slot) */
  every?: Duration;
  /** Offers per restock (distinct items) */
  slots: number;
  pool: readonly StockDef<Id>[];
  /** The rarities from the most common to the rarest: what "or better" means for the pity */
  rarities?: readonly string[];
  /** Every block of `within` restocks (aligned on the clock: the same blocks for everyone) holds at least one item of `rarity` or better */
  pity?: { rarity: string; within: number };
  /** A personal restock at most once per … (default '15m') */
  cooldown?: Duration;
  /** Names the shop's seed stream (two shops of one game differ): default 'shop' */
  name?: string;
  /** The save field (default 'restock') */
  key?: string;
  /** Called after every change of the field: `() => host.save(save)` */
  persist?: () => void;
}

export interface StockOffer<Id extends string = string> {
  id: Id;
  price: number;
  rarity: string | undefined;
  /** How many this restock holds, and how many are left to the player */
  stock: number;
  left: number;
  /** The pity put it there */
  pity: boolean;
}

export interface RestockState<Id extends string = string> {
  slot: ClockSlot;
  items: StockOffer<Id>[];
  /** Seconds until the next restock */
  nextIn: number;
  /** The player's own restock (restockNow): not the shared stock */
  personal: boolean;
  /** The personal restock: can it be offered now, and in how many seconds otherwise */
  restock: { ready: boolean; in: number };
  /** Restocks until the current pity block ends (this one included); null without a pity */
  pityIn: number | null;
}

export interface RestockLog {
  /** The slot index the purchases are for (-1: none yet) */
  slot: number;
  bought: Record<string, number>;
  /** Personal restocks in this slot */
  own: number;
  /** When the last personal restock was taken (ms, 0 never) */
  at: number;
}

export interface RestockShop<Id extends string = string> {
  state(): RestockState<Id>;
  /** Buy one: `pay(price)` takes the price and says whether it could (omit it for a free item); the offer after, or null */
  buy(id: Id, pay?: (price: number) => boolean): StockOffer<Id> | null;
  /** A personal restock right now (the reward of the `restock` placement): false while it cools down */
  restockNow(): boolean;
  /** The stock of any slot index (the shared one): a preview, a test, a bot */
  stockAt(index: number): StockOffer<Id>[];
  readonly log: RestockLog;
}

const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

/** The saved field made safe */
export function loadRestock(saved: unknown): RestockLog {
  const s = record(saved);
  const n = (v: unknown, d: number) => (typeof v === 'number' && Number.isFinite(v) ? Math.floor(v) : d);
  const bought = Object.fromEntries(Object.entries(record(s.bought)).flatMap(([k, v]) => (typeof v === 'number' && v > 0 ? [[k, Math.floor(v)]] : [])));
  return { slot: n(s.slot, -1), bought, own: Math.max(0, n(s.own, 0)), at: Math.max(0, n(s.at, 0)) };
}

/** The restock shop over `save[key]`: see the module's comment */
export function restockShop<Id extends string>(save: SaveHolder, opts: RestockOptions<Id>): RestockShop<Id> {
  const pool = opts.pool.filter((p) => p.weight > 0);
  if (!pool.length) throw new Error('restockShop: no item with a weight above 0');
  if (new Set(opts.pool.map((p) => p.id)).size !== opts.pool.length) throw new Error('restockShop: an item id twice');
  if (!(Number.isInteger(opts.slots) && opts.slots >= 1)) throw new Error('restockShop: slots is a whole number ≥ 1');
  const rarities = opts.rarities ?? [];
  for (const p of opts.pool) if (p.rarity !== undefined && rarities.length && !rarities.includes(p.rarity)) throw new Error(`restockShop: ${p.id} has the unknown rarity '${p.rarity}'`);
  const pity = opts.pity;
  const rank = (r: string | undefined) => (r === undefined ? -1 : rarities.length ? rarities.indexOf(r) : r === pity?.rarity ? 0 : -1);
  const pityRank = pity ? (rarities.length ? rarities.indexOf(pity.rarity) : 0) : 0;
  if (pity) {
    if (rarities.length && pityRank < 0) throw new Error(`restockShop: the pity rarity '${pity.rarity}' is not in rarities`);
    if (!(Number.isInteger(pity.within) && pity.within >= 1)) throw new Error('restockShop: pity.within is a whole number ≥ 1');
    if (!pool.some((p) => rank(p.rarity) >= pityRank)) throw new Error(`restockShop: no item of the pity rarity '${pity.rarity}' or better`);
  }
  const good = (p: StockDef<Id>) => !!pity && rank(p.rarity) >= pityRank;
  const clock = opts.clock;
  const len = opts.every === undefined ? clock.everyMs : durationMs(opts.every);
  if (!(len >= 60000)) throw new Error('restockShop: a restock every 1 minute or more');
  const cooldown = durationMs(opts.cooldown ?? '15m');
  const name = opts.name ?? 'shop';
  const key = opts.key ?? 'restock';
  const holder = save as Record<string, unknown>;
  const log = loadRestock(holder[key]);
  holder[key] = log;
  const persist = () => opts.persist?.();
  const count = Math.min(opts.slots, pool.length);

  /** `count` distinct items by weight */
  const draw = (r: () => number): StockDef<Id>[] => {
    const left = [...pool];
    const out: StockDef<Id>[] = [];
    while (out.length < count && left.length) {
      const sum = left.reduce((a, p) => a + p.weight, 0);
      let x = r() * sum;
      let i = left.length - 1;
      for (let k = 0; k < left.length; k++) if ((x -= left[k].weight) < 0) {
        i = k;
        break;
      }
      out.push(left.splice(i, 1)[0]);
    }
    return out;
  };
  const offer = (p: StockDef<Id>, byPity: boolean): StockOffer<Id> => {
    const stock = Math.max(1, Math.floor(p.stock ?? 1));
    return { id: p.id, price: p.price, rarity: p.rarity, stock, left: stock, pity: byPity };
  };
  const raw = (index: number) => draw(clock.rng(name, index));
  const cache = new Map<number, StockOffer<Id>[]>();
  /** The shared stock of a slot, with the world pity of its block */
  const shared = (index: number): StockOffer<Id>[] => {
    const hit = cache.get(index);
    if (hit) return hit;
    const items = raw(index);
    let out = items.map((p) => offer(p, false));
    if (pity && !items.some(good)) {
      const block = Math.floor(index / pity.within);
      const first = block * pity.within;
      const pos = first + clock.rng(`${name}:pity`, block).int(pity.within);
      let blockHas = false;
      for (let k = first; k < first + pity.within && !blockHas; k++) blockHas = k !== index && raw(k).some(good);
      if (index === pos && !blockHas) {
        const r = clock.rng(`${name}:pity-item`, index);
        const cands = pool.filter((p) => good(p) && !items.includes(p));
        const sum = cands.reduce((a, p) => a + p.weight, 0);
        let x = r() * sum;
        let pick = cands[cands.length - 1];
        for (const p of cands) if ((x -= p.weight) < 0) {
          pick = p;
          break;
        }
        // The guaranteed one takes the place of the commonest offer
        let low = 0;
        items.forEach((p, i) => (rank(p.rarity) < rank(items[low].rarity) ? (low = i) : 0));
        out = items.map((p, i) => (i === low ? offer(pick, true) : offer(p, false)));
      }
    }
    if (cache.size > 16) cache.delete(cache.keys().next().value as number);
    cache.set(index, out);
    return out;
  };

  /** The slot the player is in: the clock's, never one before the last seen (a clock set back) */
  const current = (): { s: ClockSlot; t: number } => {
    const t = clock.now();
    let s = clock.slot(len / 1000, t);
    if (log.slot > s.index) {
      s = clock.slot(len / 1000, log.slot * len);
      s = { ...s, nextIn: Math.max(0, Math.ceil((s.end - t) / 1000)) };
    }
    if (log.slot !== s.index) {
      Object.assign(log, { slot: s.index, bought: {}, own: 0 });
      persist();
    }
    return { s, t };
  };
  const items = (s: ClockSlot): StockOffer<Id>[] => {
    const base = log.own > 0 ? draw(clock.rng(`${name}:own:${log.own}`, s.index)).map((p) => offer(p, false)) : shared(s.index);
    return base.map((o) => ({ ...o, left: Math.max(0, o.stock - (log.bought[o.id] ?? 0)) }));
  };
  const restockIn = (t: number) => {
    if (!log.at) return 0;
    // A last restock dated in the future (the clock set back): wait the cooldown from it, never a free one
    return Math.max(0, Math.ceil((log.at + cooldown - t) / 1000));
  };

  current();
  return {
    log,
    state() {
      const { s, t } = current();
      const wait = restockIn(t);
      return {
        slot: s,
        items: items(s),
        nextIn: s.nextIn,
        personal: log.own > 0,
        restock: { ready: wait === 0, in: wait },
        pityIn: pity ? pity.within - (s.index % pity.within) : null,
      };
    },
    buy(id, pay) {
      const { s } = current();
      const o = items(s).find((x) => x.id === id);
      if (!o || o.left <= 0) return null;
      if (pay && !pay(o.price)) return null;
      log.bought[id] = (log.bought[id] ?? 0) + 1;
      persist();
      return { ...o, left: o.left - 1 };
    },
    restockNow() {
      const { t } = current();
      if (restockIn(t) > 0) return false;
      log.own++;
      log.bought = {};
      log.at = t;
      persist();
      return true;
    },
    stockAt: (index) => shared(Math.floor(index)).map((o) => ({ ...o })),
  };
}
