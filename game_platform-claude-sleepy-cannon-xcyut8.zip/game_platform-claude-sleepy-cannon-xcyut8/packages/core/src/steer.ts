// @gp/core/steer — 2D steering for a game's enemies, pure and deterministic: seek, flee, arrive, pursuit with a lead,
// separation, circle obstacle avoidance, golden-angle slots round a target and a flank point. The behaviours return a
// force (a change of velocity per second); the game's sim adds the ones it wants, weighted, and integrates them with
// `integrate()` (a force is a change of velocity per second, as yuka's with mass 1: a weight is its responsiveness).
// Nothing is kept between steps and nothing is random, so a seeded run replays exactly and a balance
// bot plays whole runs in Node.
//
// Frankengun (game22) took these from yuka (62 KB raw) and used them as forces only, through scratch vehicles; this is
// the same maths without the library. A 3D game on a floor passes x and z as x and y.
//
//   const f = { x: 0, y: 0 };
//   add(f, avoid(me, pillars, 2.5, speed), 3);                 // weights: avoidance first, as Frankengun's 3
//   add(f, separation(me, near, 1.6), 1.6);
//   add(f, mode === 'surround' ? arrive(me, around(player, slot(me.id, reach)), speed, 2.2) : pursue(me, player, speed, 0.6));
//   integrate(me, f, dt, speed, speed * 6);                   // me.vx/vy updated, at most `speed`; the sim moves me

export interface Vec {
  x: number;
  y: number;
}

/** Something that moves: its position and velocity (units/s); r — its radius, for avoidance and separation */
export interface Mover extends Vec {
  vx: number;
  vy: number;
  r?: number;
}

/** A circle that blocks: a pillar, a crate, the boss */
export interface Circle extends Vec {
  r: number;
}

/** The golden angle (radians): ids 0, 1, 2 … spread evenly round a circle, never two on the same spot */
export const GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));

const v = (x = 0, y = 0): Vec => ({ x, y });
const set = (o: Vec, x: number, y: number): Vec => ((o.x = x), (o.y = y), o);

/** f += g × weight (in place); returns f */
export function add(f: Vec, g: Vec, weight = 1): Vec {
  f.x += g.x * weight;
  f.y += g.y * weight;
  return f;
}

/** The vector cut to at most `max` long (in place) */
export function truncate(f: Vec, max: number): Vec {
  const l = Math.hypot(f.x, f.y);
  if (l > max && l > 0) set(f, (f.x / l) * max, (f.y / l) * max);
  return f;
}

/**
 * Apply a steering force for one step: the velocity changes by the force (cut to `maxForce`) × dt and is cut to
 * `maxSpeed`. The position is the sim's to move (it may collide): `m.x += m.vx * dt` after this
 */
export function integrate(m: Mover, force: Vec, dt: number, maxSpeed: number, maxForce = Infinity): Mover {
  let fx = force.x;
  let fy = force.y;
  const fl = Math.hypot(fx, fy);
  if (fl > maxForce) (fx *= maxForce / fl), (fy *= maxForce / fl);
  m.vx += fx * dt;
  m.vy += fy * dt;
  const s = Math.hypot(m.vx, m.vy);
  if (s > maxSpeed) (m.vx *= maxSpeed / s), (m.vy *= maxSpeed / s);
  return m;
}

/** Toward a point at full speed: the desired velocity minus the current one */
export function seek(m: Mover, target: Vec, maxSpeed: number, out: Vec = v()): Vec {
  const dx = target.x - m.x;
  const dy = target.y - m.y;
  const d = Math.hypot(dx, dy);
  if (d < 1e-9) return set(out, -m.vx, -m.vy);
  return set(out, (dx / d) * maxSpeed - m.vx, (dy / d) * maxSpeed - m.vy);
}

/** Away from a point at full speed; nothing (zero) once it is farther than `panic` */
export function flee(m: Mover, threat: Vec, maxSpeed: number, panic = Infinity, out: Vec = v()): Vec {
  const dx = m.x - threat.x;
  const dy = m.y - threat.y;
  const d = Math.hypot(dx, dy);
  if (d > panic) return set(out, 0, 0);
  // On top of it: away along the current heading (or +x), never NaN
  const [ux, uy] = d > 1e-9 ? [dx / d, dy / d] : unit(m.vx, m.vy);
  return set(out, ux * maxSpeed - m.vx, uy * maxSpeed - m.vy);
}

/**
 * Toward a point, slowing down inside `slow`. A force is a change of velocity per second (yuka's, mass 1): weighted 1 it
 * eases in late and sways round the point; weighted ≈ 4 × maxSpeed / slow (and a maxForce that lets it) it stops on it
 */
export function arrive(m: Mover, target: Vec, maxSpeed: number, slow: number, out: Vec = v()): Vec {
  const dx = target.x - m.x;
  const dy = target.y - m.y;
  const d = Math.hypot(dx, dy);
  if (d < 1e-6) return set(out, -m.vx, -m.vy);
  const speed = slow > 0 ? Math.min(maxSpeed, (maxSpeed * d) / slow) : maxSpeed;
  return set(out, (dx / d) * speed - m.vx, (dy / d) * speed - m.vy);
}

/**
 * Where a moving target will be: its position plus its velocity × the time to reach it at `speed` (+ its own), × `lead`
 * (0: where it is, 1: the full prediction), at most `maxLead` seconds ahead
 */
export function predict(m: Vec, prey: Mover, speed: number, lead = 1, maxLead = 2, out: Vec = v()): Vec {
  const d = Math.hypot(prey.x - m.x, prey.y - m.y);
  const ps = Math.hypot(prey.vx, prey.vy);
  const t = Math.min(maxLead, (d / Math.max(1e-6, speed + ps)) * lead);
  return set(out, prey.x + prey.vx * t, prey.y + prey.vy * t);
}

/** Toward where the prey is going (yuka's PursuitBehavior: `lead` its predictionFactor) */
export function pursue(m: Mover, prey: Mover, maxSpeed: number, lead = 1, out: Vec = v()): Vec {
  const p = predict(m, prey, maxSpeed, lead, 2, out);
  return seek(m, p, maxSpeed, out);
}

/**
 * Away from the neighbours closer than `radius`, each pushing by 1/distance (the closer, the harder); skips itself.
 * Two on exactly the same spot are told apart by their `id` (the lower one goes −x), so they part, deterministically
 */
export function separation(m: Mover & { id?: number }, neighbours: readonly (Vec & { id?: number })[], radius: number, out: Vec = v()): Vec {
  set(out, 0, 0);
  const r2 = radius * radius;
  for (const o of neighbours) {
    if (o === m) continue;
    const dx = m.x - o.x;
    const dy = m.y - o.y;
    const d2 = dx * dx + dy * dy;
    if (d2 >= r2) continue;
    if (d2 < 1e-12) {
      // Exactly on top of each other: a nudge apart by id (deterministic, never NaN)
      out.x += ((m.id ?? 0) < (o.id ?? 0) ? -1 : 1) / radius;
      continue;
    }
    // (dx, dy) / d² = the unit vector / d
    out.x += dx / d2;
    out.y += dy / d2;
  }
  return out;
}

/**
 * Round the circles ahead: a box `lookAhead` long (longer with speed, as yuka's dBoxMinLength) along the heading, as
 * wide as the mover plus half its radius of clearance; the nearest circle that crosses it pushes sideways — up to
 * 2 × maxSpeed a second, harder the closer and the more it is in the way — and brakes a fifth of that. Zero when
 * nothing is in the way or the mover stands still. Weight it first and heaviest (Frankengun: 3 to pursuit's 1)
 */
export function avoid(m: Mover, obstacles: readonly Circle[], lookAhead: number, maxSpeed: number, out: Vec = v()): Vec {
  set(out, 0, 0);
  const speed = Math.hypot(m.vx, m.vy);
  if (speed < 1e-6) return out;
  const hx = m.vx / speed;
  const hy = m.vy / speed;
  const len = lookAhead + (speed / Math.max(1e-6, maxSpeed)) * lookAhead;
  const mr = (m.r ?? 0) * 1.5;
  let best: { ahead: number; side: number; r: number } | null = null;
  for (const o of obstacles) {
    const dx = o.x - m.x;
    const dy = o.y - m.y;
    // In the mover's frame: ahead along the heading, side to its left (+) / right (−)
    const ahead = dx * hx + dy * hy;
    const side = -dx * hy + dy * hx;
    const reach = o.r + mr;
    if (ahead < -reach || ahead > len + reach || Math.abs(side) >= reach) continue;
    if (!best || ahead < best.ahead) best = { ahead, side, r: reach };
  }
  if (!best) return out;
  // The closer, the harder (1…2); the more in the way, the harder (0…1); away from the circle's side (dead ahead: to the right)
  const k = 1 + (len - Math.max(0, Math.min(len, best.ahead))) / len;
  const lateral = (1 - Math.abs(best.side) / best.r) * k * maxSpeed * (best.side > 0 ? -1 : best.side < 0 ? 1 : -1);
  // A brake as strong as the circle is in the way (yuka's brakingWeight 0.2): none once it only passes beside
  const brake = 0.2 * Math.abs(lateral);
  // Back into the world frame: lateral along the left normal (−hy, hx), the brake against the heading
  out.x = -hy * lateral - hx * brake;
  out.y = hx * lateral - hy * brake;
  return out;
}

/** A slot of its own round a target: the golden angle × id, at `radius` (an offset: add the target's position, `around()`) */
export function slot(id: number, radius: number, out: Vec = v(), turn = 0): Vec {
  const a = id * GOLDEN_ANGLE + turn;
  return set(out, Math.cos(a) * radius, Math.sin(a) * radius);
}

/** A point at an offset from a target (a slot round the player) */
export function around(target: Vec, offset: Vec, out: Vec = v()): Vec {
  return set(out, target.x + offset.x, target.y + offset.y);
}

/**
 * A flank point: beside the target at `range`, on the side it isn't looking at. `facing` is the direction it looks
 * (radians, atan2(y, x)); `side` +1 its left, −1 its right (by id: `id & 1 ? 1 : -1`), `back` 0 square beside it … 1
 * straight behind it
 */
export function flank(target: Vec, facing: number, range: number, side: 1 | -1, back = 0.25, out: Vec = v()): Vec {
  const a = facing + side * (Math.PI / 2 + back * (Math.PI / 2));
  return set(out, target.x + Math.cos(a) * range, target.y + Math.sin(a) * range);
}

/** A heading as a unit vector (+x when it stands still) */
function unit(x: number, y: number): [number, number] {
  const l = Math.hypot(x, y);
  return l > 1e-9 ? [x / l, y / l] : [1, 0];
}
