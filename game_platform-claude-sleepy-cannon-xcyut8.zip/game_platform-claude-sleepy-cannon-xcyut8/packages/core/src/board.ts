// Board: square and hex grids for tile, polyomino, pattern and inventory games — cells with tags, pieces of any shape
// that turn and flip, legal placements, matching edges (Dorfromantik, Carcassonne), connected regions, adjacency and
// star cells (Backpack Hero; Swarm Smash's ship and Frankengun's part grid), and a small pattern matcher with partial
// progress for hints (Cascadia, Harmonies). docs/research/board-games-2026-10.md §1.6, §1.7, §1.11 (block #2).
//
// Pure and save-safe like Zones: a Board object holds the geometry and the rules, the state is plain JSON (the pieces,
// the cells' tags, the next piece id) — saved as it is, sanitize()d on load, and every change returns a new state, so
// an UndoHistory of states is the undo. No randomness (a tile stack is a Zones pile).
//
//   const pack = new Board<Item>({ size: [5, 4], shapeOf: (it) => ITEMS[it.id].shape, turn: true });
//   let s = pack.start();
//   s = pack.place(s, { id: 'sword' }, [0, 0], 1)!;      // orientation 1: a quarter turn clockwise
//   pack.whyNot(s, { id: 'shield' }, [0, 0]);              // 'taken' — what the drag preview says
//   pack.pairs(s, (a, b) => a.item.id === 'whetstone' && b.item.id === 'sword'); // the synergies lit
//
// Coordinates are [x, y] with y down. A hex board uses axial [q, r] (pointy-top, r down); its six directions run
// clockwise from east. An orientation `o` is a number of clockwise turns (0–3 square, 0–5 hex), plus 4 (or 6) when
// mirrored. A piece's `at` is the corner of its turned shape (the smallest x and y of its cells).

export type Pos = readonly [number, number];
export type XY = [number, number];
export type GridKind = 'square' | 'hex';

/** A shape: its cells, and star cells (where its effect reaches) that turn with it */
export interface ShapeDef {
  cells: readonly Pos[];
  stars?: readonly Pos[];
}

/** A shape turned to one orientation, moved to its corner */
export interface Oriented {
  o: number;
  cells: XY[];
  stars: XY[];
}

export interface Piece<I> {
  uid: number;
  item: I;
  at: XY;
  /** Orientation (see the header) */
  o: number;
}

export interface BoardState<I> {
  pieces: Piece<I>[];
  /** Each cell's tags by key "x,y" (terrain, a star, 'off' for a cell that isn't on the board) */
  tags: Record<string, string[]>;
  /** The next piece's uid */
  uid: number;
}

/** What a pattern test or a region test sees of a cell */
export interface CellView<I> {
  pos: XY;
  piece: Piece<I> | null;
  tags: readonly string[];
}

export interface Pattern<I> {
  /** The pattern's cells, relative ([0,0],[1,0] — two side by side) */
  cells: readonly Pos[];
  /** Does a cell fit the pattern's i-th cell */
  test: (cell: CellView<I>, i: number) => boolean;
  /** Try every turn (default true) and mirror (default false) */
  turn?: boolean;
  flip?: boolean;
}

export interface PatternMatch {
  cells: XY[];
  /** Cells that fit now */
  matched: number;
  /** Empty cells still to fill to complete it (progress() only) */
  missing: XY[];
}

/** Why a piece can't go somewhere (null: it can) */
export type PlaceProblem = 'outside' | 'taken' | 'refused' | 'edge' | 'alone';

export interface BoardDef<I> {
  /** 'square' (default) or 'hex' */
  grid?: GridKind;
  /** A bounded board: [width, height] (square), or every cell listed; neither (and no radius) is an open board */
  size?: readonly [number, number];
  /** A hex board of this radius around [0, 0] */
  radius?: number;
  cells?: readonly Pos[];
  /** Square boards: diagonals count as neighbours (8, not 4) for adjacency and regions */
  diagonal?: boolean;
  /** An item's shape (default one cell) */
  shapeOf?: (item: I) => ShapeDef;
  /** Items turn (default true) and mirror (default false) */
  turn?: boolean;
  flip?: boolean;
  /** One-cell tiles: an edge label per direction (square N E S W, hex E SE SW W NW NE) at orientation 0 */
  edgesOf?: (item: I) => readonly string[];
  /** Do two facing edges fit (default: the same label) */
  match?: (a: string, b: string) => boolean;
  /** With edgesOf: a mismatched edge forbids the placement (default true — false scores it instead, as Dorfromantik) */
  strictEdges?: boolean;
  /** A new piece must touch one already down (tile laying); the first goes anywhere */
  touch?: boolean;
  /** The cell rule: can `item` lie on a cell with these tags (default: yes) */
  accepts?: (item: I, pos: XY, tags: readonly string[]) => boolean;
}

export const SQUARE_DIRS: readonly Pos[] = [[0, -1], [1, 0], [0, 1], [-1, 0]];
export const SQUARE_DIAGONALS: readonly Pos[] = [[1, -1], [1, 1], [-1, 1], [-1, -1]];
export const HEX_DIRS: readonly Pos[] = [[1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1]];
/** The tag that takes a cell off the board (a ship's hull grows by untagging) */
export const OFF = 'off';

export const posKey = (p: Pos): string => `${p[0]},${p[1]}`;
export const keyPos = (k: string): XY => {
  const [x, y] = k.split(',').map(Number);
  return [x, y];
};
const add = (a: Pos, b: Pos): XY => [a[0] + b[0], a[1] + b[1]];
const isInt = (n: unknown): n is number => typeof n === 'number' && Number.isSafeInteger(n);

// --- Shapes ---------------------------------------------------------------------------------------------------------

/** The named polyominoes (square grids): the monomino to the tetrominoes, and the pentominoes puzzle games use most */
export const POLYOMINOES: Record<string, readonly Pos[]> = {
  I1: [[0, 0]],
  I2: [[0, 0], [1, 0]],
  I3: [[0, 0], [1, 0], [2, 0]],
  L3: [[0, 0], [0, 1], [1, 1]],
  I4: [[0, 0], [1, 0], [2, 0], [3, 0]],
  O4: [[0, 0], [1, 0], [0, 1], [1, 1]],
  T4: [[0, 0], [1, 0], [2, 0], [1, 1]],
  S4: [[1, 0], [2, 0], [0, 1], [1, 1]],
  Z4: [[0, 0], [1, 0], [1, 1], [2, 1]],
  L4: [[0, 0], [0, 1], [0, 2], [1, 2]],
  J4: [[1, 0], [1, 1], [1, 2], [0, 2]],
  I5: [[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]],
  L5: [[0, 0], [0, 1], [0, 2], [0, 3], [1, 3]],
  P5: [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2]],
  T5: [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2]],
  U5: [[0, 0], [2, 0], [0, 1], [1, 1], [2, 1]],
  V5: [[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]],
  X5: [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]],
};

/** A shape from a polyomino's name or a list of cells (and star cells) */
export function polyomino(cells: string | readonly Pos[], stars: readonly Pos[] = []): ShapeDef {
  const c = typeof cells === 'string' ? POLYOMINOES[cells] : cells;
  if (!c || !c.length) throw new Error(`polyomino: unknown shape ${String(cells)}`);
  return { cells: c, stars };
}

const turnsOf = (g: GridKind) => (g === 'hex' ? 6 : 4);

/** One position turned and mirrored by orientation `o` (mirror first, then the turns) */
export function orientPos(p: Pos, o: number, grid: GridKind = 'square'): XY {
  const n = turnsOf(grid);
  let [x, y] = p;
  if (Math.floor(o / n) % 2) [x, y] = grid === 'hex' ? [-x - y, y] : [-x, y];
  for (let i = 0; i < ((o % n) + n) % n; i++) [x, y] = grid === 'hex' ? [-y, x + y] : [-y, x];
  return [x + 0, y + 0];
}

/** A shape in orientation `o`, moved so its smallest x and y are 0 (its stars move with it) */
export function orient(shape: ShapeDef, o: number, grid: GridKind = 'square'): Oriented {
  const cells = shape.cells.map((p) => orientPos(p, o, grid));
  const stars = (shape.stars ?? []).map((p) => orientPos(p, o, grid));
  const mx = Math.min(...cells.map((c) => c[0]));
  const my = Math.min(...cells.map((c) => c[1]));
  const move = (l: XY[]) => l.map(([x, y]) => [x - mx, y - my] as XY);
  return { o, cells: move(cells), stars: move(stars) };
}

/** The distinct orientations of a shape (an O piece has one, an L eight with mirrors) */
export function orientations(shape: ShapeDef, opts: { grid?: GridKind; turn?: boolean; flip?: boolean } = {}): Oriented[] {
  const grid = opts.grid ?? 'square';
  const n = turnsOf(grid);
  const seen = new Set<string>();
  const out: Oriented[] = [];
  for (let o = 0; o < n * 2; o++) {
    if (o % n && opts.turn === false) continue;
    if (o >= n && !opts.flip) continue;
    const t = orient(shape, o, grid);
    const sig = [...t.cells.map(posKey).sort(), '|', ...t.stars.map(posKey).sort()].join(' ');
    if (seen.has(sig)) continue;
    seen.add(sig);
    out.push(t);
  }
  return out;
}

// --- The board ------------------------------------------------------------------------------------------------------

const ONE: ShapeDef = { cells: [[0, 0]] };

export class Board<I> {
  readonly def: BoardDef<I>;
  readonly grid: GridKind;
  readonly dirs: readonly Pos[];
  /** The board's cells when it is bounded (null: an open board) */
  private readonly bounded: Set<string> | null;

  constructor(def: BoardDef<I> = {}) {
    this.def = def;
    this.grid = def.grid ?? 'square';
    this.dirs = this.grid === 'hex' ? HEX_DIRS : SQUARE_DIRS;
    let cells: Pos[] | null = null;
    if (def.cells) cells = [...def.cells];
    else if (def.size) {
      const [w, h] = def.size;
      if (!(isInt(w) && isInt(h) && w > 0 && h > 0)) throw new Error('board: size must be two integers > 0');
      cells = [];
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) cells.push([x, y]);
    } else if (def.radius !== undefined) {
      if (this.grid !== 'hex' || !(isInt(def.radius) && def.radius >= 0)) throw new Error('board: radius is for a hex board, an integer ≥ 0');
      cells = [];
      const R = def.radius;
      for (let r = -R; r <= R; r++) for (let q = -R; q <= R; q++) if (Math.abs(q + r) <= R) cells.push([q, r]);
    }
    this.bounded = cells ? new Set(cells.map(posKey)) : null;
  }

  // --- State ------------------------------------------------------------------------------------------------------

  /** An empty board, with the cells' tags ({ "2,3": ['star'] }) */
  start(tags: Record<string, readonly string[]> = {}): BoardState<I> {
    return { pieces: [], tags: Object.fromEntries(Object.entries(tags).map(([k, v]) => [k, [...v]])), uid: 1 };
  }

  /** A loaded state made safe: pieces that no longer fit (outside, overlapping, refused) are dropped, uids made unique */
  sanitize(raw: unknown, valid: (item: unknown) => item is I = (x): x is I => x !== undefined): BoardState<I> {
    const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
    const tags: Record<string, string[]> = {};
    if (r.tags && typeof r.tags === 'object')
      for (const [k, v] of Object.entries(r.tags as Record<string, unknown>))
        if (/^-?\d+,-?\d+$/.test(k) && Array.isArray(v)) tags[k] = v.filter((t): t is string => typeof t === 'string');
    let s: BoardState<I> = { pieces: [], tags, uid: 1 };
    const seen = new Set<number>();
    for (const p of Array.isArray(r.pieces) ? (r.pieces as Partial<Piece<I>>[]) : []) {
      if (!p || !valid(p.item) || !Array.isArray(p.at) || !isInt(p.at[0]) || !isInt(p.at[1]) || !isInt(p.o)) continue;
      if (!isInt(p.uid) || p.uid < 1 || seen.has(p.uid)) continue;
      // a loaded map keeps its pieces in the order laid, but the touch rule isn't checked again
      if (this.problem(s, p.item, p.at as XY, p.o, -1, false)) continue;
      seen.add(p.uid);
      s = { ...s, pieces: [...s.pieces, { uid: p.uid, item: p.item, at: [p.at[0], p.at[1]], o: p.o }] };
    }
    const top = Math.max(0, ...s.pieces.map((p) => p.uid));
    return { ...s, uid: isInt(r.uid) && r.uid > top ? r.uid : top + 1 };
  }

  // --- Geometry ---------------------------------------------------------------------------------------------------

  /** Is the position a cell of the board (bounded, and not tagged 'off') */
  inside(s: BoardState<I>, p: Pos): boolean {
    if (this.bounded && !this.bounded.has(posKey(p))) return false;
    return !this.tagsAt(s, p).includes(OFF);
  }

  /** The positions next to `p` (4 or 8 square, 6 hex), on the board or not */
  neighbours(p: Pos): XY[] {
    const d = this.grid === 'square' && this.def.diagonal ? [...SQUARE_DIRS, ...SQUARE_DIAGONALS] : this.dirs;
    return d.map((v) => add(p, v));
  }

  /** Every position next to a set of cells, not in it */
  around(cells: readonly Pos[]): XY[] {
    const has = new Set(cells.map(posKey));
    const out = new Map<string, XY>();
    for (const c of cells) for (const n of this.neighbours(c)) if (!has.has(posKey(n))) out.set(posKey(n), n);
    return [...out.values()];
  }

  distance(a: Pos, b: Pos): number {
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    if (this.grid === 'hex') return (Math.abs(dx) + Math.abs(dy) + Math.abs(dx + dy)) / 2;
    return this.def.diagonal ? Math.max(Math.abs(dx), Math.abs(dy)) : Math.abs(dx) + Math.abs(dy);
  }

  /** The cells at exactly distance `r` (r = 0: the cell itself) */
  ring(p: Pos, r: number): XY[] {
    if (r <= 0) return [[p[0], p[1]]];
    const out: XY[] = [];
    for (let y = -r; y <= r; y++) for (let x = -r; x <= r; x++) if (this.distance([0, 0], [x, y]) === r) out.push(add(p, [x, y]));
    return out;
  }

  /** `n` steps from `p` in direction `dir` (an index into dirs), not counting `p` */
  line(p: Pos, dir: number, n: number): XY[] {
    const d = this.dirs[((dir % this.dirs.length) + this.dirs.length) % this.dirs.length];
    const out: XY[] = [];
    for (let i = 1; i <= n; i++) out.push([p[0] + d[0] * i, p[1] + d[1] * i]);
    return out;
  }

  /** The board's cells (bounded), or the cells in play on an open board (the pieces' and the ones next to them) */
  cells(s: BoardState<I>): XY[] {
    if (this.bounded) return [...this.bounded].map(keyPos).filter((p) => this.inside(s, p));
    const taken = s.pieces.flatMap((p) => this.cellsOf(p));
    if (!taken.length) return [[0, 0]];
    return [...taken, ...this.around(taken).filter((p) => this.inside(s, p))];
  }

  /** Free cells (bounded boards; an open board's free cells next to the pieces) */
  empty(s: BoardState<I>): XY[] {
    const occ = this.occupancy(s);
    return this.cells(s).filter((p) => !occ.has(posKey(p)));
  }

  tagsAt(s: BoardState<I>, p: Pos): readonly string[] {
    return s.tags[posKey(p)] ?? [];
  }

  /** Set a cell's tags (a new hull cell: tag(s, p, []); a cell off the board: tag(s, p, ['off'])) */
  tag(s: BoardState<I>, p: Pos, tags: readonly string[]): BoardState<I> {
    const next = { ...s.tags };
    if (tags.length) next[posKey(p)] = [...tags];
    else delete next[posKey(p)];
    return { ...s, pieces: [...s.pieces], tags: next };
  }

  // --- Pieces -----------------------------------------------------------------------------------------------------

  shapeOf(item: I): ShapeDef {
    return this.def.shapeOf?.(item) ?? ONE;
  }

  /** An item's shape in orientation `o` */
  oriented(item: I, o = 0): Oriented {
    return orient(this.shapeOf(item), o, this.grid);
  }

  /** The distinct orientations an item can take on this board (a one-cell tile's differ by its edges) */
  orientations(item: I): Oriented[] {
    const n = turnsOf(this.grid);
    const turn = this.def.turn ?? true;
    const flip = this.def.flip ?? false;
    const seen = new Set<string>();
    const out: Oriented[] = [];
    for (let o = 0; o < n * 2; o++) {
      if ((o % n && !turn) || (o >= n && !flip)) continue;
      const t = orient(this.shapeOf(item), o, this.grid);
      const edges = this.def.edgesOf ? this.dirs.map((_, d) => this.edge({ item, o }, d)) : [];
      const sig = [...t.cells.map(posKey).sort(), '|', ...t.stars.map(posKey).sort(), '|', ...edges].join(' ');
      if (seen.has(sig)) continue;
      seen.add(sig);
      out.push(t);
    }
    return out;
  }

  /** The cells a piece covers (or would, at `at` in orientation `o`) */
  cellsOf(p: { item: I; at: Pos; o: number }): XY[] {
    return this.oriented(p.item, p.o).cells.map((c) => add(p.at, c));
  }

  /** Which piece covers each cell, by key */
  occupancy(s: BoardState<I>): Map<string, number> {
    const occ = new Map<string, number>();
    for (const p of s.pieces) for (const c of this.cellsOf(p)) occ.set(posKey(c), p.uid);
    return occ;
  }

  piece(s: BoardState<I>, uid: number): Piece<I> | null {
    return s.pieces.find((p) => p.uid === uid) ?? null;
  }

  pieceAt(s: BoardState<I>, p: Pos): Piece<I> | null {
    const uid = this.occupancy(s).get(posKey(p));
    return uid === undefined ? null : this.piece(s, uid);
  }

  /**
   * Why `item` can't lie at `at` in orientation `o` — 'outside' the board, a cell 'taken', a cell rule 'refused', an
   * 'edge' that doesn't fit, 'alone' (it must touch a piece) — or null when it can. `ignore` is the uid of a piece being
   * moved (its own cells are free).
   */
  whyNot(s: BoardState<I>, item: I, at: Pos, o = 0, ignore = -1): PlaceProblem | null {
    return this.problem(s, item, at, o, ignore, true);
  }

  private problem(s: BoardState<I>, item: I, at: Pos, o: number, ignore: number, touch: boolean): PlaceProblem | null {
    const cells = this.cellsOf({ item, at, o });
    const occ = this.occupancy(s);
    for (const c of cells) if (!this.inside(s, c)) return 'outside';
    for (const c of cells) {
      const u = occ.get(posKey(c));
      if (u !== undefined && u !== ignore) return 'taken';
    }
    if (this.def.accepts) for (const c of cells) if (!this.def.accepts(item, c, this.tagsAt(s, c))) return 'refused';
    if (this.def.edgesOf && (this.def.strictEdges ?? true) && this.fit(s, item, at, o, ignore).mismatched > 0) return 'edge';
    if (this.def.touch && touch) {
      const others = s.pieces.filter((p) => p.uid !== ignore);
      if (others.length) {
        const mine = new Set(cells.map(posKey));
        const near = this.around(cells).some((n) => {
          const u = occ.get(posKey(n));
          return u !== undefined && u !== ignore && !mine.has(posKey(n));
        });
        if (!near) return 'alone';
      }
    }
    return null;
  }

  canPlace(s: BoardState<I>, item: I, at: Pos, o = 0, ignore = -1): boolean {
    return this.whyNot(s, item, at, o, ignore) === null;
  }

  /** Every legal placement of `item` (each distinct orientation): the hint, the bot, "can it still fit?" */
  placements(s: BoardState<I>, item: I): { at: XY; o: number }[] {
    const out: { at: XY; o: number }[] = [];
    const occ = this.occupancy(s);
    const free = this.cells(s).filter((p) => !occ.has(posKey(p)));
    for (const t of this.orientations(item)) {
      const anchors = new Map<string, XY>();
      for (const c of free) for (const sc of t.cells) anchors.set(posKey([c[0] - sc[0], c[1] - sc[1]]), [c[0] - sc[0], c[1] - sc[1]]);
      for (const a of [...anchors.values()].sort((p, q) => p[1] - q[1] || p[0] - q[0])) if (this.canPlace(s, item, a, t.o)) out.push({ at: a, o: t.o });
    }
    return out;
  }

  /** Put an item down; null if it can't lie there (whyNot says why). The new piece is the last of next.pieces */
  place(s: BoardState<I>, item: I, at: Pos, o = 0): BoardState<I> | null {
    if (!this.canPlace(s, item, at, o)) return null;
    return { pieces: [...s.pieces, { uid: s.uid, item, at: [at[0], at[1]], o }], tags: s.tags, uid: s.uid + 1 };
  }

  /** Move (and turn) a piece already down; null if it can't go there */
  move(s: BoardState<I>, uid: number, at: Pos, o?: number): BoardState<I> | null {
    const p = this.piece(s, uid);
    if (!p) return null;
    const no = o ?? p.o;
    if (!this.canPlace(s, p.item, at, no, uid)) return null;
    return { ...s, pieces: s.pieces.map((q) => (q.uid === uid ? { ...q, at: [at[0], at[1]] as XY, o: no } : q)) };
  }

  /** Turn a piece where it lies by `by` clockwise steps (keeping its mirror); null if the turned piece doesn't fit */
  turn(s: BoardState<I>, uid: number, by = 1): BoardState<I> | null {
    const p = this.piece(s, uid);
    if (!p) return null;
    const n = turnsOf(this.grid);
    const flip = Math.floor(p.o / n) % 2;
    return this.move(s, uid, p.at, flip * n + ((((p.o % n) + by) % n) + n) % n);
  }

  /** Take a piece off the board; null if there is no such piece */
  remove(s: BoardState<I>, uid: number): BoardState<I> | null {
    if (!this.piece(s, uid)) return null;
    return { ...s, pieces: s.pieces.filter((p) => p.uid !== uid) };
  }

  // --- Adjacency and synergies ------------------------------------------------------------------------------------

  /** The pieces touching a piece (a side shared; diagonals too with `diagonal`) */
  touching(s: BoardState<I>, uid: number): Piece<I>[] {
    const p = this.piece(s, uid);
    if (!p) return [];
    const occ = this.occupancy(s);
    const ids = new Set<number>();
    for (const n of this.around(this.cellsOf(p))) {
      const u = occ.get(posKey(n));
      if (u !== undefined && u !== uid) ids.add(u);
    }
    return s.pieces.filter((q) => ids.has(q.uid));
  }

  /** Adjacent pairs [a, b] where test(a, b) holds (either way round, each pair once): the synergies switched on */
  pairs(s: BoardState<I>, test: (a: Piece<I>, b: Piece<I>) => boolean): [Piece<I>, Piece<I>][] {
    const out: [Piece<I>, Piece<I>][] = [];
    const done = new Set<string>();
    for (const a of s.pieces)
      for (const b of this.touching(s, a.uid)) {
        const k = a.uid < b.uid ? `${a.uid}-${b.uid}` : `${b.uid}-${a.uid}`;
        if (done.has(k)) continue;
        if (test(a, b)) out.push([a, b]);
        else if (test(b, a)) out.push([b, a]);
        else continue;
        done.add(k);
      }
    return out;
  }

  /** A piece's star cells on the board, and what lies on each (a lit star carries its effect there) */
  starred(s: BoardState<I>, uid: number): { pos: XY; piece: Piece<I> | null }[] {
    const p = this.piece(s, uid);
    if (!p) return [];
    return this.oriented(p.item, p.o)
      .stars.map((c) => add(p.at, c))
      .filter((c) => this.inside(s, c))
      .map((pos) => {
        const q = this.pieceAt(s, pos);
        return { pos, piece: q && q.uid !== uid ? q : null };
      });
  }

  // --- Regions and lines ------------------------------------------------------------------------------------------

  /** What a test sees of a cell */
  view(s: BoardState<I>, p: Pos): CellView<I> {
    return { pos: [p[0], p[1]], piece: this.pieceAt(s, p), tags: this.tagsAt(s, p) };
  }

  /**
   * Connected regions of the cells that pass `test` (flood fill over the board's cells; an open board's cells in play),
   * largest first: a forest of 6, the biggest empty area, the hull that must stay in one piece
   */
  regions(s: BoardState<I>, test: (cell: CellView<I>) => boolean): XY[][] {
    const cells = this.cells(s).filter((p) => test(this.view(s, p)));
    const left = new Map(cells.map((p) => [posKey(p), p]));
    const out: XY[][] = [];
    for (const start of cells) {
      if (!left.has(posKey(start))) continue;
      left.delete(posKey(start));
      const region: XY[] = [start];
      for (let i = 0; i < region.length; i++)
        for (const n of this.neighbours(region[i])) {
          const k = posKey(n);
          const q = left.get(k);
          if (q) {
            left.delete(k);
            region.push(q);
          }
        }
      out.push(region.sort((a, b) => a[1] - b[1] || a[0] - b[0]));
    }
    return out.sort((a, b) => b.length - a.length);
  }

  /** Square bounded boards: the rows and columns every cell of which is covered (a block puzzle's clears) */
  fullLines(s: BoardState<I>): { rows: number[]; cols: number[] } {
    const occ = this.occupancy(s);
    const rows = new Map<number, boolean>();
    const cols = new Map<number, boolean>();
    for (const [x, y] of this.cells(s)) {
      const f = occ.has(posKey([x, y]));
      rows.set(y, (rows.get(y) ?? true) && f);
      cols.set(x, (cols.get(x) ?? true) && f);
    }
    const full = (m: Map<number, boolean>) => [...m].filter(([, f]) => f).map(([i]) => i).sort((a, b) => a - b);
    return { rows: full(rows), cols: full(cols) };
  }

  // --- Edges (one-cell tiles) -------------------------------------------------------------------------------------

  /** The edge label a tile shows in world direction `dir` (an index into dirs) */
  edge(p: { item: I; o: number }, dir: number): string | null {
    const edges = this.def.edgesOf?.(p.item);
    if (!edges) return null;
    const n = this.dirs.length;
    for (let e = 0; e < n; e++) {
      const w = orientPos(this.dirs[e], p.o, this.grid);
      if (w[0] === this.dirs[dir][0] && w[1] === this.dirs[dir][1]) return edges[e] ?? null;
    }
    return null;
  }

  /** How a tile would fit at `at`: edges that match a neighbour, that don't, and that face an empty cell */
  fit(s: BoardState<I>, item: I, at: Pos, o = 0, ignore = -1): { matched: number; mismatched: number; open: number } {
    const out = { matched: 0, mismatched: 0, open: 0 };
    const n = this.dirs.length;
    const match = this.def.match ?? ((a: string, b: string) => a === b);
    for (let d = 0; d < n; d++) {
      const np = add(at, this.dirs[d]);
      const q = this.pieceAt(s, np);
      if (q && q.uid !== ignore) {
        const mine = this.edge({ item, o }, d);
        const theirs = this.edge(q, (d + n / 2) % n);
        if (mine === null || theirs === null) continue;
        if (match(mine, theirs)) out.matched++;
        else out.mismatched++;
      } else if (this.inside(s, np)) out.open++;
    }
    return out;
  }

  /**
   * Regions of one terrain across tile edges (Dorfromantik's forests, Carcassonne's roads): tiles joined where both
   * facing edges are `terrain`, with the edges of it still facing an empty cell; `closed` when there are none. A tile's
   * edges of one terrain count as connected inside it.
   */
  edgeRegions(s: BoardState<I>, terrain: string): { cells: XY[]; open: number; closed: boolean }[] {
    const n = this.dirs.length;
    const has = (p: Piece<I>) => Array.from({ length: n }, (_, d) => this.edge(p, d)).includes(terrain);
    const tiles = s.pieces.filter(has);
    const left = new Set(tiles.map((t) => t.uid));
    const out: { cells: XY[]; open: number; closed: boolean }[] = [];
    for (const t of tiles) {
      if (!left.has(t.uid)) continue;
      left.delete(t.uid);
      const group = [t];
      let open = 0;
      for (let i = 0; i < group.length; i++) {
        const g = group[i];
        for (let d = 0; d < n; d++) {
          if (this.edge(g, d) !== terrain) continue;
          const np = add(g.at, this.dirs[d]);
          const q = this.pieceAt(s, np);
          if (!q) {
            if (this.inside(s, np)) open++;
          } else if (this.edge(q, (d + n / 2) % n) === terrain && left.has(q.uid)) {
            left.delete(q.uid);
            group.push(q);
          }
        }
      }
      out.push({ cells: group.map((g) => [g.at[0], g.at[1]] as XY), open, closed: open === 0 });
    }
    return out.sort((a, b) => b.cells.length - a.cells.length);
  }

  // --- Patterns ---------------------------------------------------------------------------------------------------

  /** Every place a pattern is complete now (each set of cells once) */
  find(s: BoardState<I>, pattern: Pattern<I>): PatternMatch[] {
    return this.scan(s, pattern, pattern.cells.length);
  }

  /**
   * Places a pattern is at least `min` cells along and can still be finished (its other cells empty and on the board),
   * the nearest first: the "one more" glow, a hint
   */
  progress(s: BoardState<I>, pattern: Pattern<I>, min = 1): PatternMatch[] {
    return this.scan(s, pattern, min).filter((m) => m.missing.length > 0);
  }

  private scan(s: BoardState<I>, pattern: Pattern<I>, min: number): PatternMatch[] {
    const n = turnsOf(this.grid);
    const seen = new Set<string>();
    const out: PatternMatch[] = [];
    const cells = this.cells(s);
    for (let o = 0; o < n * 2; o++) {
      if (o % n && pattern.turn === false) continue;
      if (o >= n && !pattern.flip) continue;
      // The pattern's cells in order (the i-th cell keeps its test), turned
      const rel = pattern.cells.map((p) => orientPos(p, o, this.grid));
      const anchors = new Map<string, XY>();
      for (const c of cells) for (const r of rel) anchors.set(posKey([c[0] - r[0], c[1] - r[1]]), [c[0] - r[0], c[1] - r[1]]);
      for (const a of anchors.values()) {
        const at = rel.map((r) => add(a, r));
        if (!at.every((p) => this.inside(s, p))) continue;
        const sig = at.map(posKey).sort().join(' ');
        if (seen.has(sig)) continue;
        let matched = 0;
        const missing: XY[] = [];
        let possible = true;
        at.forEach((p, i) => {
          const v = this.view(s, p);
          if (pattern.test(v, i)) matched++;
          else if (v.piece) possible = false;
          else missing.push(p);
        });
        if (matched < min || (matched < at.length && !possible)) continue;
        seen.add(sig);
        out.push({ cells: at, matched, missing });
      }
    }
    return out.sort((a, b) => b.matched - a.matched || a.missing.length - b.missing.length);
  }
}
