// App: frame loop, DPR scaling, input, scene transitions, services (audio, save, ads, purchases, events)
// and the round lifecycle: round → break (ad, within the limits) → result screen.
// It knows nothing about a particular game: which scenes exist is decided by the kit's Flow.

import { AdManager, createAdProvider, type AdsOptions } from './ads';
import { GameAudio } from './audio';
import { createBilling, type BillingOptions, type BillingProvider } from './billing';
import { setRenderScale } from './draw';
import { EventBus } from './events';
import { keepAwake, minimizeApp, onBackButton, onPauseResume } from './native';
import type { Portal } from './portal';
import { loadSave, writeSave, type GameSave, type KeyValueStore } from './save';
import type { Scene } from './scene';

export interface AppOptions {
  /** localStorage key — unique per game, never changed after release */
  saveKey: string;
  /** Save fields and their defaults: core fields plus what the kit adds */
  saveDefaults: GameSave;
  /** BCP 47 language for text-to-speech */
  speechLang: string;
  /** Smallest touch target for the audience (diameter, CSS px ≈ dp) */
  minTouchPx: number;
  ads: AdsOptions | null;
  billing: BillingOptions | null;
  /** Canvas pixel-density cap: higher costs weak phones a lot and is barely visible */
  maxDpr?: number;
  /** Keep the event log (dev and E2E builds) */
  keepEventLog?: boolean;
  /** Web portal SDK (already initialized): gameplay events, ads, save storage */
  portal?: Portal | null;
}

/** What a finished round reports */
export interface RoundResult {
  /** Mode the round was played in */
  mode: string;
  [key: string]: unknown;
}

/** The kit decides which scenes exist and how they connect */
export interface Flow {
  /** The home scene (menu) */
  home(): Scene;
  /**
   * Bookkeeping at the end of a round, before the break (e.g. award a reward, save it).
   * Returns the scene to show after the break.
   */
  roundEnded(result: RoundResult): () => Scene;
  /**
   * Where the ad break is: 'round-end' — between the round and the result scene (kids kit, Families);
   * 'manual' — the kit calls app.adBreak() itself (e.g. when the player taps "Play again", as portals ask).
   */
  readonly adBreak?: 'round-end' | 'manual';
}

const FADE_SEC = 0.25;

export class App {
  readonly canvas: HTMLCanvasElement;
  readonly ctx: CanvasRenderingContext2D;
  readonly save: GameSave;
  readonly audio: GameAudio;
  readonly ads: AdManager;
  readonly billing: BillingProvider;
  readonly events: EventBus;
  readonly minTouchPx: number;
  /** Screen size in CSS pixels and its short side — the whole UI is sized from it */
  w = 0;
  h = 0;
  u = 0;
  dpr = 1;
  /** Seconds since start — for animations */
  time = 0;
  /** Safe-area insets (camera cutout, rounded corners), CSS pixels */
  inset = { top: 0, right: 0, bottom: 0, left: 0 };

  private flow: Flow | null = null;
  private scene: Scene | null = null;
  private fade = 0;
  private last = 0;
  private finishing = false;
  private frameNo = 0;
  private readonly insetProbe: HTMLDivElement;
  private readonly saveKey: string;
  private readonly maxDpr: number;
  private readonly portal: Portal | null;
  private readonly store: () => KeyValueStore;
  /** The portal was told the player is playing */
  private playing = false;
  /** The app is in the background: the game stands still (clocks, targets) */
  private hidden = false;
  /** When the player last tapped or pressed a key (performance clock, s) — rewarded ads need it */
  private lastInputSec: number | null = null;

  constructor(canvas: HTMLCanvasElement, opts: AppOptions) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas 2D is not available');
    this.ctx = ctx;
    this.minTouchPx = opts.minTouchPx;
    this.saveKey = opts.saveKey;
    this.maxDpr = opts.maxDpr ?? 2;
    this.portal = opts.portal ?? null;
    const portalStore = this.portal?.storage() ?? null;
    this.store = () => portalStore ?? localStorage;
    this.events = new EventBus(() => this.time, opts.keepEventLog ?? false);
    // Capacitor 8 puts insets into --safe-area-inset-*, browsers into env()
    this.insetProbe = document.createElement('div');
    this.insetProbe.style.cssText =
      'position:fixed;visibility:hidden;pointer-events:none;' +
      'padding:var(--safe-area-inset-top,env(safe-area-inset-top,0px)) var(--safe-area-inset-right,env(safe-area-inset-right,0px)) ' +
      'var(--safe-area-inset-bottom,env(safe-area-inset-bottom,0px)) var(--safe-area-inset-left,env(safe-area-inset-left,0px))';
    document.body.append(this.insetProbe);
    this.save = loadSave(opts.saveKey, opts.saveDefaults, this.store);
    // The portal's own mute setting (CrazyGames) wins over the game's: nothing plays while it's on
    let portalMuted = this.portal?.muted() ?? false;
    this.portal?.onMuteChange((m) => (portalMuted = m));
    this.audio = new GameAudio(
      {
        sound: () => this.save.sound && !portalMuted,
        voice: () => this.save.voice && !portalMuted,
      },
      opts.speechLang,
    );
    this.billing = createBilling(opts.billing);
    const policy = opts.ads?.policy ?? {
      noAdsAfterLaunchSec: Infinity,
      firstAdAfterRound: Infinity,
      everyRounds: Infinity,
      minIntervalSec: Infinity,
      maxAdWaitSec: 0,
      testAdCloseSec: 0,
    };
    this.ads = new AdManager(createAdProvider(opts.ads, this.portal?.adProvider() ?? null), policy, () => this.save.noAds, {
      onStart: () => {
        this.audio.pause();
        this.setPlaying(false);
        this.events.emit('ad:start');
      },
      onEnd: (shown) => {
        if (!document.hidden) this.audio.resume();
        this.events.emit('ad:end', { shown });
      },
    }, undefined, opts.ads?.rewarded ?? false);

    // Only the player's own input counts (isTrusted: not a script's synthetic event)
    const input = (e: Event) => {
      if (e.isTrusted) this.lastInputSec = performance.now() / 1000;
    };
    window.addEventListener('pointerdown', input, { capture: true });
    window.addEventListener('keydown', input, { capture: true });
    canvas.addEventListener('pointerdown', (e) => this.onPointer(e), { passive: false });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('resize', () => this.resize());
    onBackButton(() => this.back());
    onPauseResume(
      () => {
        this.hidden = true;
        this.audio.pause();
        this.setPlaying(false);
      },
      () => {
        this.hidden = false;
        this.audio.resume();
        this.last = 0;
        this.setPlaying(this.scene?.id === 'round' && !this.finishing);
      },
    );
    this.events.on((e) => {
      if (e.type === 'highlight') this.portal?.happytime();
    });
    this.resize();
  }

  /** The scene on screen */
  get current(): Scene | null {
    return this.scene;
  }

  start(flow: Flow): void {
    this.flow = flow;
    this.go(flow.home());
    // First find out whether "Remove ads" was bought (e.g. after a reinstall), then start the ads SDK:
    // a buyer doesn't need the ads SDK at all. Ads never show right after launch anyway.
    // If the store is slow, the SDK starts after 5 s, and a late "owned" answer is still applied.
    const check = this.checkPurchase();
    void Promise.race([check, new Promise((r) => setTimeout(r, 5000))]).finally(() => void this.ads.init());
    requestAnimationFrame(this.frame);
  }

  /**
   * Checks the purchase with the store. A refund does not turn ads back on by itself: a network
   * glitch or a switched account must not punish someone who paid ("Restore purchases" fixes it).
   */
  async checkPurchase(): Promise<boolean | null> {
    if (!this.billing.available) return null;
    const owned = await this.billing.isOwned();
    if (owned && !this.save.noAds) {
      this.save.noAds = true;
      this.persist();
    }
    return owned;
  }

  go(scene: Scene): void {
    this.scene?.exit?.();
    this.scene = scene;
    this.fade = 1;
    scene.enter?.();
    this.events.emit('scene', { id: scene.id });
    this.setPlaying(scene.id === 'round');
  }

  /** Tell the portal whether the player is playing right now (deduplicated) */
  private setPlaying(on: boolean): void {
    if (on === this.playing || !this.portal) return;
    this.playing = on;
    if (on) this.portal.gameplayStart();
    else this.portal.gameplayStop();
  }

  /**
   * An ad break outside the round lifecycle, for kits with `adBreak: 'manual'` (the ad shows, within the limits,
   * when the player chooses to go on — e.g. "Play again"). Resolves when it's over; repeated calls are ignored.
   */
  async adBreak(): Promise<void> {
    if (this.finishing) return;
    this.finishing = true;
    try {
      await this.ads.afterRound();
    } finally {
      this.finishing = false;
    }
  }

  /**
   * A rewarded ad the player chose (e.g. tapped "Watch an ad: ×2"). Resolves true when it was watched to the end —
   * then give the reward; false: no ad, or not allowed on this channel (hide such buttons: `ads.rewardedAvailable`, false once ads are off or after two failures).
   * Call it right from the tap handler: an ad that doesn't follow the player's own tap is refused.
   */
  async rewarded(placement: string): Promise<boolean> {
    const wasPlaying = this.playing;
    const ok = await this.ads.rewarded(this.lastInputSec);
    this.events.emit('ad:rewarded', { placement, ok });
    if (wasPlaying && !this.hidden) this.setPlaying(this.scene?.id === 'round' && !this.finishing);
    return ok;
  }

  home(): void {
    if (this.flow) this.go(this.flow.home());
  }

  persist(): void {
    writeSave(this.saveKey, this.save, this.store);
  }

  /** The screen stays on only during a round */
  keepAwake(on: boolean): void {
    keepAwake(on);
  }

  back(): void {
    if (this.finishing) return;
    const scene = this.scene;
    if (!scene) return;
    if (scene.back?.()) return;
    if (scene.isHome) minimizeApp();
    else {
      this.audio.tap();
      this.home();
    }
  }

  /**
   * End of round: the kit's bookkeeping → (ad, within the limits) → result scene.
   * A repeated call while the first one is running is ignored.
   */
  async finishRound(result: RoundResult): Promise<void> {
    if (this.finishing || !this.flow) return;
    this.finishing = true;
    try {
      this.events.emit('round:end', { mode: result.mode });
      this.setPlaying(false);
      const next = this.flow.roundEnded(result);
      this.save.rounds++;
      this.persist();
      if (this.flow.adBreak !== 'manual') await this.ads.afterRound();
      this.go(next());
    } finally {
      this.finishing = false;
    }
  }

  private readInsets(): void {
    const cs = getComputedStyle(this.insetProbe);
    this.inset = {
      top: parseFloat(cs.paddingTop) || 0,
      right: parseFloat(cs.paddingRight) || 0,
      bottom: parseFloat(cs.paddingBottom) || 0,
      left: parseFloat(cs.paddingLeft) || 0,
    };
  }

  private resize(): void {
    this.readInsets();
    const w = Math.max(1, window.innerWidth);
    const h = Math.max(1, window.innerHeight);
    const dpr = Math.min(window.devicePixelRatio || 1, this.maxDpr);
    if (w === this.w && h === this.h && dpr === this.dpr) return;
    this.w = w;
    this.h = h;
    this.u = Math.min(w, h);
    this.dpr = dpr;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    setRenderScale(dpr);
  }

  private onPointer(e: PointerEvent): void {
    e.preventDefault();
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    this.audio.unlock();
    const rect = this.canvas.getBoundingClientRect();
    this.scene?.pointer(e.clientX - rect.left, e.clientY - rect.top);
  }

  private frame = (ts: number): void => {
    requestAnimationFrame(this.frame);
    // In the background nothing moves: a timed round must not run out while the player is away.
    // Nor while an ad is on its way or on screen: the frame under it is frozen, and the phone's CPU and GPU go to the
    // ad (on a slow device the interstitial's activity took up to 2 minutes to open while the game kept drawing)
    if (this.hidden || this.ads.adPending) {
      this.last = 0;
      return;
    }
    // Up to 0.1 s per frame: on a slow phone (10 fps) the game still runs at normal speed, not in slow motion
    const dt = this.last ? Math.min(0.1, (ts - this.last) / 1000) : 0;
    this.last = ts;
    this.time += dt;
    // The window size can change without a resize event (rotation on some Android devices),
    // and Capacitor sends cutout insets via script — re-read them now and then
    if (window.innerWidth !== this.w || window.innerHeight !== this.h) this.resize();
    else if ((this.frameNo++ & 31) === 0) this.readInsets();
    const scene = this.scene;
    if (!scene) return;
    scene.update(dt);
    const ctx = this.ctx;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    scene.draw(ctx);
    if (this.fade > 0) {
      ctx.fillStyle = `rgba(255, 255, 255, ${(this.fade * 0.6).toFixed(3)})`;
      ctx.fillRect(0, 0, this.w, this.h);
      this.fade = Math.max(0, this.fade - dt / FADE_SEC);
    }
  };
}
