// Saves live only on the device, in localStorage. No identifiers, no network.
// A save is a flat record of booleans and non-negative integer counters; the shape comes from
// the defaults (core fields + fields a kit adds), and anything that doesn't match is dropped.

export type SaveValue = boolean | number;
export type SaveData = Record<string, SaveValue>;

/** Fields every game has */
export interface CoreSave {
  sound: boolean;
  voice: boolean;
  /** "Remove ads" was bought */
  noAds: boolean;
  /** Rounds played in total — on-device statistics only */
  rounds: number;
}

export type GameSave = CoreSave & SaveData;

/** Where saves live: localStorage, or a portal's (cloud-synced) storage with the same two methods */
export interface KeyValueStore {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

const local = (): KeyValueStore => localStorage;

export const CORE_SAVE_DEFAULTS: CoreSave = { sound: true, voice: true, noAds: false, rounds: 0 };

export function loadSave<T extends SaveData>(key: string, defaults: T, store: () => KeyValueStore = local): T {
  const save = { ...defaults };
  try {
    const raw = store().getItem(key);
    if (!raw) return save;
    const data = JSON.parse(raw) as Record<string, unknown>;
    for (const k of Object.keys(defaults)) {
      const v = data[k];
      if (typeof defaults[k] === 'boolean' && typeof v === 'boolean') (save as SaveData)[k] = v;
      else if (typeof defaults[k] === 'number' && typeof v === 'number' && Number.isFinite(v)) (save as SaveData)[k] = Math.max(0, Math.floor(v));
    }
  } catch {
    // Corrupted or unavailable storage — play with defaults
  }
  return save;
}

export function writeSave(key: string, save: SaveData, store: () => KeyValueStore = local): void {
  try {
    store().setItem(key, JSON.stringify(save));
  } catch {
    // Storage unavailable (private mode) — the game goes on without saving
  }
}

// ---------------------------------------------------------------------------------------------
// JSON saves for games with their own code (kit: code): nested data (upgrades, unlocked items, best times).

/**
 * `data` shaped like `defaults`: every field keeps its default unless the stored value has the same type.
 * Numbers must be finite; arrays keep only elements of a kind the default's elements have — any of them, so a
 * default of nullable slots (`hold: [null, null, null]` or `['', null]`) keeps both the strings or objects and the nulls;
 * an empty default, or one of nulls only, takes any elements;
 * an empty object default (a map such as `best: {}`) takes the stored object as is (JSON values only);
 * a non-empty one is merged field by field. A `null` default (an optional value: `campaign: null`) takes the stored
 * value as is, null included. Fields that are not in the defaults are dropped — except in a map keyed by ids: a default
 * whose entries are all objects of the same fields (`sites: { shed: { cars: 0, level: 1 } }`) keeps every stored entry that
 * is an object with one of those fields, shaped like the first default entry (so `sites.garage2` survives a reload).
 * So an old, broken or tampered save never crashes the game: it gets defaults where it doesn't fit.
 */
const isPlainObject = (x: unknown): x is Record<string, unknown> => !!x && typeof x === 'object' && !Array.isArray(x);

/** The entry shape of a default map keyed by ids: every value a non-empty object with the same fields. */
function recordEntry(d: Record<string, unknown>): Record<string, unknown> | null {
  const values = Object.values(d);
  if (!values.length || !values.every(isPlainObject)) return null;
  const sig = (o: Record<string, unknown>) => Object.keys(o).sort().join('\u0000');
  const first = values[0] as Record<string, unknown>;
  if (!Object.keys(first).length) return null;
  return values.every((v) => sig(v as Record<string, unknown>) === sig(first)) ? first : null;
}

const kindOf = (x: unknown): string => (x === null ? 'null' : Array.isArray(x) ? 'array' : typeof x);

export function mergeShape<T>(defaults: T, data: unknown): T {
  const d = defaults as unknown;
  if (d === null) return (data === undefined ? null : structuredClone(data)) as T;
  if (typeof d === 'number') return (typeof data === 'number' && Number.isFinite(data) ? data : d) as T;
  if (typeof d === 'boolean' || typeof d === 'string') return (typeof data === typeof d ? data : d) as T;
  if (Array.isArray(d)) {
    if (!Array.isArray(data)) return structuredClone(defaults);
    if (!d.length) return structuredClone(data) as T;
    // The element kinds the defaults hold, all of them: a hold `[null, null, 'coffee']` or `[null, …]` takes strings and
    // nulls (the first element alone used to decide, so a leading null dropped every string)
    const kinds = new Set(d.map(kindOf));
    if (kinds.size === 1 && kinds.has('null')) return structuredClone(data) as T;
    return structuredClone(data.filter((x) => kinds.has(kindOf(x)) && (typeof x !== 'number' || Number.isFinite(x)))) as T;
  }
  if (d && typeof d === 'object') {
    const src = data && typeof data === 'object' && !Array.isArray(data) ? (data as Record<string, unknown>) : {};
    const keys = Object.keys(d);
    if (!keys.length) return structuredClone(src) as T;
    const dd = d as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const k of keys) out[k] = Object.hasOwn(src, k) ? mergeShape(dd[k], src[k]) : structuredClone(dd[k]);
    // A map keyed by ids (`sites: { shed: { cars: 0 } }`): every default entry an object of the same fields. A stored
    // entry the defaults don't name, an object with one of those fields at least, is kept, shaped like the first entry
    // (the rule "fields not in the defaults are dropped" lost every garage but the first on a reload: Garage Evolution 1.4.0)
    const entry = recordEntry(dd);
    if (entry) {
      const fields = Object.keys(entry);
      for (const k of Object.keys(src)) {
        const v = src[k];
        if (Object.hasOwn(out, k) || !isPlainObject(v) || !fields.some((f) => Object.hasOwn(v, f))) continue;
        out[k] = mergeShape(entry, v);
      }
    }
    return out as T;
  }
  return defaults;
}

export function loadJson<T>(key: string, defaults: T, store: () => KeyValueStore = local): T {
  try {
    const raw = store().getItem(key);
    return mergeShape(defaults, raw ? JSON.parse(raw) : null);
  } catch {
    return mergeShape(defaults, null);
  }
}
