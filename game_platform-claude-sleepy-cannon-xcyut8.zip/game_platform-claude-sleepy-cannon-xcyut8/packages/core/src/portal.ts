// Portals: web game platforms with their own SDK (CrazyGames; Playgama Bridge, which reaches 20+ platforms). The app reports the gameplay
// lifecycle to the portal by itself (round start/stop, pauses, ads), so a game can't forget a call.
// Dev builds use a stub that records every call (QA checks the sequence) and never loads a real SDK.

import type { AdProvider } from './ads';
import { watchRecorder } from './recorder';
import type { KeyValueStore } from './save';

export type PortalId = 'crazygames' | 'playgama';

export interface Portal {
  readonly name: string;
  /** Load and start the SDK. Never throws: without an SDK the portal becomes a no-op. `keys`: the save keys the game
   *  reads, for a portal whose storage must be loaded up front (Playgama Bridge: one storage.get of all of them) */
  init(keys?: string[]): Promise<void>;
  loadingStart(): void;
  loadingStop(): void;
  /** The player is playing now (round running) */
  gameplayStart(): void;
  /** Any break: menu, result, pause, ad, hidden tab */
  gameplayStop(): void;
  /** A moment worth celebrating (new best score) */
  happytime(): void;
  /** The portal's ads, or null to use the platform's providers */
  adProvider(): AdProvider | null;
  /** The portal's save storage (cloud-synced for logged-in players), or null for localStorage */
  storage(): KeyValueStore | null;
  /** The player muted the game in the portal's own settings (CrazyGames: game.settings.muteAudio) */
  muted(): boolean;
  /** Called when that setting changes */
  onMuteChange(fn: (muted: boolean) => void): void;
  /** The player's locale as the portal knows it (CrazyGames: user.systemInfo.locale, e.g. "pt-BR"), or null */
  locale(): string | null;
  /** The platform itself paused the game (Playgama Bridge: YouTube, a mini-app sent to the background): the host pauses */
  onPause?(fn: (paused: boolean) => void): void;
  /** The player's account on the portal, where it has sign-in (Playgama Bridge: bridge.player), or null */
  account?(): PortalAccount | null;
  /** Start the portal's sign-in from the player's tap; resolves true once signed in */
  signIn?(): Promise<boolean>;
  /**
   * A step of the host's first-minute funnel (boot, loaded, title, firstInput, gameplayStart, play15/30/60, firstFail,
   * firstResults, exit), for a portal with an analytics API that takes a game's own events. Neither adapter has one
   * today: CrazyGames measures conversion without the SDK, and Playgama Bridge has no custom-event API — its telemetry
   * reads gameplay_started / gameplay_stopped, which the host already sends (docs/guides/first-minute.md → the funnel)
   */
  funnel?(step: string, data: Record<string, unknown>): void;
}

/** How long boot waits for the portal's SDK before the game starts without it (the SDK's calls are queued meanwhile) */
export const PORTAL_SOFT_WAIT_MS = 1500;

/** A portal whose SDK may still be loading: what the game needs right away, and when the SDK is ready */
export interface DeferredPortal extends Portal {
  /** The SDK is ready (init resolved): the queued calls have gone through */
  readonly ready: boolean;
  /** Resolves when the SDK's init has resolved (or failed: then the portal stays a no-op) */
  readonly whenReady: Promise<void>;
}

/**
 * The portal, usable before its SDK has loaded (C7: boot never blocks the game's first frame on a slow SDK — CrazyGames'
 * script and init may take up to 8 s each on a bad network). `init` starts at once; until it resolves:
 * - the lifecycle calls (loadingStart/Stop, gameplayStart/Stop, happytime) wait in a queue and go through in order then;
 * - mute and pause listeners are registered then (the current mute state is passed on if it is on);
 * - saves go to `local` (localStorage) — and when the SDK arrives, a portal store with no save of its own gets this
 *   session's saves copied in and is used from then on; a portal store that already has one (a returning player whose
 *   SDK was slow) is never overwritten: this session stays on `local` (a console warning says so).
 * When init resolves within the boot's soft wait (the usual case), boot passes the real portal on and none of this runs.
 */
export function deferPortal(portal: Portal, init: Promise<void>, keys: readonly string[], local: () => KeyValueStore = () => localStorage): DeferredPortal {
  let ready = false;
  const queue: ((p: Portal) => void)[] = [];
  const later = (fn: (p: Portal) => void) => (ready ? fn(portal) : void queue.push(fn));
  /** Where saves go: local until the SDK is ready, then the portal's store if it had nothing of its own */
  let store: KeyValueStore | null = null;
  const written = new Set<string>();
  const whenReady = init
    .catch(() => {})
    .then(() => {
      const remote = portal.storage();
      if (remote) {
        let mine = true;
        try {
          mine = keys.every((k) => !remote.getItem(k));
        } catch {
          mine = false;
        }
        if (mine) {
          for (const k of written) {
            try {
              const v = local().getItem(k);
              if (v !== null) remote.setItem(k, v);
            } catch (e) {
              console.warn('[portal] save copy failed', e);
            }
          }
          store = remote;
        } else if (written.size) console.warn('[portal] the SDK came late and has a save of its own: this session keeps saving locally, the cloud save is not overwritten');
        else store = remote;
      }
      ready = true;
      for (const fn of queue.splice(0)) {
        try {
          fn(portal);
        } catch (e) {
          console.warn('[portal]', e);
        }
      }
    });
  const kv: KeyValueStore = {
    getItem: (k) => (store ?? local()).getItem(k),
    setItem: (k, v) => {
      if (!store) written.add(k);
      (store ?? local()).setItem(k, v);
    },
  };
  return {
    name: portal.name,
    get ready() {
      return ready;
    },
    whenReady,
    init: () => whenReady,
    loadingStart: () => later((p) => p.loadingStart()),
    loadingStop: () => later((p) => p.loadingStop()),
    gameplayStart: () => later((p) => p.gameplayStart()),
    gameplayStop: () => later((p) => p.gameplayStop()),
    happytime: () => later((p) => p.happytime()),
    // Both adapters read their SDK when an ad is asked for, so their providers work before init (an ad then says 'off')
    adProvider: () => portal.adProvider(),
    storage: () => kv,
    muted: () => (ready ? portal.muted() : false),
    onMuteChange: (fn) =>
      later((p) => {
        p.onMuteChange(fn);
        if (p.muted()) fn(true);
      }),
    locale: () => (ready ? portal.locale() : null),
    onPause: portal.onPause ? (fn) => later((p) => p.onPause?.(fn)) : undefined,
    account: portal.account ? () => (ready ? (portal.account?.() ?? null) : null) : undefined,
    signIn: portal.signIn ? () => (ready ? portal.signIn!() : Promise.resolve(false)) : undefined,
    funnel: portal.funnel ? (step, data) => later((p) => p.funnel?.(step, data)) : undefined,
  };
}

/** A portal account: whether the portal offers sign-in, whether the player is signed in, and their name */
export interface PortalAccount {
  supported: boolean;
  authorized: boolean;
  name: string | null;
}

// ---------------------------------------------------------------------------------------------
// CrazyGames HTML5 SDK v3

const CRAZYGAMES_SDK = 'https://sdk.crazygames.com/crazygames-sdk-v3.js';

interface CrazySdk {
  init(): Promise<void>;
  environment: string;
  game: {
    loadingStart(): void;
    loadingStop(): void;
    gameplayStart(): void;
    gameplayStop(): void;
    happytime(): void;
    settings?: { muteAudio?: boolean };
    addSettingsChangeListener?(fn: (s: { muteAudio?: boolean }) => void): void;
  };
  ad: { requestAd(type: 'midgame' | 'rewarded', callbacks: { adStarted?: () => void; adFinished?: () => void; adError?: (e: unknown) => void }): void };
  data: KeyValueStore;
  /** systemInfo.locale: the language CrazyGames shows the player (its site language, from the browser) */
  user?: { systemInfo?: { locale?: string; countryCode?: string } };
}

function loadScript(src: string, timeoutMs: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.async = true;
    const t = setTimeout(() => reject(new Error('timeout')), timeoutMs);
    s.onload = () => {
      clearTimeout(t);
      resolve();
    };
    s.onerror = () => {
      clearTimeout(t);
      reject(new Error('load failed'));
    };
    document.head.append(s);
  });
}

class CrazyGamesPortal implements Portal {
  readonly name = 'crazygames';
  private sdk: CrazySdk | null = null;

  async init(): Promise<void> {
    try {
      await loadScript(CRAZYGAMES_SDK, 8000);
      const sdk = (window as unknown as { CrazyGames?: { SDK?: CrazySdk } }).CrazyGames?.SDK;
      if (!sdk) return;
      await Promise.race([sdk.init(), new Promise((_, rej) => setTimeout(() => rej(new Error('init timeout')), 8000))]);
      // 'disabled': the game runs outside CrazyGames — behave as a plain web build
      if (sdk.environment !== 'disabled') this.sdk = sdk;
    } catch (e) {
      console.warn('[crazygames] SDK unavailable', e);
    }
  }

  private call(fn: (s: CrazySdk) => void): void {
    if (!this.sdk) return;
    try {
      fn(this.sdk);
    } catch (e) {
      console.warn('[crazygames]', e);
    }
  }

  loadingStart(): void {
    this.call((s) => s.game.loadingStart());
  }
  loadingStop(): void {
    this.call((s) => s.game.loadingStop());
  }
  gameplayStart(): void {
    this.call((s) => s.game.gameplayStart());
  }
  gameplayStop(): void {
    this.call((s) => s.game.gameplayStop());
  }
  happytime(): void {
    this.call((s) => s.game.happytime());
  }

  adProvider(): AdProvider | null {
    return {
      name: 'crazygames',
      async init() {},
      preload() {},
      // Midgame ads only in natural breaks (the kit decides where); the portal enforces its own cooldown too
      show: () => this.requestAd('midgame').then((r) => r === true),
      // Rewarded: only when the player chose it (App.rewarded checks that); true — give the reward
      showRewarded: () => this.requestAd('rewarded'),
    };
  }

  /** true — watched; false — not this time; 'off' — no ads this session (Basic Launch: adsDisabledBasicLaunch; adblock) */
  private requestAd(type: 'midgame' | 'rewarded'): Promise<boolean | 'off'> {
    const sdk = this.sdk;
    if (!sdk) return Promise.resolve('off');
    return new Promise<boolean | 'off'>((resolve) => {
      let done = false;
      const finish = (ok: boolean | 'off') => {
        if (!done) {
          done = true;
          resolve(ok);
        }
      };
      try {
        sdk.ad.requestAd(type, {
          adFinished: () => finish(true),
          adError: (e) => {
            const code = (e as { code?: string } | undefined)?.code;
            finish(code === 'adsDisabledBasicLaunch' || code === 'adblock' ? 'off' : false);
          },
        });
      } catch {
        finish(false);
      }
    });
  }

  storage(): KeyValueStore | null {
    return this.sdk ? this.sdk.data : null;
  }

  // CrazyGames requires the game to follow the player's mute setting in the portal
  muted(): boolean {
    try {
      return !!this.sdk?.game.settings?.muteAudio;
    } catch {
      return false;
    }
  }

  onMuteChange(fn: (muted: boolean) => void): void {
    this.call((s) => s.game.addSettingsChangeListener?.((st) => fn(!!st.muteAudio)));
  }

  // CrazyGames: "pick the language from the SDK's system-info locale and fall back to English"
  locale(): string | null {
    try {
      const l = this.sdk?.user?.systemInfo?.locale;
      return typeof l === 'string' && l ? l : null;
    } catch {
      return null;
    }
  }
}

// ---------------------------------------------------------------------------------------------
// Playgama Bridge v2: one SDK, the platform's own adapter loaded from the CDN (Playgama, YouTube Playables, MSN, Yandex,
// Facebook, Discord, Telegram, Xiaomi, Huawei …). playgama-bridge-config.json sits next to index.html (gp build
// --target playgama writes it).

const PLAYGAMA_BRIDGE = 'https://bridge.playgama.com/v2/stable/playgama-bridge.js';

interface BridgeEvents {
  on(event: string, fn: (state: unknown) => void): void;
  off(event: string, fn?: (state: unknown) => void): void;
}
export interface PlaygamaBridge {
  initialize(): Promise<void>;
  platform: BridgeEvents & {
    id: string;
    language: string;
    isAudioEnabled: boolean;
    isPaused: boolean;
    sendMessage(message: string): Promise<unknown>;
  };
  storage: {
    get(keys: string[], tryParseJson?: boolean): Promise<unknown[]>;
    set(keys: string[], values: string[]): Promise<void>;
  };
  player?: {
    isAuthorizationSupported: boolean;
    isAuthorized: boolean;
    name?: string | null;
    authorize(options?: object): Promise<unknown>;
  };
  advertisement: BridgeEvents & {
    isInterstitialSupported: boolean;
    isRewardedSupported: boolean;
    showInterstitial(placement?: string | null): void;
    showRewarded(placement?: string | null): void;
    /** 'loading' | 'opened' | 'closed' | 'failed' (Bridge's own record of the ad on screen) */
    interstitialState?: string;
    rewardedState?: string;
  };
}

/**
 * How long an ad may take to start (no 'loading'/'opened': the platform's own cooldown or no fill), to open after
 * 'loading', and to end. Bridge can defer or skip an interstitial (its minimum delay, an ad blocker, no fill) after
 * 'loading' with no 'closed' or 'failed' ever coming: at 120 s the game sat frozen at the end of a floor until a reload
 * (Candle Crypt on Playgama, 2026-10-22). An interstitial with its countdown and a rewarded video fit in 45 s.
 */
const AD_START_MS = 5000;
const AD_OPEN_MS = 10000;
const AD_MAX_MS = 45000;
/**
 * An ad Bridge still reports as 'opened' is on screen: Playgama's cross-promo interstitial stays until the player taps its
 * Close, however long that takes (2026-10-23). The game waits for it — looked at again this often — and never resumes
 * behind it (the player would lose unseen); the 45 s limit only covers an ad that never opens or whose state is unknown.
 */
const AD_OPEN_CHECK_MS = 5000;

export class PlaygamaPortal implements Portal {
  readonly name = 'playgama';
  private bridge: PlaygamaBridge | null = null;
  private ready = false;

  /** `bridge`: an SDK already on the page (tests); otherwise it is loaded from the CDN */
  constructor(private readonly given?: PlaygamaBridge) {}

  /** The saves, loaded once at init (one storage.get of every key) and written through to Bridge's storage */
  private saves = new Map<string, string>();
  /** One of our ads is between its request and its end; the platform's pause state; that pause began during our ad */
  private adActive = false;
  private platformPaused = false;
  private pauseByAd = false;
  private pauseFns: ((paused: boolean) => void)[] = [];

  async init(keys: string[] = []): Promise<void> {
    // Playgama's QA Tool films the first <canvas> only: the mirror puts the DOM screens in its recording (recorder.ts)
    watchRecorder();
    try {
      if (!this.given) await loadScript(PLAYGAMA_BRIDGE, 8000);
      const b = this.given ?? (window as unknown as { bridge?: PlaygamaBridge }).bridge;
      if (!b) return;
      await Promise.race([b.initialize(), new Promise((_, rej) => setTimeout(() => rej(new Error('init timeout')), 8000))]);
      this.bridge = b;
    } catch (e) {
      console.warn('[playgama] Bridge unavailable', e);
      return;
    }
    // Bridge's checklist: progress only through Storage (cloud saves where the platform has them), all keys in one call
    if (keys.length) {
      try {
        const values = await Promise.race([this.bridge.storage.get(keys, false), new Promise<never>((_, rej) => setTimeout(() => rej(new Error('storage timeout')), 5000))]);
        keys.forEach((k, i) => {
          const v = values?.[i];
          if (v !== null && v !== undefined) this.saves.set(k, typeof v === 'string' ? v : JSON.stringify(v));
        });
      } catch (e) {
        console.warn('[playgama] storage unavailable', e);
      }
    }
  }

  private send(message: string): void {
    try {
      void this.bridge?.platform.sendMessage(message).catch(() => {});
    } catch (e) {
      console.warn('[playgama]', e);
    }
  }

  /**
   * Playgama's QA Tool checks sign-in (Authorization): where the platform has it, the game offers a way to sign in and
   * hides it once the player is signed in (2026-10-10: "No sign-in option found" / "Login button visible for an
   * authorized user"). Launching never requires it (the checklist).
   */
  account(): PortalAccount | null {
    const p = this.bridge?.player;
    if (!p) return null;
    try {
      return { supported: !!p.isAuthorizationSupported, authorized: !!p.isAuthorized, name: p.name ?? null };
    } catch {
      return null;
    }
  }

  async signIn(): Promise<boolean> {
    const p = this.bridge?.player;
    if (!p?.isAuthorizationSupported) return false;
    try {
      await p.authorize();
    } catch (e) {
      console.warn('[playgama] sign-in', e);
      return false;
    }
    return !!p.isAuthorized;
  }

  loadingStart(): void {}
  /** game_ready dismisses the platform's loader: without it most platforms keep their splash over the game */
  loadingStop(): void {
    if (this.ready) return;
    this.ready = true;
    this.send('game_ready');
  }
  gameplayStart(): void {
    this.send('gameplay_started');
  }
  gameplayStop(): void {
    this.send('gameplay_stopped');
  }
  happytime(): void {}

  adProvider(): AdProvider | null {
    return {
      name: 'playgama',
      async init() {},
      preload() {},
      // The game is held from 'opened', not from the request: Bridge loads for seconds and often finds no fill
      startsOnOpen: true,
      show: (onOpen) => this.ad('interstitial', undefined, onOpen).then((r) => r === true),
      // The game's placement goes to the Bridge (bridge.advertisement.rewardedPlacement; Playgama's QA Tool logs it)
      showRewarded: (placement) => this.ad('rewarded', placement),
    };
  }

  /** true — watched (rewarded: the reward was granted); false — not this time; 'off' — the platform has no such ads */
  private ad(kind: 'interstitial' | 'rewarded', placement?: string, onOpen?: () => void): Promise<boolean | 'off'> {
    const b = this.bridge;
    if (!b) return Promise.resolve('off');
    const ad = b.advertisement;
    if (kind === 'rewarded' ? !ad.isRewardedSupported : !ad.isInterstitialSupported) return Promise.resolve(kind === 'rewarded' ? 'off' : false);
    const event = kind === 'rewarded' ? 'rewarded_state_changed' : 'interstitial_state_changed';
    return new Promise<boolean | 'off'>((resolve) => {
      let started = false;
      let opened = false;
      let rewarded = false;
      let done = false;
      const timers: ReturnType<typeof setTimeout>[] = [];
      this.adActive = true;
      const finish = (ok: boolean) => {
        if (done) return;
        done = true;
        timers.forEach(clearTimeout);
        this.adEnded();
        try {
          ad.off(event, on);
        } catch {
          // an SDK without off(): the listener stays, `done` keeps it quiet
        }
        resolve(ok);
      };
      const on = (state: unknown) => {
        if (state === 'loading' && !started) timers.push(setTimeout(() => !opened && finish(false), AD_OPEN_MS));
        if (state === 'loading' || state === 'opened') started = true;
        if (state === 'opened' && !opened) {
          opened = true;
          onOpen?.();
        }
        if (state === 'rewarded') rewarded = true;
        if (state === 'failed') finish(false);
        if (state === 'closed') finish(kind === 'rewarded' ? rewarded : opened);
      };
      const onScreen = () => (kind === 'rewarded' ? ad.rewardedState : ad.interstitialState) === 'opened';
      const atMax = () => {
        if (done) return;
        if (opened && onScreen()) timers.push(setTimeout(atMax, AD_OPEN_CHECK_MS));
        else finish(kind === 'rewarded' ? rewarded : opened);
      };
      timers.push(setTimeout(() => !started && finish(false), AD_START_MS), setTimeout(atMax, AD_MAX_MS));
      try {
        ad.on(event, on);
        if (kind === 'rewarded') ad.showRewarded(placement);
        else ad.showInterstitial();
      } catch {
        finish(false);
      }
    });
  }

  /** Bridge's storage behind the host's synchronous save: read from what init loaded, every write sent on to Bridge */
  storage(): KeyValueStore | null {
    const b = this.bridge;
    if (!b) return null;
    return {
      getItem: (k) => this.saves.get(k) ?? null,
      setItem: (k, v) => {
        this.saves.set(k, v);
        try {
          void b.storage.set([k], [v]).catch((e) => console.warn('[playgama] save failed', e));
        } catch (e) {
          console.warn('[playgama] save failed', e);
        }
      },
    };
  }

  muted(): boolean {
    try {
      return this.bridge ? !this.bridge.platform.isAudioEnabled : false;
    } catch {
      return false;
    }
  }

  onMuteChange(fn: (muted: boolean) => void): void {
    try {
      this.bridge?.platform.on('audio_state_changed', (enabled) => fn(!enabled));
    } catch (e) {
      console.warn('[playgama]', e);
    }
  }

  onPause(fn: (paused: boolean) => void): void {
    // A Bridge pause holds until Bridge lifts it: Playgama's QA Tool opens a system overlay and checks the game stands
    // still the whole time ("Platform pause signal ignored", 2026-10-24) — the stale-pause release of 31e3735 failed it.
    // A pause that began while one of our ads was up ends with the ad: the sandbox sends pause true when a rewarded ad
    // opens and never false after it closes (2026-10-25: Candle Crypt frozen for good after "Relight (ad)")
    this.pauseFns.push(fn);
    if (this.pauseFns.length > 1) return;
    try {
      this.bridge?.platform.on('pause_state_changed', (p) => {
        // A repeat is no news: Bridge's own false after we lifted an ad's pause, a second true
        if (!!p === this.platformPaused) return;
        this.platformPaused = !!p;
        this.pauseByAd = !!p && this.adActive;
        for (const f of this.pauseFns) f(!!p);
      });
    } catch (e) {
      console.warn('[playgama]', e);
    }
  }

  /** Our ad is over (closed, failed or timed out): a Bridge pause it caused and Bridge didn't lift is lifted here */
  private adEnded(): void {
    this.adActive = false;
    if (!this.pauseByAd || !this.platformPaused) return;
    this.pauseByAd = false;
    this.platformPaused = false;
    for (const f of this.pauseFns) f(false);
  }

  locale(): string | null {
    try {
      const l = this.bridge?.platform.language;
      return typeof l === 'string' && l ? l : null;
    } catch {
      return null;
    }
  }
}

// ---------------------------------------------------------------------------------------------
// Dev stub: records calls in window.__portal.calls, stores in localStorage, ads come from the dev ad stub.

class TestPortal implements Portal {
  readonly calls: { fn: string; t: number }[] = [];

  constructor(readonly name: string) {
    (window as unknown as { __portal: TestPortal }).__portal = this;
  }

  private log(fn: string): void {
    this.calls.push({ fn, t: performance.now() / 1000 });
  }

  async init(): Promise<void> {
    this.log('init');
  }
  loadingStart(): void {
    this.log('loadingStart');
  }
  loadingStop(): void {
    this.log('loadingStop');
  }
  gameplayStart(): void {
    this.log('gameplayStart');
  }
  gameplayStop(): void {
    this.log('gameplayStop');
  }
  happytime(): void {
    this.log('happytime');
  }
  adProvider(): AdProvider | null {
    return null;
  }
  storage(): KeyValueStore | null {
    return null;
  }

  /** QA: window.__portal.setMuted(true) plays the portal's mute setting (also ?portalMute=1) */
  private mute = new URLSearchParams(location.search).get('portalMute') === '1';
  private muteFns: ((m: boolean) => void)[] = [];
  muted(): boolean {
    return this.mute;
  }
  onMuteChange(fn: (muted: boolean) => void): void {
    this.muteFns.push(fn);
  }
  /** QA: ?portalLocale=de-DE plays the portal's locale (CrazyGames systemInfo.locale) */
  locale(): string | null {
    return new URLSearchParams(location.search).get('portalLocale');
  }
  setMuted(m: boolean): void {
    this.mute = m;
    this.log(m ? 'settings:muteAudio=true' : 'settings:muteAudio=false');
    for (const f of this.muteFns) f(m);
  }
}

export function createPortal(id: PortalId | null): Portal | null {
  if (!id) return null;
  // gp playgama-check builds with the test hooks and the real portal (VITE_REAL_PORTAL): the portal's SDK is the check's fake
  if ((import.meta.env.DEV || import.meta.env.VITE_E2E === '1') && import.meta.env.VITE_REAL_PORTAL !== '1') return new TestPortal(id);
  if (id === 'crazygames') return new CrazyGamesPortal();
  if (id === 'playgama') return new PlaygamaPortal();
  return null;
}
