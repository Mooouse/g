import { describe, expect, it } from 'vitest';
import { emptyLayout, FLAT_FAIL_LIMITS, flatFrame, flatText, largestRect } from '../src/flat.ts';

/** Seeded noise in [0, 1) */
const hash = (i: number, s: number) => (Math.sin(i * 12.9898 + s * 78.233) * 43758.5453) % 1 + (Math.sin(i * 12.9898 + s * 78.233) < 0 ? 1 : 0);

/** A synthetic w×h RGBA image from a pixel function */
function image(w: number, h: number, f: (x: number, y: number) => [number, number, number]): number[] {
  const out: number[] = [];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) out.push(...f(x, y), 255);
  return out;
}

describe('the flat frame hint', () => {
  it('a solid background with a few dots is flat: one colour, few levels, featureless', () => {
    const img = image(160, 90, (x, y) => ((x - 80) ** 2 + (y - 45) ** 2 < 100 ? [255, 200, 80] : [17, 34, 51]));
    const f = flatFrame(img, 160, 90);
    expect(f.flat).toBe(true);
    expect(f.topShare).toBeGreaterThan(0.9);
    expect(f.topColor).toBe('#112233');
    expect(f.levels).toBeLessThan(4);
    expect(f.uniformShare).toBeGreaterThan(0.8);
    expect(f.hint).toMatch(/one flat colour \(#112233\).*@gp\/art/);
    expect(flatText(f)).toMatch(/top colour 9\d%/);
  });
  it('a gradient sky with noise and layered hills is not flat', () => {
    const img = image(160, 90, (x, y) => {
      const ridge = 50 + 10 * Math.sin(x / 13) + 5 * Math.sin(x / 5);
      const n = (hash(x + y * 160, 3) - 0.5) * 14;
      if (y > ridge) return [40 + y + n, 60 + y * 0.5 + n, 90 + n];
      return [20 + y * 2 + n, 30 + y * 1.6 + n, 80 + y * 1.2 + n];
    });
    const f = flatFrame(img, 160, 90);
    expect(f.flat).toBe(false);
    expect(f.hint).toBeNull();
    expect(f.levels).toBeGreaterThanOrEqual(8);
    expect(flatText(f)).toMatch(/^looks fine/);
  });
  it('a smooth gradient alone has levels but large featureless areas', () => {
    const img = image(160, 90, (_x, y) => [10 + y * 0.5, 20 + y * 0.5, 60 + y * 0.5]);
    const f = flatFrame(img, 160, 90);
    expect(f.topShare).toBeLessThan(0.4);
    expect(f.uniformShare).toBeGreaterThan(0.55);
    expect(f.flat).toBe(true);
    expect(f.hint).toMatch(/featureless/);
  });
  it('two flat colours split down the middle: few levels', () => {
    const img = image(64, 64, (x) => (x < 32 ? [200, 60, 60] : [60, 60, 200]));
    const f = flatFrame(img, 64, 64);
    expect(f.levels).toBe(2);
    expect(f.hint).toMatch(/only 2 lightness levels/);
  });
});

describe('desktop decides: a clearly empty or flat screen fails (crazygames, 1280×720 and 821×462)', () => {
  const noise = (x: number, y: number, s = 1) => (hash(x + y * 997, s) - 0.5) * 40;
  it('the largest featureless rectangle in a grid of cells', () => {
    // 4×3: a 2×3 empty column on the right, a lone empty cell left
    const g = [1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1];
    expect(largestRect(g, 4, 3)).toBe(6);
    expect(largestRect([0, 0, 0, 0], 2, 2)).toBe(0);
    expect(largestRect([1, 1, 1, 1], 2, 2)).toBe(4);
  });
  it('limits: one colour ≥ 70 %, featureless ≥ 80 %, one featureless area ≥ 40 % of the screen', () => {
    expect(FLAT_FAIL_LIMITS).toEqual({ topShare: 0.7, uniformShare: 0.8, emptyRect: 0.4 });
  });
  it('a bare background with a small panel in the middle (Germ Dodge before its dish) fails on one colour and featureless', () => {
    const img = image(320, 180, (x, y) => (x > 110 && x < 210 && y > 50 && y < 130 ? [20 + noise(x, y), 60 + noise(x, y), 70] : [15, 34, 48]));
    const why = emptyLayout(flatFrame(img, 320, 180)).join('; ');
    expect(why).toMatch(/% of the screen is one flat colour \(#002233; over 70% fails\)/);
    expect(why).toMatch(/featureless \(over 80% fails\)/);
  });
  it('detail on one half, a bare backdrop on the other: one featureless area of half the screen fails', () => {
    const img = image(320, 180, (x, y) => (x < 160 ? [80 + noise(x, y), 90 + noise(x, y, 2), 100 + noise(x, y, 3)] : [10 + y * 0.2, 20 + y * 0.2, 40 + y * 0.2]));
    const f = flatFrame(img, 320, 180);
    expect(f.emptyRect).toBeGreaterThan(0.45);
    expect(f.topShare).toBeLessThan(0.7);
    expect(emptyLayout(f).join()).toMatch(/one featureless area covers \d+% of the screen \(over 40% fails\)/);
  });
  it('a textured screen everywhere passes', () => {
    const img = image(320, 180, (x, y) => [60 + noise(x, y) + y * 0.3, 70 + noise(x, y, 2), 90 + noise(x, y, 3)]);
    const f = flatFrame(img, 320, 180);
    expect(emptyLayout(f)).toEqual([]);
    expect(flatText(f)).toMatch(/the largest featureless area \d+%/);
  });
});
