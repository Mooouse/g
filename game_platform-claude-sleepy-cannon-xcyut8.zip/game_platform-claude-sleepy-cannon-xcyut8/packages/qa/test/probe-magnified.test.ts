// The probe's magnified-bitmap watch (E_QA_BITMAP_MAGNIFIED) in a real page: a sharp sprite drawn 16× is counted, a
// soft radial glow drawn 16× is not (Candle Crypt's glow failed before the calibration of 2026-10-19), a render target
// that is blank at its first draw and sharp later is counted once it is drawn

import { chromium } from 'playwright';
import { describe, expect, it } from 'vitest';
import { installProbe } from '../src/probe.ts';

describe('bitmaps drawn magnified (installProbe)', () => {
  it('a soft glow magnified is not mush; a sharp sprite and a later-drawn render target are', async () => {
    const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
    try {
      const page = await browser.newPage({ viewport: { width: 1024, height: 1024 } });
      await page.setContent('<canvas id="c" width="1024" height="1024" style="width:1024px;height:1024px"></canvas>');
      await page.evaluate(installProbe);
      const mags = await page.evaluate(async () => {
        const g = (document.getElementById('c') as HTMLCanvasElement).getContext('2d')!;
        // Entries are one per source size and screen: the glow and the sprite get sizes of their own
        const make = (n: number, paint: (x: CanvasRenderingContext2D) => void) => {
          const c = document.createElement('canvas');
          c.width = c.height = n;
          paint(c.getContext('2d')!);
          return c;
        };
        const glow = make(48, (x) => {
          const gr = x.createRadialGradient(24, 24, 0, 24, 24, 24);
          gr.addColorStop(0, 'rgba(255,255,255,1)');
          gr.addColorStop(0.45, 'rgba(255,255,255,0.75)');
          gr.addColorStop(1, 'rgba(255,255,255,0)');
          x.fillStyle = gr;
          x.fillRect(0, 0, 48, 48);
        });
        const sprite = make(64, (x) => {
          x.fillStyle = '#c33';
          x.fillRect(16, 16, 32, 32);
        });
        g.drawImage(glow, 0, 0, 1024, 1024);
        g.drawImage(sprite, 0, 0, 1024, 1024);
        // A render target: blank at its first draw (soft), sharp 2 s later
        const target = document.createElement('canvas');
        target.width = target.height = 32;
        g.drawImage(target, 0, 0, 512, 512);
        await new Promise((r) => setTimeout(r, 2100));
        const t = target.getContext('2d')!;
        t.fillStyle = '#fff';
        t.fillRect(0, 0, 16, 16);
        g.drawImage(target, 0, 0, 512, 512);
        return [...(window as any).__gpProbe.mags.values()].map((m: { w: number; scale: number }) => `${m.w}@${Math.round(m.scale)}`);
      });
      expect(mags.sort()).toEqual(['32@16', '64@16']);
    } finally {
      await browser.close();
    }
  }, 30000);
});
