// The icon glyphs gp qa finds on screen and gp review in the code (@gp/qa/glyphs)

import { describe, expect, it } from 'vitest';
import { glyphsIn, iconGlyphs, ICON_GLYPH_SOURCE, TEXT_ARROW_SOURCE, withoutTextArrows } from '../src/glyphs.ts';

describe('glyphs as icons', () => {
  it('the symbol blocks, not only emoji: ◆ ✓ ✕ ◎ ● ▌ ▶ ◀ ⚡ ★ ♫ → ⌛ ─ and 🔒 💎', () => {
    expect(glyphsIn('◆ ✓ ✕ ◎ ● ▌ ▶ ◀ ⚡ ★ ♫ → ⌛ ─ ⬆ 🔒 💎 🟢')).toEqual(['◆', '✓', '✕', '◎', '●', '▌', '▶', '◀', '⚡', '★', '♫', '→', '⌛', '─', '⬆', '🔒', '💎', '🟢']);
    // \p{Extended_Pictographic} alone (what gp review used) misses most of them
    expect('◆✓✕◎●▌'.match(/\p{Extended_Pictographic}/gu)?.length ?? 0).toBeLessThan(3);
  });
  it('text, numbers and the marks of a sentence are not icons: letters, ×2, €, ·, •, —, …, © ® ™', () => {
    expect(glyphsIn('Play again ×2 · 12,3 s • €5 — Next… © 2026 Qma® Bungee™ Привет 日本')).toEqual([]);
  });
  it('one fresh global regex per use (no lastIndex carried over), and its source for page.evaluate', () => {
    const a = iconGlyphs();
    expect(a.flags).toBe('gu');
    expect('✓✓'.match(a)).toHaveLength(2);
    expect(new RegExp(ICON_GLYPH_SOURCE, 'u').test('▶')).toBe(true);
  });
  it('an arrow of running text is typography, not an icon (the calibration: Garage, Hang the Moon, Candle Crypt)', () => {
    // Between two words or numbers: the approved games' "×1.0 → ×1.1" and the rejected one's route line
    expect(glyphsIn('Power ×1.0 → ×1.1', true)).toEqual([]);
    expect(glyphsIn('The Drowned Catacombs → the lich', true)).toEqual([]);
    expect(glyphsIn('Rods tip 1° further → 12 %', true)).toEqual([]);
    expect(glyphsIn('10 % → 20 %', true)).toEqual([]);
    // Alone, or at either end of a label, it stands for an icon; Geometric Shapes (▶ ◀) are never text
    expect(glyphsIn('← Back', true)).toEqual(['←']);
    expect(glyphsIn('Next →', true)).toEqual(['→']);
    expect(glyphsIn('→', true)).toEqual(['→']);
    expect(glyphsIn('Wave 1 ▶ Wave 2', true)).toEqual(['▶']);
    expect(glyphsIn('★ 3 → 4', true)).toEqual(['★']);
    // The code scan (gp review) still reads every arrow; the source runs in page.evaluate
    expect(glyphsIn('Power ×1.0 → ×1.1')).toEqual(['→']);
    expect(withoutTextArrows('a → b')).toBe('a   b');
    expect(new RegExp(TEXT_ARROW_SOURCE, 'u').test('x → y')).toBe(true);
  });
});
