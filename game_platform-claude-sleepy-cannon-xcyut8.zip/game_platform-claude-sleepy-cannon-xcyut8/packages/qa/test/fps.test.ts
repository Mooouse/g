import { describe, expect, it } from 'vitest';
import { judgeFps } from '../src/probe.ts';

const busy = { busy: true, text: 'load 2.10 per core' };
const idle = { busy: false, text: 'load 0.10 per core' };

describe('judgeFps: the engine told from the machine', () => {
  it('passes a smooth sample, or a smooth re-run', () => {
    expect(judgeFps([{ fps: 59.8, mainMs: 3, ran: true }], null).ok).toBe(true);
    expect(judgeFps([{ fps: 38, mainMs: 4, ran: true }, { fps: 57, mainMs: 3, ran: true }], busy).ok).toBe(true);
  });
  it('passes slow frames on a busy machine when the page needs little main-thread time (the engine lab: 31–49 fps under parallel QA)', () => {
    const v = judgeFps([{ fps: 31, mainMs: 4.2, ran: true }, { fps: 44, mainMs: 3.9, ran: true }], busy);
    expect(v.ok).toBe(true);
    expect(v.text).toMatch(/the machine's, not the game's/);
  });
  it("fails slow frames on a busy machine when the page's own work per frame is heavy", () => {
    const v = judgeFps([{ fps: 31, mainMs: 28, ran: true }, { fps: 33, mainMs: 27, ran: true }], busy);
    expect(v.ok).toBe(false);
    expect(v.text).toMatch(/main thread is busy too/);
  });
  it('fails slow frames on an idle machine, and when the main-thread time is unknown', () => {
    expect(judgeFps([{ fps: 35.7, mainMs: 2, ran: true }], idle).ok).toBe(false);
    expect(judgeFps([{ fps: 31, mainMs: null, ran: true }, { fps: 40, mainMs: null, ran: true }], busy).ok).toBe(false);
  });
});
