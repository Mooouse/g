// The probe's canvas text records merged into the texts a player sees (mergeCanvasTexts): the passes of one outlined
// number (a drop shadow, an outline-only pass, the face), a stroke-then-fill tag, fading and off-screen texts

import { describe, expect, it } from 'vitest';
import { mergeCanvasTexts } from '../src/probe.ts';

const rec = (o: Partial<Parameters<typeof mergeCanvasTexts>[0][number]>) => ({ text: '0', kind: 'fill' as const, px: 28, x: 100, y: 40, w: 16, h: 28, color: '#ffffff', alpha: 1, shadow: null, ...o });

describe('canvas text as the player sees it', () => {
  it("drawNumber's passes (shadow 2 px lower, an outline with a transparent fill, the gradient face) are one text, outlined", () => {
    const t = mergeCanvasTexts([
      rec({ color: 'rgba(5, 5, 10, 0.55)', y: 42 }),
      rec({ kind: 'stroke', color: '#120a06' }),
      rec({ color: 'rgba(0, 0, 0, 0)' }),
      rec({ color: null }),
    ]);
    expect(t).toHaveLength(1);
    expect(t[0]).toMatchObject({ text: '0', color: null, outline: '#120a06', y: 40 });
  });
  it('a stroke then a fill: the stroke is the outline; a stroke alone is the text', () => {
    expect(mergeCanvasTexts([rec({ text: '+100', kind: 'stroke', color: '#120a06' }), rec({ text: '+100', color: '#ffd38a' })])).toEqual([
      expect.objectContaining({ text: '+100', color: '#ffd38a', outline: '#120a06' }),
    ]);
    expect(mergeCanvasTexts([rec({ kind: 'stroke', color: '#00ff00' })])[0]).toMatchObject({ color: '#00ff00' });
  });
  it('drops fading texts, invisible fills and texts off the screen; keeps the same text elsewhere apart', () => {
    expect(mergeCanvasTexts([rec({ alpha: 0.3 }), rec({ color: '#ffffff00' }), rec({ x: 2000 })], { width: 1280, height: 720 })).toEqual([]);
    expect(mergeCanvasTexts([rec({}), rec({ x: 300 })])).toHaveLength(2);
  });
});
