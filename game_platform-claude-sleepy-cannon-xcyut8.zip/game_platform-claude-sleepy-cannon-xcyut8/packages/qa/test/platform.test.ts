import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { platformCommit } from '../src/index.ts';

describe('the platform commit in the QA report', () => {
  it('names this checkout: a short hash and the commit date', () => {
    expect(platformCommit()).toMatch(/^[0-9a-f]{7,} \d{4}-\d{2}-\d{2}$/);
  });
  it('is null outside a git checkout (a copied platform), never an exception', () => {
    const dir = mkdtempSync(join(tmpdir(), 'gp-no-git-'));
    try {
      expect(platformCommit(dir)).toBeNull();
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});
