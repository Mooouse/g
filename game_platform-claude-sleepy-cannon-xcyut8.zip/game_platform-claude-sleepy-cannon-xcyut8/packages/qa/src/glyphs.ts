// Characters that stand in for drawn icons: emoji and the Unicode symbol blocks fonts draw as icons (◆ ✓ ✕ ◎ ● ▌ ▶ ◀
// ⚡ 🔒). Frankengun's review found them in its HUD and on the platform's own screens; Candle Crypt's owner asked for
// every one to be a drawn icon in the game's style («Везде где используются эмодзи замени их на нарисованные иконки в
// стиле игры»). `\p{Extended_Pictographic}` alone (what gp review looked for) misses ◆ ✓ ✕ ◎ ● ▌: they are symbols, not
// emoji. Pure: gp qa scans the visible text with it in the page, gp review the game's code and strings.

/**
 * The blocks: Arrows (2190–21FF), Misc Technical (2300–23FF), Box Drawing and Block Elements (2500–259F), Geometric
 * Shapes (25A0–25FF), Misc Symbols (2600–26FF), Dingbats (2700–27BF), Supplemental Arrows A and B (27F0–27FF,
 * 2900–297F), Misc Symbols and Arrows (2B00–2BFF), Geometric Shapes Extended (1F780–1F7FF) — and every emoji
 * (Extended_Pictographic) but © ® ™, which are marks in a sentence, not icons
 */
export const ICON_GLYPH_SOURCE =
  '[\\u2190-\\u21FF\\u2300-\\u23FF\\u2500-\\u259F\\u25A0-\\u25FF\\u2600-\\u26FF\\u2700-\\u27BF\\u27F0-\\u27FF\\u2900-\\u297F\\u2B00-\\u2BFF\\u{1F780}-\\u{1F7FF}]|(?![\\u00A9\\u00AE\\u2122])\\p{Extended_Pictographic}';

/**
 * An arrow inside running text, between two words or numbers ("Power ×1.0 → ×1.1", "The Drowned Catacombs → the lich"),
 * is typography — a sign of change or of a route, like a dash — not an icon. The calibration of 2026-10-19
 * (docs/research/qa-calibration-2026-10.md) found it on both approved games and a rejected one, never what a reviewer
 * minded. An arrow alone, or at the start or end of a label ("← Back", "Next ▶"), still counts. The Arrows blocks only
 * (2190–21FF, 27F0–27FF, 2900–297F): ▶ ◀ are Geometric Shapes and stay icons
 */
export const TEXT_ARROW_SOURCE = '(?<=[\\p{L}\\p{N}%)\\]°][ \\u00A0]*)[\\u2190-\\u21FF\\u27F0-\\u27FF\\u2900-\\u297F](?=[ \\u00A0]*[\\p{L}\\p{N}×(\\[$€£+\\-−])';

/** The text without its arrows of running text (TEXT_ARROW_SOURCE), what the icon-glyph scan of visible text reads */
export const withoutTextArrows = (text: string): string => text.replace(new RegExp(TEXT_ARROW_SOURCE, 'gu'), ' ');

/** A fresh global regex for the icon glyphs (a /g regex keeps its lastIndex: one per use) */
export const iconGlyphs = (): RegExp => new RegExp(ICON_GLYPH_SOURCE, 'gu');

/** The distinct icon glyphs in a text, in order of first appearance (`visible`: a text on screen, its arrows of running text not counted) */
export function glyphsIn(text: string, visible = false): string[] {
  return [...new Set((visible ? withoutTextArrows(text) : text).match(iconGlyphs()) ?? [])];
}
