// Engine-level probes for QA, after the engine lab (QmaCyber/game12, tools/measure.mjs: its behaviour and webgl
// sections). gp qa passed every lab variant while it had engine bugs only these probes saw: Pixi's 60 rAF callbacks a
// second on the menus, Phaser resuming the sound during an ad, Kaplay's second AudioContext and its Tab trap, a blank
// canvas after a WebGL context loss. Kit-agnostic: the code kit's suite and the portal checks use them.
//
// installProbe() is an init script (it runs before the page's own scripts) that counts and records:
//   - requestAnimationFrame callbacks the page ran (QA's own loops use the unwrapped `rawRaf`);
//   - canvas frames: tasks that drew on a canvas in the document (2D or WebGL draw calls; offscreen canvases don't count);
//   - every AudioContext made, every audio connection (connect/disconnect followed), every sound started, every
//     <audio>/<video> play();
//   - every canvas context asked for (type, granted or not), unhandled promise rejections.

import { cpus, loadavg } from 'node:os';
import type { Page } from 'playwright';

/** What a game draws on the canvas that a player reads or taps (host.qa({ canvasUi })), CSS px of the viewport */
export interface CanvasUiRect {
  name: string;
  kind: 'text' | 'button';
  x: number;
  y: number;
  w: number;
  h: number;
  fontPx?: number;
  /** The words drawn there (concept.twist.explained is looked for in them) */
  text?: string;
}

/** The iframe sizes CrazyGames checks legibility at, devicePixelRatio 1 (docs: requirements/gameplay); the smallest bind the HUD */
export const PORTAL_FRAMES = [
  { name: 'desktop-821x462', width: 821, height: 462 },
  { name: 'mobile-800x450', width: 800, height: 450 },
];
/** Smallest text we accept at DPR 1 (CSS px): DOM text is measured, canvas text is what the game declares (canvasUi) */
export const MIN_TEXT_PX = 12;

/** Text smaller than MIN_TEXT_PX, and controls or content outside the frame */
export async function legibility(page: Page): Promise<{ small: string[]; outside: string[]; scroll: boolean }> {
  return page.evaluate((min) => {
    const small = new Set<string>();
    const outside: string[] = [];
    // Visually hidden on purpose — the sr-only pattern, text for a screen reader such as the dialogue's aria-live
    // .gp-live (Frankengun's QA flagged it as cut off): a box of 1 px or less that clips, clip: rect() of no area,
    // clip-path: inset(50%), or a live region placed off screen
    const srOnly = (el: Element) => {
      for (let p: Element | null = el; p && p !== document.body; p = p.parentElement) {
        const st = getComputedStyle(p);
        const b = p.getBoundingClientRect();
        if (b.width <= 1.5 && b.height <= 1.5 && /(hidden|clip)/.test(st.overflowX + st.overflowY)) return true;
        const rect = /^(absolute|fixed)$/.test(st.position) ? st.clip.match(/rect\(([^)]*)\)/) : null;
        const [t, r, bt, l] = rect ? rect[1]!.split(/[\s,]+/).map((v) => parseFloat(v)) : [];
        if (rect && [t, r, bt, l].every((v) => Number.isFinite(v)) && r! - l! <= 1 && bt! - t! <= 1) return true;
        if (/inset\(\s*(5\d|[6-9]\d|100)(\.\d+)?%/.test(st.clipPath)) return true;
        const live = p.hasAttribute('aria-live') || /^(status|alert|log|timer|marquee)$/.test(p.getAttribute('role') ?? '');
        if (live && (b.right <= 0 || b.bottom <= 0 || b.left >= innerWidth || b.top >= innerHeight)) return true;
      }
      return false;
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const text = n.textContent?.trim();
      const el = n.parentElement;
      if (!text || !el) continue;
      const st = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      if (st.visibility === 'hidden' || st.display === 'none' || r.width === 0 || r.height === 0 || Number(st.opacity) === 0 || srOnly(el)) continue;
      if (parseFloat(st.fontSize) < min - 0.01) small.add(`"${text.slice(0, 24)}" ${parseFloat(st.fontSize).toFixed(1)}px`);
    }
    for (const el of document.querySelectorAll<HTMLElement>('button, [role=button], a[href], input, select')) {
      const r = el.getBoundingClientRect();
      const st = getComputedStyle(el);
      if (r.width === 0 || r.height === 0 || st.visibility === 'hidden' || st.display === 'none') continue;
      if (r.left < -1 || r.top < -1 || r.right > innerWidth + 1 || r.bottom > innerHeight + 1) outside.push((el.textContent || el.tagName).trim().slice(0, 24));
    }
    const scroll = document.documentElement.scrollWidth > innerWidth + 1 || document.documentElement.scrollHeight > innerHeight + 1;
    return { small: [...small], outside, scroll };
  }, MIN_TEXT_PX);
}

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  interface Window {
    __gpProbe: any;
  }
}

/** The init script: `context.addInitScript(installProbe)`. Self-contained (Playwright sends its source) */
export function installProbe(): void {
  const w = window as any;
  if (w.__gpProbe) return;
  const p: any = (w.__gpProbe = { raf: 0, frames: 0, contexts: [], sources: [], media: [], asked: [], rejections: [] });
  const raw = w.requestAnimationFrame.bind(w);
  p.rawRaf = raw;
  w.requestAnimationFrame = (cb: FrameRequestCallback) =>
    raw((t: number) => {
      p.raf++;
      cb(t);
    });
  // A canvas frame: one task (a rAF callback, a timer, an event) that drew on a canvas in the document, counted once
  let marked = false;
  const unmark = () => {
    marked = false;
  };
  const mark = (c: any) => {
    if (marked || !c || c.isConnected !== true) return;
    marked = true;
    p.frames++;
    queueMicrotask(unmark);
  };
  const wrap = (proto: any, names: string[]) => {
    if (!proto) return;
    for (const n of names) {
      const f = proto[n];
      if (typeof f !== 'function') continue;
      proto[n] = function (this: any, ...a: unknown[]) {
        mark(this.canvas);
        return f.apply(this, a);
      };
    }
  };
  wrap(w.CanvasRenderingContext2D?.prototype, ['fillRect', 'strokeRect', 'clearRect', 'fill', 'stroke', 'drawImage', 'fillText', 'strokeText', 'putImageData']);
  // Bitmaps drawn magnified on a canvas in the document: the source's pixels per device pixel of the screen (the
  // context's transform × the destination size × how much the page scales the canvas up). Garage's «Пиксельное месиво»:
  // small sprites drawn 2–3× their size, smoothed into mush. Crisp pixel art (imageSmoothingEnabled false) is meant to
  // be scaled up, and a source under 16 px a side (a gradient strip, a pattern) is stretched on purpose: neither counts.
  // A soft source (a radial glow, a blurred cloud: no step between neighbouring pixels over SOFT_STEP of 255) loses
  // nothing magnified — Candle Crypt's 64-px glow drawn 16–32× failed the check before 2026-10-19
  // (docs/research/qa-calibration-2026-10.md) — so it is not counted. Measured once per image, a canvas again every 2 s
  // (a render target drawn later). One entry per source size and screen, the largest scale kept (at most 200 entries)
  const mags: Map<string, any> = (p.mags = new Map());
  const SOFT_STEP = 24;
  const softness = new WeakMap<object, { soft: boolean; at: number }>();
  const C2D = w.CanvasRenderingContext2D?.prototype;
  if (C2D && typeof C2D.drawImage === 'function') {
    const drawImage = C2D.drawImage;
    let screenAt = -1e9;
    let screenWas = 'first screen';
    // The screen the game says it is on (host.screen), looked up at most every 100 ms
    const screenNow = () => {
      const now = performance.now();
      if (now - screenAt < 100) return screenWas;
      screenAt = now;
      return (screenWas = screenOf());
    };
    const screenOf = () => {
      try {
        const log = w.__gp?.events?.log;
        if (w.__gp?.host?.isPlaying) return 'play';
        for (let i = (log?.length ?? 0) - 1; i >= 0; i--) if (log[i].type === 'screen') return String(log[i].data?.name ?? '?');
      } catch {
        // no host yet
      }
      return 'first screen';
    };
    const label = (img: any): string => {
      if (typeof HTMLImageElement !== 'undefined' && img instanceof HTMLImageElement) return (img.currentSrc || img.src || 'img').split(/[?#]/)[0].split('/').pop()!.slice(0, 40) || 'img';
      if (typeof HTMLCanvasElement !== 'undefined' && img instanceof HTMLCanvasElement) return 'a canvas';
      if (typeof OffscreenCanvas !== 'undefined' && img instanceof OffscreenCanvas) return 'an OffscreenCanvas';
      if (typeof ImageBitmap !== 'undefined' && img instanceof ImageBitmap) return 'an ImageBitmap';
      return 'an image';
    };
    let scratch: CanvasRenderingContext2D | null = null;
    // The largest step between neighbouring pixels (premultiplied RGBA, 0–255) of the source, read at most 128 px a side
    const isSoft = (img: any, iw: number, ih: number): boolean => {
      const live = (typeof HTMLCanvasElement !== 'undefined' && img instanceof HTMLCanvasElement) || (typeof OffscreenCanvas !== 'undefined' && img instanceof OffscreenCanvas);
      const now = performance.now();
      const was = softness.get(img);
      if (was && (!live || now - was.at < 2000)) return was.soft;
      let soft = false;
      try {
        const sw = Math.min(128, iw);
        const sh = Math.min(128, ih);
        if (!scratch) scratch = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
        if (scratch) {
          scratch.canvas.width = sw;
          scratch.canvas.height = sh;
          scratch.clearRect(0, 0, sw, sh);
          drawImage.call(scratch, img, 0, 0, sw, sh);
          const d = scratch.getImageData(0, 0, sw, sh).data;
          let max = 0;
          const at = (i: number, c: number) => (c === 3 ? d[i + 3] : (d[i + c] * d[i + 3]) / 255);
          for (let y = 0; y < sh && max <= SOFT_STEP; y++)
            for (let x = 0; x < sw; x++) {
              const i = (y * sw + x) * 4;
              for (let c = 0; c < 4; c++) {
                const v = at(i, c);
                if (x + 1 < sw) max = Math.max(max, Math.abs(v - at(i + 4, c)));
                if (y + 1 < sh) max = Math.max(max, Math.abs(v - at(i + sw * 4, c)));
              }
            }
          soft = max <= SOFT_STEP;
        }
      } catch {
        soft = false; // a cross-origin image can't be read: counted
      }
      softness.set(img, { soft, at: now });
      return soft;
    };
    C2D.drawImage = function (this: CanvasRenderingContext2D, img: any, ...a: number[]) {
      try {
        const c = this.canvas as HTMLCanvasElement;
        if (c && c.isConnected === true && this.imageSmoothingEnabled !== false && !(typeof HTMLVideoElement !== 'undefined' && img instanceof HTMLVideoElement)) {
          const iw = img.naturalWidth || img.videoWidth || img.width || 0;
          const ih = img.naturalHeight || img.videoHeight || img.height || 0;
          if (iw >= 16 && ih >= 16) {
            const sw = a.length >= 8 ? a[2] : iw;
            const sh = a.length >= 8 ? a[3] : ih;
            const dw = a.length >= 8 ? a[6] : a.length >= 4 ? a[2] : iw;
            const dh = a.length >= 8 ? a[7] : a.length >= 4 ? a[3] : ih;
            if (sw >= 16 && sh >= 16 && dw && dh) {
              const m = this.getTransform();
              // How many device pixels one backing-store pixel of the canvas covers on screen
              const page = c.clientWidth && c.width ? (c.clientWidth * (w.devicePixelRatio || 1)) / c.width : 1;
              const kx = (Math.abs(dw) / sw) * Math.hypot(m.a, m.b) * page;
              const ky = (Math.abs(dh) / sh) * Math.hypot(m.c, m.d) * page;
              const k = Math.min(kx, ky);
              if (k > 1.05 && !(k > 1.25 && isSoft(img, iw, ih))) {
                const screen = screenNow();
                const key = `${label(img)}|${iw}x${ih}|${screen}`;
                const e = mags.get(key);
                if (e) {
                  e.n++;
                  if (k > e.scale) e.scale = k;
                } else if (mags.size < 200) mags.set(key, { image: label(img), w: iw, h: ih, screen, scale: k, n: 1 });
              }
            }
          }
        }
      } catch {
        // measuring never breaks the game's drawing
      }
      return drawImage.call(this, img, ...a);
    };
  }
  // The faces canvas text is drawn in (fillText / strokeText): characters per CSS font family list, for the system-font
  // check (at most 100 lists)
  const canvasFonts: Map<string, number> = (p.canvasFonts = new Map());
  // While QA records (p.textLog an array: canvasTexts()), each canvas text drawn: its box and font size in CSS px of the
  // viewport, its colour (fill or stroke, with globalAlpha), a shadow — for the play text check (size and contrast)
  p.textLog = null;
  const recordText = (g: CanvasRenderingContext2D, name: string, text: string, x: number, y: number) => {
    const log = p.textLog as unknown[] | null;
    if (!log || log.length >= 600 || !text.trim()) return;
    const cv = g.canvas as HTMLCanvasElement;
    const r = cv.getBoundingClientRect();
    if (!cv.width || !cv.height || !r.width) return;
    const m = g.getTransform();
    const kx = r.width / cv.width;
    const ky = r.height / cv.height;
    const s = Math.sqrt(Math.abs(m.a * m.d - m.b * m.c));
    const px = parseFloat((String(g.font).match(/(\d+(?:\.\d+)?)px/) ?? [])[1] ?? '10') * s * ky;
    const w = g.measureText(text).width * s * kx;
    const cx = r.left + (m.a * x + m.c * y + m.e) * kx;
    const cy = r.top + (m.b * x + m.d * y + m.f) * ky;
    const al = g.textAlign;
    const rtl = g.direction === 'rtl';
    const left = al === 'center' ? cx - w / 2 : al === 'right' || (al === 'end' && !rtl) || (al === 'start' && rtl) ? cx - w : cx;
    const bl = g.textBaseline;
    const top = bl === 'top' || bl === 'hanging' ? cy : bl === 'middle' ? cy - px / 2 : cy - px * 0.8;
    const style = name === 'fillText' ? g.fillStyle : g.strokeStyle;
    log.push({
      text,
      kind: name === 'fillText' ? 'fill' : 'stroke',
      px,
      x: left,
      y: top,
      w,
      h: px,
      color: typeof style === 'string' ? style : null,
      alpha: g.globalAlpha,
      shadow: g.shadowColor && (g.shadowBlur > 0 || g.shadowOffsetX || g.shadowOffsetY) ? g.shadowColor : null,
      t: performance.now(),
    });
  };
  for (const name of ['fillText', 'strokeText']) {
    const f = C2D?.[name];
    if (typeof f !== 'function') continue;
    C2D[name] = function (this: CanvasRenderingContext2D, text: unknown, ...a: unknown[]) {
      try {
        if ((this.canvas as HTMLCanvasElement)?.isConnected === true) {
          const fam = String(this.font).replace(/^.*?\d+(\.\d+)?(px|pt|em|rem|%|vh|vw)(\/\S+)?\s+/, '');
          const n = String(text ?? '').replace(/\s+/g, '').length;
          if (n && (canvasFonts.has(fam) || canvasFonts.size < 100)) canvasFonts.set(fam, (canvasFonts.get(fam) ?? 0) + n);
          if (p.textLog) recordText(this, name, String(text ?? ''), Number(a[0]), Number(a[1]));
        }
      } catch {
        // never breaks the drawing
      }
      return f.call(this, text, ...a);
    };
  }
  for (const gl of [w.WebGLRenderingContext, w.WebGL2RenderingContext])
    wrap(gl?.prototype, ['drawArrays', 'drawElements', 'drawArraysInstanced', 'drawElementsInstanced', 'drawRangeElements', 'clear']);
  const getContext = HTMLCanvasElement.prototype.getContext;
  (HTMLCanvasElement.prototype as any).getContext = function (this: HTMLCanvasElement, type: string, ...a: unknown[]) {
    const c = (getContext as any).call(this, type, ...a);
    if (!p.asked.some((x: any) => x.canvas === this && x.type === type && x.ok === !!c)) p.asked.push({ canvas: this, type, ok: !!c });
    return c;
  };
  // Audio: every context, every connection, every sound started
  for (const name of ['AudioContext', 'webkitAudioContext']) {
    const AC = w[name];
    if (!AC || AC.__gpProbed) continue;
    const Probed = class extends AC {
      constructor(...a: unknown[]) {
        super(...a);
        p.contexts.push(this);
      }
    };
    (Probed as any).__gpProbed = true;
    w[name] = Probed;
    if (name === 'AudioContext' && w.webkitAudioContext === AC) w.webkitAudioContext = Probed;
  }
  const edges = (p.edges = new Map());
  if (w.AudioNode) {
    const connect = AudioNode.prototype.connect;
    (AudioNode.prototype as any).connect = function (this: AudioNode, dst: unknown, ...rest: unknown[]) {
      if (!edges.has(this)) edges.set(this, []);
      edges.get(this).push(dst);
      return (connect as any).call(this, dst, ...rest);
    };
    const disconnect = AudioNode.prototype.disconnect;
    (AudioNode.prototype as any).disconnect = function (this: AudioNode, ...a: unknown[]) {
      const list = edges.get(this);
      if (list) edges.set(this, a.length === 0 || typeof a[0] === 'number' ? [] : list.filter((n: unknown) => n !== a[0]));
      return (disconnect as any).apply(this, a);
    };
    for (const proto of [w.AudioScheduledSourceNode?.prototype, w.AudioBufferSourceNode?.prototype]) {
      if (!proto || !Object.prototype.hasOwnProperty.call(proto, 'start')) continue;
      const start = proto.start;
      proto.start = function (this: AudioNode, ...a: unknown[]) {
        // When it is heard (`when` on the context's clock, now if past) and which of the mixer's buses it plays on
        if (p.sources.length < 20000) p.sources.push({ node: this, t: performance.now(), when: typeof a[0] === 'number' ? a[0] : 0, now: this.context.currentTime, bus: p.busOf(this) });
        return start.apply(this, a);
      };
    }
  }
  if (w.HTMLMediaElement) {
    const play = HTMLMediaElement.prototype.play;
    HTMLMediaElement.prototype.play = function (this: HTMLMediaElement) {
      if (p.media.length < 5000) p.media.push({ t: performance.now(), silent: this.muted || this.volume === 0, src: String(this.currentSrc || this.src || '').slice(0, 60) });
      return play.call(this);
    };
  }
  /** Some path from `node` reaches the speakers without a gain at 0 on it; `stop` is a node the walk doesn't pass */
  p.audible = (node: any, stop: any = null, seen = new Set()): boolean => {
    if (!node || seen.has(node) || node === stop) return false;
    seen.add(node);
    if (node instanceof AudioDestinationNode) return true;
    if (node instanceof GainNode && node.gain.value === 0) return false;
    return (edges.get(node) || []).some((n: unknown) => n instanceof AudioNode && p.audible(n, stop, seen));
  };
  /** The mixer's bus a sound plays on (createMixer tags them __gpBus: 'music', 'ambient', 'sfx'), or null: none of them */
  p.busOf = (node: any): string | null => {
    const seen = new Set();
    const queue = [node];
    while (queue.length && seen.size < 400) {
      const n = queue.shift();
      if (!n || seen.has(n)) continue;
      seen.add(n);
      if (typeof n.__gpBus === 'string') return n.__gpBus;
      for (const m of edges.get(n) || []) if (m instanceof AudioNode) queue.push(m);
    }
    return null;
  };
  /** `target` is reachable from `node` */
  p.reaches = (node: any, target: any, seen = new Set()): boolean => {
    if (!node || seen.has(node)) return false;
    if (node === target) return true;
    seen.add(node);
    return (edges.get(node) || []).some((n: unknown) => n instanceof AudioNode && p.reaches(n, target, seen));
  };
  /** Some path from `node` reaches the speakers around `target` (any gain, muted or not) */
  p.bypasses = (node: any, target: any, seen = new Set()): boolean => {
    if (!node || seen.has(node) || node === target) return false;
    seen.add(node);
    if (node instanceof AudioDestinationNode) return true;
    return (edges.get(node) || []).some((n: unknown) => n instanceof AudioNode && p.bypasses(n, target, seen));
  };
  w.addEventListener('unhandledrejection', (e: PromiseRejectionEvent) => {
    const r = e.reason;
    p.rejections.push(String(r && r.message ? r.message : r).slice(0, 200));
  });
}

/** Counters right now (null: the probe isn't installed) */
async function counters(page: Page): Promise<{ raf: number; frames: number } | null> {
  return page.evaluate(() => (window.__gpProbe ? { raf: window.__gpProbe.raf as number, frames: window.__gpProbe.frames as number } : null));
}

/** One-off frames a still screen may draw in a window (a redraw on resize, an engine settling): more is a running loop */
export const QUIET_ALLOWANCE = 3;
/** How long a still screen is watched */
export const QUIET_WINDOW_MS = 1500;

/**
 * requestAnimationFrame callbacks and canvas frames over `ms` on a screen that should stand still (the title, the pause
 * screen, an ad). A loop that keeps running there costs a phone's battery and a laptop's fan for nothing — and under an
 * ad it competes with the ad
 */
export async function stillness(page: Page, ms = QUIET_WINDOW_MS): Promise<{ raf: number; frames: number; quiet: boolean; text: string } | null> {
  const a = await counters(page);
  if (!a) return null;
  await new Promise((r) => setTimeout(r, ms));
  const b = (await counters(page))!;
  const raf = b.raf - a.raf;
  const frames = b.frames - a.frames;
  const quiet = raf <= QUIET_ALLOWANCE && frames <= QUIET_ALLOWANCE;
  return { raf, frames, quiet, text: `${raf} rAF callbacks, ${frames} canvas frames in ${(ms / 1000).toFixed(1)} s (≤ ${QUIET_ALLOWANCE} allowed)` };
}

/** The page's sound, from the probe: AudioContexts, sounds started and whether they go through host.audio.out */
export interface AudioReport {
  contexts: number;
  /** Where each AudioContext was made: the host's, or not */
  others: number;
  /** Each of the others: its state now and the sounds started on it ("suspended, 0 sounds") */
  otherStates: string[];
  sounds: number;
  /** Sounds with a path to the speakers that avoids host.audio.out (the portal mute and the ad pause miss them) */
  bypass: number;
  /** Sounds started on another AudioContext than the host's */
  otherContext: number;
  /** <audio>/<video> elements played with sound (they bypass the host) */
  media: number;
  /** Of the sounds started since `since` (ms, performance.now): audible ones */
  audibleSince: number;
  startedSince: number;
  /** AudioContexts running right now */
  running: number;
}

export async function audioReport(page: Page, since = Infinity): Promise<AudioReport | null> {
  return page.evaluate((since) => {
    const p = window.__gpProbe;
    if (!p) return null;
    const host = (window as any).__gp?.host?.audio ?? null;
    const later = p.sources.filter((s: any) => s.t >= since);
    return {
      contexts: p.contexts.length,
      others: p.contexts.filter((c: AudioContext) => c !== host?.ctx).length,
      otherStates: p.contexts
        .filter((c: AudioContext) => c !== host?.ctx)
        .map((c: AudioContext) => `${c.state}, ${p.sources.filter((s: any) => s.node.context === c).length} sounds`),
      sounds: p.sources.length,
      bypass: host ? p.sources.filter((s: any) => p.bypasses(s.node, host.out)).length : p.sources.filter((s: any) => p.bypasses(s.node, null)).length,
      otherContext: p.sources.filter((s: any) => s.node.context !== host?.ctx).length,
      media: p.media.filter((m: any) => !m.silent).length,
      audibleSince: later.filter((s: any) => p.audible(s.node)).length + p.media.filter((m: any) => m.t >= since && !m.silent).length,
      startedSince: later.length + p.media.filter((m: any) => m.t >= since).length,
      running: p.contexts.filter((c: AudioContext) => c.state === 'running').length,
    };
  }, since);
}

/** The canvas contexts the page asked for: on which canvas, granted or not */
export async function canvasContexts(page: Page): Promise<{ canvas: string; type: string; ok: boolean }[]> {
  return page.evaluate(() =>
    (window.__gpProbe?.asked ?? []).map((a: any) => ({ canvas: a.canvas.id ? `#${a.canvas.id}` : a.canvas.isConnected ? 'canvas' : '(offscreen)', type: a.type, ok: a.ok })),
  );
}

// --- Pixels ------------------------------------------------------------------------------------------------------------

export interface Region {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface PixelStats {
  /** Share of the region's pixels that differ from the page's background colour */
  offBackground: number;
  /** Share of the region's pixels that differ from the region's own most common colour (0: one flat colour) */
  varied: number;
}

/**
 * Pixel statistics of a screenshot of `page` in each region (CSS px; the whole viewport by default). `hideDom`: the DOM
 * layers over the canvas are hidden for the shot (what the canvas alone shows), then put back. The PNG is decoded in the
 * page itself (createImageBitmap), so no image library is needed
 */
export async function pixelStats(page: Page, regions?: Region[], opts: { hideDom?: boolean; path?: string } = {}): Promise<PixelStats[]> {
  if (opts.hideDom) await domHidden(page, true);
  let png: Buffer;
  try {
    png = await page.screenshot({ scale: 'css', path: opts.path });
  } finally {
    if (opts.hideDom) await domHidden(page, false);
  }
  return page.evaluate(
    async ({ b64, regions }) => {
      const bin = atob(b64);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      const bmp = await createImageBitmap(new Blob([u8], { type: 'image/png' }));
      const W = bmp.width;
      const H = bmp.height;
      const c = new OffscreenCanvas(W, H);
      const g = c.getContext('2d', { willReadFrequently: true })!;
      g.drawImage(bmp, 0, 0);
      const d = g.getImageData(0, 0, W, H).data;
      const parse = (s: string) => (s.match(/[\d.]+/g) ?? []).map(Number);
      let bg = parse(getComputedStyle(document.body).backgroundColor);
      if (bg.length === 4 && bg[3] === 0) bg = parse(getComputedStyle(document.documentElement).backgroundColor);
      if (bg.length < 3 || (bg.length === 4 && bg[3] === 0)) bg = [255, 255, 255];
      const sx = W / innerWidth;
      const sy = H / innerHeight;
      const TH = 40;
      return (regions ?? [{ x: 0, y: 0, w: innerWidth, h: innerHeight }]).map((r) => {
        const x0 = Math.max(0, Math.floor(r.x * sx));
        const y0 = Math.max(0, Math.floor(r.y * sy));
        const x1 = Math.min(W, Math.ceil((r.x + r.w) * sx));
        const y1 = Math.min(H, Math.ceil((r.y + r.h) * sy));
        if (x1 <= x0 || y1 <= y0) return { offBackground: 0, varied: 0 };
        // Large regions are sampled (every 2nd pixel on each axis); small ones fully
        const step = (x1 - x0) * (y1 - y0) > 200000 ? 2 : 1;
        const counts = new Map<number, number>();
        let n = 0;
        let off = 0;
        for (let y = y0; y < y1; y += step)
          for (let x = x0; x < x1; x += step) {
            const i = (y * W + x) * 4;
            const R = d[i];
            const G = d[i + 1];
            const B = d[i + 2];
            n++;
            if (Math.abs(R - bg[0]) + Math.abs(G - bg[1]) + Math.abs(B - bg[2]) > TH) off++;
            const k = ((R >> 3) << 10) | ((G >> 3) << 5) | (B >> 3);
            counts.set(k, (counts.get(k) ?? 0) + 1);
          }
        let mainKey = 0;
        let mainN = -1;
        for (const [k, v] of counts) if (v > mainN) [mainKey, mainN] = [k, v];
        const mr = (mainKey >> 10) << 3;
        const mg = ((mainKey >> 5) & 31) << 3;
        const mb = (mainKey & 31) << 3;
        let varied = 0;
        for (let y = y0; y < y1; y += step)
          for (let x = x0; x < x1; x += step) {
            const i = (y * W + x) * 4;
            if (Math.abs(d[i] - mr) + Math.abs(d[i + 1] - mg) + Math.abs(d[i + 2] - mb) > TH) varied++;
          }
        return { offBackground: off / n, varied: varied / n };
      });
    },
    { b64: png.toString('base64'), regions: regions ?? null },
  );
}

/** Hides (or shows again) everything in the page that is not a canvas: the game's DOM layer (#ui), notices, a test ad */
export async function domHidden(page: Page, hidden: boolean): Promise<void> {
  await page.evaluate((hidden) => {
    for (const el of Array.from(document.body.children) as HTMLElement[]) {
      if (el.tagName === 'CANVAS' || el.tagName === 'SCRIPT' || el.querySelector('canvas')) continue;
      if (hidden) {
        el.dataset.gpQaVis = el.style.visibility;
        el.style.visibility = 'hidden';
      } else if (el.dataset.gpQaVis !== undefined) {
        el.style.visibility = el.dataset.gpQaVis;
        delete el.dataset.gpQaVis;
      }
    }
  }, hidden);
}

// --- Frame rate --------------------------------------------------------------------------------------------------------

export const MIN_FPS = 50;

/** How busy the machine QA runs on is: the load per core, and the share of a core a short busy loop gets here */
export function machineLoad(ms = 200): { perCore: number; cpuShare: number; busy: boolean; text: string } {
  const perCore = loadavg()[0] / Math.max(1, cpus().length);
  const t0 = performance.now();
  const c0 = process.cpuUsage();
  // The calibration loop: on an idle core it gets ≈ all of the wall time; under parallel load much less
  while (performance.now() - t0 < ms);
  const used = process.cpuUsage(c0);
  const cpuShare = (used.user + used.system) / 1000 / (performance.now() - t0);
  const busy = perCore > 1 || cpuShare < 0.8;
  return { perCore, cpuShare, busy, text: `load ${perCore.toFixed(2)} per core, a calibration loop got ${Math.round(cpuShare * 100)} % of a core` };
}

export interface FpsSample {
  fps: number;
  /** Main-thread CPU time per frame (ms): the page's scripts, style, layout and paint; null when not measured */
  mainMs: number | null;
  /**
   * The game's own requestAnimationFrame loop ran through the window (its callbacks ≥ 80 % of the frames): false when the
   * run ended or the loop stood still meanwhile, so the sample says nothing about the game; null without the probe
   */
  ran: boolean | null;
  /** The game's requestAnimationFrame callbacks per displayed frame: ≈ 1 for one loop, ≈ 2 when a second loop runs (null without the probe) */
  loops: number | null;
}

/**
 * The frame-rate verdict. The engine lab's fps check failed 2–5 times per WebGL variant at 31–49 fps only because other
 * QA runs shared the CPU; the same code ran at 52–60 fps on an idle machine. So: a sample under MIN_FPS is measured again
 * once (the caller does it when the machine is busy), and when the machine is busy and the page's main thread needs
 * little time per frame (≤ 10 ms of the 16.7 ms a frame has), the lost frames are the machine's, not the game's
 */
export function judgeFps(samples: FpsSample[], load: { busy: boolean; text: string } | null): { ok: boolean; text: string } {
  const best = samples.reduce((a, b) => (b.fps > a.fps ? b : a), samples[0]);
  const ms = (s: FpsSample) => (s.mainMs === null ? '' : `, main thread ${s.mainMs.toFixed(1)} ms per frame`);
  const all = samples.map((s) => `${s.fps.toFixed(1)} fps${ms(s)}`).join('; re-run: ');
  if (best.fps >= MIN_FPS) return { ok: true, text: all };
  const light = samples.every((s) => s.mainMs !== null && s.mainMs <= 10);
  if (load?.busy && light) return { ok: true, text: `${all} — the machine is busy (${load.text}) and the page needs little main-thread time per frame: the lost frames are the machine's, not the game's` };
  if (load?.busy) return { ok: false, text: `${all} — the machine is busy (${load.text}), but the page's main thread is busy too: the game's own work per frame is too much` };
  return { ok: false, text: `${all}${load ? ` — on a machine that isn't busy (${load.text})` : ''}` };
}

/**
 * Frames per second over `ms` while the game runs, and the main thread's busy time per frame (Chrome DevTools Protocol
 * Performance.getMetrics: ThreadTime, the CPU time; TaskDuration where it is missing). QA's own loop uses the unwrapped
 * requestAnimationFrame
 */
export async function sampleFps(page: Page, ms = 2000): Promise<FpsSample> {
  let cdp: import('playwright').CDPSession | null = null;
  const task = async () => {
    if (!cdp) return null;
    const m = (await cdp.send('Performance.getMetrics')) as { metrics: { name: string; value: number }[] };
    // ThreadTime: the main thread's CPU time — unlike TaskDuration (wall time) it doesn't grow when other processes take
    // the CPU, so it is the page's own cost per frame on a busy machine too
    const t = m.metrics.find((x) => x.name === 'ThreadTime') ?? m.metrics.find((x) => x.name === 'TaskDuration');
    return t?.value ?? null;
  };
  try {
    cdp = await page.context().newCDPSession(page);
    await cdp.send('Performance.enable');
  } catch {
    cdp = null;
  }
  await page.evaluate(() => {
    const raf = window.__gpProbe?.rawRaf ?? requestAnimationFrame;
    const w = window as any;
    w.__gpFps = { n: 0, first: 0, last: 0, on: true };
    const f = (t: number) => {
      const s = w.__gpFps;
      if (!s.on) return;
      s.n++;
      if (s.n === 1) s.first = t;
      s.last = t;
      raf(f);
    };
    raf(f);
  });
  // A few frames to settle, then the window
  await new Promise((r) => setTimeout(r, 200));
  const a = await page.evaluate(() => ({ ...(window as any).__gpFps, game: window.__gpProbe?.raf ?? null }));
  const ta = await task();
  await new Promise((r) => setTimeout(r, ms));
  const b = await page.evaluate(() => {
    const s = (window as any).__gpFps;
    s.on = false;
    return { ...s, game: window.__gpProbe?.raf ?? null };
  });
  const tb = await task();
  await cdp?.detach().catch(() => {});
  const frames = b.n - a.n;
  const fps = frames > 0 && b.last > a.last ? (frames * 1000) / (b.last - a.last) : 0;
  return {
    fps,
    mainMs: ta !== null && tb !== null && frames > 0 ? ((tb - ta) * 1000) / frames : null,
    ran: a.game === null || b.game === null ? null : b.game - a.game >= frames * 0.8,
    loops: a.game === null || b.game === null || frames <= 0 ? null : (b.game - a.game) / frames,
  };
}

// --- Canvas text ---------------------------------------------------------------------------------------------------

/** A text drawn on a page canvas (fillText / strokeText) while QA recorded: its box and size in CSS px of the viewport */
export interface CanvasText {
  text: string;
  px: number;
  x: number;
  y: number;
  w: number;
  h: number;
  /** The fill's colour (a CSS colour string; null: a gradient or a pattern); `alpha` the globalAlpha it was drawn with */
  color: string | null;
  alpha: number;
  /** The colour of a strokeText of the same text at the same place (an outline), or a shadow */
  outline: string | null;
}

/**
 * The canvas text drawn in the next `ms` (the probe records only while asked: no cost otherwise): each text once per
 * place, on screen only; a fill and a stroke of the same text at the same place merged (the stroke is its outline)
 */
export async function canvasTexts(page: Page, ms = 300): Promise<CanvasText[]> {
  await page.evaluate(() => {
    const p = (window as any).__gpProbe;
    if (p) p.textLog = [];
  });
  await new Promise((r) => setTimeout(r, ms));
  const raw: any[] = await page.evaluate(() => {
    const p = (window as any).__gpProbe;
    const log = p?.textLog ?? [];
    if (p) p.textLog = null;
    return log;
  });
  return mergeCanvasTexts(raw, page.viewportSize());
}

/** A fill's colour alpha (a CSS colour string), 1 when it can't be told */
const styleAlpha = (s: string | null): number => {
  if (!s) return 1;
  const m = s.match(/^rgba?\(([^)]*)\)$/i);
  if (m) {
    const a = m[1].split(/[\s,/]+/).filter(Boolean)[3];
    return a === undefined ? 1 : a.endsWith('%') ? parseFloat(a) / 100 : parseFloat(a);
  }
  const h = s.match(/^#(?:[0-9a-f]{3}([0-9a-f])|[0-9a-f]{6}([0-9a-f]{2}))$/i);
  return h ? parseInt(h[1] ? h[1] + h[1] : h[2], 16) / 255 : 1;
};

/**
 * The probe's text records (in draw order) as the texts a player sees: the passes of one text at one place (within
 * 15 % of its size: a drop shadow a few px lower, an outline, a glow, then the face) are one text — the last visible fill
 * is its colour, the stroke or an earlier fill under it its outline. Invisible fills (alpha under 0.05: an outline-only
 * pass) and fading texts (globalAlpha under 0.5: a popup on its way out) are not the text; off-screen ones are dropped
 */
export function mergeCanvasTexts(raw: readonly { text: string; kind: 'fill' | 'stroke'; px: number; x: number; y: number; w: number; h: number; color: string | null; alpha: number; shadow?: string | null }[], view?: { width: number; height: number } | null): CanvasText[] {
  const out: (CanvasText & { filled: boolean })[] = [];
  for (const r of raw) {
    if (view && (r.x + r.w <= 0 || r.y + r.h <= 0 || r.x >= view.width || r.y >= view.height || r.w < 1)) continue;
    if (r.alpha < 0.5) continue;
    const tol = Math.max(3, r.px * 0.15);
    const e = out.find((t) => t.text === r.text && Math.abs(t.x - r.x) <= tol && Math.abs(t.y - r.y) <= tol);
    const visibleFill = r.kind === 'fill' && styleAlpha(r.color) * r.alpha >= 0.05;
    if (!e) {
      if (r.kind === 'fill' && !visibleFill) continue;
      out.push({ text: r.text, px: r.px, x: r.x, y: r.y, w: r.w, h: r.h, color: r.color, alpha: r.alpha, outline: r.kind === 'stroke' ? null : (r.shadow ?? null), filled: r.kind === 'fill' });
      if (r.kind === 'stroke') out[out.length - 1].outline = r.color;
      continue;
    }
    if (r.kind === 'stroke') {
      e.outline = r.color ?? e.outline;
      continue;
    }
    if (!visibleFill) continue;
    // A fill over an earlier pass: the earlier fill (a drop shadow) is behind it, so it outlines the face
    if (!e.outline) e.outline = e.color;
    Object.assign(e, { x: r.x, y: r.y, w: r.w, h: r.h, px: r.px, color: r.color, alpha: r.alpha, filled: true });
  }
  return out.map(({ text, px, x, y, w, h, color, alpha, outline }) => ({ text, px, x, y, w, h, color, alpha, outline }));
}
