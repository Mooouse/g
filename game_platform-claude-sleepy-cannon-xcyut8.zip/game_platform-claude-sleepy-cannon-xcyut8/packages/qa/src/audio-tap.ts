// The page's sound for `gp video --sound`, on the virtual clock (clock.ts). Frankengun mixed its soundtrack by hand from a
// log of every sound (2026-10-18): the recorder films one frame at a time, far slower than real time, while an
// AudioContext plays in real time, so a plain MediaRecorder would hear the game at the wrong speed.
//
// So the AudioContext is held still too. Installed before the page's own scripts (and before virtualClock, whose timers
// would otherwise be the ones it waits on), it wraps window.AudioContext: the game's first context gets a tap in front of
// its destination (every engine connects to `ctx.destination`, so the tap hears the host's mixer, three.js, Howler …),
// an AudioWorklet that copies what passes through, and resume()/suspend()/state that only record what the GAME wants.
// The real context stays suspended between frames; for each frame the recorder lets it run exactly one frame of audio
// (`__gpAudioRun`) and keeps those samples when the frame is filmed. In context time the frames follow each other
// without a gap, so the soundtrack is continuous and in step with the picture (within a few ms: one render quantum
// and the suspend's latency, never adding up). While the game wants its sound off (a pause, an ad, before the first
// tap) a frame is silence. Needs a secure context (the dev server on localhost is one) for the AudioWorklet.
//
//   await page.addInitScript(audioTap);           // first
//   await page.addInitScript(virtualClock);
//   … each frame: advanceClock(page, dt); await runAudio(page, dt, filmed);
//   const pcm = await takeAudio(page);            // { rate, pcm: 16-bit stereo, one frame's samples per kept frame }
//
// `gp qa`'s sound section listens the same way in real time (audioMeter, below): the context runs as the game wants, and
// a meter worklet in front of the destination reports every render quantum's loudness, peak, clipped samples and zero
// crossings — of the whole mix, and of the mixer's effects and music buses apart (createMixer tags them) — so a 30 s
// session is ≈ 150 K numbers, not 10 MB of samples.

import type { Page } from 'playwright';

/** Install with page.addInitScript(audioTap): it runs in the page, so it stays self-contained */
export const audioTap = (): void => {
  const Real = window.AudioContext;
  if (!Real) return;
  const w = window as unknown as Record<string, unknown>;
  // Real time, kept before virtualClock replaces setTimeout
  const sleep = window.setTimeout.bind(window);
  const resume0 = Real.prototype.resume;
  const suspend0 = Real.prototype.suspend;
  const stateOf = Object.getOwnPropertyDescriptor(BaseAudioContext.prototype, 'state')!.get!;
  const destinationOf = Object.getOwnPropertyDescriptor(BaseAudioContext.prototype, 'destination')!.get!;
  const QUANTUM = 128;
  type Chunk = [number, Float32Array, Float32Array];
  type Rec = {
    ctx: AudioContext;
    node: AudioWorkletNode | null;
    wanted: AudioContextState;
    chunks: Chunk[];
    /** The next sample (context time) a frame starts at, while the frames run back to back */
    head: number;
    running: boolean;
    /** What each kept frame is: [from, n] in context samples, or [-1, n] for silence */
    kept: [number, number][];
    error: string;
  };
  let rec: Rec | null = null;
  const WORKLET = `registerProcessor('gp-audio-tap', class extends AudioWorkletProcessor {
    constructor() { super(); this.buf = []; this.port.onmessage = () => { this.port.postMessage(this.buf); this.buf = []; this.port.postMessage('done'); }; }
    process(inputs) {
      const a = inputs[0];
      if (a && a.length) this.buf.push([currentFrame, a[0].slice(), (a[1] || a[0]).slice()]);
      if (this.buf.length >= 400) { this.port.postMessage(this.buf); this.buf = []; }
      return true;
    }
  });`;
  class TappedContext extends Real {
    constructor(...args: ConstructorParameters<typeof AudioContext>) {
      super(...args);
      // One AudioContext per game (the platform's rule): a second one plays unrecorded
      if (rec) return;
      const ctx = this as AudioContext;
      const real = destinationOf.call(ctx) as AudioDestinationNode;
      const bus = ctx.createGain();
      bus.connect(real);
      Object.defineProperty(bus, 'maxChannelCount', { value: real.maxChannelCount });
      // As in a browser that lets the page play sound: running until the game suspends it (gp video launches Chromium
      // with --autoplay-policy=no-user-gesture-required, so the recorder's own resume() is allowed)
      const r: Rec = { ctx, node: null, wanted: 'running', chunks: [], head: 0, running: false, kept: [], error: '' };
      rec = r;
      void suspend0.call(ctx).catch(() => {});
      Object.defineProperty(ctx, 'destination', { get: () => bus });
      Object.defineProperty(ctx, 'state', { get: () => (stateOf.call(ctx) === 'closed' ? 'closed' : r.wanted) });
      ctx.resume = () => ((r.wanted = 'running'), Promise.resolve());
      ctx.suspend = () => ((r.wanted = 'suspended'), Promise.resolve());
      if (!ctx.audioWorklet) {
        r.error = 'no AudioWorklet (not a secure context)';
        return;
      }
      const url = URL.createObjectURL(new Blob([WORKLET], { type: 'application/javascript' }));
      ctx.audioWorklet.addModule(url).then(
        () => {
          const node = new AudioWorkletNode(ctx, 'gp-audio-tap', { numberOfInputs: 1, numberOfOutputs: 0, channelCount: 2, channelCountMode: 'explicit' });
          node.port.onmessage = (e) => {
            if (Array.isArray(e.data)) for (const c of e.data as Chunk[]) r.chunks.push(c);
          };
          bus.connect(node);
          r.node = node;
        },
        (e: unknown) => (r.error = `the AudioWorklet failed: ${String(e)}`),
      );
    }
  }
  w.AudioContext = TappedContext;
  if (w.webkitAudioContext) w.webkitAudioContext = TappedContext;
  /** Let the context play `ms` of audio (when the game wants it to); keep = this frame is filmed */
  w.__gpAudioRun = async (ms: number, keep: boolean) => {
    const r = rec;
    if (!r) return;
    const rate = r.ctx.sampleRate;
    const n = Math.round((rate * ms) / 1000);
    const at = () => Math.round(r.ctx.currentTime * rate);
    if (r.wanted !== 'running' || !r.node || stateOf.call(r.ctx) === 'closed') {
      r.running = false;
      if (keep) r.kept.push([-1, n]);
      return;
    }
    // Back to back with the last frame (its overshoot belongs to this one), or from now after a stop
    if (!r.running) r.head = at();
    r.running = true;
    const from = r.head;
    r.head += n;
    if (at() < r.head) {
      await resume0.call(r.ctx);
      while (at() < r.head) await new Promise((ok) => sleep(ok, 1));
      await suspend0.call(r.ctx);
    }
    if (keep) r.kept.push([from, n]);
  };
  /** The kept frames' sound: 16-bit stereo PCM, base64 */
  w.__gpAudioTake = async () => {
    const r = rec;
    if (!r) return { rate: 0, pcm: '', error: 'the page made no AudioContext' };
    if (r.node) {
      const node = r.node;
      await new Promise<void>((ok) => {
        const prev = node.port.onmessage;
        node.port.onmessage = (e) => (e.data === 'done' ? ok() : prev?.call(node.port, e));
        node.port.postMessage('flush');
      });
    }
    const total = r.kept.reduce((s, [, n]) => s + n, 0);
    const out = new Int16Array(total * 2);
    // The chunks by their first sample (render quanta: 128 samples each)
    const byStart = new Map<number, Chunk>();
    for (const c of r.chunks) byStart.set(c[0], c);
    const first = r.chunks[0]?.[0] ?? 0;
    let o = 0;
    for (const [from, n] of r.kept) {
      for (let s = from; s < from + n; s++, o += 2) {
        if (from < 0) continue;
        const q = s - ((((s - first) % QUANTUM) + QUANTUM) % QUANTUM);
        const c = byStart.get(q);
        if (!c) continue;
        const i = s - q;
        out[o] = Math.max(-1, Math.min(1, c[1][i] ?? 0)) * 32767;
        out[o + 1] = Math.max(-1, Math.min(1, c[2][i] ?? 0)) * 32767;
      }
    }
    const bytes = new Uint8Array(out.buffer);
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return { rate: r.ctx.sampleRate, pcm: btoa(bin), error: r.error };
  };
};

/** One frame of the page's audio (audioTap): the context plays `ms`, kept in the soundtrack when `keep` */
export async function runAudio(page: Page, ms: number, keep: boolean): Promise<void> {
  await page.evaluate(([dt, k]) => (window as unknown as { __gpAudioRun: (ms: number, keep: boolean) => Promise<void> }).__gpAudioRun(dt, k), [ms, keep] as const);
}

/** The soundtrack of the kept frames: 16-bit little-endian stereo PCM at `rate` (rate 0: the page made no sound at all) */
export async function takeAudio(page: Page): Promise<{ rate: number; pcm: Buffer; error: string }> {
  const r = await page.evaluate(() => (window as unknown as { __gpAudioTake?: () => Promise<{ rate: number; pcm: string; error: string }> }).__gpAudioTake?.() ?? { rate: 0, pcm: '', error: 'audioTap is not installed' });
  return { rate: r.rate, pcm: Buffer.from(r.pcm, 'base64'), error: r.error };
}

/** Fade the PCM's last `sec` seconds out (16-bit stereo): the cut to the end card must not click */
export function fadeOut(pcm: Buffer, rate: number, sec: number): Buffer {
  const frames = pcm.length / 4;
  const n = Math.min(frames, Math.round(rate * sec));
  for (let k = 0; k < n; k++) {
    const f = frames - n + k;
    const g = 1 - (k + 1) / n;
    pcm.writeInt16LE(Math.round(pcm.readInt16LE(f * 4) * g), f * 4);
    pcm.writeInt16LE(Math.round(pcm.readInt16LE(f * 4 + 2) * g), f * 4 + 2);
  }
  return pcm;
}

// --- The meter (gp qa's sound section) -----------------------------------------------------------------------------

/** What the meter heard: one row per render quantum (128 samples) of the context's time */
export interface MeterTake {
  rate: number;
  /** [frame, then for the mix, the effects bus and the music + ambience buses: kss, peak, clipped, zero crossings] */
  rows: number[][];
  /** The mixer's buses it listens to apart (false: the game has no createMixer, or it wasn't made yet) */
  buses: { sfx: boolean; bed: boolean };
  error: string;
}

/**
 * Install with page.addInitScript(audioMeter) BEFORE installProbe (the probe then wraps the metered context and sees the
 * meter's bus reach the speakers). Real time: resume() and suspend() are the game's own. Per input and quantum it sums
 * the K-weighted energy of both channels (BS.1770's pre-filter: loudness in LUFS from it), the sample peak, the samples
 * at ≥ 0.99 (clipping, the mix only) and the mono signal's zero crossings (a pitch proxy for the repeat check)
 */
export const audioMeter = (): void => {
  const Real = window.AudioContext;
  if (!Real) return;
  const w = window as unknown as Record<string, unknown>;
  const destinationOf = Object.getOwnPropertyDescriptor(BaseAudioContext.prototype, 'destination')!.get!;
  type Rec = { ctx: AudioContext; node: AudioWorkletNode | null; rows: number[][]; error: string; linked: Set<AudioNode>; buses: { sfx: boolean; bed: boolean } };
  let rec: Rec | null = null;
  const WORKLET = `
  const kf = (r) => {
    // BS.1770 K-weighting at any rate (libebur128's coefficients): a high shelf, then a high-pass
    let K = Math.tan(Math.PI * 1681.974450955533 / r);
    const Vh = Math.pow(10, 3.999843853973347 / 20), Vb = Math.pow(Vh, 0.4996667741545416), Q = 0.7071752369554196;
    let a0 = 1 + K / Q + K * K;
    const s1 = [(Vh + Vb * K / Q + K * K) / a0, 2 * (K * K - Vh) / a0, (Vh - Vb * K / Q + K * K) / a0, 2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0];
    K = Math.tan(Math.PI * 38.13547087602444 / r);
    const Q2 = 0.5003270373238773;
    a0 = 1 + K / Q2 + K * K;
    const s2 = [1, -2, 1, 2 * (K * K - 1) / a0, (1 - K / Q2 + K * K) / a0];
    return [s1, s2];
  };
  registerProcessor('gp-audio-meter', class extends AudioWorkletProcessor {
    constructor() {
      super();
      this.f = kf(sampleRate);
      // per input, per channel, per stage: [x1, x2, y1, y2]
      this.z = [0, 1, 2].map(() => [0, 1].map(() => [[0, 0, 0, 0], [0, 0, 0, 0]]));
      this.buf = [];
      this.port.onmessage = () => { this.port.postMessage(this.buf); this.buf = []; this.port.postMessage('done'); };
    }
    process(inputs) {
      const row = [currentFrame];
      for (let k = 0; k < 3; k++) {
        const inp = inputs[k];
        if (!inp || !inp.length) { row.push(0, 0, 0, 0); continue; }
        let kss = 0, peak = 0, clip = 0, zc = 0, prev = 0;
        for (let c = 0; c < 2; c++) {
          const ch = inp[c] || inp[0];
          const zs = this.z[k][c];
          for (let i = 0; i < ch.length; i++) {
            const x = ch[i];
            const ax = x < 0 ? -x : x;
            if (ax > peak) peak = ax;
            if (k === 0 && ax >= 0.99) clip++;
            let v = x;
            for (let s = 0; s < 2; s++) {
              const b = this.f[s], st = zs[s];
              const y = b[0] * v + b[1] * st[0] + b[2] * st[1] - b[3] * st[2] - b[4] * st[3];
              st[1] = st[0]; st[0] = v; st[3] = st[2]; st[2] = y;
              v = y;
            }
            kss += v * v;
          }
        }
        const L = inp[0], R = inp[1] || inp[0];
        for (let i = 0; i < L.length; i++) {
          const m = L[i] + R[i];
          if ((m > 0 && prev < 0) || (m < 0 && prev > 0)) zc++;
          if (m !== 0) prev = m;
        }
        row.push(kss, peak, clip, zc);
      }
      this.buf.push(row);
      if (this.buf.length >= 200) { this.port.postMessage(this.buf); this.buf = []; }
      return true;
    }
  });`;
  class MeteredContext extends Real {
    constructor(...args: ConstructorParameters<typeof AudioContext>) {
      super(...args);
      // The game's first context (one per game: the platform's rule)
      if (rec) return;
      const ctx = this as AudioContext;
      const real = destinationOf.call(ctx) as AudioDestinationNode;
      const bus = ctx.createGain();
      bus.connect(real);
      Object.defineProperty(bus, 'maxChannelCount', { value: real.maxChannelCount });
      Object.defineProperty(ctx, 'destination', { get: () => bus });
      const r: Rec = { ctx, node: null, rows: [], error: '', linked: new Set(), buses: { sfx: false, bed: false } };
      rec = r;
      if (!ctx.audioWorklet) {
        r.error = 'no AudioWorklet (not a secure context)';
        return;
      }
      const url = URL.createObjectURL(new Blob([WORKLET], { type: 'application/javascript' }));
      ctx.audioWorklet.addModule(url).then(
        () => {
          const node = new AudioWorkletNode(ctx, 'gp-audio-meter', { numberOfInputs: 3, numberOfOutputs: 0, channelCount: 2, channelCountMode: 'explicit' });
          node.port.onmessage = (e) => {
            if (Array.isArray(e.data)) for (const row of e.data as number[][]) r.rows.push(row);
          };
          bus.connect(node, 0, 0);
          r.node = node;
        },
        (e: unknown) => (r.error = `the AudioWorklet failed: ${String(e)}`),
      );
    }
  }
  w.AudioContext = MeteredContext;
  if (w.webkitAudioContext) w.webkitAudioContext = MeteredContext;
  /** Listen to the mixer's buses apart (createMixer tags them __gpBus; the probe's graph lists every node that connects) */
  w.__gpMeterConnect = () => {
    const r = rec;
    const edges = (w.__gpProbe as { edges?: Map<AudioNode, unknown> } | undefined)?.edges;
    if (!r?.node || !edges) return r?.buses ?? { sfx: false, bed: false };
    for (const n of edges.keys()) {
      const kind = (n as unknown as { __gpBus?: string }).__gpBus;
      if (!kind || n.context !== r.ctx || r.linked.has(n)) continue;
      n.connect(r.node, 0, kind === 'sfx' ? 1 : 2);
      r.linked.add(n);
      if (kind === 'sfx') r.buses.sfx = true;
      else r.buses.bed = true;
    }
    return r.buses;
  };
  w.__gpMeterTake = async () => {
    const r = rec;
    if (!r) return { rate: 0, rows: [], buses: { sfx: false, bed: false }, error: 'the page made no AudioContext' };
    if (r.node) {
      const node = r.node;
      await new Promise<void>((ok) => {
        const prev = node.port.onmessage;
        node.port.onmessage = (e) => (e.data === 'done' ? ok() : prev?.call(node.port, e));
        node.port.postMessage('flush');
        // A context that no longer runs never answers
        setTimeout(ok, 500);
      });
    }
    return { rate: r.ctx.sampleRate, rows: r.rows, buses: r.buses, error: r.error };
  };
};

/** Listen to the mixer's buses apart, once they exist (call it again later: it adds the ones made since) */
export async function connectMeter(page: Page): Promise<{ sfx: boolean; bed: boolean }> {
  return page.evaluate(() => (window as unknown as { __gpMeterConnect?: () => { sfx: boolean; bed: boolean } }).__gpMeterConnect?.() ?? { sfx: false, bed: false });
}

/** Everything the meter heard so far */
export async function takeMeter(page: Page): Promise<MeterTake> {
  return page.evaluate(
    () => (window as unknown as { __gpMeterTake?: () => Promise<MeterTake> }).__gpMeterTake?.() ?? { rate: 0, rows: [], buses: { sfx: false, bed: false }, error: 'audioMeter is not installed' },
  );
}
