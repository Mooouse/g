// Portal checks on the PRODUCTION build: the one that gets uploaded. Dev and E2E builds use a portal stub, so
// only this run proves the real SDK adapter: the SDK script is replaced (Playwright route) by a fake with the
// same v3 surface that records every call and keeps the data module in memory. Any kit's game on a portal gets
// these checks; the kit only says how to start playing without test hooks (`suite.prod.play`).
// Idea from Petri Panic (QmaCyber/game2, tools/e2e.mjs), which tested its production build this way.

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Page } from 'playwright';
import type { SizeReport } from '@gp/spec';
import type { QaContext, QaSuite } from './index.ts';
import { canvasContexts, installProbe, legibility, MIN_TEXT_PX, pixelStats, PORTAL_FRAMES } from './probe.ts';

declare global {
  interface Window {
    __sdk: { calls: string[]; store: Record<string, string>; times: Record<string, number> };
  }
}

const SDK_URL = 'https://sdk.crazygames.com/**';

/**
 * A fake CrazyGames SDK v3: records calls, keeps `data` in memory, ads start and finish right away — or, with
 * `adsFail`, every ad ends in adError at once: an ad blocker, or Basic Launch, where CrazyGames monetization is off.
 */
const fakeSdk = (adsFail = false) => `(() => {
  const calls = []; const store = {}; const times = {};
  window.__sdk = { calls, store, times };
  const game = {};
  for (const f of ['loadingStart', 'loadingStop', 'gameplayStart', 'gameplayStop', 'happytime']) game[f] = () => { calls.push(f); if (!(f in times)) times[f] = performance.now(); };
  game.settings = { muteAudio: false, disableChat: false };
  const listeners = [];
  game.addSettingsChangeListener = (fn) => { calls.push('settings:listen'); listeners.push(fn); };
  window.__sdkMute = (m) => { game.settings = { ...game.settings, muteAudio: m }; for (const f of listeners) f(game.settings); };
  window.CrazyGames = { SDK: {
    environment: 'crazygames',
    init: async () => { calls.push('init'); },
    game,
    ad: { requestAd: (type, cb) => { calls.push('ad:' + type); ${adsFail ? "setTimeout(() => cb.adError && cb.adError({ code: 'adblock' }), 10);" : "setTimeout(() => { cb.adStarted && cb.adStarted(); setTimeout(() => cb.adFinished && cb.adFinished(), 50); }, 10);"} } },
    data: {
      getItem: (k) => { calls.push('data:get'); return k in store ? store[k] : null; },
      setItem: (k, v) => { calls.push('data:set'); store[k] = String(v); },
      removeItem: (k) => { delete store[k]; },
      clear: () => {},
    },
  } };
})();`;

/**
 * Class and id names ad blockers hide with their cosmetic filters (EasyList: .ad-btn, #ads, .ad_box, .advert, .sponsor …).
 * Petri Panic's revive button was class "ad-btn" and vanished in the CrazyGames preview for players with a blocker.
 */
export const AD_LIKE = /(^|[\s_-])(ads?|adv|advert\w*|adbox|adslot|adunit|sponsor\w*)([\s_-]|$)/i;

/** Class and id names on the page that ad blockers would hide */
export async function adLikeNames(page: Page): Promise<string[]> {
  return page.evaluate((src) => {
    const re = new RegExp(src, 'i');
    const out = new Set<string>();
    for (const el of document.querySelectorAll('[class], [id]')) {
      const cls = typeof el.className === 'string' ? el.className : el.getAttribute('class') ?? '';
      for (const name of [...cls.split(/\s+/).map((c) => `.${c}`), el.id ? `#${el.id}` : ''])
        if (name.length > 1 && re.test(name.slice(1))) out.add(name);
    }
    return [...out];
  }, AD_LIKE.source);
}

/** Links a game on CrazyGames must never have: app stores and other portals ("no cross-promotion", "no other portal's branding") */
const FORBIDDEN_LINKS = /(play\.google\.com|apps\.apple\.com|itunes\.apple\.com|apps\.microsoft\.com|amazon\.[a-z.]+\/.*app|poki\.com|y8\.com|kongregate\.com|armorgames\.com|gamedistribution\.com|miniclip\.com|addictinggames\.com|coolmathgames\.com|gamepix\.com|yandex\.[a-z]+\/games)/i;

export { PORTAL_FRAMES };

/** Buttons that look like a custom fullscreen toggle (CrazyGames: "Custom in-game fullscreen buttons are prohibited") */
async function fullscreenButtons(page: Page): Promise<string[]> {
  return page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>('button, [role=button]')]
      .filter((b) => b.getBoundingClientRect().width > 0)
      .map((b) => `${b.textContent ?? ''} ${b.getAttribute('aria-label') ?? ''} ${b.title ?? ''}`.trim())
      .filter((t) => /full\s?-?screen/i.test(t)),
  );
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const alternates = (c: string[]) => c.filter((x) => x.startsWith('gameplay')).every((x, i, a) => (i === 0 ? x === 'gameplayStart' : x !== a[i - 1]));

async function setHidden(page: Page, hidden: boolean): Promise<void> {
  await page.evaluate((h) => {
    Object.defineProperty(document, 'hidden', { value: h, configurable: true });
    Object.defineProperty(document, 'visibilityState', { value: h ? 'hidden' : 'visible', configurable: true });
    document.dispatchEvent(new Event('visibilitychange'));
  }, hidden);
}

/**
 * Asset chapters (game.yaml art.assets[].chapter, @gp/art/assets createAssets): the upload's later chapters are data
 * blocks after the game's script, and none of their images may be decoded before the first screen is up (loadingStop) —
 * the runtime marks `gp:assets:chapter-<n>:start` when it starts one. With the size report's first load beside it.
 */
export async function assetChapters(ctx: Pick<QaContext, 'check' | 'info' | 'outDir'>, page: Page): Promise<void> {
  const S = 'production';
  // The page as served (an allowed request: the upload itself): the blocks are read and removed by the game as it goes
  const html = await page.evaluate(() => fetch(location.href).then((r) => r.text()));
  const blocks = [...html.matchAll(/data-gp-asset="[^"]*" data-gp-chapter="(\d+)"/g)].map((m) => Number(m[1]));
  if (!blocks.length) return;
  const at = await page.evaluate(() => ({
    loaded: window.__sdk?.times?.loadingStop ?? null,
    painted: performance.getEntriesByName('first-contentful-paint')[0]?.startTime ?? null,
    chapter0: performance.getEntriesByName('gp:assets:chapter-0:ready')[0]?.startTime ?? null,
    starts: performance.getEntriesByType('mark').filter((m) => /^gp:assets:chapter-[1-9]\d*:start$/.test(m.name)).map((m) => ({ name: m.name, t: m.startTime })),
  }));
  // The first screen: chapter 0 decoded and something painted (a first visit that lands in play may ask for chapter 1
  // inside start(), before loadingStop — what matters is that it waits for what the first screen draws)
  const first = Math.max(at.chapter0 ?? 0, at.painted ?? 0);
  const early = at.starts.filter((m) => m.t < first);
  const chapters = [...new Set(blocks)].sort((a, b) => a - b);
  const s = (ms: number) => `${(ms / 1000).toFixed(2)} s`;
  ctx.check(
    S,
    'asset chapters: no later-chapter image decoded before the first screen (chapter 0 decoded, the first paint)',
    at.painted !== null && !early.length,
    `${blocks.length} image(s) in chapter${chapters.length > 1 ? 's' : ''} ${chapters.join(', ')} after the script; chapter 0 at ${at.chapter0 === null ? '—' : s(at.chapter0)}, first paint at ${at.painted === null ? '—' : s(at.painted)}, loadingStop at ${at.loaded === null ? '—' : s(at.loaded)}${early.length ? `; started before the first screen: ${early.map((m) => `${m.name} at ${s(m.t)}`).join(', ')} — ask for a later chapter (ready/prefetch) after Play, or after await assets.ready(0)` : at.starts.length ? `; ${at.starts.map((m) => `${m.name.replace('gp:assets:', '').replace(':start', '')} from ${s(m.t)}`).join(', ')}` : '; none started yet'}`,
  );
  try {
    const r = JSON.parse(readFileSync(join(ctx.outDir, '..', 'upload', 'size.json'), 'utf8')) as SizeReport;
    const kb = (n: number) => `${Math.round(n / 1024).toLocaleString('en-US')} KB`;
    if (r.first && r.chapters?.length)
      ctx.info(S, 'asset chapters: the size and load budget', `before Play ${kb(r.first.gzip)} gzipped, ≈ ${(r.load.tappableMs / 1000).toFixed(1)} s to a tappable Play on a slow phone; after it ${r.chapters.map((c) => `chapter ${c.chapter} ${kb(c.gzipBytes)} (in ≈ ${(c.inMs / 1000).toFixed(1)} s)`).join(', ')} — gp build's estimate`);
  } catch {
    // no size report next to the upload: gp build writes it
  }
}

export async function runPortalChecks(ctx: QaContext, suite: QaSuite, prodUrl: string): Promise<void> {
  const { game } = ctx;
  if (game.portal !== 'crazygames') return;
  const S = 'production';
  const bctx = await ctx.browser.newContext({ viewport: { width: 1280, height: 720 }, hasTouch: true });
  try {
    await bctx.route(SDK_URL, (route) => route.fulfill({ contentType: 'application/javascript', body: fakeSdk() }));
    const page = await bctx.newPage();
    const errors: string[] = [];
    // The upload is one file: the page must not load anything else from the package
    const origin = new URL(prodUrl).origin;
    const extra: string[] = [];
    page.on('request', (r) => {
      const u = new URL(r.url());
      if (u.origin === origin && !['/', '/index.html'].includes(u.pathname)) extra.push(u.pathname);
    });
    // Calls the portal forbids or handles itself: a custom fullscreen, links out through window.open
    await page.addInitScript(() => {
      const w = window as unknown as { __gpCalls: string[] };
      w.__gpCalls = [];
      const orig = Element.prototype.requestFullscreen;
      Element.prototype.requestFullscreen = function (this: Element, ...a: [FullscreenOptions?]) {
        w.__gpCalls.push('requestFullscreen');
        return orig.apply(this, a);
      };
      const open = window.open;
      window.open = (...a: Parameters<typeof window.open>) => {
        w.__gpCalls.push(`open:${String(a[0])}`);
        return open.apply(window, a);
      };
    });
    const adLike = new Set<string>();
    const fsButtons = new Set<string>();
    const links = new Set<string>();
    const scan = async () => {
      for (const n of await adLikeNames(page)) adLike.add(n);
      for (const b of await fullscreenButtons(page)) fsButtons.add(b);
      for (const h of await page.evaluate(() => [...document.querySelectorAll<HTMLAnchorElement>('a[href]')].map((a) => a.href))) links.add(h);
    };
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => {
      if (m.type() === 'error') errors.push(m.text());
    });
    const t0 = Date.now();
    await page.goto(prodUrl);
    await page.waitForFunction(() => window.__sdk?.calls.includes('loadingStop'), null, { timeout: 20000 }).catch(() => {});
    const loadSec = (Date.now() - t0) / 1000;
    const calls = () => page.evaluate(() => window.__sdk.calls.slice());
    let c = await calls();
    const boot = c.filter((x) => !x.startsWith('data:') && !x.startsWith('settings:'));
    ctx.check(S, 'SDK: init → loadingStart → loadingStop', boot.slice(0, 3).join() === 'init,loadingStart,loadingStop', `${boot.join(', ')}; ${loadSec.toFixed(1)} s`);
    ctx.check(S, 'SDK: loading done within 20 s (the portal measures it)', c.includes('loadingStop') && loadSec < 20, `${loadSec.toFixed(1)} s`);
    ctx.check(S, 'save: read from the SDK data module', c.includes('data:get'), '');
    ctx.check(S, "SDK: the game follows the portal's mute setting (listens to settings changes)", c.includes('settings:listen'));
    const hooks = await page.evaluate(() => ['__app', '__gp', '__portal'].filter((k) => k in window));
    ctx.check(S, 'no test hooks in the production build', hooks.length === 0, hooks.join(', '));
    const testAd = await page.evaluate(() => document.documentElement.innerHTML.includes('TEST AD'));
    ctx.check(S, 'no test ad stub in the production build', !testAd);
    await page.screenshot({ path: `${ctx.outDir}/production-title.png` });
    await scan();
    await assetChapters(ctx, page);

    if (suite.prod) {
      await suite.prod.play(page);
      await page.waitForFunction(() => window.__sdk.calls.includes('gameplayStart'), null, { timeout: 10000 }).catch(() => {});
      c = await calls();
      ctx.check(S, 'SDK: gameplayStart after at most one click from the first screen (Full Launch: "land directly in gameplay")', c.at(-1) === 'gameplayStart' || c.includes('gameplayStart'), c.slice(-3).join(', '));
      await scan();
      await setHidden(page, true);
      await sleep(300);
      c = await calls();
      ctx.check(S, 'SDK: gameplayStop when the tab is hidden', c.filter((x) => x.startsWith('gameplay')).at(-1) === 'gameplayStop', c.slice(-3).join(', '));
      await setHidden(page, false);
      await sleep(300);
      c = await calls();
      // Back on the tab the game either goes on by itself or shows its own pause screen (a break) until Resume
      let via = 'by itself';
      if (c.filter((x) => x.startsWith('gameplay')).at(-1) !== 'gameplayStart') {
        const resume = page.locator('[data-gp=resume], button:has-text("Resume")').first();
        if (await resume.isVisible().catch(() => false)) {
          await resume.tap();
          via = 'after Resume on its pause screen';
          await sleep(300);
          c = await calls();
        }
      }
      ctx.check(S, 'SDK: gameplayStart when play goes on after the tab is back', c.filter((x) => x.startsWith('gameplay')).at(-1) === 'gameplayStart', `${via}; ${c.slice(-3).join(', ')}`);
      if (suite.prod.finish) {
        await suite.prod.finish(page);
        c = await calls();
        ctx.check(S, 'SDK: gameplayStop when the round ends', c.filter((x) => x.startsWith('gameplay')).at(-1) === 'gameplayStop', c.slice(-3).join(', '));
        const saved = await page.evaluate((k) => window.__sdk.store[k] ?? null, game.saveKey);
        ctx.check(S, 'save: progress written to the SDK data module (cloud save)', !!saved && c.includes('data:set'), saved ? saved.slice(0, 120) : 'nothing stored');
        await page.screenshot({ path: `${ctx.outDir}/production-after-round.png` });
        await scan();
      }
      c = await calls();
      ctx.check(S, 'SDK: gameplayStart/Stop alternate', alternates(c), c.filter((x) => x.startsWith('gameplay')).join(','));
      ctx.check(S, 'no ads requested by the SDK in the first minute', !c.some((x) => x.startsWith('ad:')), c.filter((x) => x.startsWith('ad:')).join(', '));
    } else ctx.info(S, 'gameplay events', 'the kit has no production play script — only boot checks ran');
    ctx.check(S, 'no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
    ctx.check(S, 'upload: one file — the page loads nothing else from the package', extra.length === 0, extra.slice(0, 5).join(', '));
    ctx.check(S, 'no class or id names that ad blockers hide (.ad-btn, #ads, .advert …)', adLike.size === 0, [...adLike].slice(0, 8).join(' '));
    const gpCalls = await page.evaluate(() => (window as unknown as { __gpCalls: string[] }).__gpCalls);
    ctx.check(S, 'no custom fullscreen button (the portal provides fullscreen)', fsButtons.size === 0 && !gpCalls.includes('requestFullscreen'), [...fsButtons, ...gpCalls.filter((x) => x === 'requestFullscreen')].slice(0, 3).join(', '));
    const bad = [...links, ...gpCalls.filter((x) => x.startsWith('open:')).map((x) => x.slice(5))].filter((u) => FORBIDDEN_LINKS.test(u));
    ctx.check(S, 'no links to app stores or other portals (no cross-promotion)', bad.length === 0, bad.slice(0, 3).join(', '));
    const external = [...links].filter((u) => !u.startsWith(origin) && !FORBIDDEN_LINKS.test(u));
    if (external.length) ctx.info(S, 'external links (only a privacy policy, terms, or community links on the menu — never the main call to action)', external.slice(0, 5).join(', '));
  } finally {
    await bctx.close();
  }
  await runPortalFrames(ctx, suite, prodUrl);
  await runAdsBlocked(ctx, suite, prodUrl);
  await runSlowSdk(ctx, suite, prodUrl);
  await runNoWebgl(ctx, suite, prodUrl);
}

/** How late the slow-SDK run's script arrives: past the boot's soft wait (PORTAL_SOFT_WAIT_MS, 1.5 s) */
const SLOW_SDK_MS = 4000;

/**
 * A slow network: the SDK script arrives after 4 s. The game must not wait for it (C7: boot used to block the first frame
 * on CrazyGames' script and init — up to 8 s each): its first screen is up within 3 s of opening, and once the SDK is
 * there its calls arrive in order (init → loadingStart → loadingStop) and the game plays.
 */
async function runSlowSdk(ctx: QaContext, suite: QaSuite, prodUrl: string): Promise<void> {
  if (ctx.game.kit.kit !== 'code') return;
  const S = 'production, slow SDK';
  const bctx = await ctx.browser.newContext({ viewport: { width: 1280, height: 720 }, hasTouch: true });
  try {
    await bctx.route(SDK_URL, async (route) => {
      await sleep(SLOW_SDK_MS);
      await route.fulfill({ contentType: 'application/javascript', body: fakeSdk() }).catch(() => {});
    });
    await bctx.addInitScript(installProbe);
    const page = await bctx.newPage();
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    const t0 = Date.now();
    // Not until 'load': the late SDK script holds the page's load event
    await page.goto(prodUrl, { waitUntil: 'commit' });
    const shown = await page
      .waitForFunction(() => (document.getElementById('ui')?.childElementCount ?? 0) > 0 || (window.__gpProbe?.frames ?? 0) > 0, null, { timeout: 3000 })
      .then(() => Date.now() - t0)
      .catch(() => null);
    const before = await page.evaluate(() => !!window.__sdk);
    await page.screenshot({ path: `${ctx.outDir}/production-slow-sdk.png` });
    ctx.check(S, `the first screen is up before the SDK (it arrives after ${SLOW_SDK_MS / 1000} s): the game doesn't wait for it`, shown !== null && !before, shown !== null ? `${(shown / 1000).toFixed(1)} s` : 'nothing on screen within 3 s: boot waits for the portal SDK');
    await page.waitForFunction(() => window.__sdk?.calls.includes('loadingStop'), null, { timeout: 20000 }).catch(() => {});
    let calls = await page.evaluate(() => window.__sdk?.calls.filter((x) => !x.startsWith('data:') && !x.startsWith('settings:')) ?? []);
    ctx.check(S, 'SDK, once it is there: init → loadingStart → loadingStop (the queued calls in order)', calls.slice(0, 3).join() === 'init,loadingStart,loadingStop', calls.join(', '));
    if (suite.prod && !calls.includes('gameplayStart')) {
      await suite.prod.play(page);
      await page.waitForFunction(() => window.__sdk.calls.includes('gameplayStart'), null, { timeout: 10000 }).catch(() => {});
    }
    calls = await page.evaluate(() => window.__sdk?.calls ?? []);
    ctx.check(S, 'the game plays (gameplayStart reaches the SDK) and no errors', calls.includes('gameplayStart') && errors.length === 0, errors.slice(0, 2).join(' | ') || calls.filter((x) => x.startsWith('gameplay')).join(','));
  } finally {
    await bctx.close();
  }
}

/** Words of a can't-run message a game writes itself ("Lab Three can't run in this browser (…)") */
const CANT_RUN_TEXT = /can.?t run|cannot run|can.?t start|cannot start|not supported|isn.?t supported|unsupported|needs? webgl|requires? webgl|webgl (is )?(not available|unavailable)/;

/** Chromium switches for a browser without WebGL2 (an old phone, a blocklisted GPU) and without any WebGL */
const NO_WEBGL = [
  { name: 'WebGL2 off', slug: 'no-webgl2', args: ['--disable-webgl2'] },
  { name: 'WebGL off', slug: 'no-webgl', args: ['--disable-webgl'] },
];

/**
 * The upload in a browser without WebGL2, and without WebGL at all: it plays (a fallback: WebGL1, Canvas 2D), or it says
 * it can't run (the player's screen, data-gp="cant-run": start() threw or rejected) — never a blank page, a page that
 * never finishes loading, or an unhandled error. Before the player caught a failing start(), the engine lab's three and
 * Kaplay without WebGL and Rapier without WebAssembly left a blank page forever.
 */
async function runNoWebgl(ctx: QaContext, suite: QaSuite, prodUrl: string): Promise<void> {
  const prod = suite.prod;
  if (!prod) return;
  const { chromium } = await import('playwright');
  for (const mode of NO_WEBGL) {
    const S = `production, ${mode.name}`;
    const browser = await chromium.launch({ args: mode.args, executablePath: process.env.CHROMIUM_PATH || undefined });
    try {
      const bctx = await browser.newContext({ viewport: { width: 1280, height: 720 }, hasTouch: true });
      await bctx.route(SDK_URL, (route) => route.fulfill({ contentType: 'application/javascript', body: fakeSdk() }));
      await bctx.addInitScript(installProbe);
      const page = await bctx.newPage();
      const errors: string[] = [];
      page.on('pageerror', (e) => errors.push(String(e.message ?? e)));
      await page.goto(prodUrl);
      const loaded = await page
        .waitForFunction(() => window.__sdk?.calls.includes('loadingStop'), null, { timeout: 20000 })
        .then(() => true)
        .catch(() => false);
      await sleep(300);
      const cantRun = () => page.locator('[data-gp=cant-run]').first().isVisible().catch(() => false);
      let cant = await cantRun();
      let plays = false;
      let frames = 0;
      if (!cant && loaded) {
        const f0 = await page.evaluate(() => window.__gpProbe?.frames ?? 0);
        await prod.play(page);
        plays = await page
          .waitForFunction(() => window.__sdk.calls.includes('gameplayStart'), null, { timeout: 10000 })
          .then(() => true)
          .catch(() => false);
        await sleep(1000);
        frames = (await page.evaluate(() => window.__gpProbe?.frames ?? 0)) - f0;
        cant = await cantRun();
      }
      // A game that catches the engine's error itself and says so in its own words (the engine lab's shells): fine for the
      // player, though QA can only recognise it by its text — the player's own screen (data-gp="cant-run") is certain
      const own = cant || plays ? null : await page.evaluate((src) => {
        const m = (document.body.innerText || '').match(new RegExp(`[^\\n]*(${src})[^\\n]*`, 'i'));
        return m ? m[0].trim().slice(0, 120) : null;
      }, CANT_RUN_TEXT.source);
      const [shot] = await pixelStats(page, undefined, { path: `${ctx.outDir}/production-${mode.slug}.png` });
      const contexts = await canvasContexts(page);
      const asked = contexts.filter((c) => c.canvas !== '(offscreen)');
      const got = [...new Set(asked.filter((c) => c.ok).map((c) => c.type))];
      const refused = [...new Set(asked.filter((c) => !c.ok).map((c) => c.type))];
      const rejections = await page.evaluate(() => (window.__gpProbe?.rejections ?? []) as string[]);
      // Blank: hardly a pixel (≈ 50 at 1280×720) differs from the background
      const blank = shot.offBackground < 0.00005;
      // A canvas game that "plays" must draw: gameplay on a canvas that got no context is a blank game
      const drawsNothing = plays && !cant && asked.length > 0 && frames === 0;
      const failures = [
        !loaded ? 'loading never finished (no loadingStop in 20 s)' : '',
        !cant && !plays && !own && loaded ? 'Play did not start gameplay and no can\'t-run screen' : '',
        drawsNothing ? 'gameplay started, but nothing is drawn on the canvas' : '',
        blank ? 'the page is blank' : '',
        ...[...errors, ...rejections].slice(0, 2).map((e) => `uncaught: ${e.slice(0, 160)}`),
      ].filter(Boolean);
      const how = cant
        ? `the can't-run screen: "${(await page.locator('[data-gp=cant-run]').first().textContent())?.trim().slice(0, 120)}"`
        : own
          ? `the game's own can't-run message: "${own}" (recognised by its words: let the error reach start() for the player's screen, data-gp="cant-run")`
          : plays
            ? `plays (${frames} canvas frames in 1 s)`
            : 'does not play';
      ctx.check(
        S,
        'the upload plays, or shows the can\'t-run screen (data-gp="cant-run") — never a blank page or an uncaught error',
        failures.length === 0,
        `${how}; contexts: ${got.join(', ') || 'none'}${refused.length ? `, refused: ${refused.join(', ')}` : ''}${failures.length ? ` — ${failures.join('; ')}. A game that needs ${mode.name === 'WebGL off' ? 'WebGL' : 'WebGL2'}: throw from start() (or let the engine's error reach it) and the player shows the can't-run screen` : ''}`,
      );
    } finally {
      await browser.close();
    }
  }
}

/**
 * Legibility at the portal's smallest 16:9 iframes, devicePixelRatio 1: the first screen and gameplay. DOM text is
 * measured; text drawn on the canvas only when the game declares it (host.qa canvasUi: its sizes are checked in the dev
 * build, its pixels here) — the rest is for the eyes in the screenshots (qa/production-frame-*.png).
 */
async function runPortalFrames(ctx: QaContext, suite: QaSuite, prodUrl: string): Promise<void> {
  const S = 'production, portal frames';
  for (const f of PORTAL_FRAMES) {
    const bctx = await ctx.browser.newContext({ viewport: { width: f.width, height: f.height }, deviceScaleFactor: 1, hasTouch: true });
    try {
      await bctx.route(SDK_URL, (route) => route.fulfill({ contentType: 'application/javascript', body: fakeSdk() }));
      const page = await bctx.newPage();
      await page.goto(prodUrl);
      await page.waitForFunction(() => window.__sdk?.calls.includes('loadingStop'), null, { timeout: 20000 }).catch(() => {});
      await sleep(500);
      const first = await legibility(page);
      await page.screenshot({ path: `${ctx.outDir}/production-frame-${f.name}-title.png` });
      // What the game declared it draws on the canvas (host.qa canvasUi, read in the dev build at this size): drawn here too
      const undrawn: string[] = [];
      const canvasUi = async (screen: 'title' | 'play') => {
        const rects = ctx.canvasUi[`${f.name}:${screen}`];
        if (!rects?.length) return;
        const stats = await pixelStats(page, rects, { hideDom: true });
        rects.forEach((r, i) => {
          if (stats[i].varied < 0.02) undrawn.push(`${screen}: ${r.name} (${Math.round(r.x)},${Math.round(r.y)} ${Math.round(r.w)}×${Math.round(r.h)}: ${(stats[i].varied * 100).toFixed(1)} % of its pixels differ from its main colour)`);
        });
      };
      await canvasUi('title');
      let play = { small: [] as string[], outside: [] as string[], scroll: false };
      if (suite.prod) {
        await suite.prod.play(page);
        await sleep(1500);
        play = await legibility(page);
        await page.screenshot({ path: `${ctx.outDir}/production-frame-${f.name}-play.png` });
        await canvasUi('play');
      }
      if (ctx.canvasUi[`${f.name}:title`] || ctx.canvasUi[`${f.name}:play`])
        ctx.check(S, `${f.name}: canvas UI drawn in the upload (each host.qa canvasUi rect has something drawn in it)`, undrawn.length === 0, undrawn.slice(0, 4).join('; '));
      const small = [...new Set([...first.small, ...play.small])];
      ctx.check(S, `${f.name}: DOM text ≥ ${MIN_TEXT_PX} px at devicePixelRatio 1 (first screen and play)`, small.length === 0, small.slice(0, 4).join(', '));
      const outside = [...new Set([...first.outside, ...play.outside])];
      ctx.check(S, `${f.name}: every button inside the frame, no scrolling`, outside.length === 0 && !first.scroll && !play.scroll, [...outside.slice(0, 4), first.scroll || play.scroll ? 'page scrolls' : ''].filter(Boolean).join(', '));
    } finally {
      await bctx.close();
    }
  }
}

/**
 * CrazyGames requires a game that "works with AdBlock", and in Basic Launch its monetization is off: every ad request
 * fails. Here the real SDK adapter gets adError for every ad; the game must boot and play without errors. What the game
 * does when an ad it asked for fails is checked in the kit's own suite (dev build, `?ads=fail`).
 */
async function runAdsBlocked(ctx: QaContext, suite: QaSuite, prodUrl: string): Promise<void> {
  const S = 'production, ads blocked';
  if (!suite.prod) return;
  const bctx = await ctx.browser.newContext({ viewport: { width: 1280, height: 720 }, hasTouch: true });
  try {
    await bctx.route(SDK_URL, (route) => route.fulfill({ contentType: 'application/javascript', body: fakeSdk(true) }));
    const page = await bctx.newPage();
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => {
      if (m.type() === 'error') errors.push(m.text());
    });
    await page.goto(prodUrl);
    await page.waitForFunction(() => window.__sdk?.calls.includes('loadingStop'), null, { timeout: 20000 }).catch(() => {});
    await suite.prod.play(page);
    await page.waitForFunction(() => window.__sdk.calls.includes('gameplayStart'), null, { timeout: 10000 }).catch(() => {});
    const calls = () => page.evaluate(() => window.__sdk.calls.slice());
    ctx.check(S, 'the game starts and plays', (await calls()).includes('gameplayStart'));
    if (suite.prod.finish) {
      await suite.prod.finish(page);
      await page.screenshot({ path: `${ctx.outDir}/production-ads-blocked.png` });
    }
    ctx.check(S, 'no console errors with every ad failing', errors.length === 0, errors.slice(0, 3).join(' | '));
  } finally {
    await bctx.close();
  }
}
