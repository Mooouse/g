// Browser test of the player's boot for kit: code (packages/player/src/boot.ts): a start() that throws or rejects — an
// engine without WebGL, WebGL2 or WebAssembly — shows a plain "can't run" screen, the portal's loading still ends, one
// console warning, no unhandled rejection. The engine lab (QmaCyber/game12) had a blank page forever before its shell
// caught it. Runs with `npm run test:browser` (needs Playwright's Chromium); the fixture game is boot-fixture/.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import type { ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { startDev } from '../../cli/src/vite.ts';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  const dir = fileURLToPath(new URL('./boot-fixture', import.meta.url));
  server = await startDev({ id: 'boot-fixture', dir, file: `${dir}/game.yaml` });
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface Run {
  page: Page;
  errors: string[];
  warnings: string[];
}

async function open(fail: string | null, viewport = { width: 800, height: 450 }): Promise<Run> {
  const page = await browser.newPage({ viewport });
  const errors: string[] = [];
  const warnings: string[] = [];
  // Uncaught errors and unhandled rejections both arrive here
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => {
    if (m.type() === 'warning' && m.text().startsWith('[gp]')) warnings.push(m.text());
  });
  await page.goto(`${base}${fail ? `?fail=${fail}` : ''}`);
  await page.waitForFunction(() => (window as unknown as { __portal?: { calls: { fn: string }[] } }).__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 15000 });
  // A rejection would be reported right after the boot's promise settles
  await page.waitForTimeout(200);
  return { page, errors, warnings };
}

const calls = (page: Page) => page.evaluate(() => (window as unknown as { __portal: { calls: { fn: string }[] } }).__portal.calls.map((c) => c.fn));

describe("kit: code — a start() that fails shows the can't-run screen", () => {
  for (const [fail, reason] of [
    ['throw', 'WebGL2 is not available'],
    ['reject', 'Error creating WebGL context.'],
    ['string', 'no WebAssembly'],
  ] as const) {
    it(`${fail}: "Boot Fixture can't run in this browser (${reason})", loadingStop, one warning, no unhandled rejection`, async () => {
      const { page, errors, warnings } = await open(fail);
      const notice = page.locator('[data-gp=cant-run]');
      expect(await notice.isVisible()).toBe(true);
      expect(await notice.innerText()).toBe(`Boot Fixture can't run in this browser (${reason}).`);
      expect(errors).toEqual([]);
      expect(warnings).toHaveLength(1);
      const c = await calls(page);
      expect(c.filter((f) => f === 'loadingStop')).toHaveLength(1);
      // A start() that had already begun gameplay before it failed: the host holds gameplay until loading is done, so the
      // portal never hears it start (and never a gameplayStart without its stop)
      if (fail === 'reject') expect(c).not.toContain('gameplayStart');
      if (c.includes('gameplayStart')) expect(c.slice(c.indexOf('gameplayStart'))).toContain('gameplayStop');
      // Readable: centred, covers the window, text ≥ 12 px (the portal frames' minimum), light on dark
      const box = await page.evaluate(() => {
        const el = document.querySelector<HTMLElement>('[data-gp=cant-run]')!;
        const p = el.firstElementChild as HTMLElement;
        const r = el.getBoundingClientRect();
        const t = p.getBoundingClientRect();
        const s = getComputedStyle(p);
        return { full: r.width === innerWidth && r.height === innerHeight, dx: Math.abs(t.left + t.width / 2 - innerWidth / 2), dy: Math.abs(t.top + t.height / 2 - innerHeight / 2), font: parseFloat(s.fontSize), color: s.color, bg: getComputedStyle(el).backgroundColor };
      });
      expect(box.full).toBe(true);
      expect(box.dx).toBeLessThan(2);
      expect(box.dy).toBeLessThan(2);
      expect(box.font).toBeGreaterThanOrEqual(12);
      expect(box.color).not.toBe(box.bg);
      await page.close();
    });
  }

  it('fits a 360 px phone (the reason wraps, nothing off screen)', async () => {
    const { page } = await open('reject', { width: 360, height: 640 });
    const r = await page.locator('[data-gp=cant-run] p').boundingBox();
    expect(r!.x).toBeGreaterThanOrEqual(0);
    expect(r!.x + r!.width).toBeLessThanOrEqual(360);
    await page.close();
  });

  it('a start() that resolves: no screen, no warning, loadingStop once', async () => {
    const { page, errors, warnings } = await open(null);
    expect(await page.locator('[data-gp=cant-run]').count()).toBe(0);
    expect(await page.locator('#ui').innerText()).toBe('started');
    expect(errors).toEqual([]);
    expect(warnings).toEqual([]);
    expect((await calls(page)).filter((f) => f === 'loadingStop')).toHaveLength(1);
    await page.close();
  });
});
