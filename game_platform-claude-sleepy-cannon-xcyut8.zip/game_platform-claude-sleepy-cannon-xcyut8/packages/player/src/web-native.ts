// The native plugins in a web build (channel platform: web — CrazyGames, own site): nothing. The gp Vite plugin
// (packages/cli/src/vite-plugin.ts) points @capacitor/*, @capacitor-community/* and @capgo/* here when the game's
// channel isn't an Android one, so a web upload carries no Capacitor or AdMob code (13 KB of a 42 KB upload, measured
// by the engine lab). @gp/core calls the plugins only when Capacitor.isNativePlatform(), which is false here: the
// exports below exist so that every import resolves, and a call that reaches one anyway rejects instead of hanging.

const unavailable = (name: string): never =>
  new Proxy({} as never, {
    get: (_t, key) => (key === 'then' ? undefined : () => Promise.reject(new Error(`${name}.${String(key)}: a native plugin, not in a web build`))),
  });

export const Capacitor = {
  isNativePlatform: (): boolean => false,
  getPlatform: (): string => 'web',
  isPluginAvailable: (): boolean => false,
};
export const registerPlugin = (name: string): never => unavailable(name);

// @capacitor/app, @capacitor/browser, @capacitor-community/keep-awake, @capacitor-community/text-to-speech
export const App = unavailable('App');
export const Browser = unavailable('Browser');
export const KeepAwake = unavailable('KeepAwake');
export const TextToSpeech = unavailable('TextToSpeech');
export const QueueStrategy = { Flush: 0, Add: 1 };
// @capacitor-community/admob
export const AdMob = unavailable('AdMob');
export const MaxAdContentRating = {};
export const InterstitialAdPluginEvents = {};
export const RewardAdPluginEvents = {};
// @capgo/native-purchases
export const NativePurchases = unavailable('NativePurchases');
export const PURCHASE_TYPE = { INAPP: 'inapp', SUBS: 'subs' };

export default {};
