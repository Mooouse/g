// Boots a game from its resolved spec: portal SDK, then the kit (the App with a flow) or a code game's own module.
// Nothing here is game-specific.

import { autoSignIn, createPortal, deferPortal, GameHost, PORTAL_SOFT_WAIT_MS, seedRandom, showNotice, type App, type Portal, type Strings } from '@gp/core';
import type { CodeConfig } from '@gp/kit-code/meta';
import type { ResolvedGame } from '@gp/spec';
import entry from 'virtual:gp/entry';
import strings from 'virtual:gp/strings';

/** Test hooks (window.__app, window.__gp) exist only in dev and E2E builds, never in release builds */
const TEST_HOOKS = import.meta.env.DEV || import.meta.env.VITE_E2E === '1';

export async function boot(canvas: HTMLCanvasElement, game: ResolvedGame): Promise<App | GameHost> {
  // Repeatable runs for tests and screenshots: ?seed=<n>
  const seed = TEST_HOOKS ? Number(new URLSearchParams(location.search).get('seed')) : NaN;
  seedRandom(Number.isFinite(seed) && seed !== 0 ? seed : null);
  // Portals: no browser context menu, no text selection (also set in index.html CSS)
  document.addEventListener('contextmenu', (e) => e.preventDefault());

  // A portal's SDK must be initialized before any other call to it. The page (the game's background) is on screen
  // already; the game waits for the SDK at most PORTAL_SOFT_WAIT_MS — on a slow network it starts without it and the
  // SDK's calls are queued until it is ready (deferPortal: saves stay local until then, a cloud save is never overwritten)
  const sdk = createPortal(game.portal);
  let portal: Portal | null = sdk;
  if (sdk) {
    // The save, the language choice and the saved run: a portal that loads its storage up front (Playgama) needs the keys now
    const keys = [game.saveKey, `${game.saveKey}.lang`, `${game.saveKey}.run`];
    const init = sdk.init(keys);
    const inTime = await Promise.race([init.then(() => true), new Promise<boolean>((r) => setTimeout(() => r(false), PORTAL_SOFT_WAIT_MS))]);
    if (!inTime) {
      console.warn(`[gp] the portal's SDK isn't ready after ${PORTAL_SOFT_WAIT_MS} ms: the game starts now, its SDK calls are queued`);
      portal = deferPortal(sdk, init, keys);
    }
    portal!.loadingStart();
  }

  // GP_KIT is the game's kit, fixed at build time: a code game's bundle has no block kits, and the other way round
  if (import.meta.env.GP_KIT === 'code') return bootCode(canvas, game, game.kit as CodeConfig, portal, strings);
  const { bootKit } = await import('./kits.ts');
  return bootKit(canvas, game, portal, strings);
}

/**
 * kit: code — the game's own module gets the host; loading ends when its start() has resolved. A start() that throws or
 * rejects (no WebGL, no WebGL2, no WebAssembly…) gets a plain "can't run" screen instead of a blank page, and loading
 * still ends: the engine lab's three, Kaplay and Rapier left a blank page forever, with no loadingStop and an unhandled
 * rejection
 */
async function bootCode(canvas: HTMLCanvasElement, game: ResolvedGame, kit: CodeConfig, portal: Portal | null, texts: Strings): Promise<GameHost> {
  const host = new GameHost({
    strings: texts,
    languages: game.languages,
    saveKey: game.saveKey,
    minTouchPx: game.minTouchPx,
    locale: game.locale,
    ads: game.ads,
    portal,
    keepEventLog: TEST_HOOKS,
    canvas,
    title: game.title,
    // A first visit starts its run inside start(): the portal hears loadingStop first, then gameplayStart
    holdGameplayUntilLoaded: true,
  });
  if (TEST_HOOKS) {
    const w = window as unknown as { __gp: unknown };
    w.__gp = { game, events: host.events, host };
  }
  if (!entry) throw new Error(`kit code: no entry module (${kit.entry})`);
  const ui = document.createElement('div');
  ui.id = 'ui';
  document.body.append(ui);
  // Nothing under a pending ad can be tapped: the UI layer and the canvas are inert until it's over
  host.inertDuringAds(ui, canvas);
  try {
    await entry({ host, canvas, ui, game: { id: game.id, title: game.title, locale: game.locale, audience: game.audience.id, channel: game.channel.id } });
  } catch (e) {
    cantRun(game.title, e, host);
  }
  host.loaded();
  // Playgama's QA Tool checks sign-in: a corner button on the menus unless the game placed its own (signInButton)
  if (portal?.name === 'playgama') setTimeout(() => autoSignIn(host), 1500);
  return host;
}

/** The game couldn't start in this browser: say so, plainly and once (one console warning), instead of a blank page */
function cantRun(title: string, e: unknown, host: GameHost): void {
  const full = (e instanceof Error ? e.message || e.name : String(e)).trim() || 'unknown error';
  const reason = full.length > 200 ? `${full.slice(0, 199)}…` : full;
  console.warn(`[gp] ${title} can't run in this browser:`, e);
  host.gameplay(false);
  showNotice(host.t('gp.cantRun', { title, reason }), 'cant-run');
}
