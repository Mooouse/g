// The casual kit's save fields and flow. kits.ts imports this module only when the game's kit is `casual` (GP_KIT, fixed
// at build time), so a kids or code game's bundle doesn't carry the casual kit.

import type { TapScoreConfig } from '@gp/blocks';
import { CASUAL_SAVE_DEFAULTS, createCasualFlow, type CasualConfig } from '@gp/kit-casual';
import { CASUAL_STRINGS, type CasualStrings } from '@gp/kit-casual/meta';
import type { BlockKit } from './kits.ts';

export const kit: BlockKit = {
  save: CASUAL_SAVE_DEFAULTS,
  flow: (app, game, theme) => createCasualFlow(app, theme, game.title, game.kit as CasualConfig, game.round as TapScoreConfig),
  strings: CASUAL_STRINGS,
  own(game) {
    const c = game.kit as CasualConfig;
    return { ...c.strings, ...(c.title.subtitle ? { subtitle: c.title.subtitle } : {}) };
  },
  translate(game, i18n) {
    const c = game.kit as CasualConfig;
    c.strings = Object.fromEntries(Object.keys(c.strings).map((k) => [k, i18n.t(k)])) as CasualStrings;
    if (c.title.subtitle) c.title.subtitle = i18n.t('subtitle');
  },
};
