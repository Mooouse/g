// The block kits (kids, casual): the App with the kit's flow. Loaded only for their games, so a game with its own
// code (kit: code) doesn't download them; and only the game's own kit: a casual game's bundle has no kids kit
// (it carried 13 KB of it before) and the other way round.

import { App, byLanguage, CORE_SAVE_DEFAULTS, createI18n, detectLanguage, type Flow, type I18n, type Portal, type SaveData, type StringTable, type Strings, type Theme } from '@gp/core';
import { THEMES } from '@gp/blocks';
import type { ResolvedGame } from '@gp/spec';

/** A kit: its save fields, its flow, and its texts in every language */
export interface BlockKit {
  save: SaveData;
  flow(app: App, game: ResolvedGame, theme: Theme): Flow;
  /** The kit's texts per key and language (the platform's translation) */
  strings: StringTable;
  /** The game.yaml texts in English that strings/<code>.yaml translate (subtitle, `strings` overrides) */
  own(game: ResolvedGame): Record<string, string>;
  /** Put the texts of `i18n`'s language into the resolved game, before the flow starts */
  translate(game: ResolvedGame, i18n: I18n): void;
}

/**
 * The game's kit. GP_KIT is a build-time constant (the gp Vite plugin's `define`), so each comparison folds to true or
 * false and the bundler drops the other kits' imports: packages/cli/test/build.test.ts checks the bundles
 */
async function blockKit(): Promise<BlockKit | null> {
  if (import.meta.env.GP_KIT === 'kids') return (await import('./kit-kids.ts')).kit;
  if (import.meta.env.GP_KIT === 'casual') return (await import('./kit-casual.ts')).kit;
  return null;
}

/** Test hooks (window.__app, window.__gp) exist only in dev and E2E builds, never in release builds */
const TEST_HOOKS = import.meta.env.DEV || import.meta.env.VITE_E2E === '1';

/**
 * The kit's texts in the player's language (the portal's, else the browser's, else English; game.yaml `languages`): the
 * kit's own come from the platform, the game's from strings/<code>.yaml, English from game.yaml. A YAML kit has no
 * picker: the kids kit's texts are the grown-ups' (the device's language), the child's voice stays in `locale`
 */
function kitLanguage(game: ResolvedGame, kit: BlockKit, portal: Portal | null, texts: Strings): I18n {
  const forced = TEST_HOOKS ? new URLSearchParams(location.search).get('lang') : null;
  const browser = [...(navigator.languages ?? []), navigator.language];
  const languages = game.languages?.length ? game.languages : ['en'];
  return createI18n({
    strings: [byLanguage(kit.strings), { en: kit.own(game) }, texts],
    languages,
    lang: detectLanguage([forced, portal?.locale() ?? null, ...browser], languages),
  });
}

export async function bootKit(canvas: HTMLCanvasElement, game: ResolvedGame, portal: Portal | null, texts: Strings = {}): Promise<App> {
  const theme = THEMES[game.theme!];
  const kit = await blockKit();
  if (!theme) throw new Error(`Unknown theme "${game.theme}"`);
  if (!kit) throw new Error(`Unknown kit "${game.kit.kit}"`);
  const i18n = kitLanguage(game, kit, portal, texts);
  kit.translate(game, i18n);
  document.documentElement.lang = i18n.lang;
  const app = new App(canvas, {
    saveKey: game.saveKey,
    saveDefaults: { ...CORE_SAVE_DEFAULTS, ...kit.save },
    speechLang: game.locale,
    minTouchPx: game.minTouchPx,
    ads: game.ads,
    billing: game.billing,
    keepEventLog: TEST_HOOKS,
    portal,
  });
  app.start(kit.flow(app, game, theme));
  portal?.loadingStop();
  if (TEST_HOOKS) {
    const w = window as unknown as { __app: App; __gp: unknown };
    w.__app = app;
    w.__gp = { game, events: app.events };
  }
  return app;
}
