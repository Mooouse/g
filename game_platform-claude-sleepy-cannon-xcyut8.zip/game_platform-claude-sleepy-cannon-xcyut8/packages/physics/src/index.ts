// @gp/physics — the physics block for `kit: code` games: a Rapier 2D world that obeys the platform.
//
//   import RAPIER from '@dimforge/rapier2d-compat';            // the game's own dependency, pinned (game.yaml engine.physics)
//   import { createPhysics } from '@gp/physics';
//   const physics = await createPhysics(RAPIER, {               // after the WebAssembly init; throws a readable Error without it
//     gravity: { x: 0, y: 900 }, lengthUnit: 40, host,          // units are the game's (CSS px); lengthUnit ≈ a typical object
//     setup(world, R) { world.createCollider(R.ColliderDesc.cuboid(200, 10).setTranslation(400, 500)); },
//   });
//   physics.attach(eng);                                        // steps on the adapter's fixed step (eng.onStep), never on a rAF
//   eng.onFrame(() => draw(physics.pose(ball)));                // Canvas 2D, Pixi: draw from the body positions
//   physics.reset();                                            // a new run: everything freed, a fresh world, setup() again
//
// What it guarantees (the engine lab's lab-rapier did each by hand, QmaCyber/game12 games/lab-rapier/NOTES.md):
// - a FIXED step on the game's clock: the world steps `dt` (default 1/60 s) only when the game's step calls it — from the
//   adapter's onStep (attach), the game's own fixed-step sim (step()), or advance(frameDt) with an accumulator capped at
//   `maxSteps` per call. It has no requestAnimationFrame, timer or listener of its own;
// - pauses with the host: while host.paused (a hidden tab, an ad, a lost WebGL context) advance() steps nothing, and the
//   time that passed is dropped — back from a pause there is no jump and no catch-up burst (the adapter itself stops
//   calling onStep then too, and resets its clock);
// - WASM memory is freed, never left to the GC: reset() and destroy() free every object it made or was given (keep()),
//   then the event queue, then the world (World.free() frees its bodies, colliders and joints). In the lab, 30 worlds of
//   2,000 bodies made and not freed grew the WASM heap to 132 MB; freed, 200 of them stayed at 6.8 MB;
// - deterministic: Rapier has no randomness of its own and the step is always the same `dt`, so the same setup, the
//   same inputs at the same steps and the same seed (host.rng / seededRng) give the same positions — `gp qa` demo bots
//   and `balance()` repeat. A reset world starts from nothing (no contact cache or warm start from the last run).
//   Bit-identical on the same machine and build; across machines only with the deterministic build
//   (@dimforge/rapier2d-deterministic-compat, `engine.physics.name: rapier2d-deterministic`).
//
// The block never imports Rapier (like the engine adapters): the game passes the module, so Rapier stays the game's own
// npm dependency (games/<id>/package.json) and the platform builds and type-checks without it. The types come from the
// module the game passes: `physics.world` is Rapier's own World.

/** A 2D vector, as Rapier takes and returns it */
export interface Vec2 {
  x: number;
  y: number;
}

/** What the block uses of Rapier's event queue */
export interface EventQueueLike {
  drainCollisionEvents(f: (handle1: number, handle2: number, started: boolean) => void): void;
  free(): void;
}

/** What the block uses of a Rapier world */
export interface WorldLike {
  timestep: number;
  lengthUnit: number;
  step(eventQueue?: never): void;
  free(): void;
}

/** What the block uses of the Rapier module (`import RAPIER from '@dimforge/rapier2d-compat'`) */
export interface RapierLike {
  init(): Promise<void>;
  World: new (gravity: Vec2) => WorldLike;
  EventQueue: new (autoDrain: boolean) => EventQueueLike;
  version?(): string;
}

type WorldOf<R extends RapierLike> = InstanceType<R['World']>;
type QueueOf<R extends RapierLike> = InstanceType<R['EventQueue']>;

/** The host's side the block listens to (GameHost) */
export interface PhysicsHost {
  readonly paused: boolean;
  onPause(fn: (reason: string) => void): void;
  onResume(fn: () => void): void;
}

/** The adapter's side the block steps on (any @gp/core/engines adapter) */
export interface PhysicsEngine {
  readonly running: boolean;
  onStep(fn: (dt: number) => void): () => void;
}

export interface PhysicsOptions<R extends RapierLike> {
  /** World units per second², in the game's units (CSS px: { x: 0, y: 900 } is a light fall). Default none (0, 0) */
  gravity?: Vec2;
  /** Seconds per world step (default 1/60): the world always steps exactly this, so a run repeats */
  dt?: number;
  /** advance(): the most steps one call makes (default 4); the time beyond it is dropped, never caught up later */
  maxSteps?: number;
  /**
   * Units per meter, for Rapier's tolerances (contact distances, sleeping): about the size of a typical dynamic object
   * in the game's units — 40 for things 20–80 px across (default 1: the units are meters)
   */
  lengthUnit?: number;
  /** The host: while it is paused advance() steps nothing and the pause's time is dropped */
  host?: PhysicsHost;
  /** Builds the scene: at creation and after every reset(), on the fresh world */
  setup?(world: WorldOf<R>, R: R): void;
}

/** What the block made and freed: the leak check (stats.live is 1 while it lives, 0 after destroy) */
export interface PhysicsStats {
  /** Worlds made (one at creation, one per reset) */
  created: number;
  /** Worlds freed (World.free()) */
  freed: number;
  /** Worlds of this block not freed: 1 while it lives */
  live: number;
  /** Objects freed besides the worlds: event queues and everything given to keep() */
  freedObjects: number;
  /** World steps since creation */
  steps: number;
  resets: number;
  /** Seconds advance() dropped: over maxSteps in one call, or during a host pause */
  droppedSec: number;
}

export interface Physics<R extends RapierLike> {
  /** The Rapier module the game passed */
  readonly R: R;
  /** The current world (a new one after every reset(): don't keep it across a reset) */
  readonly world: WorldOf<R>;
  /** The event queue every step fills; collision events go to onCollision listeners, the rest is the game's to drain */
  readonly events: QueueOf<R>;
  /** Seconds per step */
  readonly dt: number;
  /** advance(): the share of a step left in the accumulator, 0..1 (to interpolate a drawing, if you want) */
  readonly alpha: number;
  readonly stats: Readonly<PhysicsStats>;
  /**
   * One world step of `dt`, then its collision events to the onCollision listeners and the onStep listeners. For a game's
   * own fixed-step sim (and Node: balance bots, unit tests). Does nothing after destroy()
   */
  step(): void;
  /**
   * `seconds` of game time: as many steps of `dt` as fit (an accumulator), at most `maxSteps`; the rest is dropped. Nothing
   * while the host is paused, or while the attached engine isn't running. Returns the steps made
   */
  advance(seconds: number): number;
  /**
   * Step on the adapter's fixed step (eng.onStep → advance(dt)): with the same dt (the adapter's `step` option), exactly
   * one world step per game step. A listener that stops the run (eng.setRunning(false)) stops the steps at once. Returns
   * an unsubscribe
   */
  attach(eng: PhysicsEngine): () => void;
  /** After every world step (its collision events already delivered). Returns an unsubscribe */
  onStep(fn: () => void): () => void;
  /**
   * Every collision event of a step (colliders need ActiveEvents.COLLISION_EVENTS): the two collider handles and whether
   * the contact started or stopped. Returns an unsubscribe
   */
  onCollision(fn: (handle1: number, handle2: number, started: boolean) => void): () => void;
  /** Free this with the world on reset() and destroy() (a character controller, a PID controller, a query pipeline) */
  keep<T extends { free(): void }>(obj: T): T;
  /** Free a kept object now (a controller the run no longer needs): never free a kept object yourself, it would be freed twice */
  free(obj: { free(): void }): void;
  /** A body's position and angle, to draw it: { x, y, angle } in the world's units and radians */
  pose(body: { translation(): Vec2; rotation(): number }): { x: number; y: number; angle: number };
  /**
   * Free everything (kept objects, the event queue, the world: every body, collider and joint), then a fresh world and
   * setup() on it. The accumulator starts empty. A new run calls it
   */
  reset(): void;
  /** Free everything for good; step(), advance() and reset() do nothing after it */
  destroy(): void;
}

/** Worlds made by every block on the page and not freed yet (the leak check across blocks) */
let liveWorlds = 0;
export function livePhysicsWorlds(): number {
  return liveWorlds;
}

/** One init per Rapier module: the compat build decodes its 3.2 MB of base64 on every init() call, even when done */
const inits = new WeakMap<object, Promise<void>>();

/** Rapier's WebAssembly, once: rejects with a readable Error where the browser has none (the player shows "can't run") */
export function initRapier(R: RapierLike): Promise<void> {
  if (typeof WebAssembly === 'undefined') return Promise.reject(new Error('no WebAssembly in this browser (the physics needs it)'));
  let p = inits.get(R);
  if (!p) {
    p = R.init().catch((e: unknown) => {
      inits.delete(R);
      throw new Error(`the physics (WebAssembly) could not start: ${(e as Error)?.message ?? String(e)}`);
    });
    inits.set(R, p);
  }
  return p;
}

/** A Rapier 2D world for the game, after the WebAssembly init (see the top of this file) */
export async function createPhysics<R extends RapierLike>(R: R, opts: PhysicsOptions<R> = {}): Promise<Physics<R>> {
  await initRapier(R);
  return physicsAfterInit(R, opts);
}

/** createPhysics without the init, for a module whose init() already resolved (the tests' fakes, a second world) */
export function physicsAfterInit<R extends RapierLike>(R: R, opts: PhysicsOptions<R> = {}): Physics<R> {
  const dt = opts.dt ?? 1 / 60;
  if (!(dt > 0)) throw new Error(`physics dt must be above 0 (got ${dt})`);
  const maxSteps = Math.max(1, Math.floor(opts.maxSteps ?? 4));
  const gravity = { x: opts.gravity?.x ?? 0, y: opts.gravity?.y ?? 0 };
  const stats: PhysicsStats = { created: 0, freed: 0, live: 0, freedObjects: 0, steps: 0, resets: 0, droppedSec: 0 };
  const stepFns: (() => void)[] = [];
  const hitFns: ((a: number, b: number, started: boolean) => void)[] = [];
  let kept: { free(): void }[] = [];
  let world!: WorldOf<R>;
  let queue!: QueueOf<R>;
  let acc = 0;
  let dead = false;
  /** The attached engine: steps stop at once when a listener stops its run */
  let engine: PhysicsEngine | null = null;
  const host = opts.host;
  const sub = <F>(list: F[], fn: F) => {
    list.push(fn);
    return () => {
      const i = list.indexOf(fn);
      if (i >= 0) list.splice(i, 1);
    };
  };

  function build(): void {
    world = new R.World(gravity) as WorldOf<R>;
    world.timestep = dt;
    if (opts.lengthUnit !== undefined) world.lengthUnit = opts.lengthUnit;
    stats.created++;
    stats.live++;
    liveWorlds++;
    // autoDrain: events nobody drains are cleared before the next step, never kept growing
    queue = new R.EventQueue(true) as QueueOf<R>;
    acc = 0;
    opts.setup?.(world, R);
  }

  function freeAll(): void {
    // What the game gave first (it may point into the world), then the queue, then the world with everything in it
    for (const o of kept.reverse()) {
      o.free();
      stats.freedObjects++;
    }
    kept = [];
    queue.free();
    stats.freedObjects++;
    world.free();
    stats.freed++;
    stats.live--;
    liveWorlds--;
  }

  const stopped = () => dead || (engine !== null && !engine.running);

  const physics: Physics<R> = {
    R,
    get world() {
      return world;
    },
    get events() {
      return queue;
    },
    dt,
    get alpha() {
      return Math.min(1, acc / dt);
    },
    stats,
    step() {
      if (dead) return;
      world.step(queue as never);
      stats.steps++;
      if (hitFns.length)
        queue.drainCollisionEvents((a, b, started) => {
          // A listener that ended the run: the rest of this step's events are dropped with it
          if (stopped()) return;
          for (const fn of hitFns) fn(a, b, started);
        });
      for (const fn of stepFns) {
        if (stopped()) return;
        fn();
      }
    },
    advance(seconds) {
      if (dead || !(seconds > 0)) return 0;
      if (host?.paused || (engine && !engine.running)) {
        stats.droppedSec += seconds;
        acc = 0;
        return 0;
      }
      acc += seconds;
      // Over the cap: the time is dropped (a slow frame plays slower), never caught up in a burst later
      const max = maxSteps * dt;
      if (acc > max + 1e-9) {
        stats.droppedSec += acc - max;
        acc = max;
      }
      let n = 0;
      // The epsilon: dt added in steps of dt must make whole steps (1/120 + 1/120 ≥ 1/60), whatever the rounding
      while (acc >= dt - 1e-9 && !stopped()) {
        acc = Math.max(0, acc - dt);
        physics.step();
        n++;
      }
      return n;
    },
    attach(eng) {
      engine = eng;
      acc = 0;
      const off = eng.onStep((s) => physics.advance(s));
      return () => {
        off();
        if (engine === eng) engine = null;
      };
    },
    onStep: (fn) => sub(stepFns, fn),
    onCollision: (fn) => sub(hitFns, fn),
    keep(obj) {
      if (dead) throw new Error('physics.keep() after destroy()');
      kept.push(obj);
      return obj;
    },
    free(obj) {
      const i = kept.indexOf(obj);
      if (i < 0) return;
      kept.splice(i, 1);
      obj.free();
      stats.freedObjects++;
    },
    pose(body) {
      const t = body.translation();
      return { x: t.x, y: t.y, angle: body.rotation() };
    },
    reset() {
      if (dead) return;
      freeAll();
      stats.resets++;
      build();
    },
    destroy() {
      if (dead) return;
      dead = true;
      freeAll();
      stepFns.length = 0;
      hitFns.length = 0;
    },
  };

  // A pause's time never reaches the world: the accumulator is emptied when it starts and when it ends
  host?.onPause(() => {
    acc = 0;
  });
  host?.onResume(() => {
    acc = 0;
  });
  build();
  return physics;
}

/**
 * Canvas 2D: every collider's outline, from Rapier's debug renderer (world.debugRender()), in the world's units — the
 * quickest way to see the physics while the game's own art isn't there yet (the context's transform is the caller's)
 */
export function drawDebug(ctx: CanvasRenderingContext2D, world: { debugRender(): { vertices: Float32Array; colors: Float32Array } }, opts: { lineWidth?: number; color?: string } = {}): void {
  const { vertices: v, colors: c } = world.debugRender();
  ctx.save();
  ctx.lineWidth = opts.lineWidth ?? 1;
  for (let i = 0; i + 3 < v.length; i += 4) {
    const k = i * 2;
    ctx.strokeStyle = opts.color ?? `rgba(${Math.round(c[k] * 255)},${Math.round(c[k + 1] * 255)},${Math.round(c[k + 2] * 255)},${c[k + 3]})`;
    ctx.beginPath();
    ctx.moveTo(v[i], v[i + 1]);
    ctx.lineTo(v[i + 2], v[i + 3]);
    ctx.stroke();
  }
  ctx.restore();
}
