// Browser test of the physics block (@gp/physics) on the REAL Rapier: @dimforge/rapier2d-compat and
// -deterministic-compat at the version game.yaml engine.physics is tested with, on the Canvas 2D and the Pixi adapters.
// The world steps only on the adapter's fixed step, stops with every host pause reason and comes back without a jump,
// a long frame steps at most the cap, a stop inside a step stops the world at once, reset() frees the WebAssembly
// memory (100 resets stay flat, where worlds not freed grow it), and the same seed and inputs give the same floats.
// The packages are installed only in packages/core/test-browser/engines-real (never in the platform):
// `npm ci --prefix packages/core/test-browser/engines-real` (CI does it before `npm run test:browser`). Without them these
// tests are skipped and say so. The block's own logic on a fake is in packages/physics/test/physics.test.ts.

import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

const DIR = fileURLToPath(new URL('../../core/test-browser/engines-real', import.meta.url));
const PACKAGES = ['@dimforge/rapier2d-compat', '@dimforge/rapier2d-deterministic-compat', 'pixi.js'];
const installed = PACKAGES.every((e) => existsSync(`${DIR}/node_modules/${e}/package.json`));
if (!installed) console.warn('[rapier-real] skipped: Rapier is not installed — npm ci --prefix packages/core/test-browser/engines-real');

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  if (!installed) return;
  // Pre-bundled up front: a dependency found on the first page load would reload the page mid-test. Its own cache:
  // engines-real.test.ts serves the same folder at the same time with other dependencies, and a shared
  // node_modules/.vite would be re-optimised under the other's pages (reloads, 13 timeouts in a full run)
  server = await createServer({ root: DIR, configFile: false, logLevel: 'error', cacheDir: `${DIR}/node_modules/.vite-physics`, server: { port: 0 }, optimizeDeps: { include: PACKAGES, entries: ['physics.html'] } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 120000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface Stats {
  raf: number;
  frames: number;
  steps: number;
  running: boolean;
  droppedSec: number;
}
interface Pose {
  x: number;
  y: number;
  angle: number;
}
interface P {
  host: { adBreak(): Promise<void>; paused: boolean; pauseReasons: ReadonlySet<string> };
  eng: { setRunning(on: boolean): void; renderOnce(): void; running: boolean };
  physics: { advance(s: number): number; reset(): void; stats: { steps: number; created: number; freed: number } };
  version: string;
  pose(): Pose;
  drawn(): { x: number; y: number };
  stats(): Stats;
  stepLog: number[];
  extra(k: string): unknown;
  memory(): number | null;
  setHidden(h: boolean): void;
  scene(seed: number, opts?: { n?: number; steps?: number; resets?: number }): number[];
  leak(n: number, bodies: number): { bytes: number[]; stats: Record<string, number>; live: number; liveAfter: number; after: Record<string, number> };
  leakWithoutFree(n: number, bodies: number): { before: number; after: number };
  livePhysicsWorlds(): number;
}
const p = <R>(page: Page, fn: (p: P) => R) => page.evaluate(`(${fn.toString()})(window.__p)`) as Promise<Awaited<R>>;
const until = (page: Page, fn: (p: P) => boolean) => page.waitForFunction(`(${fn.toString()})(window.__p)`, null, { timeout: 15000 });

async function open(query: string): Promise<Page> {
  const ctx = await browser.newContext({ viewport: { width: 640, height: 360 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => {
    // Chromium's own GPU-process notes (software WebGL) are not the page's
    if ((m.type() === 'error' || m.type() === 'warning') && !/GroupMarkerNotSet|swiftshader|^\[\.WebGL-/i.test(m.text())) errors.push(`console.${m.type()}: ${m.text()}`);
  });
  await page.goto(`${base}physics.html?${query}`);
  await page.waitForFunction('!!window.__p', null, { timeout: 30000 });
  (page as unknown as { errors: string[] }).errors = errors;
  return page;
}
const errorsOf = (page: Page) => (page as unknown as { errors: string[] }).errors;

/** rAF callbacks and world steps over `ms` */
async function still(page: Page, ms: number): Promise<{ raf: number; steps: number }> {
  const a = await p(page, (x) => x.stats());
  await page.waitForTimeout(ms);
  const b = await p(page, (x) => x.stats());
  return { raf: b.raf - a.raf, steps: b.steps - a.steps };
}

describe.skipIf(!installed).each(['canvas', 'pixi'])('the physics block on real Rapier, drawn with the %s adapter', (engine) => {
  it("the world is made after the WebAssembly init and steps only on the adapter's fixed step; the drawing follows the body", async () => {
    const page = await open(`engine=${engine}`);
    expect(await p(page, (x) => x.version)).toBe('0.21.0');
    // Created stopped: no world step and no loop of its own (Rapier has no requestAnimationFrame; the block neither)
    const s0 = await still(page, 400);
    expect(s0).toMatchObject({ steps: 0 });
    expect(s0.raf).toBeLessThanOrEqual(3);
    await p(page, (x) => x.eng.setRunning(true));
    // (after the first frames: Pixi's first one compiles its shaders, a long frame the adapter catches up on)
    await page.waitForTimeout(300);
    const a = await p(page, (x) => x.stats());
    await page.waitForTimeout(600);
    const b = await p(page, (x) => x.stats());
    expect(b.steps - a.steps).toBeGreaterThan(20);
    // One world step per adapter step of 1/60 s: about as many steps as frames at 60 Hz (never a burst)
    expect(Math.abs(b.steps - a.steps - (b.frames - a.frames))).toBeLessThanOrEqual(4);
    // The ball fell under gravity and came to rest on the platform (y = 300 − 10 − 12)
    await page.waitForTimeout(1200);
    await p(page, (x) => x.eng.setRunning(false));
    const pose = await p(page, (x) => x.pose());
    expect(pose.x).toBeCloseTo(320, 0);
    expect(Math.abs(pose.y - 278)).toBeLessThan(1.5);
    expect(await still(page, 300)).toMatchObject({ steps: 0 });
    // The frame draws the body where it is
    await p(page, (x) => x.eng.renderOnce());
    const drawn = await p(page, (x) => x.drawn());
    expect(drawn.x).toBeCloseTo(pose.x, 6);
    expect(drawn.y).toBeCloseTo(pose.y, 6);
    if (engine === 'canvas') expect(await p(page, (x) => x.extra('pixel'))).toEqual([0xff, 0xd1, 0x66]);
    else expect(await p(page, (x) => x.extra('renderer'))).toBe('webgl');
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('every host pause reason stops the world; it resumes without a jump or a catch-up burst', async () => {
    const page = await open(`engine=${engine}`);
    await p(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(300);
    // A lost WebGL context needs WebGL: the Canvas 2D adapter has none
    const reasons = engine === 'pixi' ? (['hidden', 'ad', 'context'] as const) : (['hidden', 'ad'] as const);
    for (const reason of reasons) {
      if (reason === 'hidden') await p(page, (x) => x.setHidden(true));
      const ad = reason === 'ad' ? p(page, (x) => x.host.adBreak()) : null;
      if (reason === 'context') await page.evaluate('window.__lose.loseContext()');
      await until(page, (x) => x.host.paused);
      expect(await p(page, (x) => [...x.host.pauseReasons])).toEqual([reason]);
      expect(await still(page, 500)).toMatchObject({ steps: 0 });
      const stopped = await p(page, (x) => x.stats().steps);
      if (reason === 'hidden') await p(page, (x) => x.setHidden(false));
      if (ad) await ad;
      if (reason === 'context') await page.evaluate('window.__lose.restoreContext()');
      await until(page, (x) => !x.host.paused && x.eng.running);
      await page.waitForTimeout(250);
      // A jump would be the half second of standing still stepped at once (30 steps)
      expect((await p(page, (x) => x.stats().steps)) - stopped).toBeLessThan(0.25 * 60 + 6);
    }
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('a long frame steps at most the cap (the adapter: 0.1 s = 6 steps; advance(): maxSteps), the rest is dropped', async () => {
    // World step 5 blocks the main thread for 400 ms: 24 steps would be due at once
    const page = await open(`engine=${engine}&stall=400&stallAt=5`);
    await p(page, (x) => x.eng.setRunning(true));
    await page.waitForTimeout(900);
    const log = await p(page, (x) => x.stepLog);
    // The steps of each frame (a frame's steps run before it is drawn): the frame after the stall makes at most 6
    const perFrame = new Map<number, number>();
    for (const f of log) perFrame.set(f, (perFrame.get(f) ?? 0) + 1);
    expect(Math.max(...perFrame.values())).toBe(6);
    // The world's own accumulator (a game's own loop): one call of 2 s makes maxSteps (4) steps, the rest dropped
    const own = await p(page, (x) => {
      const before = x.stats().droppedSec;
      return { n: x.physics.advance(2), dropped: x.stats().droppedSec - before };
    });
    expect(own.n).toBe(4);
    expect(own.dropped).toBeCloseTo(2 - 4 / 60, 6);
    // Not running: nothing at all
    await p(page, (x) => x.eng.setRunning(false));
    expect(await p(page, (x) => x.physics.advance(1))).toBe(0);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('a step listener that ends the run stops the world at once: no more steps in that frame', async () => {
    const page = await open(`engine=${engine}&stopAt=3`);
    await p(page, (x) => x.eng.setRunning(true));
    await until(page, (x) => !x.eng.running);
    await page.waitForTimeout(300);
    expect(await p(page, (x) => x.stats().steps)).toBe(3);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });
});

describe.skipIf(!installed).each(['compat', 'deterministic'])('real Rapier (%s): memory and determinism', (pkg) => {
  it('100 resets of a 400-body world: the WebAssembly memory stays flat, 101 worlds made and freed; worlds not freed grow it', async () => {
    const page = await open(`pkg=${pkg}`);
    const r = await p(page, (x) => x.leak(100, 400));
    // WASM memory only grows (by 64 KB pages): flat after the first worlds means each reset gave everything back
    expect(r.bytes[99]).toBe(r.bytes[4]);
    expect(r.stats).toMatchObject({ created: 101, freed: 100, live: 1, resets: 100 });
    expect(r.after).toMatchObject({ created: 101, freed: 101, live: 0, freedObjects: 202 });
    // The page's own block and this one while it lived; the page's own only after destroy()
    expect([r.live, r.liveAfter]).toEqual([2, 1]);
    // The control: the same measure sees worlds that were never freed
    const c = await p(page, (x) => x.leakWithoutFree(10, 400));
    expect(c.after - c.before).toBeGreaterThan(2 * 1024 * 1024);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('the same seed and inputs give the same floats: twice, after resets of the same block, after a reload; another seed differs', async () => {
    const page = await open(`pkg=${pkg}`);
    const a = await p(page, (x) => x.scene(7));
    expect(a.length).toBe(180);
    expect(a.every(Number.isFinite)).toBe(true);
    expect(await p(page, (x) => x.scene(7))).toEqual(a);
    expect(await p(page, (x) => x.scene(7, { resets: 3 }))).toEqual(a);
    expect(await p(page, (x) => x.scene(8))).not.toEqual(a);
    await page.reload();
    await page.waitForFunction('!!window.__p', null, { timeout: 30000 });
    expect(await p(page, (x) => x.scene(7))).toEqual(a);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('the attached world on the real loop: stopped at the same step, the ball is at the same floats in two page loads', async () => {
    const poses: Pose[] = [];
    for (let i = 0; i < 2; i++) {
      const page = await open(`pkg=${pkg}&stopAt=50`);
      await p(page, (x) => x.eng.setRunning(true));
      await until(page, (x) => !x.eng.running);
      poses.push(await p(page, (x) => x.pose()));
      await page.context().close();
    }
    expect(poses[1]).toEqual(poses[0]);
    expect(poses[0].y).toBeGreaterThan(40);
  });
});
