// Catalog entry for the "code" kit (pure data). For a brief the building blocks can't express (a survivors-like,
// a puzzle with levels, a physics toy): the game is its own TypeScript module, `start({ host, canvas, ui, game })`, and the platform
// still does everything around it — rules, portal SDK, ads, saves, QA, packaging (docs/guides/code-games.md).
// No round and no theme: the game draws everything itself.

import type { JsonSchema } from '@gp/core/schema';

/** The kit's part of a resolved game */
export interface CodeConfig {
  kit: 'code';
  /** The game's module, relative to its folder; its default export is `start({ host, canvas, ui, game })` */
  entry: string;
  /** Page background before the game draws (and the browser's theme color) */
  background: string;
  /** The engine it draws with (game.yaml `engine`): its adapter is @gp/core/engines/<name>; null when not declared */
  engine: { name: string; version: string | null; package: string | null } | null;
  /** The physics beside the engine (game.yaml `engine.physics`), run by @gp/physics; null when not declared */
  physics: { name: string; version: string; package: string } | null;
  /**
   * The number the balance is built around (game.yaml `balance.anchor`); null when not declared (or still TODO). `shape`:
   * how the model's stages are played — a campaign (the default) or a roguelite's run
   */
  anchor: { name: string; unit: string; says: string; shape: 'campaign' | 'run' } | null;
  /**
   * The difficulty as designed (game.yaml `balance.difficulty`): the win rate each bot skill should have from a fresh save
   * (± tolerance) and the minutes of a winning run; null when not declared. `gp balance` holds the bot's skill ladder to it
   */
  difficulty: {
    naive?: { winRate: number; tolerance?: number };
    average?: { winRate: number; tolerance?: number };
    skilled?: { winRate: number; tolerance?: number };
    winningRunMin?: readonly [number, number];
  } | null;
}

/** game.yaml balance.difficulty.<skill>: a win rate and its tolerance */
const winRateSchema = (description: string): JsonSchema => ({
  type: 'object',
  description,
  properties: {
    winRate: { type: 'number', minimum: 0, maximum: 1, description: 'The share of runs won from a fresh save (0.2 = 4 of 20)' },
    tolerance: { type: 'number', minimum: 0, maximum: 0.5, default: 0.1, description: 'How far either side of winRate still meets it' },
  },
  required: ['winRate'],
  additionalProperties: false,
});

export const CODE_KIT_META = {
  id: 'code',
  kind: 'kit',
  mechanics: [] as string[],
  /** No `round` and no `theme`: the game's own code has the mechanics and the look */
  round: false,
  description:
    'The game is its own TypeScript module (`entry`, default `main.ts`): its mechanics, screens and art. It gets a `host` with the portal lifecycle, midgame and rewarded ads within the channel rules, cloud saves, sound that goes quiet during ads, seeded random and movement input. For briefs the other kits can\'t express; general audiences on web channels.',
  sections: {
    entry: { type: 'string', pattern: '^[A-Za-z0-9_./-]+\\.ts$', default: 'main.ts', description: 'The game module, relative to the game folder. `export default function start({ host, canvas, ui }: GameContext)`' } satisfies JsonSchema,
    background: { type: 'string', pattern: '^#[0-9a-fA-F]{6}$', default: '#000000', description: 'Page background until the game draws; also the browser theme color' } satisfies JsonSchema,
    engine: {
      type: 'object',
      description:
        "The engine the game draws with, through its adapter in @gp/core/engines/<name> (created stopped, runs only while a run is on and the host isn't paused, resizes and routes sound through the host). canvas (Canvas 2D, the default: no package), pixi (pixi.js 8.x), phaser (phaser 4.x), three (three r163–r199, WebGL2 only). The engine is the game's own npm dependency: `version` must be the exact version pinned in games/<id>/package.json and installed; `gp validate` checks both and the adapter's supported range. `gp init --engine <name>` sets it all up. Kaplay is not supported. Physics (Rapier) goes beside the engine: `physics`. docs/guides/code-games.md#engines",
      properties: {
        name: { type: 'string', description: 'canvas | pixi | phaser | three', examples: ['canvas', 'pixi', 'phaser', 'three'] },
        version: { type: 'string', pattern: '^\\d+\\.\\d+\\.\\d+$', description: "The engine package's exact version, as pinned in games/<id>/package.json (not for canvas)", examples: ['8.21.0', '4.2.1', '0.186.1'] },
        physics: {
          type: 'object',
          description:
            "Physics beside the engine: Rapier 2D through the physics block @gp/physics (a world on the game's fixed step — the adapter's onStep — that stops with every host pause, is freed on every reset and gives the same floats for the same seed and inputs). rapier2d (@dimforge/rapier2d-compat 0.21.x) or rapier2d-deterministic (the same floats on every machine: @dimforge/rapier2d-deterministic-compat 0.21.x). The package is the game's own npm dependency: `version` must be the exact version pinned in games/<id>/package.json and installed; `gp validate` checks both and the block's range. It needs WebAssembly and adds ≈ 1.3 MB gzipped: raise the portal budget on purpose (`budget: { gzipKB: 1500 }`). `gp init --physics` sets it all up. docs/guides/code-games.md#physics",
          properties: {
            name: { type: 'string', description: 'rapier2d | rapier2d-deterministic', examples: ['rapier2d', 'rapier2d-deterministic'] },
            version: { type: 'string', pattern: '^\\d+\\.\\d+\\.\\d+$', description: "The Rapier package's exact version, as pinned in games/<id>/package.json", examples: ['0.21.0'] },
          },
          required: ['name'],
          additionalProperties: false,
        },
      },
      required: ['name'],
      additionalProperties: false,
    } satisfies JsonSchema,
    art: {
      type: 'object',
      description:
        "Cartoon, game-like raster art made by an image model at build time and bundled with the game (never fetched at runtime: the portals forbid external resources). `gp art <id>` turns the style and each asset's prompt into a style board, then every asset in that style: sprites on a chroma key cut out to transparency, trimmed, sized and saved as WebP in games/<id>/assets/ with assets/index.ts (the imports) and assets/provenance.yaml (model, prompt, hash, date — `gp validate` checks it). The game draws the images and keeps the life in code: @gp/art lights, effects, rigs and the camera on top (docs/guides/art.md#5-generated-art-gp-art). Needs GEMINI_API_KEY in the environment. Finished pictures the owner supplies: `gp art import <dir>` (assets with `source: import`, no key)",
      properties: {
        style: { type: 'string', minLength: 20, maxLength: 800, description: 'The cartoon look every asset shares, in words: shapes, shading, outline, palette, light, mood ("chunky cartoon crypt, soft cel shading, warm candle rim light, teal shadows"). Always stylized game art — `gp art` adds that to every request, and realism words are warned (W_ART_REALISTIC)', examples: ['chunky cartoon shapes, soft cel shading, warm dusk light from the upper left, teal and amber palette'] },
        technique: { enum: ['painted', 'pixel'], default: 'painted', description: 'painted: cartoon raster art, WebP at the asset\'s size. pixel: pixel art — `size` is the sprite\'s grid in pixels (32, 48, 64: big sprites read better than 16), every pixel snapped to `palette`, saved as lossless PNG; draw it with drawPixelSprite (whole-number scale, smoothing off). A pixel game stays a pixel game: raise its sprite size and its ramps, never swap its technique' },
        palette: { type: 'array', minItems: 2, maxItems: 64, items: { type: 'string', pattern: '^#[0-9a-fA-F]{6}$' }, description: 'pixel: the game\'s own palette (hex) — every pixel of every image is one of these colours, so new art sits with the old', examples: [['#1a1020', '#fff3d6', '#ecd3a0', '#b8976a', '#ffa033', '#d4531c', '#ffe56e']] },
        keep: {
          type: 'array',
          minItems: 1,
          maxItems: 12,
          items: { type: 'string', minLength: 5, maxLength: 200 },
          description: 'What the art keeps of the game — the game design leads the look: the identity that stays even if the technique changes (pixel → cartoon: the palette, the light, the hero\'s silhouette) and what play needs (what stands out at play size, colour codes for danger and loot, telegraphs). Sent with every request; the reviewer checks the art against it (W_ART_KEEP when empty)',
          examples: [["a dark crypt lit only by the hero's own candle", 'danger reads red, loot gold', 'enemies readable at 40 px']],
        },
        model: { type: 'string', pattern: '^[a-z0-9][a-z0-9.-]{2,60}$', default: 'gemini-2.5-flash-image', description: 'The image model (Gemini API). Default gemini-2.5-flash-image; gemini-3-pro-image-preview for the hardest assets', examples: ['gemini-2.5-flash-image', 'gemini-3-pro-image-preview'] },
        assets: {
          type: 'array',
          minItems: 1,
          maxItems: 600,
          description: "The images, one per id: assets/<id>.webp, imported from assets/index.ts as ART.<id>. Many pictures (an owner's 120 cars with their wheels): put what the first minutes don't draw in a later `chapter`, so Play doesn't wait for them",
          items: {
            type: 'object',
            properties: {
              id: { type: 'string', pattern: '^[a-z][a-z0-9-]{1,39}$', description: 'The file name and the key in ART (dashes become camelCase)' },
              kind: { enum: ['sprite', 'background', 'tile', 'ui', 'icon', 'keyart'], description: 'sprite, ui, icon: cut out on transparency and trimmed. background: opaque, cropped to fill. tile: opaque, square. keyart: the cover illustration (the first sprite as the main character, the top third left calm for the title) — draw it in host.qa({ cover })' },
              prompt: { type: 'string', minLength: 5, maxLength: 600, description: 'What this image shows ("the candle knight, three-quarter view, idle, holding a lantern")' },
              size: {
                oneOf: [
                  { type: 'integer', minimum: 16, maximum: 2048, description: 'The longest side in px' },
                  { type: 'array', items: { type: 'integer', minimum: 16, maximum: 2048 }, minItems: 2, maxItems: 2, description: '[width, height] in px' },
                ],
                description: 'The size in the game, in px: the longest side (sprite) or [width, height] (background). Default 256 for a sprite, [1280, 720] for a background',
              },
              from: { type: 'string', minLength: 3, maxLength: 400, description: 'An existing image instead of a new one: a file relative to game.yaml (assets-src/…, from `gp assets get`) or a URL; gp art cuts, mirrors, trims and fits it, and for pixel art snaps it to the palette' },
              cut: { type: 'array', items: { type: 'integer', minimum: 0, maximum: 16384 }, minItems: 4, maxItems: 4, description: 'With `from`: the rectangle of a sprite sheet, [x, y, w, h] in its pixels (`gp assets sheet` numbers the cells)' },
              flip: { type: 'boolean', description: 'With `from`: mirror it left to right' },
              upscale: {
                type: 'object',
                description: 'With `from`: made bigger with a pixel-art scaler, its design kept — `gp assets compare <image>` shows the methods side by side. xbrz (Zenju, the best on Candle Crypt), xbr (Hyllian), scale2x (EPX), nearest, or esrgan:<model.pth> (GP_PYTHON with spandrel); the result back in whole pixels in art.palette, small details (eyes, glints) kept pixel for pixel',
                properties: {
                  method: { type: 'string', pattern: '^(nearest|scale2x|xbr|xbrz|esrgan:.+)$', default: 'xbrz' },
                  factor: { type: 'integer', minimum: 2, maximum: 6, default: 2 },
                  keepDetails: { type: 'boolean', default: true },
                },
                required: ['method', 'factor'],
                additionalProperties: false,
                examples: [{ method: 'xbrz', factor: 2 }],
              },
              redraw: { type: 'boolean', description: 'With `from`: keep the design, redraw it — the image goes to the model as the design and comes back at this asset\'s size and technique (a game\'s 16 px sprite as a detailed 32 px one, same shapes, colours and character), then snapped to the palette' },
              frames: {
                type: 'array',
                minItems: 1,
                maxItems: 12,
                items: { type: 'string', minLength: 3, maxLength: 300 },
                description: 'A sprite\'s animation: one pose per frame ("left foot forward", "both feet together", "right foot forward"), each painted from the sprite itself so the character stays the same, at its scale. assets/<id>-1.webp …, FRAMES.<id> in assets/index.ts; play them with loadFrames + frameAt (@gp/art/assets). Squash, bob and sway need no frames: @gp/art/rig',
                examples: [['walking, left foot forward', 'walking, feet together', 'walking, right foot forward', 'walking, feet together']],
              },
              source: {
                enum: ['import'],
                description: "import: a finished picture the owner supplied, made into this asset by `gp art import <dir>` (the plain background removed, trimmed, fitted, WebP; provenance `source: owner` with the original's name and hash) — never sent to a model, `gp art` keeps it as it is. `from`, `frames`, `redraw` and `upscale` don't apply",
              },
              part: {
                type: 'object',
                description: "A part cut out of another sprite by `gp art import` (a car's wheel from cleanup.json `split.wheels`, its paint mask from `recolor`): drawn with its centre at `at` in the sprite `of`, in that sprite's pixels — assets/index.ts exports them as PARTS",
                properties: {
                  of: { type: 'string', pattern: '^[a-z][a-z0-9-]{1,39}$', description: 'The id of the sprite it was cut from' },
                  at: { type: 'array', items: { type: 'number', minimum: -4096, maximum: 4096 }, minItems: 2, maxItems: 2, description: "[x, y]: where its centre sits in that sprite, in the sprite's pixels" },
                },
                required: ['of', 'at'],
                additionalProperties: false,
                examples: [{ of: 'red-car', at: [96, 118] }],
              },
              chapter: {
                type: 'integer',
                minimum: 0,
                maximum: 9,
                default: 0,
                description:
                  "When it loads. 0 (the default): in the game's script, before Play — the size and load budget counts it. 1, 2 …: after Play — in the one-file upload a data block at the end of index.html that the game starts without (gp dev and a multi-file build: a file, fetched when needed), decoded when the game asks: `createAssets(ASSETS)` from @gp/art/assets, `await assets.ready(0)`, `assets.prefetch(1)` after Play, a low-res thumbnail drawn in its place until then. Put in chapter 0 what the first minutes draw (the first garage, the first cars); a part (wheel, paint mask) loads with its sprite. docs/guides/art.md#52-chapters-what-loads-before-play",
                examples: [1],
              },
            },
            required: ['id', 'kind', 'prompt'],
            additionalProperties: false,
          },
        },
      },
      required: ['style', 'assets'],
      additionalProperties: false,
    } satisfies JsonSchema,
    pixel: {
      type: 'object',
      description:
        "A pixel game's craft checks (`gp pixel`, docs/guides/pixel-art.md): where its sprites are and what they stand on. `gp pixel <id>` lints every sprite — colours, noise, clusters, the outline, doubled corners, bumps, values, pillow shading, mixels, soft edges, tile seams, the set's one light — and writes qa/pixel.md and qa/pixel-sheet.png. PNGs of `art.technique: pixel` in assets/ are read without being listed here",
      properties: {
        sprites: {
          type: 'array',
          minItems: 1,
          maxItems: 40,
          items: { type: 'string', minLength: 3 },
          description: "The game's own sprites, relative to its folder: modules of string-grid sprites (exports of { frames: string[][], pal }, { rows, key } or PixelArt from @gp/art/pixel), PNGs or folders of PNGs",
          examples: [['sprites.ts'], ['sprites.ts', 'assets-src/tiles']],
        },
        background: { type: 'string', pattern: '^#[0-9a-fA-F]{6}$', description: 'The colour the sprites mostly stand on in play: the contrast check (P_CONTRAST) — a sprite whose edge is as light as it melts into it', examples: ['#2e2438'] },
      },
      additionalProperties: false,
    } satisfies JsonSchema,
    balance: {
      type: 'object',
      description:
        "The balance as designed, before the tables: the session's length comes first (game.yaml money.session.minutes, entered by hand), then the one number everything converts into — the anchor — and the model (`balanceModel()`) is built in it. docs/guides/upgrades.md#start-from-time-then-the-anchor",
      properties: {
        anchor: {
          type: 'object',
          description:
            "The genre's anchor: the one number the balance converts everything into (an RPG's time to kill and time to die, a sprint's distance over the session, a lap time, a tower defense's damage per wave for the budget, a roguelike's rooms a run, an idle game's income per minute). Declared, `gp balance` and `gp qa` fail on the model's first-session checks (the first reward within a minute, a new thing every 3 min of the first 10, no two big rewards in a minute, no hard streak, no jump in a stage's time, a goal in reach at the session's end, a meta of 2+ sessions) like on the others; without it they warn (W_BALANCE_ANCHOR on a portal). The model's `measure` should name it. A roguelite whose stages are a run's waves or floors says `shape: run`: the campaign's per-stage checks give way to a run's",
          properties: {
            name: { type: 'string', minLength: 2, maxLength: 60, description: 'What it is, in a few words ("clear time", "rooms a run", "income a minute")' },
            unit: { type: 'string', minLength: 1, maxLength: 20, description: 'Its unit ("s", "m", "rooms", "coins/min")' },
            says: { type: 'string', minLength: 10, maxLength: 200, description: 'What the number says, in a sentence ("how long one room takes a fresh hero")' },
            shape: {
              type: 'string',
              enum: ['campaign', 'run'],
              description:
                "How the balance model's stages are played (default campaign). campaign: a stage at a time, retried until cleared, the last one replayed for coins — the per-stage checks (no grind, no hard streak, stage time grows steadily, no stretch that plays itself) apply. run: a roguelite's run (waves, floors, rooms a run) — every attempt starts at the first stage and goes on until a loss, purchases come between runs; those campaign checks are left out and the run's are made instead: a fresh first run lasts 2+ min, the fully progressed player gets 1.5× as far (or near the end), a winning run fits the session, the runs get further within the first session",
            },
          },
          required: ['name', 'unit', 'says'],
          additionalProperties: false,
          examples: [{ name: 'clear time', unit: 's', says: 'how long one room takes a fresh hero' }, { name: 'waves a run', unit: 'waves', says: 'how many of the 20 waves a run of the average player clears', shape: 'run' }],
        },
        difficulty: {
          type: 'object',
          description:
            "The difficulty as designed, measured by the bot skill ladder: the share of runs each skill should win from a fresh save, and how long a winning run lasts (Frankengun's targets: a skilled player — the owner's level — wins ≈ 4 runs of 20, a winning run 30–40 min). balance() reports the runs per skill (`skills: { naive, average, skilled }` or tagged `runs`: docs/guides/upgrades.md → the skill ladder); `gp balance` and `gp qa` fail a win rate outside the target ± tolerance (judged from 20 runs) and a winning run outside `winningRunMin`. With `winningRunMin`, `gp forecast` takes the winning run's length as the session (the bot's measured one, else the range's middle) in place of money.session.minutes, and scales money.session.breaks to it (forecast.md's Session row says so): the whole game is a run, and a player who wins plays it through",
          properties: {
            naive: winRateSchema('The naive bot (a new player: slow, imprecise, no plan): its win rate from a fresh save'),
            average: winRateSchema("The average bot (the curve's player): its win rate from a fresh save"),
            skilled: winRateSchema("The skilled bot (a good human, the owner's level: tighter aim, quicker, dodges most telegraphs): its win rate from a fresh save"),
            winningRunMin: { type: 'array', items: { type: 'number', minimum: 1, maximum: 240 }, minItems: 2, maxItems: 2, description: "[shortest, longest] minutes of a winning run (the skilled bot's median, else the best skill that won); also the session `gp forecast` reads", examples: [[30, 40]] },
          },
          additionalProperties: false,
          examples: [{ skilled: { winRate: 0.2, tolerance: 0.05 }, winningRunMin: [30, 40] }],
        },
      },
      additionalProperties: false,
    } satisfies JsonSchema,
  },
  required: [] as string[],
  example: 'kit: code\nentry: main.ts\nbackground: "#0f2230"\nengine: { name: canvas }',
} as const;
