// The code kit's feel section: how the game answers the player, measured frame by frame on the virtual clock (the one
// `gp video` films on: @gp/cli/clock), so a busy machine changes nothing. CrazyGames' quality page asks that "the game
// responds quickly to the player's actions" and that it plays "consistently across… 144 Hz"; the literature puts the
// numbers (docs/research/game-design-2026-10.md §1.2, top-10 ranks 2, 6, 7 and 9):
//   1. input → response: after each of QA's taps and keys in play, the frames until the screen changes there (the canvas
//      around the tap or around host.qa({ hero }), or a DOM change) — Nielsen's 0.1 s: warn when under 90 % answer within
//      100 ms (the display and the touch panel add their own, which no headless browser measures);
//   2. feedback channels: for each of the game's moments (host.happytime, host.twist, host.roundEnd, a 'score' event)
//      the channels that answer within 150 ms — a visual change, a sound started, new screen motion, a vibration
//      (Hicks et al. 2018: juice is one action answered through several channels) — warn when scoring moments get < 2;
//   3. flashes: full-frame relative luminance, every frame at 60 Hz — more than 3 flashes a second FAILS (WCAG 2.3.1;
//      a flash is a pair of opposite changes ≥ 10 % with the darker below 0.8); a cut by ≥ 40 % in two frames when the
//      screen changes warns (never a cut to white); with prefers-reduced-motion the same demo must not shake or flash;
//   4. frame-rate independence: the same seeded demo for 10 s at 60 Hz and at 144 Hz, then host.qa({ digest }) (or the
//      last 'score' event) compared;
//   5. variety over time: host.seen(kind, id) counted at 2, 5 and 10 minutes of a long demo run, and the gaps between
//      rewards (host.happytime, host.twist) — warn when nothing new appears for over 90 s of play.
// Everything but the flashes warns. The numbers go to qa/feel.json; the judges below are pure (test/feel.test.ts).

import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Page } from 'playwright';
import type { QaContext } from '@gp/qa';
import { installProbe } from '@gp/qa/probe';
import { virtualClock } from '@gp/cli/clock';

/* eslint-disable @typescript-eslint/no-explicit-any */

const S = 'feel';
/** CrazyGames' small frame (800×450): every measure is about frames, not pixels, and a smaller page draws its frames faster */
const VIEW = { width: 800, height: 450 };
/** An input answered within this is instantaneous (Nielsen's 0.1 s limit; Raaen et al. 2014: 51–90 ms go unnoticed) */
export const RESPONSE_MS = 100;
/** …and this share of the inputs must be (warn under it) */
export const RESPONSE_SHARE = 0.9;
/** An input nothing answers within this did nothing (a key the game doesn't use) */
export const RESPONSE_MAX_MS = 500;
/** A moment's channels count when they answer within this */
export const CHANNEL_MS = 150;
/** A scoring moment wants at least this many channels (feedback + juice) */
export const MIN_CHANNELS = 2;
/** WCAG 2.3.1: a transition is a change of relative luminance of at least this, the darker side below FLASH_DARK */
export const FLASH_DELTA = 0.1;
export const FLASH_DARK = 0.8;
/** …and no more than this many flashes (pairs of opposite transitions) in any one second */
export const MAX_FLASHES_PER_SEC = 3;
/** A screen change that moves the frame's luminance by this within two frames is a cut (to white, to black) */
export const CUT_DELTA = 0.4;
/** Seconds of demo play compared at 60 and 144 Hz */
export const DIGEST_SEC = 10;
/** A numeric digest may differ by this share (a fixed-step simulation is exact; a dt-scaled one drifts) */
export const DIGEST_TOLERANCE = 0.02;
/** host.seen is counted at these minutes of play */
export const VARIETY_MARKS_SEC = [120, 300, 600];
/** Nothing new for longer than this, in seconds of play, warns */
export const VARIETY_GAP_SEC = 90;
/** The median gap between rewards over this warns (Vampire Survivors: ≈ 1 reward every 23 s) */
export const REWARD_GAP_SEC = 60;
/** Screen motion counts as a channel from this many CSS px of new movement */
export const MOTION_PX = 1.5;
/** The moments that score: they want MIN_CHANNELS */
const SCORING = new Set(['highlight', 'score']);

// --- The judges (pure) ----------------------------------------------------------------------------------------------

const median = (xs: number[]): number | null => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  return s.length % 2 ? s[s.length >> 1]! : (s[s.length / 2 - 1]! + s[s.length / 2]!) / 2;
};
const quantile = (xs: number[], q: number): number | null => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(q * s.length))]!;
};

export interface InputSample {
  /** 'tap' (the canvas), 'key', 'ui' (a button) */
  kind: string;
  /** The key's code, 'pointer' for a tap */
  code: string;
  /** ms to the first visible change (canvas or DOM); null: none within RESPONSE_MAX_MS */
  ms: number | null;
  /** A control trial: the same watch with no input (what the game's own motion "answers" by itself) */
  sham?: boolean;
  /** What changed first: the canvas, the DOM or the hero's place */
  by?: 'canvas' | 'dom' | 'hero';
}

/** One input (or control trial) as the page saw it: the change around it frame by frame since the frame before it */
export interface InputTrial {
  kind: string;
  code: string;
  play?: boolean;
  sham?: boolean;
  /** Changed share of the watched region's pixels, one a frame after the input (vs the frame before it) */
  series: number[];
  /** The same share between the frame before the input and the frames before that: the scene's own drift by lag */
  drift?: number[];
  /** 'region' (around a tap), 'hero' (around host.qa({ hero }) for a key), 'frame' (the whole frame) */
  region: 'region' | 'hero' | 'frame';
  /** ms until the hero moved (≥ 1 px), until the DOM changed */
  heroMs: number | null;
  domMs: number | null;
}

/**
 * When each input was first answered: the DOM, the hero moving, or the watched pixels changing by more than the scene's
 * own drift (twice it, at the same lag), a floor, and 1.25× the most any control trial of its kind changed at that frame
 * (a control trial is held to the other control trials)
 */
export function inputVisualMs(trials: InputTrial[], frameMs = 1000 / 60): InputSample[] {
  const key = (i: InputTrial) => `${i.kind} ${i.code} ${i.region}`;
  return trials.map((i) => {
    const shams = trials.filter((o) => o !== i && o.sham && key(o) === key(i));
    const floor = i.region === 'hero' ? 0.03 : i.region === 'region' ? 0.01 : 0.0015;
    let canvas = Infinity;
    for (let k = 0; k < i.series.length; k++) {
      const lag = k + 1;
      const drift = i.drift?.length ? (i.drift[Math.min(lag, i.drift.length - 1)] ?? 0) : 0;
      const noise = Math.max(0, ...shams.map((o) => o.series[k] ?? 0));
      if (i.series[k]! > Math.max(floor, (i.region === 'hero' ? 3 : 2) * drift, 1.25 * noise)) {
        canvas = lag * frameMs;
        break;
      }
    }
    const ms = Math.min(canvas, i.heroMs ?? Infinity, i.domMs ?? Infinity);
    const by: InputSample['by'] = ms === canvas ? 'canvas' : ms === i.domMs ? 'dom' : 'hero';
    return { kind: i.kind, code: i.code, ms: Number.isFinite(ms) && ms <= RESPONSE_MAX_MS ? ms : null, ...(Number.isFinite(ms) ? { by } : {}), ...(i.sham ? { sham: true } : {}) };
  });
}

export interface ResponseReport {
  measured: number;
  medianMs: number | null;
  p90Ms: number | null;
  /** Share of the measured inputs answered within RESPONSE_MS */
  share: number | null;
  /** Inputs of a kind (and key) nothing ever answered: the game doesn't use them, not counted */
  unused: string[];
  /** The kinds counted, each with its median */
  kinds: Record<string, { n: number; medianMs: number | null; answered: number }>;
}

/**
 * Input → first visible change. A kind of input (a tap, a key by its code, a button) counts when the game answers it
 * clearly more often than the control trials with no input (its own animation alone) — by a third of the trials, and
 * at least twice; the rest are 'unused' (a key the game doesn't read)
 */
export function responseReport(inputs: InputSample[]): ResponseReport {
  // The arrows and WASD steer alike: one group; every other key its own
  const group = (i: InputSample) => (i.kind === 'key' ? (/^(Arrow|Key[WASD]$)/.test(i.code) ? 'key arrows' : `key ${i.code}`) : i.kind);
  const groups = new Map<string, InputSample[]>();
  const shams = new Map<string, InputSample[]>();
  for (const i of inputs) {
    const m = i.sham ? shams : groups;
    m.set(group(i), [...(m.get(group(i)) ?? []), i]);
  }
  const rate = (l: InputSample[] | undefined) => (l?.length ? l.filter((i) => i.ms !== null).length / l.length : 0);
  const used: InputSample[] = [];
  const unused: string[] = [];
  const kinds: ResponseReport['kinds'] = {};
  for (const [g, list] of groups) {
    if (list.filter((i) => i.ms !== null).length < Math.min(2, list.length) || rate(list) < rate(shams.get(g)) + 1 / 3) {
      unused.push(g);
      continue;
    }
    used.push(...list);
    const k = list[0]!.kind;
    const prev = kinds[k] ?? { n: 0, medianMs: null, answered: 0 };
    kinds[k] = { n: prev.n + list.length, medianMs: null, answered: prev.answered + list.filter((i) => i.ms !== null).length };
  }
  for (const k of Object.keys(kinds)) kinds[k]!.medianMs = median(used.filter((i) => i.kind === k && i.ms !== null).map((i) => i.ms!));
  // An unanswered input of a used kind counts as slow (RESPONSE_MAX_MS) in the median and the p90
  const ms = used.map((i) => i.ms ?? RESPONSE_MAX_MS);
  return {
    measured: used.length,
    medianMs: median(ms),
    p90Ms: quantile(ms, 0.9),
    share: used.length ? used.filter((i) => i.ms !== null && i.ms <= RESPONSE_MS).length / used.length : null,
    unused,
    kinds,
  };
}

export interface MomentSample {
  kind: string;
  /** The channels that answered within CHANNEL_MS */
  channels: string[];
}

export interface ChannelReport {
  /** Per kind of moment: how many, the median number of channels, how often each channel answered */
  kinds: Record<string, { n: number; medianChannels: number; channels: Record<string, number> }>;
  /** The scoring moments' median channel count (null: none) */
  scoringMedian: number | null;
}

export function channelReport(moments: MomentSample[]): ChannelReport {
  const kinds: ChannelReport['kinds'] = {};
  for (const m of moments) {
    const k = (kinds[m.kind] ??= { n: 0, medianChannels: 0, channels: {} });
    k.n++;
    for (const c of m.channels) k.channels[c] = (k.channels[c] ?? 0) + 1;
  }
  for (const [k, v] of Object.entries(kinds)) v.medianChannels = median(moments.filter((m) => m.kind === k).map((m) => m.channels.length)) ?? 0;
  return { kinds, scoringMedian: median(moments.filter((m) => SCORING.has(m.kind)).map((m) => m.channels.length)) };
}

export interface Transition {
  /** ms of the change's end */
  t: number;
  from: number;
  to: number;
}

/**
 * WCAG 2.3.1 general flashes from a luminance series (relative luminance 0…1, one value a frame): transitions are the
 * swings of a zigzag with a FLASH_DELTA threshold whose darker side is below FLASH_DARK; a flash is a pair of opposite
 * transitions. Returns the most flashes in any one-second window, and when that window ends
 */
export function flashes(series: { t: number; lum: number }[], delta = FLASH_DELTA, dark = FLASH_DARK): { maxPerSec: number; at: number | null; transitions: Transition[] } {
  const trans: Transition[] = [];
  if (series.length < 2) return { maxPerSec: 0, at: null, transitions: trans };
  let dir = 0;
  let hi = series[0]!;
  let lo = series[0]!;
  let ext = series[0]!;
  let start = series[0]!;
  const push = (a: { t: number; lum: number }, b: { t: number; lum: number }) => {
    if (Math.min(a.lum, b.lum) < dark) trans.push({ t: b.t, from: a.lum, to: b.lum });
  };
  for (const s of series) {
    if (dir === 0) {
      if (s.lum > hi.lum) hi = s;
      if (s.lum < lo.lum) lo = s;
      if (hi.lum - lo.lum >= delta) {
        dir = hi.t > lo.t ? 1 : -1;
        start = dir === 1 ? lo : hi;
        ext = dir === 1 ? hi : lo;
      }
      continue;
    }
    if ((dir === 1 && s.lum >= ext.lum) || (dir === -1 && s.lum <= ext.lum)) ext = s;
    else if (Math.abs(ext.lum - s.lum) >= delta) {
      push(start, ext);
      start = ext;
      ext = s;
      dir = -dir;
    }
  }
  if (dir !== 0 && Math.abs(ext.lum - start.lum) >= delta) push(start, ext);
  let maxPerSec = 0;
  let at: number | null = null;
  for (let i = 0, j = 0; i < trans.length; i++) {
    while (trans[i]!.t - trans[j]!.t > 1000) j++;
    const n = Math.floor((i - j + 1) / 2);
    if (n > maxPerSec) {
      maxPerSec = n;
      at = trans[i]!.t;
    }
  }
  return { maxPerSec, at, transitions: trans };
}

/** The largest change of luminance within two frames around a screen change (ms), null without frames there */
export function cutAt(series: { t: number; lum: number }[], at: number, windowMs = 500): number | null {
  let max: number | null = null;
  for (let i = 2; i < series.length; i++) {
    const s = series[i]!;
    if (s.t < at - 50 || s.t > at + windowMs) continue;
    const d = Math.max(Math.abs(s.lum - series[i - 1]!.lum), Math.abs(s.lum - series[i - 2]!.lum));
    max = Math.max(max ?? 0, d);
  }
  return max;
}

/** Frames that jolt: the whole frame shakes (its motion reverses at ≥ MOTION_PX) or its luminance jumps ≥ FLASH_DELTA in two frames */
export function jolts(frames: { lum: number | null; dx: number; dy: number }[]): { shake: number; flash: number } {
  let shake = 0;
  let flash = 0;
  let prev: { dx: number; dy: number; age: number } | null = null;
  for (let i = 0; i < frames.length; i++) {
    const f = frames[i]!;
    const d = Math.hypot(f.dx, f.dy);
    if (d >= MOTION_PX) {
      if (prev && prev.age <= 2 && prev.dx * f.dx + prev.dy * f.dy < 0) shake++;
      prev = { dx: f.dx, dy: f.dy, age: 0 };
    } else if (prev) prev.age++;
    const a = f.lum;
    const b = i >= 2 ? frames[i - 2]!.lum : null;
    if (a !== null && b !== null && Math.abs(a - b) >= FLASH_DELTA) flash++;
  }
  return { shake, flash };
}

/** The digests at 60 and 144 Hz agree: equal strings, numbers within DIGEST_TOLERANCE of the larger */
export function digestsAgree(a: string | number, b: string | number, tol = DIGEST_TOLERANCE): boolean {
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));
  return String(a) === String(b);
}

export interface VarietyReport {
  /** Seconds of play the demo reached */
  playedSec: number;
  /** Distinct ids seen by each mark (minutes of play; null: the demo didn't get there) */
  at: { sec: number; distinct: number | null; kinds: Record<string, number> | null }[];
  /** The longest stretch of play with nothing new: from when to when, seconds of play */
  longestGap: { from: number; to: number; sec: number } | null;
  /** Gaps between rewards (s of play) */
  rewardGaps: { n: number; medianSec: number | null; maxSec: number | null };
}

export function varietyReport(seen: { kind: string; id: string; playedSec: number }[], playedSec: number, rewards: number[], marks = VARIETY_MARKS_SEC): VarietyReport {
  const at = marks.map((sec) => {
    if (playedSec < sec) return { sec, distinct: null, kinds: null };
    const by = seen.filter((s) => s.playedSec <= sec);
    const kinds: Record<string, number> = {};
    for (const s of by) kinds[s.kind] = (kinds[s.kind] ?? 0) + 1;
    return { sec, distinct: by.length, kinds };
  });
  let longestGap: VarietyReport['longestGap'] = null;
  if (seen.length) {
    const ts = [0, ...seen.map((s) => s.playedSec).sort((a, b) => a - b), playedSec];
    for (let i = 1; i < ts.length; i++) {
      const sec = ts[i]! - ts[i - 1]!;
      if (!longestGap || sec > longestGap.sec) longestGap = { from: ts[i - 1]!, to: ts[i]!, sec };
    }
  }
  const r = [...rewards].sort((a, b) => a - b);
  const gaps = r.slice(1).map((t, i) => t - r[i]!);
  return { playedSec, at, longestGap, rewardGaps: { n: gaps.length, medianSec: median(gaps), maxSec: gaps.length ? Math.max(...gaps) : null } };
}

// --- In the page ----------------------------------------------------------------------------------------------------

/**
 * The init script (after the virtual clock and the probe): window.__gpFeel samples the game's canvas once a frame when
 * QA calls sample() — its luminance, its motion (row and column profiles matched), a 320×180 grey frame and, when
 * armed, a 32×32 region — and logs inputs, the host's moments, DOM mutations and vibrations. Self-contained
 */
export const feelProbe = (): void => {
  const w = window as any;
  if (w.__gpFeel) return;
  const W = 320;
  const H = 180;
  const RS = 32;
  const RING = 24;
  const lin = new Float32Array(256);
  for (let i = 0; i < 256; i++) {
    const c = i / 255;
    lin[i] = c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  }
  const F: any = (w.__gpFeel = { measure: false, frames: [], moments: [], inputs: [], vib: [], armed: null, hooked: false });
  let big: CanvasRenderingContext2D | null = null;
  let small: CanvasRenderingContext2D | null = null;
  const ring: Uint8Array[] = [];
  const rring: Uint8Array[] = [];
  let prevCol: Float32Array | null = null;
  let prevRow: Float32Array | null = null;
  const lastMut = new WeakMap<Node, number>();
  const pending: any[] = [];
  let mo: MutationObserver | null = null;
  const ctx2d = (n: number, m: number) => {
    const c = document.createElement('canvas');
    c.width = n;
    c.height = m;
    const g = c.getContext('2d', { willReadFrequently: true })!;
    g.imageSmoothingEnabled = true;
    g.imageSmoothingQuality = 'high';
    return g;
  };
  const gameCanvas = (): HTMLCanvasElement | null => {
    let best: HTMLCanvasElement | null = null;
    let area = 0;
    for (const c of document.querySelectorAll('canvas')) {
      const r = c.getBoundingClientRect();
      const a = r.width * r.height;
      if (a > area && c.width > 0 && c.height > 0 && getComputedStyle(c).visibility !== 'hidden') {
        best = c;
        area = a;
      }
    }
    return best;
  };
  const grey = (d: Uint8ClampedArray, n: number) => {
    const g = new Uint8Array(n);
    for (let i = 0; i < n; i++) g[i] = (d[i * 4]! * 77 + d[i * 4 + 1]! * 150 + d[i * 4 + 2]! * 29) >> 8;
    return g;
  };
  const changed = (a: Uint8Array, b: Uint8Array) => {
    let n = 0;
    for (let i = 0; i < a.length; i++) if (Math.abs(a[i]! - b[i]!) > 20) n++;
    return n / a.length;
  };
  // The shift of b against a (mean-free profiles), in samples: the best whole shift within ±max, refined below a sample
  // by Lucas–Kanade steps (a shake is often a pixel or two); 0 unless the shifted profile matches better (8 %: the HUD
  // and the far parallax layers stand still, so a shake improves the match by 10–20 %, a pan by under 5 %)
  const interp = (p: Float32Array, x: number) => {
    const i = Math.floor(x);
    const f = x - i;
    return (p[i] ?? 0) * (1 - f) + (p[i + 1] ?? 0) * f;
  };
  const errAt = (a: Float32Array, b: Float32Array, s: number, max: number) => {
    let e = 0;
    for (let i = max; i < a.length - max; i++) e += Math.abs(b[i]! - interp(a, i - s));
    return e;
  };
  const shiftOf = (a: Float32Array, b: Float32Array, max: number) => {
    let s = 0;
    let bestE = Infinity;
    for (let k = -max; k <= max; k++) {
      const e = errAt(a, b, k, max);
      if (e < bestE) {
        bestE = e;
        s = k;
      }
    }
    for (let it = 0; it < 3; it++) {
      let num = 0;
      let den = 0;
      for (let i = max; i < a.length - max; i++) {
        const g = (interp(a, i - s + 1) - interp(a, i - s - 1)) / 2;
        num += (b[i]! - interp(a, i - s)) * g;
        den += g * g;
      }
      if (!(den > 0)) break;
      const d = Math.max(-1, Math.min(1, -num / den));
      s += d;
      if (Math.abs(d) < 0.02) break;
    }
    const e0 = errAt(a, b, 0, max);
    return Math.abs(s) >= 0.25 && Math.abs(s) <= max && errAt(a, b, s, max) < e0 * 0.92 ? s : 0;
  };
  const profiles = (g: Uint8Array) => {
    const col = new Float32Array(W);
    const row = new Float32Array(H);
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        const v = g[y * W + x]!;
        col[x] += v / H;
        row[y] += v / W;
      }
    const free = (p: Float32Array) => {
      let m = 0;
      for (const v of p) m += v / p.length;
      for (let i = 0; i < p.length; i++) p[i] -= m;
      return p;
    };
    return { col: free(col), row: free(row) };
  };
  const kindOf = (t: EventTarget | null) => (t instanceof HTMLCanvasElement ? 'tap' : (t as Element)?.closest?.('button, [role=button], a, input, select') ? 'ui' : 'tap');
  /** Where host.qa({ hero }) says the player's object is now (its centre), null without one */
  const heroAt = (): { x: number; y: number } | null => {
    try {
      const hq = w.__gp?.host?.qaDriver?.hero;
      const r = typeof hq === 'function' ? hq() : hq;
      return r && r.w > 0 ? { x: r.x + r.w / 2, y: r.y + r.h / 2 } : null;
    } catch {
      return null;
    }
  };
  const start = (rec: any, region: boolean) => {
    const src = region ? rring : ring;
    if (!src.length) return;
    const ref = src[src.length - 1]!;
    const drift: number[] = [0];
    for (let L = 1; L < src.length; L++) drift.push(changed(ref, src[src.length - 1 - L]!));
    if (rec.series) rec.drift = drift.map((d) => Math.round(d * 1000) / 1000);
    pending.push({ rec, ref, drift, region, hero: region && F.armed?.hero ? heroAt() : null, t0: rec.t, k: 0 });
  };
  const onInput = (kind: string, code: string) => {
    if (!F.measure) return;
    const h = w.__gp?.host;
    const rec = { t: performance.now(), kind, code, play: !!h?.isPlaying && !h?.paused, visualMs: null as number | null, domMs: null as number | null, heroMs: null as number | null, series: [] as number[], region: F.armed ? (F.armed.hero ? 'hero' : 'region') : 'frame' };
    F.inputs.push(rec);
    start(rec, !!F.armed);
  };
  F.sham = (kind: string, code: string) => {
    const h = w.__gp?.host;
    const rec = { t: performance.now(), kind, code, sham: true, play: !!h?.isPlaying && !h?.paused, visualMs: null as number | null, domMs: null as number | null, heroMs: null as number | null, series: [] as number[], region: F.armed ? (F.armed.hero ? 'hero' : 'region') : 'frame' };
    F.inputs.push(rec);
    start(rec, !!F.armed);
  };
  addEventListener('pointerdown', (e) => e.isTrusted && onInput(kindOf(e.target), 'pointer'), true);
  addEventListener('keydown', (e) => e.isTrusted && !e.repeat && onInput('key', e.code), true);
  if (navigator.vibrate) {
    const vib = navigator.vibrate.bind(navigator);
    (navigator as any).vibrate = (p: any) => {
      F.vib.push(performance.now());
      return vib(p);
    };
  }
  const hook = () => {
    const gp = w.__gp;
    if (F.hooked || !gp?.events?.on) return;
    F.hooked = true;
    gp.events.on((e: { type: string; data: any }) => {
      if (!['highlight', 'twist', 'round:end', 'score', 'fail', 'screen'].includes(e.type)) return;
      const rec = { t: performance.now(), kind: e.type, playedSec: gp.host?.playedSec ?? 0, visualMs: null as number | null, domMs: null as number | null, value: e.type === 'score' ? (e.data?.score ?? e.data?.value ?? e.data?.n ?? null) : null };
      F.moments.push(rec);
      if (F.measure) start(rec, false);
    });
  };
  const dom = (now: number) => {
    if (!mo) {
      if (!document.body) return;
      mo = new MutationObserver(() => {});
      mo.observe(document.body, { subtree: true, childList: true, attributes: true, characterData: true });
      return;
    }
    const recs = mo.takeRecords();
    for (const r of recs) {
      const n = r.target;
      const before = lastMut.get(n) ?? -1e9;
      for (const p of pending) if (p.rec.domMs === null && before < p.t0 - 500 && now >= p.t0) p.rec.domMs = now - p.t0;
      lastMut.set(n, now);
    }
  };
  /** Once a frame without pictures: the hooks, the DOM's mutations (so they don't pile up) */
  F.tick = () => {
    hook();
    dom(performance.now());
  };
  /** Once a frame with pictures: after __gpAdvance, in the same task (a WebGL buffer is still there) */
  F.sample = () => {
    hook();
    const now = performance.now();
    const c = gameCanvas();
    const h = w.__gp?.host;
    const play = !!h?.isPlaying && !h?.paused;
    let lum: number | null = null;
    let dx = 0;
    let dy = 0;
    if (c) {
      big ??= ctx2d(W, H);
      try {
        big.clearRect(0, 0, W, H);
        big.drawImage(c, 0, 0, c.width, c.height, 0, 0, W, H);
        const d = big.getImageData(0, 0, W, H).data;
        let L = 0;
        for (let i = 0; i < W * H; i++) L += 0.2126 * lin[d[i * 4]!]! + 0.7152 * lin[d[i * 4 + 1]!]! + 0.0722 * lin[d[i * 4 + 2]!]!;
        lum = L / (W * H);
        const g = grey(d, W * H);
        const p = profiles(g);
        const r = c.getBoundingClientRect();
        if (prevCol && prevRow) {
          dx = (shiftOf(prevCol, p.col, 8) * r.width) / W;
          dy = (shiftOf(prevRow, p.row, 6) * r.height) / H;
        }
        prevCol = p.col;
        prevRow = p.row;
        ring.push(g);
        if (ring.length > RING) ring.shift();
        if (F.armed) {
          small ??= ctx2d(RS, RS);
          const a = F.armed;
          const sx = c.width / r.width;
          const sy = c.height / r.height;
          small.clearRect(0, 0, RS, RS);
          small.drawImage(c, (a.x - r.left) * sx, (a.y - r.top) * sy, a.w * sx, a.h * sy, 0, 0, RS, RS);
          rring.push(grey(small.getImageData(0, 0, RS, RS).data, RS * RS));
          if (rring.length > RING) rring.shift();
        }
      } catch {
        lum = null;
      }
    }
    dom(now);
    for (let i = pending.length - 1; i >= 0; i--) {
      const p = pending[i];
      p.k++;
      const cur = p.region ? rring[rring.length - 1] : ring[ring.length - 1];
      if (p.rec.series && cur && cur.length === p.ref.length) {
        // An input: the change frame by frame, judged in Node against the control trials (inputVisualMs)
        p.rec.series.push(Math.round(changed(cur, p.ref) * 1000) / 1000);
        const h = p.hero ? heroAt() : null;
        if (h && p.rec.heroMs === null && Math.hypot(h.x - p.hero.x, h.y - p.hero.y) >= 1) p.rec.heroMs = now - p.t0;
      } else if (p.rec.visualMs === null && cur && cur.length === p.ref.length) {
        const drift = p.drift[Math.min(p.k, p.drift.length - 1)] ?? 0;
        // Around the hero: the hero moved, or a clear change (its own surroundings move: germs, sparks)
        const floor = p.hero ? 0.03 : p.region ? 0.01 : 0.0015;
        const h = p.hero ? heroAt() : null;
        if (changed(cur, p.ref) > Math.max(floor, (p.hero ? 3 : 2) * drift) || (h && Math.hypot(h.x - p.hero.x, h.y - p.hero.y) >= 1)) p.rec.visualMs = now - p.t0;
      }
      if (now - p.t0 > 500 || (p.rec.visualMs !== null && p.rec.domMs !== null)) pending.splice(i, 1);
    }
    if (F.measure && F.frames.length < 30000) F.frames.push({ t: now, play, lum, dx, dy });
  };
  F.arm = (r: { x: number; y: number; w: number; h: number; hero?: boolean } | null) => {
    F.armed = r;
    rring.length = 0;
  };
  F.sounds = () =>
    ((w.__gpProbe?.sources ?? []) as { t: number; when: number; now: number; bus: string | null }[])
      .filter((s) => s.bus !== 'music' && s.bus !== 'ambient')
      .map((s) => ({ t: s.t + Math.max(0, (s.when || 0) - s.now) * 1000 }));
};

// --- Driving the page -----------------------------------------------------------------------------------------------

/** n frames of dt ms on the virtual clock: each advance, then the sample (or the tick); a real task between frames */
export async function frames(page: Page, n: number, dt: number, sample: boolean, until?: 'loaded' | 'stopped'): Promise<number> {
  return page.evaluate(
    async ({ n, dt, sample, until }) => {
      const w = window as any;
      const yieldTask = () =>
        new Promise<void>((r) => {
          const ch = new MessageChannel();
          ch.port1.onmessage = () => r();
          ch.port2.postMessage(0);
        });
      for (let i = 0; i < n; i++) {
        w.__gpAdvance(dt);
        if (sample) w.__gpFeel.sample();
        else w.__gpFeel.tick();
        await yieldTask();
        if (until === 'loaded' && w.__gp?.host && w.__portal?.calls.some((c: { fn: string }) => c.fn === 'loadingStop')) return i + 1;
        if (until === 'stopped' && !(w.__gp?.host?.isPlaying && !w.__gp.host.paused)) return i + 1;
      }
      return n;
    },
    { n, dt, sample, until },
  );
}

export const F60 = 1000 / 60;

/** A page on the virtual clock with the probe and the feel probe; loaded and half a second on the title */
export async function openVirtual(ctx: QaContext, opts: { reducedMotion?: boolean; browser?: import('playwright').Browser; view?: { width: number; height: number } } = {}): Promise<{ page: Page; close: () => Promise<void>; ok: boolean }> {
  const context = await (opts.browser ?? ctx.browser).newContext({ viewport: opts.view ?? VIEW, ...(opts.reducedMotion ? { reducedMotion: 'reduce' as const } : {}) });
  await context.addInitScript(virtualClock);
  await context.addInitScript(installProbe);
  await context.addInitScript(feelProbe);
  const page = await context.newPage();
  await page.goto(`${ctx.url}?seed=7`);
  let ok = false;
  for (let i = 0; i < 40 && !ok; i++) {
    await frames(page, 30, F60, false, 'loaded');
    ok = await page.evaluate(() => !!(window as any).__gp?.host && (window as any).__portal?.calls.some((c: { fn: string }) => c.fn === 'loadingStop'));
  }
  if (ok) await frames(page, 30, F60, false);
  ok &&= await page.evaluate(() => typeof (window as any).__gp.host.qaDriver?.play === 'function');
  return { page, close: () => context.close(), ok };
}

/** Into a run the player's way: a click on Play (it unlocks the sound), else host.qa play() */
export async function enterPlay(page: Page): Promise<void> {
  const box = await page.locator('[data-gp=play]').first().boundingBox({ timeout: 100 }).catch(() => null);
  if (box && box.width > 0) await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  else await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
  await frames(page, 2, F60, true);
  // A dialogue in the way: its skip
  const skip = await page.locator('[data-gp=dialog-skip]').first().boundingBox({ timeout: 100 }).catch(() => null);
  if (skip && skip.width > 0) await page.mouse.click(skip.x + skip.width / 2, skip.y + skip.height / 2);
}

export const demoOn = (page: Page) =>
  page.evaluate(() => {
    const d = (window as any).__gp.host.qaDriver;
    if (typeof d.demo !== 'function') return false;
    d.demo();
    return true;
  });

export const playing = (page: Page) => page.evaluate(() => !!(window as any).__gp?.host?.isPlaying && !(window as any).__gp?.host?.paused);

/** The game's digest (host.qa digest), else the last 'score' event's value, else null */
const digestOf = (page: Page) =>
  page.evaluate(() => {
    const w = window as any;
    const d = w.__gp.host.qaDriver;
    if (typeof d.digest === 'function') {
      try {
        const v = d.digest();
        return { from: 'digest', value: typeof v === 'number' ? v : String(v) };
      } catch (e) {
        return { from: 'digest', value: null, error: String(e) };
      }
    }
    const s = (w.__gpFeel.moments as { kind: string; value: unknown }[]).filter((m) => m.kind === 'score' && typeof m.value === 'number').at(-1);
    return s ? { from: 'score', value: s.value as number } : null;
  }) as Promise<{ from: string; value: string | number | null; error?: string } | null>;

/** Relative luminance of the composed page (DOM and canvas): a screenshot, decoded in the page */
async function pageLum(page: Page): Promise<number> {
  const png = await page.screenshot({ scale: 'css' });
  return page.evaluate(async (b64) => {
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    const bmp = await createImageBitmap(new Blob([u8], { type: 'image/png' }));
    const c = new OffscreenCanvas(160, 90);
    const g = c.getContext('2d')!;
    g.drawImage(bmp, 0, 0, 160, 90);
    const d = g.getImageData(0, 0, 160, 90).data;
    const lin = (v: number) => {
      const x = v / 255;
      return x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
    };
    let L = 0;
    for (let i = 0; i < d.length; i += 4) L += 0.2126 * lin(d[i]!) + 0.7152 * lin(d[i + 1]!) + 0.0722 * lin(d[i + 2]!);
    return L / (d.length / 4);
  }, png.toString('base64'));
}

/** A screen change QA makes, on the composed page: the luminance before, one and two frames after (a cut shows at once) */
async function screenCut(page: Page, act: () => Promise<void>): Promise<{ before: number; after: number[] }> {
  const before = await pageLum(page);
  await act();
  const after: number[] = [];
  for (let i = 0; i < 2; i++) {
    await frames(page, 1, F60, true);
    after.push(await pageLum(page));
  }
  return { before, after };
}

interface FrameRow {
  t: number;
  play: boolean;
  lum: number | null;
  dx: number;
  dy: number;
}
interface MomentRow {
  t: number;
  kind: string;
  playedSec: number;
  visualMs: number | null;
  domMs: number | null;
}

/** The channels that answered each moment within CHANNEL_MS: visual (canvas or DOM), sound, motion, haptic */
function momentChannels(moments: MomentRow[], fr: FrameRow[], sounds: { t: number }[], vib: number[]): MomentSample[] {
  return moments.map((m) => {
    const ch: string[] = [];
    const vis = Math.min(m.visualMs ?? Infinity, m.domMs ?? Infinity);
    if (vis <= CHANNEL_MS) ch.push('visual');
    if (sounds.some((s) => s.t >= m.t - 1 && s.t <= m.t + CHANNEL_MS)) ch.push('sound');
    const mot = (from: number, to: number) => Math.max(0, ...fr.filter((f) => f.t > from && f.t <= to).map((f) => Math.hypot(f.dx, f.dy)));
    const after = mot(m.t - 1, m.t + CHANNEL_MS);
    if (after >= MOTION_PX && after >= mot(m.t - 100, m.t - 1) + MOTION_PX) ch.push('motion');
    if (vib.some((t) => t >= m.t - 1 && t <= m.t + CHANNEL_MS)) ch.push('haptic');
    return { kind: m.kind, channels: ch };
  });
}

const pct = (x: number | null) => (x === null ? '—' : `${Math.round(x * 100)} %`);
const msTxt = (x: number | null) => (x === null ? '—' : `${Math.round(x)} ms`);

export async function runFeel(ctx: QaContext): Promise<void> {
  const warn = ctx.warn ?? ctx.info;
  const quick = ctx.quick;
  const out: Record<string, unknown> = { at: new Date().toISOString(), view: VIEW, clock: 'virtual' };
  // Seconds of the machine's time each part took (qa/feel.json)
  const timing: Record<string, number> = {};
  out.timing = timing;
  let mark = Date.now();
  const lap = (name: string) => {
    timing[name] = Math.round((Date.now() - mark) / 100) / 10;
    mark = Date.now();
  };
  // Play's cut is measured on the composed page in the input part (a screenshot may resize the page: never before a digest)
  let playCut: { before: number; after: number[] } | null = null;

  // 1. Input → response: QA's own taps and keys in play, no demo bot (its moves would answer for the game)
  {
    const { page, close, ok } = await openVirtual(ctx);
    try {
      if (!ok) {
        ctx.info(S, 'feel', 'not checked: no host.qa({ play }) (the viewport sections say so)');
        return;
      }
      await page.evaluate(() => {
        (window as any).__gpFeel.measure = true;
        (window as any).__gpFeel.arm(null);
      });
      await frames(page, 18, F60, true);
      playCut = await screenCut(page, () => enterPlay(page));
      await frames(page, 30, F60, true);
      const hero = async () =>
        page.evaluate(() => {
          const hq = (window as any).__gp.host.qaDriver.hero;
          const r = typeof hq === 'function' ? hq() : hq;
          return r && r.w > 0 && r.h > 0 ? r : null;
        }) as Promise<{ x: number; y: number; w: number; h: number } | null>;
      const keys = ['ArrowRight', 'Space', 'ArrowLeft'];
      let seed = 11;
      const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
      // Taps and keys in turn; each after a control trial in the same watch (no input: the game's own motion)
      const n = quick ? 12 : 20;
      const sham = (kind: string, code: string) => page.evaluate(([k, c]) => (window as any).__gpFeel.sham(k, c), [kind, code]);
      let keyAt = 0;
      let restarts = 0;
      for (let k = 0; k < n; k++) {
        if (!(await playing(page))) {
          if (restarts++ >= n) break;
          await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
          await frames(page, 30, F60, true);
          if (!(await playing(page))) break;
        }
        if (k % 2 === 0) {
          // A tap on the game where nothing of the UI is on top; the region around it is watched
          let pt: { x: number; y: number } | null = null;
          for (let i = 0; i < 6 && !pt; i++) {
            const x = Math.round(VIEW.width * (0.2 + rnd() * 0.6));
            const y = Math.round(VIEW.height * (0.25 + rnd() * 0.55));
            if (await page.evaluate(([px, py]) => document.elementFromPoint(px!, py!) instanceof HTMLCanvasElement, [x, y])) pt = { x, y };
          }
          if (!pt) continue;
          await page.evaluate((r) => (window as any).__gpFeel.arm(r), { x: pt.x - 70, y: pt.y - 70, w: 140, h: 140 });
          await frames(page, 18, F60, true);
          await sham('tap', 'pointer');
          await frames(page, 32, F60, true);
          await page.mouse.click(pt.x, pt.y);
          await frames(page, 32, F60, true);
        } else {
          // A key: around the hero when the game says where it is, else the whole frame
          const r = await hero();
          const s = r ? Math.max(120, Math.max(r.w, r.h) * 3) : 0;
          await page.evaluate((a) => (window as any).__gpFeel.arm(a), r ? { x: r.x + r.w / 2 - s / 2, y: r.y + r.h / 2 - s / 2, w: s, h: s, hero: true } : null);
          await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur?.());
          await frames(page, 18, F60, true);
          const key = keys[keyAt++ % keys.length]!;
          await sham('key', key);
          await frames(page, 32, F60, true);
          await page.keyboard.down(key);
          await frames(page, 7, F60, true);
          await page.keyboard.up(key);
          await frames(page, 25, F60, true);
        }
      }
      const raw = (await page.evaluate(() => (window as any).__gpFeel.inputs)) as InputTrial[];
      const inputs = inputVisualMs(raw.filter((i) => i.play || i.kind === 'ui'));
      const r = responseReport(inputs);
      out.response = { ...r, inputs };
      const kinds = Object.entries(r.kinds)
        .map(([k, v]) => `${k} ${v.answered}/${v.n} (median ${msTxt(v.medianMs)})`)
        .join(', ');
      const details = `${r.measured} input(s) in play: median ${msTxt(r.medianMs)}, p90 ${msTxt(r.p90Ms)}, ${pct(r.share)} within ${RESPONSE_MS} ms — ${kinds || 'none answered'}${r.unused.length ? `; not used by the game: ${r.unused.join(', ')}` : ''} (frames on the virtual clock at 60 Hz: the game's own delay; a display and a touch panel add theirs)`;
      lap('input');
      if (r.share !== null && r.measured >= 4 && r.share < RESPONSE_SHARE)
        warn(S, `feel: input → response`, `${details}. Under ${pct(RESPONSE_SHARE)} answer within ${RESPONSE_MS} ms (Nielsen's 0.1 s: later feels laggy) — answer every tap and key in the frame it comes (a press state, a squash, a spark where the tap landed), not at the next fixed step of a slow tick or after an animation's wind-up`);
      else ctx.info(S, 'feel: input → response', r.measured ? details : `not measured: no input in play changed the screen (${r.unused.join(', ') || 'no inputs'})`);
    } finally {
      await close();
    }
  }

  // 2–5. The demo: moments and their channels, flashes, the 60 Hz digest, the results' cut, then the long run
  const hasDemo = { v: false };
  let normalJolts: { shake: number; flash: number } | null = null;
  let digest60: Awaited<ReturnType<typeof digestOf>> = null;
  {
    const { page, close, ok } = await openVirtual(ctx);
    try {
      if (!ok) return;
      await page.evaluate(() => ((window as any).__gpFeel.measure = true));
      await frames(page, 18, F60, true);
      await enterPlay(page);
      hasDemo.v = await demoOn(page);
      const t0 = await page.evaluate(() => performance.now());
      await frames(page, DIGEST_SEC * 60, F60, true);
      digest60 = await digestOf(page);
      lap('demo 60 Hz');
      const fr10 = ((await page.evaluate(() => (window as any).__gpFeel.frames)) as FrameRow[]).filter((f) => f.t > t0);
      normalJolts = jolts(fr10);
      if (!quick) await frames(page, 10 * 60, F60, true);
      // The results: the round's end on the composed page
      const endCut = (await playing(page)) ? await screenCut(page, () => page.evaluate(() => (window as any).__gp.host.qaDriver.end())) : null;
      await frames(page, 60, F60, true);
      const fr = (await page.evaluate(() => (window as any).__gpFeel.frames)) as FrameRow[];
      const moments = (await page.evaluate(() => (window as any).__gpFeel.moments)) as MomentRow[];
      const sounds = (await page.evaluate(() => (window as any).__gpFeel.sounds())) as { t: number }[];
      const vib = (await page.evaluate(() => (window as any).__gpFeel.vib)) as number[];
      const lums = fr.filter((f) => f.lum !== null) as (FrameRow & { lum: number })[];

      // 2. Feedback channels
      const samples = momentChannels(moments.filter((m) => m.t > t0 && m.kind !== 'screen' && m.kind !== 'fail'), fr, sounds, vib);
      const ch = channelReport(samples);
      out.channels = { ...ch, demo: hasDemo.v };
      const list = Object.entries(ch.kinds)
        .map(([k, v]) => `${k} ×${v.n}: median ${v.medianChannels} channel(s) (${Object.entries(v.channels).map(([c, n]) => `${c} ${n}`).join(', ') || 'none'})`)
        .join('; ');
      if (!samples.length) ctx.info(S, 'feel: feedback channels', `no host moment in ${quick ? 10 : 20} s of ${hasDemo.v ? 'the demo bot' : 'an idle run (no host.qa({ demo }))'} — host.happytime() on a scoring action, host.emit('score', { score }) on a score change`);
      else if (ch.scoringMedian !== null && ch.scoringMedian < MIN_CHANNELS)
        warn(S, 'feel: feedback channels', `${list}. A scoring moment gets ${ch.scoringMedian} channel(s) within ${CHANNEL_MS} ms; it wants ≥ ${MIN_CHANNELS} (juice is one action answered through several channels: a pop and a spark on screen, a sound, a small shake — Hicks et al. 2018, Kao 2020)`);
      else ctx.info(S, 'feel: feedback channels', `${list} — channels within ${CHANNEL_MS} ms: visual (canvas or DOM), sound (an effect started), motion (the whole frame moves), haptic`);

      // 3. Flashes (fail), cuts (warn)
      if (lums.length < 60) ctx.info(S, 'feel: flashes', 'not measured: no canvas to read');
      else {
        const f = flashes(lums);
        out.flashes = { frames: lums.length, maxPerSec: f.maxPerSec, at: f.at, transitions: f.transitions.length, lumRange: [Math.min(...lums.map((l) => l.lum)), Math.max(...lums.map((l) => l.lum))] };
        ctx.check(
          S,
          `no more than ${MAX_FLASHES_PER_SEC} flashes in any second (WCAG 2.3.1)`,
          f.maxPerSec <= MAX_FLASHES_PER_SEC,
          `${f.maxPerSec} flash(es) in the worst second${f.at !== null ? ` (ending ${((f.at - t0) / 1000).toFixed(1)} s into the run)` : ''}, ${f.transitions.length} transition(s) of ≥ ${FLASH_DELTA * 100} % luminance over ${(lums.length / 60).toFixed(0)} s of the canvas at 60 Hz${f.maxPerSec > MAX_FLASHES_PER_SEC ? ' — flashing more than 3 times a second can trigger seizures: cap fx.flash to one per ⅓ s, keep a flash small (the hit thing, not the screen) or dim (under 10 % of the frame\'s luminance)' : ''}`,
        );
      }
      const cuts: { at: string; d: number }[] = [];
      for (const [name, c] of [['Play', playCut], ['results', endCut]] as const) if (c) cuts.push({ at: name, d: Math.max(...c.after.map((a) => Math.abs(a - c.before))) });
      for (const m of moments.filter((x) => x.kind === 'screen')) {
        const d = cutAt(lums, m.t);
        if (d !== null) cuts.push({ at: `screen at ${((m.t - t0) / 1000).toFixed(1)} s`, d });
      }
      out.cuts = cuts;
      const hard = cuts.filter((c) => c.d >= CUT_DELTA);
      if (hard.length) warn(S, 'feel: screen changes', `${hard.map((c) => `${c.at}: ${Math.round(c.d * 100)} %`).join(', ')} change of the frame's luminance within two frames — a hard cut to bright or dark; fade the change (a crossfade of 250–400 ms, never a cut to white)`);
      else if (cuts.length) ctx.info(S, 'feel: screen changes', `${cuts.map((c) => `${c.at} ${Math.round(c.d * 100)} %`).join(', ')} (the composed page's luminance within two frames; under ${CUT_DELTA * 100} %)`);

      lap('demo, results');
      // 5. Variety over time: the long run, ticks only (no pictures), as far as the wall budget lets it go
      if (!hasDemo.v) ctx.info(S, 'feel: variety over time', 'not measured: no host.qa({ demo }) to play a long run');
      else {
        const budget = Date.now() + (quick ? 15000 : 40000);
        let restarts = 0;
        let stopped = 0;
        while (Date.now() < budget) {
          const played = (await page.evaluate(() => (window as any).__gp.host.playedSec)) as number;
          if (played >= VARIETY_MARKS_SEC[VARIETY_MARKS_SEC.length - 1]!) break;
          if (!(await playing(page))) {
            stopped++;
            if (stopped > 2) {
              if (restarts++ > 60) break;
              await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
              await frames(page, 2, F60, false);
              await demoOn(page);
              stopped = 0;
            }
            await frames(page, 15, 1000 / 30, false);
            continue;
          }
          await frames(page, 90, 1000 / 30, false, 'stopped');
        }
        const v = (await page.evaluate(() => {
          const h = (window as any).__gp.host;
          return { seen: h.seenLog ?? [], played: h.playedSec, rewards: ((window as any).__gpFeel.moments as MomentRow[]).filter((m) => m.kind === 'highlight' || m.kind === 'twist').map((m) => m.playedSec) };
        })) as { seen: { kind: string; id: string; playedSec: number }[]; played: number; rewards: number[] };
        lap('variety');
        const rep = varietyReport(v.seen, v.played, v.rewards);
        out.variety = { ...rep, seen: v.seen, restarts };
        const marks = rep.at.map((a) => `${a.sec / 60} min: ${a.distinct === null ? '—' : `${a.distinct}${a.kinds ? ` (${Object.entries(a.kinds).map(([k, n]) => `${k} ${n}`).join(', ')})` : ''}`}`).join(' · ');
        const rewards = `rewards: ${rep.rewardGaps.n + (v.rewards.length ? 1 : 0)}, median gap ${rep.rewardGaps.medianSec === null ? '—' : `${rep.rewardGaps.medianSec.toFixed(1)} s`}, longest ${rep.rewardGaps.maxSec === null ? '—' : `${rep.rewardGaps.maxSec.toFixed(1)} s`}`;
        const reach = `the demo played ${Math.round(rep.playedSec)} s on the virtual clock (${restarts} restart(s))`;
        if (!v.seen.length) ctx.info(S, 'feel: variety over time', `host.seen not called: variety not counted (call host.seen(kind, id) when the player meets a new enemy, item, card or place); ${rewards}; ${reach}`);
        else {
          const gap = rep.longestGap;
          const lines = `distinct by ${marks}; longest stretch with nothing new ${gap ? `${Math.round(gap.sec)} s (${Math.round(gap.from)}–${Math.round(gap.to)} s)` : '—'}; ${rewards}; ${reach}`;
          if (gap && gap.sec > VARIETY_GAP_SEC) warn(S, 'feel: variety over time', `${lines}. Nothing new for over ${VARIETY_GAP_SEC} s of play — judges' most frequent remark is "no variety": bring in a new enemy, obstacle, item or place every minute or so (a new kind by minute 2, another by minute 5)`);
          else ctx.info(S, 'feel: variety over time', lines);
        }
        if (rep.rewardGaps.medianSec !== null && rep.rewardGaps.medianSec > REWARD_GAP_SEC) warn(S, 'feel: reward cadence', `${rewards} — over ${REWARD_GAP_SEC} s between rewards (host.happytime) is a long dry stretch: a pickup, a level-up or a combo more often`);
      }
    } finally {
      await close();
    }
  }

  // 4. Frame-rate independence: the same seeded run at 144 Hz
  {
    if (digest60 === null) ctx.info(S, 'feel: 60 vs 144 Hz', 'not compared: no host.qa({ digest }) and no score event — return a digest of the state (the score, positions rounded) and QA plays the same seeded run at 60 and 144 Hz');
    else {
      const { page, close, ok } = await openVirtual(ctx);
      try {
        if (ok) {
          await frames(page, 18, F60, false);
          await enterPlay(page);
          if (hasDemo.v) await demoOn(page);
          await frames(page, DIGEST_SEC * 144, 1000 / 144, false);
          const d144 = await digestOf(page);
          lap('144 Hz');
          const a = (digest60 as { value: string | number | null }).value;
          const b = d144?.value ?? null;
          out.refresh = { from: (digest60 as { from: string }).from, at60: a, at144: b, tolerance: DIGEST_TOLERANCE };
          const what = `${(digest60 as { from: string }).from === 'digest' ? 'host.qa digest' : 'the last score event'} after ${DIGEST_SEC} s of ${hasDemo.v ? 'the demo' : 'an idle run'}, seed 7: ${JSON.stringify(a)} at 60 Hz, ${JSON.stringify(b)} at 144 Hz`;
          if (a === null || b === null) ctx.info(S, 'feel: 60 vs 144 Hz', `not compared: ${what}`);
          else if (!digestsAgree(a, b)) warn(S, 'feel: 60 vs 144 Hz', `${what} — the simulation follows the frame rate: on a 144 Hz monitor the game plays differently (CrazyGames tests 144 and 165 Hz). Step it in fixed steps (an accumulator: while (acc >= DT) update(DT)) and draw what the steps left`);
          else ctx.info(S, 'feel: 60 vs 144 Hz', `${what} — the same (tolerance ${DIGEST_TOLERANCE * 100} %)`);
        }
      } finally {
        await close();
      }
    }
  }

  // 3b. prefers-reduced-motion: the same demo, the frame must not shake or flash
  if (normalJolts && hasDemo.v) {
    const { page, close, ok } = await openVirtual(ctx, { reducedMotion: true });
    try {
      if (ok) {
        await page.evaluate(() => ((window as any).__gpFeel.measure = true));
        await frames(page, 18, F60, true);
        await enterPlay(page);
        await demoOn(page);
        const t0 = await page.evaluate(() => performance.now());
        await frames(page, DIGEST_SEC * 60, F60, true);
        const fr = ((await page.evaluate(() => (window as any).__gpFeel.frames)) as FrameRow[]).filter((f) => f.t > t0);
        const rm = jolts(fr);
        lap('reduced motion');
        const n = normalJolts as { shake: number; flash: number };
        out.reducedMotion = { normal: n, reduced: rm };
        const before = n.shake + n.flash;
        const after = rm.shake + rm.flash;
        const txt = `${DIGEST_SEC} s of the demo: ${n.shake} shaking and ${n.flash} flashing frame(s) normally, ${rm.shake} and ${rm.flash} with prefers-reduced-motion: reduce`;
        if (before === 0) ctx.info(S, 'feel: reduced motion', `${txt} — no shake or flash to stop`);
        else if (after >= Math.max(3, before * 0.5)) warn(S, 'feel: reduced motion', `${txt} — the frame still jolts for a player who asked for less motion: no screen shake, kick or full-screen flash when matchMedia('(prefers-reduced-motion: reduce)') matches (@gp/art's Camera and Fx.flash do it by themselves)`);
        else ctx.info(S, 'feel: reduced motion', `${txt} — it stops`);
      }
    } finally {
      await close();
    }
  }
  writeFileSync(join(ctx.outDir, 'feel.json'), JSON.stringify(out, null, 2));
}
