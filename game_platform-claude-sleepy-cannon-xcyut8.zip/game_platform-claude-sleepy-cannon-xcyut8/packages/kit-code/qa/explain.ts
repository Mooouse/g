// The twist's explanation, judged (concept.twist.explained): pure, so it is unit-tested without a browser.
// The suite samples the screen during the demo bot's first run (is the text visible right now, and in what words) and
// this decides: some stretch of the run showed it — before the twist, or at it — long enough to read.
//
// Echoflies' playtest: the line that explained its echoes was on screen for 30 ms; QA (116/116) and the code review
// could not see it, because QA proved that the twist happens, not that a player is told what it is.

import { readableText, readingSec } from '@gp/core/reading';

/** One look at the screen, `t` seconds after Play */
export interface ExplainSample {
  t: number;
  visible: boolean;
  /** The whole text the phrase appears in, as shown (what the player has to read) */
  text?: string;
  /** Where it was found: the DOM, or a host.qa canvasUi rect with `text` */
  where?: 'dom' | 'canvas';
  /** Why a phrase that is on the page doesn't count as visible (off screen, faded out, too small) */
  why?: string;
}

/** A stretch of the run the explanation was visible, in seconds after Play */
export interface Episode {
  start: number;
  end: number;
  text: string;
  where: 'dom' | 'canvas';
  /** Still visible at the last sample: its end is not known yet */
  open: boolean;
}

/** After the twist fires, the explanation may come this much later and still count as shown "at" it (the next frame, a beat) */
export const EXPLAIN_GRACE_SEC = 1;

/** The phrase and the page's text, compared as a player reads them: case, spacing and curly quotes don't matter */
export function normalizeText(s: string): string {
  return readableText(s.normalize('NFKC').replace(/[‘’]/g, "'").replace(/[“”]/g, '"')).toLowerCase();
}

/** The stretches of visible samples: one ends at the first sample that doesn't show it */
export function episodes(samples: readonly ExplainSample[]): Episode[] {
  const out: Episode[] = [];
  let cur: Episode | null = null;
  for (const s of samples) {
    if (s.visible) {
      if (!cur) cur = { start: s.t, end: s.t, text: s.text ?? '', where: s.where ?? 'dom', open: true };
      cur.end = s.t;
    } else if (cur) {
      cur.end = s.t;
      cur.open = false;
      out.push(cur);
      cur = null;
    }
  }
  if (cur) out.push(cur);
  return out;
}

export interface ExplainVerdict {
  ok: boolean;
  /** Seconds the best stretch needed (readingSec of its text) */
  needSec: number;
  /** The stretch that came closest */
  best: Episode | null;
  text: string;
}

const sec = (x: number) => `${x.toFixed(x < 1 ? 2 : 1)} s`;
const quote = (s: string) => `"${s.length > 60 ? `${s.slice(0, 57)}…` : s}"`;

/**
 * Was the explanation readable before or when the twist first fired? A stretch counts when it starts no later than the
 * twist + EXPLAIN_GRACE_SEC (any stretch when the twist never fired) and lasts readingSec(its text): 2 s + 50 ms a
 * character, at most 8 s. A stretch still open at the last sample counts with the length seen so far.
 */
export function judgeExplanation(o: { samples: readonly ExplainSample[]; twistAt: number | null; phrase: string }): ExplainVerdict {
  const eps = episodes(o.samples);
  const limit = o.twistAt === null ? Infinity : o.twistAt + EXPLAIN_GRACE_SEC;
  const twist = o.twistAt === null ? 'the twist never fired' : `the twist at ${sec(o.twistAt)}`;
  const candidates = eps.filter((e) => e.start <= limit);
  const need = (e: Episode) => readingSec(e.text || o.phrase);
  const best = candidates.reduce<Episode | null>((b, e) => (!b || (e.end - e.start) / need(e) > (b.end - b.start) / need(b) ? e : b), null);
  if (!best) {
    const late = eps[0];
    const why = [...new Set(o.samples.filter((s) => !s.visible && s.why).map((s) => s.why!))].slice(0, 2);
    const text = late
      ? `${quote(o.phrase)} first shown at ${sec(late.start)}, after ${twist}: a new player meets the twist before being told what it is — show it before or when host.twist() fires`
      : `${quote(o.phrase)} never visible in the run (DOM text, or a canvasUi rect with text)${why.length ? `: on the page but ${why.join('; ')}` : ''} — show it before or when host.twist() fires (${twist})`;
    return { ok: false, needSec: readingSec(o.phrase), best: null, text };
  }
  const n = need(best);
  const shown = best.end - best.start;
  const ok = shown >= n - 0.05;
  const chars = [...readableText(best.text || o.phrase)].length;
  const where = best.where === 'canvas' ? ' (canvas)' : '';
  const text = ok
    ? `${quote(best.text || o.phrase)}${where} visible ${best.open ? `≥ ${sec(shown)}` : sec(shown)} from ${sec(best.start)} (${twist}); ${sec(n)} needed for ${chars} characters`
    : `${quote(best.text || o.phrase)}${where} visible ${sec(shown)} at most (from ${sec(best.start)}, ${twist}); ${sec(n)} needed to read its ${chars} characters (2 s + 50 ms each) — keep it on screen until read; a hint that waits for a tap: let the demo bot wait readingSec(text) too`;
  return { ok, needSec: n, best, text };
}
