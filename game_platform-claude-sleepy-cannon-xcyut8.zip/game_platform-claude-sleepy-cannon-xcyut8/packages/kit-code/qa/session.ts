// The code kit's session section: where a new player's session ENDS. Every Basic Launch we had stopped on CrazyGames'
// average playtime (3–6 min a session where 10+ is the bar: publisher/results.yaml), and nothing measured it before the
// portal did. This section plays a first visit on the virtual clock (the demo bot when the game has one, else an idle
// run) for up to 15 minutes of play, and goes through every natural break as a new player would: it waits for an
// auto-continue, else taps the big button that goes on (Next, Play again, No thanks — never Menu, never a rewarded
// offer), up to three taps. At each break it records what pulls the player on and what stops them:
//   pulls: the next run starting by itself (auto-continue), a next goal on the results whose progress moved, something
//          new met in the run that ended (host.seen), a meta screen on the way (a shop, a map, a pick), a reward timer;
//   stops: back on the title by itself, no way back into play in three taps, a wait of over 20 s, only a rewarded offer
//          to go on (a soft paywall), a goal that didn't move (an empty goal), results with nothing but Play again, and
//          3 minutes of play with nothing new or celebrated (host.seen, host.happytime, host.twist).
// The first natural stop is where a typical new player closes the tab; before 10 min of play it warns on crazygames
// (W_SESSION_SHORT). A hazard model turns the breaks into an expected session (minutes): calibrated so that Hang the
// Moon's results screen every minute gives ≈ 4 min, an endless arena's instant restart ≈ 8 and Candle Crypt's long
// runs ≈ 11, near what they did on the portal (4.0–4.8, 6.8, 9.5–11.7). The numbers go to qa/session.json; the judges below are pure (test/session.test.ts).

import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Browser, Page } from 'playwright';
import type { QaContext } from '@gp/qa';
import { demoOn, enterPlay, F60, frames, openVirtual, playing } from './feel.ts';

/* eslint-disable @typescript-eslint/no-explicit-any */

const S = 'session';
/** Minutes of play the section plays (a new player's 12-minute review, and some) */
export const SESSION_TARGET_SEC = 15 * 60;
/** The first natural stop before this many minutes of play warns (W_SESSION_SHORT): the portal's 10+ min */
export const SESSION_SHORT_MIN = 10;
/** Nothing new or celebrated for this many seconds of play is a natural stop mid-run */
export const DRY_SEC = 180;
/** Waiting longer than this before play can go on is a stop (a timer, a slow screen) */
export const WAIT_SEC = 20;
/**
 * The machine's time the section may take (a full run; --quick: QUICK_WALL_MS). Frames are drawn at 30 Hz on the virtual
 * clock (games clamp their step at 1/30–1/10 s, so a bigger step would slow their world): a light game reaches the 15
 * minutes, a heavy one less — then the estimate goes on at the rate it measured, and the report says how far it got
 */
export const WALL_MS = 100000;
export const QUICK_WALL_MS = 20000;
/** Taps a new player gives a screen to get back into play */
export const MAX_TAPS = 3;
/** A pull's weight; a break needs PULL_ENOUGH or it is a natural stop */
export const PULL_WEIGHT: Record<Pull, number> = { auto: 2, goal: 2, unlock: 2, new: 1, meta: 1, timer: 1 };
export const PULL_ENOUGH = 2;
/**
 * The hazard model: the share of the players still here who leave at a break, by its pull score (0, 1, 2, 3+) — or
 * HAZARD.stop at a hard stop (the title, no way on, a wait, a paywall) — and per minute of play (more in a dry stretch).
 * Calibrated on our recorded sessions: a results screen a minute with nothing pulling ≈ 4 min (Hang the Moon: 4.0–4.8),
 * an instant restart every 1.5 min ≈ 8 (Spin Brawl: 6.8), 8-minute runs with a goal moving ≈ 11 (Candle Crypt: 9.5–11.7)
 */
export const HAZARD = { perMin: 0.08, dryPerMin: 0.12, stop: 0.45, byScore: [0.15, 0.11, 0.07, 0.04] } as const;
/** The stops a player meets as a wall, not as a weak pull */
export const HARD_STOPS: readonly StopKind[] = ['title', 'dead-end', 'wait', 'paywall'];
/** The estimate's horizon: a session never counts for more than this */
export const HORIZON_MIN = 60;
/** Screens on the way between runs that are the meta (a shop, a map, a pick) */
const META_SCREEN = /shop|upgrade|map|pick|choice|draft|reward|loot|sites|album|season|skill|tree|forge|workshop|loadout|deck|camp|base|hub/i;

export type Pull = 'auto' | 'goal' | 'unlock' | 'new' | 'meta' | 'timer';
export type StopKind = 'title' | 'dead-end' | 'wait' | 'paywall' | 'empty-goal' | 'no-pull' | 'dry';

/** What QA saw at one natural break: from the run's stop to play again */
export interface BreakObs {
  /** Seconds of play when the run stopped (host.playedSec) */
  atSec: number;
  /** Seconds in the game (the page's clock since the first gameplay) */
  atSessionSec: number;
  /** host.roundEnd before it ('results'), host.fail ('fail'), or neither ('stop': a pause, a screen of the game's own) */
  ended: 'results' | 'fail' | 'stop';
  /** host.screen names from the stop to play again */
  screens: string[];
  /** mountResults' screen, when it was one */
  results: { primary: string | null; autoSec: number | null; goal: { label: string; progress: number | null } | null; menu: boolean } | null;
  /** The only way on was a rewarded offer (and Menu) */
  rewardedOnly: boolean;
  /** No DOM button to tap at all (a canvas UI): QA went on with host.qa play() and judges it as a plain Play again */
  noDom: boolean;
  /** A timer on screen (a gift, a restock, tomorrow's reward) */
  timer: boolean;
  /** host.seen first sightings in the run that ended */
  newInRun: number;
  /** host.happytime / host.twist in the run that ended */
  rewardsInRun: number;
  /** How play went on: by itself, by the player's taps, or only by QA's play() (no way on for a player) */
  resumed: 'auto' | 'tap' | 'qa';
  /** What was tapped, in order */
  taps: string[];
  /** Seconds from the stop to play again (the page's clock) */
  waitSec: number;
}

export interface BreakJudgement {
  pulls: Pull[];
  score: number;
  stop: { kind: StopKind; why: string } | null;
}

const pct = (x: number) => `${Math.floor(x * 100)} %`;

/** One break judged: its pulls, their score, and whether it is a natural stop (and why) */
export function judgeBreak(b: BreakObs, prevGoal: { label: string; progress: number | null } | null): BreakJudgement {
  const pulls: Pull[] = [];
  const g = b.results?.goal ?? null;
  let stuck = false;
  if (b.resumed === 'auto') pulls.push('auto');
  if (g && g.progress !== null) {
    if (g.progress >= 1) pulls.push('unlock');
    else if (!prevGoal || prevGoal.label !== g.label || prevGoal.progress === null || g.progress > prevGoal.progress + 0.005) pulls.push('goal');
    else stuck = true;
  } else if (g) pulls.push('goal');
  if (b.newInRun > 0) pulls.push('new');
  if (b.screens.some((s) => META_SCREEN.test(s))) pulls.push('meta');
  if (b.timer) pulls.push('timer');
  const score = pulls.reduce((n, p) => n + PULL_WEIGHT[p], 0);
  const stop = ((): BreakJudgement['stop'] => {
    if (b.resumed === 'qa' && !b.noDom) return { kind: 'dead-end', why: `no way back into play in ${MAX_TAPS} taps${b.taps.length ? ` (${b.taps.join(' → ')})` : ''}${b.screens.length ? ` on ${b.screens.join(' → ')}` : ''}` };
    if (b.screens.includes('title') && b.resumed !== 'auto') return { kind: 'title', why: 'back on the title by itself: the player has to choose to play again' };
    if (b.rewardedOnly) return { kind: 'paywall', why: 'only a rewarded offer goes on: a soft paywall' };
    if (b.waitSec > WAIT_SEC + (b.results?.autoSec ?? 0)) return { kind: 'wait', why: `${Math.round(b.waitSec)} s before play can go on` };
    // A pause inside a run (a level-up pick, a shop mid-run: no round end, no fail) is no exit unless it is a wall
    if (score >= PULL_ENOUGH || b.ended === 'stop') return null;
    if (stuck && g) return { kind: 'empty-goal', why: `the goal "${g.label}" didn't move (${pct(g.progress ?? 0)}): nothing to finish next run` };
    const what = b.results ? `the results with only ${b.results.primary === 'next' ? 'Next' : 'Play again'}` : b.noDom ? 'a screen QA can\'t read (canvas UI)' : b.ended === 'fail' ? 'a loss' : b.ended === 'results' ? `the game's own results${b.taps.length ? ` (${b.taps.join(' → ')})` : ''}` : 'a stop';
    return { kind: 'no-pull', why: `${what}: no auto-continue, no goal that moved, ${b.newInRun ? 'only something new' : 'nothing new'} — nothing pulls into the next run` };
  })();
  return { pulls, score, stop };
}

/** Stretches of play with nothing new or celebrated, longer than DRY_SEC: from, to (s of play) */
export function dryStretches(news: number[], playedSec: number, dry = DRY_SEC): { from: number; to: number }[] {
  const ts = [0, ...[...news].sort((a, b) => a - b), playedSec];
  const out: { from: number; to: number }[] = [];
  for (let i = 1; i < ts.length; i++) if (ts[i]! - ts[i - 1]! > dry) out.push({ from: ts[i - 1]!, to: ts[i]! });
  return out;
}

export interface SessionStop {
  kind: StopKind;
  why: string;
  /** Seconds of play */
  atSec: number;
  /** Seconds in the game */
  atSessionSec: number;
  /** The break's number (1-based; 0 for a dry stretch mid-run) */
  n: number;
}

export interface SessionEstimate {
  /** Expected minutes of play of a new player who got past the first minute (the hazard model, to HORIZON_MIN) */
  meanMin: number;
  /** Where half of them have left (minutes of play; HORIZON_MIN when more than half are still there) */
  medianMin: number;
  /** The share still playing at 10 minutes */
  at10: number;
}

/**
 * The hazard model over what QA played: the survival falls by HAZARD.perMin a minute (dryPerMin inside a dry stretch)
 * and at each break by its pull score's share (HAZARD.stop at a hard stop); past the end of the run it goes on at the rate it
 * fell at, so a short run extrapolates its own pattern
 */
export function sessionEstimate(breaks: { atSec: number; score: number; hard: boolean }[], playedSec: number, dry: { from: number; to: number }[]): SessionEstimate {
  const step = 1;
  let s = 1;
  let area = 0;
  let median: number | null = null;
  let at10: number | null = null;
  const end = Math.min(playedSec, HORIZON_MIN * 60);
  const bs = [...breaks].sort((a, b) => a.atSec - b.atSec);
  let bi = 0;
  for (let t = 0; t < end; t += step) {
    const inDry = dry.some((d) => t >= d.from + DRY_SEC && t < d.to);
    s *= Math.exp(-((inDry ? HAZARD.dryPerMin : HAZARD.perMin) * step) / 60);
    while (bi < bs.length && bs[bi]!.atSec <= t + step) {
      const b = bs[bi++]!;
      s *= 1 - (b.hard ? HAZARD.stop : HAZARD.byScore[Math.min(3, b.score)]!);
    }
    area += (s * step) / 60;
    if (median === null && s <= 0.5) median = (t + step) / 60;
    if (at10 === null && t + step >= 600) at10 = s;
  }
  // The tail: at the rate it fell at so far
  const endMin = end / 60;
  const rate = endMin > 0 && s > 0 && s < 1 ? -Math.log(s) / endMin : HAZARD.perMin;
  const left = HORIZON_MIN - endMin;
  if (left > 0 && s > 0) {
    area += (s * (1 - Math.exp(-rate * left))) / rate;
    if (median === null && s > 0.5) {
      const m = endMin + Math.log(s / 0.5) / rate;
      median = m <= HORIZON_MIN ? m : null;
    }
    if (at10 === null) at10 = endMin >= 10 ? s : s * Math.exp(-rate * (10 - endMin));
  }
  return { meanMin: Math.round(area * 10) / 10, medianMin: Math.round((median ?? HORIZON_MIN) * 10) / 10, at10: Math.round((at10 ?? s) * 100) / 100 };
}

export interface SessionReport {
  bot: 'demo' | 'idle';
  /** Seconds of play the section reached */
  playedSec: number;
  breaks: (BreakObs & BreakJudgement)[];
  dry: { from: number; to: number }[];
  firstStop: SessionStop | null;
  estimate: SessionEstimate;
  /** How often each pull appeared at a break */
  pulls: Partial<Record<Pull, number>>;
  /** The first natural stop came before SESSION_SHORT_MIN of play */
  short: boolean;
}

/** The whole judgement: every break judged, the dry stretches, the first natural stop and the estimate */
export function sessionReport(bot: 'demo' | 'idle', obs: BreakObs[], news: number[], playedSec: number): SessionReport {
  const breaks: SessionReport['breaks'] = [];
  let prev: { label: string; progress: number | null } | null = null;
  for (const b of obs) {
    const j = judgeBreak(b, prev);
    breaks.push({ ...b, ...j });
    if (b.results?.goal) prev = b.results.goal;
  }
  // A break that pulls is news too (a goal that moved, a meta screen): the dry clock starts again there
  const pulled = breaks.filter((b) => b.pulls.some((p) => p !== 'auto')).map((b) => b.atSec);
  const dry = dryStretches([...news, ...pulled], playedSec);
  const stops: SessionStop[] = [
    ...breaks.flatMap((b, i) => (b.stop ? [{ ...b.stop, atSec: b.atSec, atSessionSec: b.atSessionSec, n: i + 1 }] : [])),
    ...dry.map((d) => ({ kind: 'dry' as const, why: `nothing new or celebrated for ${Math.round(d.to - d.from)} s of play (${clock(d.from)}–${clock(d.to)})`, atSec: d.from + DRY_SEC, atSessionSec: d.from + DRY_SEC, n: 0 })),
  ].sort((a, b) => a.atSec - b.atSec);
  const firstStop = stops[0] ?? null;
  const pulls: SessionReport['pulls'] = {};
  for (const b of breaks) for (const p of b.pulls) pulls[p] = (pulls[p] ?? 0) + 1;
  const estimate = sessionEstimate(
    // A pause inside a run that went on is no break for the model (players don't leave at a level-up pick)
    breaks.filter((b) => b.ended !== 'stop' || b.stop).map((b) => ({ atSec: b.atSec, score: b.score, hard: !!b.stop && HARD_STOPS.includes(b.stop.kind) })),
    playedSec,
    dry,
  );
  // Short: the first natural stop before 10 min; or, when the measure ended earlier with none, half the players gone before 10
  const short = firstStop ? firstStop.atSec < SESSION_SHORT_MIN * 60 : playedSec < SESSION_SHORT_MIN * 60 && estimate.medianMin < SESSION_SHORT_MIN;
  return { bot, playedSec, breaks, dry, firstStop, estimate, pulls, short };
}

/** Seconds → "m:ss" */
export const clock = (sec: number): string => `${Math.floor(sec / 60)}:${String(Math.round(sec % 60)).padStart(2, '0')}`.replace(/:60$/, ':59');

const PULL_WORDS: Record<Pull, string> = { auto: 'auto-continue', goal: 'a goal that moved', unlock: 'a goal reached', new: 'something new', meta: 'a meta screen', timer: 'a reward timer' };

/** The report's lines: the first stop, the breaks, what pulls (pure, for the report and the review brief) */
export function sessionLines(r: SessionReport): { stop: string; breaks: string; pulls: string; estimate: string } {
  const st = r.firstStop;
  const stop = st ? `${clock(st.atSec)} of play${st.n ? ` (break ${st.n})` : ''}: ${st.why}` : `none in ${clock(r.playedSec)} of play${r.playedSec < SESSION_SHORT_MIN * 60 ? ' (as far as the measure got)' : ''}`;
  const breaks = r.breaks.length
    ? r.breaks
        .slice(0, 12)
        .map((b, i) => `${i + 1}. ${clock(b.atSec)} ${b.results ? `results${b.results.goal ? ` · goal "${b.results.goal.label}"${b.results.goal.progress !== null ? ` ${pct(b.results.goal.progress)}` : ''}` : ''}` : b.ended === 'fail' ? 'a loss' : b.ended === 'results' ? 'results (the game\'s own screen)' : 'a pause in the run'}${b.screens.length ? ` [${[...new Set(b.screens)].join(', ')}]` : ''} → ${b.resumed === 'auto' ? 'went on by itself' : b.resumed === 'tap' ? `${b.taps.join(' → ') || 'a tap'}` : 'no way on (QA played)'}${b.pulls.length ? `; pulls: ${b.pulls.map((p) => PULL_WORDS[p]).join(', ')}` : ''}${b.stop ? ` — STOP (${b.stop.kind})` : ''}`)
        .join(' · ') + (r.breaks.length > 12 ? ` · … ${r.breaks.length - 12} more` : '')
    : 'no break: one run the whole time';
  const pulls = Object.entries(r.pulls).map(([p, n]) => `${PULL_WORDS[p as Pull]} ×${n}`).join(', ') || 'nothing';
  const e = r.estimate;
  const estimate = `≈ ${e.meanMin} min expected (half the players gone by ${e.medianMin >= HORIZON_MIN ? `${HORIZON_MIN}+` : e.medianMin} min, ${Math.round(e.at10 * 100)} % still playing at 10 min)`;
  return { stop, breaks, pulls, estimate };
}

// --- Driving the page -----------------------------------------------------------------------------------------------

const D30 = 1000 / 30;

/** The page's log of the host's moments (installed once the game is loaded) */
const hookLog = (page: Page) =>
  page.evaluate(() => {
    const w = window as any;
    if (w.__gpSession) return;
    w.__gpSession = { log: [] };
    w.__gp.events.on((e: { type: string; data: any }) => {
      if (!['screen', 'round:end', 'fail', 'highlight', 'twist'].includes(e.type)) return;
      w.__gpSession.log.push({ type: e.type, name: e.data?.name ?? null, playedSec: w.__gp.host.playedSec, t: performance.now() });
    });
  });

const state = (page: Page) =>
  page.evaluate(() => {
    const w = window as any;
    const h = w.__gp.host;
    return { played: h.playedSec as number, t: performance.now(), seen: (h.seenLog ?? []).length as number, log: (w.__gpSession?.log ?? []).length as number };
  });

/** What is on screen at a break: the results, the buttons a player could tap, a timer (also `gp design`'s capture: it goes on as this section does) */
export const look = (page: Page) =>
  page.evaluate(() => {
    const vis = (e: Element) => {
      const r = (e as HTMLElement).getBoundingClientRect();
      const cs = getComputedStyle(e);
      return r.width > 2 && r.height > 2 && cs.visibility !== 'hidden' && cs.display !== 'none' && Number(cs.opacity) > 0.05 && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
    };
    const res = [...document.querySelectorAll('[data-gp=results]')].find(vis) as HTMLElement | undefined;
    const prim = res?.querySelector('.gp-primary') as HTMLElement | null;
    const g = res?.querySelector('[data-gp=results-goal]') as HTMLElement | null;
    document.querySelectorAll('[data-gp-session-idx]').forEach((e) => e.removeAttribute('data-gp-session-idx'));
    const all = [...document.querySelectorAll('button, [role=button]')].filter((e) => vis(e) && !(e as HTMLButtonElement).disabled) as HTMLElement[];
    const buttons = all.map((b, i) => {
      b.dataset.gpSessionIdx = String(i);
      const r = b.getBoundingClientRect();
      return { idx: i, gp: b.dataset.gp ?? null, rewarded: !!b.closest('[data-gp-rewarded]'), area: r.width * r.height, text: (b.textContent ?? '').trim().replace(/\s+/g, ' ').slice(0, 40) };
    });
    const timer = [...document.querySelectorAll('[data-gp-timer], [data-gp$="-wait"], [data-gp$="-timer"], [data-gp=streak-tomorrow], [data-gp=season-when]')].some(vis);
    return {
      results: res
        ? {
            primary: prim?.dataset.gp ?? null,
            autoSec: prim?.dataset.gpAuto ? Number(prim.dataset.gpAuto) : null,
            goal: g ? { label: (g.querySelector('.gp-goal-l')?.textContent ?? '').trim(), progress: g.dataset.gpProgress ? Number(g.dataset.gpProgress) : null } : null,
            menu: !!res.querySelector('[data-gp=menu]'),
          }
        : null,
      buttons,
      timer,
    };
  });

/** The button a new player taps to go on: the continuing ones first, else the biggest that is no menu and no ad */
const GO_ON = ['next', 'again', 'play', 'continue', 'welcome-continue', 'skip', 'dialog-skip', 'seed-play', 'streak-claim', 'streak-close', 'welcome-close'];
const NOT_ON = /^(menu|settings|lang|language|sound|music|mute|credits|privacy|sign-in|share|fullscreen|exit|back|home)/i;
export function pickButton(buttons: { idx: number; gp: string | null; rewarded: boolean; area: number; text: string }[]): { idx: number; label: string } | null {
  const free = buttons.filter((b) => !b.rewarded);
  for (const id of GO_ON) {
    const b = free.find((x) => x.gp === id);
    if (b) return { idx: b.idx, label: b.gp! };
  }
  const rest = free.filter((b) => !(b.gp && NOT_ON.test(b.gp)) && !NOT_ON.test(b.text)).sort((a, b) => b.area - a.area);
  // The last resort: Menu (the title's Play comes next — a stop on the way, judged as such)
  const out = rest[0] ?? free.find((b) => /^(menu|home|back)/i.test(b.gp ?? b.text));
  return out ? { idx: out.idx, label: out.gp ?? (out.text || 'a button') } : null;
}

export async function tapIdx(page: Page, idx: number): Promise<void> {
  const box = await page.locator(`[data-gp-session-idx="${idx}"]`).first().boundingBox({ timeout: 200 }).catch(() => null);
  if (box) await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
}

/** Up to `sec` seconds of the page's clock, until play goes on */
async function untilPlaying(page: Page, sec: number): Promise<boolean> {
  for (let i = 0; i < Math.ceil(sec * 2); i++) {
    if (await playing(page)) return true;
    await frames(page, 15, D30, false);
  }
  return playing(page);
}

/** The section (the code kit's `session`): a new player's session on the virtual clock, qa/session.json */
export async function runSession(ctx: QaContext, browser?: Browser): Promise<void> {
  const gated = ctx.game.channel.id === 'crazygames';
  const warn = gated ? (ctx.warn ?? ctx.info) : ctx.info;
  const name = `the first natural stop after ${SESSION_SHORT_MIN} min of play (a new player on desktop; W_SESSION_SHORT${gated ? '' : ', a warning on crazygames'})`;
  const { page, close, ok } = await openVirtual(ctx, browser ? { browser } : {});
  try {
    if (!ok) return void ctx.info(S, name, 'not measured: the game did not load on the virtual clock, or has no host.qa({ play })');
    await hookLog(page);
    if (!(await playing(page))) await enterPlay(page);
    await frames(page, 4, F60, false);
    const hasDemo = await demoOn(page);
    const t0 = (await state(page)).t;
    const budget = Date.now() + (ctx.quick ? QUICK_WALL_MS : WALL_MS);
    const obs: BreakObs[] = [];
    let run = await state(page);
    let stalls = 0;
    while (Date.now() < budget) {
      const st = await state(page);
      if (st.played >= SESSION_TARGET_SEC) break;
      if (await playing(page)) {
        await frames(page, 90, D30, false, 'stopped');
        continue;
      }
      // A stop: give the screen half a second to settle, then go on as a new player would
      const at = await state(page);
      await frames(page, 15, D30, false);
      const log = (await page.evaluate((from) => (window as any).__gpSession.log.slice(from), run.log)) as { type: string; name: string | null; playedSec: number }[];
      const ended: BreakObs['ended'] = log.some((l) => l.type === 'round:end') ? 'results' : log.some((l) => l.type === 'fail') ? 'fail' : 'stop';
      const rewardsInRun = log.filter((l) => l.type === 'highlight' || l.type === 'twist').length;
      if (await playing(page)) {
        // Play again within half a second: an instant restart is a break that went on by itself; a blink of a pause is none
        if (ended !== 'stop') {
          obs.push({ atSec: at.played, atSessionSec: Math.round((at.t - t0) / 100) / 10, ended, screens: [], results: null, rewardedOnly: false, noDom: false, timer: false, newInRun: at.seen - run.seen, rewardsInRun, resumed: 'auto', taps: [], waitSec: 0.5 });
          run = await state(page);
        }
        continue;
      }
      const first = await look(page);
      let resumed: BreakObs['resumed'] | null = null;
      const taps: string[] = [];
      let noDom = false;
      let rewardedOnly = false;
      let timer = first.timer;
      // The results may come after another screen (a Continue offer skipped): the last results screen seen
      let results = first.results;
      if (first.results?.autoSec && (await untilPlaying(page, first.results.autoSec + 2))) resumed = 'auto';
      else if (!first.buttons.length && (await untilPlaying(page, 3))) resumed = 'auto';
      while (!resumed && taps.length < MAX_TAPS) {
        const now = await look(page);
        timer ||= now.timer;
        results = now.results ?? results;
        const pick = pickButton(now.buttons);
        if (!pick) {
          if (!now.buttons.length) noDom = !taps.length;
          else rewardedOnly = now.buttons.some((b) => b.rewarded);
          break;
        }
        taps.push(pick.label);
        await tapIdx(page, pick.idx);
        if (await untilPlaying(page, 8)) resumed = 'tap';
      }
      if (!resumed) {
        await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
        await untilPlaying(page, 3);
        resumed = 'qa';
      }
      const after = await state(page);
      const whole = (await page.evaluate((from) => (window as any).__gpSession.log.slice(from), run.log)) as { type: string; name: string | null }[];
      const screens = whole.filter((l) => l.type === 'screen' && l.name).map((l) => l.name!);
      obs.push({
        atSec: at.played,
        atSessionSec: Math.round((at.t - t0) / 100) / 10,
        // The round may end after the stop (a Continue offer skipped, then the results)
        ended: whole.some((l) => l.type === 'round:end') ? 'results' : ended,
        screens,
        results,
        rewardedOnly,
        noDom,
        timer,
        newInRun: at.seen - run.seen,
        rewardsInRun,
        resumed,
        taps,
        waitSec: Math.round((after.t - at.t) / 100) / 10,
      });
      if (hasDemo) await demoOn(page);
      // Play didn't go on even by QA's hand: stop here
      if (!(await playing(page)) && ++stalls > 2) break;
      run = await state(page);
    }
    const end = await page.evaluate(() => {
      const w = window as any;
      const h = w.__gp.host;
      return { played: h.playedSec as number, seen: (h.seenLog ?? []).map((s: { playedSec: number }) => s.playedSec) as number[], rewards: (w.__gpSession.log as { type: string; playedSec: number }[]).filter((l) => l.type === 'highlight' || l.type === 'twist').map((l) => l.playedSec) };
    });
    const rep = sessionReport(hasDemo ? 'demo' : 'idle', obs, [...end.seen, ...end.rewards], end.played);
    const lines = sessionLines(rep);
    writeFileSync(join(ctx.outDir, 'session.json'), JSON.stringify({ at: new Date().toISOString(), channel: ctx.game.channel.id, clock: 'virtual', targetSec: SESSION_TARGET_SEC, ...rep, lines }, null, 2));
    const who = hasDemo ? 'the demo bot (host.qa({ demo }))' : 'an idle player (no host.qa({ demo }): every run is as long as touching nothing makes it — a lower bound)';
    const reach = `${clock(rep.playedSec)} of play by ${who}, ${rep.breaks.length} break(s), on the virtual clock`;
    const detail = `first natural stop: ${lines.stop}. Estimate: ${lines.estimate}. What pulls on: ${lines.pulls}. Breaks: ${lines.breaks}. (${reach}; qa/session.json)`;
    if (rep.short)
      warn(S, name, `${detail} — every Basic Launch we had stopped on average playtime (3–6 min; Candle Crypt's 9m31s scored 4/5 on desktop): push the first natural stop past ${SESSION_SHORT_MIN} min — auto-continue into the next run (mountResults autoContinueSec), the next goal on the results with its progress moving, a meta reward every 2–3 min, no dead end after the results (docs/guides/first-minute.md → The session; gp explain W_SESSION_SHORT)`);
    else if (rep.playedSec < SESSION_SHORT_MIN * 60) ctx.info(S, name, `not reached: ${detail}${ctx.quick ? ' — --quick plays a shorter session' : ''}`);
    else ctx.info(S, name, detail);
  } finally {
    await close();
  }
}
