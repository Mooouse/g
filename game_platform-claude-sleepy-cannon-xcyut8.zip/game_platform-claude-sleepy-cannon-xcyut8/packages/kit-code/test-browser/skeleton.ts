// The platform's code game skeleton (templates/game-repo, what `gp init` writes) as a test fixture: copied to a temporary
// folder with its TODOs filled, served by the dev server, and a QA context like gp qa's that collects the checks.

import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { chromium, type Browser, type BrowserContextOptions } from 'playwright';
import type { ViteDevServer } from 'vite';
import { expect } from 'vitest';
import type { QaCheck, QaContext } from '@gp/qa';
import type { ResolvedGame } from '@gp/spec';
import { checkGame } from '../../cli/src/game.ts';
import { ROOT } from '../../cli/src/paths.ts';
import { startDev } from '../../cli/src/vite.ts';

export interface Skeleton {
  url: string;
  game: ResolvedGame;
  browser: Browser;
  /** A QA context like gp qa's, collecting the checks; `init` runs in every page before the game (to break it on purpose) */
  qa(opts?: { quick?: boolean; init?: () => void }): { ctx: QaContext; checks: QaCheck[]; infos: { name: string; details: string }[] };
  close(): Promise<void>;
}

export async function startSkeleton(): Promise<Skeleton> {
  const tmp = mkdtempSync(join(tmpdir(), 'gp-qa-skeleton-'));
  const dir = join(tmp, 'games', 'skeleton');
  cpSync(join(ROOT, 'templates/game-repo/games/__ID__'), dir, { recursive: true });
  // Every TODO filled: the words don't matter here, only that the game validates
  const yaml = readFileSync(join(dir, 'game.yaml'), 'utf8')
    .replaceAll('__ID__', 'skeleton')
    .replaceAll('__TITLE__', 'Skeleton Fixture')
    .replace(/genre: TODO/, 'genre: hypercasual')
    .replace(/tags: \[TODO\]/, 'tags: [Casual]')
    .replace(/"TODO: /g, '"');
  writeFileSync(join(dir, 'game.yaml'), yaml);
  writeFileSync(join(dir, 'main.ts'), readFileSync(join(dir, 'main.ts'), 'utf8').replaceAll('__TITLE__', 'Skeleton Fixture'));
  const loc = { id: 'skeleton', dir, file: join(dir, 'game.yaml') };
  const r = checkGame(loc, 'dev');
  expect(r.issues.filter((i) => i.severity === 'error')).toEqual([]);
  const game = r.game!;
  const server: ViteDevServer = await startDev(loc);
  const url = server.resolvedUrls!.local[0];
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  return {
    url,
    game,
    browser,
    qa(opts = {}) {
      const checks: QaCheck[] = [];
      const infos: { name: string; details: string }[] = [];
      const wrapped = {
        newContext: async (o?: BrowserContextOptions) => {
          const c = await browser.newContext(o);
          if (opts.init) await c.addInitScript(opts.init);
          return c;
        },
      } as unknown as Browser;
      const ctx: QaContext = {
        url,
        game,
        outDir: mkdtempSync(join(tmp, 'qa-')),
        quick: !!opts.quick,
        browser: wrapped,
        canvasUi: {},
        check: (scope, name, ok, details = '') => void checks.push({ scope, name, ok, details }),
        info: (_scope, name, details) => void infos.push({ name, details }),
      };
      return { ctx, checks, infos };
    },
    async close() {
      await browser.close();
      await server.close();
      rmSync(tmp, { recursive: true, force: true });
    },
  };
}
