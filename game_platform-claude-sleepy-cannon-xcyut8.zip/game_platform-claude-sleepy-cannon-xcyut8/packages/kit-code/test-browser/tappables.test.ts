// Browser test of the code kit's touch-target check (tappables in qa/suite.ts): a button reached by scrolling passes
// only when a player can scroll to it. Runs with `npm run test:browser` (needs Playwright's Chromium).

import { chromium, type Browser, type Page } from 'playwright';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { panelScrolls, tappables } from '../qa/suite.ts';

let browser: Browser;

beforeAll(async () => {
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
});

async function open(body: string, viewport = { width: 640, height: 360 }): Promise<Page> {
  const page = await browser.newPage({ viewport });
  await page.setContent(`<!doctype html><html><head><style>
    html, body { margin: 0; overflow: hidden; }
    button { display: block; width: 200px; height: 60px; margin: 0; }
  </style></head><body>${body}</body></html>`);
  return page;
}

/** Items above the Buy button, so it starts below the panel's fold */
const rows = (n: number) => Array.from({ length: n }, (_, i) => `<button>Item ${i + 1}</button>`).join('');

describe('tappables: scrolling panels', () => {
  it('fails a button a player cannot reach: the page does not scroll and the panel runs off screen', async () => {
    // A 400 px panel starting at y=200 on a 360 px screen: at the panel's full scroll the button still ends at y=440
    const page = await open(`<div style="height:200px"></div>
      <div id="panel" style="height:400px; overflow:auto">${rows(6)}<button>Buy</button></div>`);
    const t = await tappables(page, 44);
    expect(t.bad.some((b) => b.startsWith('Buy: off screen'))).toBe(true);
    // Nothing stays scrolled: neither the page nor the panel
    expect(await page.evaluate(() => [document.scrollingElement!.scrollTop, document.getElementById('panel')!.scrollTop])).toEqual([0, 0]);
    await page.close();
  });

  it('never scrolls an overflow:hidden box to reach a button', async () => {
    const page = await open(`<div style="height:300px; overflow:hidden">${rows(6)}<button>Buy</button></div>`);
    const t = await tappables(page, 44);
    expect(t.scrolled).toBe(0);
    expect(t.bad.some((b) => b.startsWith('Buy: off screen'))).toBe(true);
    await page.close();
  });

  it('passes a scroll-panel shop on screen, and puts the scroll position back', async () => {
    const page = await open(`<div style="height:60px"></div>
      <div id="panel" style="height:280px; overflow-y:auto">${rows(8)}<button>Buy</button></div>`);
    await page.evaluate(() => (document.getElementById('panel')!.scrollTop = 30));
    const t = await tappables(page, 44);
    expect(t.bad).toEqual([]);
    expect(t.scrolled).toBeGreaterThan(0);
    expect(await page.evaluate(() => document.getElementById('panel')!.scrollTop)).toBe(30);
    await page.close();
  });

  it('scrolls a panel taller than the screen to the part of it that is on screen', async () => {
    // The panel runs 140 px past the bottom of the screen; its bottom padding lets a player scroll every button up into view
    const page = await open(`<div style="height:100px"></div>
      <div style="height:400px; box-sizing:border-box; overflow:auto; padding-bottom:150px">${rows(10)}<button>Buy</button></div>`);
    const t = await tappables(page, 44);
    expect(t.bad).toEqual([]);
    await page.close();
  });

  it('fails a button covered once scrolled into view', async () => {
    const page = await open(`<div style="height:300px; overflow:auto">${rows(6)}<button>Buy</button></div>
      <div style="position:fixed; left:0; top:0; width:640px; height:360px; z-index:5"></div>`);
    const t = await tappables(page, 44);
    expect(t.bad).toContain('Buy: covered once scrolled into view');
    await page.close();
  });
});

describe('panelScrolls: one screen (the owner, 2026-10-10)', () => {
  it('fails a panel the player has to scroll, passes one whose content fits', async () => {
    const page = await open(`<div id="shop" style="height:200px; overflow:auto">${rows(6)}</div><div style="height:120px; overflow:auto">${rows(1)}</div>`);
    const p = await panelScrolls(page);
    expect(p.bad).toHaveLength(1);
    expect(p.bad[0]).toMatch(/^div#shop \(360 px of content in 200\)/);
    expect(p.allowed).toEqual([]);
    await page.close();
  });

  it('lists a message marked data-gp-scroll as allowed, with its reason', async () => {
    const page = await open(`<div data-gp-scroll="the story so far"><div style="height:100px; overflow-y:auto">${rows(4)}</div></div>`);
    const p = await panelScrolls(page);
    expect(p.bad).toEqual([]);
    expect(p.allowed[0]).toContain('the story so far');
    await page.close();
  });
});
