// Browser test of the code kit's check "the first minute explains the twist" (concept.twist.explained, qa/suite.ts
// runTwist) on the platform's code game skeleton: its HUD says "Tap the target!" for 4 s from Play → passes; the same game
// with the HUD hidden 30 ms after it shows (Echoflies before its playtest) → fails. Runs with `npm run test:browser`.

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { runTwist } from '../qa/suite.ts';
import { startSkeleton, type Skeleton } from './skeleton.ts';

let sk: Skeleton;

beforeAll(async () => {
  sk = await startSkeleton();
}, 120000);

afterAll(async () => {
  await sk?.close();
});

/** Echoflies before its playtest: the explaining line goes away 30 ms after it shows */
function flashHud(): void {
  const seen = new WeakSet<Element>();
  new MutationObserver(() => {
    const hud = document.querySelector<HTMLElement>('[data-gp=hud]');
    if (!hud || seen.has(hud) || !/tap the target/i.test(hud.textContent ?? '')) return;
    seen.add(hud);
    setTimeout(() => (hud.style.visibility = 'hidden'), 30);
  }).observe(document, { subtree: true, childList: true, characterData: true });
}

describe('QA: the first minute explains the twist (concept.twist.explained)', () => {
  it('the skeleton: "Tap the target!" is on screen 4 s from Play — passes', async () => {
    expect(sk.game.concept?.twist?.explained).toBe('Tap the target');
    const { ctx, checks } = sk.qa();
    await runTwist(ctx);
    const twist = checks.find((c) => c.name.startsWith('twist "first-hit" happens'))!;
    expect(twist.ok, twist.details).toBe(true);
    const ex = checks.find((c) => c.name.startsWith('twist explained'))!;
    expect(ex.ok, ex.details).toBe(true);
    expect(ex.details).toMatch(/"Tap the target!" visible/);
    const json = JSON.parse(readFileSync(join(ctx.outDir, 'uniqueness.json'), 'utf8'));
    expect(json.explained).toMatchObject({ phrase: 'Tap the target', ok: true });
  }, 60000);

  it('the same game with its HUD hidden 30 ms after it shows — fails, and says how long it needed', async () => {
    const { ctx, checks } = sk.qa({ init: flashHud });
    await runTwist(ctx);
    // The twist itself still happens: only the explanation is gone
    expect(checks.find((c) => c.name.startsWith('twist "first-hit" happens'))!.ok).toBe(true);
    const ex = checks.find((c) => c.name.startsWith('twist explained'))!;
    expect(ex.ok).toBe(false);
    expect(ex.details).toMatch(/visible 0\.\d+ s at most .*2\.8 s needed to read its 15 characters/);
  }, 60000);
});
