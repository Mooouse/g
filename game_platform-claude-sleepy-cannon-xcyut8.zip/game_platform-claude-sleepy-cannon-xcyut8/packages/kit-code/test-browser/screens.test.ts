// Browser test of the code kit's check of every screen (host.qa({ screens }), qa/suite.ts runScreens) on the platform's
// code game skeleton: its five screens at the whole size matrix → pass; with its buttons squeezed to 30 px and their text
// cut off → fail; a screen that throws → fails alone. And textFit on hand-made pages. Runs with `npm run test:browser`.

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Page } from 'playwright';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { runScreens, screenSizes, textFit } from '../qa/suite.ts';
import { startSkeleton, type Skeleton } from './skeleton.ts';

let sk: Skeleton;

beforeAll(async () => {
  sk = await startSkeleton();
}, 120000);

afterAll(async () => {
  await sk?.close();
});

describe('QA: every screen (host.qa screens)', () => {
  it('the size matrix: the three viewports, and a portal game the two small frames (one viewport with --quick)', () => {
    expect(screenSizes(false, true).map((s) => s.name)).toEqual(['phone-portrait-360x800', 'phone-landscape-800x360', 'desktop-1280x720', 'desktop-821x462', 'mobile-800x450']);
    expect(screenSizes(true, true).map((s) => s.name)).toEqual(['phone-portrait-360x800']);
    expect(screenSizes(false, false)).toHaveLength(3);
  });

  it("the skeleton's five screens at every size — pass, with a screenshot each", async () => {
    const { ctx, checks, infos } = sk.qa();
    await runScreens(ctx);
    const failed = checks.filter((c) => !c.ok);
    expect(failed, JSON.stringify(failed, null, 1)).toEqual([]);
    for (const s of ['title', 'targets', 'paused', 'so-close', 'results'])
      for (const size of screenSizes(false, true)) expect(checks.some((c) => c.name.startsWith(`"${s}" ${size.name}: buttons on screen`)), `${s} ${size.name}`).toBe(true);
    // Tab after a click on the canvas, at the desktop size
    expect(checks.filter((c) => c.name.includes('Tab reaches the buttons')).length).toBeGreaterThan(0);
    expect(readFileSync(join(ctx.outDir, 'screen-so-close-mobile-800x450.png')).length).toBeGreaterThan(1000);
    const time = infos.find((i) => i.name === 'time')!;
    expect(time.details).toMatch(/^5 screens × 5 sizes in /);
    console.log(`screens: ${time.details}`);
  }, 120000);

  it('the same screens with the buttons squeezed to 30 px and their text cut off — fail, naming what', async () => {
    const squeeze = () => {
      document.addEventListener('DOMContentLoaded', () => {
        const st = document.createElement('style');
        st.textContent = '#ui button { min-width: 0 !important; width: 30px !important; min-height: 0 !important; height: 30px; padding: 0 !important; white-space: nowrap; overflow: hidden; }';
        document.head.append(st);
      });
    };
    const { ctx, checks } = sk.qa({ quick: true, init: squeeze });
    await runScreens(ctx);
    const title = checks.find((c) => c.name.startsWith('"title" phone-portrait-360x800: buttons'))!;
    expect(title.ok).toBe(false);
    expect(title.details).toMatch(/Play: 30×30/);
    expect(title.details).toMatch(/text "Play" cut off by button/);
  }, 60000);

  it('a screen that throws when opened — fails with its error, the others are still checked', async () => {
    const broken = () => {
      const t = setInterval(() => {
        const d = (window as unknown as { __gp?: { host?: { qaDriver?: { screens?: Record<string, () => void> } } } }).__gp?.host?.qaDriver;
        if (!d?.screens) return;
        clearInterval(t);
        d.screens = {
          ...d.screens,
          journal: () => {
            throw new Error('no journal yet');
          },
        };
      }, 5);
    };
    const { ctx, checks } = sk.qa({ quick: true, init: broken });
    await runScreens(ctx);
    const j = checks.find((c) => c.name.startsWith('"journal"'))!;
    expect(j.ok).toBe(false);
    expect(j.details).toContain('no journal yet');
    expect(checks.find((c) => c.name.startsWith('"results" phone-portrait'))!.ok).toBe(true);
  }, 60000);
});

describe('textFit', () => {
  async function open(body: string, viewport = { width: 400, height: 300 }): Promise<Page> {
    const page = await sk.browser.newPage({ viewport });
    await page.setContent(`<!doctype html><html><head><style>html, body { margin: 0; overflow: hidden; font: 16px sans-serif; } button { font: 16px sans-serif; }</style></head><body>${body}</body></html>`);
    return page;
  }
  it('passes text that fits, and text in a panel a player can scroll', async () => {
    const page = await open(`<p>Fits</p><div style="height:100px; overflow:auto"><div style="height:600px">top</div><p>far down, reachable</p></div><button style="width:200px">Play</button>`);
    expect(await textFit(page)).toEqual({ offscreen: [], clipped: [], spills: [], scroll: false });
    await page.close();
  });
  it('finds text cut off by overflow:hidden, an ellipsis, text out of its button and text off screen', async () => {
    const page = await open(`
      <div style="width:60px; overflow:hidden; white-space:nowrap">A long label that is cut</div>
      <div style="width:60px; overflow:hidden; white-space:nowrap; text-overflow:ellipsis">Ellipsis text here</div>
      <button style="width:40px; white-space:nowrap; overflow:visible">Continue the run</button>
      <p style="position:absolute; left:380px; top:10px; white-space:nowrap">Off the edge</p>`);
    const f = await textFit(page);
    expect(f.clipped.some((x) => x.startsWith('"A long label that is cut" cut off by div'))).toBe(true);
    expect(f.clipped.some((x) => x.startsWith('"Ellipsis text here" cut off'))).toBe(true);
    expect(f.spills).toEqual(['"Continue the run" out of its button']);
    expect(f.offscreen.some((x) => x.startsWith('"Off the edge"'))).toBe(true);
    await page.close();
  });
  it('skips text that is visually hidden on purpose (sr-only, an aria-live region like the dialogue\'s .gp-live)', async () => {
    const page = await open(`
      <div aria-live="polite" style="position:absolute; width:1px; height:1px; overflow:hidden; clip-path:inset(50%); white-space:nowrap">A long line the screen reader hears</div>
      <span style="position:absolute; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden; clip:rect(0, 0, 0, 0); white-space:nowrap">Skip to the game</span>
      <div role="status" style="position:absolute; left:-10000px; top:0; white-space:nowrap">Wave 3 cleared</div>
      <p style="position:absolute; left:-200px; top:40px; white-space:nowrap">Not hidden, off the edge</p>`);
    const f = await textFit(page);
    expect(f.clipped).toEqual([]);
    // An ordinary text off screen is still found
    expect(f.offscreen.map((x) => x.split(' at ')[0])).toEqual(['"Not hidden, off the edge"']);
    await page.close();
  });
  it('a box under CSS zoom (Candle Crypt zooms its panels on big screens): text that fits is not "cut off"', async () => {
    const page = await open(`<div style="zoom:1.5; width:200px; overflow:hidden; padding:4px; border:3px solid #000">Fits at any zoom</div>`, { width: 800, height: 400 });
    expect((await textFit(page)).clipped).toEqual([]);
    await page.close();
  });
  it('a page that scrolls', async () => {
    const page = await sk.browser.newPage({ viewport: { width: 400, height: 300 } });
    await page.setContent('<!doctype html><body style="margin:0"><div style="height:900px">tall</div></body>');
    expect((await textFit(page)).scroll).toBe(true);
    await page.close();
  });
});
