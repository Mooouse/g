// QA's "save: survives a reload unchanged" leaves the offline stamp out (packages/kit-code/qa/suite.ts
// withoutOfflineStamp): Craft Pickaxe Idle stamped the time away on pagehide, as offline.ts says, and QA failed it

import { describe, expect, it } from 'vitest';
import { offlineEarnings, stampOffline } from '../../core/src/offline.ts';
import { withoutOfflineStamp } from '../qa/suite.ts';

describe('the reload check ignores the offline stamp', () => {
  it('a moved stamp (pagehide, start) is no change; a changed pay-out or another field is', () => {
    const save: Record<string, unknown> = { coins: 5, offline: { at: 0, pending: null } };
    stampOffline(save, { now: () => 1000 });
    const before = JSON.stringify(save);
    stampOffline(save, { now: () => 5000 });
    expect(JSON.stringify(save)).not.toBe(before);
    expect(withoutOfflineStamp(JSON.stringify(save))).toBe(withoutOfflineStamp(before));
    // Under any field name and nested; the pending pay-out still counts
    const a = JSON.stringify({ meta: { away: { at: 1, pending: { amount: 3, seconds: 9 } } } });
    const b = JSON.stringify({ meta: { away: { pending: { amount: 3, seconds: 9 }, at: 2 } } });
    expect(withoutOfflineStamp(a)).toBe(withoutOfflineStamp(b));
    expect(withoutOfflineStamp(a)).not.toBe(withoutOfflineStamp(JSON.stringify({ meta: { away: { at: 1, pending: { amount: 4, seconds: 9 } } } })));
    expect(withoutOfflineStamp(JSON.stringify({ coins: 5, offline: { at: 1, pending: null } }))).not.toBe(withoutOfflineStamp(JSON.stringify({ coins: 6, offline: { at: 1, pending: null } })));
    // An object that only has an `at` is the game's own field, not the stamp
    expect(withoutOfflineStamp('{"at":1}')).not.toBe(withoutOfflineStamp('{"at":2}'));
    expect(withoutOfflineStamp(null)).toBeNull();
    expect(withoutOfflineStamp('{oops')).toBe('{oops');
  });

  it('offlineEarnings at start (a reload under minSec) moves only the stamp', () => {
    const save: Record<string, unknown> = { coins: 1 };
    offlineEarnings(save, {}, () => 2, () => 10_000);
    const before = JSON.stringify(save);
    expect(offlineEarnings(save, {}, () => 2, () => 30_000)).toBeNull();
    expect(withoutOfflineStamp(JSON.stringify(save))).toBe(withoutOfflineStamp(before));
  });
});
