// The feel checks of the code kit's QA, judged without a browser (qa/feel.ts): input → response against control trials,
// feedback channels, WCAG 2.3.1 flashes, shaking frames, the 60/144 Hz digests, variety over time

import { describe, expect, it } from 'vitest';
import { channelReport, cutAt, digestsAgree, flashes, inputVisualMs, jolts, MAX_FLASHES_PER_SEC, responseReport, varietyReport } from '../qa/feel.ts';

const series = (lums: number[], fps = 60) => lums.map((lum, i) => ({ t: (i * 1000) / fps, lum }));

describe('input → response', () => {
  it('counts a kind the game answers more often than its control trials; a key only the animation "answers" is unused', () => {
    const r = responseReport([
      { kind: 'tap', code: 'pointer', ms: 17 },
      { kind: 'tap', code: 'pointer', ms: 33 },
      { kind: 'tap', code: 'pointer', ms: 150 },
      { kind: 'tap', code: 'pointer', ms: null, sham: true },
      { kind: 'tap', code: 'pointer', ms: null, sham: true },
      { kind: 'key', code: 'Space', ms: 50 },
      { kind: 'key', code: 'Space', ms: 67, sham: true },
      { kind: 'key', code: 'KeyQ', ms: null },
    ]);
    expect(r.measured).toBe(3);
    expect(r.unused.sort()).toEqual(['key KeyQ', 'key Space']);
    expect(r.share).toBeCloseTo(2 / 3);
    expect(r.medianMs).toBe(33);
    expect(r.kinds.tap).toMatchObject({ n: 3, answered: 3 });
  });
  it('the arrows and WASD are one group', () => {
    const r = responseReport([
      { kind: 'key', code: 'ArrowLeft', ms: 17 },
      { kind: 'key', code: 'KeyD', ms: 17 },
      { kind: 'key', code: 'ArrowRight', ms: null, sham: true },
    ]);
    expect(r.measured).toBe(2);
    expect(r.unused).toEqual([]);
  });
  it('a kind answered once is noise; an unanswered input of a used kind counts as slow', () => {
    expect(responseReport([{ kind: 'key', code: 'KeyQ', ms: 167 }, { kind: 'key', code: 'KeyQ', ms: null }]).unused).toEqual(['key KeyQ']);
    const r = responseReport([
      { kind: 'tap', code: 'pointer', ms: 17 },
      { kind: 'tap', code: 'pointer', ms: 33 },
      { kind: 'tap', code: 'pointer', ms: null },
      { kind: 'tap', code: 'pointer', ms: null },
    ]);
    expect(r.share).toBe(0.5);
    expect(r.p90Ms).toBe(500);
  });
});

describe('the first visible change after an input', () => {
  it('above the drift, the floor and the control trials; the DOM or the hero moving answer too', () => {
    const t = (o: Partial<Parameters<typeof inputVisualMs>[0][number]>) => ({ kind: 'tap', code: 'pointer', region: 'region' as const, heroMs: null, domMs: null, series: [], ...o });
    const out = inputVisualMs([
      // the control trial: the scene's own motion changes 5 % of the region by the third frame (held to the floor alone)
      t({ sham: true, series: [0.01, 0.03, 0.05, 0.05] }),
      // a spark where the tap landed, in the second frame
      t({ series: [0.01, 0.4, 0.5, 0.5] }),
      // only what the scene does by itself
      t({ series: [0.01, 0.03, 0.05, 0.06] }),
      t({ kind: 'key', code: 'ArrowLeft', region: 'hero', series: [0, 0, 0], heroMs: 17 }),
      t({ kind: 'ui', code: 'pointer', region: 'frame', series: [0], domMs: 17 }),
    ]);
    expect(out.map((o) => o.ms && Math.round(o.ms))).toEqual([33, 33, null, 17, 17]);
    expect(out.map((o) => o.by)).toEqual(['canvas', 'canvas', undefined, 'hero', 'dom']);
  });
});

describe('feedback channels', () => {
  it('the median channels of the scoring moments', () => {
    const c = channelReport([
      { kind: 'highlight', channels: ['visual', 'sound'] },
      { kind: 'highlight', channels: ['visual'] },
      { kind: 'highlight', channels: ['visual', 'sound', 'motion'] },
      { kind: 'round:end', channels: [] },
    ]);
    expect(c.scoringMedian).toBe(2);
    expect(c.kinds.highlight).toMatchObject({ n: 3, medianChannels: 2, channels: { visual: 3, sound: 2, motion: 1 } });
    expect(channelReport([{ kind: 'twist', channels: [] }]).scoringMedian).toBeNull();
  });
});

describe('flashes (WCAG 2.3.1)', () => {
  it('a strobe at 5 Hz is 5 flashes a second; a steady frame none', () => {
    // 6 frames dark, 6 bright: 5 cycles a second at 60 fps
    const strobe = Array.from({ length: 120 }, (_, i) => (Math.floor(i / 6) % 2 ? 0.6 : 0.1));
    const f = flashes(series(strobe));
    expect(f.maxPerSec).toBeGreaterThan(MAX_FLASHES_PER_SEC);
    expect(f.maxPerSec).toBeGreaterThanOrEqual(4);
    expect(flashes(series(Array(120).fill(0.3))).maxPerSec).toBe(0);
  });
  it('two flashes a second pass; small swings and swings between bright frames (both ≥ 0.8) are no transitions', () => {
    const slow = Array.from({ length: 120 }, (_, i) => (Math.floor(i / 15) % 2 ? 0.5 : 0.2));
    expect(flashes(series(slow)).maxPerSec).toBeLessThanOrEqual(2);
    const small = Array.from({ length: 120 }, (_, i) => (i % 6 < 3 ? 0.3 : 0.36));
    expect(flashes(series(small)).maxPerSec).toBe(0);
    const bright = Array.from({ length: 120 }, (_, i) => (i % 6 < 3 ? 0.85 : 0.98));
    expect(flashes(series(bright)).maxPerSec).toBe(0);
  });
  it('a cut: the largest change within two frames around a screen change', () => {
    const s = series([0.1, 0.1, 0.1, 0.1, 0.9, 0.9, 0.9]);
    expect(cutAt(s, 60)).toBeCloseTo(0.8);
    const fade = series(Array.from({ length: 30 }, (_, i) => 0.1 + (0.8 * i) / 29));
    expect(cutAt(fade, 0)!).toBeLessThan(0.1);
  });
});

describe('jolts (reduced motion)', () => {
  it('motion that reverses is a shake; a steady pan is not; a luminance jump in two frames is a flash', () => {
    const shake = Array.from({ length: 10 }, (_, i) => ({ lum: 0.3, dx: i % 2 ? 4 : -4, dy: 0 }));
    expect(jolts(shake).shake).toBe(9);
    const pan = Array.from({ length: 10 }, () => ({ lum: 0.3, dx: 3, dy: 0 }));
    expect(jolts(pan)).toEqual({ shake: 0, flash: 0 });
    expect(jolts([0.2, 0.2, 0.5, 0.5].map((lum) => ({ lum, dx: 0, dy: 0 }))).flash).toBe(2);
  });
});

describe('60 vs 144 Hz', () => {
  it('numbers within the tolerance, strings exactly', () => {
    expect(digestsAgree(1000, 1010)).toBe(true);
    expect(digestsAgree(1000, 1100)).toBe(false);
    expect(digestsAgree('a:1', 'a:1')).toBe(true);
    expect(digestsAgree('a:1', 'a:2')).toBe(false);
  });
});

describe('variety over time (host.seen)', () => {
  it('distinct ids by each mark, the longest stretch with nothing new, the reward gaps', () => {
    const seen = [
      { kind: 'enemy', id: 'bat', playedSec: 5 },
      { kind: 'enemy', id: 'rat', playedSec: 60 },
      { kind: 'item', id: 'key', playedSec: 100 },
      { kind: 'enemy', id: 'boss', playedSec: 280 },
    ];
    const v = varietyReport(seen, 320, [10, 20, 40, 100]);
    expect(v.at[0]).toMatchObject({ sec: 120, distinct: 3, kinds: { enemy: 2, item: 1 } });
    expect(v.at[1]).toMatchObject({ sec: 300, distinct: 4 });
    expect(v.at[2]).toMatchObject({ sec: 600, distinct: null });
    expect(v.longestGap).toEqual({ from: 100, to: 280, sec: 180 });
    expect(v.rewardGaps).toEqual({ n: 3, medianSec: 20, maxSec: 60 });
    expect(varietyReport([], 50, []).longestGap).toBeNull();
  });
});
