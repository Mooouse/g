// The session section of the code kit's QA, judged without a browser (qa/session.ts): what pulls a new player on at a
// break and what stops them, the first natural stop, and the hazard model's estimate against our recorded sessions

import { describe, expect, it } from 'vitest';
import { DRY_SEC, dryStretches, judgeBreak, sessionEstimate, sessionLines, sessionReport, type BreakObs } from '../qa/session.ts';

const b = (atSec: number, o: Partial<BreakObs> = {}): BreakObs => ({
  atSec,
  atSessionSec: atSec,
  ended: 'results',
  screens: ['results'],
  results: { primary: 'again', autoSec: null, goal: null, menu: true },
  rewardedOnly: false,
  noDom: false,
  timer: false,
  newInRun: 0,
  rewardsInRun: 1,
  resumed: 'tap',
  taps: ['again'],
  waitSec: 1,
  ...o,
});
const every = (sec: number, total: number, f: (t: number, i: number) => BreakObs) => {
  const out: BreakObs[] = [];
  for (let t = sec, i = 0; t < total; t += sec, i++) out.push(f(t, i));
  return out;
};
const news = (sec: number, total: number) => {
  const out: number[] = [];
  for (let t = 10; t < total; t += sec) out.push(t);
  return out;
};
const goal = (progress: number, label = 'Star') => ({ primary: 'next', autoSec: null, goal: { label, progress }, menu: true });

describe('a break: what pulls on, what stops', () => {
  it('results with only Play again is a natural stop; an auto-continue or a goal that moved pulls on', () => {
    expect(judgeBreak(b(60), null).stop?.kind).toBe('no-pull');
    expect(judgeBreak(b(60, { results: { primary: 'next', autoSec: 4, goal: null, menu: true }, resumed: 'auto' }), null)).toMatchObject({ pulls: ['auto'], stop: null });
    expect(judgeBreak(b(60, { results: goal(0.4) }), { label: 'Star', progress: 0.2 })).toMatchObject({ pulls: ['goal'], stop: null });
    // The goal shown but not moved: an empty goal
    expect(judgeBreak(b(60, { results: goal(0.4) }), { label: 'Star', progress: 0.4 }).stop?.kind).toBe('empty-goal');
    // A goal reached is an unlock; something new + a meta screen pull on together
    expect(judgeBreak(b(60, { results: goal(1) }), { label: 'Star', progress: 0.9 }).pulls).toEqual(['unlock']);
    expect(judgeBreak(b(60, { newInRun: 2, screens: ['results', 'shop'] }), null)).toMatchObject({ pulls: ['new', 'meta'], score: 2, stop: null });
  });
  it('the hard stops: back on the title, no way on, a soft paywall, a long wait', () => {
    expect(judgeBreak(b(60, { screens: ['results', 'title'], taps: ['menu', 'play'] }), null).stop?.kind).toBe('title');
    expect(judgeBreak(b(60, { resumed: 'qa', taps: ['next', 'next', 'next'] }), null).stop?.kind).toBe('dead-end');
    expect(judgeBreak(b(60, { resumed: 'qa', rewardedOnly: true, taps: [] }), null).stop?.kind).toBe('dead-end');
    expect(judgeBreak(b(60, { rewardedOnly: true, results: goal(0.5) }), null).stop?.kind).toBe('paywall');
    expect(judgeBreak(b(60, { waitSec: 45, results: goal(0.5) }), null).stop?.kind).toBe('wait');
    // A canvas UI QA can't read is no dead end: judged as a plain Play again
    expect(judgeBreak(b(60, { resumed: 'qa', noDom: true, results: null }), null).stop?.kind).toBe('no-pull');
  });
  it('a pause inside a run (a level-up pick: no round end, no fail) is no exit — unless it is a wall', () => {
    expect(judgeBreak(b(30, { ended: 'stop', results: null, screens: ['pick'] }), null).stop).toBeNull();
    expect(judgeBreak(b(30, { ended: 'stop', results: null, screens: [] }), null).stop).toBeNull();
    expect(judgeBreak(b(30, { ended: 'stop', results: null, rewardedOnly: true }), null).stop?.kind).toBe('paywall');
    // A survivors-like with a pick every 30 s keeps the estimate of one long run
    const picks = sessionReport('demo', every(30, 900, (t) => b(t, { ended: 'stop', results: null, screens: ['pick'], taps: ['pick'] })), news(30, 900), 900);
    const none = sessionReport('demo', [], news(30, 900), 900);
    expect(picks.firstStop).toBeNull();
    expect(picks.estimate.meanMin).toBe(none.estimate.meanMin);
  });
  it('a dry stretch: nothing new or celebrated for over 3 minutes of play', () => {
    expect(dryStretches([30, 60, 400], 600)).toEqual([{ from: 60, to: 400 }, { from: 400, to: 600 }]);
    expect(dryStretches([30, 60, 200], 300)).toEqual([]);
    const r = sessionReport('demo', every(120, 900, (t, i) => b(t, { results: goal((i + 1) * 0.1), newInRun: 1 })), [20, 100], 900);
    // The goal moved at every break: the dry clock starts again at each, so no dry stretch and no stop
    expect(r.firstStop).toBeNull();
    const dry = sessionReport('demo', [], [20, 100], 900);
    expect(dry.firstStop).toMatchObject({ kind: 'dry', atSec: 100 + DRY_SEC });
  });
});

describe('the session: the first natural stop and the estimate (our recorded sessions)', () => {
  it('Hang the Moon: a results screen a minute with nothing pulling — the first stop at 1:00, ≈ 4 min expected (4.0–4.8 on the portal)', () => {
    const r = sessionReport('demo', every(60, 900, (t) => b(t)), news(30, 900), 900);
    expect(r.firstStop).toMatchObject({ kind: 'no-pull', atSec: 60, n: 1 });
    expect(r.short).toBe(true);
    expect(r.estimate.meanMin).toBeGreaterThan(3);
    expect(r.estimate.meanMin).toBeLessThan(5.5);
    expect(sessionLines(r).stop).toContain('1:00 of play (break 1)');
  });
  it('Spin Brawl: an instant restart every 1.5 min — no stop, ≈ 8 min (6.8); Candle Crypt: 8-minute runs and a goal moving — ≈ 11 (9.5–11.7)', () => {
    const spin = sessionReport('demo', every(90, 900, (t) => b(t, { results: null, screens: [], resumed: 'auto', taps: [] })), news(40, 900), 900);
    expect(spin.firstStop).toBeNull();
    expect(spin.short).toBe(false);
    expect(spin.estimate.meanMin).toBeGreaterThan(6);
    expect(spin.estimate.meanMin).toBeLessThan(10);
    const candle = sessionReport('demo', every(480, 900, (t, i) => b(t, { results: { primary: 'again', autoSec: null, goal: { label: 'Candle', progress: 0.3 + i * 0.3 }, menu: true }, newInRun: 3 })), news(45, 900), 900);
    expect(candle.firstStop).toBeNull();
    expect(candle.estimate.meanMin).toBeGreaterThan(9);
    expect(candle.estimate.meanMin).toBeLessThan(14);
    expect(candle.estimate.meanMin).toBeGreaterThan(spin.estimate.meanMin);
  });
  it('a measure that ended early goes on at the rate it fell at; short when half are gone before 10 min', () => {
    const e = sessionEstimate([{ atSec: 60, score: 2, hard: false }], 130, []);
    expect(e.meanMin).toBeGreaterThan(5);
    const r = sessionReport('demo', every(60, 130, (t) => b(t, { results: { primary: 'next', autoSec: 4, goal: null, menu: true }, resumed: 'auto' })), news(30, 130), 130);
    expect(r.firstStop).toBeNull();
    expect(r.short).toBe(r.estimate.medianMin < 10);
    expect(sessionLines(r).stop).toContain('as far as the measure got');
  });
});
